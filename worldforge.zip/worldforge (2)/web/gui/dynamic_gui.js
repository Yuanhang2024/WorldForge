/* ============================================================
 * web/gui/dynamic_gui.js — runtime builder for an LLM-shaped gui_spec
 *
 *  gui_generation_design.md §6 — the compiled HTML/JS layer takes the
 *  server-produced GUISpec (or compile_to_html_template output) and:
 *    1. injects the compiled layout CSS into the current page
 *    2. instantiates the compiled widget skeleton (real controls + canvas)
 *    3. wires each widget's binds.emit → router.ingest()
 *    4. wires binds.read subscribers to the live state/kernels (poll or push)
 *
 *  Strict safety contract (mirrors gui_generator.py):
 *    - emits are validated against ALLOWED_INTENT_KINDS (closed vocabulary
 *      shared with web/input/router.js DEFAULT_FANOUT — kept in sync by hand).
 *    - reads are forced to start with "kernel:" or "state:".
 *    - actions (when present) come from ALLOWED_ACTIONS only.
 *  Anything we don't recognise is dropped loudly — no silent privilege surface.
 *
 *  Vanilla: no frameworks, no build step. The host wires a router in; if no
 *  stateReader is supplied we run a built-in world-id-scoped state poller and
 *  close the COMMIT → /api/world/tick → refresh loop.
 * ============================================================ */

(function (root) {
  "use strict";

  // ----- closed vocabularies (mirror of gui_generator.py §4.4) ----
  var ALLOWED_INTENT_KINDS = {
    utterance: 1, decision_vector: 1, playfield_action: 1,
  };
  var ALLOWED_ACTIONS = {
    "world/tick": 1, "interact": 1, "game/step": 1, "dispatch": 1,
  };

  // ----- utilities -----

  function uuid() {
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
    return "evt-" + Math.random().toString(36).slice(2) + "-" + Date.now().toString(36);
  }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      for (var k in attrs) {
        if (Object.prototype.hasOwnProperty.call(attrs, k)) {
          if (k === "class") node.className = attrs[k];
          else if (k === "style" && typeof attrs[k] === "object") {
            for (var s in attrs[k]) node.style[s] = attrs[k][s];
          } else if (k.indexOf("data-") === 0) {
            node.setAttribute(k, attrs[k]);
          } else {
            node[k] = attrs[k];
          }
        }
      }
    }
    if (children) {
      for (var i = 0; i < children.length; i++) {
        var c = children[i];
        if (c == null) continue;
        if (typeof c === "string") node.appendChild(document.createTextNode(c));
        else node.appendChild(c);
      }
    }
    return node;
  }

  function camelize(s) { return s.replace(/-([a-z])/g, function (_, c) { return c.toUpperCase(); }); }
  function readAttr(widget, name) {
    return widget.getAttribute(name) || widget.dataset[camelize(name)] || widget.dataset[name] || null;
  }
  function readNumber(widget, name) {
    var v = readAttr(widget, name);
    if (v == null || v === "") return null;
    var n = Number(v);
    return isNaN(n) ? null : n;
  }

  // ----- safety gate (mirror of gui_generator._validate_binds) -----

  function validateBinds(widget) {
    var emit = readAttr(widget, "binds-emit");
    var read = readAttr(widget, "binds-read");
    var commit = readAttr(widget, "binds-commit");
    var action = readAttr(widget, "binds-action");

    if (emit && read) return { ok: false, reason: "binds cannot set both emit and read" };
    if (!emit && !read) return { ok: false, reason: "widget has no binds" };

    if (emit) {
      if (!ALLOWED_INTENT_KINDS[emit]) {
        return { ok: false, reason: "emit '" + emit + "' not in closed intent set" };
      }
      if (commit === "true" && action && !ALLOWED_ACTIONS[action]) {
        return { ok: false, reason: "action '" + action + "' not in closed action set" };
      }
      return { ok: true, kind: "emit", emit: emit, commit: commit === "true",
               action: action, verb: readAttr(widget, "binds-verb") };
    }
    if (read.indexOf("kernel:") !== 0 && read.indexOf("state:") !== 0) {
      return { ok: false, reason: "read must start with 'kernel:' or 'state:'" };
    }
    return { ok: true, kind: "read", read: read };
  }

  function buildDeviceEvent(widget, payload) {
    var now = (typeof performance !== "undefined" && performance.now)
      ? performance.now() : Date.now();
    payload = Object.assign({}, payload || {});
    payload.intent_kind = readAttr(widget, "binds-emit");
    var action = readAttr(widget, "binds-action");
    if (action) payload.action = action;
    return {
      event_id: uuid(),
      device: "gui",
      channel: widget.dataset.type || "generic",
      ts_monotonic_ms: now,
      raw: payload,
      confidence: 1.0,
    };
  }

  // ============================================================
  // Widget skeleton rendering — mirrors gui_generator._widget_inner_html
  // so the runtime can mount a spec produced without the HTML template.
  // ============================================================

  function esc(s) {
    if (s == null) return "";
    return String(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
  }

  function renderInner(widget, wspec) {
    // idempotent: never clobber a host-provided skeleton
    if (widget.children.length > 0) return;
    var type = wspec.type;
    var label = wspec.label || "";
    var title = wspec.title || "";
    var min = wspec.min, max = wspec.max;

    if (type === "slider") {
      widget.appendChild(el("label", { class: "w-label" }, [label]));
      var wrap = el("div", { class: "w-slider-row" });
      var input = el("input", { type: "range", class: "w-range" });
      if (min != null) input.min = String(min);
      if (max != null) input.max = String(max);
      input.step = "0.1";
      input.value = String(min != null ? min : 0);
      var val = el("span", { class: "w-slider-val" }, [String(input.value)]);
      wrap.appendChild(input);
      wrap.appendChild(val);
      widget.appendChild(wrap);
      return;
    }
    if (type === "commit_bar") {
      var btn = el("button", { class: "w-btn", type: "button" }, [label || "COMMIT"]);
      widget.appendChild(btn);
      return;
    }
    if (type === "canvas_panel") {
      widget.appendChild(el("div", { class: "w-panel-header" }, [title]));
      widget.appendChild(el("canvas", { class: "w-canvas" }));
      return;
    }
    if (type === "gauge" || type === "meter") {
      widget.appendChild(el("label", { class: "w-label" }, [label]));
      widget.appendChild(el("canvas", { class: "w-canvas w-gauge-canvas" }));
      return;
    }
    if (type === "lamp") {
      widget.appendChild(el("span", { class: "w-lamp-dot" }));
      widget.appendChild(el("span", { class: "w-lamp-text" }, ["--"]));
      return;
    }
    if (type === "timeline") {
      widget.appendChild(el("div", { class: "w-panel-header" }, [title]));
      widget.appendChild(el("canvas", { class: "w-canvas w-timeline-canvas" }));
      return;
    }
    if (type === "log_feed") {
      widget.appendChild(el("div", { class: "w-panel-header" }, [title]));
      widget.appendChild(el("ul", { class: "w-log" }));
      return;
    }
    // generic fallbacks for the other closed-set types
    if (type === "text_field") {
      widget.appendChild(el("label", { class: "w-label" }, [label]));
      widget.appendChild(el("input", { type: "text", class: "w-input",
                                        placeholder: wspec.placeholder || "" }));
      return;
    }
    if (type === "dial") {
      widget.appendChild(el("label", { class: "w-label" }, [label]));
      widget.appendChild(el("div", { class: "w-dial-knob" }));
      return;
    }
    if (type === "button" || type === "button_group" || type === "card_row") {
      var box = el("div", { class: "w-buttons" });
      var opts = wspec.options || [{ label: label || wspec.name, verb: "" }];
      for (var i = 0; i < opts.length; i++) {
        box.appendChild(el("button", {
          class: "w-btn", type: "button",
          "data-verb": opts[i].verb || "",
        }, [opts[i].label || ""]));
      }
      widget.appendChild(box);
      return;
    }
    if (type === "toggle") {
      widget.appendChild(el("label", { class: "w-label" }, [label]));
      var tog = el("span", { class: "w-toggle" });
      tog.appendChild(el("span", { class: "w-toggle-knob" }));
      widget.appendChild(tog);
      return;
    }
    if (type === "nameplate") {
      widget.appendChild(el("div", { class: "w-name" }, [label]));
      return;
    }
    widget.appendChild(el("div", { class: "w-label" }, [label]));
  }

  // ============================================================
  // Canvas helpers — devicePixelRatio scaling so paint is crisp.
  // ============================================================

  function prepCanvas(canvas) {
    if (!canvas) return null;
    var rect = canvas.getBoundingClientRect();
    var w = Math.max(1, Math.floor(rect.width || 240));
    var h = Math.max(1, Math.floor(rect.height || 160));
    var dpr = window.devicePixelRatio || 1;
    if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
      canvas.width = w * dpr;
      canvas.height = h * dpr;
    }
    var ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    return { ctx: ctx, w: w, h: h };
  }

  function readCssVar(name, fallback) {
    try {
      var v = getComputedStyle(document.documentElement).getPropertyValue(name);
      if (v && v.trim()) return v.trim();
    } catch (e) {}
    return fallback;
  }

  // ============================================================
  // Display painters — each returns an apply(value) fn the state
  // bus calls with the resolved read-target value.
  // ============================================================

  function painterFor(widget, wspec) {
    var type = wspec.type;

    if (type === "canvas_panel") {
      var readTarget = (wspec.binds && wspec.binds.read) || "";
      if (readTarget === "kernel:orbit") return makeOrbitPainter(widget);
      if (readTarget === "kernel:light_series") return makeLightPainter(widget);
      return makeOrbitPainter(widget); // generic canvas fallback
    }
    if (type === "gauge" || type === "meter") return makeGaugePainter(widget, wspec);
    if (type === "lamp") return makeLampPainter(widget);
    if (type === "timeline") return makeTimelinePainter(widget);
    if (type === "log_feed") return makeLogPainter(widget);
    if (type === "nameplate") return makeNameplatePainter(widget);
    return function () {};
  }

  function makeOrbitPainter(widget) {
    var canvas = widget.querySelector("canvas.w-canvas");
    var state = { stars: null, planet: null, frame: 0 };
    function draw() {
      var p = prepCanvas(canvas);
      if (!p) return;
      var ctx = p.ctx, w = p.w, h = p.h;
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.fillRect(0, 0, w, h);
      var cx = w / 2, cy = h / 2;
      var scale = Math.min(w, h) * 0.42;
      // placeholder orbit rings when no data
      if (!state.stars && !state.planet) {
        ctx.strokeStyle = "rgba(255,255,255,0.12)";
        ctx.lineWidth = 1;
        for (var r = 0.3; r <= 0.9; r += 0.3) {
          ctx.beginPath(); ctx.arc(cx, cy, scale * r, 0, Math.PI * 2); ctx.stroke();
        }
        var ph = (Date.now() / 30) % 360;
        var px = cx + Math.cos(ph * Math.PI / 180) * scale * 0.6;
        var py = cy + Math.sin(ph * Math.PI / 180) * scale * 0.6;
        ctx.fillStyle = "#cfe8ff";
        ctx.beginPath(); ctx.arc(px, py, 3, 0, Math.PI * 2); ctx.fill();
        return;
      }
      var stars = state.stars || [];
      var planet = state.planet || [];
      var F = stars.length;
      if (F === 0) return;
      // bounds for autoscale
      var minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9;
      for (var i = 0; i < F; i++) {
        for (var s = 0; s < 3; s++) {
          var sx = stars[i][s][0], sy = stars[i][s][1];
          if (sx < minx) minx = sx; if (sx > maxx) maxx = sx;
          if (sy < miny) miny = sy; if (sy > maxy) maxy = sy;
        }
        var px2 = planet[i][0], py2 = planet[i][1];
        if (px2 < minx) minx = px2; if (px2 > maxx) maxx = px2;
        if (py2 < miny) miny = py2; if (py2 > maxy) maxy = py2;
      }
      var rx = (maxx - minx) || 1, ry = (maxy - miny) || 1;
      var span = Math.max(rx, ry);
      function mapX(v) { return cx + ((v - (minx + maxx) / 2) / span) * scale * 1.8; }
      function mapY(v) { return cy + ((v - (miny + maxy) / 2) / span) * scale * 1.8; }
      var colors = ["#ff8a4c", "#ffd66b", "#8ab4ff"];
      // star trails
      for (s = 0; s < 3; s++) {
        ctx.strokeStyle = colors[s];
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = 1;
        ctx.beginPath();
        var tail = Math.max(0, state.frame - 24);
        for (i = tail; i <= state.frame; i++) {
          var sxp = mapX(stars[i][s][0]), syp = mapY(stars[i][s][1]);
          if (i === tail) ctx.moveTo(sxp, syp); else ctx.lineTo(sxp, syp);
        }
        ctx.stroke();
        ctx.globalAlpha = 1;
        var cur = stars[state.frame][s];
        ctx.fillStyle = colors[s];
        ctx.beginPath(); ctx.arc(mapX(cur[0]), mapY(cur[1]), 3.5, 0, Math.PI * 2); ctx.fill();
      }
      // planet trail + dot
      ctx.strokeStyle = "rgba(207,232,255,0.5)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      tail = Math.max(0, state.frame - 30);
      for (i = tail; i <= state.frame; i++) {
        var pxp = mapX(planet[i][0]), pyp = mapY(planet[i][1]);
        if (i === tail) ctx.moveTo(pxp, pyp); else ctx.lineTo(pxp, pyp);
      }
      ctx.stroke();
      var pc = planet[state.frame];
      ctx.fillStyle = "#ffffff";
      ctx.beginPath(); ctx.arc(mapX(pc[0]), mapY(pc[1]), 4, 0, Math.PI * 2); ctx.fill();
    }
    function tick() {
      if (state.stars) {
        state.frame = (state.frame + 1) % state.stars.length;
        draw();
      } else {
        draw();
      }
    }
    // animate ~20fps when visible
    var raf = setInterval(tick, 60);
    widget._stopPainter = function () { clearInterval(raf); };
    return function apply(value) {
      if (value && value.stars) {
        state.stars = value.stars;
        state.planet = value.planet || state.planet;
        state.frame = 0;
        draw();
      }
    };
  }

  function makeLightPainter(widget) {
    var canvas = widget.querySelector("canvas.w-canvas");
    var state = { illumination: null, temperature: null };
    function draw() {
      var p = prepCanvas(canvas);
      if (!p) return;
      var ctx = p.ctx, w = p.w, h = p.h;
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.fillRect(0, 0, w, h);
      var pad = 6;
      var series = state.illumination;
      if (!series || !series.length) {
        ctx.fillStyle = "rgba(255,255,255,0.4)";
        ctx.font = "12px monospace";
        ctx.fillText("-- 光照/温度序列等待内核 --", pad, h / 2);
        return;
      }
      var n = series.length;
      var mn = Infinity, mx = -Infinity;
      for (var i = 0; i < n; i++) { if (series[i] < mn) mn = series[i]; if (series[i] > mx) mx = series[i]; }
      var temp = state.temperature || [];
      var tmn = Infinity, tmx = -Infinity;
      for (i = 0; i < temp.length; i++) { if (temp[i] < tmn) tmn = temp[i]; if (temp[i] > tmx) tmx = temp[i]; }
      function plot(arr, lo, hi, color) {
        if (!arr || !arr.length) return;
        ctx.strokeStyle = color;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        for (var j = 0; j < arr.length; j++) {
          var x = pad + (j / (arr.length - 1)) * (w - pad * 2);
          var norm = (arr[j] - lo) / ((hi - lo) || 1);
          var y = h - pad - norm * (h - pad * 2);
          if (j === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      plot(series, mn, mx, "#ffd66b");
      plot(temp, tmn, tmx, "#8ab4ff");
      ctx.fillStyle = "rgba(255,255,255,0.55)";
      ctx.font = "10px monospace";
      ctx.fillText("illum", pad, 12);
      ctx.fillText("temp", pad, h - 2);
    }
    widget._stopPainter = function () {};
    return function apply(value) {
      if (value && value.illumination) {
        state.illumination = value.illumination;
        state.temperature = value.temperature || state.temperature;
        draw();
      }
    };
  }

  function makeGaugePainter(widget, wspec) {
    var canvas = widget.querySelector("canvas.w-gauge-canvas");
    var min = wspec.min != null ? Number(wspec.min) : 0;
    var max = wspec.max != null ? Number(wspec.max) : 1;
    var cur = null;
    function draw() {
      var p = prepCanvas(canvas);
      if (!p) return;
      var ctx = p.ctx, w = p.w, h = p.h;
      var cx = w / 2, cy = h * 0.92, r = Math.min(w / 2, h) * 0.85;
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.fillRect(0, 0, w, h);
      // half-circle arc
      ctx.strokeStyle = "rgba(255,255,255,0.18)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, r, Math.PI, Math.PI * 2);
      ctx.stroke();
      var frac = cur == null ? 0 : Math.min(1, Math.max(0, (cur - min) / (max - min || 1)));
      var ang = Math.PI + frac * Math.PI;
      // value arc
      ctx.strokeStyle = frac > 0.7 ? "#ff6b6b" : (frac > 0.4 ? "#ffd66b" : "#7bd88f");
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(cx, cy, r, Math.PI, ang);
      ctx.stroke();
      // needle
      ctx.strokeStyle = "rgba(255,255,255,0.85)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(ang) * r * 0.92, cy + Math.sin(ang) * r * 0.92);
      ctx.stroke();
      ctx.fillStyle = "#fff";
      ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill();
      // readout
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.font = "bold 14px monospace";
      ctx.textAlign = "center";
      ctx.fillText(cur == null ? "--" : cur.toFixed(3), cx, cy - r * 0.35);
      ctx.font = "10px monospace";
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.fillText("λ", cx, cy - r * 0.55);
      ctx.textAlign = "left";
    }
    widget._stopPainter = function () {};
    return function apply(value) {
      if (value == null || value === "") { cur = null; draw(); return; }
      var n = Number(value);
      if (isNaN(n)) return;
      // auto-expand range if value exceeds it so the needle never pins
      if (n > max) max = n * 1.1;
      cur = n;
      draw();
    };
  }

  function makeLampPainter(widget) {
    var dot = widget.querySelector(".w-lamp-dot");
    var text = widget.querySelector(".w-lamp-text");
    widget._stopPainter = function () {};
    return function apply(value) {
      var on = !!value;
      if (dot) dot.classList.toggle("on", on);
      if (dot) dot.classList.toggle("off", !on);
      if (text) text.textContent = on ? "逃离已证明 ✓" : "未证明 ✗";
    };
  }

  function makeTimelinePainter(widget) {
    var canvas = widget.querySelector("canvas.w-timeline-canvas");
    var history = [1]; // civilization count over committed beats
    var forecast = null; // civ_curve from bake (tech sweep)
    function draw() {
      var p = prepCanvas(canvas);
      if (!p) return;
      var ctx = p.ctx, w = p.w, h = p.h;
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.fillRect(0, 0, w, h);
      var pad = 6;
      // sparkline of civ count history
      var n = history.length;
      var mn = Math.min.apply(null, history), mx = Math.max.apply(null, history);
      if (mx === mn) mx = mn + 1;
      var barW = (w - pad * 2) / Math.max(n, 1);
      for (var i = 0; i < n; i++) {
        var norm = (history[i] - mn) / (mx - mn);
        var bh = Math.max(2, norm * (h - pad * 2 - 14));
        var x = pad + i * barW;
        ctx.fillStyle = "#8ab4ff";
        ctx.fillRect(x, h - pad - bh, Math.max(1, barW - 2), bh);
      }
      // current count readout
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.font = "bold 12px monospace";
      ctx.fillText("civ #" + history[n - 1] + " · beats=" + n, pad, 12);
    }
    widget._stopPainter = function () {};
    var apply = function apply(value) {
      // value may be a forecast civ_curve (from bake) or a count int (from tick)
      if (value == null) { draw(); return; }
      if (typeof value === "number") {
        history.push(value);
        if (history.length > 60) history.shift();
        draw();
        return;
      }
      if (value && value.forecast) {
        forecast = value.forecast;
        draw();
        return;
      }
      draw();
    };
    // expose a hook for the state bus to push live count
    widget._pushCivCount = function (c) {
      history.push(c);
      if (history.length > 60) history.shift();
      draw();
    };
    return apply;
  }

  function makeLogPainter(widget) {
    var ul = widget.querySelector(".w-log");
    widget._stopPainter = function () {};
    function append(line) {
      if (!ul || line == null) return;
      var li = el("li", null, [String(line)]);
      ul.appendChild(li);
      while (ul.children.length > 50) ul.removeChild(ul.firstChild);
      ul.scrollTop = ul.scrollHeight;
    }
    function clear() { if (ul) while (ul.firstChild) ul.removeChild(ul.firstChild); }
    return function apply(value) {
      // value: array of lines, or a single string, or {append:[...], replace:[...]}
      if (value == null || value === "") return;
      if (typeof value === "string") { append(value); return; }
      if (Array.isArray(value)) {
        for (var i = 0; i < value.length; i++) append(value[i]);
        return;
      }
      if (value.replace) { clear(); for (i = 0; i < value.replace.length; i++) append(value.replace[i]); }
      if (value.append) { for (i = 0; i < value.append.length; i++) append(value.append[i]); }
    };
  }

  function makeNameplatePainter(widget) {
    var node = widget.querySelector(".w-name");
    widget._stopPainter = function () {};
    return function apply(value) {
      if (node && value != null) node.textContent = String(value);
    };
  }

  // ============================================================
  // State bus — default, world-agnostic poller when the host supplies no
  // stateReader.  The protocol is deliberately small:
  //   GET  /api/state?world_id=<id>
  //   POST /api/world/tick {world_id, session_id, mode:"generic", decision}
  // A specialised world page may provide opts.stateReader instead.
  // ============================================================

  function createStateBus(worldId, onTick) {
    var subscribers = {};      // readTarget -> [apply, widget]
    var intervalId = null;
    var tickInFlight = false;

    function fetchJson(url, opts) {
      return fetch(url, opts || {}).then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      });
    }

    function valueAt(obj, path) {
      if (!obj || !path) return undefined;
      var cur = obj;
      var parts = path.split(".");
      for (var i = 0; i < parts.length; i++) {
        if (cur == null || !Object.prototype.hasOwnProperty.call(cur, parts[i])) {
          return undefined;
        }
        cur = cur[parts[i]];
      }
      return cur;
    }

    function valueForTarget(snapshot, readTarget) {
      var split = readTarget.indexOf(":");
      var scope = readTarget.slice(0, split);
      var path = readTarget.slice(split + 1);
      var base;
      if (scope === "kernel") {
        base = snapshot.kernel_state || snapshot.kernel || snapshot.kernels || {};
      } else {
        base = snapshot.state || snapshot;
      }
      return valueAt(base, path);
    }

    function fetchState() {
      var url = "/api/state";
      if (worldId) url += "?world_id=" + encodeURIComponent(worldId);
      return fetchJson(url).then(function (d) {
        if (!d) return;
        deliverState(d);
      }).catch(function (err) {
        console.warn("dynamic_gui: state poll failed", err);
      });
    }

    function deliverState(d) {
      Object.keys(subscribers).forEach(function (readTarget) {
        var value = valueForTarget(d, readTarget);
        if (value !== undefined) dispatch(readTarget, value);
      });
    }

    function deliverBeat(beat) {
      var mt = beat.model_trace || {};
      var beatNo = mt.world_builder_beat;
      if (mt.kernel_event_log && mt.kernel_event_log.length) {
        var prefix = "[beat " + (beatNo != null ? beatNo : "?") + "] ";
        dispatch("state:event_log", {
          append: mt.kernel_event_log.map(function (line) { return prefix + line; }),
        });
      }
      var updates = beat.world_updates || [];
      var lines = [];
      for (var i = 0; i < updates.length; i++) {
        if (updates[i].title) lines.push("【" + updates[i].title + "】");
        if (updates[i].content) lines.push(updates[i].content);
      }
      if (beat.dialogue) lines.push("「" + beat.dialogue + "」");
      if (lines.length) dispatch("state:narrative", { append: lines });
    }

    function dispatch(readTarget, value) {
      var subs = subscribers[readTarget];
      if (!subs) return;
      for (var i = 0; i < subs.length; i++) {
        try { subs[i].apply(value); } catch (e) { console.warn("painter apply failed", e); }
      }
    }

    function subscribe(readTarget, applyFn, widget) {
      if (!subscribers[readTarget]) subscribers[readTarget] = [];
      subscribers[readTarget].push({ apply: applyFn, widget: widget });
    }

    function start(intervalMs) {
      if (intervalId) return;
      // immediate first poll
      fetchState();
      intervalId = setInterval(fetchState, intervalMs || 1000);
      // Node returns an object timer that otherwise keeps DOM regression
      // processes alive forever. Browsers return a number and ignore this.
      if (intervalId && typeof intervalId.unref === "function") intervalId.unref();
    }

    function stop() {
      if (intervalId) { clearInterval(intervalId); intervalId = null; }
    }

    // COMMIT → POST /api/world/tick → push results → refresh.
    function commit(decision, onDone) {
      if (tickInFlight) return Promise.resolve(false);
      tickInFlight = true;
      var body = {
        world_id: worldId,
        session_id: "world_gui:" + (worldId || "main"),
        mode: "generic",
        decision: decision,
      };
      return fetchJson("/api/world/tick", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      }).then(function (resp) {
        if (!resp || !resp.ok) throw new Error("tick ok=false");
        var beat = resp.beat || {};
        deliverBeat(beat);
        if (typeof onTick === "function") onTick(beat);
        fetchState();
        if (typeof onDone === "function") onDone(beat);
        return true;
      }).catch(function (err) {
        console.warn("dynamic_gui: tick failed", err);
        dispatch("state:event_log", { append: ["[commit error] " + (err && err.message ? err.message : err)] });
        return false;
      }).then(function (ok) { tickInFlight = false; return ok; });
    }

    return {
      subscribe: subscribe,
      start: start,
      stop: stop,
      commit: commit,
      _fetchState: fetchState,
    };
  }

  // ============================================================
  // Emit-side binders (existing behaviour preserved + ctx hookup).
  // ============================================================

  function bindSlider(widget, router, accepted, ctx) {
    var input = widget.querySelector("input[type='range']");
    if (!input) return;
    var val = widget.querySelector(".w-slider-val");
    var name = widget.dataset.widget;
    function syncLabel() { if (val) val.textContent = String(input.value); }
    syncLabel();
    if (ctx && ctx.decisionState) {
      // initialize decision state from the slider default
      ctx.decisionState[name] = Number(input.value);
    }
    input.addEventListener("input", function () {
      syncLabel();
      if (ctx && ctx.decisionState) ctx.decisionState[name] = Number(input.value);
    });
    input.addEventListener("change", function () {
      router.ingest(buildDeviceEvent(widget, {
        axis: Number(input.dataset.axis || 0),
        value: Number(input.value),
        label: readAttr(widget, "label") || name,
      }));
    });
  }

  function bindDial(widget, router, accepted) {
    var knob = widget.querySelector(".w-dial-knob");
    if (!knob) return;
    knob.addEventListener("click", function () {
      router.ingest(buildDeviceEvent(widget, {
        axis: 0, value: Math.random(),
        label: readAttr(widget, "label") || widget.dataset.widget,
      }));
    });
  }

  function bindButtons(widget, router, accepted) {
    var btns = widget.querySelectorAll("button[data-verb]");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", (function (btn) {
        return function () {
          router.ingest(buildDeviceEvent(widget, {
            verb: btn.dataset.verb || accepted.verb || "",
            object_id: widget.dataset.widget,
            actor_strength: 1,
          }));
        };
      })(btns[i]));
    }
  }

  function bindToggle(widget, router, accepted) {
    var toggle = widget.querySelector(".w-toggle");
    if (!toggle) return;
    toggle.addEventListener("click", function () {
      toggle.classList.toggle("on");
      router.ingest(buildDeviceEvent(widget, {
        verb: accepted.verb || widget.dataset.widget,
        object_id: widget.dataset.widget,
        state: toggle.classList.contains("on"),
      }));
    });
  }

  function bindTextField(widget, router, accepted) {
    var input = widget.querySelector("input[type='text']");
    var btn = widget.querySelector(".w-btn");
    if (!input) return;
    function submit() {
      router.ingest(buildDeviceEvent(widget, {
        text: input.value,
        transcript: input.value,
        speaker_hint: "player_01",
      }));
      input.value = "";
    }
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") { e.preventDefault(); submit(); }
    });
    if (btn) btn.addEventListener("click", submit);
  }

  function bindCommitBar(widget, router, accepted, ctx) {
    var btn = widget.querySelector("button.w-btn");
    if (!btn) return;
    btn.addEventListener("click", function () {
      // notify the router (bumps the host's intent counter) — preserves
      // the existing presentational contract.
      router.ingest(buildDeviceEvent(widget, {
        axis: -1, value: 1, committed: true,
        action: accepted.action || "world/tick",
        verb: readAttr(widget, "binds-verb") || "commit",
        handled_by_state_bus: true,
      }));
      if (ctx && ctx.stateBus && ctx.stateBus.commit) {
        var decision = buildDecision(ctx.decisionState);
        var original = btn.textContent;
        btn.disabled = true;
        btn.textContent = "COMMIT…";
        ctx.stateBus.commit(decision, function () {
          btn.disabled = false;
          btn.textContent = original;
        });
      }
    });
  }

  function buildDecision(decisionState) {
    if (!decisionState) return { tech_level: 0 };
    var tech = decisionState["decision_tech"];
    var resources = {};
    var hasRes = false;
    ["decision_shelter", "decision_hoard", "decision_gamble"].forEach(function (k) {
      if (decisionState[k] != null) { resources[k.replace("decision_", "")] = decisionState[k]; hasRes = true; }
    });
    var d = {};
    if (tech != null) d.tech_level = Number(tech);
    if (hasRes) d.resources = resources;
    if (tech == null && !hasRes) d.tech_level = 0;
    return d;
  }

  function bindCardRow(widget, router, accepted) {
    var cards = widget.querySelectorAll("[data-card]");
    for (var i = 0; i < cards.length; i++) {
      cards[i].addEventListener("click", (function (card) {
        return function () {
          router.ingest(buildDeviceEvent(widget, {
            verb: "play_card", object_id: card.dataset.card, card: card.dataset.card,
          }));
        };
      })(cards[i]));
    }
  }

  // ============================================================
  // Public mount
  // ============================================================

  function mount(guiSpec, opts) {
    opts = opts || {};
    if (!guiSpec || !guiSpec.widgets) {
      throw new Error("mount: guiSpec with widgets is required");
    }
    var router = opts.router || { ingest: function () {} };
    var stateReader = opts.stateReader || null;
    var worldId = guiSpec.world_id || (opts.worldId || "");

    // 1) inject CSS into :root scoped style tag
    var layoutType = guiSpec.layout_type || "dashboard";
    if (typeof opts.css === "string" && opts.css.length) {
      var style = document.createElement("style");
      style.setAttribute("data-gui-spec", guiSpec.gui_spec_id || "");
      style.textContent = opts.css;
      document.head.appendChild(style);
    }

    // 2) build root container
    var root = el("section", {
      class: "gui-" + layoutType +
             " chrome-" + (guiSpec.chrome || "instrument_bezel") +
             " motion-" + (guiSpec.motion || "free") +
             " icon-" + (guiSpec.icon_style || "instrument"),
      "data-gui-spec": guiSpec.gui_spec_id || "",
    });

    // If the host gave no stateReader, run the built-in three-body bus.
    var stateBus = null;
    if (!stateReader) {
      stateBus = createStateBus(worldId, opts.onTick);
      stateReader = function (readTarget, applyFn, widget) {
        stateBus.subscribe(readTarget, applyFn, widget);
      };
    }

    var ctx = {
      worldId: worldId,
      router: router,
      decisionState: {},          // slider name -> current value
      stateBus: stateBus,
    };

    var emitHandlers = {
      slider: bindSlider,
      dial: bindDial,
      button: bindButtons,
      button_group: bindButtons,
      card_row: bindCardRow,
      toggle: bindToggle,
      text_field: bindTextField,
      commit_bar: bindCommitBar,
    };

    for (var i = 0; i < guiSpec.widgets.length; i++) {
      var wspec = guiSpec.widgets[i];
      var widget = el("div", {
        class: "w-" + wspec.type + " role-" + (wspec.role || "panel"),
        "data-widget": wspec.name,
        "data-type": wspec.type,
        "data-area": wspec.area,
        "data-role": wspec.role || "panel",
        style: { gridArea: wspec.area },
      });
      if (wspec.binds) {
        if (wspec.binds.emit) widget.setAttribute("data-binds-emit", wspec.binds.emit);
        if (wspec.binds.read) widget.setAttribute("data-binds-read", wspec.binds.read);
        if (wspec.binds.commit) widget.setAttribute("data-binds-commit", "true");
        if (wspec.binds.action) widget.setAttribute("data-binds-action", wspec.binds.action);
        if (wspec.binds.verb) widget.setAttribute("data-binds-verb", wspec.binds.verb);
      }
      if (wspec.label) widget.setAttribute("data-label", wspec.label);
      if (wspec.title) widget.setAttribute("data-title", wspec.title);
      if (wspec.placeholder) widget.setAttribute("data-placeholder", wspec.placeholder);
      if (wspec.min != null) widget.setAttribute("data-min", String(wspec.min));
      if (wspec.max != null) widget.setAttribute("data-max", String(wspec.max));

      // render the skeleton (real controls + canvas) into the widget
      renderInner(widget, wspec);

      var accepted = validateBinds(widget);
      if (!accepted.ok) {
        widget.setAttribute("data-binds-status", "rejected");
        widget.setAttribute("data-binds-reason", accepted.reason);
        widget.classList.add("w-rejected");
        root.appendChild(widget);
        continue;
      }

      if (accepted.kind === "emit") {
        var handler = emitHandlers[wspec.type];
        if (typeof handler === "function") handler(widget, router, accepted, ctx);
        widget.setAttribute("data-binds-status", "emit:" + accepted.emit);
      } else {
        var painter = painterFor(widget, wspec);
        widget.setAttribute("data-binds-status", "read:" + accepted.read);
        try { stateReader(accepted.read, painter, widget); }
        catch (e) { console.warn("stateReader subscribe failed", e); }
      }
      root.appendChild(widget);
    }
    (opts.mountPoint || document.body).appendChild(root);

    // Start the state bus poller (1s default). Expose stop() on the root
    // so the host can tear it down when unmounting the GUI.
    if (stateBus) {
      stateBus.start(opts.pollIntervalMs || 1000);
      root.stop = function () { stateBus.stop(); };
    } else {
      root.stop = function () {};
    }
    root._stateBus = stateBus;
    return root;
  }

  function applySpecToContainer(container, guiSpec, opts) {
    opts = opts || {};
    opts.mountPoint = container;
    return mount(guiSpec, opts);
  }

  var api = {
    mount: mount,
    applySpecToContainer: applySpecToContainer,
    validateBinds: validateBinds,
    ALLOWED_INTENT_KINDS: ALLOWED_INTENT_KINDS,
    ALLOWED_ACTIONS: ALLOWED_ACTIONS,
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
  root.DynamicGUI = api;
})(typeof window !== "undefined" ? window : this);
