/* ============================================================
 * web/gui/theme.js — GuiTheme 载入 + CSS 变量落地
 *
 * GUI chrome 从一套中性默认主题确定性派生并编译成 CSS 自定义属性。
 * 世界可以提供调色板覆盖，但世界名和内核名不参与主题分支。
 *
 * 纯前端、零依赖、零推理（T0 换 ramp = 换配色）。
 * 也可在 Node 下 require（供测试/后端对拍）：既挂 window.GuiTheme，
 * 也在 module.exports 暴露同一批函数。
 * ============================================================ */
(function (root) {
  "use strict";

  // --- 语义槽默认索引（roles）。ramp 索引，非颜色本身。 ------------
  // 与 §3.2 的 roles 对齐：GUI 只用语义名，不直接引 ramp 颜色。
  var DEFAULT_ROLES = {
    bg: 0,
    panel: 1,
    ink: 14,
    accent: 9,
    ok: 6,
    warn: 11,
    danger: 4,
  };

  // --- 单一中性默认主题。世界/内核不得注册特殊预设。 ----------------
  var DEFAULT_THEME = {
    world_id: "default",
    derived_from_style_lock: "default",
    palette_ramp: [
      "#111318", "#191d24", "#232936", "#2d3543",
      "#c4515c", "#4a5568", "#4fa878", "#667085",
      "#d0a85c", "#58a6a6", "#98a2b3", "#c7925b",
      "#7c8aa5", "#74b89a", "#d0d5dd", "#f2f4f7",
    ],
    roles: {
      bg: 0, panel: 1, ink: 14, accent: 9,
      ok: 6, warn: 8, danger: 4,
    },
    layout: "dashboard",
    typography: { display: "Noto Serif SC", mono: "IBM Plex Mono" },
    light_dir_deg: 45,
    density: "vector",
    motion: "free",
  };

  var PRESETS = {
    default: DEFAULT_THEME,
  };

  // --- 工具：深拷贝一个 plain 主题对象（避免调用方改到预设）。 ------
  function clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  // Compatibility helper: every kernel receives the same neutral layout.
  function layoutForKernels() {
    return "dashboard";
  }

  function defaultTheme() {
    return clone(DEFAULT_THEME);
  }

  // --- 从世界 style lock 确定性派生 GuiTheme（§3.1）。 --------------
  // styleLock: {
  //   style_lock_id, palette_ramp:[...], light_dir_deg, density
  // }
  // 派生纯函数、无随机：同输入 → 同输出。世界名和 enabled_kernels
  // 被有意忽略，避免通用 GUI 对具体世界做特殊优化。
  function deriveTheme(styleLock) {
    styleLock = styleLock || {};
    var base = clone(DEFAULT_THEME);

    var ramp = styleLock.palette_ramp;
    if (Array.isArray(ramp) && ramp.length >= 2) {
      base.palette_ramp = ramp.slice();
      // roles 索引可能越界（ramp 变短）——夹到合法范围，保持确定性。
      base.roles = clampRoles(base.roles, ramp.length);
    }
    if (typeof styleLock.light_dir_deg === "number") {
      base.light_dir_deg = styleLock.light_dir_deg;
    }
    if (styleLock.density === "vector") {
      base.density = styleLock.density;
    }
    if (styleLock.world_id) base.world_id = styleLock.world_id;
    if (styleLock.style_lock_id) {
      base.derived_from_style_lock = styleLock.style_lock_id;
    }
    return base;
  }

  function clampRoles(roles, rampLen) {
    var out = {};
    var max = rampLen - 1;
    for (var k in roles) {
      if (Object.prototype.hasOwnProperty.call(roles, k)) {
        var v = roles[k];
        out[k] = v > max ? max : (v < 0 ? 0 : v);
      }
    }
    return out;
  }

  // --- 把 GuiTheme 编译成 CSS 自定义属性并落到 :root。 --------------
  // roles → --bg/--panel/--ink/--accent/--ok/--warn/--danger/...（语义名）
  // 另外落 --gui-light-dir / --gui-density / --gui-font-display / -mono
  // 以及原始 ramp 索引 --ramp-0..N（调试/直接取色用）。
  // 返回落下去的 {属性名: 值} map（供测试断言）。
  function applyTheme(theme, target) {
    if (!theme) throw new Error("applyTheme: theme is required");
    var el =
      target ||
      (typeof document !== "undefined" ? document.documentElement : null);
    var ramp = theme.palette_ramp || [];
    var roles = theme.roles || {};
    var applied = {};

    function set(prop, value) {
      applied[prop] = value;
      if (el && el.style && typeof el.style.setProperty === "function") {
        el.style.setProperty(prop, value);
      }
    }

    // 语义槽 → 颜色（roles 索引进 ramp）。
    for (var role in roles) {
      if (Object.prototype.hasOwnProperty.call(roles, role)) {
        var idx = roles[role];
        var color = ramp[idx];
        if (color != null) set("--" + role.replace(/_/g, "-"), color);
      }
    }

    // 原始 ramp 索引，便于面板直接引某一档色。
    for (var i = 0; i < ramp.length; i++) {
      set("--ramp-" + i, ramp[i]);
    }

    // 布局/风格元信息。
    if (typeof theme.light_dir_deg === "number") {
      set("--gui-light-dir", theme.light_dir_deg + "deg");
    }
    if (theme.density) {
      set("--gui-density", theme.density);
    }
    if (theme.motion) set("--gui-motion", theme.motion);
    if (theme.typography) {
      if (theme.typography.display) {
        set("--gui-font-display", theme.typography.display);
      }
      if (theme.typography.mono) set("--gui-font-mono", theme.typography.mono);
    }
    if (theme.layout) set("--gui-layout", theme.layout);

    return applied;
  }

  var api = {
    applyTheme: applyTheme,
    deriveTheme: deriveTheme,
    defaultTheme: defaultTheme,
    layoutForKernels: layoutForKernels,
    presets: PRESETS,
    DEFAULT_ROLES: DEFAULT_ROLES,
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
  root.GuiTheme = api;
})(typeof window !== "undefined" ? window : this);
