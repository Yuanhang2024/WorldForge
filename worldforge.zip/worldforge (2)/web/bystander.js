/* ============================================================
 * web/bystander.js — "全程旁观" posture (spec §10.2/§10.3/§13.4).
 *
 * The third posture alongside creator (造物主) and guest (客人): the
 * bystander (旁观者) does not possess or operate — the world lives on its
 * own and they watch, with cheap affordances to skip ahead (§10.2 代价约束)
 * and a director-view overlay (§10.3 读内核状态 = 零成本).
 *
 * Responsibilities:
 *   1. posture toggle: add/remove `body.bystander` — hides player-input
 *      widgets (sliders/commit_bar/etc.) via CSS, leaving only the read-only
 *      dashboard + event/narrative feeds.
 *   2. fast-forward: POST /api/world/fast_forward → loop generic world ticks
 *      with a "快进中…" progress readout.
 *   3. timeline panorama: poll /api/state and render a compact sparkline of
 *      worldbook activity.
 *   4. offline summary: GET /api/world/offline_summary → "你离开时发生了……".
 *
 * Vanilla: no framework, plain DOM, fetch. Exposed as window.Bystander.
 * ============================================================ */

(function (root) {
  "use strict";

  var SPARK_GLYPHS = ["▁", "▂", "▃", "▄", "▅", "▆", "▇", "█"];

  function sparkline(values) {
    if (!values || !values.length) return "▁";
    var mn = Math.min.apply(null, values);
    var mx = Math.max.apply(null, values);
    if (mx === mn) mx = mn + 1;
    var out = "";
    for (var i = 0; i < values.length; i++) {
      var idx = Math.round(((values[i] - mn) / (mx - mn)) * (SPARK_GLYPHS.length - 1));
      out += SPARK_GLYPHS[Math.max(0, Math.min(SPARK_GLYPHS.length - 1, idx))];
    }
    return out;
  }

  function init() {
    var toggleBtn = document.getElementById("posture-toggle");
    var ffBtn = document.getElementById("ff-run");
    var recapBtn = document.getElementById("recap-fetch");
    var progressEl = document.getElementById("bystander-progress");
    var panoramaEl = document.getElementById("bystander-panorama");
    var recapEl = document.getElementById("bystander-recap");
    if (!toggleBtn) return;

    // 1) posture toggle
    function setPosture(on) {
      document.body.classList.toggle("bystander", on);
      toggleBtn.textContent = on ? "旁观模式：开" : "旁观模式：关";
      toggleBtn.classList.toggle("active", on);
    }
    toggleBtn.addEventListener("click", function () {
      setPosture(!document.body.classList.contains("bystander"));
    });

    // 2) fast-forward
    function setProgress(text) {
      if (progressEl) progressEl.textContent = text || "";
    }
    function activeWorldId() {
      if (root.__worldId) return root.__worldId;
      return "main";
    }
    if (ffBtn) {
      ffBtn.addEventListener("click", function () {
        var beats = parseInt(document.getElementById("ff-beats").value || "5", 10);
        var worldId = activeWorldId();
        ffBtn.disabled = true;
        setProgress("快进中… 0/" + beats);
        fetch("/api/world/fast_forward", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ beats: beats, mode: "generic", world_id: worldId }),
        }).then(function (r) { return r.json(); }).then(function (body) {
          if (!body || !body.ok) throw new Error(body && body.error ? body.error : "fast_forward failed");
          setProgress("快进完成 " + body.beats_run + "/" + beats + " 拍");
          refreshPanorama();
        }).catch(function (err) {
          setProgress("快进失败: " + (err && err.message ? err.message : err));
        }).then(function () { ffBtn.disabled = false; });
      });
    }

    // 3) timeline panorama — render a sparkline of the whole history.
    function refreshPanorama() {
      var worldId = activeWorldId();
      fetch("/api/state?world_id=" + encodeURIComponent(worldId))
        .then(function (r) { return r.json(); }).then(function (s) {
        if (!s) return;
        var wb = s.worldbook || [];
        if (panoramaEl) {
          var heights = wb.map(function (e, i) {
            return (e.content || "").length + i * 0.1;
          });
          panoramaEl.textContent = "史册 " + sparkline(heights) + " · " + wb.length + " 条";
        }
      }).catch(function () {});
    }

    // 4) offline summary
    if (recapBtn) {
      recapBtn.addEventListener("click", function () {
        recapBtn.disabled = true;
        if (recapEl) recapEl.textContent = "正在生成回归摘要…";
        var worldId = activeWorldId();
        fetch("/api/world/offline_summary?world_id=" + encodeURIComponent(worldId) + "&max_entries=5")
          .then(function (r) { return r.json(); })
          .then(function (body) {
            if (!body || !body.ok) throw new Error(body && body.error ? body.error : "summary failed");
            var text = body.summary && body.summary.trim();
            if (!text && body.recent_entries && body.recent_entries.length) {
              text = "你离开时发生了：\n" + body.recent_entries.map(function (e) {
                return "· " + (e.title || "") + " — " + (e.content || "").slice(0, 80);
              }).join("\n");
            }
            if (recapEl) recapEl.textContent = text || "(世界静止，没有新进展)";
          })
          .catch(function (err) {
            if (recapEl) recapEl.textContent = "摘要失败: " + (err && err.message ? err.message : err);
          })
          .then(function () { recapBtn.disabled = false; });
      });
    }

    // Refresh the panorama shortly after load + periodically.
    setTimeout(refreshPanorama, 600);
    setInterval(refreshPanorama, 4000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  root.Bystander = { sparkline: sparkline, init: init };
})(typeof window !== "undefined" ? window : this);
