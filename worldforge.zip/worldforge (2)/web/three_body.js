/* ============================================================
 * Three-Body World Dashboard — render layer
 * Pure vanilla JS / Canvas 2D. No frameworks, no LLM, no
 * generated visuals — direct read of the baked kernel output
 * (architecture spec §8.2 + §11.5).
 *
 * Entry point: ThreeBody.boot({backend, defaults}) where
 *   backend  : base URL of the mother-project server (default
 *              http://localhost:8787)
 *   defaults : {seed, years, dt, frames}
 * Wires up the controls, fetches /api/three_body/bake, and
 * draws the 5 panels.
 * ============================================================ */
(function (global) {
  'use strict';

  const BACKEND_DEFAULT = 'http://localhost:8787';
  const WORLD_IDS = { HOME: 'three_body' };

  // ------------------------------------------------------------
  // DPR-aware canvas helpers
  // ------------------------------------------------------------
  function fitCanvas(canvas) {
    const dpr = global.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
      canvas.width = 0;
      canvas.height = 0;
      return { w: 0, h: 0, dpr };
    }
    canvas.width = Math.max(1, Math.round(rect.width * dpr));
    canvas.height = Math.max(1, Math.round(rect.height * dpr));
    return { w: canvas.width, h: canvas.height, dpr };
  }

  function clear(ctx, w, h) {
    ctx.fillStyle = '#05071a';
    ctx.fillRect(0, 0, w, h);
  }

  // ------------------------------------------------------------
  // Network
  // ------------------------------------------------------------
  async function fetchBake(backend, params) {
    const url = backend.replace(/\/+$/, '') + '/api/three_body/bake'
      + '?seed=' + encodeURIComponent(params.seed)
      + '&years=' + encodeURIComponent(params.years)
      + '&dt='   + encodeURIComponent(params.dt)
      + '&frames=' + encodeURIComponent(params.frames);
    const resp = await fetch(url, { method: 'GET' });
    if (!resp.ok) {
      const text = await resp.text();
      throw new Error('HTTP ' + resp.status + ': ' + text.slice(0, 200));
    }
    return await resp.json();
  }

  // Read current kernel-tracked civ state (spec §8.4 — kernel is truth
  // source). Returns null on any failure so callers can degrade gracefully.
  async function fetchThreeBodyState(backend) {
    const url = backend.replace(/\/+$/, '') + '/api/three_body/state';
    try {
      const resp = await fetch(url, { method: 'GET' });
      if (!resp.ok) return null;
      const data = await resp.json();
      return data && data.ok ? data : null;
    } catch (e) {
      return null;
    }
  }

  // COMMIT a DecisionVector into the kernel (spec §8.4). Returns the
  // dispatched beat dict or throws. The kernel computes survival/
  // destruction; LLM only narrates the event_log.
  async function commitTick(backend, sessionId, decisionVector, worldId) {
    const url = backend.replace(/\/+$/, '') + '/api/world/tick';
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: sessionId,
        mode: 'three_body',
        decision: decisionVector,
        world_id: worldId || WORLD_IDS.HOME,
      }),
    });
    const text = await resp.text();
    let body = null;
    try { body = JSON.parse(text); } catch (e) { body = { ok: false, error: text.slice(0, 200) }; }
    if (!resp.ok || !body || body.ok === false) {
      const msg = (body && (body.error || body.message)) || ('HTTP ' + resp.status);
      throw new Error(msg);
    }
    return body.beat || body;
  }

  // Seed a new world via the dispatcher (used by "create new world" +
  // world-switching buttons). The dispatch endpoint is content-agnostic —
  // the producer LLM interprets the message and writes a worldbook entry
  // under the given world_id (mother-project §8 dispatch).
  async function dispatchSeed(backend, message, worldId, sessionId) {
    const url = backend.replace(/\/+$/, '') + '/api/dispatch';
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: message,
        world_id: worldId,
        session_id: sessionId || ('spawn_' + worldId),
      }),
    });
    const text = await resp.text();
    let body = null;
    try { body = JSON.parse(text); } catch (e) { body = { ok: false, error: text.slice(0, 200) }; }
    if (!resp.ok || (body && body.error)) {
      throw new Error((body && body.error) || ('HTTP ' + resp.status));
    }
    return body;
  }

  // ------------------------------------------------------------
  // Panel 1 — orbit timeline (canvas 2D)
  // ------------------------------------------------------------
  function drawOrbit(canvas, payload, frameIdx) {
    const { w, h } = fitCanvas(canvas);
    if (w === 0) return;
    const ctx = canvas.getContext('2d');
    clear(ctx, w, h);

    const stars = payload.stars;          // [F][3][2]
    const planet = payload.planet;        // [F][2]
    const eras = payload.eras;
    const t = payload.t;
    const F = stars.length;
    const colors = ['#ffd27a', '#ff9a6b', '#b07aff'];
    const planetColor = '#6bffb6';

    // Compute bounding box over all samples (with margin)
    let xmin = Infinity, xmax = -Infinity, ymin = Infinity, ymax = -Infinity;
    for (let i = 0; i < F; i++) {
      for (let s = 0; s < 3; s++) {
        if (stars[i][s][0] < xmin) xmin = stars[i][s][0];
        if (stars[i][s][0] > xmax) xmax = stars[i][s][0];
        if (stars[i][s][1] < ymin) ymin = stars[i][s][1];
        if (stars[i][s][1] > ymax) ymax = stars[i][s][1];
      }
      if (planet[i][0] < xmin) xmin = planet[i][0];
      if (planet[i][0] > xmax) xmax = planet[i][0];
      if (planet[i][1] < ymin) ymin = planet[i][1];
      if (planet[i][1] > ymax) ymax = planet[i][1];
    }
    const xrange = xmax - xmin || 1;
    const yrange = ymax - ymin || 1;
    const scale = Math.min(w / xrange, h / yrange) * 0.82;
    const cx = (xmin + xmax) / 2;
    const cy = (ymin + ymax) / 2;
    const toX = x => (x - cx) * scale + w / 2;
    const toY = y => (y - cy) * scale + h / 2;

    // Background era tint (full-width bands along the time axis)
    const tmin = t[0];
    const tmax = t[t.length - 1];
    for (const era of eras) {
      const fx = (era.start - tmin) / (tmax - tmin);
      const fe = (era.end - tmin) / (tmax - tmin);
      const px = fx * w;
      const pw = (fe - fx) * w;
      ctx.fillStyle = era.kind === 'stable'
        ? 'rgba(255, 207, 107, 0.06)'
        : 'rgba(107, 229, 255, 0.08)';
      ctx.fillRect(px, 0, Math.max(1, pw), h);
    }

    // Origin cross
    ctx.strokeStyle = '#1d2349';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, h / 2); ctx.lineTo(w, h / 2);
    ctx.moveTo(w / 2, 0); ctx.lineTo(w / 2, h);
    ctx.stroke();

    // Trajectory traces up to current frame
    ctx.lineWidth = 1.4;
    for (let s = 0; s < 3; s++) {
      ctx.strokeStyle = colors[s];
      ctx.globalAlpha = 0.35;
      ctx.beginPath();
      for (let i = 0; i <= frameIdx && i < F; i++) {
        const x = toX(stars[i][s][0]);
        const y = toY(stars[i][s][1]);
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    // Planet trace
    ctx.strokeStyle = planetColor;
    ctx.globalAlpha = 0.5;
    ctx.beginPath();
    for (let i = 0; i <= frameIdx && i < F; i++) {
      const x = toX(planet[i][0]);
      const y = toY(planet[i][1]);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.globalAlpha = 1.0;

    // Current positions (larger glowing circles)
    const idx = Math.min(frameIdx, F - 1);
    for (let s = 0; s < 3; s++) {
      const x = toX(stars[idx][s][0]);
      const y = toY(stars[idx][s][1]);
      // Outer glow
      const grd = ctx.createRadialGradient(x, y, 0, x, y, 22);
      grd.addColorStop(0, colors[s]);
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grd;
      ctx.beginPath(); ctx.arc(x, y, 22, 0, Math.PI * 2); ctx.fill();
      // Core
      ctx.fillStyle = colors[s];
      ctx.beginPath(); ctx.arc(x, y, 6, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(x, y, 2, 0, Math.PI * 2); ctx.fill();
    }
    // Planet current
    {
      const x = toX(planet[idx][0]);
      const y = toY(planet[idx][1]);
      const grd = ctx.createRadialGradient(x, y, 0, x, y, 14);
      grd.addColorStop(0, planetColor);
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grd;
      ctx.beginPath(); ctx.arc(x, y, 14, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = planetColor;
      ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI * 2); ctx.fill();
    }

    // Frame label
    ctx.fillStyle = '#8a8fb3';
    ctx.font = '11px ui-monospace, "JetBrains Mono", monospace';
    ctx.fillText(`t=${t[idx].toFixed(2)}  frame ${idx}/${F-1}`, 10, h - 10);
  }

  // ------------------------------------------------------------
  // Panel 2 — illumination + temperature (with era background bands)
  // ------------------------------------------------------------
  function drawIllumination(canvas, payload) {
    const { w, h } = fitCanvas(canvas);
    if (w === 0) return;
    const ctx = canvas.getContext('2d');
    clear(ctx, w, h);

    const t = payload.t;
    const illum = payload.illumination;
    const temp = payload.temperature;
    const eras = payload.eras;
    const F = t.length;

    const padding = { l: 38, r: 12, t: 10, b: 22 };
    const pw = w - padding.l - padding.r;
    const ph = h - padding.t - padding.b;

    // Era background bands (full height)
    const tmin = t[0], tmax = t[F - 1];
    for (const era of eras) {
      const fx = padding.l + (era.start - tmin) / (tmax - tmin) * pw;
      const fe = padding.l + (era.end - tmin) / (tmax - tmin) * pw;
      ctx.fillStyle = era.kind === 'stable'
        ? 'rgba(255, 207, 107, 0.10)'
        : 'rgba(107, 229, 255, 0.12)';
      ctx.fillRect(fx, padding.t, Math.max(1, fe - fx), ph);
    }

    // Axes grid
    ctx.strokeStyle = '#1d2349';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padding.t + (ph * i / 4);
      ctx.beginPath(); ctx.moveTo(padding.l, y); ctx.lineTo(padding.l + pw, y); ctx.stroke();
    }

    // Illumination (top half), temperature (bottom half)
    const illMin = Math.min.apply(null, illum);
    const illMax = Math.max.apply(null, illum);
    const tempMin = Math.min.apply(null, temp);
    const tempMax = Math.max.apply(null, temp);
    const illRange = (illMax - illMin) || 1;
    const tempRange = (tempMax - tempMin) || 1;

    function plotSeries(arr, amin, arange, color, yOffset, heightFrac) {
      const sub = padding.t + yOffset;
      const sh = ph * heightFrac;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      for (let i = 0; i < F; i++) {
        const x = padding.l + (i / (F - 1)) * pw;
        const y = sub + sh - ((arr[i] - amin) / arange) * sh;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
      // Label at top-left
      ctx.fillStyle = color;
      ctx.font = '10px ui-monospace, monospace';
      ctx.fillText(arr === illum ? '光' : '温', padding.l + 6, sub + 12);
    }

    plotSeries(illum, illMin, illRange, '#ffcf6b', 0,         0.5);
    plotSeries(temp,  tempMin, tempRange, '#6be5ff', ph * 0.5, 0.5);

    // Mid divider
    ctx.strokeStyle = '#2c3568';
    ctx.setLineDash([2, 3]);
    ctx.beginPath();
    ctx.moveTo(padding.l, padding.t + ph * 0.5);
    ctx.lineTo(padding.l + pw, padding.t + ph * 0.5);
    ctx.stroke();
    ctx.setLineDash([]);

    // X-axis tick labels (start/mid/end)
    ctx.fillStyle = '#4a4f76';
    ctx.font = '10px ui-monospace, monospace';
    ctx.fillText(`t=${tmin.toFixed(0)}`, padding.l, h - 6);
    ctx.fillText(`t=${((tmin + tmax) / 2).toFixed(0)}`,
                 padding.l + pw / 2 - 18, h - 6);
    ctx.fillText(`t=${tmax.toFixed(0)}`, padding.l + pw - 32, h - 6);
  }

  // ------------------------------------------------------------
  // Panel 3 — civilization count curve
  // ------------------------------------------------------------
  function drawCivilization(canvas, payload) {
    const { w, h } = fitCanvas(canvas);
    if (w === 0) return;
    const ctx = canvas.getContext('2d');
    clear(ctx, w, h);

    const curve = payload.civilization_curve;
    const N = curve.length;
    const padding = { l: 44, r: 16, t: 14, b: 26 };
    const pw = w - padding.l - padding.r;
    const ph = h - padding.t - padding.b;

    // Y axis: stack destroyed (-1) / survived (+1) into two bands
    const bandH = ph / 2;

    // Axis lines
    ctx.strokeStyle = '#1d2349';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padding.l, padding.t + bandH);
    ctx.lineTo(padding.l + pw, padding.t + bandH);
    ctx.stroke();

    // Bars
    const barW = pw / N * 0.7;
    for (let i = 0; i < N; i++) {
      const ev = curve[i];
      const x = padding.l + (i + 0.5) * (pw / N) - barW / 2;
      const isSurv = ev.kind === 'survived';
      // top half = survived, bottom = destroyed
      const yTop = isSurv ? padding.t : padding.t + bandH;
      const yBot = isSurv ? padding.t + bandH : padding.t + ph;
      ctx.fillStyle = isSurv ? 'rgba(107, 255, 158, 0.85)' : 'rgba(255, 90, 122, 0.85)';
      ctx.fillRect(x, yTop, barW, yBot - yTop);
      // Tech label below the bar
      ctx.fillStyle = '#8a8fb3';
      ctx.font = '9px ui-monospace, monospace';
      ctx.fillText(curve[i].tech.toFixed(1), x, padding.t + ph + 12);
    }

    // Y labels
    ctx.fillStyle = '#6bff9e';
    ctx.font = '10px ui-monospace, monospace';
    ctx.fillText('S 幸存', padding.l - 38, padding.t + 12);
    ctx.fillStyle = '#ff5a7a';
    ctx.fillText('D 毁灭', padding.l - 38, padding.t + bandH + 14);

    // Pivot line — first survived
    let pivot = -1;
    for (let i = 0; i < N; i++) {
      if (curve[i].kind === 'survived') { pivot = i; break; }
    }
    if (pivot >= 0) {
      const x = padding.l + (pivot + 0.5) * (pw / N);
      ctx.strokeStyle = 'rgba(255, 207, 107, 0.6)';
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(x, padding.t);
      ctx.lineTo(x, padding.t + ph);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#ffcf6b';
      ctx.fillText('转折', x - 8, padding.t - 2);
    }

    // X axis label
    ctx.fillStyle = '#4a4f76';
    ctx.font = '10px ui-monospace, monospace';
    ctx.fillText('科技水平 tech level', padding.l + pw / 2 - 30, h - 4);
  }

  // ------------------------------------------------------------
  // Panel 4 — lambda + T_predict (delta_0 → horizon)
  // ------------------------------------------------------------
  function drawLambda(canvas, payload) {
    const { w, h } = fitCanvas(canvas);
    if (w === 0) return;
    const ctx = canvas.getContext('2d');
    clear(ctx, w, h);

    const curve = payload.civilization_curve;
    const N = curve.length;
    const evac = payload.evacuation;
    const padding = { l: 50, r: 16, t: 14, b: 28 };
    const pw = w - padding.l - padding.r;
    const ph = h - padding.t - padding.b;

    // Y axis = T_predict (log scale friendly, but most are linear)
    let tpMin = Infinity, tpMax = -Infinity;
    for (const ev of curve) {
      if (ev.T_predict < tpMin) tpMin = ev.T_predict;
      if (ev.T_predict > tpMax) tpMax = ev.T_predict;
    }
    const tpRange = (tpMax - tpMin) || 1;

    // Grid
    ctx.strokeStyle = '#1d2349';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padding.t + (ph * i / 4);
      ctx.beginPath();
      ctx.moveTo(padding.l, y);
      ctx.lineTo(padding.l + pw, y);
      ctx.stroke();
      const v = tpMax - (tpMax - tpMin) * i / 4;
      ctx.fillStyle = '#4a4f76';
      ctx.font = '9px ui-monospace, monospace';
      ctx.fillText(v.toFixed(1), 4, y + 3);
    }

    // Mean chaos gap reference line
    if (evac.mean_chaos_gap != null) {
      const yGap = padding.t + ph - ((evac.mean_chaos_gap - tpMin) / tpRange) * ph;
      ctx.strokeStyle = 'rgba(255, 90, 122, 0.65)';
      ctx.setLineDash([4, 3]);
      ctx.beginPath();
      ctx.moveTo(padding.l, yGap);
      ctx.lineTo(padding.l + pw, yGap);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#ff5a7a';
      ctx.font = '10px ui-monospace, monospace';
      ctx.fillText(`mean chaos gap = ${evac.mean_chaos_gap.toFixed(2)}`,
                   padding.l + 6, yGap - 4);
    }

    // T_predict curve
    ctx.strokeStyle = '#ffcf6b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < N; i++) {
      const x = padding.l + (i / (N - 1)) * pw;
      const y = padding.t + ph - ((curve[i].T_predict - tpMin) / tpRange) * ph;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Data points (color = kind)
    for (let i = 0; i < N; i++) {
      const x = padding.l + (i / (N - 1)) * pw;
      const y = padding.t + ph - ((curve[i].T_predict - tpMin) / tpRange) * ph;
      ctx.fillStyle = curve[i].kind === 'survived' ? '#6bff9e' : '#ff5a7a';
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    // X labels
    for (let i = 0; i < N; i += 2) {
      const x = padding.l + (i / (N - 1)) * pw;
      ctx.fillStyle = '#8a8fb3';
      ctx.font = '9px ui-monospace, monospace';
      ctx.fillText(curve[i].tech.toFixed(1), x - 6, padding.t + ph + 12);
    }
    ctx.fillStyle = '#4a4f76';
    ctx.font = '10px ui-monospace, monospace';
    ctx.fillText('tech level', padding.l + pw / 2 - 20, h - 6);
  }

  // ------------------------------------------------------------
  // Redraw all panels
  // ------------------------------------------------------------
  function redraw(state) {
    if (!state.payload) return;
    drawOrbit(state.cv.orbit, state.payload, state.orbitFrame);
    drawIllumination(state.cv.light, state.payload);
    drawCivilization(state.cv.civ, state.payload);
    drawLambda(state.cv.lambda, state.payload);
  }

  // ------------------------------------------------------------
  // Update stat tiles + evacuation verdict
  // ------------------------------------------------------------
  function updateStats(payload) {
    const illum = payload.illumination;
    document.getElementById('s-light-max').textContent = Math.max.apply(null, illum).toFixed(3);
    document.getElementById('s-light-min').textContent = Math.min.apply(null, illum).toFixed(3);
    const nStable  = payload.eras.filter(e => e.kind === 'stable').length;
    const nChaotic = payload.eras.filter(e => e.kind === 'chaotic').length;
    document.getElementById('s-stable').textContent  = nStable;
    document.getElementById('s-chaotic').textContent = nChaotic;

    const curve = payload.civilization_curve;
    const survived  = curve.filter(e => e.kind === 'survived').length;
    const destroyed = curve.filter(e => e.kind === 'destroyed').length;
    document.getElementById('s-survived').textContent  = survived;
    document.getElementById('s-destroyed').textContent = destroyed;
    const pivot = curve.find(e => e.kind === 'survived');
    document.getElementById('s-pivot').textContent = pivot ? pivot.tech.toFixed(1) : '—';
    const last = curve[curve.length - 1];
    document.getElementById('s-tpred-max').textContent = last ? last.T_predict.toFixed(2) : '—';

    document.getElementById('s-lambda').textContent = payload.kernel.lambda_max.toFixed(6);
    document.getElementById('s-energy').textContent = payload.kernel.energy_drift.toExponential(2);
    const evac = payload.evacuation;
    document.getElementById('s-gap').textContent =
      evac.mean_chaos_gap != null ? evac.mean_chaos_gap.toFixed(2) : '—';
    document.getElementById('s-covers').textContent =
      evac.covers_gap === null ? '—'
      : evac.covers_gap ? '覆盖' : '不覆盖';

    // Evacuation verdict
    const lamp = document.getElementById('evac-lamp');
    const head = document.getElementById('evac-headline');
    const det  = document.getElementById('evac-detail');
    lamp.classList.remove('ok', 'no', 'gray');
    head.classList.remove('ok', 'no', 'gray');
    if (evac.proved) {
      lamp.classList.add('ok');
      head.classList.add('ok');
      head.textContent = '证明必逃离 · EVACUATION PROVED';
      det.textContent = `max-tech 视界 T_pred=${evac.T_pred_best.toFixed(2)} < 乱纪元平均间隔 ${evac.mean_chaos_gap.toFixed(2)} — 长期幸存在数学上不可能`;
    } else if (evac.mean_chaos_gap == null) {
      lamp.classList.add('gray');
      head.classList.add('gray');
      head.textContent = '未证明 · INSUFFICIENT DATA';
      det.textContent = '烘焙窗口内乱纪元不足 2 个 — 短时间线无法判定统计间隔，需要更长的 years';
    } else {
      lamp.classList.add('no');
      head.classList.add('no');
      head.textContent = '未证明逃离 · EVACUATION NOT YET PROVED';
      det.textContent =
        `max-tech 视界 T_pred=${evac.T_pred_best.toFixed(2)} ≥ 乱纪元平均间隔 ${evac.mean_chaos_gap.toFixed(2)} — ` +
        '在当前 max_tech 下还能幸存（虽然代价比视界=0 时更大）';
    }

    // Header meta
    document.getElementById('meta-seed').textContent  = payload.params.seed;
    document.getElementById('meta-years').textContent = payload.params.years.toFixed(0);
    document.getElementById('meta-lam').textContent   = payload.kernel.lambda_max.toFixed(6);
  }

  // ------------------------------------------------------------
  // Orbit timeline loop (independent RAF)
  // ------------------------------------------------------------
  function startOrbitLoop(state) {
    stopOrbitLoop(state);
    state.playing = true;
    document.getElementById('orbit-play').textContent = '⏸ 暂停';
    const F = state.payload.stars.length;
    const durationMs = Math.max(2000, Math.min(20000, F * 25)); // 25ms/frame, clamp
    const stepDelay = durationMs / F;
    let last = performance.now();
    state._raf = function tick(now) {
      if (!state.playing) return;
      if (now - last >= stepDelay) {
        last = now;
        state.orbitFrame = (state.orbitFrame + 1) % F;
        document.getElementById('orbit-scrub').value = state.orbitFrame;
        document.getElementById('orbit-time').textContent =
          `t=${state.payload.t[state.orbitFrame].toFixed(2)}`;
        drawOrbit(state.cv.orbit, state.payload, state.orbitFrame);
      }
      state._rafId = requestAnimationFrame(tick);
    };
    state._rafId = requestAnimationFrame(state._raf);
  }
  function stopOrbitLoop(state) {
    state.playing = false;
    if (state._rafId) cancelAnimationFrame(state._rafId);
    state._rafId = null;
    document.getElementById('orbit-play').textContent = '▶ 播放';
  }

  // ------------------------------------------------------------
  // Decision vector — live horizon prediction (spec §8.2 + §8.4)
  //
  // T_predict = (1/λ) · ln(Δ/δ₀)
  // δ₀ = 0.5 · exp(-1.5 · tech)
  // Δ = 0.1
  //
  // All arithmetic is microsec — pure client-side, no backend round
  // trip. The kernel's λ is read from bake.payload; the resource
  // sliders collapse into tech via _resolve_three_body_decision
  // (tech = sum of resources, max_tech cap = 8).
  // ------------------------------------------------------------
  function predictHorizon(lambda, betTech) {
    if (!lambda || lambda <= 0) return null;
    const tech = Math.max(0, Math.min(8, betTech));
    const delta0 = 0.5 * Math.exp(-1.5 * tech);
    const Delta = 0.1;
    if (delta0 <= 0) return null;
    const tp = Math.log(Delta / delta0) / lambda;
    return { delta0, T_predict: tp };
  }

  // Find the smallest next chaotic era start time ahead of cursor.
  // Returns null if no chaotic eras are visible from cursor in payload.
  function nextChaosFrom(eras, cursor) {
    if (!Array.isArray(eras)) return null;
    let best = null;
    for (const e of eras) {
      if (e.kind === 'chaotic' && e.start >= cursor) {
        if (best === null || e.start < best) best = e.start;
      }
    }
    return best;
  }

  function renderPrediction(state) {
    const out = {
      delta0:    document.getElementById('pred-delta'),
      horizon:   document.getElementById('pred-horizon'),
      nextChaos: document.getElementById('pred-next-chaos'),
      verdict:   document.getElementById('pred-verdict'),
    };
    if (!state.payload) {
      out.delta0.textContent = '—';
      out.horizon.textContent = '—';
      out.nextChaos.textContent = '—';
      out.verdict.textContent = '—';
      out.verdict.classList.remove('ok', 'bad', 'gray');
      out.verdict.classList.add('gray');
      return;
    }
    const lambda = state.payload.kernel ? state.payload.kernel.lambda_max : null;
    const bet = state.decision.bet_tech_level;
    const pred = predictHorizon(lambda, bet);
    const cursor = state.civState && typeof state.civState.cursor_t === 'number'
      ? state.civState.cursor_t : 0.0;
    const next = nextChaosFrom(state.payload.eras, cursor);

    if (!pred) {
      out.delta0.textContent = '—';
      out.horizon.textContent = '—';
      out.nextChaos.textContent = next != null ? next.toFixed(1) : '—';
      out.verdict.textContent = '—';
      out.verdict.className = 'v gray';
      return;
    }
    out.delta0.textContent = pred.delta0.toExponential(2);
    out.horizon.textContent = pred.T_predict.toFixed(2) + ' yr';
    out.nextChaos.textContent = next != null ? next.toFixed(1) : '无可见乱纪元';
    let covers = null;
    if (next != null) {
      const interval = next - cursor;
      covers = pred.T_predict >= interval;  // covers = survives next
    }
    out.verdict.classList.remove('ok', 'bad', 'gray');
    if (covers === null) {
      out.verdict.textContent = '无间隔可比';
      out.verdict.classList.add('gray');
    } else if (covers) {
      out.verdict.textContent = '覆盖 = 幸存';
      out.verdict.classList.add('ok');
    } else {
      out.verdict.textContent = '不覆盖 = 灾难将至';
      out.verdict.classList.add('bad');
    }
    // Update header civ meta + enable COMMIT
    const meta = document.getElementById('civ-meta');
    const cm = state.civState && state.civState.civilization
      ? state.civState.civilization : null;
    if (meta) {
      if (cm) {
        const evacuated = cm.evacuated ? ' · 已逃离' : '';
        meta.textContent = `文明计数=${cm.count} · 科技等级=${cm.tech_level.toFixed(2)} · 上次=${cm.last_event || '—'}${evacuated}`;
      } else {
        meta.textContent = '文明计数=— · 科技等级=—';
      }
    }
  }

  // ------------------------------------------------------------
  // Commit + event log
  // ------------------------------------------------------------
  function readDecision() {
    return {
      tech_investment: parseFloat(document.getElementById('dec-tech').value),
      shelter_priority: parseFloat(document.getElementById('dec-shelter').value),
      stockpile: parseFloat(document.getElementById('dec-stockpile').value),
      bet_tech_level: parseFloat(document.getElementById('dec-bet').value),
    };
  }

  function setCommitStatus(text, kind) {
    const el = document.getElementById('commit-status');
    el.textContent = text;
    el.classList.remove('ok', 'err');
    if (kind === 'ok') el.classList.add('ok');
    if (kind === 'err') el.classList.add('err');
  }

  function appendLogEntry(state, beat) {
    const log = document.getElementById('event-log');
    if (!log) return;
    const placeholder = log.querySelector('.log-empty');
    if (placeholder) placeholder.remove();

    const trace = (beat && beat.model_trace) || {};
    const eventLog = trace.kernel_event_log || [];
    const verdict = trace.kernel_verdict || (beat && beat.intent) || 'unknown';
    const civ = trace.civilization || {};
    const worlds = (beat && beat.world_updates) || [];
    const narrative = (worlds[0] && worlds[0].content) || '';
    const title = (worlds[0] && worlds[0].title) || `三体：第${trace.world_builder_beat || '?'}拍`;

    const entry = document.createElement('div');
    entry.className = 'entry';

    const beatLabel = trace.world_builder_beat != null
      ? `BEAT ${trace.world_builder_beat}` : 'BEAT ?';
    const isoNow = new Date().toISOString().slice(11, 19);

    const verdictClass = verdict === 'survived' ? 'survived'
      : (verdict === 'destroyed' ? 'destroyed' : '');
    const verdictLabel = verdict === 'survived' ? '幸存'
      : (verdict === 'destroyed' ? '毁灭' : verdict);

    const kernelRows = eventLog.map(line =>
      `<span class="row">${escapeHtml(line)}</span>`).join('');

    const narrativeBlock = narrative
      ? `<div class="el-narrative"><span class="n-title">${escapeHtml(title)}</span>${escapeHtml(narrative)}</div>`
      : '';

    entry.innerHTML =
      `<div class="e-head">
         <span class="beat">${escapeHtml(beatLabel)}</span>
         <span class="ts">${escapeHtml(isoNow)} · civ.count=${civ.count != null ? civ.count : '?'} tech=${civ.tech_level != null ? civ.tech_level.toFixed(2) : '?'}</span>
         <span class="verdict ${verdictClass}">${escapeHtml(verdictLabel)}</span>
       </div>
       <div class="el-kernel">${kernelRows || '<span class="row">(内核无事件)</span>'}</div>
       ${narrativeBlock}`;

    log.insertBefore(entry, log.firstChild);
  }

  // ---- Narrative-only panel (the LLM prose feed) ------------------
  // Spec §8.4: each COMMIT's beat.world_updates[0] carries
  //   {title, content, source="three_body_kernel_narration"}
  // plus the dialogue line (beat.dialogue). We render the
  // full title+narrative+dialogue as a dedicated feed so the long
  // Chinese prose is easy to read separately from the structured
  // kernel event log.
  function appendNarrativeEntry(state, beat) {
    const feed = document.getElementById('narr-feed');
    if (!feed) return;
    const placeholder = feed.querySelector('.narr-empty');
    if (placeholder) placeholder.remove();

    const trace = (beat && beat.model_trace) || {};
    const worlds = (beat && beat.world_updates) || [];
    const nu = worlds[0];
    const title = (nu && nu.title) || `三体：第${trace.world_builder_beat || '?'}拍`;
    const body = (nu && nu.content) || '';
    const dialogue = (beat && beat.dialogue) || '';
    const beatN = trace.world_builder_beat != null ? trace.world_builder_beat : '?';
    const eraKind = currentEraKind(state);
    const isoNow = new Date().toISOString().slice(11, 19);

    const entry = document.createElement('div');
    entry.className = 'narr-entry';
    entry.innerHTML =
      `<div class="n-head">
         <span class="beat">BEAT ${escapeHtml(String(beatN))}</span>
         <span class="ts">${escapeHtml(isoNow)}</span>
         <span class="era ${eraKind}">${eraKind === 'chaotic' ? '乱纪元' : '恒纪元'}</span>
       </div>
       <div class="n-title">${escapeHtml(title)}</div>
       <div class="n-body">${escapeHtml(body) || '<em>(narrative 为空 — 见下方 LLM warning)</em>'}</div>
       ${dialogue
         ? `<div class="n-dialogue"><span class="q">「</span>${escapeHtml(dialogue)}<span class="q">」</span></div>`
         : ''}`;
    feed.insertBefore(entry, feed.firstChild);
    updateNarrMeta(state);
  }

  // Pre-populate narrative panel from GET /api/three_body/state when the
  // session already has beats on disk (returning user).
  function hydrateNarrativeFromState(state, threeBodyState) {
    if (!threeBodyState) return;
    const recent = Array.isArray(threeBodyState.recent_narration) ? threeBodyState.recent_narration : [];
    const feed = document.getElementById('narr-feed');
    if (!feed || recent.length === 0) return;
    const empty = feed.querySelector('.narr-empty');
    if (empty) empty.remove();
    // Insert oldest first so the feed ends up with newest on top.
    for (let i = recent.length - 1; i >= 0; i--) {
      const r = recent[i];
      const entry = document.createElement('div');
      entry.className = 'narr-entry';
      const beatN = r.beat != null ? r.beat : '?';
      const eraKind = currentEraKind(state);
      entry.innerHTML =
        `<div class="n-head">
           <span class="beat">BEAT ${escapeHtml(String(beatN))}</span>
           <span class="ts">(历史)</span>
           <span class="era ${eraKind}">${eraKind === 'chaotic' ? '乱纪元' : '恒纪元'}</span>
         </div>
         <div class="n-title">${escapeHtml((r.narrative || '').slice(0, 14) || `三体：第${beatN}拍`)}</div>
         <div class="n-body">${escapeHtml(r.narrative || '')}</div>
         ${r.dialogue
           ? `<div class="n-dialogue"><span class="q">「</span>${escapeHtml(r.dialogue)}<span class="q">」</span></div>`
           : ''}`;
      feed.insertBefore(entry, feed.firstChild);
    }
    updateNarrMeta(state);
  }

  function updateNarrMeta(state) {
    const meta = document.getElementById('narr-meta');
    const feed = document.getElementById('narr-feed');
    if (!meta) return;
    const n = feed ? feed.querySelectorAll('.narr-entry').length : 0;
    meta.textContent = `${n} 拍叙述 · world_id=${state.worldId}`;
  }

  // Determine the kernel's current era kind (stable/chaotic) from the baked
  // eras + cursor_t. Used to colour the narrative feed entry's badge.
  function currentEraKind(state) {
    if (!state.payload || !state.civState) return 'stable';
    const cursor = state.civState.cursor_t || 0;
    const eras = state.payload.eras || [];
    for (const e of eras) {
      const t0 = e.start, t1 = e.end;
      if (t0 <= cursor && cursor < t1) return e.kind;
    }
    // cursor past last era → use last era's kind
    if (eras.length > 0) return eras[eras.length - 1].kind;
    return 'stable';
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ------------------------------------------------------------
  // Boot
  // ------------------------------------------------------------
  function boot(opts) {
    opts = opts || {};
    const backend = opts.backend || BACKEND_DEFAULT;
    const sessionId = opts.sessionId || 'three_body_arc';
    const defaults = Object.assign({
      seed: 2026, years: 200, dt: 0.02, frames: 600,
    }, opts.defaults || {});

    const state = {
      payload: null,
      orbitFrame: 0,
      playing: false,
      civState: null,           // kernel civ scalars from /api/three_body/state
      decision: readDecision(), // DecisionVector mirrored to sliders
      worldId: WORLD_IDS.HOME,  // active backend world_id (for /api/dispatch)
      cv: {
        orbit:  document.getElementById('cv-orbit'),
        light:  document.getElementById('cv-light'),
        civ:    document.getElementById('cv-civ'),
        lambda: document.getElementById('cv-lambda'),
      },
    };

    function setStatus(text, kind) {
      const el = document.getElementById('ctl-status');
      el.textContent = text;
      el.classList.remove('ok', 'err');
      if (kind === 'ok') el.classList.add('ok');
      if (kind === 'err') el.classList.add('err');
    }

    async function load() {
      const params = {
        seed:   parseInt(document.getElementById('ctl-seed').value, 10),
        years:  parseFloat(document.getElementById('ctl-years').value),
        dt:     parseFloat(document.getElementById('ctl-dt').value),
        frames: parseInt(document.getElementById('ctl-frames').value, 10),
      };
      const btn = document.getElementById('ctl-bake');
      btn.disabled = true;
      setStatus('烘焙中… 辛积分 + Lyapunov 估计', '');
      setCommitStatus('烘焙中…', '');
      stopOrbitLoop(state);
      try {
        const payload = await fetchBake(backend, params);
        if (!payload.ok) throw new Error(payload.error || 'bake failed');
        state.payload = payload;
        state.orbitFrame = 0;
        const F = payload.stars.length;
        const scrub = document.getElementById('orbit-scrub');
        scrub.max = F - 1;
        scrub.value = 0;
        updateStats(payload);
        redraw(state);
        setStatus(`就绪 · ${payload.kernel.baked_samples} 帧 · λ=${payload.kernel.lambda_max.toFixed(4)}`,
                  'ok');
        // Hydrate kernel-tracked civ state (the worldbook ground truth).
        const fresh = await fetchThreeBodyState(backend);
        if (fresh) {
          state.civState = fresh;
          // Pre-populate event log with prior beat(s) so the panel isn't
          // empty when returning users revisit the dashboard.
          const recent = Array.isArray(fresh.recent_narration)
            ? fresh.recent_narration : [];
          const log = document.getElementById('event-log');
          if (log && recent.length) {
            const empty = log.querySelector('.log-empty');
            if (empty) empty.remove();
            // Render older entries first so insertBefore(firstChild) keeps
            // the latest at the top during a live session.
            for (let i = recent.length - 1; i >= 0; i--) {
              const beat = {
                world_updates: [{ title: recent[i].narrative && recent[i].narrative.slice(0, 14),
                                  content: recent[i].narrative || '' }],
                model_trace: {
                  world_builder_beat: recent[i].beat,
                  kernel_event_log: recent[i].event_log || [],
                  kernel_verdict: 'history',
                  civilization: { count: '-', tech_level: 0 },
                },
              };
              appendLogEntry(state, beat);
            }
          }
          // Narrative-only feed — show the same LLM history in full text form.
          hydrateNarrativeFromState(state, fresh);
        } else {
          // Backend reachable but state not yet initialised → neutral.
          state.civState = { civilization: { count: 1, tech_level: 0,
                                            alive: true, evacuated: false,
                                            last_event: '' }, cursor_t: 0,
                             max_tech: 8 };
        }
        renderPrediction(state);
        document.getElementById('commit-btn').disabled = false;
        setCommitStatus('准备 COMMIT', 'ok');
        // Auto-play orbit
        startOrbitLoop(state);
      } catch (err) {
        console.error(err);
        setStatus('失败: ' + err.message, 'err');
        setCommitStatus('烘焙失败 — ' + err.message, 'err');
      } finally {
        btn.disabled = false;
      }
    }

    // Wire controls
    document.getElementById('ctl-bake').addEventListener('click', load);

    document.getElementById('ctl-frames').addEventListener('input', (e) => {
      document.getElementById('ctl-frames-val').textContent = e.target.value;
    });
    document.getElementById('orbit-scrub').addEventListener('input', (e) => {
      if (!state.payload) return;
      state.orbitFrame = parseInt(e.target.value, 10);
      document.getElementById('orbit-time').textContent =
        `t=${state.payload.t[state.orbitFrame].toFixed(2)}`;
      drawOrbit(state.cv.orbit, state.payload, state.orbitFrame);
    });
    document.getElementById('orbit-play').addEventListener('click', () => {
      if (!state.payload) return;
      if (state.playing) stopOrbitLoop(state);
      else startOrbitLoop(state);
    });

    // Decision vector sliders → readDecision + live prediction.
    // Each input: update display, refresh prediction. Microsec, no backend.
    function wireSlider(id, valId) {
      const el = document.getElementById(id);
      const valEl = document.getElementById(valId);
      el.addEventListener('input', () => {
        valEl.textContent = parseFloat(el.value).toFixed(id === 'dec-bet' ? 1 : 2);
        state.decision = readDecision();
        renderPrediction(state);
      });
    }
    wireSlider('dec-tech', 'dec-tech-val');
    wireSlider('dec-shelter', 'dec-shelter-val');
    wireSlider('dec-stockpile', 'dec-stockpile-val');
    wireSlider('dec-bet', 'dec-bet-val');

    // COMMIT button — POST /api/world/tick with the decision vector.
    document.getElementById('commit-btn').addEventListener('click', async () => {
      if (!state.payload) {
        setCommitStatus('请先烘焙时间线', 'err');
        return;
      }
      const btn = document.getElementById('commit-btn');
      btn.disabled = true;
      setCommitStatus('内核积分中…', '');
      try {
        const beat = await commitTick(backend, sessionId, readDecision(), state.worldId);
        appendLogEntry(state, beat);
        // Hydrate kernel state and re-render prediction.
        const fresh = await fetchThreeBodyState(backend);
        if (fresh) {
          state.civState = fresh;
          renderPrediction(state);
          // ALSO update the narrative feed's era badges, since cursor
          // has just advanced into a potentially new era.
          updateNarrMeta(state);
        }
        // Narrative feed: append THIS beat's prose so it's visible
        // without scrolling.
        if (beat) appendNarrativeEntry(state, beat);
        setCommitStatus('COMMIT 成功 · 见事件日志', 'ok');
      } catch (err) {
        console.error(err);
        setCommitStatus('COMMIT 失败: ' + err.message, 'err');
      } finally {
        btn.disabled = false;
      }
    });

    // Handle window resize (redraw canvases)
    let resizeRaf = null;
    window.addEventListener('resize', () => {
      if (!state.payload) return;
      if (resizeRaf) cancelAnimationFrame(resizeRaf);
      resizeRaf = requestAnimationFrame(() => redraw(state));
    });

    // ============================================================
    // Create a fresh three-body world
    // ============================================================
    function setWorldIdBadge(wid) {
      const badge = document.getElementById('ctl-world-id');
      if (badge) badge.textContent = 'world=' + wid;
      document.body.dataset.world = wid;
      const commitBtn = document.getElementById('commit-btn');
      if (commitBtn) commitBtn.disabled = !state.payload;
    }

    async function createWorld() {
      const btn = document.getElementById('ctl-create');
      const sw = document.getElementById('ctl-status');
      btn.disabled = true;
      sw.textContent = '播种中… /api/dispatch (world_id=three_body)';
      sw.classList.remove('ok', 'err');
      try {
        await dispatchSeed(
          backend,
          '请在 world_id=three_body 下播种一个新三体世界：建立了一颗行星，处于一个不规则的三星系统轨道上，行星上有一个有文明的物种，刚刚进入了第一个恒纪元。',
          WORLD_IDS.HOME,
          sessionId,
        );
        state.worldId = WORLD_IDS.HOME;
        setWorldIdBadge(WORLD_IDS.HOME);
        sw.textContent = '已播种 · 重新烘焙时间线';
        sw.classList.add('ok');
        // Immediately re-bake so the kernel timeline reflects the new world.
        await load();
        // Re-fetch civ state — fresh world = civ.count = 1.
        const fresh = await fetchThreeBodyState(backend);
        if (fresh) {
          state.civState = fresh;
          renderPrediction(state);
        }
      } catch (err) {
        console.error(err);
        sw.textContent = '播种失败: ' + err.message;
        sw.classList.add('err');
      } finally {
        btn.disabled = false;
      }
    }

    document.getElementById('ctl-create').addEventListener('click', createWorld);

    setWorldIdBadge(WORLD_IDS.HOME);

    // Auto-bake on load with defaults
    load();
  }

  global.ThreeBody = { boot };
})(window);
