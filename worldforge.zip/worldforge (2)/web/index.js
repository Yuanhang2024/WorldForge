/* ============================================================
 * web/index.js — GUI-first entry point.
 *
 * Both visible paths enter the editable five-step onboarding wizard:
 *   description → model/neutral draft → user edit → user confirm.
 * No home-page action can bypass the confirmation stages.
 * ============================================================ */

(function (root) {
  "use strict";

  function $(id) {
    return document.getElementById(id);
  }

  function setStatus(text, isError) {
    var el = $("forge-status");
    if (!el) return;
    el.textContent = text;
    el.classList.toggle("error", !!isError);
    el.setAttribute("data-state", isError ? "error" : "active");
  }

  function normalizedDescription() {
    var input = $("world-desc");
    var desc = input && input.value ? input.value.trim() : "";
    return desc;
  }

  function openEditableWizard(autoPrefill) {
    var desc = normalizedDescription();
    setStatus(
      autoPrefill
        ? "正在进入分步向导；第 1 步会请求模型预填，之后每步都可编辑并确认。"
        : "正在进入手动分步向导；每一步都由你触发预填、编辑并确认。"
    );
    root.location.href =
      "/onboarding.html?autoprefill=" + (autoPrefill ? "1" : "0") +
      "&description=" + encodeURIComponent(desc);
  }

  function init() {
    var prefillBtn = $("forge-btn");
    var manualBtn = $("manual-wizard-btn");
    var input = $("world-desc");
    if (!prefillBtn || !manualBtn || !input) return;

    prefillBtn.addEventListener("click", function () {
      openEditableWizard(true);
    });
    manualBtn.addEventListener("click", function () {
      openEditableWizard(false);
    });
    input.addEventListener("keydown", function (event) {
      if (event.key === "Enter") {
        event.preventDefault();
        prefillBtn.click();
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  root.WorldForgeEntry = {
    openEditableWizard: openEditableWizard,
    normalizedDescription: normalizedDescription,
  };
})(typeof window !== "undefined" ? window : this);
