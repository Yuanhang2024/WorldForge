/* ============================================================
 * web/onboarding.js — 5-step onboarding wizard with propose+confirm.
 *
 * Each step:
 *   "生成草案" (propose) → LLM fills editable form → user edits →
 *   "确认" (confirm) → persists → next step enabled
 *
 * Steps:
 *   1. World  — propose → edit world_type/seed/lambda/initial_state → confirm
 *   2. Characters — propose → edit char cards → confirm
 *   3. Rules+GUI — propose → edit rules/state/gui → confirm
 *   4. Gameplay — propose → edit gameplay → confirm
 *   5. Finalize → POST /api/onboarding/finalize → enter-world link
 * ============================================================ */

(function (root) {
  "use strict";

  var state = {
    step: 1,
    worldId: null,
    description: "",
    worldbook: null,
    completed: {},
    // per-step draft (LLM proposal before user edits)
    draft: {},
  };

  var STEP_GUIDE = {
    1: {
      name: "世界",
      prerequisite: "连接可用 LLM；构想可留空并由模型从零生成。",
      next: "点击“LLM 预填世界草案”，编辑后确认。",
    },
    2: {
      name: "角色",
      prerequisite: "第 1 步世界已经确认并取得 world_id。",
      next: "预填角色卡，逐项编辑后确认。",
    },
    3: {
      name: "规则 + GUI",
      prerequisite: "第 2 步角色已经确认。",
      next: "预填规则、状态、GUI 布局和组件，编辑后确认。",
    },
    4: {
      name: "玩法",
      prerequisite: "第 3 步规则与 GUI 已经确认。",
      next: "预填玩法 JSON，编辑后确认。",
    },
    5: {
      name: "确认",
      prerequisite: "前四步均已经由你确认。",
      next: "点击“确认并完成”，然后进入世界。",
    },
  };

  var FROM_SCRATCH_PROMPTS = {
    world: "请从零生成一个原创世界，并自行决定其状态结构、角色空间和规则方向。",
    characters: "请从零生成适合当前世界的原创角色卡，并完整填写所有可编辑字段。",
    rules: "请从零生成当前世界的规则、初始状态和可操作 GUI。",
    gameplay: "请从零生成当前世界的玩法、合法行动、终止条件和状态转换。",
  };

  // ----- DOM helpers -----
  function $(id) { return document.getElementById(id); }

  function setStatus(id, badge, text, type) {
    var el = $(id);
    if (!el) return;
    el.innerHTML = "";
    var b = document.createElement("span");
    b.className = "badge";
    b.textContent = badge;
    el.appendChild(b);
    var span = document.createElement("span");
    span.textContent = text;
    el.appendChild(span);
    el.classList.remove("error", "ok");
    if (type === "error") el.classList.add("error");
    if (type === "ok") el.classList.add("ok");
    el.setAttribute("data-state", type === "error" ? "error" : (
      type === "ok" ? "complete" : String(badge || "working").toLowerCase()
    ));
  }

  function updateFlowGuide(n, blockedText) {
    var guide = STEP_GUIDE[n] || STEP_GUIDE[1];
    if ($("flow-current")) {
      $("flow-current").textContent = "当前：第 " + n + " 步，共 5 步 · " + guide.name;
    }
    if ($("flow-prerequisite")) {
      $("flow-prerequisite").textContent = "前置条件：" + (blockedText || guide.prerequisite);
    }
    if ($("flow-next")) {
      $("flow-next").textContent = state.completed[n]
        ? "完成态：本步已确认，可进入下一步；返回编辑后请重新确认。"
        : "下一步：" + guide.next;
    }
    if ($("flow-guide")) {
      $("flow-guide").setAttribute(
        "data-state", state.completed[n] ? "complete" : (blockedText ? "blocked" : "current")
      );
    }
  }

  function showStep(n) {
    if (n > 1 && !state.completed[n - 1]) {
      updateFlowGuide(state.step, "请先确认第 " + (n - 1) + " 步。");
      return false;
    }
    var active = document.activeElement;
    if (active && typeof active.blur === "function") active.blur();
    state.step = n;
    for (var i = 1; i <= 5; i++) {
      var panel = $("step-" + i);
      panel.classList.toggle("hidden", i !== n);
      panel.setAttribute("aria-hidden", i === n ? "false" : "true");
    }
    var currentHeading = $("step-" + n).querySelector("h2");
    if (currentHeading) {
      currentHeading.setAttribute("tabindex", "-1");
      currentHeading.focus({ preventScroll: true });
    }
    var steps = document.querySelectorAll("#stepper .step");
    steps.forEach(function (s) {
      var idx = parseInt(s.getAttribute("data-step"), 10);
      s.classList.toggle("active", idx === n);
      s.classList.toggle("done", !!state.completed[idx]);
      s.setAttribute("data-state", idx === n ? "current" : (
        state.completed[idx] ? "complete" : "pending"
      ));
      if (idx === n) s.setAttribute("aria-current", "step");
      else s.removeAttribute("aria-current");
    });
    var statusEl = $("status-" + n);
    if (statusEl && statusEl.getAttribute("data-state") === "locked") {
      setStatus(
        "status-" + n, "READY",
        "前置步骤已完成。点击本步的 LLM 预填按钮，编辑草案后确认。",
        false
      );
    }
    updateFlowGuide(n);
    return true;
  }

  function markStepComplete(n) {
    state.completed[n] = true;
    updateFlowGuide(n);
    var marker = document.querySelector('#stepper .step[data-step="' + n + '"]');
    if (marker) {
      marker.classList.add("done");
      marker.setAttribute("data-state", n === state.step ? "current" : "complete");
    }
  }

  /** Update world-id display in header */
  function updateWorldIdDisplay() {
    var el = $("world-id-display");
    if (state.worldId) {
      el.textContent = "world_id: " + state.worldId;
    } else {
      el.textContent = "";
    }
  }

  /** Show/hide the "next" button for a step (shown only after confirm) */
  function showNextButton(step, visible) {
    var btn = $("next-" + step);
    if (btn) btn.classList.toggle("hidden", !visible);
  }

  /** Show/hide the confirm button */
  function showConfirmButton(step, visible) {
    var btn = $("confirm-" + step);
    if (btn) btn.classList.toggle("hidden", !visible);
  }

  // ----- Utility: fetch with JSON body -----
  function apiPost(url, body) {
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).then(function (r) { return r.json(); });
  }

  function draftStatusText(noun) {
    return noun + "已由 LLM 从零生成；请编辑后确认。";
  }

  function blockDraftStep(step, badge, message) {
    delete state.draft[step === 1 ? "world" : (
      step === 2 ? "characters" : (step === 3 ? "rules" : "gameplay")
    )];
    delete state.completed[step];
    showConfirmButton(step, false);
    showNextButton(step, false);
    var draftId = step === 1 ? "world-draft" : (
      step === 2 ? "char-draft" : (
        step === 3 ? "rules-draft" : "gameplay-draft"
      )
    );
    if ($(draftId)) $(draftId).classList.add("hidden");
    var marker = document.querySelector('#stepper .step[data-step="' + step + '"]');
    if (marker) {
      marker.classList.remove("done");
      marker.setAttribute("data-state", "current");
    }
    setStatus("status-" + step, badge, message, "error");
    updateFlowGuide(step, "必须连接可用 LLM 并成功生成本步草案。");
  }

  // ================================================================
  //  STEP 1 — WORLD
  // ================================================================

  function readWorldbookFile(file, cb) {
    if (!file) return cb(null);
    var reader = new FileReader();
    reader.onload = function () {
      try { cb(JSON.parse(reader.result)); }
      catch (e) { cb(null, "世界书 JSON 解析失败：" + e.message); }
    };
    reader.readAsText(file);
  }

  function doProposeWorld() {
    var desc = $("world-desc").value.trim();
    var file = $("worldbook-file").files[0];
    if (!desc && !file) {
      setStatus("status-1", "LLM", "输入为空：正在要求 LLM 从零生成世界。", false);
    }
    state.description = desc;
    if (file) {
      readWorldbookFile(file, function (wb, err) {
        if (err) {
          setStatus("status-1", "ERROR", err, "error");
          return;
        }
        state.worldbook = wb;
        if (!state.description && wb) state.description = "导入世界";
        sendProposeWorld();
      });
    } else {
      state.worldbook = null;
      sendProposeWorld();
    }
  }

  function sendProposeWorld() {
    setStatus("status-1", "LLM", "正在生成世界草案…", false);
    $("propose-1").disabled = true;
    apiPost("/api/onboarding/world/propose", { description: state.description })
      .then(function (result) {
        $("propose-1").disabled = false;
        if (!result.ok) {
          blockDraftStep(
            1, "LLM_REQUIRED",
            "世界草案生成失败：" + (result.error || "需要可用 LLM。")
          );
          return;
        }
        // Fill editable fields with proposal
        state.draft.world = result;
        var draft = result.draft || result;
        var wp = draft.world_params || {};
        var hasModelContent = !!(
          draft.world_type || wp.world_type ||
          draft.seed != null || wp.seed != null ||
          draft.lambda != null || wp.lambda != null ||
          (draft.initial_state && Object.keys(draft.initial_state).length) ||
          (wp.initial_state && Object.keys(wp.initial_state).length)
        );
        if (!hasModelContent) {
          blockDraftStep(
            1, "LLM_REQUIRED",
            "服务未返回有效的 LLM 世界草案；本步骤已阻断。"
          );
          return;
        }
        $("edit-world-type").value = draft.world_type || wp.world_type || "";
        $("edit-seed").value = wp.seed != null ? String(wp.seed) : (draft.seed != null ? String(draft.seed) : "");
        $("edit-lambda").value = wp.lambda != null ? String(wp.lambda) : (draft.lambda != null ? String(draft.lambda) : "");
        $("edit-initial-state").value = draft.initial_state
          ? (typeof draft.initial_state === "string" ? draft.initial_state : JSON.stringify(draft.initial_state, null, 2))
          : "";
        $("world-draft").classList.remove("hidden");
        showConfirmButton(1, true);
        setStatus("status-1", "DRAFT", draftStatusText("世界草案"), "ok");
      })
      .catch(function (err) {
        $("propose-1").disabled = false;
        blockDraftStep(
          1, "ERROR",
          "LLM 世界草案请求失败：" + String(err.message || err)
        );
      });
  }

  function doConfirmWorld() {
    var seedText = $("edit-seed").value.trim();
    var lambdaText = $("edit-lambda").value.trim();
    var seedValue = Number(seedText);
    var lambdaValue = Number(lambdaText);
    if (
      !seedText || !Number.isInteger(seedValue) ||
      !lambdaText || !Number.isFinite(lambdaValue) ||
      lambdaValue < 0 || lambdaValue > 1
    ) {
      setStatus(
        "status-1",
        "INVALID",
        "seed 必须是整数，Lambda 必须是 0 到 1 之间的数字。",
        "error"
      );
      return;
    }
    var edited = {
      world_params: {
        world_type: $("edit-world-type").value.trim(),
        seed: seedValue,
        lambda: lambdaValue,
      },
    };
    var initialStateStr = $("edit-initial-state").value.trim();
    if (initialStateStr) {
      try { edited.world_params.initial_state = JSON.parse(initialStateStr); }
      catch (e) {
        setStatus("status-1", "INVALID", "初始状态 JSON 无法解析：" + e.message, "error");
        return;
      }
    }
    setStatus("status-1", "SAVE", "正在确认世界…", false);
    $("confirm-1").disabled = true;
    apiPost("/api/onboarding/world/confirm", {
      description: state.description,
      edited_params: edited,
    }).then(function (result) {
      $("confirm-1").disabled = false;
      if (!result.ok) {
        setStatus("status-1", "ERROR", result.error || "confirm 失败", "error");
        return;
      }
      state.worldId = result.world_id;
      updateWorldIdDisplay();
      var finishWorldStep = function (suffix) {
        markStepComplete(1);
        showConfirmButton(1, false);
        showNextButton(1, true);
        setStatus(
          "status-1", "COMPLETE",
          "第 1 步已完成：世界已创建 " + state.worldId +
            (suffix ? "；" + suffix : "") + "。下一步创建角色。",
          "ok"
        );
      };
      if (state.worldbook) {
        setStatus("status-1", "IMPORT", "世界已创建，正在导入已选择的世界书…", false);
        apiPost("/api/world/import_worldbook", {
          world_id: state.worldId,
          lorebook: state.worldbook,
          merge: true,
        }).then(function (imported) {
          if (imported.ok) {
            finishWorldStep("世界书已导入 " + (imported.imported || 0) + " 条");
          } else {
            finishWorldStep("世界书导入失败，可返回本步重试");
          }
        }).catch(function () {
          finishWorldStep("世界书导入失败，可返回本步重试");
        });
      } else {
        finishWorldStep("");
      }
    }).catch(function (err) {
      $("confirm-1").disabled = false;
      setStatus("status-1", "ERROR", String(err.message || err), "error");
    });
  }

  function initStep1() {
    $("propose-1").addEventListener("click", doProposeWorld);
    $("confirm-1").addEventListener("click", doConfirmWorld);
    $("next-1").addEventListener("click", function () { showStep(2); });

    // ----- Worldbook file upload -----
    $("worldbook-file").addEventListener("change", function () {
      var file = this.files[0];
      if (!file) return;
      var wid = state.worldId;
      // Fallback: try URL param ?world_id=
      if (!wid) {
        var m = location.search.match(/[?&]world_id=([^&]+)/);
        if (m) wid = decodeURIComponent(m[1]);
      }
      if (!wid) {
        setStatus("status-1", "READY", "世界书已选择；点击“LLM 预填世界草案”，确认世界后再导入内容。", "ok");
        return;
      }
      var reader = new FileReader();
      reader.onload = function () {
        var parsed;
        try { parsed = JSON.parse(reader.result); }
        catch (e) {
          setStatus("status-1", "ERROR", "世界书 JSON 解析失败: " + e.message, "error");
          return;
        }
        setStatus("status-1", "UPLOAD", "正在导入世界书…", false);
        apiPost("/api/world/import_worldbook", {
          world_id: wid,
          lorebook: parsed,
          merge: true,
        }).then(function (result) {
          if (!result.ok) {
            setStatus("status-1", "ERROR", result.error || "导入世界书失败", "error");
            return;
          }
          var count = result.imported != null ? result.imported : 0;
          setStatus("status-1", "OK", "世界书导入成功 (" + count + " 条)", "ok");
        }).catch(function (err) {
          setStatus("status-1", "ERROR", String(err.message || err), "error");
        });
      };
      reader.readAsText(file);
    });
  }

  // ================================================================
  //  STEP 2 — CHARACTERS
  // ================================================================

  function renderCharCards(chars) {
    var container = $("char-cards");
    container.innerHTML = "";
    if (!chars || chars.length === 0) return;
    chars.forEach(function (c, idx) {
      var card = document.createElement("div");
      card.className = "char-card";
      card.setAttribute("data-testid", "character-card-" + idx);
      card.innerHTML =
        '<div class="char-header">' +
        '  <label>角色 #' + (idx + 1) + '</label>' +
        '  <button type="button" class="remove-char" data-idx="' + idx + '" aria-label="移除角色 ' + (idx + 1) + '">移除</button>' +
        '</div>' +
        '<div class="field"><label for="char-name-' + idx + '">姓名</label><input id="char-name-' + idx + '" class="char-name" data-idx="' + idx + '" data-testid="character-name-' + idx + '" value="' + escAttr(c.name || "") + '" /></div>' +
        '<div class="field"><label for="char-personality-' + idx + '">性格</label><textarea id="char-personality-' + idx + '" class="char-personality" data-idx="' + idx + '" data-testid="character-personality-' + idx + '" rows="2">' + escHtml(c.personality || "") + '</textarea></div>' +
        '<div class="field"><label for="char-appearance-' + idx + '">外貌（纯文本）</label><textarea id="char-appearance-' + idx + '" class="char-appearance" data-idx="' + idx + '" data-testid="character-appearance-' + idx + '" rows="2">' + escHtml(c.appearance || "") + '</textarea></div>' +
        '<div class="field"><label for="char-line-' + idx + '">示例台词</label><textarea id="char-line-' + idx + '" class="char-line" data-idx="' + idx + '" data-testid="character-line-' + idx + '" rows="2">' + escHtml(c.sample_line || "") + '</textarea></div>';
      container.appendChild(card);
    });
    // Bind remove buttons
    container.querySelectorAll(".remove-char").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var idx = parseInt(btn.getAttribute("data-idx"), 10);
        state.draft.characters.splice(idx, 1);
        renderCharCards(state.draft.characters);
        if (state.draft.characters.length === 0) {
          $("char-draft").classList.remove("hidden"); // keep visible but empty
        }
      });
    });
  }

  function collectEditedCharacters() {
    var result = [];
    var cards = document.querySelectorAll("#char-cards .char-card");
    cards.forEach(function (card, idx) {
      result.push({
        name: card.querySelector(".char-name").value.trim(),
        personality: card.querySelector(".char-personality").value.trim(),
        appearance: card.querySelector(".char-appearance").value.trim(),
        sample_line: card.querySelector(".char-line").value.trim(),
      });
    });
    return result;
  }

  function escHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function escAttr(s) {
    return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function doProposeCharacters() {
    if (!state.worldId) {
      setStatus("status-2", "ERROR", "请先完成世界创建。", "error");
      return;
    }
    var desc = $("char-desc").value.trim();
    var mode = $("char-mode").value;
    if (!desc) {
      desc = FROM_SCRATCH_PROMPTS.characters;
      setStatus("status-2", "LLM", "输入为空：正在要求 LLM 从零生成角色。", false);
    }
    setStatus("status-2", "LLM", "正在生成角色草案…", false);
    $("propose-2").disabled = true;
    apiPost("/api/onboarding/characters/propose", {
      world_id: state.worldId,
      description: desc,
      mode: mode,
    }).then(function (result) {
      $("propose-2").disabled = false;
      if (!result.ok) {
        blockDraftStep(
          2, "LLM_REQUIRED",
          "角色草案生成失败：" + (result.error || "需要可用 LLM。")
        );
        return;
      }
      var chars = Array.isArray(result) ? result : (result.characters || result.draft || []);
      var hasLlmContent = chars.length > 0 && chars.some(function (c) {
        return !!(c && (c.personality || c.appearance || c.sample_line));
      });
      if (!hasLlmContent || result.degraded) {
        blockDraftStep(
          2, "LLM_REQUIRED",
          "服务未返回完整的 LLM 角色草案；本步骤已阻断。"
        );
        return;
      }
      state.draft.characters = chars.slice();
      renderCharCards(chars);
      $("char-draft").classList.remove("hidden");
      showConfirmButton(2, true);
      setStatus(
        "status-2", "DRAFT",
        chars.length + " 个角色草案已由 LLM 从零生成；可编辑后确认。",
        "ok"
      );
    }).catch(function (err) {
      $("propose-2").disabled = false;
      blockDraftStep(
        2, "ERROR",
        "LLM 角色草案请求失败：" + String(err.message || err)
      );
    });
  }

  function doConfirmCharacters() {
    if (!state.worldId) return;
    var edited = collectEditedCharacters();
    if (edited.length === 0) {
      setStatus("status-2", "EMPTY", "至少需要一个角色。", "error");
      return;
    }
    setStatus("status-2", "SAVE", "正在确认角色…", false);
    $("confirm-2").disabled = true;
    apiPost("/api/onboarding/characters/confirm", {
      world_id: state.worldId,
      edited_characters: edited,
    }).then(function (result) {
      $("confirm-2").disabled = false;
      if (!result.ok) {
        setStatus("status-2", "ERROR", result.error || "confirm 失败", "error");
        return;
      }
      markStepComplete(2);
      showConfirmButton(2, false);
      showNextButton(2, true);
      setStatus("status-2", "COMPLETE", "第 2 步已完成：" + edited.length + " 个角色已确认。下一步设置规则与 GUI。", "ok");
    }).catch(function (err) {
      $("confirm-2").disabled = false;
      setStatus("status-2", "ERROR", String(err.message || err), "error");
    });
  }

  function initStep2() {
    $("propose-2").addEventListener("click", doProposeCharacters);
    $("confirm-2").addEventListener("click", doConfirmCharacters);
    $("prev-2").addEventListener("click", function () { showStep(1); });
    $("next-2").addEventListener("click", function () { showStep(3); });
    $("add-char-card").addEventListener("click", function () {
      if (!state.draft.characters) state.draft.characters = [];
      state.draft.characters.push({
        name: "新角色",
        personality: "",
        appearance: "",
        sample_line: "",
      });
      renderCharCards(state.draft.characters);
    });

    // ----- Character card file upload -----
    $("card-file").addEventListener("change", function () {
      var file = this.files[0];
      if (!file) return;
      var wid = state.worldId;
      if (!wid) {
        var m = location.search.match(/[?&]world_id=([^&]+)/);
        if (m) wid = decodeURIComponent(m[1]);
      }
      if (!wid) {
        setStatus("status-2", "ERROR", "还未创建世界，请先生成并确认世界。", "error");
        this.value = "";
        return;
      }
      var reader = new FileReader();
      reader.onload = function () {
        var parsed;
        try { parsed = JSON.parse(reader.result); }
        catch (e) {
          setStatus("status-2", "ERROR", "角色卡 JSON 解析失败: " + e.message, "error");
          return;
        }
        setStatus("status-2", "UPLOAD", "正在导入角色卡…", false);
        apiPost("/api/world/import_card", {
          world_id: wid,
          card: parsed,
        }).then(function (result) {
          if (!result.ok) {
            setStatus("status-2", "ERROR", result.error || "导入角色卡失败", "error");
            return;
          }
          setStatus("status-2", "OK", "角色卡导入成功", "ok");
        }).catch(function (err) {
          setStatus("status-2", "ERROR", String(err.message || err), "error");
        });
      };
      reader.readAsText(file);
    });
  }

  // ================================================================
  //  STEP 3 — RULES + GUI
  // ================================================================

  function doProposeRules() {
    if (!state.worldId) {
      setStatus("status-3", "ERROR", "请先完成世界创建。", "error");
      return;
    }
    var desc = $("rules-desc").value.trim();
    if (!desc) {
      desc = FROM_SCRATCH_PROMPTS.rules;
      setStatus("status-3", "LLM", "输入为空：正在要求 LLM 从零生成规则与 GUI。", false);
    }
    setStatus("status-3", "LLM", "正在生成规则+GUI 草案…", false);
    $("propose-3").disabled = true;
    apiPost("/api/onboarding/rules_gui/propose", {
      world_id: state.worldId,
      description: desc,
    }).then(function (result) {
      $("propose-3").disabled = false;
      if (!result.ok) {
        blockDraftStep(
          3, "LLM_REQUIRED",
          "规则与 GUI 草案生成失败：" + (result.error || "需要可用 LLM。")
        );
        return;
      }
      var rulesSource = result.meta_rules && result.meta_rules.source;
      var guiSource = result.meta_gui && result.meta_gui.source;
      if (result.degraded || rulesSource !== "llm" || guiSource !== "llm") {
        blockDraftStep(
          3, "LLM_REQUIRED",
          "服务未返回完整的 LLM 规则与 GUI 草案；本步骤已阻断。"
        );
        return;
      }
      state.draft.rules = result;
      // Fill editable fields — backend returns {draft_rules, draft_gui, ...}
      var dr = result.draft_rules || {};
      $("edit-rules").value = JSON.stringify(dr, null, 2);
      $("edit-state").value = dr.initial_state
        ? (typeof dr.initial_state === "string" ? dr.initial_state : JSON.stringify(dr.initial_state, null, 2))
        : "";
      var gui = result.draft_gui || {};
      $("edit-gui-layout").value = gui.layout_type || "";
      $("edit-gui-widgets").value = gui.widgets
        ? (typeof gui.widgets === "string" ? gui.widgets : JSON.stringify(gui.widgets, null, 2))
        : "";
      $("rules-draft").classList.remove("hidden");
      showConfirmButton(3, true);
      setStatus(
        "status-3", "DRAFT",
        draftStatusText("规则与 GUI 草案"),
        "ok"
      );
    }).catch(function (err) {
      $("propose-3").disabled = false;
      blockDraftStep(
        3, "ERROR",
        "LLM 规则与 GUI 草案请求失败：" + String(err.message || err)
      );
    });
  }

  function doConfirmRules() {
    if (!state.worldId) return;
    // Parse textarea JSON back into structured dicts for the backend
    var editedRulesStr = $("edit-rules").value.trim();
    var editedStateStr = $("edit-state").value.trim();
    var editedRulesObj;
    try { editedRulesObj = JSON.parse(editedRulesStr || "{}"); }
    catch (e) {
      setStatus("status-3", "INVALID", "规则 JSON 无法解析：" + e.message, "error");
      return;
    }
    var editedStateObj;
    try { editedStateObj = JSON.parse(editedStateStr || "{}"); }
    catch (e) {
      setStatus("status-3", "INVALID", "初始状态 JSON 无法解析：" + e.message, "error");
      return;
    }
    var editedGuiWidgetsStr = $("edit-gui-widgets").value.trim();
    var editedGuiWidgetsObj;
    try { editedGuiWidgetsObj = JSON.parse(editedGuiWidgetsStr || "[]"); }
    catch (e) {
      setStatus("status-3", "INVALID", "GUI 组件 JSON 无法解析：" + e.message, "error");
      return;
    }
    var editedRules = Array.isArray(editedRulesObj)
      ? { world_type: "user_defined", rules: editedRulesObj }
      : editedRulesObj;
    editedRules.world_type = editedRules.world_type || "user_defined";
    editedRules.rules = Array.isArray(editedRules.rules) ? editedRules.rules : [];
    editedRules.initial_state = editedStateObj;
    var editedGui = {
      layout_type: $("edit-gui-layout").value.trim(),
      widgets: editedGuiWidgetsObj,
    };

    setStatus("status-3", "SAVE", "正在确认规则+GUI…", false);
    $("confirm-3").disabled = true;
    apiPost("/api/onboarding/rules_gui/confirm", {
      world_id: state.worldId,
      edited_rules: editedRules,
      edited_gui: editedGui,
    }).then(function (result) {
      $("confirm-3").disabled = false;
      if (!result.ok) {
        setStatus("status-3", "ERROR", result.error || "confirm 失败", "error");
        return;
      }
      markStepComplete(3);
      showConfirmButton(3, false);
      showNextButton(3, true);
      setStatus("status-3", "COMPLETE", "第 3 步已完成：规则与 GUI 已确认。下一步设置玩法。", "ok");
    }).catch(function (err) {
      $("confirm-3").disabled = false;
      setStatus("status-3", "ERROR", String(err.message || err), "error");
    });
  }

  function initStep3() {
    $("propose-3").addEventListener("click", doProposeRules);
    $("confirm-3").addEventListener("click", doConfirmRules);
    $("prev-3").addEventListener("click", function () { showStep(2); });
    $("next-3").addEventListener("click", function () { showStep(4); });
  }

  // ================================================================
  //  STEP 4 — GAMEPLAY
  // ================================================================

  function doProposeGameplay() {
    if (!state.worldId) {
      setStatus("status-4", "ERROR", "请先完成世界创建。", "error");
      return;
    }
    var desc = $("gameplay-desc").value.trim();
    if (!desc) {
      desc = FROM_SCRATCH_PROMPTS.gameplay;
      setStatus("status-4", "LLM", "输入为空：正在要求 LLM 从零生成玩法。", false);
    }
    setStatus("status-4", "LLM", "正在生成玩法草案…", false);
    $("propose-4").disabled = true;
    apiPost("/api/onboarding/gameplay/propose", {
      world_id: state.worldId,
      description: desc,
    }).then(function (result) {
      $("propose-4").disabled = false;
      if (!result.ok) {
        blockDraftStep(
          4, "LLM_REQUIRED",
          "玩法草案生成失败：" + (result.error || "需要可用 LLM。")
        );
        return;
      }
      if (result.degraded || result.source !== "llm" || !result.draft) {
        blockDraftStep(
          4, "LLM_REQUIRED",
          "服务未返回有效的 LLM 玩法草案；本步骤已阻断。"
        );
        return;
      }
      state.draft.gameplay = result;
      $("edit-gameplay").value = JSON.stringify(result.draft || result, null, 2);
      $("gameplay-draft").classList.remove("hidden");
      showConfirmButton(4, true);
      setStatus("status-4", "DRAFT", draftStatusText("玩法草案"), "ok");
    }).catch(function (err) {
      $("propose-4").disabled = false;
      blockDraftStep(
        4, "ERROR",
        "LLM 玩法草案请求失败：" + String(err.message || err)
      );
    });
  }

  function doConfirmGameplay() {
    if (!state.worldId) return;
    var edited = $("edit-gameplay").value.trim();
    // Try to parse as JSON for the backend; fallback to raw string
    var editedObj;
    try { editedObj = JSON.parse(edited); }
    catch (e) {
      setStatus("status-4", "INVALID", "玩法 JSON 无法解析：" + e.message, "error");
      return;
    }

    setStatus("status-4", "SAVE", "正在确认玩法…", false);
    $("confirm-4").disabled = true;
    apiPost("/api/onboarding/gameplay/confirm", {
      world_id: state.worldId,
      edited_gameplay: editedObj,
    }).then(function (result) {
      $("confirm-4").disabled = false;
      if (!result.ok) {
        setStatus("status-4", "ERROR", result.error || "confirm 失败", "error");
        return;
      }
      markStepComplete(4);
      showConfirmButton(4, false);
      showNextButton(4, true);
      setStatus("status-4", "COMPLETE", "第 4 步已完成：玩法已确认。下一步完成创建。", "ok");
    }).catch(function (err) {
      $("confirm-4").disabled = false;
      setStatus("status-4", "ERROR", String(err.message || err), "error");
    });
  }

  function initStep4() {
    $("propose-4").addEventListener("click", doProposeGameplay);
    $("confirm-4").addEventListener("click", doConfirmGameplay);
    $("prev-4").addEventListener("click", function () { showStep(3); });
    $("next-4").addEventListener("click", function () { showStep(5); });
  }

  // ================================================================
  //  STEP 5 — FINALIZE
  // ================================================================

  function doFinalize() {
    if (!state.worldId) {
      setStatus("status-5", "ERROR", "world_id 缺失，请返回第 1 步。", "error");
      return;
    }
    setStatus("status-5", "FINAL", "正在完成世界创建…", false);
    $("finalize-btn").disabled = true;
    apiPost("/api/onboarding/finalize", { world_id: state.worldId })
      .then(function (result) {
        $("finalize-btn").disabled = false;
        if (!result.ok) {
          setStatus("status-5", "ERROR", result.error || "finalize 失败", "error");
          return;
        }
        // Show summary
        $("result-box").classList.remove("hidden");
        $("res-world-id").textContent = state.worldId;
        var ready = result.ready;
        if (ready) {
          setStatus("status-5", "READY", "世界已就绪，可以开始叙事。", "ok");
        } else {
          setStatus("status-5", "WARN", "世界创建完成，但可能未完全就绪。", false);
        }
        var link = $("enter-world");
        link.href = "/world_gui.html?world_id=" + encodeURIComponent(state.worldId);
        link.classList.remove("hidden");
        $("finalize-btn").classList.add("hidden");
        markStepComplete(5);
        setStatus("status-5", "COMPLETE", "第 5 步已完成：世界已就绪，可以进入。", "ok");
      }).catch(function (err) {
        $("finalize-btn").disabled = false;
        setStatus("status-5", "ERROR", String(err.message || err), "error");
      });
  }

  function initStep5() {
    $("finalize-btn").addEventListener("click", doFinalize);
    $("prev-5").addEventListener("click", function () { showStep(4); });
  }

  // ================================================================
  //  INIT
  // ================================================================

  function init() {
    initStep1();
    initStep2();
    initStep3();
    initStep4();
    initStep5();
    var initialStep = 1;
    var shouldPrefill = false;
    try {
      var params = new URLSearchParams(root.location.search || "");
      var initialDescription = (params.get("description") || "").trim();
      if (initialDescription) $("world-desc").value = initialDescription;
      var existingWorldId = (params.get("world_id") || "").trim();
      var requestedStep = parseInt(params.get("step") || "1", 10);
      if (existingWorldId && requestedStep >= 2 && requestedStep <= 5) {
        state.worldId = existingWorldId;
        state.description = initialDescription || "";
        for (var completedStep = 1; completedStep < requestedStep; completedStep++) {
          state.completed[completedStep] = true;
        }
        initialStep = requestedStep;
        updateWorldIdDisplay();
      }
      shouldPrefill = params.get("autoprefill") === "1";
    } catch (e) { /* URL query is optional */ }
    showStep(initialStep);
    if (shouldPrefill) {
      setTimeout(function () {
        if (initialStep === 1) doProposeWorld();
        else if (initialStep === 2) doProposeCharacters();
        else if (initialStep === 3) doProposeRules();
        else if (initialStep === 4) doProposeGameplay();
      }, 0);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  root.OnboardingWizard = {
    state: state,
    showStep: showStep,
    prefillWorld: doProposeWorld,
    prefillCharacters: doProposeCharacters,
    prefillRulesGui: doProposeRules,
    prefillGameplay: doProposeGameplay,
  };

})(typeof window !== "undefined" ? window : this);
