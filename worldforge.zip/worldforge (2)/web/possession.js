/* ============================================================
 * web/possession.js — 夺舍 posture (spec §10.6 setuid-style).
 *
 * Lists characters from /api/state, lets the player enter possession
 * (POST /api/possession/enter → allowed_actions), renders an action
 * button per allowed verb, and exits possession (POST /api/possession/exit).
 *
 * The world_id is read from ?world_id=… (set by world_gui.js on load) so
 * the possession targets the world the user just forged. Falls back to the
 * orchestrator's current world if none is given.
 * ============================================================ */

(function (root) {
  "use strict";

  function $(id) { return document.getElementById(id); }

  function status(text, cls) {
    var el = $("possess-status");
    if (!el) return;
    el.textContent = text || "";
    el.className = cls || "";
  }

  function currentWorldId() {
    if (root.__worldId) return root.__worldId;
    try {
      var q = new URLSearchParams(root.location.search);
      return q.get("world_id") || "main";
    } catch (e) { return "main"; }
  }

  function loadCharacters() {
    var sel = $("possess-char");
    if (!sel) return;
    fetch("/api/state").then(function (r) { return r.json(); }).then(function (s) {
      sel.innerHTML = "";
      var chars = (s && s.characters) || [];
      if (!chars.length) {
        var o = document.createElement("option");
        o.value = "";
        o.textContent = "（暂无角色）";
        sel.appendChild(o);
        return;
      }
      chars.forEach(function (c) {
        var opt = document.createElement("option");
        opt.value = c.character_id || c.id || c.name || "";
        opt.textContent = (c.name || c.character_id || "?") + (c.role ? " · " + c.role : "");
        sel.appendChild(opt);
      });
    }).catch(function () {
      sel.innerHTML = "<option value=''>载入失败</option>";
    });
  }

  function renderActions(allowed) {
    var wrap = $("possess-action-buttons");
    if (!wrap) return;
    wrap.innerHTML = "";
    if (!allowed || !allowed.length) {
      wrap.textContent = "（无可用动作）";
      $("possess-actions").style.display = "flex";
      return;
    }
    allowed.forEach(function (verb) {
      var b = document.createElement("button");
      b.type = "button";
      b.textContent = verb;
      b.addEventListener("click", function () {
        status("动作「" + verb + "」已发出（通过 router / tick 路由）", "active");
        if (root.Router && root.__router) {
          try { root.__router.ingest({ lane: verb, verb: verb }); } catch (e) {}
        }
      });
      wrap.appendChild(b);
    });
    $("possess-actions").style.display = "flex";
  }

  function enterPossession() {
    var sel = $("possess-char");
    var characterId = sel && sel.value;
    if (!characterId) { status("请先选择角色", "error"); return; }
    var enterBtn = $("possess-enter");
    enterBtn.disabled = true;
    status("正在夺舍…");
    fetch("/api/possession/enter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        character_id: characterId,
        player_id: "player_01",
        reason: "gui_entry",
      }),
    }).then(function (r) { return r.json(); }).then(function (body) {
      enterBtn.disabled = false;
      if (body.error) { status(body.error, "error"); return; }
      var allowed = body.allowed_actions || [];
      var name = (body.character && (body.character.name || body.character.character_id)) || characterId;
      status("已夺舍 " + name + " · 可执行 " + allowed.length + " 个动作", "active");
      $("possess-exit").disabled = false;
      renderActions(allowed);
    }).catch(function (err) {
      enterBtn.disabled = false;
      status("夺舍失败: " + (err && err.message ? err.message : err), "error");
    });
  }

  function exitPossession() {
    var sel = $("possess-char");
    var characterId = sel && sel.value;
    var exitBtn = $("possess-exit");
    exitBtn.disabled = true;
    fetch("/api/possession/exit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ character_id: characterId || "aster" }),
    }).then(function (r) { return r.json(); }).then(function (body) {
      if (body.error) { status(body.error, "error"); exitBtn.disabled = false; return; }
      status("已退出夺舍", "");
      $("possess-actions").style.display = "none";
      $("possess-enter").disabled = false;
    }).catch(function (err) {
      status("退出失败: " + (err && err.message ? err.message : err), "error");
      exitBtn.disabled = false;
    });
  }

  function init() {
    var enterBtn = $("possess-enter");
    var exitBtn = $("possess-exit");
    if (!enterBtn) return;
    enterBtn.addEventListener("click", enterPossession);
    if (exitBtn) exitBtn.addEventListener("click", exitPossession);
    loadCharacters();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  root.Possession = { init: init, loadCharacters: loadCharacters };
})(typeof window !== "undefined" ? window : this);
