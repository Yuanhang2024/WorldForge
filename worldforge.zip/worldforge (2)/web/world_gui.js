/* ============================================================
 * web/world_gui.js — driver for /api/world/gui + dynamic mount.
 *
 * Flow:
 *   1. onboarding asks the LLM for a GUI draft and the user confirms it
 *   2. this page fetches /api/world/gui?world_id=... for that persisted artifact
 *   3. GuiTheme.applyTheme(gui_theme) -> CSS vars on :root
 *   4. DynamicGUI.mount(gui_spec, {css, router}) -> skeleton into #gui-mount
 *   5. emit-side widgets fire through router.ingest(evt)
 *
 * No widgets are implemented here — all wiring goes through the router
 * (web/input/router.js) and the dynamic_gui.js event drivers, so this file
 * stays focused on persisted-artifact loading + render lifecycle.
 * ============================================================ */

(function (root) {
  "use strict";

  // ----- DOM handles (resolved lazily inside init) -----
  var formEl = null;
  var inputEl = null;
  var statusEl = null;
  var previewCardEl = null;
  var previewTextEl = null;
  var worldIdDisplayEl = null;
  var intentCountEl = null;
  var mountEl = null;

  var router = null;
  var mountedGuiRoot = null;
  var intentCount = 0;

  // ----- status helpers -----

  function setStatus(badge, text, isError) {
    if (!statusEl) return;
    statusEl.innerHTML = "";
    var b = document.createElement("span");
    b.className = "badge";
    b.textContent = badge;
    statusEl.appendChild(b);
    var span = document.createElement("span");
    span.textContent = text;
    statusEl.appendChild(span);
    statusEl.classList.toggle("error", !!isError);
    statusEl.setAttribute("data-state", isError ? "error" : String(badge || "active").toLowerCase());
  }

  function setGuiFlow(currentStep, completedThrough, message, stateName) {
    var steps = typeof document.querySelectorAll === "function"
      ? document.querySelectorAll("#gui-flow .flow-step")
      : [];
    steps.forEach(function (el) {
      var idx = parseInt(el.getAttribute("data-gui-step"), 10);
      var stepState = idx <= completedThrough ? "complete" : (
        idx === currentStep ? "current" : "pending"
      );
      el.setAttribute("data-state", stepState);
      if (stepState === "current") el.setAttribute("aria-current", "step");
      else el.removeAttribute("aria-current");
    });
    var note = document.getElementById("gui-flow-note");
    if (note) {
      note.textContent = message;
      note.setAttribute("data-state", stateName || "active");
    }
  }

  function setWorldId(worldId) {
    if (worldIdDisplayEl) {
      worldIdDisplayEl.textContent = worldId ? "world_id: " + worldId : "";
    }
  }

  function bumpIntentCount() {
    intentCount++;
    if (intentCountEl) intentCountEl.textContent = "intents: " + intentCount;
  }

  function esc(s) {
    if (s == null) return "";
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  // ============================================================
  // Director-view info panel (spec §13.6).
  //
  // Holds the last tick's model_trace in memory and polls the active world's
  // generic /api/state snapshot. The panel stays useful even when no generated
  // GUI has mounted yet and never branches on a world or kernel name.
  // ============================================================

  var INFO_DOM = {};
  var lastModelTrace = null;   // from /api/world/tick beat.model_trace
  var lastWorldState = null;
  var infoPollId = null;
  var infoRefreshBound = false;

  function resolveInfoDom() {
    INFO_DOM = {
      beat: document.getElementById("info-beat"),
      world: document.getElementById("info-world"),
      schema: document.getElementById("info-schema"),
      characters: document.getElementById("info-characters"),
      worldbook: document.getElementById("info-worldbook"),
      rules: document.getElementById("info-rules"),
      beliefs: document.getElementById("info-beliefs"),
      commitments: document.getElementById("info-commitments"),
      causal: document.getElementById("info-causal"),
      events: document.getElementById("info-events"),
      outcome: document.getElementById("info-outcome"),
      refresh: document.getElementById("info-refresh"),
    };
  }

  function fmt(v) {
    if (v == null) return "—";
    if (typeof v === "boolean") return v ? "是" : "否";
    if (typeof v === "number") {
      return Number.isInteger(v) ? String(v) : v.toFixed(3).replace(/0+$/, "").replace(/\.$/, "");
    }
    return String(v);
  }

  function setCard(el, value, isDim) {
    if (!el) return;
    el.textContent = fmt(value);
    el.classList.toggle("dim", value == null || !!isDim);
  }

  function setList(el, items, emptyText) {
    if (!el) return;
    if (!items || !items.length) {
      el.innerHTML = '<li class="kv">' + esc(emptyText || "(暂无)") + "</li>";
      return;
    }
    el.innerHTML = items.map(function (item) {
      return "<li>" + item + "</li>";
    }).join("");
  }

  function setText(el, value, emptyText) {
    if (!el) return;
    var empty = value == null || value === "";
    el.textContent = empty ? (emptyText || "(暂无)") : String(value);
    el.classList.toggle("empty", empty);
  }

  // --- belief row renderer (predicted/confidence/strategy/contradiction/
  //     accepted/model_error = belief_update_trace incl. 教条强化) ---
  function beliefRows(beliefs) {
    if (!beliefs || !beliefs.length) return [];
    return beliefs.map(function (b) {
      var cls = b.model_error ? "warn" : (b.accepted === false ? "warn" : "ok");
      var parts = [];
      parts.push('<span class="kv">actor:</span> ' + esc(b.actor_id || "?"));
      if (b.topic) parts.push('<span class="kv">topic:</span> ' + esc(b.topic));
      parts.push('<span class="kv">predicted:</span> ' + fmt(b.predicted));
      parts.push('<span class="kv">confidence:</span> ' + fmt(b.confidence));
      if (b.strategy) parts.push('<span class="kv">strategy:</span> ' + esc(b.strategy));
      if (b.contradiction != null) parts.push('<span class="kv">contradiction:</span> ' + fmt(b.contradiction));
      parts.push('<span class="' + cls + '">' + (b.accepted === false ? "REJECTED" : "accepted") + "</span>");
      if (b.model_error) parts.push('<span class="warn">[' + esc(b.model_error) + "]</span>");
      if (b.rejected_info) parts.push('<span class="kv">' + esc(b.rejected_info) + "</span>");
      return parts.join(" · ");
    });
  }

  function commitmentRows(commitments) {
    if (!commitments || !commitments.length) return [];
    return commitments.map(function (c) {
      var pct = c.progress != null ? Math.round((Number(c.progress) || 0) * 100) + "%" : "—";
      var res = "";
      var rr = c.required_resources || {};
      var rrKeys = Object.keys(rr);
      if (rrKeys.length) {
        res = ' <span class="kv">req:</span> ' + rrKeys.map(function (k) {
          return k + "=" + fmt(rr[k]);
        }).join(",");
      }
      return '<span class="kv">goal:</span> ' + esc(c.goal || c.commitment_id || "?") +
        ' · <span class="kv">actor:</span> ' + esc(c.actor_id || "?") +
        ' · <span class="kv">status:</span> ' + esc(c.status || "?") +
        ' · <span class="kv">progress:</span> ' + pct +
        (c.decision_type ? ' · <span class="kv">' + esc(c.decision_type) + "</span>" : "") +
        res;
    });
  }

  function renderInfoPanel() {
    var mt = lastModelTrace || {};
    var state = lastWorldState || {};
    var meta = state._meta || {};
    var characters = Array.isArray(state.characters) ? state.characters : [];
    var worldbook = Array.isArray(state.worldbook) ? state.worldbook : [];
    var rules = Array.isArray(state.rules)
      ? state.rules
      : (((state.world_kernel_spec || {}).rules) || []);

    setCard(INFO_DOM.beat, mt.world_builder_beat);
    setCard(INFO_DOM.world, state.world_id || meta.world_id || getWorldId());
    setCard(INFO_DOM.schema, state.schema_version != null ? state.schema_version : meta.schema_version);
    setCard(INFO_DOM.characters, characters.length);
    setCard(INFO_DOM.worldbook, worldbook.length);
    setCard(INFO_DOM.rules, rules.length);

    // beliefs — model_trace.agent_mind.agents (flatten, mirrors _belief_rows)
    var beliefs = [];
    var am = mt.agent_mind || {};
    var agents = am.agents || {};
    Object.keys(agents).forEach(function (aid) {
      var rec = agents[aid] || {};
      var trace = rec.belief_trace || {};
      var posterior = trace.posterior || {};
      var prior = trace.prior || {};
      beliefs.push({
        actor_id: aid,
        topic: trace.topic || "",
        predicted: rec.belief != null ? rec.belief : posterior.predicted,
        confidence: posterior.confidence != null ? posterior.confidence : prior.confidence,
        strategy: trace.strategy,
        contradiction: trace.contradiction,
        accepted: trace.accepted,
        rejected_info: trace.rejected_info,
        model_error: trace.error_source,
      });
    });
    setList(INFO_DOM.beliefs, beliefRows(beliefs), "(暂无 AgentMind 信念数据)");

    // commitments — model_trace.commitments.resolutions (flatten)
    var commits = [];
    var cm = mt.commitments || {};
    (cm.resolutions || []).forEach(function (res) {
      var c = res.commitment || res;
      commits.push({
        commitment_id: c.commitment_id,
        actor_id: c.actor_id,
        goal: c.goal,
        status: c.status,
        progress: c.progress,
        decision_type: c.decision_type,
        required_resources: c.required_resources || {},
        allocated_resources: c.allocated_resources || {},
        resolution_status: res.status,
      });
    });
    setList(INFO_DOM.commitments, commitmentRows(commits), "(暂无决策承诺)");

    // causal narrative — agent_mind.causal_narrative, fallback to agent_causal_trace
    var cn = (am.causal_narrative) || null;
    var causalText = "";
    if (cn && cn.narrative) causalText = cn.narrative;
    else if (mt.agent_causal_trace) {
      var act = mt.agent_causal_trace;
      causalText = act.narrative || act.summary || "";
    }
    setText(INFO_DOM.causal, causalText, "(暂无因果叙事)");

    // event log — current model trace plus any generic persisted event list
    var events = [];
    if (Array.isArray(mt.kernel_event_log)) events = events.concat(mt.kernel_event_log);
    if (Array.isArray(state.event_log)) events = events.concat(state.event_log);
    setList(INFO_DOM.events, (events || []).map(function (e) { return esc(String(e)); }), "(暂无事件)");

    // outcome chapter — any world update whose source ends in outcome_chapter
    var outcomeText = null;
    var kind = mt.kernel_verdict;
    (mt.world_updates || []).forEach(function (wu) {
      if (wu && /(?:^|_)outcome_chapter$/.test(String(wu.source || ""))) {
        outcomeText = wu.content;
        if (!kind && wu.title) {
          var parts = String(wu.title).split("·");
          if (parts.length) kind = parts[parts.length - 1];
        }
      }
    });
    var outcomeFull = outcomeText;
    if (kind && outcomeText) outcomeFull = "[" + kind + "] " + outcomeText;
    else if (kind && !outcomeText) outcomeFull = "[" + kind + "]";
    setText(INFO_DOM.outcome, outcomeFull, "(暂无结局章)");
  }

  function fetchWorldState() {
    var url = "/api/state";
    var worldId = getWorldId();
    if (worldId) url += "?world_id=" + encodeURIComponent(worldId);
    return fetch(url, { headers: { "Accept": "application/json" } })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (d) lastWorldState = d;
        renderInfoPanel();
      })
      .catch(function () { /* offline — leave last known state */ });
  }

  function refreshInfoPanel() {
    if (INFO_DOM.refresh) INFO_DOM.refresh.disabled = true;
    fetchWorldState().then(function () {
      if (INFO_DOM.refresh) INFO_DOM.refresh.disabled = false;
    });
  }

  function startInfoPanelPolling() {
    resolveInfoDom();
    if (INFO_DOM.refresh && !infoRefreshBound) {
      INFO_DOM.refresh.addEventListener("click", refreshInfoPanel);
      infoRefreshBound = true;
    }
    refreshInfoPanel();
    if (infoPollId) clearInterval(infoPollId);
    infoPollId = setInterval(refreshInfoPanel, 3000);
    if (infoPollId && typeof infoPollId.unref === "function") infoPollId.unref();
  }

  function stopInfoPanelPolling() {
    if (infoPollId) {
      clearInterval(infoPollId);
      infoPollId = null;
    }
  }

  // Called by the dynamic_gui state bus (or tests) to push a fresh tick's
  // model_trace so the panel reflects the latest committed beat without
  // waiting for the next poll.
  function pushTickModelTrace(beat) {
    if (!beat) return;
    lastModelTrace = beat.model_trace || lastModelTrace;
    renderInfoPanel();
  }

  // ----- render: apply theme + dynamic_gui.mount -----

  function postJson(url, body) {
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(body),
    }).then(function (resp) {
      if (!resp.ok) {
        return resp.text().then(function (text) {
          throw new Error("HTTP " + resp.status + ": " + text.slice(0, 200));
        });
      }
      return resp.json();
    });
  }

  function sendWorldIntent(intent) {
    if (!intent || !intent.kind) return Promise.reject(new Error("invalid intent"));
    var payload = intent.payload || {};
    var worldId = intent.world_id || getWorldId() || "main";
    var action = payload.action || "";

    // COMMIT is already closed by DynamicGUI's state bus so the button can
    // remain disabled until the same request refreshes its subscribers.
    if (payload.handled_by_state_bus) {
      return Promise.resolve({ ok: true, delegated: "state_bus" });
    }

    if (action === "world/tick" || intent.kind === "decision_vector") {
      return postJson("/api/world/tick", {
        world_id: worldId,
        session_id: "world_gui:" + worldId,
        mode: "generic",
        decision: payload.decision || payload,
      }).then(function (data) {
        if (data && data.beat) pushTickModelTrace(data.beat);
        return data;
      });
    }

    if (action === "interact" || intent.kind === "playfield_action") {
      return postJson("/api/interact", {
        world_id: worldId,
        actor_id: payload.actor_id || payload.speaker_hint || "player_01",
        verb: payload.verb || "interact",
        object_id: payload.object_id || "scene",
        actor_strength: payload.actor_strength || 1,
      });
    }

    if (action === "game/step") {
      return postJson("/api/game/step", {
        world_id: worldId,
        session_id: "world_gui:" + worldId,
        command: payload.command || payload.verb || "idle",
      });
    }

    // Utterances, intent hints, and explicit dispatch actions enter the
    // director through the natural-language dispatch contract.
    var message = payload.transcript || payload.text || payload.message ||
      payload.partial || payload.verb || intent.kind;
    return postJson("/api/dispatch", {
      world_id: worldId,
      session_id: "world_gui:" + worldId,
      message: String(message),
    });
  }

  function renderDynamicGUI(payload) {
    var spec = payload.gui_spec;
    var theme = payload.gui_theme;
    var css = payload.css || "";

    if (!spec || !spec.widgets) {
      throw new Error("renderDynamicGUI: gui_spec.widgets missing");
    }
    if (!theme) {
      throw new Error("renderDynamicGUI: gui_theme missing");
    }

    // 1) apply CSS vars from the world's theme onto :root
    if (root.GuiTheme && typeof root.GuiTheme.applyTheme === "function") {
      root.GuiTheme.applyTheme(theme, document.documentElement);
    } else {
      console.warn("GuiTheme.applyTheme not available; CSS vars left at defaults");
    }

    // 2) clear previous mount + inject the spec's layout CSS
    if (mountedGuiRoot && typeof mountedGuiRoot.stop === "function") {
      mountedGuiRoot.stop();
    }
    mountedGuiRoot = null;
    while (mountEl && mountEl.firstChild) mountEl.removeChild(mountEl.firstChild);
    if (css) {
      var style = document.createElement("style");
      style.setAttribute("data-gui-spec", spec.gui_spec_id || "");
      style.textContent = css;
      document.head.appendChild(style);
    }

    // 3) mount the widget skeleton through the existing builder.
    //    We feed the spec directly so DynamicGUI.mount() handles every
    //    widget type via its known handler table.
    if (!root.DynamicGUI || typeof root.DynamicGUI.mount !== "function") {
      throw new Error("DynamicGUI.mount not available; dynamic_gui.js failed to load");
    }

    var routerOpts = {
      // Wrap ingest so we can also bump the local intent counter without
      // monkey-patching the router. Every widget emit ends up here.
      ingest: function (evt) {
        bumpIntentCount();
        if (router && typeof router.ingest === "function") {
          router.ingest(evt);
        }
      },
    };

    mountedGuiRoot = root.DynamicGUI.mount(spec, {
      css: css,
      router: routerOpts,
      mountPoint: mountEl,
      onTick: pushTickModelTrace,
    });

    return spec;
  }

  // ----- persisted GUI loading -----

  function applyWorldGuiPayload(payload) {
    if (!payload.ok) throw new Error(payload.error || "server returned ok=false");

    var source = String(payload.gui_source || "").toLowerCase();
    var provenance = payload.gui_spec && payload.gui_spec.provenance;
    var proposedBy = String(
      provenance && provenance.proposed_by || ""
    ).toLowerCase();
    if (source !== "persisted" || proposedBy !== "llm") {
      var requiredError = new Error(
        "CONFIRMED_GUI_REQUIRED: persisted LLM GUI artifact was not returned"
      );
      requiredError.code = "CONFIRMED_GUI_REQUIRED";
      throw requiredError;
    }

    root.__worldId = payload.world_id || (payload.gui_spec && payload.gui_spec.world_id) || "";
    if (router && typeof router.setWorldId === "function") {
      router.setWorldId(root.__worldId);
    }

    var spec = renderDynamicGUI(payload);
    var widgetNames = (spec.widgets || []).map(function (w) { return w.name; }).join(", ");
    setStatus(
      "COMPLETE",
      "已载入确认过的 GUI · layout=" + spec.layout_type + " · " +
        (spec.widgets || []).length + " widgets (" + widgetNames + ")",
      false
    );
    setGuiFlow(3, 3, "完成态：已载入并启用创建向导中确认过的世界 GUI。", "complete");
    setWorldId(payload.world_id || "");

    if (payload.preview && previewCardEl && previewTextEl) {
      previewCardEl.style.display = "block";
      previewTextEl.textContent = payload.preview.summary_text || "(no preview)";
    }
    return payload;
  }

  function openGuiWizard(description) {
    var wid = getWorldId();
    var url = "/onboarding.html?autoprefill=1&description=" +
      encodeURIComponent(String(description || "").trim());
    if (wid) {
      url += "&world_id=" + encodeURIComponent(wid) + "&step=3";
      setStatus("REDIRECT", "正在返回第 3 步：由 LLM 生成规则与 GUI 草案，编辑后确认。", false);
    } else {
      setStatus("REDIRECT", "尚无 world_id；正在从创建向导第 1 步开始。", false);
    }
    root.location.href = url;
    return url;
  }

  function loadWorldGUI(worldId) {
    if (!worldId) return Promise.reject(new Error("world_id is required"));
    setStatus("LOADING", "正在载入已生成的世界 GUI…", false);
    var url = "/api/world/gui?world_id=" + encodeURIComponent(worldId);
    return fetch(url, { method: "GET", headers: { "Accept": "application/json" } })
      .then(function (resp) {
        if (!resp.ok) {
          return resp.text().then(function (t) {
            var loadError = new Error(
              "HTTP " + resp.status + ": " + t.slice(0, 200)
            );
            loadError.status = resp.status;
            throw loadError;
          });
        }
        return resp.json();
      })
      .then(applyWorldGuiPayload)
      .catch(function (err) {
        console.error("loadWorldGUI failed:", err);
        var missing = err && (
          err.status === 404 || err.code === "CONFIRMED_GUI_REQUIRED"
        );
        setStatus(
          missing ? "CONFIRMED_GUI_REQUIRED" : "ERROR",
          missing
            ? "该 world_id 没有已确认 GUI；未挂载任何 fallback。请返回创建向导完成第 3 步。"
            : String(err && err.message ? err.message : err),
          true
        );
        setGuiFlow(
          1, 0,
          "载入失败：返回创建向导，让 LLM 生成并由你确认规则与 GUI。",
          "error"
        );
        throw err;
      });
  }

  // ============================================================
  // World management: save / load / list / reset
  // Maps to backend /api/world/{save,load,list,reset}.
  // ============================================================

  function getWorldId() {
    return root.__worldId || "";
  }

  function worldMgmtStatus(msg, isError) {
    var el = document.getElementById("world-mgmt-status");
    if (!el) return;
    el.textContent = msg;
    el.className = isError ? "error" : (msg ? "active" : "");
  }

  function worldSave() {
    var wid = getWorldId();
    if (!wid) { worldMgmtStatus("无 world_id", true); return; }
    var btn = document.getElementById("world-save");
    if (btn) btn.disabled = true;
    worldMgmtStatus("存档中…");
    fetch("/api/world/save", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ world_id: wid }),
    })
      .then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        if (data.ok) {
          worldMgmtStatus("已保存到 " + (data.zip_path || "服务器"));
        } else {
          worldMgmtStatus("存档失败: " + (data.error || "unknown"), true);
        }
      })
      .catch(function (err) {
        worldMgmtStatus("存档失败: " + (err.message || err), true);
      })
      .then(function () {
        if (btn) btn.disabled = false;
      });
  }

  function worldLoad(file) {
    if (!file) { worldMgmtStatus("未选择文件", true); return; }
    var btn = document.getElementById("world-load-btn");
    if (btn) btn.disabled = true;
    worldMgmtStatus("读档中…");
    var fd = new FormData();
    fd.append("file", file);
    return fetch("/api/world/load", {
      method: "POST",
      body: fd,
    })
      .then(function (r) {
        if (!r.ok) return r.text().then(function (t) { throw new Error("HTTP " + r.status + ": " + t.slice(0, 200)); });
        return r.json();
      })
      .then(function (data) {
        if (data && data.world_id) {
          root.__worldId = data.world_id;
          setWorldId(data.world_id);
        }
        worldMgmtStatus("读档成功，刷新页面…");
        setTimeout(function () { root.location.reload(); }, 800);
      })
      .catch(function (err) {
        worldMgmtStatus("读档失败: " + (err.message || err), true);
      })
      .then(function () {
        if (btn) btn.disabled = false;
      });
  }

  function worldList() {
    var btn = document.getElementById("world-list");
    if (btn) btn.disabled = true;
    worldMgmtStatus("获取列表…");
    fetch("/api/world/list", { method: "GET", headers: { "Accept": "application/json" } })
      .then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        var worlds = (data && data.saves) || (Array.isArray(data) ? data : []);
        if (!worlds.length) {
          worldMgmtStatus("无存档世界", true);
          return;
        }
        var lines = worlds.map(function (w) {
          var id = (typeof w === "string") ? w : (w.world_id || w.id || JSON.stringify(w));
          return "  - " + id;
        });
        worldMgmtStatus("世界列表 (" + worlds.length + ")");
        alert("存档世界列表:\n" + lines.join("\n"));
      })
      .catch(function (err) {
        worldMgmtStatus("列表失败: " + (err.message || err), true);
      })
      .then(function () {
        if (btn) btn.disabled = false;
      });
  }

  function worldReset() {
    var wid = getWorldId();
    if (!wid) { worldMgmtStatus("无 world_id", true); return; }
    if (!confirm("确认重置世界 " + wid + "？此操作不可撤销。")) return;
    var btn = document.getElementById("world-reset");
    if (btn) btn.disabled = true;
    worldMgmtStatus("重置中…");
    fetch("/api/world/reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ world_id: wid }),
    })
      .then(function (r) {
        if (!r.ok) return r.text().then(function (t) { throw new Error("HTTP " + r.status + ": " + t.slice(0, 200)); });
        return r.json();
      })
      .then(function () {
        worldMgmtStatus("已重置，刷新页面…");
        setTimeout(function () { root.location.reload(); }, 800);
      })
      .catch(function (err) {
        worldMgmtStatus("重置失败: " + (err.message || err), true);
      })
      .then(function () {
        if (btn) btn.disabled = false;
      });
  }

  // ============================================================
  // Generate tools. Rules and gameplay enter the editable onboarding stages:
  // model output is only a draft and never bypasses user confirmation.
  // Cognitive models retain their dedicated generation endpoint.
  // ============================================================

  function genToolsStatus(msg, isError) {
    var el = document.getElementById("gen-tools-status");
    if (!el) return;
    el.textContent = msg;
    el.className = isError ? "error" : (msg ? "active" : "");
  }

  function getDescriptionFallback() {
    // Empty is meaningful: the target LLM is asked to generate from zero.
    var inp = document.getElementById("description");
    return (inp && inp.value && inp.value.trim()) ? inp.value.trim() : "";
  }

  function openEditableGenerator(step) {
    var wid = getWorldId();
    if (!wid) {
      genToolsStatus("需要 world_id：先完成 GUI 创建或从高级向导创建世界。", true);
      return;
    }
    var url = "/onboarding.html?world_id=" + encodeURIComponent(wid) +
      "&step=" + encodeURIComponent(String(step)) +
      "&autoprefill=1&description=" +
      encodeURIComponent(getDescriptionFallback());
    genToolsStatus("正在打开可编辑草案；确认前不会写入。");
    root.location.href = url;
  }

  function genRules() {
    openEditableGenerator(3);
  }

  function genGameplay() {
    openEditableGenerator(4);
  }

  function genCogModel() {
    var btn = document.getElementById("gen-cogmodel");
    if (btn) btn.disabled = true;
    genToolsStatus("生成认知模型中…");
    var body = {
      world_description: getDescriptionFallback() ||
        "请从零生成与当前世界一致的认知与误判模型。",
      agent_role: "default",
      use_llm: true,
    };
    fetch("/api/cognitive_model/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
      .then(function (r) {
        if (!r.ok) return r.text().then(function (t) { throw new Error("HTTP " + r.status + ": " + t.slice(0, 200)); });
        return r.json();
      })
      .then(function (data) {
        var fmCount = (data && data.failure_modes) ? data.failure_modes.length : (data && data.n_failure_modes != null ? data.n_failure_modes : "?");
        genToolsStatus("failure_modes: " + fmCount);
      })
      .catch(function (err) {
        genToolsStatus("生成认知模型失败: " + (err.message || err), true);
      })
      .then(function () {
        if (btn) btn.disabled = false;
      });
  }

  function init() {
    formEl = document.getElementById("gui-wizard-form");
    inputEl = document.getElementById("description");
    statusEl = document.getElementById("status-line");
    previewCardEl = document.getElementById("preview-card");
    previewTextEl = document.getElementById("preview-text");
    worldIdDisplayEl = document.getElementById("world-id-display");
    intentCountEl = document.getElementById("intent-count");
    mountEl = document.getElementById("gui-mount");

    if (!formEl || !inputEl || !mountEl) {
      console.error("world_gui.js: required DOM nodes missing");
      return;
    }

    // Read ?world_id=… so deep links from index.html target the forged world.
    try {
      var q = new URLSearchParams(root.location.search);
      var wid = q.get("world_id");
      if (wid) {
        root.__worldId = wid;
        setWorldId(wid);
        loadWorldGUI(wid).catch(function () { /* error already shown */ });
      }
    } catch (e) { /* ignore */ }
    if (!getWorldId()) {
      setStatus(
        "CONFIRMED_GUI_REQUIRED",
        "本页只加载已确认 GUI。请返回创建向导，由 LLM 生成并由你确认。",
        true
      );
      setGuiFlow(1, 0, "当前：没有 world_id，请从创建向导第 1 步开始。", "blocked");
    }

    // Build the generic DeviceEvent → WorldIntent router. The host callback
    // selects the backend endpoint from the closed intent/action vocabulary.
    var routerApi = root.inputRouter || root.Router;
    if (routerApi && typeof routerApi.createRouter === "function") {
      router = routerApi.createRouter({
        worldId: getWorldId(),
        sendIntent: function (intent) {
          sendWorldIntent(intent).catch(function (err) {
            console.error("GUI intent dispatch failed:", err);
            setStatus("INTENT ERROR", String(err && err.message ? err.message : err), true);
          });
        },
      });
      root.__router = router;
    }

    formEl.addEventListener("submit", function (evt) {
      evt.preventDefault();
      openGuiWizard(inputEl.value);
    });

    // Start the read-only director-view info panel. It polls the active
    // world's generic state; belief/commitment/causal/outcome slots fill
    // once a tick lands.
    startInfoPanelPolling();
    if (root.addEventListener) {
      root.addEventListener("pagehide", function () {
        stopInfoPanelPolling();
        if (mountedGuiRoot && typeof mountedGuiRoot.stop === "function") {
          mountedGuiRoot.stop();
        }
      });
    }

    // Optional: pressing Enter on the input triggers submit (form default
    // handles this already, but we keep the explicit handler so the API
    // call path is the only entrypoint.)

    // Wire world management buttons.
    var saveBtn = document.getElementById("world-save");
    if (saveBtn) saveBtn.addEventListener("click", worldSave);

    var loadBtn = document.getElementById("world-load-btn");
    var loadInput = document.getElementById("world-load-input");
    if (loadBtn && loadInput) {
      loadBtn.addEventListener("click", function () { loadInput.click(); });
      loadInput.addEventListener("change", function () {
        if (loadInput.files && loadInput.files[0]) {
          worldLoad(loadInput.files[0]);
        }
        loadInput.value = "";
      });
    }

    var listBtn = document.getElementById("world-list");
    if (listBtn) listBtn.addEventListener("click", worldList);

    var resetBtn = document.getElementById("world-reset");
    if (resetBtn) resetBtn.addEventListener("click", worldReset);

    // Wire generate tools buttons.
    var genRulesBtn = document.getElementById("gen-rules");
    if (genRulesBtn) genRulesBtn.addEventListener("click", genRules);
    var genGameplayBtn = document.getElementById("gen-gameplay");
    if (genGameplayBtn) genGameplayBtn.addEventListener("click", genGameplay);
    var genCogModelBtn = document.getElementById("gen-cogmodel");
    if (genCogModelBtn) genCogModelBtn.addEventListener("click", genCogModel);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // Exposed for tests / programmatic use.
  var api = {
    openGuiWizard: openGuiWizard,
    loadWorldGUI: loadWorldGUI,
    renderDynamicGUI: renderDynamicGUI,
    setStatus: setStatus,
    // Director-view info panel (spec §13.6).
    renderInfoPanel: renderInfoPanel,
    pushTickModelTrace: pushTickModelTrace,
    setLastWorldState: function (s) { lastWorldState = s; renderInfoPanel(); },
    setLastModelTrace: function (mt) { lastModelTrace = mt; renderInfoPanel(); },
    startInfoPanelPolling: startInfoPanelPolling,
    stopInfoPanelPolling: stopInfoPanelPolling,
    sendWorldIntent: sendWorldIntent,
    _resolveInfoDom: resolveInfoDom,
    _beliefRows: beliefRows,
    _commitmentRows: commitmentRows,
    // World management: save / load / list / reset (spec §13.7).
    getWorldId: getWorldId,
    worldMgmtStatus: worldMgmtStatus,
    worldSave: worldSave,
    worldLoad: worldLoad,
    worldList: worldList,
    worldReset: worldReset,
    // Generate tools: rules / gameplay / cognitive-model.
    genToolsStatus: genToolsStatus,
    genRules: genRules,
    genGameplay: genGameplay,
    genCogModel: genCogModel,
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
  root.WorldGUI = api;
})(typeof window !== "undefined" ? window : this);
