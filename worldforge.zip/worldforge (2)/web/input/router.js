// router.js — DeviceEvent → WorldIntent fan-out.
// One DeviceEvent may produce 1..N WorldIntent; each is dispatched by lane
// (L0 preview / L1 utterance or committed action / L2 deep).
//
// L0 intents are local previews. L1/L2 intents are passed to sendIntent(),
// which the host wires to the backend.
//
// Usage:
//   import { createRouter } from "./router.js";
//   const router = createRouter({
//     sendIntent: (intent) => fetch("/api/dispatch", { method: "POST", body: JSON.stringify(intent) }),
//     worldId: "world_042",
//   });
//   devices.onDeviceEvent((evt) => router.ingest(evt));
//
// The router is pure: it does not acquire devices or fetch; the host owns
// side effects and receives intents via sendIntent().

(function (root) {
  "use strict";

  function uuid() {
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
    return "int-" + Math.random().toString(36).slice(2) + "-" + Date.now().toString(36);
  }

  // Build a WorldIntent from a DeviceEvent.
  // `extra` carries kind-specific payload bits. We carry the source event_id
  // and device timestamp so end-to-end latency (device ts → intent dispatch)
  // can be measured downstream.
  function makeIntent(evt, lane, kind, extra) {
    extra = extra || {};
    return Object.assign(
      {
        intent_id: uuid(),
        source_event: evt.event_id,
        kind: kind,
        lane: lane,
        latency_budget_ms: extra.latency_budget_ms || (lane === "L0" ? 20 : lane === "L1" ? 200 : 1000),
        needs_llm: extra.needs_llm || false,
        commitment_layer: extra.commitment_layer || (lane === "L0" ? "overlay" : lane === "L1" ? "base" : "world_state"),
        invalidation_radius: extra.invalidation_radius || (lane === "L0" ? "overlay" : lane === "L1" ? "next_beat" : "none"),
        payload: extra.payload || {},
        world_id: extra.world_id || null,
        device_ts_ms: evt.ts_monotonic_ms,
        device: evt.device,
        channel: evt.channel,
        confidence: evt.confidence,
      },
    );
  }

  // ---- default mapping table ----
  // Returns an array of partial-intent descriptors; the router fills in the
  // envelope (intent_id, lane, payload) and dispatches by lane.
  //
  // Each entry: (evt) => Array<{kind, lane, payload, needs_llm?, commitment_layer?, invalidation_radius?}> | null
  const GUI_INTENT_KINDS = {
    utterance: 1, decision_vector: 1, playfield_action: 1,
  };
  const DEFAULT_FANOUT = [
    // Dynamic GUI controls carry their closed-vocabulary bind in the raw
    // event.  Preview-only decision vectors remain L0; committed decisions
    // and all user-facing actions are forwarded to the host for API routing.
    function guiBinding(evt) {
      if (evt.device !== "gui" || !evt.raw || !evt.raw.intent_kind) return null;
      const kind = evt.raw.intent_kind;
      if (!GUI_INTENT_KINDS[kind]) return null;
      const isPreview = kind === "decision_vector" &&
        !evt.raw.committed && !evt.raw.action;
      return [{
        kind: kind,
        lane: isPreview ? "L0" : "L1",
        payload: Object.assign({}, evt.raw),
        needs_llm: kind === "utterance",
        commitment_layer: isPreview ? "overlay" : "world_state",
        invalidation_radius: isPreview ? "none" : "next_beat",
      }];
    },
    // gamepad button press → L1 playfield_action (verb direct to host).
    // We map common buttons to verbs; unmapped buttons become a generic
    // playfield_action with the button name in the payload so the host can
    // gate it further.
    function gamepadButton(evt) {
      if (evt.device !== "gamepad" || evt.channel !== "button" || !evt.raw.pressed) return null;
      const name = evt.raw.name;
      const map = {
        A: "play_card",
        B: "stop",
        X: "take",
        Y: "point",
        RB: "deal",
        LB: "break",
        up: "move_forward",
        down: "move_back",
        left: "move_left",
        right: "move_right",
      };
      const verb = map[name] || "play_card";
      return [
        {
          kind: "playfield_action",
          lane: "L1",
          payload: { verb: verb, object_id: "scene", actor_strength: 1 },
          latency_budget_ms: 10,
          commitment_layer: "scene",
          invalidation_radius: "next_beat",
        },
      ];
    },
    // gamepad left-stick axis → L0 decision_vector preview (axes 0,1).
    function gamepadAxis(evt) {
      if (evt.device !== "gamepad" || evt.channel !== "axis") return null;
      const axis = evt.raw.axis;
      const value = evt.raw.value;
      if (axis !== 0 && axis !== 1) return null; // only left stick
      return [
        {
          kind: "decision_vector",
          lane: "L0",
          payload: { axis: axis, value: value, committed: false },
          latency_budget_ms: 10,
          commitment_layer: "world_state",
          invalidation_radius: "none",
        },
      ];
    },
    // keyboard text (synthesized via devices.synthesize("text", {text})) →
    // L1 utterance, needs_llm=true.
    function keyboardText(evt) {
      if (evt.device !== "keyboard" || evt.channel !== "text") return null;
      return [
        {
          kind: "utterance",
          lane: "L1",
          payload: { transcript: evt.raw.text || "", speaker_hint: "player_01" },
          latency_budget_ms: 1000,
          needs_llm: true,
          commitment_layer: "base",
          invalidation_radius: "next_beat",
        },
      ];
    },
  ];

  function createRouter(opts) {
    opts = opts || {};
    const sendIntent = opts.sendIntent || function (intent) {};
    let worldId = opts.worldId || null;
    const fanout = opts.fanout || DEFAULT_FANOUT;
    const stats = { ingested: 0, by_lane: { L0: 0, L1: 0, L2: 0 }, dropped: 0 };

    function ingest(evt) {
      if (!evt || !evt.device || !evt.channel) return [];
      stats.ingested++;
      const out = [];
      for (const fn of fanout) {
        let partials = null;
        try {
          partials = fn(evt);
        } catch (e) {
          if (typeof console !== "undefined") console.error("router fan-out threw:", e);
          continue;
        }
        if (!partials) continue;
        for (const p of partials) {
          const intent = makeIntent(evt, p.lane || "L0", p.kind, {
            payload: p.payload,
            needs_llm: p.needs_llm,
            commitment_layer: p.commitment_layer,
            invalidation_radius: p.invalidation_radius,
            latency_budget_ms: p.latency_budget_ms,
            world_id: worldId,
          });
          out.push(intent);
          stats.by_lane[intent.lane] = (stats.by_lane[intent.lane] || 0) + 1;
          dispatch(intent);
        }
      }
      if (out.length === 0) stats.dropped++;
      return out;
    }

    function dispatch(intent) {
      if (intent.lane === "L0") {
        return;
      }
      // L1 / L2 go through sendIntent (host wires to backend).
      try {
        sendIntent(intent);
      } catch (e) {
        if (typeof console !== "undefined") console.error("sendIntent threw:", e);
      }
    }

    return {
      ingest: ingest,
      stats: stats,
      setWorldId: function (nextWorldId) { worldId = nextWorldId || null; },
      // exposed for tests / advanced wiring
      _fanout: fanout,
    };
  }

  const api = {
    createRouter: createRouter,
    makeIntent: makeIntent,
    DEFAULT_FANOUT: DEFAULT_FANOUT,
    GUI_INTENT_KINDS: GUI_INTENT_KINDS,
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  } else {
    root.inputRouter = api;
    // Compatibility alias used by the generic world GUI and possession
    // adapter.  New code should prefer inputRouter.
    root.Router = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
