// devices.js — generic keyboard/gamepad adapters → DeviceEvent.
//
// Each adapter normalizes its raw device signal into the unified DeviceEvent
// shape and hands it to a sink callback. The router (router.js) is the only
// consumer of these events. Adapters do NOT touch rendering or backend.
//
// Generic input coverage:
//   - gamepad: navigator.getGamepads() polling loop → button/axis channels.
//   - keyboard: deterministic synthesized text events for the shared router.
//
// All events carry ts_monotonic_ms from performance.now() so the router can
// tag intents with the original device timestamp for end-to-end latency
// accounting (§6.5 / §14 experiment A).
//
// Usage:
//   import { startGamepad, synthesize, onDeviceEvent } from "./devices.js";
//   onDeviceEvent((evt) => router.ingest(evt));
//   const gamepadStop = await startGamepad();  // returns a teardown fn
//
// No imports of other modules: the file stays self-contained and
// Node-test-friendly, while browser-only gamepad access is feature-detected.

(function (root) {
  "use strict";

  // ---- uuid (browser crypto.randomUUID or fallback) ----
  function uuid() {
    if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
    return "dev-" + Math.random().toString(36).slice(2) + "-" + Date.now().toString(36);
  }

  // monotonic ms clock (browser perfNow or Date.now fallback)
  function monoMs() {
    return typeof performance !== "undefined" && performance.now
      ? performance.now()
      : Date.now();
  }

  function makeEvent(device, channel, raw, confidence) {
    return {
      event_id: uuid(),
      device: device,
      channel: channel,
      ts_monotonic_ms: monoMs(),
      raw: raw,
      confidence: typeof confidence === "number" ? confidence : 1.0,
    };
  }

  // ---- sink registry ----
  const sinks = [];
  function onDeviceEvent(fn) {
    sinks.push(fn);
    return () => {
      const i = sinks.indexOf(fn);
      if (i >= 0) sinks.splice(i, 1);
    };
  }
  function emit(evt) {
    for (const s of sinks) {
      try {
        s(evt);
      } catch (e) {
        // a broken sink must not stop others from receiving
        if (typeof console !== "undefined") console.error("device sink threw:", e);
      }
    }
  }

  // ---- gamepad: navigator.getGamepads() polling ----
  //
  // Polls at GAMEPAD_POLL_MS and emits events only on edges (button pressed
    // / released) or when an axis crosses DEADZONE. The router turns each
    // button event into a playfield_action verb and axis events into a
    // decision_vector preview.
  const GAMEPAD_POLL_MS = 33; // ~30 Hz
  const GAMEPAD_AXIS_DEADZONE = 0.2;

  function startGamepad(opts) {
    opts = opts || {};
    if (typeof navigator === "undefined" || typeof navigator.getGamepads !== "function") {
      return () => {};
    }
    // Standard mapping (most modern browsers / controllers): button indices
    // 0=A,1=B,2=X,3=Y,4=LB,5=RB,6=LT,7=RT,8=Back,9=Start,10=LStick,11=RStick,
    // 12=Up,13=Down,14=Left,15=Right. We forward the index verbatim and let
    // the router map verbs.
    const buttonNames = ["A","B","X","Y","LB","RB","LT","RT","back","start","ls","rs","up","down","left","right"];
    const prev = { buttons: [], axes: [] };
    let stopped = false;
    let timer = null;

    function tick() {
      if (stopped) return;
      const pads = navigator.getGamepads ? navigator.getGamepads() : [];
      for (let i = 0; i < pads.length; i++) {
        const gp = pads[i];
        if (!gp) continue;
        // buttons
        for (let b = 0; b < gp.buttons.length; b++) {
          const v = gp.buttons[b] && typeof gp.buttons[b].value === "number" ? gp.buttons[b].value : 0;
          const pressed = (gp.buttons[b] && gp.buttons[b].pressed) || v > 0.5;
          const wasPressed = !!(prev.buttons[i] && prev.buttons[i][b]);
          if (pressed !== wasPressed) {
            emit(
              makeEvent(
                "gamepad",
                "button",
                { index: i, button: b, name: buttonNames[b] || ("btn_" + b), value: v, pressed: pressed },
                pressed ? 0.95 : 0.5,
              ),
            );
          }
        }
        if (!prev.buttons[i]) prev.buttons[i] = [];
        for (let b = 0; b < gp.buttons.length; b++) {
          const v = (gp.buttons[b] && typeof gp.buttons[b].value === "number") ? gp.buttons[b].value : 0;
          prev.buttons[i][b] = v > 0.5;
        }
        // axes — emit only when crossing the deadzone (don't spam while held)
        if (!prev.axes[i]) prev.axes[i] = [];
        for (let a = 0; a < gp.axes.length; a++) {
          const v = Number(gp.axes[a]) || 0;
          const prevOutside = Math.abs(prev.axes[i][a] || 0) > GAMEPAD_AXIS_DEADZONE;
          const nowOutside = Math.abs(v) > GAMEPAD_AXIS_DEADZONE;
          if (nowOutside && (a < 2 || opts.emitAllAxes)) {
            // axes 0,1 = left stick; 2,3 = right stick
            emit(
              makeEvent(
                "gamepad",
                "axis",
                { index: i, axis: a, value: v },
                Math.min(1, Math.abs(v)),
              ),
            );
          } else if (!nowOutside && prevOutside && (a < 2 || opts.emitAllAxes)) {
            // emit a "return to center" so decision_vector previews can reset
            emit(
              makeEvent(
                "gamepad",
                "axis",
                { index: i, axis: a, value: 0 },
                0.5,
              ),
            );
          }
          prev.axes[i][a] = v;
        }
      }
      timer = setTimeout(tick, GAMEPAD_POLL_MS);
    }
    tick();

    return function stopGamepad() {
      stopped = true;
      if (timer) clearTimeout(timer);
    };
  }

  // ---- keyboard helper for tests: synthesize a DeviceEvent without a real
  // key event. Not wired to the DOM by default (the existing textbox owns
  // keyboard). Tests use this to construct a deterministic DeviceEvent.
  function synthesize(channel, raw, confidence) {
    return makeEvent("keyboard", channel, raw, confidence);
  }

  const api = {
    onDeviceEvent: onDeviceEvent,
    startGamepad: startGamepad,
    synthesize: synthesize,
    // exposed for tests
    _makeEvent: makeEvent,
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  } else {
    root.inputDevices = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
