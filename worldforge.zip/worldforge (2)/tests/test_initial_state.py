"""Tests for RuleGenerator + WorldKernelSpec ``initial_state`` wiring.

Acceptance criteria (see the parent task):
  1. LLM output containing ``initial_state`` → parsed on the spec.
  2. LLM output without ``initial_state`` → inferred from every path the
     rules read (condition ASTs + effect ASTs, including nested writes).
  3. Every preset carries a non-empty ``initial_state`` that covers the
     paths its rules reference.
  4. ``WorldKernelHost`` falls back to ``spec.initial_state`` for any key
     the caller did NOT pass in (and lets caller-supplied keys win,
     including partial-nested overrides).
  5. Path coverage: every path a rule reads is present in the inferred
     ``initial_state`` (so the kernel never defaults to 0 silently when
     the LLM forgot to emit initial_state).

Note: the rule generator normalises dotted-key initial_state
(``{"population.infected": 5}``) into a nested dict
(``{"population": {"infected": 5}}``) so the host's `_lookup` (which
splits paths on ``.`` and walks nested dicts) can resolve them.  Tests
use ``_reach_path`` so they accept either form.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_initial_state.py -q
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, List

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.rule_generator import RuleGenerator, _PRESET_BUILDERS
from theater.world_kernel_host import (
    WorldKernelHost,
    WorldKernelSpec,
    WorldRule,
)


# =====================================================================
# Shared mock LLM
# =====================================================================


def _mock_llm_factory(raw_outputs: List[str]):
    iterator = iter(raw_outputs)

    def _fn(prompt: str) -> str:
        return next(iterator)

    return _fn


# =====================================================================
# 1) LLM output containing initial_state → parsed
# =====================================================================


class TestLLMInitialStateParsed:
    def test_initial_state_passes_through_to_spec(self) -> None:
        spec_obj = {
            "world_type": "plague",
            "rules": [
                {
                    "rule_id": "spread_one_step",
                    "kind": "dynamic",
                    "trigger": "tick",
                    "effect": {
                        "writes": "population.infected",
                        "op": "add",
                        "value": {
                            "op": "add",
                            "args": [{"ref": "population.infected"},
                                     {"const": 1}],
                        },
                    },
                    "description": "spread",
                    "priority": 1,
                },
            ],
            "params": {},
            "initial_state": {
                "population.infected": 10,
                "city.infection_rate": 0.05,
            },
        }
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory([json.dumps(spec_obj)])
        spec = gen.generate("anything", llm_fn=llm_fn)
        assert spec.world_type == "plague"
        assert _reach_path(spec.initial_state, "population.infected")[0] == 10
        assert _reach_path(spec.initial_state, "population.infected")[1]
        assert _reach_path(spec.initial_state, "city.infection_rate")[0] == 0.05

    def test_initial_state_is_dict_copy(self) -> None:
        """The LLM dict is deep-copied onto the spec (mutations don't leak)."""
        raw_initial = {"a": {"b": 1}}
        spec_obj = {
            "world_type": "x",
            "rules": [{
                "rule_id": "r", "kind": "dynamic", "trigger": "t",
                "effect": {"writes": "a.b", "op": "set", "value": {"const": 1}},
            }],
            "params": {},
            "initial_state": raw_initial,
        }
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory([json.dumps(spec_obj)])
        spec = gen.generate("anything", llm_fn=llm_fn)
        raw_initial["a"]["b"] = 999
        assert spec.initial_state == {"a": {"b": 1}}

    def test_initial_state_survives_json_with_prose(self) -> None:
        """The LLM happens to chat around the JSON; we still extract correctly."""
        spec_obj = {
            "world_type": "x",
            "rules": [{
                "rule_id": "r", "kind": "dynamic", "trigger": "t",
                "effect": {"writes": "k", "op": "set", "value": {"const": 1}},
            }],
            "params": {},
            "initial_state": {"k": 42},
        }
        gen = RuleGenerator()
        raw = "Here is the JSON:\n" + json.dumps(spec_obj) + "\nDone."
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate("anything", llm_fn=llm_fn)
        assert spec.initial_state.get("k") == 42


# =====================================================================
# 2) LLM output WITHOUT initial_state → inferred from rule paths
# =====================================================================


class TestInferredInitialState:
    def test_missing_initial_state_inferred_from_refs(self) -> None:
        spec_obj = {
            "world_type": "x",
            "rules": [
                {
                    "rule_id": "r",
                    "kind": "dynamic",
                    "trigger": "tick",
                    "condition": {"op": "gt",
                                  "args": [{"ref": "city.infection_rate"},
                                           {"const": 0}]},
                    "effect": {
                        "writes": "population.infected",
                        "op": "add",
                        "value": {
                            "op": "add",
                            "args": [{"ref": "population.infected"},
                                     {"const": 1}],
                        },
                    },
                },
            ],
            "params": {},
            # NO initial_state field — repair must infer one.
        }
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory([json.dumps(spec_obj)])
        spec = gen.generate("anything", llm_fn=llm_fn)
        assert _reach_path(spec.initial_state, "population.infected")[1]
        assert _reach_path(spec.initial_state, "city.infection_rate")[1]

    def test_inferred_state_collects_every_ref_path(self) -> None:
        """Every path the rules *reference* (condition args + writes) is
        captured in initial_state — including dotted paths under a
        namespace prefix (e.g. ``trade.amount``), because the walker only
        follows AST nodes (refs/lookups/writes), never ``rule.trigger``.
        """
        spec_obj = {
            "world_type": "x",
            "rules": [{
                "rule_id": "r", "kind": "dynamic", "trigger": "trade.executed",
                "condition": {"op": "gt",
                              "args": [{"ref": "trade.amount"}, {"const": 0}]},
                "effect": {"writes": "supply", "op": "set",
                           "value": {"const": 1}},
            }],
            "params": {},
        }
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory([json.dumps(spec_obj)])
        spec = gen.generate("anything", llm_fn=llm_fn)
        assert _reach_path(spec.initial_state, "supply")[1]
        assert _reach_path(spec.initial_state, "trade.amount")[1]
        # The trigger string itself is NOT a state path.
        assert not _reach_path(spec.initial_state, "trade.executed")[1]

    def test_inferred_state_picks_up_nested_lookup_paths(self) -> None:
        """The walker must descend into ``{"op":"lookup","args":["x.y"]}``."""
        spec_obj = {
            "world_type": "x",
            "rules": [{
                "rule_id": "r", "kind": "dynamic", "trigger": "t",
                # lookup-via-args form
                "condition": {"op": "eq",
                              "args": [{"op": "lookup", "args": ["population"]},
                                       {"const": 0}]},
                # ref shorthand
                "effect": {"writes": "b", "op": "set",
                           "value": {"ref": "population"}},
            }],
            "params": {},
        }
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory([json.dumps(spec_obj)])
        spec = gen.generate("anything", llm_fn=llm_fn)
        assert _reach_path(spec.initial_state, "population")[1]
        # Same path appears in condition + effect → only one entry, default 0.
        assert _reach_path(spec.initial_state, "population")[0] == 0

    def test_inferred_state_boolean_leaf_defaults_to_one(self) -> None:
        spec_obj = {
            "world_type": "x",
            "rules": [{
                "rule_id": "r", "kind": "dynamic", "trigger": "t",
                "effect": {"writes": "infected", "op": "set",
                           "value": {"const": 1}},
            }],
            "params": {},
        }
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory([json.dumps(spec_obj)])
        spec = gen.generate("anything", llm_fn=llm_fn)
        # Boolean-flavored names default to 1 (treat as "yes" baseline).
        assert _reach_path(spec.initial_state, "infected")[0] == 1

    def test_inferred_state_explicit_initial_state_wins(self) -> None:
        """If the LLM DID emit initial_state, the repair step must not
        overwrite it with the inferred guess."""
        spec_obj = {
            "world_type": "x",
            "rules": [{
                "rule_id": "r", "kind": "dynamic", "trigger": "t",
                "effect": {"writes": "supply", "op": "set",
                           "value": {"const": 1}},
            }],
            "params": {},
            "initial_state": {"supply": 999},
        }
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory([json.dumps(spec_obj)])
        spec = gen.generate("anything", llm_fn=llm_fn)
        assert spec.initial_state == {"supply": 999}

    def test_path_coverage_every_rule_read_is_in_initial_state(self) -> None:
        """Invariant: every dotted state path any rule reads is present in
        the spec's initial_state (after repair), so the host never has to
        fabricate a 0 silently."""
        spec_obj = {
            "world_type": "epidemic",
            "rules": [
                {
                    "rule_id": "spread",
                    "kind": "dynamic",
                    "trigger": "tick",
                    "condition": {"op": "and",
                                  "args": [{"op": "gt",
                                            "args": [{"ref": "city.infection_rate"},
                                                     {"const": 0}]},
                                           {"op": "lt",
                                            "args": [{"ref": "city.infection_rate"},
                                                     {"const": 1}]}]},
                    "effect": {"writes": "population.infected",
                               "op": "add",
                               "value": {"op": "add",
                                         "args": [{"ref": "population.infected"},
                                                  {"ref": "city.infection_rate"}]}},
                    "priority": 10,
                },
                {
                    "rule_id": "infected_positive",
                    "kind": "invariant",
                    "trigger": None,
                    "effect": {"op": "predicate",
                               "expr": {"op": "ge",
                                        "args": [{"ref": "population.infected"},
                                                 {"const": 0}]}},
                    "priority": 100,
                },
            ],
            "params": {},
        }
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory([json.dumps(spec_obj)])
        spec = gen.generate("anything", llm_fn=llm_fn)
        # Every leaf the rules reference must be in initial_state.
        for path in ("city.infection_rate", "population.infected"):
            assert _reach_path(spec.initial_state, path)[1], (
                f"missing path {path!r}"
            )


# =====================================================================
# 3) Presets carry initial_state
# =====================================================================


class TestPresetsIncludeInitialState:
    @pytest.mark.parametrize("description,wtype,expected_paths", [
        ("经济世界里供需决定价格", "economy",
         {"supply", "demand", "price", "population",
          "production_rate", "consumption_rate",
          "total_gold", "gold_constant"}),
        ("重力下的抛体运动", "physical", {"y", "vy", "gravity", "tick"}),
        ("社交互动影响信任和影响力", "social",
         {"trust", "influence"}),
        ("四人牌局的出牌得分", "card_game", {"game.last_rank",
                                              "game.score.p1",
                                              "game.score.p2"}),
    ])
    def test_preset_carries_initial_state(self, description: str,
                                          wtype: str,
                                          expected_paths: set) -> None:
        gen = RuleGenerator()
        spec = _PRESET_BUILDERS[wtype]()
        assert spec.world_type == wtype
        assert isinstance(spec.initial_state, dict)
        assert spec.initial_state, "preset initial_state must be non-empty"
        # Each expected dotted-path must be reachable from initial_state
        # (possibly nested under dicts).
        for p in expected_paths:
            assert _reach_path(spec.initial_state, p)[1], (
                f"preset {wtype!r} missing initial_state path {p!r}; "
                f"got state={spec.initial_state!r}"
            )


# =====================================================================
# 4) WorldKernelHost merges spec.initial_state + caller state
# =====================================================================


class TestHostMergesInitialState:
    def _spec_with_initial(self, initial_state: Dict[str, Any]) -> WorldKernelSpec:
        return WorldKernelSpec(
            world_type="x",
            rules=[WorldRule(
                rule_id="r",
                kind="dynamic",
                trigger="t",
                effect={"writes": "x", "op": "set", "value": {"const": 1}},
            )],
            initial_state=initial_state,
        )

    def test_empty_caller_state_filled_from_initial_state(self) -> None:
        spec = self._spec_with_initial({"a": 1, "b": 2})
        host = WorldKernelHost(spec, {}, seed=0)
        assert host.state() == {"a": 1, "b": 2}

    def test_missing_keys_filled_from_initial_state(self) -> None:
        spec = self._spec_with_initial({"a": 1, "b": 2, "c": 3})
        host = WorldKernelHost(spec, {"a": 99}, seed=0)
        # Caller overrides a; b, c filled from initial_state.
        assert host.state() == {"a": 99, "b": 2, "c": 3}

    def test_caller_state_wins_for_overridden_keys(self) -> None:
        spec = self._spec_with_initial({"x": 0, "y": 0})
        host = WorldKernelHost(spec, {"x": 5, "y": 7}, seed=0)
        assert host.state() == {"x": 5, "y": 7}

    def test_nested_merge_caller_leaf_overrides_initial(self) -> None:
        """Caller can override ONE leaf of a nested initial_state dict
        without losing the sibling keys."""
        spec = self._spec_with_initial(
            {"economy": {"price": 1.0, "supply": 100, "demand": 50}}
        )
        host = WorldKernelHost(spec, {"economy": {"price": 5.0}}, seed=0)
        assert host.state() == {
            "economy": {"price": 5.0, "supply": 100, "demand": 50},
        }

    def test_no_initial_state_unchanged_behavior(self) -> None:
        """Empty initial_state (the default) preserves the old contract:
        caller state IS the host state, exactly."""
        spec = WorldKernelSpec(
            world_type="x",
            rules=[WorldRule(rule_id="r", kind="dynamic", trigger="t",
                             effect={"writes": "x", "op": "set",
                                     "value": {"const": 1}})],
        )
        host = WorldKernelHost(spec, {"a": 1}, seed=0)
        assert host.state() == {"a": 1}

    def test_state_is_deepcopied_from_initial(self) -> None:
        """Mutation of state by step() must not affect the spec."""
        spec = self._spec_with_initial({"c": 5})
        host = WorldKernelHost(spec, {}, seed=0)
        host.step({"trigger": "t"})
        # Sanity: step wrote 'x'=1; 'c' from initial_state still 5.
        assert host.state()["c"] == 5
        # spec.initial_state was not mutated by host step.
        assert spec.initial_state == {"c": 5}


# =====================================================================
# 5) System prompt explicitly mentions initial_state (LLM guardrail)
# =====================================================================


class TestSystemPromptMentionsInitialState:
    def test_system_prompt_documents_initial_state(self) -> None:
        gen = RuleGenerator()
        prompt = gen._build_system_prompt()
        assert "initial_state" in prompt
        # Must also mention why it matters (so the LLM doesn't drop it).
        assert "0" in prompt or "default" in prompt.lower()


# =====================================================================
# helpers
# =====================================================================


def _reach_path(state: Dict[str, Any], dotted: str) -> Any:
    """Read a dotted path through nested dicts; also try a literal key.

    Returns ``(value, found)``.  The repair step in RuleGenerator may
    normalise ``{"a.b": v}`` into ``{"a": {"b": v}}``; this helper
    accepts either shape so tests don't depend on the normalisation.
    """
    if dotted in state:
        return state[dotted], True
    cursor: Any = state
    for part in dotted.split("."):
        if not isinstance(cursor, dict) or part not in cursor:
            return None, False
        cursor = cursor[part]
    return cursor, True


def _flatten(d: Dict[str, Any], prefix: str = "") -> Dict[str, Any]:
    """Flatten a nested dict to dot-paths (for asserting presence)."""
    out: Dict[str, Any] = {}
    for k, v in d.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            out[key] = v
            out.update(_flatten(v, key))
        else:
            out[key] = v
    return out


def _present_parents(d: Dict[str, Any], prefix: str = "",
                     out: Dict[str, Any] = None) -> Dict[str, Any]:
    """Mark every dotted path that is a *dict node* in *d* (so we can
    match both ``game`` and ``game.score.p1``)."""
    if out is None:
        out = {}
    for k, v in d.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            out[key] = v
            _present_parents(v, key, out)
    return out
