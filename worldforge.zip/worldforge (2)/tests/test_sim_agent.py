"""Tests for SimAgent + CharacterCardAdapter (architecture §4.2 / §5).

P1 scope: the runtime subjectification of characters — turning a card into
a simulated subject with CharacterDefinition / MindProfile / AgentMindState /
RuntimeState / WorldBinding, plus the observe→update_belief→choose_action
skeleton.  Concrete belief-update + decision policy arrive in P2; here we
pin the structure, the deterministic MindProfile derivation, the adapter
flow, and the skeleton's interface contract.

No LLM, no randomness — every assertion is a pure function of its inputs.
"""

from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.character_card_adapter import (  # noqa: E402
    CharacterCardAdapter,
    adapt_card,
)
from theater.cognitive_model import Belief  # noqa: E402
from theater.sim_agent import (  # noqa: E402
    AgentMindState,
    CharacterDefinition,
    MindProfile,
    RuntimeState,
    SimAgent,
    WorldBinding,
    derive_mind_profile,
)


# ---------------------------------------------------------------------------
# SimAgent structure
# ---------------------------------------------------------------------------


def _stub_character(**kw) -> CharacterDefinition:
    base = dict(
        character_id="carmen",
        name="Carmen",
        personality="热情而固执",
        appearance="吉普赛女郎",
        sample_line="L'amour est un oiseau rebelle",
        background="吉普赛女郎，烟草厂女工",
        social_role="烟草厂女工",
    )
    base.update(kw)
    return CharacterDefinition(**base)


def test_sim_agent_composes_all_four_substructures():
    """SimAgent carries CharacterDefinition, MindProfile, AgentMindState,
    RuntimeState, and WorldBinding (§4.2)."""
    agent = SimAgent(character=_stub_character())
    assert isinstance(agent.character, CharacterDefinition)
    assert isinstance(agent.mind, MindProfile)
    assert isinstance(agent.mind_state, AgentMindState)
    assert isinstance(agent.runtime, RuntimeState)
    assert isinstance(agent.world_binding, WorldBinding)


def test_sim_agent_identity_shortcuts():
    agent = SimAgent(character=_stub_character())
    assert agent.character_id == "carmen"
    assert agent.name == "Carmen"


def test_sim_agent_defaults_mind_profile_when_none_supplied():
    """When no MindProfile is passed, it is derived from the character's
    personality text (deterministic)."""
    agent = SimAgent(character=_stub_character(personality="固执"))
    # 固执 → evidence_weight below neutral 1.0
    assert agent.mind.evidence_weight < 1.0


# ---------------------------------------------------------------------------
# MindProfile derivation
# ---------------------------------------------------------------------------


def test_mind_profile_stubborn_lowers_evidence_weight():
    """固执 → low evidence weight (×0.3 band)."""
    profile = derive_mind_profile("性格固执，不易改变想法")
    assert profile.evidence_weight < 0.6


def test_mind_profile_open_raises_evidence_weight():
    """开放 → high evidence weight (×1.5 band)."""
    profile = derive_mind_profile("性格开放，对新事物充满好奇")
    assert profile.evidence_weight > 1.2


def test_mind_profile_cautious_raises_loss_weight():
    """谨慎 → loss_weight > gain_weight (loss-averse)."""
    profile = derive_mind_profile("为人谨慎，行事小心")
    assert profile.risk_profile["loss_weight"] > profile.risk_profile["gain_weight"]


def test_mind_profile_gambler_raises_gain_weight():
    profile = derive_mind_profile("天生的赌徒，爱冒险")
    assert profile.risk_profile["gain_weight"] > profile.risk_profile["loss_weight"]


def test_mind_profile_belief_update_rate_stubborn_slow_rational_fast():
    stubborn = derive_mind_profile("固执")
    rational = derive_mind_profile("理性冷静")
    assert stubborn.belief_update_rate < rational.belief_update_rate


def test_mind_profile_neutral_defaults():
    """No personality keywords → neutral defaults (evidence_weight=1.0,
    balanced risk, mid Big Five)."""
    profile = derive_mind_profile("")
    assert profile.evidence_weight == 1.0
    assert profile.risk_profile["loss_weight"] == 1.0
    assert profile.risk_profile["gain_weight"] == 1.0
    for axis in ("openness", "conscientiousness", "extraversion",
                 "agreeableness", "neuroticism"):
        assert 0.4 <= profile.big_five[axis] <= 0.6


def test_mind_profile_big_five_derived_and_bounded():
    """Big Five axes are present, in [0,1], and shift with keywords."""
    profile = derive_mind_profile("外向健谈，敏感情绪化")
    assert 0.0 <= profile.big_five["extraversion"] <= 1.0
    assert 0.0 <= profile.big_five["neuroticism"] <= 1.0
    assert profile.big_five["extraversion"] > 0.5
    assert profile.big_five["neuroticism"] > 0.5


def test_mind_profile_derivation_is_deterministic():
    a = derive_mind_profile("固执 谨慎 开放")
    b = derive_mind_profile("固执 谨慎 开放")
    assert a == b


# ---------------------------------------------------------------------------
# CharacterCardAdapter
# ---------------------------------------------------------------------------


def _card() -> dict:
    return {
        "character_id": "carmen",
        "name": "Carmen",
        "description": "吉普赛女郎，烟草厂女工",
        "personality": "热情而固执，性格开放又谨慎",
        "first_mes": "L'amour est un oiseau rebelle",
    }


def test_adapter_returns_three_components():
    char, mind, binding = CharacterCardAdapter.adapt(_card())
    assert isinstance(char, CharacterDefinition)
    assert isinstance(mind, MindProfile)
    assert isinstance(binding, WorldBinding)


def test_adapter_copies_card_fields_into_character_definition():
    char, _, _ = CharacterCardAdapter.adapt(_card())
    assert char.character_id == "carmen"
    assert char.name == "Carmen"
    assert char.background.startswith("吉普赛女郎")
    assert char.sample_line.startswith("L'amour")
    assert "热情而固执" in char.personality


def test_adapter_derives_mind_profile_from_card_personality():
    """Adapter must derive MindProfile from card text without an LLM."""
    _, mind, _ = CharacterCardAdapter.adapt({
        "name": "x", "personality": "固执", "description": "",
    })
    assert mind.evidence_weight < 0.6


def test_adapter_world_binding_defaults():
    _, _, binding = CharacterCardAdapter.adapt(_card())
    assert binding.world_id == ""
    assert binding.knowledge_scope == "*"
    assert binding.permissions["allowed_actions"] == ["move", "speak", "inspect"]


def test_adapter_world_binding_custom_world_and_actions():
    _, _, binding = CharacterCardAdapter.adapt(
        _card(), world_id="seville",
        knowledge_scope=["tobacco_factory"],
        allowed_actions=["move", "speak", "sing"],
    )
    assert binding.world_id == "seville"
    assert binding.knowledge_scope == ["tobacco_factory"]
    assert "sing" in binding.permissions["allowed_actions"]


def test_adapt_card_convenience_returns_sim_agent():
    agent = adapt_card(_card())
    assert isinstance(agent, SimAgent)
    assert agent.name == "Carmen"
    assert isinstance(agent.mind, MindProfile)


def test_adapter_reuses_world_import_parse_card_aliases():
    """Adapter wraps world_import.parse_card, so v1 nested aliases work."""
    char, _, _ = CharacterCardAdapter.adapt({
        "char_name": "José",
        "char_description": "军官",
        "char_personality": "谨慎",
    })
    assert char.name == "José"
    assert char.background == "军官"
    assert "谨慎" in char.personality


# ---------------------------------------------------------------------------
# observe / update_belief / choose_action skeleton
# ---------------------------------------------------------------------------


def test_observe_appends_to_memory():
    agent = SimAgent(character=_stub_character())
    assert agent.mind_state.memory == []
    agent.observe({"event": "explosion"})
    assert len(agent.mind_state.memory) == 1
    assert agent.mind_state.memory[0]["event"] == "explosion"


def test_observe_wraps_raw_value():
    agent = SimAgent(character=_stub_character())
    agent.observe("loud bang")
    assert agent.mind_state.memory[-1] == {"raw": "loud bang"}


def test_update_belief_commits_a_belief_reusing_cognitive_model_belief():
    """AgentMindState.beliefs reuse cognitive_model.Belief (Sabre commitment).

    The first observation on a fresh topic commits the evidence as the
    prior; revise_belief then runs (a no-op move when observation equals
    prior) and returns a BeliefUpdateTrace whose posterior is the committed
    Belief.
    """
    from theater.belief_update import BeliefUpdateTrace
    agent = SimAgent(character=_stub_character())
    trace = agent.update_belief(topic="weather", evidence=0.8)
    assert isinstance(trace, BeliefUpdateTrace)
    assert isinstance(trace.posterior, Belief)
    assert "weather" in agent.mind_state.beliefs
    assert trace.posterior.predicted == 0.8


def test_update_belief_nudges_existing_confidence_deterministically():
    agent = SimAgent(character=_stub_character(personality="理性"))
    first = agent.update_belief(topic="price", evidence=10.0)
    second = agent.update_belief(topic="price", evidence=11.0)
    assert second.posterior.confidence >= first.posterior.confidence
    # same inputs → same output (determinism)
    agent2 = SimAgent(character=_stub_character(personality="理性"))
    a = agent2.update_belief(topic="price", evidence=10.0).posterior.confidence
    b = SimAgent(character=_stub_character(personality="理性")).update_belief(
        topic="price", evidence=10.0).posterior.confidence
    assert a == b


def test_choose_action_returns_default_from_allowed_actions():
    agent = SimAgent(
        character=_stub_character(),
        world_binding=WorldBinding(
            permissions={"allowed_actions": ["speak", "move"]}),
    )
    action = agent.choose_action()
    assert action["verb"] == "speak"
    assert action["actor_id"] == "carmen"


def test_choose_action_falls_back_when_no_permissions():
    agent = SimAgent(character=_stub_character(),
                     world_binding=WorldBinding(permissions={}))
    action = agent.choose_action()
    assert action["verb"] == "wait"


# ---------------------------------------------------------------------------
# P2 wiring: observe via ObservationFilter, three-strategy belief revision,
# softmax decision, social pressure, stable mistakes, backward compat.
# ---------------------------------------------------------------------------


class _MockFilter:
    """Minimal ObservationFilter stub: returns a canned projection and
    records what it was called with, so tests can assert the SimAgent
    handed its binding (not the raw ground truth) to the filter."""

    def __init__(self, projection):
        self._projection = projection
        self.calls = []

    def observe(self, true_state, agent_binding):
        self.calls.append({"true_state": dict(true_state),
                           "agent_binding": dict(agent_binding)})
        return dict(self._projection)


def _candidates():
    return [
        {"verb": "flee", "target": "gate", "benefit": 10.0, "cost": 2.0,
         "risk": 0.3, "belief_topic": "danger"},
        {"verb": "fight", "target": "thief", "benefit": 6.0, "cost": 4.0,
         "risk": 0.8, "belief_topic": "danger"},
        {"verb": "hide", "target": "cellar", "benefit": 3.0, "cost": 1.0,
         "risk": 0.1, "belief_topic": "danger"},
    ]


# --- observe via filter ----------------------------------------------------


def test_observe_via_filter_does_not_read_raw_ground_truth():
    """observe(filter, true_state) projects truth through the filter; the
    agent's memory holds the *filtered* projection, not the raw truth."""
    agent = SimAgent(character=_stub_character())
    filt = _MockFilter({"observed_price": 5.0, "filter_flags": ["delayed"]})
    true_state = {"price": 7.0, "secret": "the-raw-truth"}
    filtered = agent.observe(filt, true_state, seed=42)
    assert filtered == {"observed_price": 5.0, "filter_flags": ["delayed"]}
    # memory carries the filtered envelope, not the raw true_state
    entry = agent.mind_state.memory[-1]
    assert entry["type"] == "filtered_observation"
    assert entry["observation"]["observed_price"] == 5.0
    # the raw ground truth must not leak into memory
    assert "secret" not in str(entry)


def test_observe_via_filter_passes_subject_binding_not_truth():
    """The filter receives (true_state, binding); the binding identifies the
    subject, and the filter — not the agent — decides what to reveal."""
    agent = SimAgent(character=_stub_character(personality="理性"),
                     world_binding=WorldBinding(world_id="seville",
                                                knowledge_scope=["market"]))
    filt = _MockFilter({"x": 1})
    agent.observe(filt, {"price": 9.0}, seed=7)
    call = filt.calls[-1]
    assert call["true_state"] == {"price": 9.0}
    binding = call["agent_binding"]
    assert binding["character_id"] == "carmen"
    assert binding["world_id"] == "seville"
    assert binding["knowledge_scope"] == ["market"]
    assert binding["seed"] == 7


def test_oberve_filter_mode_seed_determinism():
    agent = SimAgent(character=_stub_character())
    filt = _MockFilter({"a": 1})
    agent.observe(filt, {"price": 1.0}, seed=99)
    agent.observe(filt, {"price": 1.0}, seed=99)
    # both calls recorded with identical bindings
    assert filt.calls[0]["agent_binding"] == filt.calls[1]["agent_binding"]


def test_observe_stub_backward_compat_dict():
    """No filter → raw dict appended verbatim (P1 behaviour preserved)."""
    agent = SimAgent(character=_stub_character())
    agent.observe({"event": "explosion"})
    assert agent.mind_state.memory[-1] == {"event": "explosion"}


def test_observe_stub_backward_compat_raw():
    agent = SimAgent(character=_stub_character())
    agent.observe("loud bang")
    assert agent.mind_state.memory[-1] == {"raw": "loud bang"}


# --- update_belief: three strategies --------------------------------------


def test_update_belief_returns_trace_with_strategy_and_posterior():
    from theater.belief_update import BeliefUpdateTrace
    agent = SimAgent(character=_stub_character(personality="理性"))
    trace = agent.update_belief(topic="danger", evidence=0.9)
    assert isinstance(trace, BeliefUpdateTrace)
    assert trace.topic == "danger"
    assert trace.strategy == "rational"
    assert isinstance(trace.posterior, Belief)
    # posterior committed into mind_state
    assert agent.mind_state.beliefs["danger"] is trace.posterior


def test_update_belief_open_personality_uses_rational_strategy():
    agent = SimAgent(character=_stub_character(personality="开放好奇"))
    trace = agent.update_belief(topic="t", evidence=0.5)
    assert trace.strategy == "rational"
    assert trace.evidence_weight > 1.0


def test_update_belief_stubborn_uses_dogmatic_strategy():
    agent = SimAgent(character=_stub_character(personality="固执"))
    trace = agent.update_belief(topic="t", evidence=0.5)
    assert trace.strategy == "dogmatic"


def test_update_belief_conspiratorial_strategy_from_personality_text():
    agent = SimAgent(character=_stub_character(personality="多疑，相信阴谋"))
    trace = agent.update_belief(topic="t", evidence=0.5)
    assert trace.strategy == "conspiratorial"


def test_update_belief_dogmatic_backfires_on_contradiction():
    """固执 agent: prior committed to a low value; strong contradicting
    evidence pushes the posterior *away* from the evidence (backfire)."""
    agent = SimAgent(character=_stub_character(personality="固执"))
    # Commit a prior at 0.1
    agent.update_belief(topic="danger", evidence=0.1)
    # Hit it with strong evidence the other way (0.9)
    trace = agent.update_belief(topic="danger", evidence=0.9)
    assert trace.contradiction != 0.0
    assert not trace.accepted  # backfire → evidence rejected
    # posterior moved *away* from 0.9, i.e. below the prior
    assert trace.posterior.predicted < 0.1


def test_update_belief_rational_moves_toward_evidence():
    agent = SimAgent(character=_stub_character(personality="理性开放"))
    agent.update_belief(topic="danger", evidence=0.2)
    trace = agent.update_belief(topic="danger", evidence=0.8)
    assert trace.accepted
    # rational moves toward 0.8 (above the prior 0.2); it may overshoot.
    assert trace.posterior.predicted > 0.2


# --- six error sources are traceable --------------------------------------


def test_update_belief_tags_cognitive_bias_on_dogmatic_backfire():
    agent = SimAgent(character=_stub_character(personality="固执"))
    agent.update_belief(topic="t", evidence=0.1)
    trace = agent.update_belief(topic="t", evidence=0.9)
    assert trace.error_source == "cognitive_bias"


def test_update_belief_tags_perception_error_when_observation_unvalidated():
    agent = SimAgent(character=_stub_character(personality="理性"))
    agent.update_belief(topic="t", evidence=0.5)
    trace = agent.update_belief(topic="t", evidence=0.6,
                               observation_validated=False)
    assert trace.error_source == "perception_error"


def test_update_belief_trace_replay_reproduces_posterior():
    agent = SimAgent(character=_stub_character(personality="理性"))
    agent.update_belief(topic="t", evidence=0.3)
    trace = agent.update_belief(topic="t", evidence=0.7, seed=123)
    replayed = trace.replay()
    assert replayed.predicted == trace.posterior.predicted
    assert replayed.confidence == trace.posterior.confidence


def test_update_belief_stores_trace_in_memory_for_replay():
    agent = SimAgent(character=_stub_character(personality="理性"))
    agent.update_belief(topic="t", evidence=0.4)
    memory_entry = agent.mind_state.memory[-1]
    assert memory_entry["type"] == "belief_update"
    assert memory_entry["topic"] == "t"
    assert memory_entry["trace"].posterior.predicted == 0.4


# --- choose_action: subjective softmax ------------------------------------


def _danger_agent(personality="理性", allowed=None):
    binding = WorldBinding(
        permissions={"allowed_actions": allowed
                     or ["flee", "fight", "hide", "wait"]})
    agent = SimAgent(character=_stub_character(personality=personality),
                     world_binding=binding)
    return agent


def test_choose_action_filters_candidates_through_permissions():
    agent = _danger_agent(allowed=["flee", "wait"])
    # candidate list includes a non-permitted verb
    cands = _candidates() + [{"verb": "teleport", "target": "moon",
                              "benefit": 100.0, "cost": 0.0, "risk": 0.0,
                              "belief_topic": "danger"}]
    action = agent.choose_action({"candidates": cands, "seed": 1})
    assert action["verb"] in {"flee", "wait"}
    assert action["verb"] != "teleport"


def test_choose_action_softmax_is_seed_deterministic():
    agent = _danger_agent()
    agent.update_belief(topic="danger", evidence=0.7)
    ctx = {"candidates": _candidates(), "seed": 42}
    a1 = agent.choose_action(ctx)
    a2 = agent.choose_action(ctx)
    assert a1["verb"] == a2["verb"]
    # same agent + different seed may legitimately differ
    a3 = agent.choose_action({"candidates": _candidates(), "seed": 999})
    assert isinstance(a3["verb"], str)


def test_choose_action_subjective_score_uses_belief_not_truth():
    """The agent scores candidates with its *subjective* belief, which may
    disagree with the kernel's true danger.  A low subjective danger →
    low-scoring 'flee' → agent rarely flees."""
    agent = _danger_agent()
    # Subjective belief: danger is low (0.05) even though the candidate
    # list references topic "danger".  flee's score = 0.05*10 - 2 - 0.3*1.0
    agent.update_belief(topic="danger", evidence=0.05)
    action = agent.choose_action({"candidates": _candidates(), "seed": 3})
    # subjective_scores are populated and finite
    scores = action["subjective_scores"]
    assert "flee" in scores and "fight" in scores and "hide" in scores
    # With low danger, flee (benefit×danger) is not the runaway winner.
    # Run 8 seeds and assert flee is not chosen deterministically every time.
    choices = {
        agent.choose_action({"candidates": _candidates(), "seed": s})["verb"]
        for s in range(8)
    }
    assert "flee" not in choices or len(choices) > 1


def test_choose_action_high_subjective_danger_favours_flee():
    agent = _danger_agent()
    agent.update_belief(topic="danger", evidence=0.95)
    choices = [
        agent.choose_action({"candidates": _candidates(), "seed": s})["verb"]
        for s in range(12)
    ]
    # With high subjective danger, flee (highest benefit×danger) dominates.
    assert choices.count("flee") >= 8


def test_choose_action_pressure_raises_temperature_and_impulse():
    """High pressure → higher temperature → flatter softmax → more
    impulsive / varied choices even with a clear best action."""
    agent = _danger_agent()
    agent.update_belief(topic="danger", evidence=0.95)
    low_p = {
        agent.choose_action({"candidates": _candidates(),
                             "seed": s, "pressure": 0.0})["verb"]
        for s in range(10)
    }
    high_p = {
        agent.choose_action({"candidates": _candidates(),
                             "seed": s, "pressure": 5.0})["verb"]
        for s in range(10)
    }
    # high pressure should broaden the choice set (more impulsive)
    assert len(high_p) >= len(low_p)
    # temperature is reported and scales with pressure
    t_low = agent.choose_action({"candidates": _candidates(), "seed": 0,
                                 "pressure": 0.0})["temperature"]
    t_high = agent.choose_action({"candidates": _candidates(), "seed": 0,
                                  "pressure": 5.0})["temperature"]
    assert t_high > t_low


def test_choose_action_returns_action_intent_fields():
    agent = _danger_agent()
    agent.update_belief(topic="danger", evidence=0.6)
    action = agent.choose_action({"candidates": _candidates(), "seed": 1})
    for key in ("actor_id", "verb", "target", "subjective_reason",
                "belief_refs", "subjective_scores", "confidence"):
        assert key in action
    assert action["actor_id"] == "carmen"
    assert action["verb"] in {"flee", "fight", "hide", "wait"}
    assert "danger" in action["belief_refs"]
    assert 0.0 <= action["confidence"] <= 1.0


def test_choose_action_does_not_mutate_world_state():
    """The intent is a commitment to act; choose_action itself changes no
    belief / memory beyond what update_belief already did."""
    agent = _danger_agent()
    agent.update_belief(topic="danger", evidence=0.6)
    mem_before = len(agent.mind_state.memory)
    beliefs_before = dict(agent.mind_state.beliefs)
    agent.choose_action({"candidates": _candidates(), "seed": 1})
    assert len(agent.mind_state.memory) == mem_before
    assert agent.mind_state.beliefs == beliefs_before


# --- stable mistake: stubborn agent reinforces wrong belief then acts on it


def test_stable_mistake_stubborn_reinforces_wrong_belief_then_acts():
    """The bounded-rationality red line: a stubborn agent with an old
    belief, hit with contradicting evidence, *reinforces* the wrong belief
    (dogmatic backfire) and then chooses an action based on that wrong
    subjective belief — a deterministic, traceable mistake, not a fluke."""
    agent = _danger_agent(personality="固执")
    # Old belief: danger is low (0.1) — the agent is committed to "safe".
    agent.update_belief(topic="danger", evidence=0.1)
    prior_pred = agent.mind_state.beliefs["danger"].predicted
    # Kernel sends strong contradicting evidence (danger high, 0.9).
    trace = agent.update_belief(topic="danger", evidence=0.9)
    # Dogmatic backfire: posterior moved AWAY from the evidence.
    assert trace.strategy == "dogmatic"
    assert trace.error_source == "cognitive_bias"
    assert trace.posterior.predicted < prior_pred  # reinforced "safe"
    # The agent now decides on the (wrong) subjective belief that danger
    # is low → flee (high benefit×danger) should NOT dominate.
    choices = [
        agent.choose_action({"candidates": _candidates(), "seed": s})["verb"]
        for s in range(12)
    ]
    # With a low subjective danger the agent should rarely flee.
    assert choices.count("flee") <= 4
    # And the whole sequence is replayable / deterministic.
    agent2 = _danger_agent(personality="固执")
    agent2.update_belief(topic="danger", evidence=0.1)
    t2 = agent2.update_belief(topic="danger", evidence=0.9)
    assert t2.posterior.predicted == trace.posterior.predicted


# --- social pressure wiring (optional) ------------------------------------


def test_update_belief_blends_social_pressure_when_graph_bound():
    from theater.character_graph import CharacterGraph, social_pressure
    graph = CharacterGraph()
    graph.add_relationship("carmen", "leader", trust=0.9, influence=0.5)
    agent = SimAgent(character=_stub_character(personality="理性"),
                     character_graph=graph)
    agent.update_belief(topic="danger", evidence=0.2)
    # Neighbours believe danger is high.
    peer_beliefs = {"leader": {"danger": 0.95}}
    trace = agent.update_belief(topic="danger", evidence=0.3,
                                peer_beliefs=peer_beliefs)
    assert trace.personality_modifiers["blended"] is True
    assert trace.personality_modifiers["social_pressure"] == 0.95
    # Blended observation pulled between 0.3 (primary) and 0.95 (social).
    # Rational update moves predicted toward the blended obs, which is
    # above the raw 0.3 → posterior should exceed the no-social case.
    agent_solo = SimAgent(character=_stub_character(personality="理性"))
    agent_solo.update_belief(topic="danger", evidence=0.2)
    trace_solo = agent_solo.update_belief(topic="danger", evidence=0.3)
    assert trace.posterior.predicted > trace_solo.posterior.predicted


def test_update_belief_no_graph_skips_social_pressure():
    agent = SimAgent(character=_stub_character(personality="理性"))
    agent.update_belief(topic="t", evidence=0.4)
    trace = agent.update_belief(topic="t", evidence=0.5,
                               peer_beliefs={"x": {"t": 0.9}})
    assert trace.personality_modifiers["blended"] is False
    assert trace.personality_modifiers["social_pressure"] == 0.0


# --- backward-compat: choose_action with no context still works -----------


def test_choose_action_no_context_returns_first_allowed():
    agent = _danger_agent(allowed=["speak", "move"])
    action = agent.choose_action()
    assert action["verb"] == "speak"
    assert action["actor_id"] == "carmen"


def test_sim_agent_round_trip_via_dispatcher_create_character_as_sim_agent():
    """create_character(as_sim_agent=True) returns a sim_agent upgrade of
    the freshly stored character (dispatcher §4.2 wiring)."""
    # Local import to avoid module-level dispatcher dependency.
    from theater.dispatcher import TheaterOrchestrator
    from theater.storage import JsonStateStore
    import tempfile, pathlib
    tmp = pathlib.Path(tempfile.mkdtemp()) / "state"
    store = JsonStateStore(tmp)
    orch = TheaterOrchestrator(
        state_store=store,
        model_client=None,
    )
    result = orch.create_character(
        mode="manual",
        fields={"name": "Stubborn Merchant",
                "personality": "性格固执，谨慎",
                "summary": "a stubborn merchant"},
        as_sim_agent=True,
    )
    assert result["ok"]
    assert "sim_agent" in result
    sim = result["sim_agent"]
    assert sim["character_id"] == result["character_id"]
    assert sim["world_binding"]["world_id"] == orch.world_id
    # 固执 → derived evidence weight below neutral
    assert sim["mind"]["evidence_weight"] < 1.0
