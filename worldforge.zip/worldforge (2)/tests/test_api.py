import json
import os
import tempfile
import threading
import unittest
from urllib import error, request
from urllib.parse import quote

from theater.agents import ProviderDiagnostics
from theater.server import create_server
from theater.settings import Settings


class ApiTests(unittest.TestCase):
    def test_api_exposes_health_and_rejects_dispatch_without_llm_or_secret_leak(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = dict(os.environ)
            os.environ["AI_THEATER_API_KEY"] = "test-secret-token"
            os.environ["AI_THEATER_ENABLE_LIVE_API"] = "false"
            # Explicit cloud models — the no-config default is now the local
            # Spark qwen3-coder endpoint, so opt back into the cloud path.
            os.environ["AI_THEATER_BASE_URL"] = "https://api.requestme.top/v1"
            os.environ["AI_THEATER_MODEL_FAST"] = "gpt5.4"
            os.environ["AI_THEATER_MODEL_DEEP"] = "gpt5.5"
            os.environ["AI_THEATER_DATA_DIR"] = directory
            server = create_server(host="127.0.0.1", port=0)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                base_url = f"http://127.0.0.1:{server.server_port}"
                health = json.loads(request.urlopen(f"{base_url}/api/health", timeout=5).read())
                self.assertIs(health["ok"], True)

                payload = json.dumps({"session_id": "story_1", "message": "我要夺舍 Aster，然后查看档案馆"}).encode("utf-8")
                req = request.Request(
                    f"{base_url}/api/dispatch",
                    data=payload,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with self.assertRaises(error.HTTPError) as caught:
                    request.urlopen(req, timeout=5)
                self.assertEqual(caught.exception.code, 503)
                body = json.loads(caught.exception.read())
                self.assertFalse(body["ok"])
                self.assertIn("LLM dispatch failed", body["error"])
                self.assertNotIn("test-secret-token", str(body))

                state_text = request.urlopen(f"{base_url}/api/state", timeout=5).read().decode("utf-8")
                self.assertNotIn("test-secret-token", state_text)
                state = json.loads(state_text)
                self.assertNotIn("assets", state)
                self.assertNotIn("attachments", state)
                self.assertEqual(state["world_id"], "main")
                self.assertEqual(state["schema_version"], 6)
                self.assertEqual(state["_meta"]["world_id"], "main")
                self.assertIsInstance(state["rules"], list)
                self.assertIsInstance(state["kernel_state"], dict)
                self.assertIn("gpt5.4", state_text)
                self.assertIn("gpt5.5", state_text)
                self.assertIn("gpt-5.4", state_text)
                self.assertIn("gpt-5.5", state_text)
            finally:
                server.shutdown()
                server.server_close()
                os.environ.clear()
                os.environ.update(previous)

    def test_api_shutdown_stops_server(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = dict(os.environ)
            os.environ["AI_THEATER_API_KEY"] = ""
            os.environ["AI_THEATER_ENABLE_LIVE_API"] = "false"
            os.environ["AI_THEATER_DATA_DIR"] = directory
            server = create_server(host="127.0.0.1", port=0)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                base_url = f"http://127.0.0.1:{server.server_port}"
                health = json.loads(request.urlopen(f"{base_url}/api/health", timeout=5).read())
                self.assertIs(health["ok"], True)

                shutdown_payload = json.dumps({}).encode("utf-8")
                shutdown_req = request.Request(
                    f"{base_url}/api/system/shutdown",
                    data=shutdown_payload,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                body = json.loads(request.urlopen(shutdown_req, timeout=5).read())
                self.assertIs(body["ok"], True)
                self.assertIs(body["shutting_down"], True)

                thread.join(timeout=5)
                self.assertFalse(thread.is_alive())
            finally:
                if thread.is_alive():
                    server.shutdown()
                server.server_close()
                os.environ.clear()
                os.environ.update(previous)

    def test_provider_diagnostics_fetch_models_returns_model_list(self):
        settings = Settings(api_key="test-key", base_url="https://api.example/v1", enable_live_api=True)

        class FakeResponse:
            def read(self):
                return json.dumps({"data": [{"id": "gpt-5.4"}, {"id": "gpt-5.5"}]}).encode("utf-8")

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        diagnostics = ProviderDiagnostics(settings, urlopen=lambda req, **kwargs: FakeResponse())
        result = diagnostics.fetch_models()
        self.assertTrue(result["ok"])
        self.assertIn("gpt-5.4", result["models"])
        self.assertIn("gpt-5.5", result["models"])

    def test_api_provider_models_endpoint_exists_and_does_not_leak_key(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = dict(os.environ)
            os.environ["AI_THEATER_API_KEY"] = "test-key"
            os.environ["AI_THEATER_ENABLE_LIVE_API"] = "false"
            os.environ["AI_THEATER_DATA_DIR"] = directory
            server = create_server(host="127.0.0.1", port=0)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                base_url = f"http://127.0.0.1:{server.server_port}"
                body = json.loads(request.urlopen(f"{base_url}/api/provider/models", timeout=5).read())
                self.assertIn("ok", body)
                self.assertIn("models", body)
                self.assertIn("base_url", body)
                self.assertNotIn("test-key", str(body))
            finally:
                if thread.is_alive():
                    server.shutdown()
                server.server_close()
                os.environ.clear()
                os.environ.update(previous)

    def test_onboarding_without_llm_creates_no_world_or_gui(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = dict(os.environ)
            os.environ["AI_THEATER_API_KEY"] = ""
            os.environ["AI_THEATER_ENABLE_LIVE_API"] = "false"
            os.environ["AI_THEATER_DATA_DIR"] = directory
            server = create_server(host="127.0.0.1", port=0)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                base_url = f"http://127.0.0.1:{server.server_port}"
                payload = json.dumps({
                    "description": "一个未指定类型、仅记录状态变化的世界",
                    "characters": [],
                    "use_llm": False,
                }).encode("utf-8")
                req = request.Request(
                    f"{base_url}/api/onboarding",
                    data=payload,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                created = json.loads(request.urlopen(req, timeout=10).read())
                self.assertFalse(created["ok"])
                self.assertEqual(created["error_code"], "llm_required")

                with self.assertRaises(error.HTTPError) as caught:
                    request.urlopen(
                        f"{base_url}/api/world/gui?world_id={quote('not-created')}",
                        timeout=10,
                    )
                self.assertEqual(caught.exception.code, 404)
                loaded = json.loads(caught.exception.read())
                self.assertFalse(loaded["ok"])
            finally:
                server.shutdown()
                server.server_close()
                os.environ.clear()
                os.environ.update(previous)


if __name__ == "__main__":
    unittest.main()
