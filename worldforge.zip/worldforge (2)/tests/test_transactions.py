"""Tests for the state-transaction component (spec §8.1, §8.4, §15.6, §13.2).

覆盖：
  - apply 影子不污染 base
  - commit 转正、rollback 丢弃
  - llm_adjudication 无 ref → raise
  - prerequisites_checked 为空 → raise
  - 嵌套事务/多变更
  - 可复现性：同序列 apply+commit 产出相同状态
"""

from __future__ import annotations

import copy
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.transactions import (  # noqa: E402
    StateChange,
    StateTransaction,
    StateTransactionError,
)


# -- helpers -----------------------------------------------------------------

def _seed_state() -> dict:
    return {
        "civilization": {
            "tech_level": 3,
            "population": 1_000_000,
        },
        "resources": {"iron": 100, "gold": 5},
        "flags": {"civil_war": False},
    }


def _kernel_change(**kw) -> StateChange:
    return StateChange.new(
        origin="kernel",
        changes=[{"path": "civilization.tech_level", "op": "set", "value": 4}],
        prerequisites_checked=["dag:gravity_law"],
        speculative=True,
        **kw,
    )


# -- 影子不污染 base ----------------------------------------------------------

def test_apply_shadow_does_not_mutate_base():
    base = _seed_state()
    txn = StateTransaction(base).begin()
    txn.apply(_kernel_change())
    # 影子活跃期间 base 不变
    assert base == _seed_state()
    # snapshot() 取 base_state（commit 前 base 未变）
    assert txn.snapshot() == _seed_state()
    # commit 后 base 反映变更；commit 是原地写，标识保留
    committed = txn.commit()
    assert committed["civilization"]["tech_level"] == 4
    assert base is committed


# -- commit / rollback --------------------------------------------------------

def test_commit_promotes_shadow():
    base = _seed_state()
    txn = StateTransaction(base).begin()
    txn.apply(_kernel_change())
    new = txn.commit()
    assert new["civilization"]["tech_level"] == 4
    assert base is new  # commit 原地写，base 标识保留


def test_rollback_discards_shadow():
    base = _seed_state()
    txn = StateTransaction(base).begin()
    txn.apply(_kernel_change())
    kept = txn.rollback()
    assert kept["civilization"]["tech_level"] == 3
    assert base == _seed_state()


def test_apply_after_commit_raises():
    base = _seed_state()
    txn = StateTransaction(base).begin()
    txn.commit()
    with pytest.raises(StateTransactionError):
        txn.apply(_kernel_change())


def test_double_begin_resets_shadow():
    base = _seed_state()
    txn = StateTransaction(base).begin()
    txn.apply(_kernel_change())
    # 第二轮 begin：上一轮的影子丢失
    txn.begin()
    assert txn.snapshot() == _seed_state()


# -- §15.6 校验 ---------------------------------------------------------------

def test_llm_adjudication_without_ref_raises():
    txn = StateTransaction(_seed_state()).begin()
    bad = StateChange.new(
        origin="llm_adjudication",
        changes=[{"path": "civilization.tech_level", "op": "set", "value": 5}],
        prerequisites_checked=["dag:gravity_law"],
        # adjudication_ref 故意缺省
    )
    with pytest.raises(StateTransactionError) as ei:
        txn.apply(bad)
    assert "adjudication_ref" in str(ei.value)


def test_llm_adjudication_with_ref_ok():
    base = _seed_state()
    txn = StateTransaction(base).begin()
    good = StateChange.new(
        origin="llm_adjudication",
        changes=[{"path": "flags.civil_war", "op": "set", "value": True}],
        prerequisites_checked=["conservation:resources"],
        adjudication_ref="llm_output_log:42",
    )
    txn.apply(good)
    new = txn.commit()
    assert new["flags"]["civil_war"] is True


def test_prerequisites_checked_required():
    txn = StateTransaction(_seed_state()).begin()
    bad = StateChange.new(
        origin="kernel",
        changes=[{"path": "civilization.tech_level", "op": "set", "value": 4}],
        prerequisites_checked=[],  # I3 拒绝
    )
    with pytest.raises(StateTransactionError) as ei:
        txn.apply(bad)
    assert "prerequisites_checked" in str(ei.value)


def test_empty_changes_raises():
    txn = StateTransaction(_seed_state()).begin()
    bad = StateChange.new(
        origin="kernel",
        changes=[],
        prerequisites_checked=["dag:gravity_law"],
    )
    with pytest.raises(StateTransactionError):
        txn.apply(bad)


def test_unknown_op_raises():
    txn = StateTransaction(_seed_state()).begin()
    bad = StateChange.new(
        origin="kernel",
        changes=[{"path": "civilization.tech_level", "op": "fly", "value": 9}],
        prerequisites_checked=["dag:gravity_law"],
    )
    with pytest.raises(StateTransactionError):
        txn.apply(bad)


# -- 嵌套事务 / 多变更 -------------------------------------------------------

def test_nested_transactions_independent():
    """嵌套：从同一 base 派生两个独立事务。
    begin() 取的是 base 在那一刻的深拷贝，因此两个事务的影子互不污染。
    这是"快照点"语义——每个事务对自己的 begin 时刻负责。"""
    base = _seed_state()
    outer = StateTransaction(base).begin()
    outer.apply(_kernel_change())  # tech_level -> 4 (speculative)
    inner = StateTransaction(base).begin()
    inner.apply(StateChange.new(
        origin="rule_engine",
        changes=[{"path": "resources.iron", "op": "set", "value": 999}],
        prerequisites_checked=["conservation:resources"],
    ))
    inner.commit()
    # inner 已落 base
    assert base["resources"]["iron"] == 999
    # outer 影子仍是 begin 时的快照
    assert outer.pending_changes
    new = outer.commit()
    # outer's shadow 是 begin 时的深拷贝，resources.iron 仍是 100
    assert new["civilization"]["tech_level"] == 4
    assert new["resources"]["iron"] == 100


def test_multiple_changes_in_one_state_change():
    txn = StateTransaction(_seed_state()).begin()
    txn.apply(StateChange.new(
        origin="kernel",
        changes=[
            {"path": "civilization.tech_level", "op": "set", "value": 5},
            {"path": "resources.gold", "op": "set", "value": 0},
            {"path": "flags.civil_war", "op": "set", "value": True},
        ],
        prerequisites_checked=["dag:gravity_law", "conservation:resources"],
    ))
    new = txn.commit()
    assert new["civilization"]["tech_level"] == 5
    assert new["resources"]["gold"] == 0
    assert new["flags"]["civil_war"] is True


def test_delete_op():
    txn = StateTransaction(_seed_state()).begin()
    txn.apply(StateChange.new(
        origin="rule_engine",
        changes=[{"path": "flags.civil_war", "op": "delete"}],
        prerequisites_checked=["conservation:resources"],
    ))
    new = txn.commit()
    assert "civil_war" not in new["flags"]


def test_deep_path_creates_intermediate_dicts():
    base = {"a": {}}
    txn = StateTransaction(base).begin()
    txn.apply(StateChange.new(
        origin="kernel",
        changes=[{"path": "a.b.c.d", "op": "set", "value": 1}],
        prerequisites_checked=["x"],
    ))
    new = txn.commit()
    assert new["a"]["b"]["c"]["d"] == 1


def test_snapshot_is_deep_copy():
    base = _seed_state()
    txn = StateTransaction(base).begin()
    snap = txn.snapshot()
    snap["civilization"]["tech_level"] = 99
    # base 不被影响
    assert base["civilization"]["tech_level"] == 3


# -- 可复现性 -----------------------------------------------------------------

def test_reproducibility_same_sequence_same_state():
    base_a = _seed_state()
    base_b = _seed_state()
    seq = [
        StateChange.new(
            origin="kernel",
            changes=[{"path": "civilization.tech_level", "op": "set", "value": 4}],
            prerequisites_checked=["dag:gravity_law"],
        ),
        StateChange.new(
            origin="rule_engine",
            changes=[{"path": "resources.iron", "op": "set", "value": 50}],
            prerequisites_checked=["conservation:resources"],
        ),
        StateChange.new(
            origin="llm_adjudication",
            changes=[{"path": "flags.civil_war", "op": "set", "value": True}],
            prerequisites_checked=["conservation:resources"],
            adjudication_ref="llm_output_log:7",
        ),
    ]
    t_a = StateTransaction(base_a).begin()
    t_b = StateTransaction(base_b).begin()
    for ca, cb in zip(seq, seq):
        t_a.apply(ca)
        t_b.apply(cb)
    # txn_id 是 uuid，不应影响逻辑状态——但必须仍然产出相同 state
    out_a = t_a.commit()
    out_b = t_b.commit()
    assert out_a == out_b


def test_reproducibility_speculative_commit_then_more():
    base_a = _seed_state()
    base_b = _seed_state()
    seq_spec = [
        StateChange.new(
            origin="kernel",
            changes=[{"path": "civilization.tech_level", "op": "set", "value": 5}],
            prerequisites_checked=["dag:gravity_law"],
            speculative=True,
        ),
    ]
    seq_after = [
        StateChange.new(
            origin="rule_engine",
            changes=[{"path": "resources.gold", "op": "set", "value": 0}],
            prerequisites_checked=["conservation:resources"],
        ),
    ]
    for sa, sb in zip(seq_spec, seq_spec):
        ta = StateTransaction(base_a).begin(); tb = StateTransaction(base_b).begin()
        ta.apply(sa); tb.apply(sb)
        ta.commit(); tb.commit()
        for aa, bb in zip(seq_after, seq_after):
            ta2 = StateTransaction(base_a).begin(); tb2 = StateTransaction(base_b).begin()
            ta2.apply(aa); tb2.apply(bb)
            ta2.commit(); tb2.commit()
    assert base_a == base_b


# -- 非投机直接落 base（与 §15.6 speculative 默认路径对称） -------------------

def test_non_speculative_apply_writes_directly():
    base = _seed_state()
    txn = StateTransaction(base).begin()
    txn.apply(StateChange.new(
        origin="user_action",
        changes=[{"path": "civilization.tech_level", "op": "set", "value": 7}],
        prerequisites_checked=["user_input_validated"],
        speculative=False,
    ))
    # 非投机变更走 base
    assert base["civilization"]["tech_level"] == 7
    txn.commit()  # 不应丢东西


# -- pending_changes 用于审计 -------------------------------------------------

def test_pending_changes_records_for_audit():
    txn = StateTransaction(_seed_state()).begin()
    c = _kernel_change()
    txn.apply(c)
    assert txn.pending_changes == [c]
    txn.commit()
    assert txn.pending_changes == []