"""P2 — 张力7 + P3 — 张力6: stance switch + constraint-type labelling +
degraded flag.

张力7: onboarding ended by jumping straight to world_gui tick with no stance
switch. LLM-authored rules entered the simulation as one-size-fits-all
immutable, even though §10.1 distinguishes constitutive (immutable) from
content (evolvable) constraints.

张力6: degraded state had no uniform marker — scattered source:preset flags.

Fixes pinned here:
  * onboarding stage 4 emits stance="guest" + stance_message (生成→模拟 boundary)
  * narrative stage carries constraint_type (§10.1) from classify_constraint_type
  * top-level result carries a single `degraded` bool
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.onboarding import OnboardingFlow  # noqa: E402
from theater.settings import Settings  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402
from theater.world_kernel_host import classify_constraint_type  # noqa: E402


def _build_orchestrator(root: Path) -> TheaterOrchestrator:
    settings = Settings(data_dir=root, enable_live_api=False)
    return TheaterOrchestrator(
        state_store=JsonStateStore(root / "state"),
        model_client=DeterministicModelClient(),
        settings=settings,
    )


@pytest.fixture
def tmp_root(tmp_path):
    return tmp_path


# ---------------------------------------------------------------------------
# classify_constraint_type (§10.1)
# ---------------------------------------------------------------------------


def test_physical_world_type_does_not_implicitly_set_constraint_policy():
    assert classify_constraint_type("physical") == "content"


def test_three_body_world_type_does_not_implicitly_set_constraint_policy():
    assert classify_constraint_type("three_body") == "content"
    assert classify_constraint_type("three-body") == "content"
    assert classify_constraint_type("anything", "constitutive") == "constitutive"


def test_classify_economy_is_content():
    assert classify_constraint_type("economy") == "content"


def test_classify_social_simulation_cardgame_are_content():
    assert classify_constraint_type("social") == "content"
    assert classify_constraint_type("simulation") == "content"
    assert classify_constraint_type("card_game") == "content"


def test_classify_case_insensitive():
    assert classify_constraint_type("Economy") == "content"
    assert classify_constraint_type("PHYSICAL") == "content"
    assert classify_constraint_type("anything", "CONSISTENCY") == "consistency"


def test_classify_empty_is_content():
    assert classify_constraint_type("") == "content"


# ---------------------------------------------------------------------------
# onboarding stage 4: stance switch + constraint type
# ---------------------------------------------------------------------------


def test_onboarding_without_llm_blocks_before_narrative_handoff(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("一个经济世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"
    assert "narrative" not in result["stages"]


def test_onboarding_without_llm_does_not_infer_constraint_type(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("一个经济世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"
    assert result["stages"] == {}


def test_onboarding_without_llm_does_not_route_physics_to_a_preset(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    # "物理世界" routes to the physical preset (keyword '物理'/'gravity').
    result = flow.run("物理与引力的世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"
    assert result["stages"] == {}


def test_onboarding_without_llm_does_not_create_a_three_body_world(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("三体世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"
    assert result["world_id"] == ""


# ---------------------------------------------------------------------------
# 张力6: degraded flag
# ---------------------------------------------------------------------------


def test_onboarding_without_llm_has_no_degraded_success_result(tmp_root):
    """No-model creation is blocked rather than reported as degraded success."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("一个经济世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"
    assert "degraded" not in result


def test_degraded_flag_false_on_clean_llm_run(tmp_root):
    """A fully-LLM run with no warnings and no preset fallback → not degraded."""
    import json as _json
    rule_json = _json.dumps({
        "world_type": "economy",
        "rules": [{
            "rule_id": "produce", "kind": "dynamic", "trigger": "turn.tick",
            "effect": {"writes": "supply", "value": {"op": "add",
                      "args": [{"ref": "supply"}, {"const": 1}]}},
            "priority": 30,
        }],
        "params": {"seed": 42},
        "initial_state": {"supply": 10},
    })

    class _LLM:
        def as_text_fn(self, temperature=0.2, max_tokens=2048):
            def _fn(prompt):
                if "gameplay rule compiler" in prompt:
                    return _json.dumps({
                        "name": "countdown", "description": "bounded test gameplay",
                        "state_schema": {"count": 10, "turn": 0},
                        "legal_actions": [{"id": "dec", "condition": {"op": "gt", "args": [{"ref": "count"}, {"const": 0}]}}],
                        "terminal": {"op": "or", "args": [
                            {"op": "le", "args": [{"ref": "count"}, {"const": 0}]},
                            {"op": "ge", "args": [{"ref": "turn"}, {"const": 50}]},
                        ]},
                        "payoff": {"op": "ref", "path": "turn"},
                        "apply": {"dec": {"writes": [
                            {"path": "count", "value": {"op": "sub", "args": [{"ref": "count"}, {"const": 1}]}},
                            {"path": "turn", "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
                        ]}},
                    })
                return rule_json
            return _fn

        def as_dict_fn(self, temperature=0.4, max_tokens=2048):
            def _fn(w):
                if "世界设计架构师" in w:
                    return {
                        "world_type": "test_economy", "seed": 42, "lambda": 0.5,
                        "initial_state": {"supply": 10},
                    }
                return {"gui_spec_id": "g", "world_id": "w",
                        "layout_type": "dashboard",
                        "grid": {"columns": "1fr", "areas": ["main"]},
                        "widgets": [{"id": "r", "type": "text", "area": "main",
                                     "binds": {"read": "kernel:k"}}]}
            return _fn

    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_LLM(),
    )
    # Provide a character so stage2 doesn't skip (which would itself degrade).
    result = flow.run(
        "一个经济世界",
        characters=[{"mode": "manual", "fields": {"name": "旅者"}}],
        use_llm=True,
    )
    assert result["degraded"] is False
    assert result["stages"]["rules"]["source"] == "llm"
    assert result["stages"]["gui"]["source"] == "llm"


def test_onboarding_without_llm_returns_no_degraded_warning_path(tmp_root):
    """No-model creation never reaches a warning-based degraded path."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("一个经济世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"
    assert result["warnings"] == []
