import json
import os
import tempfile
import threading
import unittest
from urllib import request

from theater.agents import DeterministicModelClient
from theater.server import create_server


class BridgeEndpointTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.previous = dict(os.environ)
        # The server's production gate remains enabled while the model itself
        # is an explicit test double below.
        os.environ["AI_THEATER_ENABLE_LIVE_API"] = "true"
        # Default is the local Spark qwen3-coder endpoint; pin cloud models so
        # the alias-exposure assertions below remain meaningful.
        os.environ["AI_THEATER_API_KEY"] = "test-key"
        os.environ["AI_THEATER_BASE_URL"] = "http://127.0.0.1:1/v1"
        os.environ["AI_THEATER_MODEL_FAST"] = "gpt5.4"
        os.environ["AI_THEATER_MODEL_DEEP"] = "gpt5.5"
        os.environ["AI_THEATER_DATA_DIR"] = self.directory.name
        self.server = create_server(host="127.0.0.1", port=0)
        # This suite exercises the HTTP bridge rather than provider failure
        # handling, so install an explicit test stub. Production never does.
        self.server.orchestrator.model_client = DeterministicModelClient()
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        os.environ.clear()
        os.environ.update(self.previous)
        self.directory.cleanup()

    def post_json(self, path, payload):
        req = request.Request(
            f"{self.base_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        return json.loads(request.urlopen(req, timeout=5).read())

    def test_openai_compatible_chat_returns_task_manifest_as_assistant_content(self):
        body = self.post_json(
            "/v1/chat/completions",
            {"model": "gpt5.5", "messages": [{"role": "user", "content": "生成档案馆场景"}]},
        )

        self.assertEqual(body["object"], "chat.completion")
        content = json.loads(body["choices"][0]["message"]["content"])
        self.assertTrue(content["tasks"])
        self.assertEqual(content["model_trace"]["model_deep"], "gpt5.5")
        self.assertEqual(content["model_trace"]["provider_model_deep"], "gpt-5.5")

    def test_provider_diagnostics_endpoint_exposes_aliases_without_secret(self):
        body = json.loads(request.urlopen(f"{self.base_url}/api/provider/diagnostics", timeout=5).read())

        self.assertEqual(body["model_fast"], "gpt5.4")
        self.assertEqual(body["provider_model_fast"], "gpt-5.4")
        self.assertNotIn("sk-", json.dumps(body))


if __name__ == "__main__":
    unittest.main()
