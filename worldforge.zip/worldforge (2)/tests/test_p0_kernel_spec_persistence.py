"""P0 — compiled WorldKernelSpec persistence across processes / orchestrator instances.

Before this fix, :meth:`TheaterOrchestrator.register_world_kernel` stored the
``WorldKernelSpec`` only in the instance-memory ``_world_kernel_hosts`` dict.
A new orchestrator instance (new process, e.g. CLI ``--onboard`` then
``--tick``) saw an empty registry, so the LLM-authored DSL rules never fired
again — "立法颁布一拍即失效".

These tests pin the on-disk source-of-truth fix:

  * ``WorldKernelSpec.to_dict`` / ``from_dict`` round-trip losslessly.
  * ``register_world_kernel`` writes the spec to ``kernel_<world_id>.json``.
  * a fresh orchestrator instance recovers the spec on ``set_world``.
  * ``world_tick`` on the fresh instance actually fires the DSL rules.
  * unregistered worlds still tick without crashing (empty state).
  * the CLI ``cmd_tick`` routes a DSL world to ``world_tick`` and a three-body
    world to ``three_body_tick`` (§8.2 red line preserved).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict

import pytest

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.onboarding import OnboardingFlow  # noqa: E402
from theater.settings import Settings  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402
from theater.world_creation import WorldCreator, WorldProposal  # noqa: E402
from theater.world_kernel_host import (  # noqa: E402
    DENY_WRITES_DEFAULT,
    RuleCompiler,
    WorldKernelSpec,
    WorldRule,
)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

_RULE_JSON = json.dumps({
    "world_type": "economy",
    "rules": [
        {
            "rule_id": "production_each_turn",
            "kind": "dynamic",
            "trigger": "turn.tick",
            "effect": {"writes": "supply", "op": "add",
                       "value": {"op": "add", "args": [
                           {"ref": "supply"}, {"ref": "production_rate"}]}},
            "description": "每回合按产能增加供给",
            "priority": 30,
        },
    ],
    "params": {"seed": 42},
    "initial_state": {"supply": 100, "production_rate": 8.0},
})

_GAMEPLAY_JSON = json.dumps({
    "name": "countdown", "description": "bounded test gameplay",
    "state_schema": {"count": 10, "turn": 0},
    "legal_actions": [{"id": "dec", "condition": {"op": "gt", "args": [{"ref": "count"}, {"const": 0}]}}],
    "terminal": {"op": "or", "args": [
        {"op": "le", "args": [{"ref": "count"}, {"const": 0}]},
        {"op": "ge", "args": [{"ref": "turn"}, {"const": 50}]},
    ]},
    "payoff": {"op": "ref", "path": "turn"},
    "apply": {"dec": {"writes": [
        {"path": "count", "value": {"op": "sub", "args": [{"ref": "count"}, {"const": 1}]}},
        {"path": "turn", "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
    ]}},
})


class _FakeLLMClient:
    def __init__(self, rule_text: str = _RULE_JSON):
        self._rule_text = rule_text

    def as_text_fn(self, temperature=0.2, max_tokens=2048):
        def _fn(prompt: str) -> str:
            return _GAMEPLAY_JSON if "gameplay rule compiler" in prompt else self._rule_text
        return _fn

    def as_dict_fn(self, temperature=0.4, max_tokens=2048):
        def _fn(prompt: str) -> Dict[str, Any]:
            if "世界设计架构师" in prompt:
                return {
                    "world_type": "economy",
                    "seed": 42,
                    "lambda": 0.5,
                    "initial_state": {"supply": 100, "production_rate": 8.0},
                }
            return {
                "gui_spec_id": "llm_test", "world_id": "test_world",
                "layout_type": "dashboard",
                "grid": {"columns": "1fr", "areas": ["main"]},
                "widgets": [{"id": "readout", "type": "text", "area": "main",
                             "binds": {"read": "kernel:tick"}}],
            }
        return _fn


def _build_orchestrator(root: Path) -> TheaterOrchestrator:
    settings = Settings(data_dir=root, enable_live_api=False)
    return TheaterOrchestrator(
        state_store=JsonStateStore(root / "state"),
        model_client=DeterministicModelClient(),
        settings=settings,
    )


def _patch_cli_with_runtime_model(monkeypatch, cli) -> None:
    """Give CLI ticks an explicit local model stub; no provider fallback."""
    def _build(world_id: str) -> TheaterOrchestrator:
        settings = Settings(data_dir=cli.STATE_ROOT, enable_live_api=False)
        return TheaterOrchestrator(
            state_store=JsonStateStore(cli.STATE_ROOT, world_id=world_id),
            model_client=DeterministicModelClient(),
            settings=settings,
        )

    monkeypatch.setattr(cli, "_build_orchestrator", _build)


def _economy_spec() -> WorldKernelSpec:
    return WorldKernelSpec(
        world_type="economy",
        rules=[
            WorldRule(rule_id="production_each_turn", kind="dynamic",
                      trigger="turn.tick",
                      effect={"writes": "supply", "op": "add",
                              "value": {"op": "add", "args": [
                                  {"ref": "supply"},
                                  {"ref": "production_rate"}]}},
                      description="每回合按产能增加供给", priority=30),
        ],
        params={"seed": 42},
        initial_state={"supply": 100, "production_rate": 8.0},
    )


@pytest.fixture
def tmp_root(tmp_path):
    return tmp_path


# ===========================================================================
# 1. serialization round-trip
# ===========================================================================


def test_world_rule_to_dict_from_dict_roundtrip(tmp_root):
    rule = WorldRule(
        rule_id="r1", kind="dynamic", trigger="turn.tick",
        condition={"op": "gt", "args": [{"ref": "x"}, {"const": 0}]},
        effect={"writes": "x", "op": "set", "value": {"const": 1}},
        description="d", deny_writes=("sealed.",), priority=5, enabled=False,
    )
    rt = WorldRule.from_dict(rule.to_dict())
    assert rt.rule_id == rule.rule_id
    assert rt.kind == rule.kind
    assert rt.trigger == rule.trigger
    assert rt.condition == rule.condition
    assert rt.effect == rule.effect
    assert rt.deny_writes == rule.deny_writes
    assert rt.priority == rule.priority
    assert rt.enabled is False


def test_world_kernel_spec_to_dict_from_dict_roundtrip(tmp_root):
    spec = _economy_spec()
    spec.constraint_type = "consistency"
    spec.enabled_kernels = ["main"]
    spec.deny_writes = DENY_WRITES_DEFAULT + ("sealed.",)
    rt = WorldKernelSpec.from_dict(spec.to_dict())
    assert rt.world_type == spec.world_type
    assert rt.constraint_type == "consistency"
    assert rt.params == spec.params
    assert rt.initial_state == spec.initial_state
    assert rt.enabled_kernels == spec.enabled_kernels
    assert rt.deny_writes == spec.deny_writes
    assert [r.rule_id for r in rt.rules] == [r.rule_id for r in spec.rules]
    # JSON-serializable (on-disk persistence requires this)
    json.dumps(spec.to_dict())


def test_world_kernel_spec_from_dict_tolerates_missing_optional_fields():
    # Minimal dict — only world_type + rules required shape.
    minimal = {"world_type": "economy", "rules": [
        {"rule_id": "r1", "kind": "dynamic", "trigger": "turn.tick",
         "effect": {"writes": "x", "value": {"const": 1}}}]}
    spec = WorldKernelSpec.from_dict(minimal)
    assert spec.world_type == "economy"
    assert spec.constraint_type == "content"
    assert spec.params == {}
    assert spec.initial_state == {}
    assert spec.deny_writes == DENY_WRITES_DEFAULT
    assert spec.rules[0].enabled is True  # default


# ===========================================================================
# 2. register_world_kernel persists to disk
# ===========================================================================


def test_register_world_kernel_writes_kernel_file(tmp_root):
    orch = _build_orchestrator(tmp_root)
    orch.set_world("econ")
    spec = _economy_spec()
    orch.register_world_kernel("econ", spec)
    store = orch._world_store("econ")
    assert store.kernel_path.exists(), "kernel_<world_id>.json not written"
    raw = store.load_world_kernel_spec()
    assert raw is not None
    assert raw["world_type"] == "economy"
    assert raw["initial_state"]["supply"] == 100


def test_register_world_kernel_rejects_invalid_spec_no_file(tmp_root):
    orch = _build_orchestrator(tmp_root)
    bad = WorldKernelSpec(
        world_type="economy",
        rules=[WorldRule(rule_id="", kind="dynamic", trigger="turn.tick")],
    )
    with pytest.raises(ValueError):
        orch.register_world_kernel("main", bad)
    # No file should be written on rejection.
    assert not orch.state_store.kernel_path.exists()


# ===========================================================================
# 3. a fresh orchestrator instance recovers the spec
# ===========================================================================


def test_new_orchestrator_loads_spec_on_set_world(tmp_root):
    # First instance: register the kernel.
    orch1 = _build_orchestrator(tmp_root)
    orch1.set_world("econ")
    orch1.register_world_kernel("econ", _economy_spec())

    # Fresh instance sharing the same state root: must reload from disk.
    orch2 = _build_orchestrator(tmp_root)
    assert "econ" not in orch2._world_kernel_hosts  # not cached yet
    orch2.set_world("econ")
    spec = orch2.get_world_kernel_spec("econ")
    assert spec is not None
    assert spec.world_type == "economy"
    assert spec.initial_state["supply"] == 100
    assert "econ" in orch2._world_kernel_hosts


def test_new_orchestrator_world_tick_fires_loaded_rules(tmp_root):
    """Cross-instance end-to-end: register in process A → tick in process B."""
    orch1 = _build_orchestrator(tmp_root)
    orch1.set_world("econ")
    orch1.register_world_kernel("econ", _economy_spec())

    orch2 = _build_orchestrator(tmp_root)
    orch2.set_world("econ")
    # No host built yet — state empty before first tick.
    assert orch2.get_world_kernel_state("econ") == {}
    orch2.world_tick(session_id="test")
    state = orch2.get_world_kernel_state("econ")
    assert state["supply"] == 108.0  # 100 + 8 production_rate
    # The kernel event landed in the worldbook.
    entries = orch2.state_store.snapshot().worldbook
    kernel_entries = [e for e in entries if e.source == "world_kernel_tick"]
    assert kernel_entries
    assert "supply" in kernel_entries[-1].content


def test_onboarding_then_fresh_orchestrator_sees_registered_spec(tmp_root):
    """Real onboarding flow → new orchestrator instance recovers the spec."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run("一个供需经济世界", characters=[], use_llm=True)
    assert result["stages"]["rules"]["registered"] is True
    wid = result["world_id"]

    fresh = _build_orchestrator(tmp_root)
    fresh.set_world(wid)
    spec = fresh.get_world_kernel_spec(wid)
    assert spec is not None
    assert spec.world_type == "economy"
    # Tick on the fresh instance fires the recovered rules.
    fresh.world_tick(session_id="test")
    assert fresh.get_world_kernel_state(wid)["supply"] == 108.0


# ===========================================================================
# 4. unregistered worlds: no crash, empty state
# ===========================================================================


def test_unregistered_world_world_tick_no_crash(tmp_root):
    orch = _build_orchestrator(tmp_root)
    orch.set_world("empty")
    assert orch.get_world_kernel_spec("empty") is None
    assert orch.get_world_kernel_state("empty") == {}
    orch.world_tick(session_id="test")
    # No kernel fact recorded.
    entries = orch.state_store.snapshot().worldbook
    assert not [e for e in entries if e.source == "world_kernel_tick"]


def test_load_world_kernel_spec_returns_none_when_file_missing(tmp_root):
    orch = _build_orchestrator(tmp_root)
    orch.set_world("ghost")
    assert orch._load_world_kernel_spec("ghost") is None
    assert orch.get_world_kernel_state("ghost") == {}


# ===========================================================================
# 5. CLI routing: cmd_tick routes DSL worlds to world_tick
# ===========================================================================


def test_cmd_tick_routes_dsl_world_to_world_tick(tmp_root, monkeypatch):
    """An economy world with a persisted spec runs the DSL tick path."""
    # Pre-register the kernel via onboarding so the file exists.
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run("一个供需经济世界", characters=[], use_llm=True)
    wid = result["world_id"]

    # Now run cmd_tick as a fresh process would: build a fresh orchestrator.
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root / "runtime_state")
    _patch_cli_with_runtime_model(monkeypatch, cli)
    # Repoint the world's state into the monkeypatched root by re-registering
    # there (simulates the onboarding file living under STATE_ROOT).
    fresh_root = tmp_root / "runtime_state"
    WorldCreator.create(
        WorldProposal(world_id=wid, world_params={"enabled_kernels": []}),
        fresh_root,
    )
    orch = cli._build_orchestrator(wid)
    orch.register_world_kernel(wid, _economy_spec())

    rc = cli.cmd_tick("一个供需经济世界", tech=None)
    assert rc == 0


def test_cmd_tick_three_body_requires_live_narration_llm(tmp_root, monkeypatch, capsys):
    """The adapter path blocks explicitly when its narration LLM is unavailable."""
    import worldforge as cli
    state_root = tmp_root / "tb_state"
    monkeypatch.setattr(cli, "STATE_ROOT", state_root)
    _patch_cli_with_runtime_model(monkeypatch, cli)
    WorldCreator.create(
        WorldProposal(
            world_id="三体世界",
            world_params={"seed": 7, "enabled_kernels": ["three_body"]},
        ),
        state_root,
    )
    rc = cli.cmd_tick("三体世界", tech=1.0)
    assert rc == 2
    assert "本拍叙事需要可用的 LLM" in capsys.readouterr().err


def test_cmd_tick_rejects_a_world_without_llm_authored_rules(tmp_root, monkeypatch):
    """A name never enables an adapter or installs generic replacement rules."""
    import worldforge as cli
    state_root = tmp_root / "generic_named_state"
    monkeypatch.setattr(cli, "STATE_ROOT", state_root)
    WorldCreator.create(
        WorldProposal(
            world_id="三体世界",
            world_params={"seed": 42, "enabled_kernels": []},
        ),
        state_root,
    )

    rc = cli.cmd_tick("三体世界", tech=None)
    assert rc == 2
    stored = JsonStateStore(state_root, world_id="三体世界")
    spec = stored.load_world_kernel_spec()
    assert spec is None


# ===========================================================================
# 6. compiled-spec re-compile after reload (rules still valid)
# ===========================================================================


def test_reloaded_spec_still_compiles(tmp_root):
    orch = _build_orchestrator(tmp_root)
    orch.set_world("econ")
    spec = _economy_spec()
    orch.register_world_kernel("econ", spec)

    fresh = _build_orchestrator(tmp_root)
    fresh.set_world("econ")
    reloaded = fresh.get_world_kernel_spec("econ")
    # The reloaded spec must still pass static validation + compile.
    issues = RuleCompiler().validate_spec(reloaded)
    assert issues == []
    compiled = RuleCompiler().compile(reloaded)
    assert len(compiled.rules) == len(spec.rules)
