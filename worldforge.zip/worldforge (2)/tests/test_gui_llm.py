"""Tests for the LLM-driven GUI generation path (gui_generator.generate).

Covers:
  - Mock LLM returns a valid GUISpec → generation parses + normalises +
    validates cleanly.
  - Unknown layout/widget/binding values fail the validation gate.
  - LLM reply is unparseable garbage fails explicitly.
  - No ``llm_fn`` at all fails explicitly.
  - ``_build_gui_system_prompt``, ``_parse_llm_gui``, ``_normalize_gui_spec``
    work as primitives that downstream code can compose with.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional

import pytest

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from theater.gui_generator import (
    ALLOWED_ACTIONS,
    ALLOWED_INTENT_KINDS,
    ALLOWED_LAYOUT_TYPES,
    ALLOWED_WIDGET_TYPES,
    GUIGenerator,
    GUISpec,
    WidgetSpec,
    _build_gui_system_prompt,
    _coerce_spec,
    _normalize_gui_spec,
    _normalize_widget,
    _parse_llm_gui,
    validate_gui_spec,
)


# ---------------------------------------------------------------------------
# Test fixtures — a "well-formed" LLM reply from a hypothetical model.
# ---------------------------------------------------------------------------

def _valid_payload(world_style: str = "edge_city") -> Dict[str, Any]:
    """A well-formed LLM reply for an 'edge city' world (terminal layout)."""
    return {
        "gui_spec_id": "llm_edge_city",
        "world_id": "edge_city",
        "layout_type": "terminal",
        "chrome": "crt_scanline",
        "grid": {
            "columns": "2fr 1fr",
            "rows": "auto 1fr auto",
            "areas": ["netmap ice", "netmap hack", "cmdline cmdline"],
        },
        "icon_style": "line_terminal",
        "motion": "glitch",
        "typography": {"display": "IBM Plex Mono", "mono": "IBM Plex Mono",
                       "case": "upper"},
        "color_scheme": {"bg_role": 0, "panel_role": 1, "ink_role": 14,
                         "accent_role": 9, "ok_role": 6, "warn_role": 11,
                         "danger_role": 4},
        "widgets": [
            {
                "id": "netmap",
                "type": "canvas_panel",
                "area": "netmap",
                "role": "panel",
                "title": "NET://GRID",
                "binds": {"read": "kernel:netmap"},
            },
            {
                "id": "cmd",
                "type": "text_field",
                "area": "cmdline",
                "role": "accent",
                "placeholder": "> run exploit",
                "binds": {"emit": "utterance"},
            },
            {
                "id": "exec",
                "type": "commit_bar",
                "area": "cmdline",
                "role": "warn",
                "label": "EXECUTE",
                "binds": {"emit": "decision_vector", "commit": True,
                           "action": "world/tick"},
            },
        ],
    }


# ---------------------------------------------------------------------------
# Mock-LLM end-to-end paths
# ---------------------------------------------------------------------------

def test_mock_llm_returns_valid_spec_parses_normally():
    """Mock LLM returns a well-formed dict → spec is generated cleanly."""
    payload = _valid_payload()

    def llm_fn(_world_style: str) -> Dict[str, Any]:
        return payload

    spec = GUIGenerator(llm_fn=llm_fn).generate("edge city neon noir")
    assert isinstance(spec, GUISpec)
    assert spec.gui_spec_id == "llm_edge_city"
    assert spec.layout_type == "terminal"
    widget_names = {w.name for w in spec.widgets}
    assert {"netmap", "cmd", "exec"} <= widget_names
    validate_gui_spec(spec)  # passes — central gate


def test_mock_llm_unknown_layout_fails_validation():
    payload = _valid_payload()
    payload["layout_type"] = "atlantis_octopus_grid"  # not in closed set

    def llm_fn(_world_style: str) -> Dict[str, Any]:
        return payload

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("潮汐湿地生态监测")


def test_mock_llm_unknown_widget_type_fails_validation():
    payload = _valid_payload()
    payload["widgets"][1]["type"] = "quantum_holo_input"

    def llm_fn(_world_style: str) -> Dict[str, Any]:
        return payload

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("edge city")


def test_mock_llm_emit_not_in_allowlist_fails_validation():
    payload = _valid_payload()
    payload["widgets"].append({
        "id": "evil_button",
        "type": "button",
        "area": "hack",
        "role": "accent",
        "label": "destroy world",
        "binds": {"emit": "delete_universe"},
    })

    def llm_fn(_world_style: str) -> Dict[str, Any]:
        return payload

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("edge city")


def test_mock_llm_action_not_in_allowlist_fails_validation():
    payload = _valid_payload()
    payload["widgets"].append({
        "id": "rce",
        "type": "commit_bar",
        "area": "cmdline",
        "role": "warn",
        "label": "PWN",
        "binds": {"emit": "decision_vector", "commit": True,
                   "action": "/etc/passwd"},
    })

    def llm_fn(_world_style: str) -> Dict[str, Any]:
        return payload

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("edge city")


def test_mock_llm_read_without_prefix_fails_validation():
    payload = _valid_payload()
    payload["widgets"].append({
        "id": "leak",
        "type": "canvas_panel",
        "area": "netmap",
        "role": "panel",
        "title": "leak",
        "binds": {"read": "ftp://host/secret"},
    })

    def llm_fn(_world_style: str) -> Dict[str, Any]:
        return payload

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("edge city")


def test_mock_llm_emit_and_read_together_is_preserved():
    """The validator permits a read/write widget; normalisation must not drop it."""
    payload = _valid_payload()
    payload["widgets"].append({
        "id": "ambiguous",
        "type": "slider",
        "area": "hack",
        "role": "accent",
        "label": "both",
        "binds": {"emit": "utterance", "read": "kernel:nonsense"},
    })

    def llm_fn(_world_style: str) -> Dict[str, Any]:
        return payload

    spec = GUIGenerator(llm_fn=llm_fn).generate("edge city")
    assert any(w.name == "ambiguous" for w in spec.widgets)
    validate_gui_spec(spec)


def test_mock_llm_garbage_string_fails():
    """LLM reply is unparseable text → explicit generation failure."""
    def llm_fn(_world_style: str) -> str:
        return "I'd love to help! Here is some prose instead of JSON ..."

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("regional transit network")


def test_mock_llm_json_with_code_fence_parses():
    """Common LLM habit of wrapping JSON in ```json ... ``` fences."""
    payload = _valid_payload()

    def llm_fn(_world_style: str) -> str:
        return "```json\n" + json.dumps(payload) + "\n```"

    spec = GUIGenerator(llm_fn=llm_fn).generate("edge city")
    assert spec.gui_spec_id == "llm_edge_city"
    assert spec.layout_type == "terminal"
    validate_gui_spec(spec)


def test_mock_llm_none_fails():
    """LLM returns None → explicit generation failure."""
    def llm_fn(_world_style: str) -> Optional[Dict[str, Any]]:
        return None

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("watershed council")


def test_no_llm_fn_fails():
    """No configured model cannot generate a semantic GUI."""
    with pytest.raises(RuntimeError, match="requires llm_fn"):
        GUIGenerator().generate("public records archive")


def test_per_call_llm_fn_overrides_constructor():
    """The ``llm_fn`` argument to ``generate`` overrides the constructor fn."""
    constructor_fn_called: Dict[str, int] = {"n": 0}
    per_call_fn_called: Dict[str, int] = {"n": 0}

    def constructor_fn(_world_style: str) -> Dict[str, Any]:
        constructor_fn_called["n"] += 1
        return _valid_payload()

    def per_call_fn(_world_style: str) -> Dict[str, Any]:
        per_call_fn_called["n"] += 1
        p = _valid_payload()
        p["gui_spec_id"] = "per_call_wins"
        return p

    spec = GUIGenerator(llm_fn=constructor_fn).generate(
        "edge city", llm_fn=per_call_fn
    )
    assert spec.gui_spec_id == "per_call_wins"
    assert constructor_fn_called["n"] == 0
    assert per_call_fn_called["n"] == 1


def test_llm_failure_path_fails_after_one_attempt():
    """Timeout/offline errors fail after one attempt; no substitute is used."""
    calls = {"count": 0}

    def llm_fn(_world_style: str) -> Dict[str, Any]:
        calls["count"] += 1
        raise RuntimeError("model offline / OOM / schema mismatch")

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("orbital resource planning")
    assert calls["count"] == 1


def test_invalid_gui_schema_is_reprompted_until_llm_repairs_it():
    """Schema-invalid model output is repaired by the model, never locally."""
    calls = {"count": 0, "prompts": []}

    def llm_fn(prompt: str) -> Dict[str, Any]:
        calls["count"] += 1
        calls["prompts"].append(prompt)
        if calls["count"] == 1:
            payload = _valid_payload()
            payload["grid"] = "not-an-object"
            return payload
        return _valid_payload()

    spec = GUIGenerator(llm_fn=llm_fn).generate("floating civic archive")
    assert spec.widgets
    assert calls["count"] == 2
    assert "layout.grid must be an object" in calls["prompts"][1]


def test_undeclared_widget_area_is_reprompted_not_locally_rewritten():
    calls = {"count": 0, "prompts": []}

    def llm_fn(prompt: str) -> Dict[str, Any]:
        calls["count"] += 1
        calls["prompts"].append(prompt)
        payload = _valid_payload()
        if calls["count"] == 1:
            payload["widgets"][0]["area"] = "invented_area"
        return payload

    spec = GUIGenerator(llm_fn=llm_fn).generate("floating civic archive")
    assert spec.widgets[0].area == "netmap"
    assert calls["count"] == 2
    assert "is not declared" in calls["prompts"][1]


# ---------------------------------------------------------------------------
# Unit tests for the helper primitives
# ---------------------------------------------------------------------------

def test_build_gui_system_prompt_lists_closed_sets():
    """The system prompt enumerates every closed vocabulary — proves the
    LLM is told exactly what tokens it may emit.
    """
    prompt = _build_gui_system_prompt()
    assert "JSON" in prompt
    for token in ALLOWED_INTENT_KINDS:
        assert token in prompt
    for token in ALLOWED_LAYOUT_TYPES:
        assert token in prompt
    for token in ALLOWED_WIDGET_TYPES:
        assert token in prompt
    for token in ALLOWED_ACTIONS:
        assert token in prompt
    assert "kernel:" in prompt
    assert "state:" in prompt


def test_parse_llm_gui_accepts_dict():
    assert _parse_llm_gui({"a": 1}) == {"a": 1}


def test_parse_llm_gui_accepts_json_string():
    assert _parse_llm_gui('{"layout_type": "terminal"}') == {
        "layout_type": "terminal"
    }


def test_parse_llm_gui_strips_code_fence():
    blob = "noise before\n```json\n{\"k\": 2}\n```\nnoise after"
    assert _parse_llm_gui(blob) == {"k": 2}


def test_parse_llm_gui_extracts_first_json_object():
    """Trailing prose is ignored when a JSON object is present early."""
    blob = '   {"layout_type": "stage"}   trailing commentary...'
    assert _parse_llm_gui(blob) == {"layout_type": "stage"}


def test_parse_llm_gui_garbage_returns_empty_dict():
    assert _parse_llm_gui("totally not json") == {}
    assert _parse_llm_gui("") == {}
    assert _parse_llm_gui(None) == {}
    assert _parse_llm_gui(123) == {}


def test_normalize_gui_spec_preserves_unknown_layout_for_validator():
    spec = {"layout": {"type": "zoo_layout"}, "widgets": []}
    out = _normalize_gui_spec(spec, "公共资源协调")
    assert out["layout"]["type"] == "zoo_layout"


def test_normalize_gui_spec_preserves_widget_with_bad_emit():
    spec = {
        "layout": {"type": "dashboard",
                   "grid": {"columns": "1fr", "areas": ["main"]}},
        "widgets": [
            {"id": "bad", "type": "button", "area": "main",
             "binds": {"emit": "open_seal"}},
            {"id": "good", "type": "button", "area": "main",
             "binds": {"emit": "utterance"}},
        ],
    }
    out = _normalize_gui_spec(spec, "regional ecology")
    kept_names = [w["id"] for w in out["widgets"]]
    assert kept_names == ["bad", "good"]


def test_normalize_gui_spec_preserves_unknown_widget_type():
    spec = {
        "layout": {"type": "dashboard",
                   "grid": {"columns": "1fr", "areas": ["main"]}},
        "widgets": [
            {"id": "weird", "type": "holo_panel", "area": "main",
             "binds": {"read": "kernel:foo"}},
        ],
    }
    out = _normalize_gui_spec(spec, "edge city")
    assert out["widgets"][0]["type"] == "holo_panel"


def test_normalize_widget_preserves_widget_with_no_binds():
    widget = {"type": "button", "binds": {}}
    assert _normalize_widget(widget) == widget


def test_normalize_widget_preserves_widget_with_only_action():
    widget = {"type": "button", "binds": {"action": "world/tick"}}
    assert _normalize_widget(widget) == widget


def test_coerce_spec_after_normalize_validates():
    """End-to-end: parse + normalize + coerce + validate must agree."""
    raw = _valid_payload()
    parsed = _parse_llm_gui(raw)
    normalised = _normalize_gui_spec(parsed, "edge city")
    spec = _coerce_spec(normalised, "edge city")
    validate_gui_spec(spec)


# ---------------------------------------------------------------------------
# Round-trip: LLM-generated spec compiles to CSS + HTML without error.
# ---------------------------------------------------------------------------

def test_llm_spec_compiles_to_css_and_html():
    from theater.gui_generator import compile_to_css, compile_to_html_template

    def llm_fn(_world_style: str) -> Dict[str, Any]:
        return _valid_payload()

    spec = GUIGenerator(llm_fn=llm_fn).generate("edge city neon noir")
    css = compile_to_css(spec)
    html = compile_to_html_template(spec)
    assert "display: grid;" in css
    assert "terminal" in css
    assert "<section " in html
    assert 'data-widget="netmap"' in html
    assert 'data-widget="exec"' in html
