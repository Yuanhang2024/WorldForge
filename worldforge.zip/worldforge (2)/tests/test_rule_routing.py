"""Focused tests for RuleGenerator keyword routing behaviour after preset removal.

Covers:
  - No LLM → RuntimeError (preset fallback removed).
  - Custom routing map is ignored when LLM is used.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_rule_routing.py -q
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, List

ROOT = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.rule_generator import RuleGenerator
from theater.world_kernel_host import RuleCompiler, WorldKernelSpec, WorldRule


# =====================================================================
# Helpers
# =====================================================================


def _make_spec(world_type: str = "simulation") -> str:
    """Return a minimal valid spec JSON for the given world_type."""
    return json.dumps({
        "world_type": world_type,
        "rules": [
            {
                "rule_id": "mock_rule",
                "kind": "dynamic",
                "trigger": "turn.tick",
                "condition": None,
                "effect": {
                    "op": "writes",
                    "changes": [{"path": "counter", "value": {"const": 1}}],
                },
                "description": "mock rule",
                "priority": 10,
            },
        ],
        "params": {},
        "initial_state": {"counter": 0},
    })


def _mock_llm(raw: str):
    def _fn(prompt: str) -> str:
        return raw
    return _fn


class TestNoLLMRaises:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_simulation_without_llm_raises(self) -> None:
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            self.gen.generate("城市管理模拟")

    def test_plague_without_llm_raises(self) -> None:
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            self.gen.generate("瘟疫蔓延的社会")

    def test_economy_without_llm_raises(self) -> None:
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            self.gen.generate("经济贸易市场")

    def test_any_description_without_llm_raises(self) -> None:
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            self.gen.generate("anything at all")


class TestLLMWithCustomRouting:
    def test_custom_keyword_routing_map_is_rejected(self) -> None:
        with pytest.raises(ValueError, match="keyword routing was removed"):
            RuleGenerator(preset_map={"custom_zen": ["zen", "garden"]})


class TestLLMDrivenSimulation:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_simulation_via_llm_chinese(self) -> None:
        raw = _make_spec("simulation")
        spec = self.gen.generate("城市管理模拟", llm_fn=_mock_llm(raw))
        assert spec.world_type == "simulation"
        ids = {r.rule_id for r in spec.rules}
        assert "mock_rule" in ids

    def test_simulation_via_llm_english(self) -> None:
        raw = _make_spec("simulation")
        spec = self.gen.generate("city management simulation", llm_fn=_mock_llm(raw))
        assert spec.world_type == "simulation"

    def test_simulation_validates_and_compiles(self) -> None:
        raw = _make_spec("simulation")
        spec = self.gen.generate("模拟城市管理", llm_fn=_mock_llm(raw))
        issues = RuleCompiler().validate_spec(spec)
        assert issues == [], f"validation issues: {issues}"
        kernel = RuleCompiler(seed=0).compile(spec)
        assert kernel.world_type == "simulation"
        assert len(kernel.rule_ids()) == len(spec.rules)


class TestLLMDrivenSocial:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_plague_via_llm_chinese(self) -> None:
        raw = _make_spec("social")
        spec = self.gen.generate("瘟疫蔓延的社会", llm_fn=_mock_llm(raw))
        assert spec.world_type == "social"
