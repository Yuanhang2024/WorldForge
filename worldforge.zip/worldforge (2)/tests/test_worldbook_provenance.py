"""§17 P0 事实隔离 — WorldBookEntry.provenance tests.

Covers:
- WorldBookEntry / WorldBookPatch default provenance (canonical_event)
- each dispatcher write point tags the correct provenance
- narration read path (_recent_worldbook_for_narration) prefers
  canonical_event over narrative_rendering (shadow-world defense)
- storage migration v3→v4 backfills provenance for legacy entries
- the 6 provenance types are a closed set

These are the regression guards for the fact-isolation layer that
unlocks AgentMind / causal graph / two-stage narration downstream.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)
TESTS = os.path.join(ROOT, "tests")
if TESTS not in sys.path:
    sys.path.insert(0, TESTS)

from theater.models import (  # noqa: E402
    WORLDBOOK_PROVENANCE_TYPES,
    WorldBookEntry,
    WorldBookPatch,
)
from theater.storage import JsonStateStore, _infer_provenance  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.agents import DeterministicModelClient  # noqa: E402


# ---------------------------------------------------------------------------
# 1. defaults + type set
# ---------------------------------------------------------------------------

def test_worldbook_entry_defaults_to_canonical_event():
    entry = WorldBookEntry(title="t", content="c", source="s",
                           approved_by="science_director")
    assert entry.provenance == "canonical_event"


def test_worldbook_patch_defaults_to_canonical_event():
    patch = WorldBookPatch(title="t", content="c", source="s")
    assert patch.provenance == "canonical_event"


def test_worldbook_entry_provenance_overridable():
    entry = WorldBookEntry(title="t", content="c", source="s",
                           approved_by="x", provenance="rumor")
    assert entry.provenance == "rumor"


def test_provenance_type_set_is_six():
    assert set(WORLDBOOK_PROVENANCE_TYPES) == {
        "canonical_event", "narrative_rendering", "agent_observation",
        "agent_belief", "rumor", "lore",
    }
    assert len(WORLDBOOK_PROVENANCE_TYPES) == 6


# ---------------------------------------------------------------------------
# 2. _infer_provenance (migration helper)
# ---------------------------------------------------------------------------

def test_infer_provenance_narrative_sources():
    assert _infer_provenance("three_body_kernel_narration") == "narrative_rendering"
    assert _infer_provenance("director_group") == "narrative_rendering"


def test_infer_provenance_lore_sources():
    assert _infer_provenance("imported_lorebook") == "lore"
    assert _infer_provenance("worldbook_import") == "lore"


def test_infer_provenance_defaults_canonical():
    assert _infer_provenance("world_kernel_tick") == "canonical_event"
    assert _infer_provenance("three_body_outcome_chapter") == "canonical_event"
    assert _infer_provenance("interaction") == "canonical_event"
    assert _infer_provenance("") == "canonical_event"


# ---------------------------------------------------------------------------
# 3. storage migration v3 → v4
# ---------------------------------------------------------------------------

def _write_state_v3(path: Path, worldbook: list) -> None:
    # legacy v3 entries carry approved_by (required on WorldBookEntry); no
    # provenance field yet (that's what the v3→v4 migration adds).
    wb = [
        {**e, "approved_by": e.get("approved_by", "science_director")}
        for e in worldbook
    ]
    state = {
        "worldbook": wb,
        "characters": [],
        "objects": [],
        "_meta": {
            "schema_version": 3,
            "world_id": "main",
            "created_from": None,
            "generator_ids": {"llm": None, "gui_compiler": None},
            "world_params": {"lambda": None, "initial_conditions_seed": None,
                             "enabled_kernels": [], "sealed_solutions": {}},
            "integrity_flags": {"sandbox": False, "constraint_mutations": []},
        },
    }
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2),
                    encoding="utf-8")


def test_migration_backfills_provenance_for_legacy_entries():
    with tempfile.TemporaryDirectory() as d:
        state_path = Path(d) / "state.json"
        _write_state_v3(state_path, [
            {"title": "内核", "content": "x", "source": "world_kernel_tick"},
            {"title": "叙事", "content": "y", "source": "three_body_kernel_narration"},
            {"title": "设定", "content": "z", "source": "imported_lorebook"},
            {"title": "既有", "content": "w", "source": "x",
             "provenance": "rumor"},
        ])
        store = JsonStateStore(Path(d))   # __init__ runs _migrate_if_needed
        wb = store.snapshot().worldbook
        assert wb[0].provenance == "canonical_event"
        assert wb[1].provenance == "narrative_rendering"
        assert wb[2].provenance == "lore"
        # existing provenance preserved (not overwritten)
        assert wb[3].provenance == "rumor"
        # The full chain runs through the current text-world schema.
        assert store._load()["_meta"]["schema_version"] == 6


def test_migration_preserves_canonical_default_for_unknown_sources():
    with tempfile.TemporaryDirectory() as d:
        state_path = Path(d) / "state.json"
        _write_state_v3(state_path, [
            {"title": "未知", "content": "x", "source": "some_unknown_origin"},
        ])
        store = JsonStateStore(Path(d))
        assert store.snapshot().worldbook[0].provenance == "canonical_event"


def test_storage_schema_version_is_6():
    assert JsonStateStore.SCHEMA_VERSION == 6


# ---------------------------------------------------------------------------
# 4. add_world_entry persists provenance
# ---------------------------------------------------------------------------

def test_add_world_entry_persists_provenance():
    with tempfile.TemporaryDirectory() as d:
        store = JsonStateStore(Path(d))
        patch = WorldBookPatch(title="t", content="c", source="s",
                               provenance="agent_belief")
        assert store.add_world_entry(patch, approved_by="science_director")
        entry = store.snapshot().worldbook[-1]
        assert entry.provenance == "agent_belief"


def test_add_world_entry_defaults_canonical_when_unspecified():
    with tempfile.TemporaryDirectory() as d:
        store = JsonStateStore(Path(d))
        patch = WorldBookPatch(title="t", content="c", source="s")  # no provenance
        store.add_world_entry(patch, approved_by="science_director")
        assert store.snapshot().worldbook[-1].provenance == "canonical_event"


# ---------------------------------------------------------------------------
# 5. dispatcher write points tag provenance
# ---------------------------------------------------------------------------

def _orch(tmp: Path) -> TheaterOrchestrator:
    orch = TheaterOrchestrator(
        state_store=JsonStateStore(tmp / "state"),
        model_client=DeterministicModelClient(),
    )
    return orch


def _populate(orch, entries):
    """Append WorldBookEntry-shaped patches through the orch's store."""
    for title, content, source, prov in entries:
        orch.state_store.add_world_entry(
            WorldBookPatch(title=title, content=content, source=source,
                           provenance=prov),
            approved_by="science_director")
    return orch.state_store.snapshot()


def test_three_body_narration_tagged_narrative_rendering():
    """three_body_tick's beat narration entry → narrative_rendering (prose)."""
    from test_three_body_tick import StubKernel
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        orch._three_body_kernel = StubKernel([("survived", 100.0)])
        orch._narrate_three_body = lambda event_log, history: {
            "title": "T", "narrative": "故事", "dialogue": "", "warnings": []}
        result = orch.three_body_tick(decision=2.0)
        beat = next(e for e in result.world_updates
                    if e.source == "three_body_kernel_narration")
        assert beat.provenance == "narrative_rendering"


def test_three_body_evacuation_tagged_canonical_event():
    """A proven-evacuation worldbook fact → canonical_event (kernel truth)."""
    from test_three_body_tick import StubKernel
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        orch._three_body_kernel = StubKernel([("survived", 100.0)], evac=True)
        orch._narrate_three_body = lambda event_log, history: {
            "title": "T", "narrative": "故事", "dialogue": "", "warnings": []}
        result = orch.three_body_tick(decision=2.0)
        evac = next(e for e in result.world_updates
                    if e.source == "three_body_kernel_evacuation")
        assert evac.provenance == "canonical_event"


def test_three_body_does_not_synthesize_outcome_chapter():
    """One accepted model narration is written; no deterministic chapter."""
    from test_three_body_tick import StubKernel
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        orch._three_body_kernel = StubKernel([("destroyed", 5.0)])
        orch._narrate_three_body = lambda event_log, history: {
            "title": "T", "narrative": "故事", "dialogue": "", "warnings": []}
        result = orch.three_body_tick(decision=4.0)
        assert not [
            entry for entry in result.world_updates
            if entry.source == "three_body_outcome_chapter"
        ]
        beat = next(
            entry for entry in result.world_updates
            if entry.source == "three_body_kernel_narration"
        )
        assert beat.provenance == "narrative_rendering"


def test_world_tick_kernel_entry_tagged_canonical_event():
    """world_tick's kernel event-log entry → canonical_event."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        orch._world_beat = 0
        orch._last_activity = 0.0
        # stub the kernel step to emit one deterministic change
        orch._step_world_kernel = lambda world_id: [
            {"path": "civilization.tech_level", "op": "set", "value": 1.0},
        ]
        # stub dispatch so no LLM is hit; the kernel-entry branch still runs
        class _R:
            model_trace: dict = {}
            warnings: list = []
        orch.dispatch = lambda *a, **k: _R()
        orch.world_tick()
        wb = orch.state_store.snapshot().worldbook
        kernel_entries = [e for e in wb if e.source == "world_kernel_tick"]
        assert kernel_entries, "kernel event entry should be written"
        assert all(e.provenance == "canonical_event" for e in kernel_entries)


# ---------------------------------------------------------------------------
# 6. narration read path prefers canonical_event (shadow-world defense)
# ---------------------------------------------------------------------------

def test_recent_worldbook_prefers_canonical_over_narrative():
    """Mix canonical + narrative entries; narration reads canonical first."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        snap = _populate(orch, [
            ("叙事0", "prose0", "three_body_kernel_narration", "narrative_rendering"),
            ("事实0", "fact0", "world_kernel_tick", "canonical_event"),
            ("叙事1", "prose1", "three_body_kernel_narration", "narrative_rendering"),
            ("事实1", "fact1", "world_kernel_tick", "canonical_event"),
        ])
        recent = orch._recent_worldbook_for_narration(snap, limit=3)
        # limit=3, only 2 canonical exist → both canonical + 1 narrative top-up
        assert len(recent) == 3
        titles = [e.title for e in recent]
        assert "事实0" in titles and "事实1" in titles
        assert sum(1 for e in recent if e.provenance == "narrative_rendering") == 1


def test_recent_worldbook_all_canonical_returns_only_canonical():
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        snap = _populate(orch, [
            (f"事实{i}", f"f{i}", "world_kernel_tick", "canonical_event")
            for i in range(5)
        ])
        recent = orch._recent_worldbook_for_narration(snap, limit=3)
        assert len(recent) == 3
        assert all(e.provenance == "canonical_event" for e in recent)
        assert [e.title for e in recent] == ["事实2", "事实3", "事实4"]


def test_recent_worldbook_empty_worldbook():
    orch = _orch(Path(tempfile.mkdtemp()))
    from theater.models import StateSnapshot
    snap = StateSnapshot(worldbook=[], characters=[], objects=[])
    assert orch._recent_worldbook_for_narration(snap, limit=3) == []


def test_recent_worldbook_no_canonical_falls_back_to_narrative():
    """Fresh world with only narrative entries still reads something."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        snap = _populate(orch, [
            (f"叙事{i}", f"p{i}", "director_group", "narrative_rendering")
            for i in range(2)
        ])
        recent = orch._recent_worldbook_for_narration(snap, limit=3)
        assert len(recent) == 2
        assert all(e.provenance == "narrative_rendering" for e in recent)


def test_three_body_history_reads_canonical_not_prior_prose():
    """_three_body_history must surface canonical facts, not LLM prose —
    the core shadow-world defense (narration based on facts, not prior narration).
    With enough canonical entries to fill the limit, prior prose is excluded."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        _populate(orch, [
            ("旧叙事", "上一拍的文学表达", "three_body_kernel_narration",
             "narrative_rendering"),
            ("内核事实A", "确定性事实A", "world_kernel_tick", "canonical_event"),
            ("内核事实B", "确定性事实B", "world_kernel_tick", "canonical_event"),
            ("内核事实C", "确定性事实C", "world_kernel_tick", "canonical_event"),
        ])
        history = orch._three_body_history()
        # canonical facts fill the limit=3 → surfaced
        assert "确定性事实A" in history
        assert "确定性事实B" in history
        assert "确定性事实C" in history
        # the narrative prose is NOT surfaced (canonical fills the limit)
        assert "上一拍的文学表达" not in history


# ---------------------------------------------------------------------------
# 7. remaining write points: possession + interaction → agent_observation /
#    canonical_event (the two call sites that complete the fact-isolation map)
# ---------------------------------------------------------------------------

def _possess(orch: TheaterOrchestrator, cid: str = "aster",
             allowed=("move", "speak", "inspect")):
    from theater.models import CharacterPatch
    orch.upsert_character(
        CharacterPatch(character_id=cid, name=cid.title(),
                       summary="test actor", source="test",
                       possession_limit={"max_duration": 3600,
                                         "allowed_actions": list(allowed)}),
        approved_by="science_director")
    orch.possession_manager.enter_possession(cid, "player_01", reason="test")


def test_possess_action_tagged_agent_observation():
    """A non-object possession action is a character's observed act, not kernel
    truth → agent_observation (世界事实 ≠ 角色行为观察)."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        _possess(orch, "aster", allowed=("move", "speak", "inspect"))
        out = orch.possess_action("aster", "move", {"detail": "走向北方"})
        assert out["ok"] is True
        entries = orch.state_store.snapshot().worldbook
        pos = [e for e in entries if e.source == "possession_action"]
        assert pos, "possession_action entry should be written"
        assert pos[-1].provenance == "agent_observation"


def test_interact_state_change_tagged_canonical_event():
    """A gate-arbitrated object state change (砸桌子) is a kernel-mediated
    physics verdict → canonical_event, not LLM prose."""
    from theater.models import SceneObjectPatch
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d))
        orch.upsert_object(
            SceneObjectPatch(object_id="crate", name="木箱", kind="prop",
                             location="room", state="intact",
                             source="test", material="wood", durability=2),
            approved_by="science_director")
        # break verb → set_state outcome (broken) → worldbook fact written
        out = orch.interact(actor_id="aster", verb="砸", object_id="crate",
                           actor_strength=5)
        assert out["ok"] is True
        entries = orch.state_store.snapshot().worldbook
        inter = [e for e in entries if e.source == "interaction"]
        assert inter, "interaction entry should be written"
        assert inter[-1].provenance == "canonical_event"
