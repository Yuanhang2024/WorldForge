"""Tests for multi-model routing — per-role default models, per-role env
overrides, per-role base_url, and model capability declarations.

Covers the "多模型路由" task:

* Each agent role defaults to a model suited to its job (narrative vs code),
  and the defaults differ between roles.
* ``AI_THEATER_AGENT_{ROLE}_MODEL`` overrides a single role's model without
  touching the others.
* ``AI_THEATER_AGENT_{ROLE}_BASE_URL`` routes a role to its own endpoint
  (different models may live on different Spark ports).
* ``role_default_model`` / ``MODEL_CAPABILITIES`` / ``model_capability``
  expose the declaration table used by docs and tooling.
* The runtime ``OpenAICompatibleClient`` honours per-role model + base_url
  when settings come from ``from_env``.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_model_routing.py -q
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

import pytest

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from theater.settings import (  # noqa: E402
    LOCAL_LLM_MODEL,
    LOCAL_NARRATIVE_MODEL,
    MODEL_CAPABILITIES,
    ROLE_DEFAULT_MODELS,
    Settings,
    model_capability,
    role_default_model,
)
from theater.agents import OpenAICompatibleClient  # noqa: E402


# ---------------------------------------------------------------------------
# role_default_model / ROLE_DEFAULT_MODELS
# ---------------------------------------------------------------------------


def test_role_default_model_table_covers_every_role():
    from theater.settings import AGENT_ROLES
    for role in AGENT_ROLES:
        assert role in ROLE_DEFAULT_MODELS, f"role {role} has no default model"
        assert ROLE_DEFAULT_MODELS[role], f"role {role} default model is empty"


def test_role_default_model_helper_returns_table_value():
    assert role_default_model("world_builder") == LOCAL_NARRATIVE_MODEL
    assert role_default_model("science_director") == LOCAL_LLM_MODEL
    # unknown role falls back to the general-purpose local model
    assert role_default_model("unknown_role") == LOCAL_LLM_MODEL


def test_role_defaults_are_differentiated():
    """world_builder (narrative) differs from science_director (code/rules)."""
    wb = role_default_model("world_builder")
    sd = role_default_model("science_director")
    assert wb != sd, "world_builder and science_director must differ"


def test_role_defaults_assign_narrative_model_to_world_builder():
    # world_builder is the literary narration role — it gets the narrative model.
    assert role_default_model("world_builder") == LOCAL_NARRATIVE_MODEL


def test_role_defaults_assign_coder_model_to_rule_roles():
    # producer + science_director are orchestration/rule roles — coder model.
    assert role_default_model("producer") == LOCAL_LLM_MODEL
    assert role_default_model("science_director") == LOCAL_LLM_MODEL


# ---------------------------------------------------------------------------
# from_env applies per-role default models (no env set)
# ---------------------------------------------------------------------------


@pytest.fixture
def clean_env(monkeypatch, tmp_path):
    """Wipe every AI_THEATER_* env var so from_env sees only defaults."""
    for key in list(os.environ):
        if key.startswith("AI_THEATER_"):
            monkeypatch.delenv(key, raising=False)
    monkeypatch.chdir(tmp_path)
    yield


def test_from_env_applies_per_role_default_models(clean_env):
    s = Settings.from_env()
    assert s.agent_config("world_builder").model == LOCAL_NARRATIVE_MODEL
    assert s.agent_config("science_director").model == LOCAL_LLM_MODEL
    assert s.agent_config("producer").model == LOCAL_LLM_MODEL


def test_from_env_world_builder_differs_from_science_director(clean_env):
    s = Settings.from_env()
    assert s.agent_config("world_builder").model != s.agent_config("science_director").model


def test_from_env_per_role_model_env_override_wins(clean_env, monkeypatch):
    monkeypatch.setenv("AI_THEATER_AGENT_WORLD_BUILDER_MODEL", "qwen-story-32b")
    s = Settings.from_env()
    assert s.agent_config("world_builder").model == "qwen-story-32b"
    # other roles keep their defaults
    assert s.agent_config("science_director").model == LOCAL_LLM_MODEL


def test_from_env_override_does_not_leak_to_other_roles(clean_env, monkeypatch):
    monkeypatch.setenv("AI_THEATER_AGENT_PRODUCER_MODEL", "custom-producer-x")
    s = Settings.from_env()
    assert s.agent_config("producer").model == "custom-producer-x"
    assert s.agent_config("world_builder").model == LOCAL_NARRATIVE_MODEL


# ---------------------------------------------------------------------------
# per-role base_url
# ---------------------------------------------------------------------------


def test_from_env_per_role_base_url_override(clean_env, monkeypatch):
    """A role can be routed to its own endpoint (different Spark port)."""
    monkeypatch.setenv("AI_THEATER_AGENT_WORLD_BUILDER_BASE_URL", "http://127.0.0.1:18900/v1")
    s = Settings.from_env()
    assert s.agent_config("world_builder").base_url == "http://127.0.0.1:18900/v1"
    assert s.agent_normalized_base_url("world_builder") == "http://127.0.0.1:18900/v1"
    # producer has no per-role base_url override, so it falls back to the
    # global local endpoint (same URL the global setting resolves to).
    assert s.agent_normalized_base_url("producer") == s.normalized_base_url


def test_from_env_per_role_base_url_and_model_together(clean_env, monkeypatch):
    """world_builder on its own port with its own model — independent of others."""
    monkeypatch.setenv("AI_THEATER_AGENT_WORLD_BUILDER_BASE_URL", "http://127.0.0.1:18900/v1")
    monkeypatch.setenv("AI_THEATER_AGENT_WORLD_BUILDER_MODEL", "gemma-4-12b")
    s = Settings.from_env()
    wb = s.agent_config("world_builder")
    assert wb.model == "gemma-4-12b"
    assert wb.base_url == "http://127.0.0.1:18900/v1"
    # producer unaffected
    prod = s.agent_config("producer")
    assert prod.model == LOCAL_LLM_MODEL
    assert s.agent_normalized_base_url("producer") == s.normalized_base_url


# ---------------------------------------------------------------------------
# Model capability declarations
# ---------------------------------------------------------------------------


def test_model_capabilities_table_covers_all_default_models():
    for model in set(ROLE_DEFAULT_MODELS.values()):
        assert model in MODEL_CAPABILITIES, f"capability missing for {model}"


def test_model_capability_helper_returns_declaration():
    cap = model_capability(LOCAL_NARRATIVE_MODEL)
    assert cap is not None
    assert cap.name == LOCAL_NARRATIVE_MODEL
    assert cap.context_length > 0
    assert cap.supports_json_schema is True
    assert cap.strength  # non-empty human-readable tag


def test_model_capability_unknown_model_returns_none():
    assert model_capability("does-not-exist") is None


def test_model_capability_coder_strong_for_json():
    cap = model_capability(LOCAL_LLM_MODEL)
    assert cap is not None
    assert cap.supports_json_schema is True
    assert "JSON" in cap.strength or "code" in cap.strength.lower()


# ---------------------------------------------------------------------------
# Runtime client honours per-role model + base_url
# ---------------------------------------------------------------------------


class _FakeResp:
    def __init__(self, body: bytes):
        self._body = body

    def read(self) -> bytes:
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def _openai_json(content: str) -> bytes:
    return json.dumps({
        "choices": [{"message": {"role": "assistant", "content": content}}]
    }).encode("utf-8")


def test_client_world_builder_uses_narrative_model_and_local_url(clean_env, monkeypatch):
    """With a configured local endpoint, world_builder POSTs the narrative
    model to that endpoint — proving per-role model routing reaches the wire."""
    monkeypatch.setenv("AI_THEATER_BASE_URL", "http://127.0.0.1:18899/v1")
    monkeypatch.setenv("AI_THEATER_API_KEY", "sk-test")
    settings = Settings.from_env()
    captured: List[Dict[str, Any]] = []

    def fake_urlopen(req):
        captured.append({
            "url": req.full_url,
            "body": json.loads(req.data.decode("utf-8")),
        })
        return _FakeResp(_openai_json(
            '{"name":"无名剑客","summary":"沉默的旅行者",'
            '"personality":"谨慎而克制","appearance":"旅行装束",'
            '"sample_line":"先观察。","warnings":[]}'
        ))

    monkeypatch.setattr("theater.agents.urllib.request.urlopen", fake_urlopen)
    client = OpenAICompatibleClient(settings)
    # complete_character_card routes through the world_builder role.
    client.complete_character_card("一个沉默的剑客", settings.model_deep)
    assert captured, "urlopen was never called"
    assert captured[0]["body"]["model"] == LOCAL_NARRATIVE_MODEL
    assert captured[0]["url"].startswith("http://127.0.0.1:18899/v1/chat/completions")


def test_client_world_builder_uses_per_role_base_url(clean_env, monkeypatch):
    """Per-role base_url override reaches the request URL."""
    monkeypatch.setenv("AI_THEATER_AGENT_WORLD_BUILDER_BASE_URL", "http://127.0.0.1:18900/v1")
    monkeypatch.setenv("AI_THEATER_API_KEY", "sk-test")
    settings = Settings.from_env()
    captured: List[str] = []

    def fake_urlopen(req):
        captured.append(req.full_url)
        return _FakeResp(_openai_json(
            '{"name":"x","summary":"s","personality":"p","appearance":"a",'
            '"sample_line":"l","warnings":[]}'
        ))

    monkeypatch.setattr("theater.agents.urllib.request.urlopen", fake_urlopen)
    client = OpenAICompatibleClient(settings)
    client.complete_character_card("剑客", settings.model_deep)
    assert captured[0].startswith("http://127.0.0.1:18900/v1/chat/completions")


def test_client_per_role_model_override_reaches_wire(clean_env, monkeypatch):
    """Env override of a role's model is what the LLM endpoint receives."""
    monkeypatch.setenv("AI_THEATER_AGENT_WORLD_BUILDER_MODEL", "qwen-story-32b")
    monkeypatch.setenv("AI_THEATER_API_KEY", "sk-test")
    settings = Settings.from_env()
    captured: List[Dict[str, Any]] = []

    def fake_urlopen(req):
        captured.append(json.loads(req.data.decode("utf-8")))
        return _FakeResp(_openai_json(
            '{"name":"x","summary":"s","personality":"p","appearance":"a",'
            '"sample_line":"l","warnings":[]}'
        ))

    monkeypatch.setattr("theater.agents.urllib.request.urlopen", fake_urlopen)
    client = OpenAICompatibleClient(settings)
    client.complete_character_card("剑客", settings.model_deep)
    assert captured[0]["model"] == "qwen-story-32b"


# ---------------------------------------------------------------------------
# public_dict exposes per-role models (runtime visibility)
# ---------------------------------------------------------------------------


def test_public_dict_exposes_per_role_default_models(clean_env):
    s = Settings.from_env()
    agents = s.public_dict()["agents"]
    assert agents["world_builder"]["model"] == LOCAL_NARRATIVE_MODEL
    assert agents["science_director"]["model"] == LOCAL_LLM_MODEL
    assert "action_director" not in agents
