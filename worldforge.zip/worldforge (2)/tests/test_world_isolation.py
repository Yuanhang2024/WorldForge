import tempfile, threading, unittest
from pathlib import Path
from theater.dispatcher import TheaterOrchestrator
from theater.storage import JsonStateStore
from theater.agents import DeterministicModelClient
from theater.models import CharacterPatch, WorldBookPatch


class ConcurrentCapturingClient(DeterministicModelClient):
    def __init__(self):
        self.barrier = threading.Barrier(2)
        self.prompts = {}
        self.lock = threading.Lock()

    def complete_json(self, role, prompt, model):
        request = prompt.split(
            "\n\n已持久化的当前世界上下文",
            1,
        )[0]
        with self.lock:
            self.prompts[request] = prompt
        self.barrier.wait(timeout=5)
        return super().complete_json(role, prompt, model)


class WorldIsolationTests(unittest.TestCase):
    def _orch(self):
        d = tempfile.mkdtemp()
        store = JsonStateStore(Path(d) / "state")  # default "main" world
        orch = TheaterOrchestrator(state_store=store,
                                   model_client=DeterministicModelClient())
        return orch

    def test_worlds_have_separate_state_files(self):
        orch = self._orch()
        main_store = orch.state_store
        orch.set_world("three_body")
        tb_store = orch.state_store
        self.assertNotEqual(main_store.path, tb_store.path)
        self.assertEqual(main_store.world_id, "main")
        self.assertEqual(tb_store.world_id, "three_body")

    def test_worldbook_does_not_leak_across_worlds(self):
        orch = self._orch()
        # write to main world
        orch.state_store.add_world_entry(
            WorldBookPatch(title="卡门场景", content="歌剧世界", source="test"),
            approved_by="science_director")
        # switch to three_body — should see NO carmen entries
        orch.set_world("three_body")
        snap = orch.state_store.snapshot()
        self.assertEqual(len(snap.worldbook), 0)
        # write to three_body
        orch.state_store.add_world_entry(
            WorldBookPatch(title="三体场景", content="三体世界", source="test"),
            approved_by="science_director")
        # back to main — should only have carmen, not three_body
        orch.set_world("main")
        snap = orch.state_store.snapshot()
        titles = [e.title for e in snap.worldbook]
        self.assertIn("卡门场景", titles)
        self.assertNotIn("三体场景", titles)

    def test_characters_are_world_scoped(self):
        orch = self._orch()
        orch.state_store.upsert_character(
            CharacterPatch(character_id="carmen", name="卡门", summary="歌剧",
                           source="test"),
            approved_by="science_director")
        orch.set_world("three_body")
        snap = orch.state_store.snapshot()
        self.assertEqual(len(snap.characters), 0)  # carmen not in three_body world
        orch.set_world("main")
        snap = orch.state_store.snapshot()
        self.assertEqual(len(snap.characters), 1)
        self.assertEqual(snap.characters[0].character_id, "carmen")

    def test_dispatch_with_world_id_isolates(self):
        orch = self._orch()
        # dispatch into three_body world
        orch.dispatch("test", session_id="t", world_id="three_body")
        self.assertEqual(orch.world_id, "main")
        # main world should be untouched
        snap = orch.state_store.snapshot()
        self.assertEqual(len(snap.worldbook), 0)

    def test_concurrent_dispatches_keep_world_context_and_writes_isolated(self):
        d = tempfile.mkdtemp()
        client = ConcurrentCapturingClient()
        orch = TheaterOrchestrator(
            state_store=JsonStateStore(Path(d) / "state"),
            model_client=client,
        )
        with orch.world_scope("alpha"):
            orch.add_world_entry(
                WorldBookPatch(
                    title="Alpha前情",
                    content="红桥完整",
                    source="test",
                ),
                approved_by="science_director",
            )
        with orch.world_scope("beta"):
            orch.add_world_entry(
                WorldBookPatch(
                    title="Beta前情",
                    content="蓝塔点亮",
                    source="test",
                ),
                approved_by="science_director",
            )

        errors = []

        def run(message, world_id):
            try:
                orch.dispatch(message, world_id=world_id)
            except Exception as exc:  # pragma: no cover - assertion below
                errors.append(exc)

        threads = [
            threading.Thread(target=run, args=("推进Alpha", "alpha")),
            threading.Thread(target=run, args=("推进Beta", "beta")),
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=10)

        self.assertEqual(errors, [])
        self.assertIn('"world_id": "alpha"', client.prompts["推进Alpha"])
        self.assertIn("红桥完整", client.prompts["推进Alpha"])
        self.assertNotIn("蓝塔点亮", client.prompts["推进Alpha"])
        self.assertIn('"world_id": "beta"', client.prompts["推进Beta"])
        self.assertIn("蓝塔点亮", client.prompts["推进Beta"])
        self.assertNotIn("红桥完整", client.prompts["推进Beta"])
        with orch.world_scope("alpha"):
            alpha_text = " ".join(
                entry.content for entry in orch.state_store.snapshot().worldbook
            )
        with orch.world_scope("beta"):
            beta_text = " ".join(
                entry.content for entry in orch.state_store.snapshot().worldbook
            )
        self.assertIn("推进Alpha", alpha_text)
        self.assertNotIn("推进Beta", alpha_text)
        self.assertIn("推进Beta", beta_text)
        self.assertNotIn("推进Alpha", beta_text)

    def test_list_worlds(self):
        orch = self._orch()
        orch.set_world("three_body")
        orch.set_world("carmen")
        worlds = orch.list_worlds()
        self.assertIn("main", worlds)
        self.assertIn("three_body", worlds)
        self.assertIn("carmen", worlds)


if __name__ == "__main__":
    unittest.main()
