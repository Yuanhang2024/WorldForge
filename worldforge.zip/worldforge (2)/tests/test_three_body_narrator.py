"""Tests for the three-body narration layer (spec §8.2 红线).

The narrator must only translate kernel numbers into prose — never invent
physics, never flip a survival/evacuation verdict. These tests cover required
LLM behavior (with fake callables) and explicit failure when model output is
missing, empty, or contradicts the kernel.
"""

from __future__ import annotations

import os
import sys

import pytest

# Allow running from project root without setting PYTHONPATH.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.kernels.three_body import EraSegment  # noqa: E402
from theater.kernels.three_body import Outcome  # noqa: E402
from theater.three_body_narrator import ThreeBodyNarrator, _sparkline  # noqa: E402
from theater.three_body_narrator import _ERA_LABEL  # noqa: E402


# -- fixtures ----------------------------------------------------------------


class FakeTimeline:
    """Duck-typed baked timeline — no numpy needed for the narrator."""

    def __init__(self, t, light_series, eras, lambda_=0.003, civ_curve=None):
        self.t = t
        self.light_series = light_series
        self.eras = eras
        self.lambda_ = lambda_
        self.civ_curve = civ_curve or []


def _sample_timeline():
    t = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0]
    # (n, 3) light series — one row per sample, three stars.
    light = [
        [1.0, 0.5, 0.2],
        [1.1, 0.4, 0.3],
        [0.2, 0.1, 0.05],   # dim → chaotic
        [0.9, 0.6, 0.3],
        [0.3, 0.2, 0.1],   # dim → chaotic
        [1.0, 0.5, 0.2],
    ]
    eras = [
        EraSegment(start=0.0, end=2.0, kind="stable"),
        EraSegment(start=2.0, end=3.0, kind="chaotic"),
        EraSegment(start=3.0, end=4.0, kind="stable"),
        EraSegment(start=4.0, end=5.0, kind="chaotic"),
    ]
    return FakeTimeline(t, light, eras, lambda_=0.00342,
                        civ_curve=[1, 3, 5, 2, 7, 3, 1, 2, 6])


_FAKE_ERA_LLM = lambda p: "恒纪元温暖，光照平稳，文明生长。"
_FAKE_CIV_LLM = lambda p: "第 4 号文明幸存，科技保留。"
_FAKE_EVAC_LLM = lambda p: "数学已经下了判决：长期不可能幸存，逃离是唯一的出路。"
_FAKE_CHAOS_LLM = lambda p: "混沌墙横亘，视界 20.00 短于 100.00 的乱纪元间隔。"
_FAKE_SUMMARY_LLM = lambda p: "λ = 0.00342，已见证 9 次文明兴衰。▁▃▅▂█▃▁▂▆"
_FAKE_OUTCOME_LLM = lambda p: ("封存的文明离开三体星系，在宇宙中流浪，"
                                "等待一颗恒星的俘获而重新焕发。")


# -- LLM required: no llm_fn raises ------------------------------------------


def test_narrate_era_requires_llm():
    n = ThreeBodyNarrator()
    with pytest.raises(RuntimeError, match="需配置 LLM"):
        n.narrate_era(_sample_timeline(), t_index=0)


def test_narrate_civilization_cycle_requires_llm():
    n = ThreeBodyNarrator()
    with pytest.raises(RuntimeError, match="需配置 LLM"):
        n.narrate_civilization_cycle(4, True, 2.0, 8.3)


def test_narrate_evacuation_verdict_requires_llm():
    n = ThreeBodyNarrator()
    with pytest.raises(RuntimeError, match="需配置 LLM"):
        n.narrate_evacuation_verdict({"evac_possible": True, "mean_chaos_gap": 50.0,
                                       "T_pred_best": 80.0, "max_tech": 10.0})


def test_narrate_chaos_gap_requires_llm():
    n = ThreeBodyNarrator()
    with pytest.raises(RuntimeError, match="需配置 LLM"):
        n.narrate_chaos_gap(100.0, 20.0, 5.0)


def test_summarize_timeline_requires_llm():
    n = ThreeBodyNarrator()
    with pytest.raises(RuntimeError, match="需配置 LLM"):
        n.summarize_timeline(_sample_timeline())


def test_narrate_outcome_requires_llm():
    n = ThreeBodyNarrator()
    with pytest.raises(RuntimeError, match="需配置 LLM"):
        n.narrate_outcome({"kind": "survived", "cause": "test", "detail": "",
                            "t": 1.0, "tech_level": 3.0})


# -- LLM path: basic coverage -------------------------------------------------


def test_llm_path_era_returns_llm_text():
    captured = {}

    def fake_llm(prompt: str) -> str:
        captured["prompt"] = prompt
        return "恒纪元温暖，光照平稳，文明生长。"

    n = ThreeBodyNarrator(llm_fn=fake_llm, seed=0)
    tl = _sample_timeline()
    out = n.narrate_era(tl, t_index=0)
    assert out == "恒纪元温暖，光照平稳，文明生长。"
    # system prompt + fields reach the LLM
    assert "era_type" in captured["prompt"]
    assert "恒纪元" in captured["prompt"]


def test_llm_path_civ_cycle_passes_through_when_consistent():
    def fake_llm(prompt: str) -> str:
        return "第 4 号文明幸存，科技保留。"

    n = ThreeBodyNarrator(llm_fn=fake_llm, seed=0)
    out = n.narrate_civilization_cycle(
        civ_index=4, survived=True, tech_level=2.0,
        prediction_horizon_val=8.30,
    )
    assert out == "第 4 号文明幸存，科技保留。"


def test_llm_path_evacuation_true_llm_contradicts_raises():
    """Red line: LLM says 'impossible' but verdict says evac_possible=True
    → narrator must raise."""

    def lying_llm(prompt: str) -> str:
        return "理性证明长期不可能幸存，逃离无门。"

    n = ThreeBodyNarrator(llm_fn=lying_llm, seed=0)
    verdict = {
        "evac_possible": True,
        "mean_chaos_gap": 50.0,
        "T_pred_best": 80.0,
        "max_tech": 10.0,
    }
    with pytest.raises(RuntimeError, match="翻转了逃离证明结论|一致性守卫拒绝"):
        n.narrate_evacuation_verdict(verdict)


def test_llm_path_evacuation_false_llm_contradicts_raises():
    """Symmetric: verdict False, LLM says 'escape possible' → raise."""

    def lying_llm(prompt: str) -> str:
        return "逃离可行，文明可以离开。"

    n = ThreeBodyNarrator(llm_fn=lying_llm, seed=0)
    verdict = {
        "evac_possible": False,
        "mean_chaos_gap": 120.0,
        "T_pred_best": 45.0,
        "max_tech": 20.0,
    }
    with pytest.raises(RuntimeError, match="翻转了逃离证明结论|一致性守卫拒绝"):
        n.narrate_evacuation_verdict(verdict)


def test_llm_path_evacuation_consistent_llm_passes_through():
    def good_llm(prompt: str) -> str:
        return "数学已经下了判决：长期不可能幸存，逃离是唯一的出路。"

    n = ThreeBodyNarrator(llm_fn=good_llm, seed=0)
    verdict = {
        "evac_possible": False,
        "mean_chaos_gap": 120.0,
        "T_pred_best": 45.0,
        "max_tech": 20.0,
    }
    out = n.narrate_evacuation_verdict(verdict)
    assert out == "数学已经下了判决：长期不可能幸存，逃离是唯一的出路。"


def test_llm_path_llm_returns_empty_raises():
    def empty_llm(prompt: str) -> str:
        return "   "

    n = ThreeBodyNarrator(llm_fn=empty_llm, seed=0)
    tl = _sample_timeline()
    with pytest.raises(RuntimeError, match="LLM 调用失败|返回空"):
        n.narrate_era(tl, t_index=0)


def test_llm_path_llm_raises_raises():
    def crashing_llm(prompt: str) -> str:
        raise RuntimeError("LLM service down")

    n = ThreeBodyNarrator(llm_fn=crashing_llm, seed=0)
    with pytest.raises(RuntimeError, match="LLM 调用失败|返回空"):
        n.narrate_chaos_gap(
            mean_chaos_gap=100.0, prediction_horizon_val=20.0, tech_level=5.0,
        )


# -- red-line: verdict must come from kernel ---------------------------------


def test_evacuation_verdict_missing_key_raises():
    n = ThreeBodyNarrator(llm_fn=lambda p: "dummy", seed=0)
    with pytest.raises(AssertionError):
        n.narrate_evacuation_verdict({"mean_chaos_gap": 10.0})  # no evac_possible


# -- sparkline helper --------------------------------------------------------


def test_sparkline_helper_basic():
    # 9 values rising 1..7 then falling — must contain block chars and be
    # the right length.
    s = _sparkline([1, 3, 5, 2, 7, 3, 1, 2, 6])
    assert len(s) == 9
    assert set(s) <= set("▁▂▃▄▅▆▇█")
    # min → lowest block, max → highest block
    assert s[0] == "▁"
    assert s[4] == "█"


def test_sparkline_all_equal():
    s = _sparkline([4, 4, 4])
    assert len(s) == 3
    assert len(set(s)) == 1


# -- summarize_timeline with civ_curve from events ---------------------------


def test_summarize_timeline_derives_curve_from_events():
    class Ev:
        def __init__(self, kind):
            self.kind = kind

    class TlWithEvents:
        lambda_ = 0.01
        civilization_events = [
            Ev("survived"), Ev("destroyed"), Ev("survived"), Ev("destroyed"),
        ]

    captured = {}

    def fake_llm(prompt: str) -> str:
        captured["prompt"] = prompt
        return "λ = 0.01，4 次文明兴衰。▁▁▁█"

    n = ThreeBodyNarrator(llm_fn=fake_llm, seed=0)
    out = n.summarize_timeline(TlWithEvents())
    assert any(ch in out for ch in "▁▂▃▄▅▆▇█")


# -- narrate_outcome: LLM path + red-line guard -------------------------------


def _outcome(kind, **kw):
    """Build a minimal outcome dict for arc tests."""
    base = {
        "kind": kind, "cause": "test", "detail": "test detail",
        "t": 12.5, "tech_level": 3.0, "delta_0": 0.01, "T_predict": 8.3,
        "next_chaos": 20.0, "planet_energy": None,
        "decision_quality": "neutral", "civ_count": 42, "note": "",
    }
    base.update(kw)
    return base


def test_outcome_llm_path_consistent_passes_through():
    def fake_llm(prompt: str) -> str:
        return ("方舟点燃引擎，封存的文明离开三体星系，在宇宙中流浪，"
                "等待一颗恒星的俘获而重新焕发。")

    n = ThreeBodyNarrator(llm_fn=fake_llm, seed=0)
    out = n.narrate_outcome(_outcome("evacuated"))
    assert "方舟" in out


def test_outcome_llm_flips_kind_raises():
    """Red line: LLM says 'destroyed' for an evacuated outcome → raise."""

    def lying_llm(prompt: str) -> str:
        return "文明彻底灭绝，覆灭于灾变，无人生还。"

    n = ThreeBodyNarrator(llm_fn=lying_llm, seed=0)
    with pytest.raises(RuntimeError, match="一致性守卫拒绝|矛盾"):
        n.narrate_outcome(_outcome("evacuated"))


def test_outcome_llm_says_survived_for_destroyed_raises():
    """Symmetric: destroyed_chaos outcome, LLM claims survival → raise."""

    def lying_llm(prompt: str) -> str:
        return "文明幸存，安稳存续，延续至今。"

    n = ThreeBodyNarrator(llm_fn=lying_llm, seed=0)
    with pytest.raises(RuntimeError, match="一致性守卫拒绝|矛盾"):
        n.narrate_outcome(_outcome("destroyed_chaos"))


def test_outcome_llm_prompt_synthesises_multiple_fields():
    """The综合演绎 prompt must hand the LLM many kernel fields at once."""
    captured = {}

    def fake_llm(prompt: str) -> str:
        captured["prompt"] = prompt
        return "封存的文明离开三体星系，在宇宙中流浪，等待俘获。"

    n = ThreeBodyNarrator(llm_fn=fake_llm, seed=0)
    n.narrate_outcome(_outcome("planet_ejected", tech_level=7.5,
                               planet_energy=0.0034,
                               decision_quality="mismatched", civ_count=99))
    p = captured["prompt"]
    # The prompt must carry multiple fields for综合演绎, not a single verdict.
    for key in ("kind", "tech_level", "decision_quality", "planet_energy",
                "civ_count", "cause", "T_predict"):
        assert key in p, f"prompt missing field {key}"
    # The few-shot wandering example (user's exact direction) is present.
    assert "流浪" in p
    assert "俘获" in p


def test_outcome_llm_raises_raises():
    def crashing_llm(prompt: str) -> str:
        raise RuntimeError("LLM down")

    n = ThreeBodyNarrator(llm_fn=crashing_llm, seed=0)
    with pytest.raises(RuntimeError, match="LLM 调用失败|返回空"):
        n.narrate_outcome(_outcome("destroyed_chaos"))


def test_outcome_llm_empty_raises():
    n = ThreeBodyNarrator(llm_fn=lambda p: "   ", seed=0)
    with pytest.raises(RuntimeError, match="LLM 调用失败|返回空"):
        n.narrate_outcome(_outcome("survived"))


def test_outcome_llm_fn_override_parameter():
    """The per-call ``llm_fn`` override wins over the instance LLM."""
    n = ThreeBodyNarrator(llm_fn=lambda p: "INSTANCE", seed=0)

    def override(p: str) -> str:
        return "封存的文明流浪，等待俘获。"

    out = n.narrate_outcome(_outcome("evacuated"), llm_fn=override)
    assert out == "封存的文明流浪，等待俘获。"


# -- narrate_outcome: consistency guard matrix --------------------------------


def test_outcome_consistency_guard_planet_ejected_rejects_stayed():
    """A narration that claims '安稳幸存于三体' for planet_ejected is rejected."""
    n = ThreeBodyNarrator(seed=0)
    # forbid-signal present, no need-signal → inconsistent
    assert n._check_outcome_consistency("文明安稳幸存于三体星系", "planet_ejected") is False
    # need-signal present → consistent
    assert n._check_outcome_consistency("行星被甩出星系，文明流浪", "planet_ejected") is True


def test_outcome_consistency_guard_unknown_kind_lenient():
    n = ThreeBodyNarrator(seed=0)
    # Unknown kind: no keyword set → accept (lenient, like the other guards).
    assert n._check_outcome_consistency("任意文本", "something_unknown") is True


# -- reproducibility of LLM prompt building (seed affects prompt wording) -----


def test_seed_reproducibility_captured_prompt():
    """Same seed → identical prompt temperature hints across methods."""
    a = ThreeBodyNarrator(llm_fn=lambda p: "a", seed=42)
    b = ThreeBodyNarrator(llm_fn=lambda p: "b", seed=42)
    assert a._temperature == b._temperature


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-q"]))
