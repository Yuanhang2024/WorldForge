"""Tests for backend.theater.gameplay_generator (spec §9.2 库外玩法 LLM 生成).

Covers the LLM generate → validate → repair → fallback pipeline:
  - LLM returns valid spec → source="llm", repairs=0
  - LLM returns invalid spec → repair 1 round succeeds → source="llm", repairs=1
  - LLM returns invalid spec, repair 2 rounds fails → RuntimeError
  - no llm_fn/kernel_id → explicit failure (no fallback)
  - explicit kernel_id → matching parameterized library adapter
  - GenerationResult.to_dict shape

Uses fake/stub llm_fn; no real Spark dependency.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_gameplay_generator.py -q
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, List

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.gameplay_generator import GameplayGenerator, GenerationResult
from theater.gameplay_validator import GameplaySpec, GameplayValidator


# =====================================================================
# Fixtures / helpers
# =====================================================================


def _valid_spec_dict() -> Dict[str, Any]:
    """A GameplaySpec dict that passes all four validator gates."""
    return {
        "name": "countdown",
        "description": "count down from 10",
        "state_schema": {"count": 10, "turn": 0},
        "legal_actions": [
            {"id": "dec",
             "condition": {"op": "gt", "args": [{"ref": "count"}, {"const": 0}]}},
        ],
        "terminal": {"op": "or", "args": [
            {"op": "le", "args": [{"ref": "count"}, {"const": 0}]},
            {"op": "ge", "args": [{"ref": "turn"}, {"const": 50}]},
        ]},
        "payoff": {"op": "ref", "path": "turn"},
        "apply": {"dec": {"writes": [
            {"path": "count",
             "value": {"op": "sub", "args": [{"ref": "count"}, {"const": 1}]}},
            {"path": "turn",
             "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
        ]}},
    }


def _dominant_spec_dict() -> Dict[str, Any]:
    """A spec that FAILS the no-dominant-strategy gate (trivial always-win)."""
    return {
        "name": "dom",
        "description": "trivial dominant",
        "state_schema": {"score": 0, "turn": 0},
        "legal_actions": [
            {"id": "good", "condition": {"op": "lt", "args": [{"ref": "turn"}, {"const": 1}]}},
            {"id": "bad",  "condition": {"op": "lt", "args": [{"ref": "turn"}, {"const": 1}]}},
        ],
        "terminal": {"op": "ge", "args": [{"ref": "turn"}, {"const": 1}]},
        "payoff": {"op": "ref", "path": "score"},
        "apply": {
            "good": {"writes": [
                {"path": "score", "value": {"op": "add", "args": [{"ref": "score"}, {"const": 10}]}},
                {"path": "turn",  "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
            ]},
            "bad": {"writes": [
                {"path": "score", "value": {"op": "sub", "args": [{"ref": "score"}, {"const": 10}]}},
                {"path": "turn",  "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
            ]},
        },
    }


# =====================================================================
# LLM path: valid on first try
# =====================================================================


def test_llm_valid_first_try():
    def llm_fn(prompt: str) -> str:
        return json.dumps(_valid_spec_dict())

    g = GameplayGenerator()
    spec, res = g.generate("countdown game", llm_fn=llm_fn)
    assert res.source == "llm"
    assert res.repairs == 0
    assert res.validation is not None and res.validation.passed
    assert spec.name == "countdown"
    assert isinstance(spec, GameplaySpec)


def test_llm_valid_with_code_fence():
    """LLM wraps output in ```json fences — parser strips them."""
    def llm_fn(prompt: str) -> str:
        return "```json\n" + json.dumps(_valid_spec_dict()) + "\n```"

    g = GameplayGenerator()
    spec, res = g.generate("countdown", llm_fn=llm_fn)
    assert res.source == "llm"
    assert res.repairs == 0


def test_llm_valid_with_prose_around_json():
    """LLM emits prose before/after the JSON — parser scans for braces."""
    def llm_fn(prompt: str) -> str:
        return ("Here is the spec:\n" + json.dumps(_valid_spec_dict())
                + "\nHope it helps!")

    g = GameplayGenerator()
    spec, res = g.generate("countdown", llm_fn=llm_fn)
    assert res.source == "llm"


# =====================================================================
# LLM path: repair round succeeds
# =====================================================================


def test_llm_repair_one_round_then_success():
    """First call returns invalid spec (dominant), second call returns valid."""
    calls = {"n": 0}

    def llm_fn(prompt: str) -> str:
        calls["n"] += 1
        if calls["n"] == 1:
            return json.dumps(_dominant_spec_dict())
        return json.dumps(_valid_spec_dict())

    g = GameplayGenerator()
    spec, res = g.generate("countdown", llm_fn=llm_fn)
    assert res.source == "llm"
    assert res.repairs == 1
    assert calls["n"] == 2
    assert res.validation.passed


def test_llm_repair_after_unparseable_first_call():
    """First call returns garbage, second returns valid spec."""
    calls = {"n": 0}

    def llm_fn(prompt: str) -> str:
        calls["n"] += 1
        if calls["n"] == 1:
            return "sorry I cannot do that"
        return json.dumps(_valid_spec_dict())

    g = GameplayGenerator()
    spec, res = g.generate("countdown", llm_fn=llm_fn)
    assert res.source == "llm"
    assert res.repairs >= 1


# =====================================================================
# LLM path: repair exhausted → raise RuntimeError
# =====================================================================


def test_llm_always_invalid_raises():
    """LLM always returns a dominant (invalid) spec → RuntimeError after 2 repairs."""
    calls = {"n": 0}

    def llm_fn(prompt: str) -> str:
        calls["n"] += 1
        return json.dumps(_dominant_spec_dict())

    g = GameplayGenerator(max_repairs=2)
    with pytest.raises(RuntimeError, match="LLM gameplay generation failed"):
        g.generate("countdown", llm_fn=llm_fn)
    assert calls["n"] == 3  # initial + 2 repairs


def test_llm_always_garbage_raises():
    def llm_fn(prompt: str) -> str:
        return "not json"

    g = GameplayGenerator(max_repairs=2)
    with pytest.raises(RuntimeError, match="LLM gameplay generation failed"):
        g.generate("countdown", llm_fn=llm_fn)


# =====================================================================
# No llm_fn → failure unless kernel_id is explicit
# =====================================================================


def test_no_llm_fn_fails_without_fallback():
    g = GameplayGenerator()
    with pytest.raises(RuntimeError, match="requires llm_fn"):
        g.generate("a poker game", llm_fn=None)


def test_no_llm_fn_with_world_style():
    g = GameplayGenerator()
    with pytest.raises(RuntimeError, match="requires llm_fn"):
        g.generate("dice game", world_style="tavern", llm_fn=None)


# =====================================================================
# Parameterized kernels require an explicit ID
# =====================================================================


def test_explicit_betting_kernel():
    g = GameplayGenerator()
    spec, res = g.generate(
        "description is not used for routing",
        llm_fn=None,
        kernel_id="betting",
    )
    assert res.source == "kernel"
    assert spec.parameters.get("source_kernel") == "betting"


def test_explicit_dice_pool_kernel():
    g = GameplayGenerator()
    spec, res = g.generate("anything", llm_fn=None, kernel_id="dice_pool")
    assert spec.parameters.get("source_kernel") == "dice_pool"


def test_explicit_deck_kernel():
    g = GameplayGenerator()
    spec, res = g.generate("anything", llm_fn=None, kernel_id="deck")
    assert spec.parameters.get("source_kernel") == "deck"


def test_unknown_explicit_kernel_is_rejected():
    g = GameplayGenerator()
    with pytest.raises(ValueError, match="unknown kernel_id"):
        g.generate("anything", llm_fn=None, kernel_id="not_registered")


# =====================================================================
# GenerationResult shape
# =====================================================================


def test_generation_result_to_dict():
    def llm_fn(prompt):
        return json.dumps(_valid_spec_dict())
    g = GameplayGenerator()
    spec, res = g.generate("countdown", llm_fn=llm_fn)
    d = res.to_dict()
    assert d["ok"] is True
    assert d["source"] == "llm"
    assert d["repairs"] == 0
    assert "spec" in d and "validation" in d
    # JSON-safe
    json.dumps(d)


def test_kernel_spec_passes_validator():
    """The kernel spec itself must pass all four gates (never ship broken)."""
    v = GameplayValidator()
    g = GameplayGenerator()
    spec, _ = g.generate("anything", llm_fn=None, kernel_id="deck")
    report = v.validate_all(spec)
    assert report.passed, report.reasons


def test_system_prompt_mentions_whitelist_and_constraints():
    """The LLM system prompt teaches the whitelist + the four gates."""
    from theater.gameplay_generator import _SYSTEM_PROMPT
    assert "whitelist" in _SYSTEM_PROMPT.lower() or "whitelisted" in _SYSTEM_PROMPT.lower()
    assert "terminate" in _SYSTEM_PROMPT.lower()
    assert "deadlock" in _SYSTEM_PROMPT.lower()
    assert "dominant" in _SYSTEM_PROMPT.lower()
    # Safety red line: no eval/exec
    assert "eval" in _SYSTEM_PROMPT.lower()  # mentioned as forbidden
    assert "no eval" in _SYSTEM_PROMPT.lower() or "no ``eval``" in _SYSTEM_PROMPT.lower() \
           or "no eval" in _SYSTEM_PROMPT.lower()


def test_repair_prompt_includes_failure_reasons():
    """When repairing, the user prompt must echo the validation failures."""
    # Track call count and capture the (combined) prompt each call.
    state = {"n": 0, "prompts": []}

    def llm_fn2(prompt: str) -> str:
        state["n"] += 1
        state["prompts"].append(prompt)
        if state["n"] == 1:
            return json.dumps(_dominant_spec_dict())
        return json.dumps(_valid_spec_dict())

    g = GameplayGenerator()
    spec, res = g.generate("countdown", llm_fn=llm_fn2)
    assert res.source == "llm"
    assert res.repairs == 1
    # The second prompt is the repair prompt; it should mention the failure.
    repair_prompt = state["prompts"][1]
    assert "validation failed" in repair_prompt.lower() or "failed validation" in repair_prompt.lower()
