"""Tests for the Character Graph (spec §5/§6 multi-character substrate).

Pins the contract of :mod:`theater.character_graph`:

- directed (asymmetric) relationships,
- trust-thresholded neighbour filtering,
- information propagation that trust opens and distrust blocks
  (the §5 scientist↔leader example),
- trust-weighted social pressure with conflict suppression,
- organisation decisions (dictator / consensus / vote),
- relationship evolution with event-sourced history,
- same-seed determinism.
"""

from __future__ import annotations

import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.character_graph import (  # noqa: E402
    CharacterGraph,
    Organization,
    org_decide,
    propagate_info,
    social_pressure,
)


# ---------------------------------------------------------------------------
# 1. Relationship structure + asymmetry
# ---------------------------------------------------------------------------


def test_relationship_clamps_fields():
    g = CharacterGraph()
    rel = g.add_relationship("a", "b", trust=5.0, conflict=-1.0, influence=2.0)
    assert rel.trust == 1.0
    assert rel.conflict == 0.0
    assert rel.influence == 1.0


def test_trust_is_asymmetric():
    g = CharacterGraph()
    g.add_relationship("leader", "scientist", trust=0.8)
    g.add_relationship("scientist", "leader", trust=-0.3)
    assert g.get_trust("leader", "scientist") == pytest.approx(0.8)
    assert g.get_trust("scientist", "leader") == pytest.approx(-0.3)
    # absent edge → neutral 0.0
    assert g.get_trust("leader", "general") == 0.0


def test_neighbors_min_trust_filter():
    g = CharacterGraph()
    g.add_relationship("leader", "scientist", trust=0.8)
    g.add_relationship("leader", "general", trust=-0.7)
    g.add_relationship("leader", "advisor", trust=0.4)
    # all neighbours
    assert g.neighbors("leader") == ["advisor", "general", "scientist"]
    # only trusted ones (trust > 0)
    assert g.neighbors("leader", min_trust=0.0) == ["advisor", "scientist"]
    # higher bar
    assert g.neighbors("leader", min_trust=0.5) == ["scientist"]


def test_isolated_node_has_no_neighbors():
    g = CharacterGraph()
    g.add_node("hermit")
    assert g.neighbors("hermit") == []
    assert "hermit" in g.nodes


# ---------------------------------------------------------------------------
# 2. Information propagation — the §5 scientist/leader example
# ---------------------------------------------------------------------------


def test_info_propagates_along_trust():
    g = CharacterGraph()
    g.add_relationship("source", "a", trust=0.8)
    g.add_relationship("a", "b", trust=0.6)
    out = propagate_info(g, "source", "fire alarm", info_quality=1.0)
    assert out["source"] is True
    assert out["a"] is True
    assert out["b"] is True


def test_info_blocked_by_distrust_scientist_leader():
    """The canonical §5 example.

    Scientist knows the disaster probability is 90%.  Leader distrusts
    the scientist → the warning cannot propagate to the leader → the
    leader is left uninformed.  This is "信息错误来源①：角色没看到重要
    信息" made structural.
    """
    g = CharacterGraph()
    g.add_relationship("scientist", "leader", trust=-0.7)  # distrust
    out = propagate_info(g, "scientist", "disaster 90%", info_quality=0.9)
    assert out["scientist"] is True
    assert out["leader"] is False


def test_info_blocked_at_threshold_boundary():
    g = CharacterGraph()
    # trust exactly at threshold (0.0) — strict > needed to pass
    g.add_relationship("a", "b", trust=0.0)
    out = propagate_info(g, "a", "x", trust_threshold=0.0)
    assert out["b"] is False
    # positive trust opens the channel
    g.update_trust("a", "b", 0.1)
    out = propagate_info(g, "a", "x", trust_threshold=0.0)
    assert out["b"] is True


def test_info_max_hops_bounds_spread():
    g = CharacterGraph()
    g.add_relationship("s", "a", trust=0.9)
    g.add_relationship("a", "b", trust=0.9)
    g.add_relationship("b", "c", trust=0.9)
    # 1 hop → only a receives
    out = propagate_info(g, "s", "x", max_hops=1)
    assert out["a"] is True
    assert out["b"] is False
    assert out["c"] is False
    # 3 hops → reaches c
    out = propagate_info(g, "s", "x", max_hops=3)
    assert out["c"] is True


def test_info_reached_agents_marked_false_for_unreached():
    g = CharacterGraph()
    g.add_node("isolated")
    g.add_relationship("s", "a", trust=0.8)
    out = propagate_info(g, "s", "x")
    assert out["isolated"] is False
    assert out["a"] is True


# ---------------------------------------------------------------------------
# 3. Social pressure
# ---------------------------------------------------------------------------


def test_social_pressure_trust_weighted():
    g = CharacterGraph()
    # agent trusts a (0.8, says 1.0) more than c (0.4, says 0.0)
    g.add_relationship("agent", "a", trust=0.8)
    g.add_relationship("agent", "c", trust=0.4)
    beliefs = {"a": {"topic": 1.0}, "c": {"topic": 0.0}}
    p = social_pressure(g, "agent", "topic", beliefs)
    # weighted: (0.8*1.0 + 0.4*0.0) / (0.8+0.4)
    assert p == pytest.approx(0.8 / 1.2)


def test_social_pressure_filters_distrust():
    g = CharacterGraph()
    # distrusted neighbour should not pull the average toward their view
    g.add_relationship("agent", "trusted", trust=0.8)
    g.add_relationship("agent", "distrusted", trust=-0.5)
    beliefs = {
        "trusted": {"topic": 1.0},
        "distrusted": {"topic": 1.0},
    }
    p = social_pressure(g, "agent", "topic", beliefs, min_trust=0.0)
    # only trusted contributes
    assert p == pytest.approx(1.0)


def test_social_pressure_conflict_discounts():
    g = CharacterGraph()
    # high trust but high conflict → suppressed
    g.add_relationship("agent", "rival", trust=0.8, conflict=0.9)
    beliefs = {"rival": {"topic": 1.0}}
    p = social_pressure(g, "agent", "topic", beliefs)
    # w = 0.8 * (1 - 0.9) = 0.08, value 1.0 → 1.0 (still pulls, but weakly)
    assert p == pytest.approx(1.0)
    # full conflict → weight 0 → returns 0.0 (no social pressure)
    g2 = CharacterGraph()
    g2.add_relationship("agent", "rival", trust=0.8, conflict=1.0)
    p2 = social_pressure(g2, "agent", "topic", {"rival": {"topic": 1.0}})
    assert p2 == 0.0


def test_social_pressure_no_opinion_returns_zero():
    g = CharacterGraph()
    g.add_relationship("agent", "a", trust=0.8)
    # neighbour has no belief on topic
    p = social_pressure(g, "agent", "topic", {"a": {}})
    assert p == 0.0


# ---------------------------------------------------------------------------
# 4. Organization decisions
# ---------------------------------------------------------------------------


def test_org_decide_dictator():
    org = Organization(
        org_id="o", members=["leader", "a", "b"],
        roles={"leader": "dictator"}, decision_rule="dictator",
        dictator_id="leader",
    )
    votes = {"leader": "attack", "a": "retreat", "b": "attack"}
    assert org_decide(org, votes) == "attack"


def test_org_decide_dictator_raises_when_no_vote():
    org = Organization(
        org_id="o", members=["leader"], decision_rule="dictator",
        dictator_id="leader",
    )
    with pytest.raises(ValueError):
        org_decide(org, {})


def test_org_decide_consensus_unanimous():
    org = Organization(org_id="o", members=["a", "b", "c"],
                       decision_rule="consensus")
    votes = {"a": "yes", "b": "yes", "c": "yes"}
    assert org_decide(org, votes) == "yes"


def test_org_decide_consensus_dissent_blocks():
    org = Organization(org_id="o", members=["a", "b", "c"],
                       decision_rule="consensus")
    votes = {"a": "yes", "b": "yes", "c": "no"}
    assert org_decide(org, votes) is None


def test_org_decide_vote_majority():
    org = Organization(org_id="o", members=["a", "b", "c"],
                       decision_rule="vote")
    votes = {"a": "yes", "b": "yes", "c": "no"}
    assert org_decide(org, votes) == "yes"


def test_org_decide_vote_tie_no_majority():
    org = Organization(org_id="o", members=["a", "b"],
                       decision_rule="vote")
    votes = {"a": "yes", "b": "no"}
    assert org_decide(org, votes) is None


def test_org_decide_ignores_non_member_votes():
    org = Organization(org_id="o", members=["a", "b"],
                       decision_rule="vote")
    # outsider tries to vote — should be ignored
    votes = {"a": "yes", "outsider": "no"}
    assert org_decide(org, votes) == "yes"


def test_org_decide_rule_override():
    org = Organization(org_id="o", members=["a", "b", "c"],
                       decision_rule="vote")
    votes = {"a": "yes", "b": "yes", "c": "yes"}
    # override to consensus
    assert org_decide(org, votes, rule="consensus") == "yes"


# ---------------------------------------------------------------------------
# 5. Relationship evolution + history (event sourcing)
# ---------------------------------------------------------------------------


def test_update_trust_clamps_and_records_history():
    g = CharacterGraph()
    g.add_relationship("a", "b", trust=0.2)
    new = g.update_trust("a", "b", 0.5, reason="b shared evidence")
    assert new == pytest.approx(0.7)
    rel = g.get_relationship("a", "b")
    assert rel is not None
    last = rel.history[-1]
    assert last["event"] == "update_trust"
    assert last["reason"] == "b shared evidence"
    assert last["old"] == pytest.approx(0.2)
    assert last["new"] == pytest.approx(0.7)


def test_update_trust_clamps_upper():
    g = CharacterGraph()
    g.add_relationship("a", "b", trust=0.9)
    new = g.update_trust("a", "b", 0.5)
    assert new == 1.0


def test_update_trust_creates_edge_if_missing():
    g = CharacterGraph()
    # no prior edge — update should create one
    new = g.update_trust("a", "b", 0.3, reason="first contact")
    assert new == pytest.approx(0.3)
    rel = g.get_relationship("a", "b")
    assert rel is not None
    assert rel.history[-1]["reason"] == "first contact"


def test_history_is_append_only_event_log():
    g = CharacterGraph()
    rel = g.add_relationship("a", "b", trust=0.1, reason="seed")
    g.update_trust("a", "b", 0.2, reason="t1")
    g.update_trust("a", "b", -0.1, reason="t2")
    events = [h["event"] for h in rel.history]
    assert events == ["add_relationship", "update_trust", "update_trust"]
    reasons = [h["reason"] for h in rel.history]
    assert reasons == ["seed", "t1", "t2"]


# ---------------------------------------------------------------------------
# 6. Determinism — same seed reproduces propagation exactly
# ---------------------------------------------------------------------------


def test_propagate_info_deterministic_without_seed():
    g = CharacterGraph()
    g.add_relationship("s", "a", trust=0.8)
    g.add_relationship("a", "b", trust=0.6)
    g.add_relationship("b", "c", trust=0.4)
    out1 = propagate_info(g, "s", "x")
    out2 = propagate_info(g, "s", "x")
    assert out1 == out2


def test_propagate_info_same_seed_same_result():
    g = CharacterGraph()
    g.add_relationship("s", "a", trust=0.8)
    g.add_relationship("a", "b", trust=0.6)
    out1 = propagate_info(g, "s", "x", seed=42)
    out2 = propagate_info(g, "s", "x", seed=42)
    assert out1 == out2


def test_graph_to_dict_roundtrip_structure():
    g = CharacterGraph()
    g.add_relationship("a", "b", trust=0.5, conflict=0.1, influence=0.3)
    d = g.to_dict()
    assert "a" in d["nodes"]
    assert "b" in d["nodes"]
    assert len(d["edges"]) == 1
    e = d["edges"][0]
    assert e["from_id"] == "a"
    assert e["to_id"] == "b"
    assert e["trust"] == pytest.approx(0.5)
