"""Tests for the parameterized game kernel library (spec §9.2).

Covers all three initial kernels: DeckKernel, DicePoolKernel, BettingKernel.
All tests are fully deterministic — zero LLM involvement.
"""

from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.game_kernels import (
    AbstractStrategyKernel,
    AuctionKernel,
    BettingKernel,
    DeckKernel,
    DicePoolKernel,
    GameKernel,
    GuessingKernel,
    KERNEL_REGISTRY,
    MemoryKernel,
    SetCollectionKernel,
    StrengthContestKernel,
    SUITS,
    TrickTakingKernel,
    match_kernel,
)
import pytest


def _play_to_terminal(kernel: GameKernel, persona: str = "greedy", cap: int = 5000) -> dict:
    """Helper: play a kernel to terminal using bot_action, checking invariants."""
    s = kernel.init_state()
    steps = 0
    while not kernel.is_terminal(s):
        acts = kernel.legal_actions(s)
        assert acts, f"stuck with no legal actions at step {steps}"
        a = kernel.bot_action(s, persona)
        assert a in acts, f"bot returned illegal action {a!r}; legal={acts}"
        s = kernel.apply(s, a)
        if hasattr(kernel, "check_invariants"):
            assert kernel.check_invariants(s), f"invariant violated at step {steps}"
        steps += 1
        assert steps < cap, "kernel did not terminate"
    return s


# ===================================================================
# DeckKernel tests
# ===================================================================
class TestDeckKernel:
    def test_init_deals_cards(self) -> None:
        k = DeckKernel({"num_players": 4, "seed": 0})
        s = k.init_state()
        assert len(s["hands"]) == 4
        for p in ["p0", "p1", "p2", "p3"]:
            assert len(s["hands"][p]) == 52 // 4  # 13 cards each

    def test_legal_actions_lead_any(self) -> None:
        k = DeckKernel({"num_players": 2, "seed": 0})
        s = k.init_state()
        acts = k.legal_actions(s)
        assert len(acts) == len(s["hands"]["p0"])
        assert all(a.startswith("play_") for a in acts)

    def test_legal_actions_follow_suit(self) -> None:
        """After a card is led, the next player must follow suit if possible."""
        k = DeckKernel({"num_players": 2, "seed": 1})
        s = k.init_state()
        # Take the first action to lead a card
        acts = k.legal_actions(s)
        first = acts[0]
        led_card = first[5:]
        led_suit = led_card[0]
        s2 = k.apply(s, first)
        # Now it's the second player's turn — they must follow suit
        acts2 = k.legal_actions(s2)
        for a in acts2:
            card = a[5:]
            assert card[0] == led_suit or all(
                c[0] != led_suit for c in s2["hands"]["p1"]
            )

    def test_full_hand_completes(self) -> None:
        """A full 2-player hand with 26 cards (13 each) must terminate."""
        k = DeckKernel({"num_players": 2, "seed": 42, "num_cards": 13})
        s = k.init_state()
        steps = 0
        while not k.is_terminal(s):
            acts = k.legal_actions(s)
            assert acts, f"stuck at step {steps}"
            s = k.apply(s, acts[0])
            steps += 1
            assert steps < 100, "did not terminate within expected steps"
        total_cards = 13 * 2  # 2 players, 13 cards each
        assert steps == total_cards

    def test_has_winner(self) -> None:
        k = DeckKernel({"num_players": 2, "seed": 42, "num_cards": 3})
        s = k.init_state()
        while not k.is_terminal(s):
            acts = k.legal_actions(s)
            s = k.apply(s, acts[0])
        w = k.winner(s)
        # There should always be a winner (or tie) at end
        assert w is None or w in ("p0", "p1")

    def test_bot_action_returns_legal(self) -> None:
        k = DeckKernel({"num_players": 2, "seed": 0, "num_cards": 3})
        s = k.init_state()
        for persona in ("greedy", "aggressive", "conservative", "reckless", "cheater"):
            act = k.bot_action(s, persona)
            assert act in k.legal_actions(s), f"{persona}: {act} not legal"

    def test_bot_persona_different_strategies(self) -> None:
        """Greedy bot should play the highest card; conservative the lowest."""
        k = DeckKernel({"num_players": 2, "seed": 0, "num_cards": 3})
        s = k.init_state()
        # On the first lead (no led suit), greedy plays highest, conservative lowest
        hand = s["hands"]["p0"]
        greedy_act = k.bot_action(s, "greedy")
        cons_act = k.bot_action(s, "conservative")
        greedy_card = greedy_act[5:]
        cons_card = cons_act[5:]
        greedy_rank = int(greedy_card[1:]) if greedy_card[1:].isdigit() else {"J": 11, "Q": 12, "K": 13, "A": 14}[greedy_card[1:]]
        cons_rank = int(cons_card[1:]) if cons_card[1:].isdigit() else {"J": 11, "Q": 12, "K": 13, "A": 14}[cons_card[1:]]
        # Greedy should play something higher than conservative (or equal if only 1 card)
        assert greedy_rank >= cons_rank

    def test_terminal_eventually_true(self) -> None:
        k = DeckKernel({"num_players": 4, "seed": 7, "num_cards": 3})
        s = k.init_state()
        for _ in range(500):
            if k.is_terminal(s):
                return
            acts = k.legal_actions(s)
            s = k.apply(s, acts[0])
        pytest.fail("DeckKernel did not terminate")


# ===================================================================
# DicePoolKernel tests
# ===================================================================
class TestDicePoolKernel:
    def test_init_state(self) -> None:
        k = DicePoolKernel({"num_players": 2, "num_dice": 5, "seed": 0})
        s = k.init_state()
        assert s["dice"] == [0, 0, 0, 0, 0]
        assert s["phase"] == "playing"
        assert s["round"] == 0

    def test_legal_actions_before_roll(self) -> None:
        """Before any roll, only 'roll' is legal (no dice to hold)."""
        k = DicePoolKernel({"num_players": 2, "num_dice": 3, "seed": 0})
        s = k.init_state()
        acts = k.legal_actions(s)
        assert acts == ["roll"]

    def test_roll_produces_values(self) -> None:
        k = DicePoolKernel({"num_players": 2, "num_dice": 5, "sides": 6, "seed": 1})
        s = k.init_state()
        s2 = k.apply(s, "roll")
        assert all(1 <= v <= 6 for v in s2["dice"])
        assert s2["roll_count"] == 1

    def test_hold_and_unhold(self) -> None:
        k = DicePoolKernel({"num_players": 2, "num_dice": 3, "seed": 2})
        s = k.apply(k.init_state(), "roll")
        # Hold die 0
        s2 = k.apply(s, "hold_0")
        assert s2["held"][0] is True
        # Unhold it
        s3 = k.apply(s2, "unhold_0")
        assert s3["held"][0] is False

    def play_until_terminal(self, k: DicePoolKernel) -> dict:
        """Helper: play a DicePoolKernel game to completion using a simple
        strategy that always terminates: roll first, then end turn."""
        s = k.init_state()
        while not k.is_terminal(s):
            acts = k.legal_actions(s)
            assert acts, "stuck with no legal actions"
            # Simple strategy: roll first, then end turn
            if "roll" in acts and s["roll_count"] < k._max_rolls:
                s = k.apply(s, "roll")
            elif "end_turn" in acts:
                s = k.apply(s, "end_turn")
            elif "hold_0" in acts:
                s = k.apply(s, "hold_0")
            else:
                s = k.apply(s, acts[0])
        return s

    def test_full_game_reaches_terminal(self) -> None:
        """A full game with 1 round, 2 players must terminate."""
        k = DicePoolKernel({"num_players": 2, "num_dice": 3, "rounds": 1,
                            "max_rolls": 2, "seed": 3})
        s = self.play_until_terminal(k)
        assert k.is_terminal(s)

    def test_score_accumulates(self) -> None:
        k = DicePoolKernel({"num_players": 2, "num_dice": 3, "rounds": 1,
                            "max_rolls": 3, "seed": 4})
        s = self.play_until_terminal(k)
        # Scores should be non-negative integers
        for score in s["scores"].values():
            assert score >= 0

    def test_bot_action_returns_legal(self) -> None:
        k = DicePoolKernel({"num_players": 2, "num_dice": 3, "seed": 5})
        s = k.apply(k.init_state(), "roll")
        for persona in ("aggressive", "greedy", "conservative", "reckless"):
            act = k.bot_action(s, persona)
            assert act in k.legal_actions(s), f"{persona}: {act} not in {k.legal_actions(s)}"

    def test_terminal_eventually_true(self) -> None:
        k = DicePoolKernel({"num_players": 2, "num_dice": 3, "seed": 6})
        s = self.play_until_terminal(k)
        assert k.is_terminal(s)


# ===================================================================
# BettingKernel tests
# ===================================================================
class TestBettingKernel:
    def test_init_state(self) -> None:
        k = BettingKernel({"num_players": 2, "seed": 0})
        s = k.init_state()
        assert s["phase"] == "betting"
        assert len(s["hand_strength"]) == 2
        for v in s["hand_strength"].values():
            assert 0.0 <= v <= 1.0

    def test_legal_actions_initial(self) -> None:
        """First player must be able to check, bet, or fold."""
        k = BettingKernel({"num_players": 2, "seed": 0})
        s = k.init_state()
        acts = k.legal_actions(s)
        assert "check" in acts
        assert any(a.startswith("bet_") for a in acts)
        assert "fold" in acts
        assert "call" not in acts  # no bet outstanding yet

    def test_bet_and_call(self) -> None:
        k = BettingKernel({"num_players": 2, "seed": 1})
        s = k.init_state()
        # p0 bets
        bet_act = [a for a in k.legal_actions(s) if a.startswith("bet_")][0]
        s2 = k.apply(s, bet_act)
        assert s2["current_bet"] > 0
        # p1 now sees the bet — can call, fold, or raise
        acts2 = k.legal_actions(s2)
        assert "call" in acts2
        assert "fold" in acts2
        # p1 calls
        s3 = k.apply(s2, "call")
        assert s3["phase"] in ("showdown", "finished")

    def test_check_round(self) -> None:
        """Both players check -> showdown."""
        k = BettingKernel({"num_players": 2, "seed": 2})
        s = k.init_state()
        # p0 checks
        s2 = k.apply(s, "check")
        # p1 now checks too
        acts2 = k.legal_actions(s2)
        assert "check" in acts2
        s3 = k.apply(s2, "check")
        assert s3["phase"] == "showdown" or s3["phase"] == "finished"

    def test_fold_ends_hand(self) -> None:
        """If one player folds, hand ends immediately."""
        k = BettingKernel({"num_players": 2, "seed": 3})
        s = k.init_state()
        s2 = k.apply(s, "fold")
        assert k.is_terminal(s2)

    def test_showdown_awards_pot(self) -> None:
        k = BettingKernel({"num_players": 2, "seed": 4})
        s = k.init_state()
        total_chips_before = sum(s["chips"].values())
        s2 = k.apply(s, "check")
        s3 = k.apply(s2, "check")
        assert k.is_terminal(s3)
        total_chips_after = sum(s3["chips"].values())
        assert total_chips_after == total_chips_before  # chips conserved

    def test_winner_is_determined(self) -> None:
        k = BettingKernel({"num_players": 2, "seed": 5})
        s = k.init_state()
        while not k.is_terminal(s):
            acts = k.legal_actions(s)
            s = k.apply(s, acts[0])
        w = k.winner(s)
        assert w is None or w in ("p0", "p1")

    def test_bot_action_returns_legal(self) -> None:
        k = BettingKernel({"num_players": 2, "seed": 6})
        s = k.init_state()
        for persona in ("greedy", "aggressive", "conservative", "cheater", "reckless"):
            act = k.bot_action(s, persona)
            assert act in k.legal_actions(s), f"{persona}: {act} not legal"

    def test_terminal_eventually_true(self) -> None:
        k = BettingKernel({"num_players": 3, "seed": 7})
        s = k.init_state()
        for _ in range(200):
            if k.is_terminal(s):
                return
            acts = k.legal_actions(s)
            s = k.apply(s, acts[0] if acts else "")
        pytest.fail("BettingKernel did not terminate")


# ===================================================================
# KERNEL_REGISTRY tests
# ===================================================================
class TestKernelRegistry:
    def test_registry_contains_expected(self) -> None:
        assert "deck" in KERNEL_REGISTRY
        assert "dice_pool" in KERNEL_REGISTRY
        assert "betting" in KERNEL_REGISTRY
        assert "trick" in KERNEL_REGISTRY
        assert "set_collection" in KERNEL_REGISTRY
        assert "memory" in KERNEL_REGISTRY
        assert "abstract_strategy" in KERNEL_REGISTRY
        assert "guessing" in KERNEL_REGISTRY
        assert "auction" in KERNEL_REGISTRY
        assert "strength" in KERNEL_REGISTRY

    def test_registry_values_are_classes(self) -> None:
        for name, cls in KERNEL_REGISTRY.items():
            assert issubclass(cls, GameKernel), f"{name} is not a GameKernel subclass"


# ===================================================================
# TrickTakingKernel tests
# ===================================================================
class TestTrickTakingKernel:
    def test_init_state(self) -> None:
        k = TrickTakingKernel({"num_players": 4, "cards_per_hand": 7, "seed": 0})
        s = k.init_state()
        assert s["phase"] == "playing"
        assert s["trump"] in SUITS
        for p in s["hands"].values():
            assert len(p) == 7

    def test_deterministic_same_seed(self) -> None:
        k1 = TrickTakingKernel({"num_players": 3, "cards_per_hand": 5, "seed": 11})
        k2 = TrickTakingKernel({"num_players": 3, "cards_per_hand": 5, "seed": 11})
        s1 = k1.init_state()
        s2 = k2.init_state()
        assert s1["hands"] == s2["hands"]
        assert s1["trump"] == s2["trump"]

    def test_terminates_and_invariants(self) -> None:
        k = TrickTakingKernel({"num_players": 3, "cards_per_hand": 5,
                               "num_rounds": 2, "seed": 3})
        s = _play_to_terminal(k)
        assert k.is_terminal(s)
        # cumulative tricks across rounds sum to rounds * cards_per_hand
        assert sum(s["cumulative"].values()) == 2 * 5

    def test_follow_suit_legal(self) -> None:
        k = TrickTakingKernel({"num_players": 2, "cards_per_hand": 4, "seed": 1})
        s = k.init_state()
        lead = k.legal_actions(s)[0]
        led_suit = lead[5]
        s2 = k.apply(s, lead)
        for a in k.legal_actions(s2):
            assert a[5] == led_suit or all(c[0] != led_suit for c in s2["hands"]["p1"])

    def test_trump_wins_over_lead_suit(self) -> None:
        k = TrickTakingKernel({"num_players": 2, "cards_per_hand": 4, "seed": 5,
                               "trump": "S"})
        s = k.init_state()
        # find p0 hand with a spade available to set up a scenario
        # just ensure trump is honored: play through and confirm terminal
        s_final = _play_to_terminal(k)
        assert k.is_terminal(s_final)

    def test_boundary_min_players_min_rounds(self) -> None:
        k = TrickTakingKernel({"num_players": 2, "cards_per_hand": 1,
                               "num_rounds": 1, "seed": 0})
        s = _play_to_terminal(k, cap=50)
        assert k.is_terminal(s)

    def test_bot_returns_legal(self) -> None:
        k = TrickTakingKernel({"num_players": 2, "cards_per_hand": 3, "seed": 2})
        s = k.init_state()
        for persona in ("greedy", "aggressive", "conservative", "reckless"):
            a = k.bot_action(s, persona)
            assert a in k.legal_actions(s)


# ===================================================================
# SetCollectionKernel tests
# ===================================================================
class TestSetCollectionKernel:
    def test_init_state(self) -> None:
        k = SetCollectionKernel({"num_players": 3, "ranks": 6, "copies": 4, "seed": 0})
        s = k.init_state()
        assert s["phase"] == "playing"
        assert len(s["pool"]) == 3
        assert len(s["deck"]) == 6 * 4 - 3

    def test_deterministic_same_seed(self) -> None:
        k1 = SetCollectionKernel({"seed": 7})
        k2 = SetCollectionKernel({"seed": 7})
        s1, s2 = k1.init_state(), k2.init_state()
        assert s1["pool"] == s2["pool"]
        assert s1["deck"] == s2["deck"]

    def test_terminates_and_invariants(self) -> None:
        k = SetCollectionKernel({"num_players": 3, "ranks": 5, "copies": 4, "seed": 4})
        s = _play_to_terminal(k)
        assert k.is_terminal(s)
        assert not s["deck"] and not s["pool"]
        # all tiles distributed into banks and hands
        banked_tiles = sum(len(st) for sets in s["banked"].values() for st in sets)
        hand_total = sum(len(h) for h in s["hands"].values())
        assert banked_tiles + hand_total == 5 * 4

    def test_auto_banks_three_of_a_kind(self) -> None:
        k = SetCollectionKernel({"num_players": 2, "ranks": 3, "copies": 4,
                                 "pool_size": 3, "seed": 9})
        s = k.init_state()
        # force p0 to take tiles until a set banks
        steps = 0
        while s["scores"]["p0"] == 0 and not k.is_terminal(s):
            # take index 0 repeatedly to concentrate one rank
            s = k.apply(s, "take_0")
            k.check_invariants(s)
            steps += 1
            assert steps < 60
        assert s["scores"]["p0"] > 0

    def test_boundary_min_config(self) -> None:
        k = SetCollectionKernel({"num_players": 2, "ranks": 3, "copies": 3,
                                 "pool_size": 2, "seed": 0})
        s = _play_to_terminal(k)
        assert k.is_terminal(s)

    def test_bot_returns_legal(self) -> None:
        k = SetCollectionKernel({"seed": 2})
        s = k.init_state()
        for persona in ("greedy", "conservative", "reckless"):
            a = k.bot_action(s, persona)
            assert a in k.legal_actions(s)


# ===================================================================
# MemoryKernel tests
# ===================================================================
class TestMemoryKernel:
    def test_init_state(self) -> None:
        k = MemoryKernel({"num_pairs": 6, "num_players": 2, "seed": 0})
        s = k.init_state()
        assert s["phase"] == "select1"
        assert len(s["positions"]) == 12
        from collections import Counter
        assert set(Counter(s["positions"]).values()) == {2}

    def test_deterministic_same_seed(self) -> None:
        k1 = MemoryKernel({"num_pairs": 5, "seed": 3})
        k2 = MemoryKernel({"num_pairs": 5, "seed": 3})
        assert k1.init_state()["positions"] == k2.init_state()["positions"]

    def test_terminates_and_invariants(self) -> None:
        k = MemoryKernel({"num_pairs": 6, "num_players": 2, "seed": 8})
        s = _play_to_terminal(k)
        assert k.is_terminal(s)
        assert len(s["matched"]) == 12

    def test_match_scores_pair(self) -> None:
        k = MemoryKernel({"num_pairs": 4, "num_players": 2, "seed": 1})
        s = k.init_state()
        # find two positions with the same value and flip them
        pos = s["positions"]
        match = None
        for i in range(len(pos)):
            for j in range(i + 1, len(pos)):
                if pos[i] == pos[j]:
                    match = (i, j)
                    break
            if match:
                break
        i, j = match
        s2 = k.apply(s, f"flip_{i}")
        assert s2["phase"] == "select2"
        s3 = k.apply(s2, f"flip_{j}")
        assert s3["scores"]["p0"] == 1
        assert i in s3["matched"] and j in s3["matched"]

    def test_boundary_min_pairs(self) -> None:
        k = MemoryKernel({"num_pairs": 3, "num_players": 2, "seed": 0})
        s = _play_to_terminal(k, cap=200)
        assert k.is_terminal(s)

    def test_bot_returns_legal(self) -> None:
        k = MemoryKernel({"num_pairs": 4, "seed": 2})
        s = k.init_state()
        for persona in ("greedy", "conservative", "reckless"):
            a = k.bot_action(s, persona)
            assert a in k.legal_actions(s)


# ===================================================================
# AbstractStrategyKernel tests
# ===================================================================
class TestAbstractStrategyKernel:
    def test_init_state(self) -> None:
        k = AbstractStrategyKernel({"width": 3, "height": 3, "win_length": 3, "seed": 0})
        s = k.init_state()
        assert s["phase"] == "playing"
        assert len(s["board"]) == 9
        assert all(v is None for v in s["board"])

    def test_deterministic_same_seed(self) -> None:
        k1 = AbstractStrategyKernel({"seed": 4})
        k2 = AbstractStrategyKernel({"seed": 4})
        assert k1.init_state() == k2.init_state()

    def test_terminates_and_invariants(self) -> None:
        k = AbstractStrategyKernel({"width": 4, "height": 4, "win_length": 4, "seed": 6})
        s = _play_to_terminal(k)
        assert k.is_terminal(s)
        # board full or a winner exists
        assert all(v is not None for v in s["board"]) or s["winner_id"] is not None

    def test_win_detection(self) -> None:
        k = AbstractStrategyKernel({"width": 3, "height": 3, "win_length": 3, "seed": 0})
        s = k.init_state()
        s = k.apply(s, "place_0")  # p0
        s = k.apply(s, "place_3")  # p1
        s = k.apply(s, "place_1")  # p0
        s = k.apply(s, "place_4")  # p1
        s = k.apply(s, "place_2")  # p0 wins top row
        assert k.is_terminal(s)
        assert k.winner(s) == "p0"

    def test_boundary_min_board(self) -> None:
        k = AbstractStrategyKernel({"width": 3, "height": 3, "win_length": 3, "seed": 0})
        s = _play_to_terminal(k, cap=50)
        assert k.is_terminal(s)

    def test_bot_blocks_winning_move(self) -> None:
        k = AbstractStrategyKernel({"width": 3, "height": 3, "win_length": 3, "seed": 0})
        s = k.init_state()
        # set up: p0 at 0,1 ; p1 to move should block at 2
        s = k.apply(s, "place_0")  # p0
        s = k.apply(s, "place_3")  # p1
        s = k.apply(s, "place_1")  # p0 threatens 2
        # p1 to move
        a = k.bot_action(s, "greedy")
        assert a == "place_2"


# ===================================================================
# GuessingKernel tests
# ===================================================================
class TestGuessingKernel:
    def test_init_state(self) -> None:
        k = GuessingKernel({"num_players": 2, "range_min": 1, "range_max": 100, "seed": 0})
        s = k.init_state()
        assert s["phase"] == "playing"
        assert 1 <= s["secret"] <= 100

    def test_deterministic_same_seed(self) -> None:
        k1 = GuessingKernel({"seed": 5})
        k2 = GuessingKernel({"seed": 5})
        assert k1.init_state()["secret"] == k2.init_state()["secret"]

    def test_terminates_and_invariants(self) -> None:
        k = GuessingKernel({"num_players": 2, "range_max": 100, "max_guesses": 7, "seed": 12})
        s = _play_to_terminal(k)
        assert k.is_terminal(s)
        assert s["low"] < s["secret"] < s["high"]

    def test_correct_guess_wins(self) -> None:
        k = GuessingKernel({"num_players": 2, "seed": 0})
        s = k.init_state()
        secret = s["secret"]
        s2 = k.apply(s, f"guess_{secret}")
        assert k.is_terminal(s2)
        assert k.winner(s2) == "p0"

    def test_feedback_updates_range(self) -> None:
        k = GuessingKernel({"num_players": 2, "seed": 0})
        s = k.init_state()
        secret = s["secret"]
        low_guess = max(1, secret - 30)
        s2 = k.apply(s, f"guess_{low_guess}")
        assert s2["feedback"] == "higher"
        assert s2["low"] == low_guess

    def test_boundary_small_range(self) -> None:
        k = GuessingKernel({"num_players": 2, "range_min": 1, "range_max": 3,
                            "max_guesses": 5, "seed": 0})
        s = _play_to_terminal(k, cap=50)
        assert k.is_terminal(s)

    def test_bot_returns_legal(self) -> None:
        k = GuessingKernel({"seed": 2})
        s = k.init_state()
        for persona in ("greedy", "conservative", "reckless"):
            a = k.bot_action(s, persona)
            assert a in k.legal_actions(s)


# ===================================================================
# AuctionKernel tests
# ===================================================================
class TestAuctionKernel:
    def test_init_state(self) -> None:
        k = AuctionKernel({"num_players": 3, "budget": 100, "num_items": 5, "seed": 0})
        s = k.init_state()
        assert s["phase"] == "bidding"
        assert len(s["item_values"]) == 5
        for v in s["budgets"].values():
            assert v == 100

    def test_deterministic_same_seed(self) -> None:
        k1 = AuctionKernel({"seed": 6})
        k2 = AuctionKernel({"seed": 6})
        assert k1.init_state()["item_values"] == k2.init_state()["item_values"]

    def test_terminates_and_invariants(self) -> None:
        k = AuctionKernel({"num_players": 3, "budget": 100, "num_items": 5, "seed": 15})
        s = _play_to_terminal(k)
        assert k.is_terminal(s)
        # budget conservation
        total_budget = sum(s["budgets"].values())
        total_spent = sum(s["spent"].values())
        assert total_budget + total_spent == 3 * 100

    def test_highest_bid_wins_item(self) -> None:
        k = AuctionKernel({"num_players": 2, "budget": 100, "num_items": 2, "seed": 0})
        s = k.init_state()
        # p0 bids 10, p1 bids 20 → p1 wins item 0
        s = k.apply(s, "bid_10")
        s = k.apply(s, "bid_20")
        assert s["item_idx"] == 1
        assert s["won_value"]["p1"] == s["item_values"][0]
        assert s["spent"]["p1"] == 20
        assert s["budgets"]["p1"] == 80

    def test_boundary_min_items(self) -> None:
        k = AuctionKernel({"num_players": 2, "budget": 20, "num_items": 2, "seed": 0})
        s = _play_to_terminal(k, cap=100)
        assert k.is_terminal(s)

    def test_bot_returns_legal(self) -> None:
        k = AuctionKernel({"seed": 2})
        s = k.init_state()
        for persona in ("greedy", "conservative", "cheater", "reckless"):
            a = k.bot_action(s, persona)
            assert a in k.legal_actions(s)


# ===================================================================
# StrengthContestKernel tests
# ===================================================================
class TestStrengthContestKernel:
    def test_init_state(self) -> None:
        k = StrengthContestKernel({"max_hp": 20, "rounds": 5, "seed": 0})
        s = k.init_state()
        assert s["phase"] == "select_p0"
        assert s["hp"] == {"p0": 20, "p1": 20}

    def test_deterministic_same_seed(self) -> None:
        k1 = StrengthContestKernel({"seed": 5})
        k2 = StrengthContestKernel({"seed": 5})
        assert k1.init_state() == k2.init_state()

    def test_terminates_and_invariants(self) -> None:
        k = StrengthContestKernel({"max_hp": 20, "rounds": 5, "seed": 13})
        s = _play_to_terminal(k)
        assert k.is_terminal(s)
        for hp in s["hp"].values():
            assert 0 <= hp <= 20

    def test_rps_resolution(self) -> None:
        k = StrengthContestKernel({"max_hp": 20, "rounds": 5, "seed": 0})
        s = k.init_state()
        # p0 aggressive beats p1 balanced → p1 takes 3
        s = k.apply(s, "stance_aggressive")
        s = k.apply(s, "stance_balanced")
        assert s["hp"]["p1"] == 17
        assert s["hp"]["p0"] == 20
        assert s["round"] == 1

    def test_tie_both_take_damage(self) -> None:
        k = StrengthContestKernel({"max_hp": 20, "rounds": 5, "seed": 0})
        s = k.init_state()
        s = k.apply(s, "stance_defensive")
        s = k.apply(s, "stance_defensive")
        assert s["hp"]["p0"] == 19 and s["hp"]["p1"] == 19

    def test_boundary_min_rounds(self) -> None:
        k = StrengthContestKernel({"max_hp": 10, "rounds": 1, "seed": 0})
        s = _play_to_terminal(k, cap=20)
        assert k.is_terminal(s)

    def test_bot_returns_legal(self) -> None:
        k = StrengthContestKernel({"seed": 2})
        s = k.init_state()
        for persona in ("greedy", "conservative", "reckless"):
            a = k.bot_action(s, persona)
            assert a in k.legal_actions(s)



class TestMatchKernel:
    def test_match_keywords_deck(self) -> None:
        assert match_kernel("打牌定胜负") == "deck"
        assert match_kernel("来玩扑克吧") == "deck"
        assert match_kernel("trick taking game") == "deck"

    def test_match_keywords_dice(self) -> None:
        assert match_kernel("掷骰子比大小") == "dice_pool"
        assert match_kernel("roll the dice") == "dice_pool"

    def test_match_keywords_betting(self) -> None:
        assert match_kernel("押注诈唬") == "betting"
        assert match_kernel("poker game") == "betting"
        assert match_kernel("德扑无限") == "betting"

    def test_match_keywords_new_kernels(self) -> None:
        assert match_kernel("猜数字游戏") == "guessing"
        assert match_kernel("猜谜推理") == "guessing"
        assert match_kernel("井字棋对决") == "abstract_strategy"
        assert match_kernel("五子连珠") == "abstract_strategy"
        assert match_kernel("记忆翻牌配对") == "memory"
        assert match_kernel("memory concentration") == "memory"
        assert match_kernel("拍卖竞价") == "auction"
        assert match_kernel("auction sealed bid") == "auction"
        assert match_kernel("凑集成套") == "set_collection"
        assert match_kernel("rummy collection") == "set_collection"
        assert match_kernel("将牌王牌") == "trick"
        assert match_kernel("trump game") == "trick"
        assert match_kernel("力量对抗比武") == "strength"

    def test_unknown_keywords_default(self) -> None:
        """Unknown descriptions should return a default kernel name."""
        name = match_kernel("玩个完全无关的游戏")
        assert name in KERNEL_REGISTRY


# ===================================================================
# Cross-kernel: bot_action with persona variations
# ===================================================================
class TestBotActionCrossKernel:
    def test_bot_persona_never_empty(self) -> None:
        for kls in KERNEL_REGISTRY.values():
            k = kls({"num_players": 2, "seed": 0})
            s = k.init_state()
            for persona in ("greedy", "aggressive", "conservative", "reckless"):
                act = k.bot_action(s, persona)
                legal = k.legal_actions(s)
                if legal:
                    assert act in legal, f"{kls.__name__}/{persona}: {act} not legal"

    def test_deterministic_given_seed(self) -> None:
        """Same seed yields same initial state."""
        k1 = DeckKernel({"seed": 0, "num_players": 2, "num_cards": 3})
        k2 = DeckKernel({"seed": 0, "num_players": 2, "num_cards": 3})
        s1 = k1.init_state()
        s2 = k2.init_state()
        assert s1["hands"] == s2["hands"]
