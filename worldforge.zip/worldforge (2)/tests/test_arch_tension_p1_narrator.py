"""P1 — 张力3: ThreeBodyNarrator is no longer an orphan; the dispatcher's
three-body narration path routes through it (§8.2 red-line guard lives on
the narrator, not duplicated in the dispatcher).

Before this fix, three_body_narrator.py had the §8.2 verdict-consistency
guard + 21 tests but the dispatcher never called it — _narrate_three_body
ran its own unguarded LLM path. These tests pin the unified path:
  * _narrate_three_body delegates parsing + guard to the narrator
  * the guard rejects an LLM survival-verdict flip
  * the guard rejects an LLM evacuation-verdict flip
  * no-LLM / empty output fails explicitly
  * bulleted-outline LLM output is still parsed (gemma compatibility)
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402
from theater.three_body_narrator import (  # noqa: E402
    ThreeBodyNarrator,
    _kernel_verdict_from_event_log,
    _parse_beat_json,
)


def _orch(tmp: Path) -> TheaterOrchestrator:
    return TheaterOrchestrator(
        state_store=JsonStateStore(tmp / "state"),
        model_client=DeterministicModelClient(),
    )


@pytest.fixture
def tmp_root(tmp_path):
    return tmp_path


# ---------------------------------------------------------------------------
# verdict extraction + parsing helpers
# ---------------------------------------------------------------------------


def test_kernel_verdict_survived_default():
    v = _kernel_verdict_from_event_log(["beat=3", "civ_survived", "tech_retained"])
    assert v["survived"] is True
    assert v["evac_possible"] is False


def test_kernel_verdict_destroyed_flips_survived():
    v = _kernel_verdict_from_event_log(["beat=3", "civ_destroyed", "tech_reset"])
    assert v["survived"] is False


def test_kernel_verdict_evacuation_proven():
    v = _kernel_verdict_from_event_log(["beat=9", "evacuation_proven"])
    assert v["evac_possible"] is True


def test_parse_beat_json_strict():
    out = _parse_beat_json('{"title":"t","narrative":"n","dialogue":"d"}')
    assert out == {"title": "t", "narrative": "n", "dialogue": "d"}


def test_parse_beat_json_fenced():
    out = _parse_beat_json('```json\n{"title":"t","narrative":"n","dialogue":"d"}\n```')
    assert out["narrative"] == "n"


def test_parse_beat_json_bulleted_outline():
    """gemma-style bulleted outline must still parse (compatibility)."""
    text = "* Title: 恒星的审判\n* Narrative: 陆远跪在观测台。\n* Dialogue: 又结束了。"
    out = _parse_beat_json(text)
    assert out["title"] == "恒星的审判"
    assert "陆远" in out["narrative"]
    assert out["dialogue"] == "又结束了。"


def test_parse_beat_json_empty():
    assert _parse_beat_json("") == {}


# ---------------------------------------------------------------------------
# narrate_beat: strict guard (the runtime path)
# ---------------------------------------------------------------------------


def test_narrate_beat_no_llm_rejected_survived():
    n = ThreeBodyNarrator(llm_fn=None, seed=1)
    with pytest.raises(RuntimeError, match="requires LLM output"):
        n.narrate_beat(["beat=2", "civ_survived"], "历史", llm_content=None)


def test_narrate_beat_no_llm_rejected_destroyed():
    n = ThreeBodyNarrator(llm_fn=None, seed=1)
    with pytest.raises(RuntimeError, match="requires LLM output"):
        n.narrate_beat(["beat=2", "civ_destroyed"], "历史", llm_content=None)


def test_narrate_beat_no_llm_rejected_evacuation():
    n = ThreeBodyNarrator(llm_fn=None, seed=1)
    with pytest.raises(RuntimeError, match="requires LLM output"):
        n.narrate_beat(["beat=5", "evacuation_proven"], "历史", llm_content=None)


def test_narrate_beat_accepts_consistent_llm_output():
    n = ThreeBodyNarrator(llm_fn=None, seed=1)
    llm = '{"title":"恒纪元","narrative":"文明幸存，科技保留。","dialogue":"活下来了。"}'
    out = n.narrate_beat(["beat=2", "civ_survived"], "历史", llm_content=llm)
    assert out["warnings"] == []
    assert "幸存" in out["narrative"]


def test_narrate_beat_rejects_llm_flip_survival():
    n = ThreeBodyNarrator(llm_fn=None, seed=1)
    llm = ('{"title":"审判","narrative":"文明灭绝，一切重启，科技归零。",'
           '"dialogue":"完了。"}')
    with pytest.raises(RuntimeError, match="survival verdict"):
        n.narrate_beat(
            ["beat=2", "civ_survived"], "历史", llm_content=llm
        )


def test_narrate_beat_rejects_llm_flip_evacuation():
    n = ThreeBodyNarrator(llm_fn=None, seed=1)
    llm = ('{"title":"决断","narrative":"逃离可行，我们走吧。","dialogue":"走。"}')
    with pytest.raises(RuntimeError, match="evacuation verdict"):
        n.narrate_beat(
            ["beat=2", "civ_survived"], "历史", llm_content=llm
        )


def test_narrate_beat_malformed_llm_content_fails():
    n = ThreeBodyNarrator(llm_fn=None, seed=1)
    with pytest.raises(RuntimeError, match="empty or malformed"):
        n.narrate_beat(
            ["beat=2", "civ_survived"],
            "历史",
            llm_content="not json at all",
        )


# ---------------------------------------------------------------------------
# dispatcher integration: _narrate_three_body delegates to the narrator
# ---------------------------------------------------------------------------


def test_dispatcher_narrate_three_body_fails_on_api_failure(tmp_root):
    import urllib.error

    orch = _orch(tmp_root)
    from theater.settings import Settings
    orch.settings = Settings(
        api_key="test-key",
        base_url="http://provider.invalid/v1",
        model_fast="test-model",
        model_deep="test-model",
        enable_live_api=True,
    )

    def _boom(*a, **kw):
        raise urllib.error.URLError("no spark")

    # Patch urllib.request.urlopen via monkeypatch on the module the
    # dispatcher imports at call time.
    import urllib.request as ur
    orig = ur.urlopen
    ur.urlopen = _boom
    try:
        with pytest.raises(RuntimeError, match="LLM narration failed"):
            orch._narrate_three_body(["beat=2", "civ_survived"], "历史")
    finally:
        ur.urlopen = orig


def test_dispatcher_narrate_three_body_routes_llm_content_through_guard(tmp_root):
    """A consistent LLM output passes; the dispatcher keeps its HTTP contract
    while the narrator owns the guard."""
    orch = _orch(tmp_root)
    from theater.settings import Settings
    orch.settings = Settings(
        api_key="test-key",
        base_url="http://provider.invalid/v1",
        model_fast="test-model",
        model_deep="test-model",
        enable_live_api=True,
    )
    # Stub the HTTP fetch to return a consistent narration.
    import urllib.request as ur

    class _FakeResp:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return None

        def read(self):
            import json as _json
            return _json.dumps({"choices": [{"message": {
                "content": '{"title":"恒纪元","narrative":"文明幸存，科技保留。",'
                           '"dialogue":"活下来了。"}'}}]}).encode()

    orig = ur.urlopen
    ur.urlopen = lambda *a, **kw: _FakeResp()
    try:
        out = orch._narrate_three_body(["beat=2", "civ_survived"], "历史")
    finally:
        ur.urlopen = orig
    assert out["warnings"] == []
    assert "幸存" in out["narrative"]


def test_dispatcher_uses_singleton_narrator(tmp_root):
    orch = _orch(tmp_root)
    n1 = orch._three_body_narrator()
    n2 = orch._three_body_narrator()
    assert n1 is n2
    assert isinstance(n1, ThreeBodyNarrator)
