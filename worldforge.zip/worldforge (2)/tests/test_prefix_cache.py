"""Tests for the RadixAttention prefix cache (architecture spec §5.2, §13.6).

All tests are deterministic and run in seconds.  The spec mandates that
the prefix cache hit rate stays > 80% and that the world-state prefix
is pinned and never evicted.
"""

from __future__ import annotations

import os
import sys

import pytest

# Allow running from project root without setting PYTHONPATH.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.prefix_cache import PrefixCache, SharedPrefixManager  # noqa: E402


# ======================================================================
# PrefixCache — put / get basic
# ======================================================================

class TestPutGet:
    def test_put_and_get_exact_match(self):
        cache = PrefixCache(max_entries=10)
        cache.put("Hello, ", "world")
        assert cache.get("Hello, ") == "world"

    def test_get_returns_none_on_miss(self):
        cache = PrefixCache(max_entries=10)
        assert cache.get("nothing") is None

    def test_get_overwrites_on_re_put(self):
        cache = PrefixCache(max_entries=10)
        cache.put("key", "v1")
        cache.put("key", "v2")
        assert cache.get("key") == "v2"

    def test_empty_cache_get_returns_none(self):
        assert PrefixCache(max_entries=10).get("x") is None


# ======================================================================
# PrefixCache — 最长前缀匹配
# ======================================================================

class TestLongestPrefix:
    def test_longest_prefix_wins(self):
        cache = PrefixCache(max_entries=10)
        cache.put("short", "s")
        cache.put("shorter", "r")
        # "shorterX" starts with both "short" and "shorter" → "shorter" wins
        assert cache.get("shorterX") == "r"

    def test_exact_match_preferred_over_shorter_prefix(self):
        cache = PrefixCache(max_entries=10)
        cache.put("abc", "exact")
        cache.put("ab", "prefix")
        assert cache.get("abc") == "exact"

    def test_prefix_not_contaminates_other_keys(self):
        cache = PrefixCache(max_entries=10)
        cache.put("abc", "data")
        assert cache.get("ab") is None
        assert cache.get("abcd") == "data"


# ======================================================================
# PrefixCache — LRU 淘汰（非 pinned）
# ======================================================================

class TestLRUEviction:
    def test_evict_oldest_when_full(self):
        cache = PrefixCache(max_entries=3)
        cache.put("a", "1")
        cache.put("b", "2")
        cache.put("c", "3")
        cache.put("d", "4")  # "a" should be evicted
        assert cache.get("a") is None
        assert cache.get("b") == "2"
        assert cache.get("c") == "3"
        assert cache.get("d") == "4"

    def test_lru_get_moves_to_end(self):
        cache = PrefixCache(max_entries=2)
        cache.put("a", "1")
        cache.put("b", "2")
        cache.get("a")           # access → "a" becomes most recent
        cache.put("c", "3")      # evict "b", not "a"
        assert cache.get("a") == "1"
        assert cache.get("b") is None

    def test_evict_removes_one_non_pinned(self):
        cache = PrefixCache(max_entries=10)
        cache.put("a", "1")
        cache.put("b", "2")
        cache.evict()
        assert cache.get("a") is None
        assert cache.get("b") == "2"  # "b" is now LRU head


# ======================================================================
# PrefixCache — pinned 不淘汰
# ======================================================================

class TestPinned:
    def test_pinned_not_evicted_by_lru(self):
        cache = PrefixCache(max_entries=2)
        cache.pin("world_state_xxx")
        cache.put("a", "1")
        cache.put("b", "2")
        # "a" was put first → evicted; cache has pinned + "b"
        cache.put("c", "3")  # "b" evicted or kept depending on order
        # pinned entry is never evicted
        assert cache.get("world_state_xxx") is not None

    def test_pin_moves_from_lru_to_pinned(self):
        cache = PrefixCache(max_entries=5)
        cache.put("important", "data")
        cache.pin("important")
        # important is now pinned; fill and evict many times
        for i in range(20):
            cache.put(f"filler_{i}", str(i))
        assert cache.get("important") == "data"

    def test_unpin_returns_entry_to_lru(self):
        cache = PrefixCache(max_entries=4)
        cache.put("p", "data")
        cache.pin("p")
        cache.put("a", "1")
        cache.put("b", "2")
        cache.unpin("p")
        # now "p" is in LRU; fill to trigger evictions
        cache.put("c", "3")
        cache.put("d", "4")
        assert cache.get("p") is not None  # "p" still alive
        cache.put("e", "5")
        cache.put("f", "6")
        assert cache.get("p") is not None  # still alive
        cache.put("g", "7")
        assert cache.get("p") == "data"

    def test_pin_already_pinned_is_idempotent(self):
        cache = PrefixCache(max_entries=5)
        cache.pin("x")
        cache.pin("x")  # no error


# ======================================================================
# PrefixCache — hit_rate 跟踪
# ======================================================================

class TestHitRate:
    def test_hit_rate_starts_at_zero(self):
        cache = PrefixCache(max_entries=10)
        assert cache.hit_rate == 0.0

    def test_hit_rate_after_misses_only(self):
        cache = PrefixCache(max_entries=10)
        cache.get("miss1")
        cache.get("miss2")
        cache.get("miss3")
        assert cache.hit_rate == 0.0

    def test_hit_rate_after_hits_only(self):
        cache = PrefixCache(max_entries=10)
        cache.put("key", "val")
        cache.get("key")
        cache.get("key")
        assert cache.hit_rate == 1.0

    def test_hit_rate_mixed(self):
        cache = PrefixCache(max_entries=10)
        cache.put("hit", "v")
        cache.get("hit")    # hit
        cache.get("miss")   # miss
        cache.get("hit")    # hit
        # 2 hits / 3 total = 0.666...
        assert cache.hit_rate == pytest.approx(2 / 3)

    def test_stats_returns_dict(self):
        cache = PrefixCache(max_entries=10)
        cache.put("a", "1")
        cache.pin("p")
        s = cache.stats()
        assert "hit_rate" in s
        assert "cache_size" in s
        assert "pinned_count" in s
        assert s["pinned_count"] == 1


# ======================================================================
# PrefixCache — edge cases
# ======================================================================

class TestEdgeCases:
    def test_max_entries_must_be_positive(self):
        with pytest.raises(ValueError):
            PrefixCache(max_entries=0)
        with pytest.raises(ValueError):
            PrefixCache(max_entries=-1)

    def test_put_empty_string_key(self):
        cache = PrefixCache(max_entries=10)
        cache.put("", "empty")
        assert cache.get("") == "empty"

    def test_evict_on_empty_cache_does_nothing(self):
        cache = PrefixCache(max_entries=5)
        cache.evict()  # no error


# ======================================================================
# SharedPrefixManager
# ======================================================================

class TestSharedPrefixManager:
    def test_initial_world_prefix_is_pinned(self):
        cache = PrefixCache(max_entries=10)
        mgr = SharedPrefixManager(cache, initial_world_prefix="WORLD:")
        # pinned entry exists; filling cache shouldn't evict it
        for i in range(20):
            cache.put(f"filler_{i}", str(i))
        assert cache.get("WORLD:rest") is not None

    def test_build_prompt_concatenates(self):
        cache = PrefixCache(max_entries=10)
        mgr = SharedPrefixManager(cache)
        prompt = mgr.build_prompt("W", "S", "P")
        assert prompt == "WSP"

    def test_world_state_change_updates_prefix(self):
        cache = PrefixCache(max_entries=10)
        mgr = SharedPrefixManager(cache, initial_world_prefix="old:")
        # change world state
        mgr.world_state_prefix = "new:"
        assert mgr.world_state_prefix == "new:"
        # new prefix is pinned (survives eviction)
        for i in range(20):
            cache.put(f"filler_{i}", str(i))
        assert cache.get("new:anything") is not None

    def test_invalidate_world_state_clears_non_pinned(self):
        cache = PrefixCache(max_entries=10)
        mgr = SharedPrefixManager(cache, initial_world_prefix="WORLD:")
        cache.put("temp1", "v1")
        cache.put("temp2", "v2")
        mgr.invalidate_world_state()
        # non-pinned cleared
        assert cache.get("temp1") is None
        # pinned still there
        assert cache.get("WORLD:anything") is not None

    def test_build_prompt_then_cache_hit(self):
        cache = PrefixCache(max_entries=10)
        mgr = SharedPrefixManager(cache)
        prompt = mgr.build_prompt("state_", "ctx_", "alice")
        cache.put(prompt, "output")
        # same prompt again → cache hit
        same = mgr.build_prompt("state_", "ctx_", "bob")
        assert cache.get(same) is None  # different persona → different prompt

    def test_shared_prefix_hit_across_personas(self):
        """共享的世界状态前缀应被所有人格命中。"""
        cache = PrefixCache(max_entries=10)
        mgr = SharedPrefixManager(cache, initial_world_prefix="WORLD:")
        cache.put("WORLD:", "world_cache")  # world prefix → cached output
        # bob's prompt starts with "WORLD:" → should hit
        result = cache.get("WORLD:context:bob")
        assert result == "world_cache"
