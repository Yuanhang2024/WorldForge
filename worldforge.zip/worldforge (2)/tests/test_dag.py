"""Tests for the prerequisite DAG component (architecture spec §8.3, §13.5).

All tests are deterministic and run in seconds. The spec mandates that
the DAG's universal-machine implementation be exercised here before any
downstream consumer (cognitive progression, fantasy recipe chains) can
rely on it.
"""

from __future__ import annotations

import os
import sys

import pytest

# Allow running from project root without setting PYTHONPATH.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.dag import (  # noqa: E402
    CycleError,
    PrerequisiteDAG,
    PrerequisiteError,
    UnknownNodeError,
    three_body_cognition_dag,
)


# -- helpers -----------------------------------------------------------------

def _chain(n: int) -> PrerequisiteDAG:
    """Build a linear chain a -> b -> c -> ... (n nodes, ids 'a'..chr)."""
    dag = PrerequisiteDAG()
    ids = [f"n{i}" for i in range(n)]
    for nid in ids:
        dag.add_node(nid)
    for a, b in zip(ids, ids[1:]):
        dag.add_edge(a, b)
    return dag


def _diamond() -> PrerequisiteDAG:
    """Build the classic diamond: top -> {left, right} -> bottom."""
    dag = PrerequisiteDAG()
    for nid in ("top", "left", "right", "bottom"):
        dag.add_node(nid)
    dag.add_edge("top", "left")
    dag.add_edge("top", "right")
    dag.add_edge("left", "bottom")
    dag.add_edge("right", "bottom")
    return dag


# -- add_edge cycle rejection ----------------------------------------------

def test_add_edge_rejects_self_loop():
    """A self-loop is the simplest cycle; must be rejected."""
    dag = PrerequisiteDAG()
    dag.add_node("a")
    with pytest.raises(CycleError):
        dag.add_edge("a", "a")


def test_add_edge_rejects_direct_cycle():
    """Two-node cycle a->b, b->a must be rejected."""
    dag = PrerequisiteDAG()
    dag.add_node("a")
    dag.add_node("b")
    dag.add_edge("a", "b")
    with pytest.raises(CycleError):
        dag.add_edge("b", "a")


def test_add_edge_rejects_transitive_cycle():
    """A transitive cycle a -> b -> c -> a must be rejected."""
    dag = _chain(3)  # a -> b -> c
    # Try to wire c back to a: c -> a would close a -> b -> c -> a.
    with pytest.raises(CycleError):
        dag.add_edge("n2", "n0")


def test_add_edge_rejects_long_cycle():
    """Long cycle a -> b -> c -> d -> b must be rejected at the b-> step."""
    dag = PrerequisiteDAG()
    for nid in ("a", "b", "c", "d"):
        dag.add_node(nid)
    dag.add_edge("a", "b")
    dag.add_edge("b", "c")
    dag.add_edge("c", "d")
    # d -> b would close a cycle (b -> c -> d -> b). Must reject.
    with pytest.raises(CycleError):
        dag.add_edge("d", "b")


def test_add_edge_unknown_node_raises():
    """Edges referencing unknown endpoints must raise."""
    dag = PrerequisiteDAG()
    dag.add_node("a")
    with pytest.raises(UnknownNodeError):
        dag.add_edge("a", "ghost")
    with pytest.raises(UnknownNodeError):
        dag.add_edge("ghost", "a")


def test_add_edge_is_idempotent_when_already_present():
    """Adding the same edge twice must not raise and must not double-add."""
    dag = PrerequisiteDAG()
    dag.add_node("a")
    dag.add_node("b")
    dag.add_edge("a", "b")
    dag.add_edge("a", "b")  # second call is a no-op
    assert dag.prerequisites("b") == ["a"]


# -- can_reach / is_unlocked ------------------------------------------------

def test_can_reach_locked_when_prereqs_missing():
    """A locked node with locked prereqs cannot be reached."""
    dag = _chain(3)
    # n2's only direct prereq is n1, which is locked.
    assert dag.can_reach("n2") is False
    assert dag.is_unlocked("n2") is False


def test_can_reach_true_after_unlocking_prereqs():
    """Once every prereq is unlocked, can_reach flips to True."""
    dag = _chain(3)
    dag.unlock("n0")
    assert dag.can_reach("n1") is True
    assert dag.is_unlocked("n1") is False  # not yet unlocked, just reachable
    dag.unlock("n1")
    assert dag.can_reach("n2") is True


def test_can_reach_unknown_node_raises():
    dag = PrerequisiteDAG()
    with pytest.raises(UnknownNodeError):
        dag.can_reach("nope")


def test_can_reach_on_diamond_needs_both_branches():
    """In a diamond, 'bottom' needs BOTH 'left' AND 'right' unlocked."""
    dag = _diamond()
    dag.unlock("top")
    dag.unlock("left")
    # right is still locked -> bottom not reachable
    assert dag.can_reach("bottom") is False
    dag.unlock("right")
    assert dag.can_reach("bottom") is True


def test_missing_prerequisites_lists_only_locked():
    """missing_prerequisites returns only the *locked* direct prereqs."""
    dag = _diamond()
    dag.unlock("top")
    # bottom's prereqs are left & right; both still locked
    assert sorted(dag.missing_prerequisites("bottom")) == ["left", "right"]
    dag.unlock("left")
    assert dag.missing_prerequisites("bottom") == ["right"]
    dag.unlock("right")
    assert dag.missing_prerequisites("bottom") == []


# -- advance: cannot skip nodes --------------------------------------------

def test_advance_rejects_when_prereqs_missing():
    """The user cannot skip nodes — advance must raise on missing prereqs
    (spec §8.3: 'user cannot skip nodes')."""
    dag = _chain(3)
    with pytest.raises(PrerequisiteError) as exc_info:
        dag.advance("n2")
    assert exc_info.value.node_id == "n2"
    assert "n1" in exc_info.value.missing
    # State must be unchanged.
    assert not dag.is_unlocked("n2")


def test_advance_succeeds_when_prereqs_unlocked():
    """advance should unlock the node when its prereqs are unlocked."""
    dag = _chain(3)
    dag.unlock("n0")
    dag.advance("n1")
    assert dag.is_unlocked("n1")
    dag.advance("n2")
    assert dag.is_unlocked("n2")


def test_advance_idempotent_on_already_unlocked_node():
    """Calling advance on an already-unlocked node is a no-op (no error)."""
    dag = _chain(3)
    dag.unlock("n0")
    dag.unlock("n1")  # via unlock(), not advance()
    dag.advance("n1")  # must not raise
    assert dag.is_unlocked("n1")


def test_advance_on_diamond_requires_both_branches():
    """Advance on the diamond's bottom must fail until BOTH branches unlock."""
    dag = _diamond()
    dag.unlock("top")
    dag.advance("left")
    with pytest.raises(PrerequisiteError):
        dag.advance("bottom")
    dag.advance("right")
    dag.advance("bottom")  # now succeeds
    assert dag.is_unlocked("bottom")


# -- path_to ---------------------------------------------------------------

def test_path_to_on_empty_dag_is_empty():
    """Unknown target -> empty path (or raises — we choose raise via
    UnknownNodeError to surface programmer errors)."""
    dag = PrerequisiteDAG()
    dag.add_node("a")
    with pytest.raises(UnknownNodeError):
        dag.path_to("ghost")


def test_path_to_already_unlocked_returns_empty():
    """An already-unlocked target has nothing to walk — empty list."""
    dag = _chain(3)
    dag.unlock("n0")
    dag.advance("n1")
    assert dag.path_to("n1") == []


def test_path_to_against_locked_target_returns_unlocks_sequence():
    """Path from the unlocked frontier to a locked-but-reachable target
    should list the nodes in unlock order."""
    dag = _chain(3)
    dag.unlock("n0")
    path = dag.path_to("n2")
    assert path == ["n1", "n2"]


def test_path_to_through_diamond_returns_one_branch():
    """In a diamond (two parallel prereqs), path_to returns the unlock
    sequence along one branch (a path is linear by definition). The
    OTHER branch is still listed by missing_prerequisites — the caller
    combines both to drive parallel DAG advancement."""
    dag = _diamond()
    dag.unlock("top")
    path = dag.path_to("bottom")
    # Path must end at bottom and contain one of {left, right} (but not
    # both — a linear path can't cover parallel branches).
    assert path[-1] == "bottom"
    assert len(path) == 2  # one branch + bottom
    assert ("left" in path) ^ ("right" in path)  # exactly one branch
    # Both branches are still missing (nothing unlocked yet).
    assert set(dag.missing_prerequisites("bottom")) == {"left", "right"}
    # After walking the path's branch, the OTHER branch is the only one
    # left missing.
    dag.advance(path[0])
    assert dag.missing_prerequisites("bottom") == [
        b for b in ("left", "right") if b != path[0]
    ]


def test_path_to_returns_empty_when_target_unreachable():
    """A node fully disconnected from the unlocked frontier returns empty."""
    dag = _chain(3)
    dag.unlock("n0")
    # Sanity: n2 is reachable from the frontier (path is the 2-step
    # sequence n1 -> n2).
    assert dag.path_to("n2") == ["n1", "n2"]
    # A fully disconnected node has no path.
    dag.add_node("orphan")
    assert dag.path_to("orphan") == []


# -- topological_order ------------------------------------------------------

def test_topological_order_on_chain_respects_dependencies():
    """In a chain, topo order is the chain itself."""
    dag = _chain(4)
    order = dag.topological_order()
    assert order == ["n0", "n1", "n2", "n3"]


def test_topological_order_on_diamond_respects_dependencies():
    """In a diamond, top must come before {left,right} before bottom."""
    dag = _diamond()
    order = dag.topological_order()
    idx = {n: i for i, n in enumerate(order)}
    assert idx["top"] < idx["left"]
    assert idx["top"] < idx["right"]
    assert idx["left"] < idx["bottom"]
    assert idx["right"] < idx["bottom"]


def test_topological_order_contains_every_node():
    dag = _chain(5)
    order = dag.topological_order()
    assert sorted(order) == sorted(dag.nodes())


# -- serialization round-trip ----------------------------------------------

def test_to_dict_then_from_dict_round_trip():
    dag = _chain(3)
    dag.unlock("n0")
    dag.unlock("n1")
    snapshot = dag.to_dict()

    assert snapshot["schema_version"] == 1
    assert snapshot["kind"] == "prerequisite_dag"

    restored = PrerequisiteDAG.from_dict(snapshot)
    assert sorted(restored.nodes()) == sorted(dag.nodes())
    assert restored.unlocked_set() == dag.unlocked_set()
    for nid in dag.nodes():
        assert sorted(restored.prerequisites(nid)) == sorted(dag.prerequisites(nid))
        assert restored.is_unlocked(nid) == dag.is_unlocked(nid)


def test_from_dict_rejects_unknown_schema_version():
    dag = _chain(2)
    snapshot = dag.to_dict()
    snapshot["schema_version"] = 999
    with pytest.raises(ValueError):
        PrerequisiteDAG.from_dict(snapshot)


# -- three_body_cognition_dag factory --------------------------------------

def test_three_body_factory_returns_correct_node_set():
    """The factory must wire up the canonical 11 nodes from spec §8.3."""
    dag = three_body_cognition_dag()
    expected_nodes = {
        "observe", "curve_fit", "periodicity", "falsify_periodic",
        "gravity_law", "three_body_eq", "numerical_integrate",
        "sensitive_dependence", "chaos", "lyapunov_wall", "escape",
    }
    assert set(dag.nodes()) == expected_nodes


def test_three_body_factory_all_nodes_initially_locked():
    """Freshly-built factory DAG has nothing unlocked."""
    dag = three_body_cognition_dag()
    for nid in dag.nodes():
        assert not dag.is_unlocked(nid), f"{nid} should be locked"
    assert dag.unlocked_set() == frozenset()


def test_three_body_factory_escape_prereq_chain_complete():
    """'escape' must trace back to 'observe' through a complete prereq
    chain. This is the spec §8.3 invariant: escaping requires having gone
    through the full cognitive progression."""
    dag = three_body_cognition_dag()

    # escape -> lyapunov_wall (its only direct prereq, per spec diagram).
    assert dag.prerequisites("escape") == ["lyapunov_wall"]

    # Transitively, escape's reachability chain is the full DAG path.
    # Walk backward from escape and confirm every node along the path
    # is a prereq (direct or transitive) of the next.
    seen: set = set()
    stack = ["escape"]
    while stack:
        cur = stack.pop()
        if cur in seen:
            continue
        seen.add(cur)
        for pre in dag.prerequisites(cur):
            assert pre in dag.nodes()
            stack.append(pre)

    # The chain must reach 'observe' (the entry-point node).
    assert "observe" in seen


def test_three_body_factory_cannot_advance_to_escape_directly():
    """The user cannot skip directly to 'escape' without first unlocking
    its prerequisite chain. Spec §8.3: 'user cannot skip nodes'."""
    dag = three_body_cognition_dag()
    with pytest.raises(PrerequisiteError):
        dag.advance("escape")


def test_three_body_factory_walk_full_chain_succeeds():
    """Walking the spec §8.3 chain in order, calling `advance` at each
    step, must complete without error and end with 'escape' unlocked."""
    dag = three_body_cognition_dag()
    walk = [
        "observe", "curve_fit", "periodicity", "falsify_periodic",
        "gravity_law", "three_body_eq", "numerical_integrate",
        "sensitive_dependence", "chaos", "lyapunov_wall", "escape",
    ]
    for i, nid in enumerate(walk):
        # Before walking: previous nodes already unlocked, so can_reach
        # must be true for the next.
        if i > 0:
            assert dag.is_unlocked(walk[i - 1])
        # After earlier unlocks, current must be reachable.
        assert dag.can_reach(nid), f"{nid} should be reachable at step {i}"
        dag.advance(nid)
    assert dag.is_unlocked("escape")


def test_three_body_factory_topological_order_contains_all_nodes():
    """The factory's topological order must cover every node without
    cycles (the cycle-rejection invariant)."""
    dag = three_body_cognition_dag()
    order = dag.topological_order()
    assert len(order) == len(dag.nodes())
    assert set(order) == set(dag.nodes())
    # Every edge prereq must appear before its dependent in the order.
    idx = {n: i for i, n in enumerate(order)}
    for nid in dag.nodes():
        for pre in dag.prerequisites(nid):
            assert idx[pre] < idx[nid], (
                f"{pre} should come before {nid} in topological order"
            )


def test_three_body_factory_round_trip_serialization():
    """Factory-built DAG must round-trip through to_dict/from_dict."""
    dag = three_body_cognition_dag()
    snapshot = dag.to_dict()
    restored = PrerequisiteDAG.from_dict(snapshot)
    assert sorted(restored.nodes()) == sorted(dag.nodes())
    for nid in dag.nodes():
        assert sorted(restored.prerequisites(nid)) == sorted(dag.prerequisites(nid))


# -- generic-machine smoke test --------------------------------------------

def test_dag_is_a_generic_machine_not_three_body_specific():
    """The DAG module must NOT bake three-body semantics in (spec §8.1:
    'must be a universal component, not hard-coded to three-body')."""
    dag = PrerequisiteDAG()
    # Build a fantasy recipe DAG with no three-body concepts.
    dag.add_node("gather_wood", metadata={"recipe": "campfire"})
    dag.add_node("strike_flint", metadata={"recipe": "campfire"})
    dag.add_node("campfire", metadata={"recipe": "campfire"})
    dag.add_node("cook_stew", metadata={"recipe": "stew"})
    dag.add_edge("gather_wood", "campfire")
    dag.add_edge("strike_flint", "campfire")
    dag.add_edge("campfire", "cook_stew")
    dag.unlock("gather_wood")
    dag.unlock("strike_flint")
    dag.advance("campfire")
    assert dag.is_unlocked("campfire")
    assert dag.can_reach("cook_stew")