"""Tests for the schema migration chain (§13.1).

Covers: pathfinding, full-version migration, no-op for current,
skip-ahead via BFS, downgrade export readability, and custom
registration.
"""

from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.migrations import (
    MigrationChain,
    MigrationError,
    get_default_chain,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def chain():
    """The singleton default migration chain (v0→…→v6)."""
    return get_default_chain()


def _make_state(version: int, **extra) -> dict:
    """Build a plausible state dict at the given schema version."""
    base = {"characters": [], "worldbook": []}
    if version == 0:
        return {**base, **extra}
    base["_meta"] = {"schema_version": version}
    if version >= 2:
        base["_meta"]["world_id"] = extra.get("world_id", "test_world")
        base["_meta"].setdefault("created_from", None)
        base["_meta"].setdefault("sandbox", False)
        base["_meta"].setdefault("constraint_mutations", [])
    if version >= 3:
        base["_meta"].setdefault("generator_ids", {"llm": None, "gui_compiler": None})
        base["_meta"].setdefault("world_params", {
            "lambda": None, "initial_conditions_seed": None,
            "enabled_kernels": [], "sealed_solutions": {},
        })
        base["_meta"].setdefault("integrity_flags", {
            "sandbox": False, "constraint_mutations": [],
        })
    return {**base, **{k: v for k, v in extra.items() if k != "world_id"}}


# ---------------------------------------------------------------------------
# v0 state → migrate to v2 → _meta exists
# ---------------------------------------------------------------------------

class TestV0ToV2:
    def test_v0_reaches_v2_with_meta(self, chain):
        state = _make_state(0)
        result = chain.migrate(state, target_version=2)

        meta = result.get("_meta")
        assert meta is not None, "v2 state must have _meta"
        assert meta["schema_version"] == 2
        assert meta["world_id"] == "main"
        assert meta["created_from"] is None
        assert meta["sandbox"] is False
        assert meta["constraint_mutations"] == []
        assert "characters" in result

    def test_v0_preserves_existing_keys(self, chain):
        state = _make_state(0, characters=[{"name": "Aria"}], worldbook=[{"title": "Lore"}])
        result = chain.migrate(state, target_version=2)
        assert len(result["characters"]) == 1
        assert result["characters"][0]["name"] == "Aria"
        assert len(result["worldbook"]) == 1


# ---------------------------------------------------------------------------
# v1 state → migrate to v2 → _meta complete
# ---------------------------------------------------------------------------

class TestV1ToV2:
    def test_v1_gets_full_meta(self, chain):
        state = _make_state(1)
        result = chain.migrate(state, target_version=2)

        meta = result["_meta"]
        assert meta["schema_version"] == 2
        assert meta["world_id"] == "main"  # v1→v2 default
        assert meta["created_from"] is None
        assert meta["sandbox"] is False

    def test_v1_preserves_existing_meta_values(self, chain):
        state = _make_state(1)
        state["_meta"]["world_id"] = "custom"
        result = chain.migrate(state, target_version=2)
        assert result["_meta"]["world_id"] == "custom"


# ---------------------------------------------------------------------------
# Already at target → no-op
# ---------------------------------------------------------------------------

class TestNoop:
    def test_v2_targets_v2_is_noop(self, chain):
        state = _make_state(2, world_id="steady")
        result = chain.migrate(state, target_version=2)
        assert result is state  # same object reference

    def test_v3_targets_v3_is_noop(self, chain):
        state = _make_state(3)
        result = chain.migrate(state, target_version=3)
        assert result is state

    def test_v6_targets_v6_is_noop(self, chain):
        state = _make_state(6)
        result = chain.migrate(state, target_version=6)
        assert result is state

    def test_needs_migration_false_at_target(self, chain):
        state = _make_state(2)
        assert not chain.needs_migration(state, 2)

    def test_needs_migration_true_when_behind(self, chain):
        state = _make_state(0)
        assert chain.needs_migration(state, 2)
        assert chain.needs_migration(state, 1)

    def test_current_version_helpers(self, chain):
        assert chain.current_version(_make_state(0)) == 0
        assert chain.current_version(_make_state(1)) == 1
        assert chain.current_version(_make_state(2)) == 2
        assert chain.current_version(_make_state(3)) == 3
        assert chain.current_version(_make_state(6)) == 6
        assert chain.current_version({}) == 0
        assert chain.current_version({"characters": []}) == 0


# ---------------------------------------------------------------------------
# Skip-ahead: v0 → v2 in two steps
# ---------------------------------------------------------------------------

class TestSkipAhead:
    def test_v0_to_v2_jump(self, chain):
        state = _make_state(0)
        result = chain.migrate(state, target_version=2)
        assert result["_meta"]["schema_version"] == 2

    def test_v0_to_v3_full(self, chain):
        state = _make_state(0, characters=[{"name": "Carmen"}])
        result = chain.migrate(state, target_version=3)
        assert result["_meta"]["schema_version"] == 3
        meta = result["_meta"]
        assert "generator_ids" in meta
        assert "world_params" in meta
        assert "integrity_flags" in meta
        assert result["characters"][0]["name"] == "Carmen"

    def test_v1_to_v3_jump(self, chain):
        state = _make_state(1)
        result = chain.migrate(state, target_version=3)
        assert result["_meta"]["schema_version"] == 3
        assert "integrity_flags" in result["_meta"]

    def test_v0_to_v6_reaches_current_text_world_schema(self, chain):
        state = _make_state(0)
        result = chain.migrate(state, target_version=6)
        assert result["_meta"]["schema_version"] == 6
        assert result["_meta"]["generator_ids"] == {
            "llm": None,
            "gui_compiler": None,
        }


class TestV5ToV6:
    def test_retired_media_and_animation_fields_are_scrubbed(self, chain):
        state = _make_state(5)
        state["characters"] = [{
            "character_id": "c",
            "voice_style": "legacy",
            "portrait_asset_id": "portrait",
            "pending_ai_actions": [{
                "intent": "inspect",
                "target": "archive",
                "bones": [{"name": "arm"}],
                "expression": "alert",
            }],
        }]
        state["objects"] = [{"object_id": "o", "state_assets": {"open": "x"}}]
        state["attachments"] = [{"attachment_id": "a"}]
        state["assets"] = [{"asset_id": "legacy"}]
        state["_meta"]["generator_ids"] = {
            "image": "legacy-image",
            "svs": "legacy-svs",
            "llm": "text-model",
        }

        result = chain.migrate(state, target_version=6)

        assert result["_meta"]["schema_version"] == 6
        assert result["_meta"]["generator_ids"] == {
            "llm": "text-model",
            "gui_compiler": None,
        }
        assert "voice_style" not in result["characters"][0]
        assert "portrait_asset_id" not in result["characters"][0]
        assert result["characters"][0]["pending_ai_actions"] == [{
            "intent": "inspect",
            "target": "archive",
        }]
        assert "state_assets" not in result["objects"][0]
        assert "attachments" not in result
        assert "assets" not in result


# ---------------------------------------------------------------------------
# Degradation: downgrade_export produces readable text
# ---------------------------------------------------------------------------

class TestDowngradeExport:
    def test_export_contains_sections(self, chain):
        state = _make_state(2)
        output = chain.downgrade_export(state)
        assert "WORLD STATE EXPORT" in output
        assert "Schema version" in output
        assert "Characters" in output
        assert "World Book" in output
        assert "END OF EXPORT" in output

    def test_export_lists_characters(self, chain):
        state = _make_state(2)
        state["characters"] = [{"name": "Carmen", "summary": "A fiery gypsy."}]
        output = chain.downgrade_export(state)
        assert "Carmen" in output
        assert "fiery gypsy" in output

    def test_export_lists_worldbook(self, chain):
        state = _make_state(2)
        state["worldbook"] = [{"title": "History", "content": "Once upon a time…"}]
        output = chain.downgrade_export(state)
        assert "History" in output
        assert "Once upon a time" in output

    def test_export_lists_objects(self, chain):
        state = _make_state(2)
        state["objects"] = [{"name": "Sword", "location": "inventory"}]
        output = chain.downgrade_export(state)
        assert "Sword" in output
        assert "inventory" in output

    def test_export_shows_raw_meta(self, chain):
        state = _make_state(2, world_id="wonderland")
        output = chain.downgrade_export(state)
        assert "wonderland" in output
        assert "Raw Metadata" in output

    def test_export_empty_sections_graceful(self, chain):
        state = _make_state(2)
        output = chain.downgrade_export(state)
        assert "(none)" in output  # no characters


# ---------------------------------------------------------------------------
# Custom migration registration
# ---------------------------------------------------------------------------

class TestCustomRegistration:
    def test_register_and_apply(self):
        chain = MigrationChain()

        chain.register(0, 1, lambda s: {**s, "custom": True}, "Custom step")
        state = {}
        result = chain.migrate(state, target_version=1)
        assert result["custom"] is True
        assert result["_meta"]["schema_version"] == 1

    def test_register_duplicate_raises(self):
        chain = MigrationChain()
        chain.register(0, 1, lambda s: s, "first")
        with pytest.raises(ValueError, match="already registered"):
            chain.register(0, 1, lambda s: s, "duplicate")

    def test_no_path_raises(self):
        chain = MigrationChain()
        chain.register(0, 1, lambda s: s, "only step")
        state = {}
        # no path from 1→2
        with pytest.raises(MigrationError, match="No migration path"):
            chain.migrate(state, target_version=2)


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_v0_to_same_v0_is_noop(self, chain):
        state = _make_state(0)
        result = chain.migrate(state, target_version=0)
        assert result is state

    def test_target_lower_than_current_raises(self, chain):
        state = _make_state(2)
        with pytest.raises(MigrationError):
            chain.migrate(state, target_version=0)

    def test_migration_error_raised_on_fn_failure(self):
        chain = MigrationChain()

        def broken(state):
            raise RuntimeError("boom")

        chain.register(0, 1, broken, "broken step")
        with pytest.raises(MigrationError, match="v0→v1 failed"):
            chain.migrate({}, target_version=1)

    def test_custom_chain_does_not_interfere_with_default(self):
        """Ensure separate MigrationChain instances are isolated."""
        c1 = get_default_chain()
        c2 = MigrationChain()
        c2.register(0, 5, lambda s: {**s, "_meta": {"schema_version": 5}}, "custom big jump")
        r1 = c1.migrate(_make_state(0), target_version=2)
        r2 = c2.migrate(_make_state(0), target_version=5)
        assert r1["_meta"]["schema_version"] == 2
        assert r2["_meta"]["schema_version"] == 5

    def test_migration_updates_schema_version_correctly(self, chain):
        state = _make_state(0)
        # Step through each version and check intermediate
        r1 = chain.migrate(state, target_version=1)
        assert r1["_meta"]["schema_version"] == 1
        r2 = chain.migrate(r1, target_version=2)
        assert r2["_meta"]["schema_version"] == 2
        r3 = chain.migrate(r2, target_version=3)
        assert r3["_meta"]["schema_version"] == 3
        r4 = chain.migrate(r3, target_version=4)
        assert r4["_meta"]["schema_version"] == 4
        r5 = chain.migrate(r4, target_version=5)
        assert r5["_meta"]["schema_version"] == 5
        r6 = chain.migrate(r5, target_version=6)
        assert r6["_meta"]["schema_version"] == 6
