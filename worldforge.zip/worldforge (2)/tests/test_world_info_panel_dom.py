"""Front-end rendering test for the #world-info-panel (spec §13.6).

Runs ``web/world_gui.js`` under Node with a minimal mock DOM, then drives
``WorldGUI.renderInfoPanel()`` / ``WorldGUI.pushTickModelTrace()`` with mock
model_trace + generic world state and asserts the rendered DOM contains the
expected kernel state, belief, commitment, causal, event-log, and outcome
text. Skips when ``node`` is not on PATH (the JS is also covered indirectly
by the Python projection tests in test_gui_info_panel.py).

Run with::

    PYTHONPATH=backend python -m pytest tests/test_world_info_panel_dom.py -q
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"
JS = WEB / "world_gui.js"


_NODE_SCRIPT = r"""
// Minimal mock DOM + fetch for world_gui.js under Node.
global.window = global;
global.document = (function () {
  function make(id) {
    return {
      id: id, className: "", textContent: "", innerHTML: "",
      children: [], childNodes: [], firstChild: null, style: {},
      dataset: {}, classList: { _s:new Set(),
        add:function(c){this._s.add(c);},
        remove:function(c){this._s.delete(c);},
        toggle:function(c,on){var f=on===undefined?!this._s.has(c):on;
          if(f)this._s.add(c);else this._s.delete(c);return f;},
        contains:function(c){return this._s.has(c);} },
      getAttribute:function(){return null;}, setAttribute:function(){},
      appendChild:function(n){this.children.push(n);this.firstChild=this.children[0];return n;},
      removeChild:function(n){var i=this.children.indexOf(n);if(i>=0)this.children.splice(i,1);
        this.firstChild=this.children[0]||null;return n;},
      addEventListener:function(){},
      querySelector:function(){return null;}, querySelectorAll:function(){return [];},
    };
  }
  var nodes = {};
  return {
    readyState: "complete",
    _nodes: nodes,
    getElementById: function (id) {
      if (!nodes[id]) { var n = make(id); n.id = id; nodes[id] = n; }
      return nodes[id];
    },
    addEventListener: function () {},
    createElement: function (tag) { return make(tag); },
    createTextNode: function (t) { return make("#text"); },
  };
})();
global.performance = { now: function () { return Date.now(); } };
global.crypto = { randomUUID: function () { return "x"; } };
global.fetch = function () { return Promise.resolve({ ok: false, json: function () { return Promise.resolve(null); } }); };
global.URLSearchParams = function () { return { get: function () { return null; } }; };

require(process.argv[1]);
var api = global.WorldGUI;

// Resolve the info-panel DOM handles + render once (no polling).
api._resolveInfoDom();

var mt = %MT%;
var worldState = %STATE%;
api.setLastWorldState(worldState);
api.setLastModelTrace(mt);
api.renderInfoPanel();

var d = document._nodes;
var out = {
  beat: d["info-beat"].textContent,
  world: d["info-world"].textContent,
  schema: d["info-schema"].textContent,
  characters: d["info-characters"].textContent,
  worldbook: d["info-worldbook"].textContent,
  rules: d["info-rules"].textContent,
  beliefs_html: d["info-beliefs"].innerHTML,
  commitments_html: d["info-commitments"].innerHTML,
  causal_text: d["info-causal"].textContent,
  events_html: d["info-events"].innerHTML,
  outcome_text: d["info-outcome"].textContent,
};
process.stdout.write(JSON.stringify(out));
"""


def _node_available() -> bool:
    return shutil.which("node") is not None


@pytest.mark.skipif(not _node_available(), reason="node not on PATH")
def test_render_info_panel_with_mock_data():
    mt = {
        "world_builder_beat": 7,
        "kernel_event_log": ["policy enacted", "market shifted"],
        "kernel_verdict": "stable_transition",
        "agent_mind": {
            "agents": {
                "sci_1": {
                    "belief": 0.42,
                    "belief_trace": {
                        "topic": "era",
                        "prior": {"predicted": 0.3, "confidence": 0.4},
                        "posterior": {"predicted": 0.42, "confidence": 0.55},
                        "strategy": "dogmatic",
                        "contradiction": 0.12,
                        "accepted": True,
                        "rejected_info": None,
                        "error_source": None,
                    },
                },
            },
            "causal_narrative": {
                "narrative": "sci_1 doubled down",
                "causal_graph": {"nodes": [{"id": "a"}], "edges": []},
                "validation_ok": True,
                "validation_errors": [],
                "fallback_used": False,
            },
        },
        "commitments": {
            "resolutions": [{
                "status": "committed",
                "commitment": {
                    "commitment_id": "c1", "actor_id": "sci_1",
                    "goal": "build observatory", "status": "active",
                    "progress": 0.3, "decision_type": "launch_project",
                    "required_resources": {"budget": 5},
                    "allocated_resources": {"budget": 3},
                },
            }],
        },
        "world_updates": [{
            "source": "simulation_outcome_chapter",
            "title": "Beat 7 outcome",
            "content": "The transition completed without contradiction.",
        }],
    }
    state = {
        "world_id": "test_world",
        "_meta": {"world_id": "test_world", "schema_version": 6},
        "characters": [{"character_id": "sci_1"}, {"character_id": "sci_2"}],
        "worldbook": [{"title": "Founding"}],
        "rules": [{"rule_id": "budget_floor"}, {"rule_id": "audit_cycle"}],
        "event_log": ["persisted event"],
    }
    script = _NODE_SCRIPT.replace("%MT%", json.dumps(mt)).replace(
        "%STATE%", json.dumps(state)
    )
    proc = subprocess.run(
        ["node", "-e", script, str(JS)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, (
        f"node failed:\nstdout={proc.stdout}\nstderr={proc.stderr}")
    out = json.loads(proc.stdout)

    # kernel_state cards
    assert out["beat"] == "7"
    assert out["world"] == "test_world"
    assert out["schema"] == "6"
    assert out["characters"] == "2"
    assert out["worldbook"] == "1"
    assert out["rules"] == "2"

    # beliefs: predicted + strategy + accepted surface
    assert "sci_1" in out["beliefs_html"]
    assert "0.42" in out["beliefs_html"]
    assert "dogmatic" in out["beliefs_html"]
    assert "accepted" in out["beliefs_html"]

    # commitments: goal + progress %
    assert "build observatory" in out["commitments_html"]
    assert "30%" in out["commitments_html"]
    assert "active" in out["commitments_html"]

    # causal narrative text
    assert "sci_1 doubled down" in out["causal_text"]

    # event log: latest kernel trace plus generic persisted events
    assert "policy enacted" in out["events_html"]
    assert "persisted event" in out["events_html"]

    # outcome chapter: kind prefix + literary text
    assert "stable_transition" in out["outcome_text"]
    assert "The transition completed without contradiction." in out["outcome_text"]


@pytest.mark.skipif(not _node_available(), reason="node not on PATH")
def test_render_info_panel_empty_state():
    api = None
    script = _NODE_SCRIPT.replace("%MT%", "null").replace("%STATE%", "null")
    proc = subprocess.run(
        ["node", "-e", script, str(JS)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, f"node failed: {proc.stderr}"
    out = json.loads(proc.stdout)
    # Empty → cards show — , lists show the empty placeholder, no crash.
    assert out["beat"] == "—"
    assert "暂无" in out["beliefs_html"]
    assert "暂无" in out["commitments_html"]
    assert "暂无" in out["causal_text"] or "尚存" in out["causal_text"]


@pytest.mark.skipif(not _node_available(), reason="node not on PATH")
def test_push_tick_model_trace_updates_panel():
    """pushTickModelTrace(beat) folds beat.model_trace into the panel."""
    script = r"""
global.window = global;
global.document = (function () {
  function make(id){return{id:id,className:"",textContent:"",innerHTML:"",children:[],firstChild:null,style:{},dataset:{},classList:{_s:new Set(),add:function(c){this._s.add(c);},remove:function(c){this._s.delete(c);},toggle:function(c,on){var f=on===undefined?!this._s.has(c):on;if(f)this._s.add(c);else this._s.delete(c);return f;},contains:function(c){return this._s.has(c);}},getAttribute:function(){return null;},setAttribute:function(){},appendChild:function(n){this.children.push(n);this.firstChild=this.children[0];return n;},removeChild:function(n){var i=this.children.indexOf(n);if(i>=0)this.children.splice(i,1);this.firstChild=this.children[0]||null;return n;},addEventListener:function(){},querySelector:function(){return null;},querySelectorAll:function(){return [];}};}
  var nodes={};
  return{readyState:"complete",_nodes:nodes,getElementById:function(id){if(!nodes[id]){var n=make(id);n.id=id;nodes[id]=n;}return nodes[id];},addEventListener:function(){},createElement:function(t){return make(t);},createTextNode:function(t){return make("#text");}};
})();
global.performance={now:function(){return Date.now();}};
global.crypto={randomUUID:function(){return "x";}};
global.fetch=function(){return Promise.resolve({ok:false,json:function(){return Promise.resolve(null);}});};
global.URLSearchParams=function(){return{get:function(){return null;}};};
require(process.argv[1]);
var api=global.WorldGUI;
api._resolveInfoDom();
api.pushTickModelTrace({model_trace:{world_builder_beat:5,kernel_event_log:["tick5 event"]}});
var d=document._nodes;
process.stdout.write(JSON.stringify({beat:d["info-beat"].textContent,events:d["info-events"].innerHTML}));
"""
    proc = subprocess.run(
        ["node", "-e", script, str(JS)],
        capture_output=True, text=True, timeout=30,
    )
    assert proc.returncode == 0, f"node failed: {proc.stderr}"
    out = json.loads(proc.stdout)
    assert out["beat"] == "5"
    assert "tick5 event" in out["events"]
