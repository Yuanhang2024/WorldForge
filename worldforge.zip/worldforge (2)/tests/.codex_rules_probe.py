import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "backend"))

os.environ["AI_THEATER_BASE_URL"] = "http://127.0.0.1:1234/v1"
os.environ["AI_THEATER_API_KEY"] = ""
os.environ["AI_THEATER_MODEL_FAST"] = "deepseek-v4-flash"
os.environ["AI_THEATER_MODEL_DEEP"] = "deepseek-v4-flash"

from theater.onboarding import OnboardingFlow


flow = OnboardingFlow(state_root=Path("data/runtime/state"))
result = flow.propose_rules_gui("AuroralHarmony", "")
print(json.dumps(result, ensure_ascii=False), flush=True)
