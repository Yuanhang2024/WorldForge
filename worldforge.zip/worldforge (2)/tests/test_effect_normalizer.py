"""Tests for effect-format normalisation in ``RuleGenerator``.

The LLM occasionally emits effect shapes that don't match what the
deterministic ``RuleCompiler`` accepts natively.  This file exercises the
auto-fix surface added to ``_normalize_ast`` and ``_repair_spec`` so the
generated spec is byte-correct.

Variants covered:
  - ``{"op":"const","value":V}``           → ``{"const": V}`` shorthand
  - ``{"op":"lookup","path":"x"}``         → ``{"op":"lookup","args":["x"]}``
  - ``{"op":"var","name":"x"}``            → ``{"op":"lookup","args":["x"]}``
  - ``{"op":"writes","changes":[{...}]}``  → flat ``{"writes": ..., ...}``
  - ``{"writes":"x","value":V}``           → missing ``op`` filled in
  - ``{"writes":"x","op":"add","value":V}`` already canonical
  - invariant ``{"predicate": <ast>}``     preserved
  - Recursion into nested ``args``/``value``
  - LLM raw output (all variants in one spec) → repaired → validate+compile

Run with::

    PYTHONPATH=backend python -m pytest tests/test_effect_normalizer.py -q
"""

from __future__ import annotations

import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.rule_generator import RuleGenerator
from theater.world_kernel_host import (
    RuleCompiler,
    WorldKernelHost,
    WorldKernelSpec,
    WorldRule,
)


# =====================================================================
# const / leaf unwrap
# =====================================================================


class TestConstUnwrap:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_const_wrapper_unwrapped_to_shorthand(self) -> None:
        node = {"op": "const", "value": 10}
        self.gen._normalize_ast(node)
        # Should now be {"const": 10} shorthand
        assert node == {"const": 10}

    def test_const_wrapper_with_string(self) -> None:
        node = {"op": "const", "value": "hello"}
        self.gen._normalize_ast(node)
        assert node == {"const": "hello"}

    def test_const_wrapper_with_list(self) -> None:
        node = {"op": "const", "value": [1, 2, 3]}
        self.gen._normalize_ast(node)
        assert node == {"const": [1, 2, 3]}

    def test_const_wrapper_with_extra_keys_left_alone(self) -> None:
        # Only the pure 2-key wrapper ``{op, value}`` is unwrapped.
        node = {"op": "const", "value": 10, "extra": "ignore"}
        self.gen._normalize_ast(node)
        # Not unwrapped because of the extra key — leaves the original form.
        assert node["op"] == "const"
        assert node["value"] == 10


# =====================================================================
# lookup path → args
# =====================================================================


class TestLookupPathToArgs:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_lookup_path_becomes_args(self) -> None:
        node = {"op": "lookup", "path": "x"}
        self.gen._normalize_ast(node)
        assert node == {"op": "lookup", "args": ["x"]}

    def test_lookup_path_with_dotted_path(self) -> None:
        node = {"op": "lookup", "path": "foo.bar.baz"}
        self.gen._normalize_ast(node)
        assert node == {"op": "lookup", "args": ["foo.bar.baz"]}

    def test_lookup_with_existing_args_left_alone(self) -> None:
        # If both path and args are present, args wins (no clobber).
        node = {"op": "lookup", "path": "x", "args": ["y"]}
        self.gen._normalize_ast(node)
        assert node["args"] == ["y"]


# =====================================================================
# var → lookup
# =====================================================================


class TestVarToLookup:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_var_name_becomes_lookup(self) -> None:
        node = {"op": "var", "name": "x"}
        self.gen._normalize_ast(node)
        assert node == {"op": "lookup", "args": ["x"]}

    def test_var_with_dotted_name(self) -> None:
        node = {"op": "var", "name": "player.score"}
        self.gen._normalize_ast(node)
        assert node == {"op": "lookup", "args": ["player.score"]}


# =====================================================================
# writes + changes → flat writes
# =====================================================================


class TestWritesFlattening:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_single_change_writes_to_flat(self) -> None:
        node = {
            "op": "writes",
            "changes": [{"path": "x", "value": {"const": 1}}],
        }
        self.gen._normalize_ast(node)
        assert node == {
            "writes": "x",
            "value": {"const": 1},
            "op": "set",
        }

    def test_single_change_writes_preserves_write_op(self) -> None:
        node = {
            "op": "writes",
            "changes": [{"path": "x", "value": {"const": 1}, "op": "add"}],
        }
        self.gen._normalize_ast(node)
        assert node["op"] == "add"
        assert node["writes"] == "x"

    def test_multi_change_writes_left_intact(self) -> None:
        # Multi-change writes can't be represented as a single flat writes
        # node — they keep the nested shape.
        node = {
            "op": "writes",
            "changes": [
                {"path": "x", "value": {"const": 1}},
                {"path": "y", "value": {"const": 2}},
            ],
        }
        self.gen._normalize_ast(node)
        # Still nested.
        assert node.get("op") == "writes"
        assert isinstance(node.get("changes"), list)
        assert len(node["changes"]) == 2

    def test_change_without_path_left_alone(self) -> None:
        # A change without ``path`` is malformed; we don't transform it.
        node = {
            "op": "writes",
            "changes": [{"value": {"const": 1}}],
        }
        self.gen._normalize_ast(node)
        # Not flattened — stays in writes+changes form (will fail validation
        # downstream, which is correct).
        assert node.get("op") == "writes"
        assert "changes" in node


# =====================================================================
# Nested recursion
# =====================================================================


class TestNestedNormalization:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_const_inside_add_args_rewritten(self) -> None:
        node = {
            "op": "add",
            "args": [
                {"ref": "x"},
                {"op": "const", "value": 5},
            ],
        }
        self.gen._normalize_ast(node)
        assert node["args"][0] == {"ref": "x"}
        assert node["args"][1] == {"const": 5}

    def test_lookup_path_inside_nested_args(self) -> None:
        node = {
            "op": "if",
            "args": [
                {"op": "lookup", "path": "flag"},
                {"op": "lookup", "path": "yes"},
                {"op": "lookup", "path": "no"},
            ],
        }
        self.gen._normalize_ast(node)
        for i, expected in enumerate(("flag", "yes", "no")):
            assert node["args"][i]["args"] == [expected]

    def test_var_inside_writes_change_value(self) -> None:
        node = {
            "op": "writes",
            "changes": [{
                "path": "x",
                "value": {
                    "op": "add",
                    "args": [
                        {"op": "var", "name": "y"},
                        {"const": 1},
                    ],
                },
            }],
        }
        self.gen._normalize_ast(node)
        # Single-change → flat. Inside, var → lookup args.
        assert node["writes"] == "x"
        assert node["value"]["args"][0] == {"op": "lookup", "args": ["y"]}
        assert node["value"]["args"][1] == {"const": 1}


# =====================================================================
# _repair_spec: effect shape normalisation
# =====================================================================


class TestRepairEffectShape:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_legacy_single_change_normalised_to_flat(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[WorldRule(
                rule_id="r1",
                kind="dynamic",
                trigger="tick",
                effect={
                    "op": "writes",
                    "changes": [{"path": "x", "value": {"const": 1}}],
                },
            )],
        )
        self.gen._repair_spec(spec)
        eff = spec.rules[0].effect
        assert eff["writes"] == "x"
        assert eff["op"] == "set"
        assert eff["value"] == {"const": 1}

    def test_legacy_multi_change_keeps_nested_shape(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[WorldRule(
                rule_id="r1",
                kind="dynamic",
                trigger="tick",
                effect={
                    "op": "writes",
                    "changes": [
                        {"path": "x", "value": {"const": 1}},
                        {"path": "y", "value": {"const": 2}},
                    ],
                },
            )],
        )
        self.gen._repair_spec(spec)
        eff = spec.rules[0].effect
        # Multi-change keeps the nested shape.
        assert eff["op"] == "writes"
        assert len(eff["changes"]) == 2

    def test_flat_writes_missing_op_filled_with_set(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[WorldRule(
                rule_id="r1",
                kind="dynamic",
                trigger="tick",
                effect={"writes": "x", "value": {"const": 1}},  # no op
            )],
        )
        self.gen._repair_spec(spec)
        eff = spec.rules[0].effect
        assert eff["writes"] == "x"
        assert eff["op"] == "set"

    def test_flat_writes_with_canonical_add_kept(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[WorldRule(
                rule_id="r1",
                kind="dynamic",
                trigger="tick",
                effect={"writes": "x", "op": "add", "value": {"const": 1}},
            )],
        )
        self.gen._repair_spec(spec)
        eff = spec.rules[0].effect
        assert eff["writes"] == "x"
        assert eff["op"] == "add"
        assert eff["value"] == {"const": 1}

    def test_invariant_predicate_flat_preserved(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[WorldRule(
                rule_id="inv1",
                kind="invariant",
                trigger=None,
                effect={"predicate": {"op": "ge",
                                       "args": [{"ref": "price"},
                                                {"const": 0}]}},
            )],
        )
        self.gen._repair_spec(spec)
        eff = spec.rules[0].effect
        assert "predicate" in eff
        assert eff["predicate"]["op"] == "ge"


# =====================================================================
# End-to-end: LLM raw output → repaired → validates → compiles
# =====================================================================


def _llm_plague_raw() -> str:
    """A representative LLM output containing every variant at once.

    Mirrors the kind of slop the LLM emits when asked to author rules for a
    medieval-plague world (think: qwen3-coder output).  Every effect shape
    variant is represented somewhere.
    """
    return json.dumps({
        "world_type": "medieval_plague_city",
        "rules": [
            # 1. writes + changes → flat (single change)
            {
                "rule_id": "infection_spreads",
                "kind": "dynamic",
                "trigger": "turn.tick",
                "condition": {"op": "gt", "args": [
                    {"op": "lookup", "path": "population"},
                    {"const": 0},
                ]},
                "effect": {
                    "op": "writes",
                    "changes": [{
                        "path": "infected",
                        "value": {"op": "add", "args": [
                            {"op": "var", "name": "infected"},
                            {"op": "mul", "args": [
                                {"op": "lookup", "path": "population"},
                                {"op": "const", "value": 0.1},
                            ]},
                        ]},
                    }],
                },
                "priority": 30,
            },
            # 2. already-flat writes, missing op → fill set
            {
                "rule_id": "death_count",
                "kind": "dynamic",
                "trigger": "turn.tick",
                "effect": {
                    "writes": "deaths",
                    "value": {"op": "add", "args": [
                        {"op": "lookup", "path": "deaths"},
                        {"op": "const", "value": 0.05},
                    ]},
                },
                "priority": 20,
            },
            # 3. already-canonical flat writes with add
            {
                "rule_id": "population_decline",
                "kind": "dynamic",
                "trigger": "turn.tick",
                "effect": {
                    "writes": "population",
                    "op": "add",
                    "value": {"op": "mul", "args": [
                        {"op": "lookup", "path": "population"},
                        {"op": "const", "value": -0.05},
                    ]},
                },
                "priority": 10,
            },
            # 4. invariant with flat predicate shape (LLM-friendly)
            {
                "rule_id": "population_non_negative",
                "kind": "invariant",
                "trigger": None,
                "effect": {"predicate": {"op": "ge",
                                          "args": [{"op": "lookup",
                                                    "path": "population"},
                                                   {"const": 0}]}},
                "priority": 100,
            },
            # 5. invariant with legacy predicate shape (also valid)
            {
                "rule_id": "infected_non_negative",
                "kind": "invariant",
                "trigger": None,
                "effect": {"op": "predicate",
                           "expr": {"op": "ge",
                                    "args": [{"ref": "infected"},
                                             {"const": 0}]}},
                "priority": 100,
            },
        ],
        "params": {"seed": 7},
    })


class TestEndToEndLLMOutput:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def _run(self) -> WorldKernelSpec:
        calls = {"n": 0}

        def _llm(prompt: str) -> str:
            calls["n"] += 1
            return _llm_plague_raw()

        spec = self.gen.generate(
            "medieval plague city", llm_fn=_llm,
        )
        assert calls["n"] == 1
        return spec

    def test_spec_accepted_not_fallback(self) -> None:
        spec = self._run()
        assert spec.world_type == "medieval_plague_city"

    def test_all_effects_validated(self) -> None:
        spec = self._run()
        issues = RuleCompiler().validate_spec(spec)
        assert issues == [], f"unexpected issues: {issues}"

    def test_compiles_without_exception(self) -> None:
        spec = self._run()
        kernel = RuleCompiler(seed=0).compile(spec)
        assert kernel.world_type == "medieval_plague_city"

    def test_runs_in_world_kernel_host(self) -> None:
        spec = self._run()
        host = WorldKernelHost(
            spec,
            {"population": 1000, "infected": 5, "deaths": 0},
            seed=42,
        )
        # Fire one tick — should produce writes for infected, deaths, population.
        changes = host.step({"trigger": "turn.tick"})
        write_paths = {c["path"] for c in changes}
        assert "infected" in write_paths
        assert "deaths" in write_paths
        assert "population" in write_paths

    def test_invariants_pass(self) -> None:
        spec = self._run()
        host = WorldKernelHost(
            spec,
            {"population": 1000, "infected": 5, "deaths": 0},
            seed=42,
        )
        # Invariants: population >= 0, infected >= 0 — both satisfied at start.
        failing = host.check_invariants()
        assert failing == [], f"invariant violations: {failing}"

    def test_determinism_two_runs_same_result(self) -> None:
        spec_a = self._run()
        spec_b = self._run()
        # Same raw → same spec.
        assert spec_a.world_type == spec_b.world_type
        assert {r.rule_id for r in spec_a.rules} == {r.rule_id for r in spec_b.rules}
