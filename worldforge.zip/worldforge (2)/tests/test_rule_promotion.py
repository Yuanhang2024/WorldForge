"""Tests for backend.theater.rule_promotion (recurring-adjudication promotion).

Covers:
  - AdjudicationTracker counters: record / is_recurring / recurrent_paths / reset.
  - RulePromoter.promote_for_path: installs an LLM-generated rule.
  - RulePromoter.promote_for_path: rejects on conflict (duplicate rule_id).
  - RulePromoter.check_and_promote: scans tracker, returns one promotion.
  - Post-promotion: tracker.reset clears the recurrence counter.
  - Manual promote_for_path on a non-recurring path still works.
  - Missing/failed LLM generation never installs or resets anything.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_rule_promotion.py -q
"""

from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.rule_promotion import (
    AdjudicationTracker,
    RulePromoter,
)
from theater.world_kernel_host import (
    RuleCompiler,
    WorldKernelHost,
    WorldKernelSpec,
    WorldRule,
)


# =====================================================================
# Helpers
# =====================================================================


def _empty_host() -> WorldKernelHost:
    """A minimal host with no rules — safest for promotion tests."""
    spec = WorldKernelSpec(world_type="test", rules=[])
    return WorldKernelHost(spec, {}, seed=0)


def _seeded_host() -> WorldKernelHost:
    """A host pre-populated with one rule, used to test conflict detection."""
    existing = WorldRule(
        rule_id="existing_pin",
        kind="dynamic",
        trigger="turn.tick",
        effect={
            "op": "writes",
            "changes": [{
                "path": "world.flag",
                "value": {"const": 1},
            }],
        },
        priority=10,
    )
    spec = WorldKernelSpec(world_type="test", rules=[existing])
    return WorldKernelHost(spec, {}, seed=0)


def _all_rule_ids(host: WorldKernelHost) -> set:
    """Return the union of original kernel rules + runtime-added extras."""
    ids = {r.rule_id for r in host.kernel().rules}
    for extra in getattr(host, "_compiled_extra", []) or []:
        ids.add(extra.rule_id)
    return ids


class _TargetingGenerator:
    """Small model-boundary stub returning one rule for the requested path."""

    def generate(self, world_description, llm_fn=None):
        marker = "path "
        raw_path = world_description.rsplit(marker, 1)[-1]
        path = raw_path.strip().strip("'").strip('"')
        return WorldKernelSpec(
            world_type="test",
            rules=[
                WorldRule(
                    rule_id="llm_" + path.replace(".", "_"),
                    kind="dynamic",
                    trigger="turn.tick",
                    effect={
                        "op": "writes",
                        "changes": [{"path": path, "value": {"const": 0}}],
                    },
                    description=f"LLM-generated rule for {path}",
                )
            ],
        )


def _promoter(host, tracker, *, threshold=3):
    return RulePromoter(
        host,
        tracker,
        generator=_TargetingGenerator(),
        llm_fn=lambda _prompt: "{}",
        threshold=threshold,
    )


# =====================================================================
# AdjudicationTracker
# =====================================================================


class TestAdjudicationTracker:
    def test_record_increments_counter(self) -> None:
        t = AdjudicationTracker()
        t.record("narrative.continuity")
        t.record("narrative.continuity")
        assert t.count("narrative.continuity") == 2

    def test_count_default_zero(self) -> None:
        t = AdjudicationTracker()
        assert t.count("never.seen") == 0

    def test_is_recurring_threshold(self) -> None:
        t = AdjudicationTracker(default_threshold=3)
        t.record("p1")
        t.record("p1")
        assert not t.is_recurring("p1")
        t.record("p1")
        assert t.is_recurring("p1")

    def test_is_recurring_per_call_threshold(self) -> None:
        t = AdjudicationTracker(default_threshold=10)
        t.record("p1")
        t.record("p1")
        # Default threshold 10 not crossed, but explicit 2 IS.
        assert not t.is_recurring("p1")
        assert t.is_recurring("p1", threshold=2)

    def test_recurrent_paths(self) -> None:
        t = AdjudicationTracker(default_threshold=3)
        t.record("a")
        t.record("a")
        t.record("b")
        t.record("b")
        t.record("b")
        t.record("c")
        t.record("c")
        t.record("c")
        assert t.recurrent_paths() == ["b", "c"]  # insertion order

    def test_reset_clears_one_path(self) -> None:
        t = AdjudicationTracker(default_threshold=3)
        t.record("a")
        t.record("a")
        t.record("a")
        t.record("b")
        t.record("b")
        t.record("b")
        assert t.recurrent_paths() == ["a", "b"]
        t.reset("a")
        assert t.recurrent_paths() == ["b"]
        assert t.count("a") == 0

    def test_reset_unknown_path_is_noop(self) -> None:
        t = AdjudicationTracker()
        t.reset("never.recorded")  # must not raise
        assert t.count("never.recorded") == 0

    def test_record_ignores_empty_and_non_string(self) -> None:
        t = AdjudicationTracker()
        t.record("")             # ignored
        t.record("   ")          # empty stripped — recorded once
        t.record(None)           # type: ignore[arg-type]
        t.record(123)            # type: ignore[arg-type]
        # None and int must NOT be counted.
        assert t.count("") == 0
        # "   " is a non-empty string, so it DOES get counted once.
        assert t.count("   ") == 1

    def test_reset_all(self) -> None:
        t = AdjudicationTracker()
        t.record("a")
        t.record("b")
        t.reset_all()
        assert t.snapshot() == {}

    def test_snapshot_independent_of_internal_state(self) -> None:
        t = AdjudicationTracker()
        t.record("a")
        snap = t.snapshot()
        snap["a"] = 999
        # Mutating the snapshot must not affect the tracker.
        assert t.count("a") == 1


# =====================================================================
# RulePromoter.promote_for_path
# =====================================================================


class TestRulePromoterPromote:
    def test_promote_installs_rule(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        rule = promoter.promote_for_path("world.flag")
        assert rule is not None
        # Rule was actually appended to the host's runtime extras.
        ids = _all_rule_ids(host)
        assert rule.rule_id in ids

    def test_promote_resets_tracker(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        tracker.record("world.flag")
        tracker.record("world.flag")
        tracker.record("world.flag")
        assert tracker.recurrent_paths() == ["world.flag"]
        promoter.promote_for_path("world.flag")
        # After promotion, the recurrence counter is cleared.
        assert tracker.recurrent_paths() == []

    def test_promote_does_not_overwrite_existing(self) -> None:
        host = _seeded_host()  # has rule_id="existing_pin"
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        rule = promoter.promote_for_path("world.flag")
        assert rule is not None
        # Now the host must contain both the original AND the new rule.
        ids = _all_rule_ids(host)
        assert "existing_pin" in ids
        assert rule.rule_id in ids

    def test_promote_rejects_conflicting_rule(self) -> None:
        """A rule that would duplicate an existing rule_id must be rejected."""
        host = _empty_host()
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        # First promotion: succeeds, uses base id "promote_<path>_promoted".
        first = promoter.promote_for_path("world.flag")
        assert first is not None
        # Inject a SECOND rule directly with the same rule_id — the host
        # must reject it.
        dup = WorldRule(
            rule_id=first.rule_id,           # same id!
            kind="dynamic",
            trigger="turn.tick",
            effect={
                "op": "writes",
                "changes": [{
                    "path": "world.flag",
                    "value": {"const": 99},
                }],
            },
        )
        issues = host.add_rule(dup)
        assert any("duplicate" in m for m in issues)

    def test_promote_invalid_rule_rejected(self) -> None:
        """A validation failure is explicit and installs nothing."""
        host = _empty_host()
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        # Construct a clearly invalid rule (bad op) and push it through
        # promote_for_path by monkey-patching _mint_rule.
        bad = WorldRule(
            rule_id="bad_thing",
            kind="dynamic",
            trigger="turn.tick",
            condition={"op": "eval", "args": [{"const": 1}]},  # illegal op
            effect={
                "op": "writes",
                "changes": [{
                    "path": "world.flag",
                    "value": {"const": 0},
                }],
            },
        )
        promoter._mint_rule = lambda path: bad  # type: ignore[assignment]
        with pytest.raises(ValueError, match="failed validation"):
            promoter.promote_for_path("world.flag")
        # Tracker must NOT be reset on rejection (only on success).
        assert tracker.count("world.flag") == 0

    def test_promote_without_llm_fails_and_installs_nothing(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker()
        tracker.record("world.flag")
        promoter = RulePromoter(host, tracker)

        with pytest.raises(RuntimeError, match="requires llm_fn"):
            promoter.promote_for_path("world.flag")

        assert _all_rule_ids(host) == set()
        assert tracker.count("world.flag") == 1

    def test_promote_empty_path_returns_none(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        assert promoter.promote_for_path("") is None

    def test_promote_generates_unique_rule_id_on_repeat(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        # Two promotions on different paths => different rule_ids.
        r1 = promoter.promote_for_path("a.b")
        r2 = promoter.promote_for_path("c.d")
        assert r1 is not None and r2 is not None
        assert r1.rule_id != r2.rule_id

    def test_promote_is_deterministic(self) -> None:
        # Same path, fresh hosts → identical rule_id.
        host_a = _empty_host()
        host_b = _empty_host()
        prom_a = _promoter(host_a, AdjudicationTracker())
        prom_b = _promoter(host_b, AdjudicationTracker())
        ra = prom_a.promote_for_path("x.y")
        rb = prom_b.promote_for_path("x.y")
        assert ra is not None and rb is not None
        assert ra.rule_id == rb.rule_id
        assert ra.description == rb.description


# =====================================================================
# RulePromoter.check_and_promote
# =====================================================================


class TestRulePromoterCheckAndPromote:
    def test_no_recurrence_returns_none(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker(default_threshold=3)
        promoter = _promoter(host, tracker)
        assert promoter.check_and_promote() is None
        # Host must still be empty.
        assert host.kernel().rules == []

    def test_recurrence_triggers_one_promotion(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker(default_threshold=3)
        promoter = _promoter(host, tracker)
        # Build up recurrence on one path.
        for _ in range(3):
            tracker.record("narrative.continuity")
        # Add a second path that ALSO recurs — only one should promote
        # per pass (MAX_PROMOTIONS_PER_PASS = 1).
        for _ in range(3):
            tracker.record("temporal.paradox")
        promoted = promoter.check_and_promote()
        assert promoted is not None
        # Host has exactly one new rule.
        assert len(getattr(host, "_compiled_extra", [])) == 1
        # The promoted path was cleared.
        assert "narrative.continuity" not in tracker.recurrent_paths()
        # The other path still recurs (didn't get promoted this pass).
        assert "temporal.paradox" in tracker.recurrent_paths()

    def test_subsequent_pass_promotes_next_path(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker(default_threshold=3)
        promoter = _promoter(host, tracker)
        for _ in range(3):
            tracker.record("a")
        for _ in range(3):
            tracker.record("b")
        first = promoter.check_and_promote()
        second = promoter.check_and_promote()
        assert first is not None
        assert second is not None
        # Both rules now live in the host's runtime extras.
        assert len(getattr(host, "_compiled_extra", [])) == 2

    def test_recurrence_does_not_block_step_execution(self) -> None:
        # Sanity: an LLM-generated rule does not break host step execution.
        host = _empty_host()
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        promoted = promoter.promote_for_path("counter")
        assert promoted is not None
        # Drive a step on the promoted trigger.
        changes = host.step({"trigger": "turn.tick"})
        # The promoted rule fires (counter pinned to 0).
        writes = [c for c in changes if c.get("path") == "counter"]
        assert len(writes) == 1
        assert writes[0]["value"] == 0

    def test_check_and_promote_uses_tracker_threshold(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker(default_threshold=2)
        promoter = _promoter(host, tracker, threshold=2)
        tracker.record("only.twice")
        tracker.record("only.twice")
        out = promoter.check_and_promote()
        assert out is not None


# =====================================================================
# Self-consistency (a/b/c/d from design doc §3.2)
# =====================================================================


class TestSelfConsistency:
    def test_no_overwrite_when_id_collides(self) -> None:
        # Promotion id is computed against existing kernel rules + extras —
        # we verify it by pre-seeding the host with a colliding id.
        collider = WorldRule(
            rule_id="llm_world_flag_promoted",
            kind="dynamic",
            trigger="turn.tick",
            effect={
                "op": "writes",
                "changes": [{
                    "path": "world.flag",
                    "value": {"const": 5},
                }],
            },
            priority=5,
        )
        host = WorldKernelHost(
            WorldKernelSpec(world_type="test", rules=[collider]), {}, seed=0,
        )
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        rule = promoter.promote_for_path("world.flag")
        assert rule is not None
        # The promoted id MUST differ from the collider.
        assert rule.rule_id != collider.rule_id
        # Both rules live in the host — collider untouched.
        ids = _all_rule_ids(host)
        assert collider.rule_id in ids
        assert rule.rule_id in ids

    def test_promoted_rule_validates_via_compiler(self) -> None:
        host = _empty_host()
        tracker = AdjudicationTracker()
        promoter = _promoter(host, tracker)
        rule = promoter.promote_for_path("world.flag")
        assert rule is not None
        # The rule itself passes per-rule validation…
        assert RuleCompiler().validate_rule(rule) == []
        # …and so does the union with the host's existing rules.
        spec = WorldKernelSpec(
            world_type=host.kernel().world_type,
            rules=list(host.kernel().rules),
        )
        assert RuleCompiler().validate_spec(spec) == []
