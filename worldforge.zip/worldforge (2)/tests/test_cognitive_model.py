"""Tests for the cognitive-model layer (spec §8.2 model-error limit, step 1).

Step 1 is a pure refactor: the three-body δ₀→horizon misprediction is
repackaged as an explicit ``CognitiveModel`` / ``Belief``.  These tests pin
the new protocol's contract and the three-body adapter's behaviour.

The hard regression gate (6-outcome civilisation tests) lives in
``test_three_body_kernel.py`` — these tests cover the new surface only.
"""

from __future__ import annotations

import os
import sys

import numpy as np
import pytest

# Allow running from project root without setting PYTHONPATH.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.cognitive_model import (  # noqa: E402
    Belief,
    CognitiveModel,
    ThreeBodyCognitiveModel,
)
from theater.kernels.three_body import ThreeBodyKernel  # noqa: E402


# -- helpers -----------------------------------------------------------------

def _quick_kernel(years: float = 600.0, seed: int = 42) -> ThreeBodyKernel:
    k = ThreeBodyKernel(seed=seed, dt=0.02,
                        lyapunov_renorms=8, lyapunov_renorm_steps=80)
    k.bake(years=years)
    return k


def _first_chaos_or_skip(k: ThreeBodyKernel) -> float:
    chaotic = k.chaotic_era_intervals()
    if not chaotic:
        pytest.skip("bake produced no chaotic era")
    return chaotic[0].start


# -- Protocol / Belief contract ----------------------------------------------

def test_cognitive_model_protocol_is_runtime_checkable():
    """ThreeBodyCognitiveModel must satisfy the CognitiveModel protocol."""
    k = _quick_kernel()
    cm = ThreeBodyCognitiveModel(k)
    assert isinstance(cm, CognitiveModel)


def test_belief_is_sabre_committed_single_value():
    """Belief.predicted is a single committed value, never a distribution.

    Sabre commitment: the subject commits to one concrete prediction
    (``predicted`` is ``float | None``), not "A with 40% / B with 60%".
    ``confidence`` is a scalar self-assessment, not a probability mass.
    """
    b = Belief(predicted=12.5, confidence=0.7, model_error=False,
               committed_values={"T_predict": 8.0})
    assert b.predicted == 12.5
    assert isinstance(b.confidence, float)
    assert isinstance(b.model_error, bool)
    # committed_values is a plain dict of concrete scalars.
    assert b.committed_values["T_predict"] == 8.0


def test_belief_default_committed_values_is_independent():
    """Each Belief gets its own committed_values dict (no shared default)."""
    b1 = Belief()
    b2 = Belief()
    b1.committed_values["x"] = 1.0
    assert "x" not in b2.committed_values


# -- ThreeBodyCognitiveModel: high-tech predicts correctly -------------------

def test_high_tech_predicts_next_chaos(monkeypatch):
    """High tech → horizon covers the next chaos → belief.predicted = next_chaos."""
    k = _quick_kernel()
    chaos = _first_chaos_or_skip(k)
    vantage = max(0.0, chaos - 1.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)
    ev = k.civilization_step(tech_level=10.0, t=vantage)
    assert ev.kind == "survived"  # sanity: high tech survives
    cm = ThreeBodyCognitiveModel(k)
    belief = cm.predict({"next_chaos": ev.next_chaos},
                        {"tech_level": 10.0, "delta_0": ev.delta_0,
                         "T_predict": ev.T_predict}, vantage)
    assert belief.model_error is False
    assert belief.predicted == pytest.approx(ev.next_chaos)


def test_low_tech_mispredicts_deterministically(monkeypatch):
    """Low tech → horizon falls short → subject commits to 'no chaos' (model_error).

    The misprediction is deterministic in the seed: the same kernel/tech
    yields the same belief every time.
    """
    k = _quick_kernel()
    chaos = _first_chaos_or_skip(k)
    vantage = max(0.0, chaos - 5.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)
    ev = k.civilization_step(tech_level=0.0, t=vantage)
    assert ev.kind == "destroyed"  # sanity: low tech is destroyed
    cm = ThreeBodyCognitiveModel(k)
    cap = {"tech_level": 0.0, "delta_0": ev.delta_0, "T_predict": ev.T_predict}
    b1 = cm.predict({"next_chaos": ev.next_chaos}, cap, vantage)
    b2 = cm.predict({"next_chaos": ev.next_chaos}, cap, vantage)
    assert b1.model_error is True
    assert b1.predicted is None  # subject commits to "no chaos coming"
    # Determinism: identical inputs → identical belief.
    assert b1 == b2


def test_mispredict_is_seed_deterministic(monkeypatch):
    """Same seed reproduces the same model_error flag across two kernels."""
    k1 = _quick_kernel(seed=42)
    k2 = _quick_kernel(seed=42)
    chaos = _first_chaos_or_skip(k1)
    vantage = max(0.0, chaos - 5.0)
    for k in (k1, k2):
        monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)
    ev1 = k1.civilization_step(tech_level=0.0, t=vantage)
    ev2 = k2.civilization_step(tech_level=0.0, t=vantage)
    b1 = ThreeBodyCognitiveModel(k1).predict(
        {"next_chaos": ev1.next_chaos},
        {"tech_level": 0.0, "delta_0": ev1.delta_0, "T_predict": ev1.T_predict},
        vantage)
    b2 = ThreeBodyCognitiveModel(k2).predict(
        {"next_chaos": ev2.next_chaos},
        {"tech_level": 0.0, "delta_0": ev2.delta_0, "T_predict": ev2.T_predict},
        vantage)
    assert b1.model_error == b2.model_error
    assert b1.predicted == b2.predicted


# -- No next chaos: correct "no chaos" prediction ----------------------------

def test_no_next_chaos_yields_correct_no_chaos_belief():
    """When the kernel has no next chaotic era, the subject correctly commits
    to 'no chaos coming' — no model error."""
    k = _quick_kernel()
    # Force no next chaos from the current time.
    k.next_chaotic_era_after = lambda t: None  # type: ignore[assignment]
    ev = k.civilization_step(tech_level=2.0, t=0.0)
    cm = ThreeBodyCognitiveModel(k)
    belief = cm.predict({"next_chaos": None},
                        {"tech_level": 2.0, "delta_0": ev.delta_0,
                         "T_predict": ev.T_predict}, 0.0)
    assert belief.predicted is None
    assert belief.model_error is False


# -- Confidence: higher tech → higher confidence -----------------------------

def test_confidence_monotone_in_tech_level():
    """Confidence is a non-decreasing function of tech_level."""
    k = _quick_kernel()
    cm = ThreeBodyCognitiveModel(k)
    # Same ground truth / horizon, only tech changes.
    cap_low = {"tech_level": 0.0, "delta_0": 0.5, "T_predict": 5.0}
    cap_high = {"tech_level": 8.0, "delta_0": 0.5, "T_predict": 5.0}
    b_low = cm.predict({"next_chaos": 100.0}, cap_low, 0.0)
    b_high = cm.predict({"next_chaos": 100.0}, cap_high, 0.0)
    assert b_high.confidence > b_low.confidence
    assert 0.0 < b_low.confidence < 1.0
    assert 0.0 < b_high.confidence <= 1.0


def test_confidence_is_bounded_in_unit_interval():
    """Confidence must always be in [0, 1] even at extreme tech levels."""
    k = _quick_kernel()
    cm = ThreeBodyCognitiveModel(k)
    for tech in (-10.0, -1.0, 0.0, 5.0, 50.0, 1000.0):
        b = cm.predict({"next_chaos": 100.0},
                       {"tech_level": tech, "delta_0": 0.5, "T_predict": 5.0}, 0.0)
        assert 0.0 <= b.confidence <= 1.0


# -- committed_values carry T_predict / delta_0 ------------------------------

def test_committed_values_carry_horizon_quantities(monkeypatch):
    """Belief.committed_values carries T_predict and delta_0 (Sabre commitment)."""
    k = _quick_kernel()
    chaos = _first_chaos_or_skip(k)
    vantage = max(0.0, chaos - 5.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)
    ev = k.civilization_step(tech_level=1.5, t=vantage)
    cm = ThreeBodyCognitiveModel(k)
    belief = cm.predict(
        {"next_chaos": ev.next_chaos},
        {"tech_level": 1.5, "delta_0": ev.delta_0, "T_predict": ev.T_predict},
        vantage)
    assert belief.committed_values["T_predict"] == pytest.approx(ev.T_predict)
    assert belief.committed_values["delta_0"] == pytest.approx(ev.delta_0)
    assert belief.committed_values["tech_level"] == 1.5


# -- Integration: civilization_outcome attaches belief -----------------------

def test_outcome_carries_belief_with_model_error_on_destroyed_chaos(monkeypatch):
    """destroyed_chaos outcome carries a belief with model_error=True.

    The civilisation predicted 'no chaos coming' but the kernel knows
    chaos is coming — the dramatic-irony gap is captured in the belief.
    """
    k = _quick_kernel()
    chaos = _first_chaos_or_skip(k)
    vantage = max(0.0, chaos - 5.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)
    oc = k.civilization_outcome(tech_level=0.0, t=vantage, decision_vector=None)
    assert oc.kind == "destroyed_chaos"
    assert oc.belief is not None
    assert oc.belief["model_error"] is True
    assert oc.belief["predicted"] is None


def test_outcome_belief_no_error_on_survived(monkeypatch):
    """survived outcome carries a belief with model_error=False."""
    k = _quick_kernel()
    chaos = _first_chaos_or_skip(k)
    vantage = max(0.0, chaos - 1.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)
    oc = k.civilization_outcome(tech_level=10.0, t=vantage)
    assert oc.kind == "survived"
    assert oc.belief is not None
    assert oc.belief["model_error"] is False


def test_outcome_as_dict_includes_belief(monkeypatch):
    """Outcome.as_dict exposes the belief field for the narrator."""
    k = _quick_kernel()
    chaos = _first_chaos_or_skip(k)
    vantage = max(0.0, chaos - 5.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)
    d = k.civilization_outcome(tech_level=0.0, t=vantage).as_dict()
    assert "belief" in d
    assert isinstance(d["belief"], dict)
    assert {"predicted", "confidence", "model_error",
            "committed_values"} <= set(d["belief"])


def test_destroyed_decision_cause_unchanged_with_belief(monkeypatch):
    """destroyed_decision still routes on decision_quality; belief attached.

    Regression guard: the cognitive-model refactor must NOT change the
    destroyed_decision cause routing (§8.2 red line: kernel decides).
    """
    k = _quick_kernel()
    chaos = _first_chaos_or_skip(k)
    vantage = max(0.0, chaos - 5.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)
    bad = {"tech": 0.0, "shelter": 0.0, "hoard": 5.0, "gamble": 3.0}
    oc = k.civilization_outcome(tech_level=0.0, t=vantage,
                                decision_vector=bad)
    assert oc.kind == "destroyed_decision"
    assert oc.decision_quality == "mismatched"
    assert oc.cause == "bad_decision"
    # belief still attached; horizon short → model_error.
    assert oc.belief is not None
    assert oc.belief["model_error"] is True


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-q"]))
