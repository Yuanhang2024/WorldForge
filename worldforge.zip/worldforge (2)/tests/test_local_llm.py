"""Tests for the standard OpenAI LLM defaults + the OpenAILLMClient.

Covers the "删 Spark 改标准 OpenAI" task:

* ``Settings`` dataclass + ``from_env`` default to the public OpenAI
  endpoint (``https://api.openai.com/v1``), model ``gpt-4o-mini``, empty
  API key, ``enable_live_api=False`` (no key → disabled).
* Env vars (``AI_THEATER_*``) override every default.
* :class:`OpenAICompatibleClient` with explicit local settings POSTs to
  the configured endpoint and sends the configured model name.
* ``dispatcher._narrate_three_body`` derives its base URL + model from
  settings (follows the default automatically).
* :class:`OpenAILLMClient` POSTs a standard OpenAI ``/chat/completions``
  body (``messages`` array with ``role``/``content`` + ``model``) and
  parses the response content; ``as_dict_fn`` parses JSON (clean / fenced
  / prose-wrapped) and raises on non-JSON.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_local_llm.py -q
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

import pytest

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from theater.settings import (  # noqa: E402
    DEFAULT_API_KEY,
    DEFAULT_OPENAI_BASE_URL,
    DEFAULT_OPENAI_MODEL,
    LOCAL_LLM_API_KEY,
    LOCAL_LLM_BASE_URL,
    LOCAL_LLM_MODEL,
    Settings,
)
from theater.agents import (  # noqa: E402
    DeterministicModelClient,
    ModelClientError,
    OpenAICompatibleClient,
)
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402
from theater.llm_client import LLMError, OpenAILLMClient  # noqa: E402


# ---------------------------------------------------------------------------
# Settings defaults
# ---------------------------------------------------------------------------


def test_settings_dataclass_defaults_are_openai():
    s = Settings()
    assert s.base_url == DEFAULT_OPENAI_BASE_URL
    assert s.model_fast == DEFAULT_OPENAI_MODEL
    assert s.model_deep == DEFAULT_OPENAI_MODEL
    assert s.api_key == DEFAULT_API_KEY
    assert s.enable_live_api is False


def test_settings_default_constants_match_expected_values():
    assert DEFAULT_OPENAI_BASE_URL == "https://api.openai.com/v1"
    assert DEFAULT_OPENAI_MODEL == "gpt-4o-mini"
    assert DEFAULT_API_KEY == ""
    # Legacy local-server constants retained for reference (not the default).
    assert LOCAL_LLM_BASE_URL == "http://127.0.0.1:18899/v1"
    assert LOCAL_LLM_MODEL == "qwen3-coder-30b-nvfp4-blackwell"
    assert LOCAL_LLM_API_KEY == "local"


def test_settings_normalized_base_url_keeps_https_scheme():
    s = Settings()
    assert s.normalized_base_url == "https://api.openai.com/v1"


# ---------------------------------------------------------------------------
# from_env — no env → OpenAI defaults (live API off)
# ---------------------------------------------------------------------------


def test_from_env_no_env_uses_openai_defaults(monkeypatch, tmp_path):
    for key in (
        "AI_THEATER_API_KEY", "AI_THEATER_BASE_URL",
        "AI_THEATER_MODEL_FAST", "AI_THEATER_MODEL_DEEP",
        "AI_THEATER_ENABLE_LIVE_API",
    ):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.chdir(tmp_path)
    s = Settings.from_env(cwd=tmp_path)
    assert s.base_url == DEFAULT_OPENAI_BASE_URL
    assert s.model_fast == DEFAULT_OPENAI_MODEL
    assert s.model_deep == DEFAULT_OPENAI_MODEL
    assert s.api_key == DEFAULT_API_KEY
    assert s.enable_live_api is False


# ---------------------------------------------------------------------------
# from_env — env override (cloud / local server)
# ---------------------------------------------------------------------------


def test_from_env_cloud_env_vars_override(monkeypatch, tmp_path):
    for key in (
        "AI_THEATER_API_KEY", "AI_THEATER_BASE_URL",
        "AI_THEATER_MODEL_FAST", "AI_THEATER_MODEL_DEEP",
        "AI_THEATER_ENABLE_LIVE_API",
    ):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("AI_THEATER_API_KEY", "sk-cloud-secret")
    monkeypatch.setenv("AI_THEATER_BASE_URL", "https://api.requestme.top/v1")
    monkeypatch.setenv("AI_THEATER_MODEL_FAST", "gpt5.4")
    monkeypatch.setenv("AI_THEATER_MODEL_DEEP", "gpt5.5")
    s = Settings.from_env(cwd=tmp_path)
    assert s.api_key == "sk-cloud-secret"
    assert s.base_url == "https://api.requestme.top/v1"
    assert s.model_fast == "gpt5.4"
    assert s.model_deep == "gpt5.5"
    assert s.provider_model_fast == "gpt-5.4"
    assert s.provider_model_deep == "gpt-5.5"
    assert s.enable_live_api is True


def test_from_env_enable_live_api_flag(monkeypatch, tmp_path):
    for key in (
        "AI_THEATER_API_KEY", "AI_THEATER_BASE_URL",
        "AI_THEATER_MODEL_FAST", "AI_THEATER_MODEL_DEEP",
        "AI_THEATER_ENABLE_LIVE_API",
    ):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("AI_THEATER_API_KEY", "sk-x")
    monkeypatch.setenv("AI_THEATER_ENABLE_LIVE_API", "false")
    s = Settings.from_env(cwd=tmp_path)
    assert s.enable_live_api is False


@pytest.mark.parametrize("base_url", [
    "http://127.0.0.1:1234/v1",
    "http://localhost:11434/v1",
    "https://custom-provider.example/v1",
])
def test_from_env_empty_key_enables_non_openai_provider(
    monkeypatch, tmp_path, base_url,
):
    for key in (
        "AI_THEATER_API_KEY", "AI_THEATER_BASE_URL",
        "AI_THEATER_ENABLE_LIVE_API",
    ):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("AI_THEATER_BASE_URL", base_url)
    monkeypatch.setenv("AI_THEATER_MODEL_FAST", "provider-model")

    settings = Settings.from_env(cwd=tmp_path)

    assert settings.api_key == ""
    assert settings.enable_live_api is True
    assert settings.live_api_ready is True
    assert settings.agent_live_api_enabled("producer") is True


# ---------------------------------------------------------------------------
# OpenAICompatibleClient points at the configured endpoint
# ---------------------------------------------------------------------------


class _FakeResp:
    def __init__(self, body: bytes):
        self._body = body

    def read(self) -> bytes:
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def _openai_json(content: str) -> bytes:
    return json.dumps({
        "choices": [{"message": {"role": "assistant", "content": content}}]
    }).encode("utf-8")


def test_openai_client_posts_to_configured_endpoint(monkeypatch):
    """With explicit cloud settings, the director POST goes to the cloud."""
    settings = Settings(
        api_key="sk-cloud",
        base_url="https://api.requestme.top/v1",
        model_fast="gpt5.4",
        model_deep="gpt5.5",
        enable_live_api=True,
    )
    captured: List[str] = []

    def fake_urlopen(req):
        captured.append(req.full_url)
        return _FakeResp(_openai_json(
            '{"intent":"world_update","brief":"x","dialogue":"",'
            '"actor_id":"aster","warnings":[]}'
        ))

    monkeypatch.setattr("theater.agents.urllib.request.urlopen", fake_urlopen)
    client = OpenAICompatibleClient(settings)
    out = client.complete_json("producer", "清晨集市", settings.model_fast)
    assert out["actor_id"] == "aster"
    assert captured, "urlopen was never called"
    assert captured[0].startswith("https://api.requestme.top/v1/chat/completions")


def test_openai_client_sends_configured_model_name(monkeypatch):
    settings = Settings(
        api_key="sk-cloud",
        base_url="https://api.requestme.top/v1",
        model_fast="gpt5.4",
        model_deep="gpt5.5",
        enable_live_api=True,
    )
    captured: List[Dict[str, Any]] = []

    def fake_urlopen(req):
        captured.append(json.loads(req.data.decode("utf-8")))
        return _FakeResp(_openai_json(
            '{"intent":"world_update","brief":"x","dialogue":"",'
            '"actor_id":"aster","warnings":[]}'
        ))

    monkeypatch.setattr("theater.agents.urllib.request.urlopen", fake_urlopen)
    client = OpenAICompatibleClient(settings)
    client.complete_json("producer", "清晨集市", settings.model_fast)
    assert captured[0]["model"] == "gpt-5.4"


def test_runtime_client_disabled_configuration_raises_without_fallback():
    settings = Settings(
        base_url="https://api.openai.com/v1",
        api_key="",
        enable_live_api=True,
    )
    with pytest.raises(ModelClientError, match="not enabled"):
        OpenAICompatibleClient(settings).complete_json(
            "producer", "推进一拍", settings.model_fast,
        )


def test_runtime_client_network_failure_raises_without_fallback(monkeypatch):
    settings = Settings(
        base_url="http://127.0.0.1:1234/v1",
        api_key="",
        model_fast="local-model",
        model_deep="local-model",
        enable_live_api=True,
    )

    def fail(_req):
        import urllib.error
        raise urllib.error.URLError("provider unavailable")

    monkeypatch.setattr("theater.agents.urllib.request.urlopen", fail)
    with pytest.raises(ModelClientError, match="request failed"):
        OpenAICompatibleClient(settings).complete_json(
            "producer", "推进一拍", settings.model_fast,
        )


def test_runtime_client_invalid_output_raises_without_fallback(monkeypatch):
    settings = Settings(
        base_url="http://localhost:11434/v1",
        api_key="",
        model_fast="local-model",
        model_deep="local-model",
        enable_live_api=True,
    )
    monkeypatch.setattr(
        "theater.agents.urllib.request.urlopen",
        lambda _req: _FakeResp(_openai_json("{}")),
    )
    with pytest.raises(ModelClientError, match="missing string fields"):
        OpenAICompatibleClient(settings).complete_json(
            "producer", "推进一拍", settings.model_fast,
        )


def test_runtime_local_provider_uses_no_blank_authorization_header(monkeypatch):
    settings = Settings(
        base_url="http://127.0.0.1:1234/v1",
        api_key="",
        model_fast="local-model",
        model_deep="local-model",
        enable_live_api=True,
    )
    captured = {}

    def fake_urlopen(req):
        captured["headers"] = dict(req.headers)
        return _FakeResp(_openai_json(
            '{"intent":"world_update","brief":"x","dialogue":"",'
            '"actor_id":"","warnings":[]}'
        ))

    monkeypatch.setattr("theater.agents.urllib.request.urlopen", fake_urlopen)
    result = OpenAICompatibleClient(settings).complete_json(
        "producer", "推进一拍", settings.model_fast,
    )
    assert result["intent"] == "world_update"
    assert "Authorization" not in captured["headers"]


# ---------------------------------------------------------------------------
# _narrate_three_body follows settings (explicit local endpoint)
# ---------------------------------------------------------------------------


def test_narrate_three_body_uses_settings_base_url_and_model(monkeypatch, tmp_path):
    """The dispatcher's narration call derives base_url + model from settings."""
    settings = Settings(
        api_key="sk-local",
        base_url="http://127.0.0.1:18899/v1",
        model_fast="qwen3-coder-30b-nvfp4-blackwell",
        model_deep="qwen3-coder-30b-nvfp4-blackwell",
        enable_live_api=True,
    )
    orch = TheaterOrchestrator(
        state_store=JsonStateStore(tmp_path / "state"),
        model_client=None,  # not used by _narrate_three_body
        settings=settings,
    )
    captured: List[Dict[str, Any]] = []

    class _Resp:
        def read(self):
            return _openai_json(
                '{"title":"t","narrative":"n","dialogue":"d"}'
            )

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def fake_urlopen(req):
        captured.append({
            "url": req.full_url,
            "body": json.loads(req.data.decode("utf-8")),
        })
        return _Resp()

    import urllib.request as ur
    monkeypatch.setattr(ur, "urlopen", fake_urlopen)
    out = orch._narrate_three_body(["beat=1", "civ_survived"], "历史")
    assert captured, "urlopen was never called"
    assert captured[0]["url"].startswith("http://127.0.0.1:18899/v1/chat/completions")
    assert captured[0]["body"]["model"] == "qwen3-coder-30b-nvfp4-blackwell"
    assert out["title"] == "t"


# ---------------------------------------------------------------------------
# OpenAILLMClient — standard OpenAI /chat/completions protocol
# ---------------------------------------------------------------------------


def test_llm_client_posts_standard_openai_body(monkeypatch):
    """complete() POSTs {model, messages[{role,content}]} to /chat/completions."""
    client = OpenAILLMClient(
        base_url="https://api.openai.com/v1",
        api_key="sk-test",
        model="gpt-4o-mini",
    )
    captured: List[Dict[str, Any]] = []

    def fake_urlopen(req):
        captured.append({
            "url": req.full_url,
            "headers": dict(req.headers),
            "body": json.loads(req.data.decode("utf-8")),
        })
        return _FakeResp(_openai_json("hello world"))

    monkeypatch.setattr("theater.llm_client.urllib.request.urlopen", fake_urlopen)
    out = client.complete("hi", system="be brief")
    assert out == "hello world"
    assert captured[0]["url"] == "https://api.openai.com/v1/chat/completions"
    assert captured[0]["headers"]["Authorization"] == "Bearer sk-test"
    body = captured[0]["body"]
    assert body["model"] == "gpt-4o-mini"
    assert body["messages"] == [
        {"role": "system", "content": "be brief"},
        {"role": "user", "content": "hi"},
    ]
    assert body["stream"] is False


def test_llm_client_as_text_fn_single_arg(monkeypatch):
    client = OpenAILLMClient(
        base_url="https://api.openai.com/v1", api_key="sk-test", model="gpt-4o-mini",
    )
    monkeypatch.setattr(
        "theater.llm_client.urllib.request.urlopen",
        lambda req: _FakeResp(_openai_json("raw text")),
    )
    fn = client.as_text_fn(temperature=0.2, max_tokens=128)
    # Single-arg contract.
    assert fn("prompt only") == "raw text"


def test_llm_client_as_dict_fn_parses_json(monkeypatch):
    client = OpenAILLMClient(
        base_url="https://api.openai.com/v1", api_key="sk-test", model="gpt-4o-mini",
    )
    payload = '{"a": 1, "b": [2, 3]}'
    monkeypatch.setattr(
        "theater.llm_client.urllib.request.urlopen",
        lambda req: _FakeResp(_openai_json(payload)),
    )
    out = client.as_dict_fn()("describe")
    assert out == {"a": 1, "b": [2, 3]}


def test_llm_client_as_dict_fn_extracts_fenced_json(monkeypatch):
    client = OpenAILLMClient(
        base_url="https://api.openai.com/v1", api_key="sk-test", model="gpt-4o-mini",
    )
    fenced = "```json\n{\"x\": 5}\n```"
    monkeypatch.setattr(
        "theater.llm_client.urllib.request.urlopen",
        lambda req: _FakeResp(_openai_json(fenced)),
    )
    assert client.as_dict_fn()("style") == {"x": 5}


def test_llm_client_as_dict_fn_raises_on_non_json(monkeypatch):
    client = OpenAILLMClient(
        base_url="https://api.openai.com/v1", api_key="sk-test", model="gpt-4o-mini",
    )
    monkeypatch.setattr(
        "theater.llm_client.urllib.request.urlopen",
        lambda req: _FakeResp(_openai_json("not json at all")),
    )
    with pytest.raises(LLMError):
        client.as_dict_fn()("style")


def test_llm_client_requires_base_url_and_key():
    with pytest.raises(LLMError):
        OpenAILLMClient(base_url="", api_key="sk-test")
    with pytest.raises(LLMError):
        OpenAILLMClient(base_url="https://api.openai.com/v1", api_key="")


def test_llm_client_network_failure_retries_then_raises(monkeypatch):
    client = OpenAILLMClient(
        base_url="https://api.openai.com/v1", api_key="sk-test", model="gpt-4o-mini",
    )
    import urllib.error

    attempts = []

    def fake_urlopen(req):
        attempts.append(req)
        raise urllib.error.URLError("connection refused")

    monkeypatch.setattr("theater.llm_client.urllib.request.urlopen", fake_urlopen)
    with pytest.raises(LLMError, match="after 3 attempts"):
        client.complete("hi")
    assert len(attempts) == 3


def test_llm_client_retries_lm_studio_peer_keepalive_timeout(monkeypatch):
    client = OpenAILLMClient(
        base_url="http://127.0.0.1:1234/v1",
        api_key="lm-studio",
        model="deepseek-v4-flash",
    )
    import io
    import urllib.error

    attempts = []

    def fake_urlopen(req):
        attempts.append(req)
        if len(attempts) < 3:
            raise urllib.error.HTTPError(
                req.full_url,
                400,
                "Bad Request",
                {},
                io.BytesIO(
                    b'{"error":"LM Link connection entered error state '
                    b'peer_keepalive_timeout"}'
                ),
            )
        return _FakeResp(_openai_json("recovered"))

    monkeypatch.setattr("theater.llm_client.urllib.request.urlopen", fake_urlopen)
    assert client.complete("hi") == "recovered"
    assert len(attempts) == 3


def test_build_llm_unconfigured_returns_none(monkeypatch, tmp_path):
    """build_llm returns (None, msg) when no API key is configured."""
    from theater.onboarding_llm import build_llm
    for key in ("AI_THEATER_API_KEY", "AI_THEATER_BASE_URL"):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.chdir(tmp_path)
    client, msg = build_llm(settings=Settings.from_env(cwd=tmp_path))
    assert client is None
    assert msg


def test_build_llm_configured_returns_client(monkeypatch, tmp_path):
    from theater.onboarding_llm import build_llm
    for key in ("AI_THEATER_API_KEY", "AI_THEATER_BASE_URL", "AI_THEATER_MODEL_FAST"):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("AI_THEATER_API_KEY", "sk-test")
    monkeypatch.setenv("AI_THEATER_BASE_URL", "https://api.openai.com/v1")
    monkeypatch.setenv("AI_THEATER_MODEL_FAST", "gpt-4o-mini")
    client, msg = build_llm(settings=Settings.from_env(cwd=tmp_path))
    assert client is not None
    assert msg == ""


def test_runtime_character_client_posts_without_a_request_deadline(monkeypatch):
    settings = Settings(
        api_key="local",
        base_url="http://127.0.0.1:1234/v1",
        model_fast="model-a",
        model_deep="model-a",
        enable_live_api=True,
    )
    captured = {}

    def fake_urlopen(req):
        captured["url"] = req.full_url
        return _FakeResp(_openai_json(
            '{"name":"测试角色","summary":"中性角色卡","personality":"谨慎",'
            '"appearance":"未指定","sample_line":"你好",'
            '"warnings":[]}'
        ))

    monkeypatch.setattr("theater.agents.urllib.request.urlopen", fake_urlopen)
    out = OpenAICompatibleClient(settings).complete_character_card(
        "一个未指定世界观的角色", "model-a",
    )
    assert out["name"] == "测试角色"
    assert captured["url"].endswith("/chat/completions")


def test_deterministic_character_fallback_is_world_agnostic():
    out = DeterministicModelClient().complete_character_card(
        "一个负责记录变化的角色", "offline",
    )
    assert out["name"] == "主要角色"
    assert out["summary"] == "一个负责记录变化的角色"
    assert out["appearance"] == "未指定。"
