"""Regression tests for strict LLM-only GUI generation."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from theater.gui_generator import (
    GUIGenerator,
)


@pytest.mark.parametrize(
    "description",
    [
        "",
        "潮汐湿地生态监测站",
        "跨区域公共交通调度",
        "档案审计与线索核对",
        "mountain watershed council",
        "orbital resource planning",
        "nonsense-string-xyz",
    ],
)
def test_every_description_without_llm_fails(description):
    with pytest.raises(RuntimeError, match="requires llm_fn"):
        GUIGenerator().generate(description)


@pytest.mark.parametrize(
    "llm_fn",
    [
        lambda _prompt: (_ for _ in ()).throw(TimeoutError("timed out")),
        lambda _prompt: "not JSON",
        lambda _prompt: {"widgets": "not a list"},
    ],
)
def test_all_llm_failure_modes_fail_without_fallback(llm_fn):
    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("description B")
