import tempfile
import unittest
from pathlib import Path

from theater.dispatcher import TheaterOrchestrator
from theater.storage import JsonStateStore
from theater.agents import DeterministicModelClient
from theater.gates import ScienceDirectorGate
from theater.models import SceneObjectEntry


class SceneObjectGateTests(unittest.TestCase):
    def _table(self, **kw):
        base = dict(object_id="table", name="橡木长桌", kind="furniture", material="wood",
                    durability=3, is_destructible=True, affordances=["inspect", "push", "break"])
        base.update(kw)
        return SceneObjectEntry(**base)

    def test_berserker_breaks_wood_table(self):
        gate = ScienceDirectorGate()
        v = gate.validate_interaction("砸烂", self._table(), actor_strength=5)
        self.assertTrue(v["approved"])
        self.assertEqual(v["outcome"]["type"], "set_state")
        self.assertEqual(v["outcome"]["state"], "broken")
        self.assertTrue(v["outcome"].get("spawn_debris"))

    def test_indestructible_object_resists(self):
        gate = ScienceDirectorGate()
        v = gate.validate_interaction("砸烂", self._table(material="stone", is_destructible=False), actor_strength=9)
        self.assertFalse(v["approved"])
        self.assertEqual(v["outcome"]["type"], "none")

    def test_weak_hit_only_damages(self):
        gate = ScienceDirectorGate()
        v = gate.validate_interaction("砸", self._table(material="metal", durability=5), actor_strength=1)
        self.assertTrue(v["approved"])
        self.assertEqual(v["outcome"]["state"], "damaged")   # withstands, not broken

    def test_missing_object_rejected(self):
        gate = ScienceDirectorGate()
        v = gate.validate_interaction("砸", None)
        self.assertFalse(v["approved"])


class InteractionFlowTests(unittest.TestCase):
    def _orch(self):
        d = tempfile.mkdtemp()
        return TheaterOrchestrator(state_store=JsonStateStore(Path(d) / "s"),
                                   model_client=DeterministicModelClient())

    def test_break_table_full_chain(self):
        orch = self._orch()
        orch.add_object("table_main", "橡木长桌", kind="furniture", material="wood",
                        durability=3, affordances=["inspect", "break"])
        res = orch.interact(actor_id="berserker", verb="砸烂", object_id="table_main", actor_strength=5)
        self.assertTrue(res["ok"])
        self.assertEqual(res["applied_state"], "broken")
        # object state persisted
        obj = orch.state_store.get_object("table_main")
        self.assertEqual(obj.state, "broken")
        # propagated to worldbook (all agents now know)
        snap = orch.state_store.snapshot()
        self.assertTrue(any("table" in e.title.lower() or "长桌" in e.title for e in snap.worldbook))

    def test_break_indestructible_no_state_change(self):
        orch = self._orch()
        orch.add_object("altar", "石祭坛", material="stone", is_destructible=False, affordances=["inspect", "break"])
        res = orch.interact(actor_id="warrior", verb="砸烂", object_id="altar", actor_strength=9)
        self.assertFalse(res["ok"])
        self.assertIsNone(res["applied_state"])
        self.assertEqual(orch.state_store.get_object("altar").state, "intact")


class AutonomousInteractionTests(unittest.TestCase):
    def test_director_interaction_field_auto_executes(self):
        # the LLM director proposes an interaction; dispatch resolves it
        class InteractingClient(DeterministicModelClient):
            def complete_json(self, role, prompt, model):
                r = super().complete_json(role, prompt, model)
                r["intent"] = "action"
                r["actor_id"] = "berserker"
                r["interaction"] = {"verb": "砸烂", "object_id": "table_main", "actor_strength": 5}
                return r

        d = tempfile.mkdtemp()
        orch = TheaterOrchestrator(state_store=JsonStateStore(Path(d) / "s"),
                                   model_client=InteractingClient())
        orch.add_object("table_main", "橡木长桌", material="wood", durability=3, affordances=["inspect", "break"])
        res = orch.dispatch("狂战士砸桌子", session_id="t")
        inter = res.model_trace.get("interaction")
        self.assertIsNotNone(inter)
        self.assertEqual(inter["applied_state"], "broken")
        self.assertEqual(orch.state_store.get_object("table_main").state, "broken")

    def test_interaction_on_missing_object_is_noop(self):
        class InteractingClient(DeterministicModelClient):
            def complete_json(self, role, prompt, model):
                r = super().complete_json(role, prompt, model)
                r["interaction"] = {"verb": "砸", "object_id": "ghost_object", "actor_strength": 5}
                return r

        d = tempfile.mkdtemp()
        orch = TheaterOrchestrator(state_store=JsonStateStore(Path(d) / "s"),
                                   model_client=InteractingClient())
        res = orch.dispatch("砸一个不存在的东西", session_id="t")
        self.assertIsNone(res.model_trace.get("interaction"))  # no such object → no-op


if __name__ == "__main__":
    unittest.main()
