"""Tests for conditional triggers + event emit/chaining in WorldKernelHost.

Covers the event-trigger system extension:
  - Condition triggers: ``trigger`` is an AST, re-evaluated each ``turn.tick``.
  - Emit: an effect may ``emit`` a named event (optionally alongside a write).
  - Event chains: an emitted event name matches another rule's string trigger.
  - Condition not satisfied → rule does not fire.
  - ``condition_triggered`` auto-emit on condition-trigger firing.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_conditional_triggers.py -q
"""

from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.world_kernel_host import (
    RuleCompiler,
    WorldKernelHost,
    WorldKernelSpec,
    WorldRule,
)


# ---------------------------------------------------------------------------
# Rule fixtures — an outbreak world
# ---------------------------------------------------------------------------


def _quarantine_rule() -> WorldRule:
    """Condition-triggered: infected > 100 → start quarantine + emit event."""
    return WorldRule(
        rule_id="auto_quarantine",
        kind="dynamic",
        trigger={"op": "gt", "args": [{"op": "lookup", "args": ["infected"]}, 100]},
        effect={
            "emit": "quarantine_started",
            "writes": "policy.quarantine",
            "op": "set",
            "value": True,
        },
        description="infected > 100 → quarantine",
        priority=10,
    )


def _economy_reacts_rule() -> WorldRule:
    """String-triggered on the emitted event: quarantine → demand drops."""
    return WorldRule(
        rule_id="economy_reacts_to_quarantine",
        kind="dynamic",
        trigger="quarantine_started",
        effect={
            "writes": "economy.demand",
            "op": "set",
            "value": {"op": "sub", "args": [{"ref": "economy.demand"}, {"const": 20}]},
        },
        description="quarantine → demand down 20",
        priority=5,
    )


def _base_state() -> dict:
    return {
        "infected": 0,
        "policy": {"quarantine": False},
        "economy": {"demand": 100},
    }


def _host(rules, state=None) -> WorldKernelHost:
    spec = WorldKernelSpec(world_type="outbreak", rules=rules)
    return WorldKernelHost(spec, state or _base_state(), seed=42)


# ---------------------------------------------------------------------------
# Condition triggers
# ---------------------------------------------------------------------------


class TestConditionTrigger:
    def test_fires_when_condition_true(self) -> None:
        host = _host([_quarantine_rule()], {**_base_state(), "infected": 150})
        emitted = host.step({"trigger": "turn.tick"})
        assert host.query("policy.quarantine") is True
        writes = [c for c in emitted if c["path"] == "policy.quarantine"]
        assert len(writes) == 1 and writes[0]["value"] is True

    def test_does_not_fire_when_condition_false(self) -> None:
        host = _host([_quarantine_rule()], {**_base_state(), "infected": 50})
        emitted = host.step({"trigger": "turn.tick"})
        assert host.query("policy.quarantine") is False
        assert [c for c in emitted if c["path"] == "policy.quarantine"] == []

    def test_condition_trigger_ignored_off_tick(self) -> None:
        # Condition triggers only evaluate on turn.tick, not arbitrary events.
        host = _host([_quarantine_rule()], {**_base_state(), "infected": 150})
        emitted = host.step({"trigger": "some.other.event"})
        assert host.query("policy.quarantine") is False
        assert emitted == []

    def test_auto_emits_condition_triggered_event(self) -> None:
        host = _host([_quarantine_rule()], {**_base_state(), "infected": 150})
        emitted = host.step({"trigger": "turn.tick"})
        markers = [c for c in emitted if c["path"] == "_events.emit"]
        types = [m["value"]["event"].get("type") for m in markers]
        assert "condition_triggered" in types
        ct = next(m["value"]["event"] for m in markers
                  if m["value"]["event"].get("type") == "condition_triggered")
        assert ct["source_rule"] == "auto_quarantine"
        assert "path" in ct


# ---------------------------------------------------------------------------
# Emit events
# ---------------------------------------------------------------------------


class TestEmit:
    def test_emit_produces_named_event(self) -> None:
        host = _host([_quarantine_rule()], {**_base_state(), "infected": 150})
        emitted = host.step({"trigger": "turn.tick"})
        markers = [c for c in emitted if c["path"] == "_events.emit"]
        types = [m["value"]["event"].get("type") for m in markers]
        assert "quarantine_started" in types

    def test_emit_writes_state_too(self) -> None:
        # emit + writes: the state write still lands.
        host = _host([_quarantine_rule()], {**_base_state(), "infected": 150})
        host.step({"trigger": "turn.tick"})
        assert host.query("policy.quarantine") is True


# ---------------------------------------------------------------------------
# Event chains
# ---------------------------------------------------------------------------


class TestEventChain:
    def test_condition_emit_chains_to_string_trigger(self) -> None:
        # infected>100 (condition) → emit quarantine_started → economy reacts.
        host = _host(
            [_quarantine_rule(), _economy_reacts_rule()],
            {**_base_state(), "infected": 150},
        )
        host.step({"trigger": "turn.tick"})
        assert host.query("policy.quarantine") is True
        assert host.query("economy.demand") == 80  # 100 - 20

    def test_no_chain_when_condition_false(self) -> None:
        host = _host(
            [_quarantine_rule(), _economy_reacts_rule()],
            {**_base_state(), "infected": 50},
        )
        host.step({"trigger": "turn.tick"})
        assert host.query("policy.quarantine") is False
        assert host.query("economy.demand") == 100  # unchanged

    def test_direct_string_event_triggers_reactor(self) -> None:
        # Feeding the event name directly also fires the string-triggered rule.
        host = _host([_economy_reacts_rule()])
        host.step({"trigger": "quarantine_started"})
        assert host.query("economy.demand") == 80

    def test_chain_terminates(self) -> None:
        # A rule that emits its own trigger must not loop forever.
        loop_rule = WorldRule(
            rule_id="self_loop",
            kind="dynamic",
            trigger="ping",
            effect={"emit": "ping", "writes": "counter",
                    "op": "set", "value": {"op": "add",
                                            "args": [{"ref": "counter"}, {"const": 1}]}},
        )
        host = _host([loop_rule], {"counter": 0})
        emitted = host.step({"trigger": "ping"})
        # Bounded by _MAX_EVENT_CHAIN — terminates without hanging.
        assert host.query("counter") >= 1
        assert isinstance(emitted, list)


# ---------------------------------------------------------------------------
# Compilation / validation of the new shapes
# ---------------------------------------------------------------------------


class TestCompileNewShapes:
    def test_condition_trigger_rule_compiles(self) -> None:
        spec = WorldKernelSpec(world_type="outbreak", rules=[_quarantine_rule()])
        issues = RuleCompiler().validate_spec(spec)
        assert issues == []

    def test_bad_trigger_ast_rejected(self) -> None:
        bad = WorldRule(
            rule_id="bad_cond",
            kind="dynamic",
            trigger={"op": "eval", "args": [{"const": 1}]},
            effect={"emit": "x", "writes": "p", "op": "set", "value": True},
        )
        spec = WorldKernelSpec(world_type="x", rules=[bad])
        issues = RuleCompiler().validate_spec(spec)
        assert any("eval" in m for m in issues)

    def test_emit_without_name_rejected(self) -> None:
        bad = WorldRule(
            rule_id="bad_emit",
            kind="dynamic",
            trigger="t",
            effect={"emit": "", "writes": "p", "op": "set", "value": True},
        )
        spec = WorldKernelSpec(world_type="x", rules=[bad])
        issues = RuleCompiler().validate_spec(spec)
        assert any("emit" in m for m in issues)
