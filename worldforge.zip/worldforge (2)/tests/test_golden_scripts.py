"""Golden-script regression tests (architecture spec §13.5).

Without a golden baseline, every change to the kernel, DAG, or transactions
rolls the dice on whether the system still preserves its core invariants.
This file provides exactly that baseline: fixed-input
sequences that must produce bit-identical outputs on every run.

RED LINE: if any of these tests fail, the refactor/commit is BROKEN and must
not proceed until the invariant is restored or the spec is formally amended.
"""

from __future__ import annotations

import copy
import hashlib
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pytest

# Allow running from project root without setting PYTHONPATH.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.kernels.three_body import (  # noqa: E402
    EraSegment,
    ThreeBodyKernel,
    estimate_lyapunov,
    random_stars,
    stars_to_state,
    yoshida_step,
    total_energy,
)
from theater.dag import (  # noqa: E402
    PrerequisiteDAG,
    three_body_cognition_dag,
)
from theater.transactions import (  # noqa: E402
    StateChange,
    StateTransaction,
)
from theater.best_of_n import (  # noqa: E402
    BestOfN,
    ScoringCriteria,
)


# =========================================================================
# 1. Three-body kernel: same seed -> same lambda / same era structure
# =========================================================================

GOLDEN_SEEDS = [0, 1, 7, 42, 99, 123, 256, 999, 1729, 2024]


@pytest.mark.parametrize("seed", GOLDEN_SEEDS)
class TestThreeBodyGolden:
    """For each fixed seed, bake the kernel and assert bit-identical outputs
    across repeated bakes + exact era structure + positive Lyapunov."""

    def _bake(self, seed: int, years: float = 200.0) -> ThreeBodyKernel:
        k = ThreeBodyKernel(
            seed=seed,
            dt=0.02,
            lyapunov_renorms=8,
            lyapunov_renorm_steps=80,
            search_attempts=60,
        )
        k.bake(years=years)
        return k

    def test_lambda_is_deterministic(self, seed: int):
        """Two sequential bakes with the same seed produce identical lambda."""
        k1 = self._bake(seed)
        k2 = self._bake(seed)
        assert k1.lambda_ == pytest.approx(k2.lambda_, abs=1e-15), (
            f"seed={seed}: lambda drifted between bakes: {k1.lambda_} vs {k2.lambda_}"
        )

    def test_lambda_is_positive(self, seed: int):
        """Every golden seed must yield a chaotic (lambda > 0) configuration."""
        k = self._bake(seed)
        assert k.lambda_ > 1e-6, (
            f"seed={seed}: lambda={k.lambda_} not positive"
        )

    def test_era_count_is_deterministic(self, seed: int):
        """Same seed -> same number of eras."""
        k1 = self._bake(seed)
        k2 = self._bake(seed)
        assert len(k1.eras) == len(k2.eras), (
            f"seed={seed}: era count mismatch: {len(k1.eras)} vs {len(k2.eras)}"
        )

    def test_era_boundaries_are_deterministic(self, seed: int):
        """Each era segment has identical start/end/kind across bakes."""
        k1 = self._bake(seed)
        k2 = self._bake(seed)
        for i, (e1, e2) in enumerate(zip(k1.eras, k2.eras)):
            assert e1.start == pytest.approx(e2.start, abs=1e-12), (
                f"seed={seed}, era[{i}].start mismatch: {e1.start} vs {e2.start}"
            )
            assert e1.end == pytest.approx(e2.end, abs=1e-12), (
                f"seed={seed}, era[{i}].end mismatch: {e1.end} vs {e2.end}"
            )
            assert e1.kind == e2.kind, (
                f"seed={seed}, era[{i}].kind mismatch: {e1.kind} vs {e2.kind}"
            )

    def test_energy_drift_is_finite(self, seed: int):
        k = self._bake(seed)
        import math
        assert math.isfinite(k.energy_drift), (
            f"seed={seed}: energy_drift is not finite: {k.energy_drift}"
        )


def test_yoshida_step_deterministic():
    """Yoshida step with identical inputs yields bit-identical outputs."""
    masses = np.array([0.5, 0.3, 0.2])
    state = np.array([
        [1.0, 0.0, 0.0, 0.0, 0.5, 0.0],
        [-0.5, 0.8, 0.0, -0.3, -0.2, 0.0],
        [0.0, -0.6, 0.0, 0.2, -0.4, 0.0],
    ])
    s1 = yoshida_step(state.copy(), masses, 0.01)
    s2 = yoshida_step(state.copy(), masses, 0.01)
    np.testing.assert_array_equal(s1, s2)


def test_total_energy_deterministic():
    """total_energy with identical state yields bit-identical float."""
    masses = np.array([0.5, 0.3, 0.2])
    state = np.array([
        [1.0, 0.0, 0.0, 0.0, 0.5, 0.0],
        [-0.5, 0.8, 0.0, -0.3, -0.2, 0.0],
        [0.0, -0.6, 0.0, 0.2, -0.4, 0.0],
    ])
    e1 = total_energy(state, masses)
    e2 = total_energy(state, masses)
    assert e1 == pytest.approx(e2, abs=1e-15)


def test_estimate_lyapunov_deterministic():
    """estimate_lyapunov with same seed and inputs yields same lambda."""
    masses = np.array([0.5, 0.3, 0.2])
    star_state = np.array([
        [1.0, 0.0, 0.0, 0.0, 0.5, 0.0],
        [-0.5, 0.8, 0.0, -0.3, -0.2, 0.0],
        [0.0, -0.6, 0.0, 0.2, -0.4, 0.0],
    ])
    planet_state = np.array([2.0, 0.0, 0.1, 0.0, 0.3, 0.0])
    lam1 = estimate_lyapunov(
        star_state, masses, planet_state, dt=0.01,
        steps_per_renorm=50, n_renorms=6, d0=1e-9, rng=np.random.default_rng(0),
    )
    lam2 = estimate_lyapunov(
        star_state, masses, planet_state, dt=0.01,
        steps_per_renorm=50, n_renorms=6, d0=1e-9, rng=np.random.default_rng(0),
    )
    assert lam1 == pytest.approx(lam2, abs=1e-15)


# =========================================================================
# 2. DAG: fixed graph -> fixed reachability results
# =========================================================================

FIXED_DAG_NODES = ["root", "a", "b", "c", "d", "e", "f", "g"]
FIXED_DAG_EDGES = [
    ("root", "a"),
    ("root", "b"),
    ("a", "c"),
    ("a", "d"),
    ("b", "d"),
    ("b", "e"),
    ("c", "f"),
    ("d", "f"),
    ("e", "g"),
    ("f", "g"),
]


def _build_fixed_dag() -> PrerequisiteDAG:
    """Build the standard test DAG used by all DAG golden tests."""
    dag = PrerequisiteDAG()
    for nid in FIXED_DAG_NODES:
        dag.add_node(nid)
    for pre, dep in FIXED_DAG_EDGES:
        dag.add_edge(pre, dep)
    return dag


GOLDEN_DAG_WALK = [
    ("root", True, False, []),
    ("a", False, False, ["root"]),
    ("b", False, False, ["root"]),
    ("c", False, False, ["a"]),
    ("d", False, False, ["a", "b"]),
    ("e", False, False, ["b"]),
    ("f", False, False, ["c", "d"]),
    ("g", False, False, ["e", "f"]),
]


def test_dag_initial_state_is_golden():
    """Freshly-built DAG: verify can_reach/is_unlocked/missing_prerequisites
    for every node matches golden expectations."""
    dag = _build_fixed_dag()
    for node_id, expected_reachable, expected_unlocked, expected_missing in GOLDEN_DAG_WALK:
        assert dag.can_reach(node_id) is expected_reachable, (
            f"can_reach({node_id}) mismatch"
        )
        assert dag.is_unlocked(node_id) is expected_unlocked, (
            f"is_unlocked({node_id}) mismatch"
        )
        assert sorted(dag.missing_prerequisites(node_id)) == expected_missing, (
            f"missing_prerequisites({node_id}) mismatch"
        )


def test_dag_unlock_sequence_is_golden():
    """Unlocking nodes in a fixed sequence produces a deterministic unlock set."""
    dag = _build_fixed_dag()
    dag.unlock("root")
    dag.advance("a")
    dag.advance("b")
    dag.advance("c")
    dag.advance("d")
    dag.advance("e")
    dag.advance("f")
    dag.advance("g")
    unlocked = sorted(dag.unlocked_set())
    assert unlocked == sorted(FIXED_DAG_NODES), f"unlocked set mismatch: {unlocked}"


def test_dag_topological_order_is_golden():
    """Topological order is deterministic for a fixed graph."""
    dag = _build_fixed_dag()
    order = dag.topological_order()
    # Check that every edge is respected.
    idx = {n: i for i, n in enumerate(order)}
    for pre, dep in FIXED_DAG_EDGES:
        assert idx[pre] < idx[dep], (
            f"{pre} must come before {dep} in topo order; got {order}"
        )
    # Verify it matches exactly — produce a known-good order.
    assert order[0] == "root", f"expected root first, got {order[0]}"
    assert order[-1] == "g", f"expected g last, got {order[-1]}"


def test_dag_serialization_round_trip_is_deterministic():
    """to_dict then from_dict produces an identical DAG (node set, edges, unlocks)."""
    dag = _build_fixed_dag()
    dag.unlock("root")
    dag.advance("a")
    snapshot = dag.to_dict()
    restored = PrerequisiteDAG.from_dict(snapshot)
    assert sorted(restored.nodes()) == sorted(dag.nodes())
    for nid in dag.nodes():
        assert sorted(restored.prerequisites(nid)) == sorted(dag.prerequisites(nid))
        assert restored.is_unlocked(nid) == dag.is_unlocked(nid)


def test_three_body_cognition_dag_is_golden():
    """The factory DAG has exactly 11 nodes, all locked, with escape reachable
    only through the full chain."""
    dag = three_body_cognition_dag()
    assert len(dag.nodes()) == 11
    assert dag.unlocked_set() == frozenset()
    # Full walk
    walk = [
        "observe", "curve_fit", "periodicity", "falsify_periodic",
        "gravity_law", "three_body_eq", "numerical_integrate",
        "sensitive_dependence", "chaos", "lyapunov_wall", "escape",
    ]
    dag.unlock("observe")
    for nid in walk[1:]:
        assert dag.can_reach(nid), f"{nid} should be reachable before advance"
        dag.advance(nid)
    assert dag.is_unlocked("escape")


# =========================================================================
# 3. Transactions: same sequence apply+commit -> same state (reproducibility)
# =========================================================================

GOLDEN_STATE = {
    "civilization": {
        "tech_level": 3,
        "population": 1_000_000,
    },
    "resources": {"iron": 100, "gold": 5},
    "flags": {"civil_war": False, "famine": False},
}


GOLDEN_CHANGE_SEQUENCE: List[Dict[str, Any]] = [
    {"origin": "kernel", "path": "civilization.tech_level", "value": 4,
     "prerequisites_checked": ["dag:gravity_law"], "speculative": True},
    {"origin": "rule_engine", "path": "resources.iron", "value": 50,
     "prerequisites_checked": ["conservation:resources"], "speculative": True},
    {"origin": "llm_adjudication", "path": "flags.civil_war", "value": True,
     "prerequisites_checked": ["conservation:resources"],
     "adjudication_ref": "llm_output_log:7", "speculative": True},
    {"origin": "kernel", "path": "flags.famine", "value": True,
     "prerequisites_checked": ["dag:sensitive_dependence"], "speculative": True},
    {"origin": "rule_engine", "path": "resources.gold", "value": 0,
     "prerequisites_checked": ["conservation:resources"], "speculative": True},
]


def _make_change(cfg: dict) -> StateChange:
    kwargs = dict(
        origin=cfg["origin"],
        changes=[{"path": cfg["path"], "op": "set", "value": cfg["value"]}],
        prerequisites_checked=cfg["prerequisites_checked"],
        speculative=cfg.get("speculative", True),
    )
    if cfg.get("adjudication_ref"):
        kwargs["adjudication_ref"] = cfg["adjudication_ref"]
    return StateChange.new(**kwargs)


def test_transaction_reproducibility_golden_sequence():
    """Same sequence of StateChanges applied to identical base states produces
    bit-identical committed states."""
    states = []
    for _ in range(3):
        base = copy.deepcopy(GOLDEN_STATE)
        txn = StateTransaction(base).begin()
        for cfg in GOLDEN_CHANGE_SEQUENCE:
            txn.apply(_make_change(cfg))
        states.append(txn.commit())

    # All three must be identical
    for i in range(1, len(states)):
        assert states[0] == states[i], (
            f"reproducibility failure between run 0 and run {i}"
        )

    # Check expected final values
    final = states[0]
    assert final["civilization"]["tech_level"] == 4
    assert final["resources"]["iron"] == 50
    assert final["resources"]["gold"] == 0
    assert final["flags"]["civil_war"] is True
    assert final["flags"]["famine"] is True


def test_transaction_rollback_restores_golden():
    """Rollback restores exactly the original base state."""
    base = copy.deepcopy(GOLDEN_STATE)
    base_hash = hashlib.sha256(repr(sorted(base.items())).encode()).hexdigest()
    txn = StateTransaction(base).begin()
    for cfg in GOLDEN_CHANGE_SEQUENCE:
        txn.apply(_make_change(cfg))
    txn.rollback()
    assert base == GOLDEN_STATE, "rollback did not restore golden state"
    # Verify identity too (not just equality)
    rollback_hash = hashlib.sha256(repr(sorted(base.items())).encode()).hexdigest()
    assert base_hash == rollback_hash


def test_transaction_shadow_does_not_mutate_base():
    """While a speculative transaction is active, the base state is untouched."""
    base = copy.deepcopy(GOLDEN_STATE)
    txn = StateTransaction(base).begin()
    txn.apply(_make_change(GOLDEN_CHANGE_SEQUENCE[0]))  # speculative: tech_level -> 4
    assert base["civilization"]["tech_level"] == 3, "speculative change leaked to base"


def test_transaction_non_speculative_writes_through():
    """Non-speculative changes write directly to base state."""
    base = copy.deepcopy(GOLDEN_STATE)
    txn = StateTransaction(base).begin()
    change = StateChange.new(
        origin="rule_engine",
        changes=[{"path": "resources.iron", "op": "set", "value": 50}],
        prerequisites_checked=["conservation:resources"],
        speculative=False,
    )
    txn.apply(change)
    assert base["resources"]["iron"] == 50, "non-speculative change did not reach base"


# =========================================================================
# 4. World isolation: two worlds' state doesn't mix
# =========================================================================


def test_world_isolation_golden():
    """Two worlds (main, three_body) have fully separated state: writing to one
    does not affect the other, even through the same orchestrator."""
    from theater.dispatcher import TheaterOrchestrator
    from theater.agents import DeterministicModelClient
    from theater.storage import JsonStateStore
    from theater.models import CharacterPatch, WorldBookPatch

    d = tempfile.mkdtemp()
    store = JsonStateStore(Path(d) / "state")
    orch = TheaterOrchestrator(
        state_store=store,
        model_client=DeterministicModelClient(),
    )

    # Write to main world
    orch.state_store.add_world_entry(
        WorldBookPatch(title="卡门场景", content="歌剧世界", source="test"),
        approved_by="science_director",
    )

    # Switch to three_body world
    orch.set_world("three_body")
    snap = orch.state_store.snapshot()
    assert len(snap.worldbook) == 0, "three_body world saw main's worldbook entries"

    # Write to three_body
    orch.state_store.add_world_entry(
        WorldBookPatch(title="三体世界", content="乱纪元", source="test"),
        approved_by="science_director",
    )

    # Back to main: should only have carmen, not three_body
    orch.set_world("main")
    snap = orch.state_store.snapshot()
    titles = [e.title for e in snap.worldbook]
    assert "卡门场景" in titles
    assert "三体世界" not in titles

    # Three_body still has its own entry
    orch.set_world("three_body")
    snap = orch.state_store.snapshot()
    titles = [e.title for e in snap.worldbook]
    assert "三体世界" in titles
    assert "卡门场景" not in titles


def test_world_isolation_characters_golden():
    """Characters created in main world do not appear in three_body world."""
    from theater.dispatcher import TheaterOrchestrator
    from theater.agents import DeterministicModelClient
    from theater.storage import JsonStateStore
    from theater.models import CharacterPatch

    d = tempfile.mkdtemp()
    store = JsonStateStore(Path(d) / "state")
    orch = TheaterOrchestrator(
        state_store=store,
        model_client=DeterministicModelClient(),
    )

    # Create character in main
    orch.state_store.upsert_character(
        CharacterPatch(
            character_id="carmen", name="卡门", summary="歌剧",
            source="test",
        ),
        approved_by="science_director",
    )

    # three_body sees no characters
    orch.set_world("three_body")
    snap = orch.state_store.snapshot()
    assert len(snap.characters) == 0

    # Back to main, character still exists
    orch.set_world("main")
    snap = orch.state_store.snapshot()
    assert len(snap.characters) == 1
    assert snap.characters[0].character_id == "carmen"


# =========================================================================
# 7. Best-of-N: scoring determinism
# =========================================================================

GOLDEN_CANDIDATES = [
    "The moonlit cafe Luna offers a cozy atmosphere with creative vibes.",
    "Luna Cafe: where every sip feels like a warm moonlit embrace of comfort.",
    "A small cozy cafe named Luna, bathed in moonlit calm and creativity.",
    "Bad cafe bad no good terrible awful horrible yuck.",
    "x",
]

GOLDEN_PROMPT = "Find three creative business names for a cafe called Luna with cozy atmosphere"


class TestBestOfNGolden:
    """BestOfN scoring must be deterministic: same text + same prompt + same
    criteria yields the same score every time."""

    def test_score_is_deterministic(self):
        """Same candidate, same prompt, same criteria -> bit-identical score."""
        bon = BestOfN()
        crit = ScoringCriteria.from_prompt(GOLDEN_PROMPT)
        for cand in GOLDEN_CANDIDATES:
            s1 = bon.score(cand, GOLDEN_PROMPT, crit)
            s2 = bon.score(cand, GOLDEN_PROMPT, crit)
            assert s1 == pytest.approx(s2, abs=1e-15), (
                f"score not deterministic for candidate: {cand!r}"
            )

    def test_scoring_ranks_correctly(self):
        """Good candidates consistently outrank bad ones."""
        bon = BestOfN()
        crit = ScoringCriteria.from_prompt(GOLDEN_PROMPT)
        scores = [bon.score(c, GOLDEN_PROMPT, crit) for c in GOLDEN_CANDIDATES]
        # The first three (meaningful) should beat the last two (garbage)
        for good_idx in range(3):
            for bad_idx in range(3, 5):
                assert scores[good_idx] > scores[bad_idx], (
                    f"candidate {good_idx} (score={scores[good_idx]}) should beat "
                    f"candidate {bad_idx} (score={scores[bad_idx]})"
                )

    def test_score_components_are_in_unit_interval(self):
        """Each ScoreBreakdown component is in [0, 1]."""
        bon = BestOfN()
        crit = ScoringCriteria.from_prompt(GOLDEN_PROMPT)
        for cand in GOLDEN_CANDIDATES:
            bd = bon.score_breakdown(cand, GOLDEN_PROMPT, crit)
            for field in ("length", "keyword", "format", "diversity", "no_duplicate"):
                v = getattr(bd, field)
                assert 0.0 <= v <= 1.0, (
                    f"{field}={v} outside [0, 1] for {cand!r}"
                )

    def test_select_picks_best_golden(self):
        """select returns the highest-scoring candidate."""
        bon = BestOfN()
        crit = ScoringCriteria.from_prompt(GOLDEN_PROMPT)
        best, ranked = bon.select(GOLDEN_CANDIDATES, GOLDEN_PROMPT, crit)
        scores = [r.score for r in ranked]
        assert scores == sorted(scores, reverse=True), "ranked not sorted desc"
        assert best == ranked[0].text, "best != ranked[0]"
        # The best candidate should be one of the first three (meaningful ones)
        assert best in GOLDEN_CANDIDATES[:3], (
            f"best candidate {best!r} is not among the top 3"
        )


def test_best_of_n_score_sum_weights_approx_one():
    """Total score with all-max components must approach 1.0."""
    bon = BestOfN()
    crit = ScoringCriteria(
        required_keywords=("luna", "cafe"),
        want_json=False,
        length_lo=10,
        length_hi=200,
    )
    text = "Luna cafe is the best place for coffee and relaxing"
    score = bon.score(text, "luna cafe", crit)
    # With a reasonable text that hits most keywords, score should be well above 0.5
    assert score > 0.5, f"score too low for reasonable text: {score}"
    assert score <= 1.0


# =========================================================================
# 9. Cross-component invariant: DAG + Transactions integration
#    (advancing through DAG then committing state changes)
# =========================================================================

def test_dag_transaction_integration_golden():
    """Advance through the three-body cognition DAG, then apply corresponding
    state changes, and verify the full sequence is reproducible."""
    # Run the full sequence twice
    def full_sequence() -> bytes:
        dag = three_body_cognition_dag()
        dag.unlock("observe")
        base = copy.deepcopy(GOLDEN_STATE)
        txn = StateTransaction(base).begin()

        walk = [
            ("curve_fit", "civilization.tech_level", 4),
            ("periodicity", "resources.iron", 80),
            ("falsify_periodic", "flags.civil_war", True),
        ]
        for node_id, path, value in walk:
            dag.advance(node_id)
            txn.apply(StateChange.new(
                origin="kernel",
                changes=[{"path": path, "op": "set", "value": value}],
                prerequisites_checked=[f"dag:{node_id}"],
                speculative=True,
            ))
        txn.commit()
        return hashlib.sha256(repr(sorted(base.items())).encode()).digest()

    h1 = full_sequence()
    h2 = full_sequence()
    assert h1 == h2, "DAG + transaction integrated sequence not reproducible"


# =========================================================================
# Verify: ``pytest tests/test_golden_scripts.py -q`` must pass entirely.
# =========================================================================
