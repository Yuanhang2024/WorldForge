from pathlib import Path
import tempfile
import unittest

from theater.gates import ScienceDirectorGate
from theater.models import CharacterPatch, Task
from theater.runtime import EmbeddingMemory, GameSessionManager, PossessionManager, TaskManager
from theater.storage import JsonStateStore


class RuntimeManagersTests(unittest.TestCase):
    def test_task_manager_persists_tasks_by_priority_and_session(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manager = TaskManager(root / "runtime")
            manager.enqueue(
                "story_queue",
                [
                    Task("task_low", "game_logic", 3, {"step": "later"}),
                    Task("task_high", "world_update", 1, {"event": "archive opens"}),
                ],
            )

            reloaded = TaskManager(root / "runtime")
            queued = reloaded.list_tasks("story_queue")

            self.assertEqual([task.task_id for task in queued], ["task_high", "task_low"])
            self.assertEqual([task.status for task in queued], ["queued", "queued"])

    def test_possession_manager_enters_and_exits_with_science_director_state(self):
        with tempfile.TemporaryDirectory() as directory:
            store = JsonStateStore(Path(directory) / "state")
            manager = PossessionManager(store, ScienceDirectorGate())

            entered = manager.enter_possession("aster", "player_01", "我要夺舍 Aster")
            self.assertTrue(entered.possessed)
            self.assertEqual(entered.possessed_by, "player_01")
            self.assertIn("suppressed", entered.ai_subconscious.lower())

            action = {
                "actor_id": "aster",
                "intent": "inspect",
                "target": "archive",
            }
            queued = manager.queue_ai_action("aster", action)
            self.assertEqual(len(queued.pending_ai_actions), 1)
            self.assertEqual(queued.pending_ai_actions[0]["intent"], "inspect")

            exited = manager.exit_possession("aster")
            self.assertFalse(exited.possessed)
            self.assertIsNone(exited.possessed_by)
            self.assertEqual(exited.pending_ai_actions, [])

    def test_game_session_manager_steps_sessions_independently(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = GameSessionManager(Path(directory) / "runtime")

            first = manager.step("story_a", "inspect")
            second = manager.step("story_a", "move")
            other = manager.step("story_b", "inspect")

            self.assertEqual(first["tick"], 1)
            self.assertEqual(second["tick"], 2)
        self.assertEqual(other["tick"], 1)
        self.assertEqual(second["last_command"], "move")

    def test_embedding_memory_returns_deterministic_vector_without_secret_material(self):
        memory = EmbeddingMemory(dimensions=8)

        result = memory.embed("Storm Archive memory")

        self.assertEqual(result["dimensions"], 8)
        self.assertEqual(len(result["embedding"]), 8)
        self.assertEqual(result["provider"], "local_hash_embedding")
        self.assertNotIn("sk-", str(result))

    def test_science_gate_rejects_invalid_possession_patch(self):
        gate = ScienceDirectorGate()
        patch = CharacterPatch(
            character_id="aster",
            name="Aster",
            summary="Possessed actor without control boundary.",
            source="unit-test",
            possessed=True,
            possessed_by="player_01",
            ai_subconscious="",
            possession_limit={},
        )

        approval = gate.validate_write([], [patch])

        self.assertFalse(approval.approved)
        self.assertIn("possession patch requires suppression", " ".join(approval.reasons))


if __name__ == "__main__":
    unittest.main()
