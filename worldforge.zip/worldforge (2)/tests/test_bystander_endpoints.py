"""Server-side smoke tests for the bystander posture (spec §10.2/§10.3/§13.4):
summary endpoint + fast-forward endpoint + possession-safe autonomous advance.
Uses the real HTTP server with an explicitly injected deterministic test stub;
production has no automatic offline model fallback.
"""
import json
import os
import tempfile
import threading
import unittest
from urllib import request

from theater.agents import DeterministicModelClient
from theater.server import create_server


class BystanderEndpointTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._previous = dict(os.environ)
        os.environ["AI_THEATER_API_KEY"] = ""
        os.environ["AI_THEATER_ENABLE_LIVE_API"] = "true"
        os.environ["AI_THEATER_BASE_URL"] = "http://127.0.0.1:1/v1"
        os.environ["AI_THEATER_MODEL_FAST"] = "test-model"
        os.environ["AI_THEATER_MODEL_DEEP"] = "test-model"
        os.environ["AI_THEATER_DATA_DIR"] = self._tmp.name
        self.server = create_server(host="127.0.0.1", port=0)
        self.server.orchestrator.model_client = DeterministicModelClient()
        self.server.orchestrator._narrate_three_body = lambda events, history: {
            "title": "test adapter beat",
            "narrative": "; ".join(events),
            "dialogue": "",
            "warnings": [],
        }
        self._thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self._thread.start()
        self.base_url = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        os.environ.clear()
        os.environ.update(self._previous)
        self._tmp.cleanup()

    def _post(self, path, payload):
        req = request.Request(
            f"{self.base_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        return json.loads(request.urlopen(req, timeout=15).read())

    def _get(self, path):
        return json.loads(request.urlopen(f"{self.base_url}{path}", timeout=15).read())

    def test_summary_returns_recent_entries_with_explicit_model_stub(self):
        # Produce a beat so the worldbook is non-empty.
        self._post("/api/world/tick", {"mode": "generic", "world_id": "main"})
        body = self._get("/api/world/offline_summary?world_id=main&max_entries=3")
        self.assertIs(body["ok"], True)
        self.assertEqual(body["world_id"], "main")
        self.assertIsInstance(body["recent_entries"], list)
        self.assertGreaterEqual(len(body["recent_entries"]), 1)

    def test_summary_empty_world_returns_empty_summary(self):
        body = self._get("/api/world/offline_summary?world_id=empty_world")
        self.assertIs(body["ok"], True)
        self.assertEqual(body["summary"], "")
        self.assertEqual(body["recent_entries"], [])

    def test_fast_forward_generic_runs_n_beats(self):
        body = self._post("/api/world/fast_forward",
                          {"beats": 3, "mode": "generic", "world_id": "main"})
        self.assertIs(body["ok"], True)
        self.assertEqual(body["beats_run"], 3)
        self.assertEqual(len(body["summaries"]), 3)
        self.assertIsNotNone(body["last_beat"])

    def test_world_tick_defaults_to_generic_runtime(self):
        body = self._post("/api/world/tick", {})
        self.assertIs(body["ok"], True)
        self.assertEqual(body["beat"]["session_id"], "world_tick")
        state = self._get("/api/state")
        self.assertEqual(state["world_id"], "main")

    def test_fast_forward_defaults_to_current_generic_world(self):
        body = self._post("/api/world/fast_forward", {"beats": 1})
        self.assertIs(body["ok"], True)
        self.assertEqual(body["beats_run"], 1)
        state = self._get("/api/state")
        self.assertEqual(state["world_id"], "main")

    def test_fast_forward_clamps_to_safety_cap(self):
        # Requesting 9999 beats must clamp to 50, not run away.
        body = self._post("/api/world/fast_forward",
                          {"beats": 9999, "mode": "generic", "world_id": "main"})
        self.assertIs(body["ok"], True)
        self.assertLessEqual(body["beats_run"], 50)

    def test_fast_forward_three_body_advances_cursor(self):
        body = self._post("/api/world/fast_forward",
                          {"beats": 2, "mode": "three_body",
                           "world_id": "three_body", "decision": {"tech_level": 1.0}})
        self.assertIs(body["ok"], True)
        self.assertGreaterEqual(body["beats_run"], 1)


if __name__ == "__main__":
    unittest.main()
