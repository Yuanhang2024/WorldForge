"""P2 — 张力5: possession execution closure (setuid action loop, §10.6).

Before this fix, PossessionManager had enter/exit/queue + an allowed_actions
*declaration* but no executor — the player could say "去北边" during possession
and nothing routed it. These tests pin the closed loop:

  * allowed verb → executed (state changes via the single write point, I4)
  * disallowed verb → rejected before any state touches
  * action on a non-possessed character → rejected
  * object-targeted verbs route through the gate-arbitrated interact path
  * non-object verbs record a possession worldbook fact
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.models import SceneObjectPatch  # noqa: E402
from theater.runtime import PossessionManager  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402


def _orch(tmp: Path) -> TheaterOrchestrator:
    return TheaterOrchestrator(
        state_store=JsonStateStore(tmp / "state"),
        model_client=DeterministicModelClient(),
    )


@pytest.fixture
def tmp_root(tmp_path):
    return tmp_path


def _possess(orch: TheaterOrchestrator, cid: str = "aster",
             allowed=("move", "speak", "inspect")):
    """Enter possession on a character with a custom allowed_actions set."""
    # Ensure the character exists first.
    from theater.models import CharacterPatch
    orch.upsert_character(
        CharacterPatch(character_id=cid, name=cid.title(),
                       summary="test actor", source="test",
                       possession_limit={"max_duration": 3600,
                                         "allowed_actions": list(allowed)}),
        approved_by="science_director")
    orch.possession_manager.enter_possession(cid, "player_01", reason="test")


# ---------------------------------------------------------------------------
# PossessionManager.execute_action: pure validation + executor dispatch
# ---------------------------------------------------------------------------


def test_execute_action_rejects_disallowed_verb(tmp_root):
    orch = _orch(tmp_root)
    _possess(orch, "aster", allowed=("move", "speak"))
    calls = []
    out = orch.possession_manager.execute_action(
        "aster", "fly", {}, executor=lambda v, p: calls.append((v, p)) or {"ok": True})
    assert out["ok"] is False
    assert "not in allowed_actions" in out["reason"]
    assert calls == []  # executor never ran


def test_execute_action_rejects_when_not_possessed(tmp_root):
    orch = _orch(tmp_root)
    from theater.models import CharacterPatch
    orch.upsert_character(
        CharacterPatch(character_id="ghost", name="Ghost",
                       summary="not possessed", source="test",
                       possession_limit={"max_duration": 3600,
                                         "allowed_actions": ["move"]}),
        approved_by="science_director")
    out = orch.possession_manager.execute_action(
        "ghost", "move", {}, executor=lambda v, p: {"ok": True})
    assert out["ok"] is False
    assert "not possessed" in out["reason"]


def test_execute_action_validation_only_when_no_executor(tmp_root):
    orch = _orch(tmp_root)
    _possess(orch, "aster", allowed=("move",))
    out = orch.possession_manager.execute_action("aster", "move", {})
    assert out["ok"] is True
    assert out["reason"] == "validated (no executor)"


def test_execute_action_invokes_executor_for_allowed_verb(tmp_root):
    orch = _orch(tmp_root)
    _possess(orch, "aster", allowed=("move", "speak"))
    seen = {}
    def _exec(v, p):
        seen["v"] = v
        seen["p"] = p
        return {"ok": True, "moved": "north"}
    out = orch.possession_manager.execute_action(
        "aster", "move", {"detail": "north"}, executor=_exec)
    assert out["ok"] is True
    assert seen["v"] == "move"
    assert seen["p"]["detail"] == "north"
    assert out["result"]["moved"] == "north"


def test_execute_action_executor_exception_is_caught(tmp_root):
    orch = _orch(tmp_root)
    _possess(orch, "aster", allowed=("move",))
    def _boom(v, p):
        raise RuntimeError("gate denied")
    out = orch.possession_manager.execute_action(
        "aster", "move", {}, executor=_boom)
    assert out["ok"] is False
    assert "executor raised" in out["reason"]


def test_execute_action_verb_case_insensitive(tmp_root):
    orch = _orch(tmp_root)
    _possess(orch, "aster", allowed=("Move",))
    out = orch.possession_manager.execute_action(
        "aster", "move", {}, executor=lambda v, p: {"ok": True})
    assert out["ok"] is True


# ---------------------------------------------------------------------------
# orchestrator.possess_action: end-to-end through the single write point
# ---------------------------------------------------------------------------


def test_possess_action_records_non_object_verb_to_worldbook(tmp_root):
    orch = _orch(tmp_root)
    _possess(orch, "aster", allowed=("move", "speak", "inspect"))
    out = orch.possess_action("aster", "move", {"detail": "走向北方"})
    assert out["ok"] is True
    entries = orch.state_store.snapshot().worldbook
    assert any(e.source == "possession_action" and "move" in e.title
               for e in entries)
    assert any("走向北方" in e.content for e in entries)


def test_possess_action_disallowed_verb_does_not_write(tmp_root):
    orch = _orch(tmp_root)
    _possess(orch, "aster", allowed=("move",))
    before = len(orch.state_store.snapshot().worldbook)
    out = orch.possess_action("aster", "fireball", {"detail": "burn"})
    assert out["ok"] is False
    after = len(orch.state_store.snapshot().worldbook)
    assert before == after  # no write happened


def test_possess_action_object_target_routes_through_interact(tmp_root):
    """An allowed verb + object_id → gate-arbitrated interaction."""
    orch = _orch(tmp_root)
    _possess(orch, "aster", allowed=("push", "inspect"))
    # Create a breakable object.
    orch.upsert_object(
        SceneObjectPatch(object_id="crate", name="木箱", kind="prop",
                         location="room", state="intact",
                         source="test", material="wood", durability=2),
        approved_by="science_director")
    out = orch.possess_action("aster", "push", {"object_id": "crate"})
    assert out["ok"] is True
    # interact() was invoked (result carries actor/verb/object_id).
    res = out["result"]
    assert res["actor"] == "aster"
    assert res["verb"] == "push"
    assert res["object_id"] == "crate"


def test_possess_action_on_nonexistent_object_records_fact(tmp_root):
    """object_id given but no such object → falls back to recording a fact."""
    orch = _orch(tmp_root)
    _possess(orch, "aster", allowed=("inspect",))
    out = orch.possess_action("aster", "inspect", {"object_id": "ghost_obj"})
    assert out["ok"] is True
    entries = orch.state_store.snapshot().worldbook
    assert any(e.source == "possession_action" for e in entries)


def test_possess_action_not_possessed_rejected(tmp_root):
    orch = _orch(tmp_root)
    from theater.models import CharacterPatch
    orch.upsert_character(
        CharacterPatch(character_id="free", name="Free",
                       summary="free actor", source="test",
                       possession_limit={"max_duration": 3600,
                                         "allowed_actions": ["move"]}),
        approved_by="science_director")
    out = orch.possess_action("free", "move", {})
    assert out["ok"] is False
    assert "not possessed" in out["reason"]
