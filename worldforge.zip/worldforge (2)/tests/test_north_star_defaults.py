"""North-star alignment tests — ``worldforge "一句话"`` → Progressing World.

Pins the new defaults so a bare one-shot world description (no CLI flags)
produces an LLM-authored world + auto protagonist + auto-progressing
(WorldClock) with AgentMind + decision commitments on, and the --no-*
opt-outs still degrade each layer.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_north_star_defaults.py -q
"""
from __future__ import annotations

import argparse
import ast
import json
import sys
from pathlib import Path
from typing import Any, Dict

import pytest

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from theater.agents import (  # noqa: E402
    DeterministicModelClient,
    ModelClientError,
    OpenAICompatibleClient,
)
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.onboarding import OnboardingFlow  # noqa: E402
from theater.settings import Settings  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402
from theater.world_creation import WorldCreator, WorldProposal  # noqa: E402


# ---------------------------------------------------------------------------
# fakes
# ---------------------------------------------------------------------------

_VALID_RULE_JSON = json.dumps({
    "world_type": "economy",
    "rules": [
        {
            "rule_id": "production_each_turn",
            "kind": "dynamic",
            "trigger": "turn.tick",
            "effect": {"op": "writes", "changes": [{
                "path": "supply",
                "value": {"op": "add", "args": [
                    {"ref": "supply"}, {"ref": "production_rate"}
                ]},
            }]},
            "description": "每回合按产能增加供给",
            "priority": 30,
        },
        {
            "rule_id": "gold_conservation",
            "kind": "invariant",
            "trigger": None,
            "effect": {"op": "predicate", "expr": {"op": "eq", "args": [
                {"ref": "total_gold"}, {"ref": "gold_constant"}
            ]}},
            "description": "总货币量恒定",
            "priority": 100,
        },
    ],
    "params": {"seed": 42},
    "initial_state": {
        "supply": 100, "production_rate": 8.0,
        "total_gold": 10000, "gold_constant": 10000,
    },
})

_VALID_GAMEPLAY_JSON = json.dumps({
    "name": "bounded_choice",
    "description": "在有限回合内推进状态",
    "state_schema": {"count": 10, "turn": 0},
    "legal_actions": [{
        "id": "dec",
        "condition": {"op": "gt", "args": [{"ref": "count"}, {"const": 0}]},
    }],
    "terminal": {"op": "or", "args": [
        {"op": "le", "args": [{"ref": "count"}, {"const": 0}]},
        {"op": "ge", "args": [{"ref": "turn"}, {"const": 50}]},
    ]},
    "payoff": {"op": "ref", "path": "turn"},
    "apply": {"dec": {"writes": [
        {"path": "count", "value": {
            "op": "sub", "args": [{"ref": "count"}, {"const": 1}],
        }},
        {"path": "turn", "value": {
            "op": "add", "args": [{"ref": "turn"}, {"const": 1}],
        }},
    ]}},
})


class _FakeLLMClient:
    """Fake LLM client for the LLM onboarding path."""

    def as_text_fn(self, temperature=0.2, max_tokens=2048):
        def _fn(prompt: str) -> str:
            if "角色设计师" in prompt:
                return json.dumps([{
                    "name": "LLM主角", "personality": "坚定",
                    "appearance": "简洁装束", "sample_line": "开始吧。",
                }])
            if "GameplaySpec" in prompt or "gameplay rule JSON" in prompt:
                return _VALID_GAMEPLAY_JSON
            return _VALID_RULE_JSON
        return _fn

    def as_dict_fn(self, temperature=0.4, max_tokens=2048):
        def _fn(prompt: str) -> Dict[str, Any]:
            if "世界设计架构师" in prompt:
                return {
                    "world_type": "llm_generated_world",
                    "seed": 42,
                    "lambda": 0.5,
                    "initial_state": {"status": "new"},
                }
            return {
                "gui_spec_id": "llm_test", "world_id": "test_world",
                "layout_type": "dashboard",
                "grid": {"columns": "1fr", "areas": ["main"]},
                "widgets": [{"id": "readout", "type": "text", "area": "main",
                             "binds": {"read": "kernel:tick"}}],
            }
        return _fn

    def complete(self, prompt: str, **kwargs: Any) -> str:
        if "制片人导演" in str(kwargs.get("system") or ""):
            return json.dumps({
                "intent": "world_update",
                "brief": "世界按规则推进一拍",
                "dialogue": "",
                "actor_id": "",
                "world_title": "自主推进",
                "world_content": "状态发生了一次可追踪变化。",
                "character_summary": "",
                "warnings": [],
            })
        return json.dumps({
            "name": "LLM主角", "summary": "由 LLM 生成", "personality": "坚定",
            "appearance": "未指定", "sample_line": "开始吧。", "warnings": [],
        })


class _RecordingModelClient(DeterministicModelClient):
    def complete_character_card(self, description, model):
        return {"name": "LLM主角", "summary": "LLM生成的主角摘要",
                "personality": "坚毅", "appearance": "深色斗篷",
                "sample_line": "我来了。",
                "warnings": [], "provider_model": model}


def _build_orchestrator(root: Path, **settings_kw) -> TheaterOrchestrator:
    settings = Settings(data_dir=root, enable_live_api=False, **settings_kw)
    return TheaterOrchestrator(
        state_store=JsonStateStore(root / "state"),
        model_client=_RecordingModelClient(),
        settings=settings,
    )


@pytest.fixture
def tmp_root(tmp_path):
    return tmp_path


@pytest.fixture(autouse=True)
def configured_cli_llm(monkeypatch):
    """CLI creation tests use an explicitly configured fake LLM client."""
    import worldforge as cli
    monkeypatch.setattr(cli, "_build_llm_for_onboarding", lambda _args: _FakeLLMClient())


# ---------------------------------------------------------------------------
# 1. settings defaults
# ---------------------------------------------------------------------------


def test_settings_default_world_tick_interval_is_300():
    s = Settings()
    assert s.world_tick_interval == 300


def test_settings_default_agent_mind_and_commitments_on():
    s = Settings()
    assert s.enable_agent_mind is True
    assert s.enable_commitments is True


def test_settings_env_can_override_defaults(tmp_root, monkeypatch):
    for k in ("AI_THEATER_API_KEY", "AI_THEATER_BASE_URL", "THEATER_LLM_BASE_URL"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("AI_THEATER_WORLD_TICK_INTERVAL", "0")
    monkeypatch.setenv("AI_THEATER_ENABLE_AGENT_MIND", "false")
    monkeypatch.setenv("AI_THEATER_ENABLE_COMMITMENTS", "false")
    monkeypatch.setenv("AI_THEATER_DATA_DIR", str(tmp_root))
    s = Settings.from_env(cwd=tmp_root)
    assert s.world_tick_interval == 0
    assert s.enable_agent_mind is False
    assert s.enable_commitments is False


def test_settings_from_env_defaults_match_dataclass_defaults(tmp_root, monkeypatch):
    """from_env with no overrides yields the same north-star defaults."""
    for k in ("AI_THEATER_API_KEY", "AI_THEATER_BASE_URL", "THEATER_LLM_BASE_URL"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("AI_THEATER_DATA_DIR", str(tmp_root))
    s = Settings.from_env(cwd=tmp_root)
    assert s.world_tick_interval == 300
    assert s.enable_agent_mind is True
    assert s.enable_commitments is True


# ---------------------------------------------------------------------------
# 2. onboarding default protagonist
# ---------------------------------------------------------------------------


def test_onboarding_without_llm_rejects_world_creation(tmp_root):
    """A world is not created from a non-LLM fallback."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("三体世界", use_llm=False)  # characters defaults to None
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_onboarding_without_llm_does_not_install_character_fallback(tmp_root):
    """characters=[] cannot make an unconfigured LLM creation path succeed."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("三体世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_onboarding_use_llm_default_true_with_fake_client(tmp_root):
    """use_llm defaults True; with a fake client the LLM path fires."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run("一个供需经济世界")  # use_llm defaults True
    rules = result["stages"]["rules"]
    assert rules["source"] == "llm"
    assert rules["compiled"] is True
    # default protagonist was created
    assert len(result["stages"]["characters"]) == 1


# ---------------------------------------------------------------------------
# 3. CLI default no-flag path = progressing world
# ---------------------------------------------------------------------------


def _ns(**kw):
    """Build an argparse.Namespace matching the CLI's north-star flags."""
    base = dict(no_llm=False, no_characters=False, no_agent_mind=False,
                no_commitments=False, no_auto_advance=False,
                characters=None, gameplay=None)
    base.update(kw)
    return argparse.Namespace(**base)


def test_cli_default_progressing_world_runs(tmp_root, monkeypatch):
    """``worldforge "desc"`` (no flags) runs onboarding + one autonomous beat
    + WorldClock, returns 0, and prints the progressing-world message."""
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    rc = cli.cmd_progressing_world("测试世界", _ns())
    assert rc == 0
    # world state file created
    assert (tmp_root / "state_测试世界.json").exists()


def test_cli_default_path_creates_protagonist(tmp_root, monkeypatch):
    """The default path auto-creates one protagonist (north-star)."""
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    cli.cmd_progressing_world("测试世界", _ns())
    # Reload the store to confirm a character was persisted.
    state_file = next(
        path for path in tmp_root.glob("state_*.json")
        if path.stem != "state_测试世界"
    )
    world_id = state_file.stem.removeprefix("state_")
    store = JsonStateStore(tmp_root, world_id=world_id)
    snap = store.snapshot()
    assert len(snap.characters) >= 1


def test_cli_default_path_advances_one_beat(tmp_root, monkeypatch):
    """The default path runs one autonomous world_tick immediately."""
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    cli.cmd_progressing_world("测试世界", _ns())
    # The beat wrote a worldbook entry via dispatch (idle_advance origin).
    state_file = next(
        path for path in tmp_root.glob("state_*.json")
        if path.stem != "state_测试世界"
    )
    world_id = state_file.stem.removeprefix("state_")
    store = JsonStateStore(tmp_root, world_id=world_id)
    entries = store.snapshot().worldbook
    assert len(entries) >= 1


def test_cli_no_agent_mind_disables_agent_mind(tmp_root, monkeypatch):
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    # Patch cmd_progressing_world's orchestrator builder to capture settings.
    captured = {}

    orig_build = cli._build_progressing_orchestrator

    def _capture(wid, args):
        orch = orig_build(wid, args)
        captured["enable_agent_mind"] = orch.settings.enable_agent_mind
        return orch

    monkeypatch.setattr(cli, "_build_progressing_orchestrator", _capture)
    cli.cmd_progressing_world("测试世界", _ns(no_agent_mind=True))
    assert captured["enable_agent_mind"] is False


def test_cli_no_commitments_disables_commitments(tmp_root, monkeypatch):
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    captured = {}
    orig_build = cli._build_progressing_orchestrator

    def _capture(wid, args):
        orch = orig_build(wid, args)
        captured["enable_commitments"] = orch.settings.enable_commitments
        return orch

    monkeypatch.setattr(cli, "_build_progressing_orchestrator", _capture)
    cli.cmd_progressing_world("测试世界", _ns(no_commitments=True))
    assert captured["enable_commitments"] is False


def test_cli_no_auto_advance_sets_zero_interval(tmp_root, monkeypatch):
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    captured = {}
    orig_build = cli._build_progressing_orchestrator

    def _capture(wid, args):
        orch = orig_build(wid, args)
        captured["interval"] = orch.settings.world_tick_interval
        return orch

    monkeypatch.setattr(cli, "_build_progressing_orchestrator", _capture)
    cli.cmd_progressing_world("测试世界", _ns(no_auto_advance=True))
    assert captured["interval"] == 0


def test_cli_default_path_agent_mind_and_commitments_on_by_default(tmp_root, monkeypatch):
    """No opt-out flags → AgentMind + commitments + interval=300 all on."""
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    captured = {}
    orig_build = cli._build_progressing_orchestrator

    def _capture(wid, args):
        orch = orig_build(wid, args)
        captured["enable_agent_mind"] = orch.settings.enable_agent_mind
        captured["enable_commitments"] = orch.settings.enable_commitments
        captured["interval"] = orch.settings.world_tick_interval
        return orch

    monkeypatch.setattr(cli, "_build_progressing_orchestrator", _capture)
    cli.cmd_progressing_world("测试世界", _ns())
    assert captured["enable_agent_mind"] is True
    assert captured["enable_commitments"] is True
    assert captured["interval"] == 300


def test_cli_create_preview_requires_configured_llm_onboarding(tmp_root, monkeypatch, capsys):
    """The legacy non-LLM creation command is deliberately disabled."""
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    rc = cli.cmd_create_or_preview("预览世界")
    assert rc == 2
    assert not (tmp_root / "state_预览世界.json").exists()
    assert "requires a configured LLM" in capsys.readouterr().err


def test_cli_generic_orchestrators_do_not_patch_three_body_narration(tmp_root, monkeypatch):
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)

    generic = cli._build_orchestrator("neutral")
    progressing = cli._build_progressing_orchestrator("progressing", _ns())

    assert "_narrate_three_body" not in generic.__dict__
    assert "_narrate_three_body" not in progressing.__dict__


def test_cli_generic_orchestrators_use_strict_runtime_llm_clients(
    tmp_root, monkeypatch,
):
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    for name in (
        "AI_THEATER_API_KEY",
        "AI_THEATER_BASE_URL",
        "AI_THEATER_ENABLE_LIVE_API",
    ):
        monkeypatch.delenv(name, raising=False)

    generic = cli._build_orchestrator("neutral")
    progressing = cli._build_progressing_orchestrator("progressing", _ns())

    assert isinstance(generic.model_client, OpenAICompatibleClient)
    assert isinstance(progressing.model_client, OpenAICompatibleClient)
    assert not isinstance(generic.model_client, DeterministicModelClient)
    with pytest.raises(ModelClientError, match="not enabled"):
        generic.model_client.complete_json(
            "producer", "推进一拍", generic.settings.model_deep,
        )


def test_cli_three_body_kernel_import_is_not_top_level():
    import worldforge as cli

    tree = ast.parse(Path(cli.__file__).read_text(encoding="utf-8"))
    assert not any(
        isinstance(node, ast.ImportFrom)
        and node.module == "theater.kernels.three_body"
        for node in tree.body
    )


def test_cli_empty_saves_hint_is_world_agnostic(tmp_root, monkeypatch, capsys):
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)

    assert cli.cmd_saves() == 0

    assert "三体" not in capsys.readouterr().out


def test_cli_gui_without_llm_is_rejected(tmp_root, monkeypatch):
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    rc = cli.cmd_gui("任意描述", use_llm=False)
    assert rc == 2
    assert not (tmp_root / "gui_任意描述.css").exists()


def test_cli_generic_bake_requires_an_explicit_adapter(tmp_root, monkeypatch):
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    WorldCreator.create(WorldProposal(
        world_id="中性世界", world_params={"enabled_kernels": []},
    ), tmp_root)

    assert cli.cmd_bake("中性世界") == 2


def test_cli_world_creation_rejects_a_missing_llm(tmp_root, monkeypatch, capsys):
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)
    monkeypatch.setattr(cli, "_build_llm_for_onboarding", lambda _args: (_ for _ in ()).throw(
        RuntimeError("LLM is required to create a world. Configure it in the WorldForge launcher."),
    ))

    assert cli.cmd_progressing_world("测试世界", _ns(no_llm=False)) == 2
    assert not (tmp_root / "state_测试世界.json").exists()
    assert "LLM is required" in capsys.readouterr().err


def test_cli_cognitive_model_requires_explicit_llm():
    import worldforge as cli
    assert cli.cmd_generate_cognitive_model(
        "任意描述", role="auto", use_llm=False,
    ) == 2


def test_cli_parser_has_opt_out_flags():
    """The parser exposes --no-agent-mind / --no-commitments / --no-auto-advance."""
    import worldforge as cli
    parser = cli.build_parser()
    args = parser.parse_args(["x", "--no-agent-mind", "--no-commitments", "--no-auto-advance"])
    assert args.no_agent_mind is True
    assert args.no_commitments is True
    assert args.no_auto_advance is True


def test_cli_parser_defaults_opt_outs_false():
    import worldforge as cli
    parser = cli.build_parser()
    args = parser.parse_args(["x"])
    assert args.no_agent_mind is False
    assert args.no_commitments is False
    assert args.no_auto_advance is False
    assert args.no_llm is False  # LLM on by default


# ---------------------------------------------------------------------------
# 4. end-to-end with a fake LLM (use_llm=True path)
# ---------------------------------------------------------------------------


def test_e2e_default_path_with_fake_llm(tmp_root, monkeypatch):
    """End-to-end: default no-flag path with a fake LLM client produces an
    LLM-authored world + protagonist + one progressing beat."""
    import worldforge as cli
    monkeypatch.setattr(cli, "STATE_ROOT", tmp_root)

    # Inject a fake LLM client into the OnboardingFlow by patching _run_onboarding
    # to pass our fake client through the flow.
    fake = _FakeLLMClient()
    orig_run = cli._run_onboarding

    def _patched(description, args, orch):
        orch.model_client = cli._LLMRuntimeModelClient(fake)
        flow = OnboardingFlow(orchestrator=orch, state_root=cli.STATE_ROOT,
                              llm_client=fake)
        characters = [] if args.no_characters else (
            list(args.characters) if args.characters else None)
        use_llm = not args.no_llm
        result = flow.run(description, characters=characters, use_llm=use_llm,
                          mode="auto", gameplay=None)
        result["llm_active"] = True
        return result

    monkeypatch.setattr(cli, "_run_onboarding", _patched)
    # use_llm path (no --no-llm)
    ns = _ns(no_llm=False)
    rc = cli.cmd_progressing_world("一个供需经济世界", ns)
    assert rc == 0
    # The LLM-authored economy kernel was registered + a beat ran.
    state_file = next(
        path for path in tmp_root.glob("state_*.json")
        if path.stem != "state_一个供需经济世界"
    )
    world_id = state_file.stem.removeprefix("state_")
    store = JsonStateStore(tmp_root, world_id=world_id)
    snap = store.snapshot()
    # protagonist created
    assert len(snap.characters) >= 1
    # worldbook has content (autonomous beat fired)
    assert len(snap.worldbook) >= 1
