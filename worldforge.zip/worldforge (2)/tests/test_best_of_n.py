"""Unit tests for backend/theater/best_of_n.py.

Pure-Python, no LLM calls — all clients are mocks. Verifies:
  * generate() returns N (de-duplicated) candidates
  * score() ranks a "good" candidate above a "bad" one
  * select() picks the best score and returns ranked list
  * QualityRouter maps every commitment state to the right path
  * Deterministic: same inputs -> same outputs (mock LLM)
"""

import json
import unittest
from typing import Any, List

from theater.best_of_n import (
    BestOfN,
    QualityRouter,
    ScoreBreakdown,
    ScoreResult,
    ScoringCriteria,
)


# ---------------------------------------------------------------------------
# Mock LLM clients
# ---------------------------------------------------------------------------


class _CycleMockClient:
    """Returns one of ``_outputs`` per call (cycled). Records temperatures."""

    def __init__(self, outputs: List[str]) -> None:
        self._outputs = list(outputs)
        self._idx = 0
        self.calls: List[dict] = []

    def generate(self, prompt: str, **kwargs: Any) -> str:
        self.calls.append({"prompt": prompt, **kwargs})
        item = self._outputs[self._idx % len(self._outputs)]
        self._idx += 1
        return item


class _BatchMockClient:
    """Supports a single ``generate(prompt, n=...)`` call returning a list."""

    def __init__(self, batched: List[str]) -> None:
        self._batched = list(batched)
        self.calls: List[dict] = []

    def generate(self, prompt: str, **kwargs: Any) -> List[str]:
        self.calls.append({"prompt": prompt, **kwargs})
        return list(self._batched)


class _CallableMockClient:
    """Bare callable client (no .generate)."""

    def __init__(self, outputs: List[str]) -> None:
        self._outputs = list(outputs)
        self._idx = 0
        self.calls: List[tuple[str, float]] = []

    def __call__(self, prompt: str, **kwargs: Any) -> str:
        # 'temperature' is required by our client_call wrapper — accept both
        # keyword and positional for robustness.
        temp = kwargs.get("temperature", 0.0)
        self.calls.append((prompt, temp))
        item = self._outputs[self._idx % len(self._outputs)]
        self._idx += 1
        return item


# ---------------------------------------------------------------------------
# Sampling tests
# ---------------------------------------------------------------------------


class BestOfNGenerateTests(unittest.TestCase):
    def test_generate_returns_n_distinct_candidates(self):
        outputs = [f"candidate-{i} different content" for i in range(8)]
        client = _CycleMockClient(outputs)
        bon = BestOfN()
        cands = bon.generate("any prompt", client, n=8, temperature=0.9)
        self.assertEqual(len(cands), 8)
        self.assertEqual(len(set(cands)), 8)

    def test_generate_dedupes_repeats(self):
        client = _CycleMockClient(["same", "same", "other", "same"])
        bon = BestOfN()
        cands = bon.generate("p", client, n=4, temperature=1.0)
        self.assertEqual(cands, ["same", "other"])

    def test_generate_dispatches_temperature(self):
        client = _CycleMockClient(["x"] * 3)
        bon = BestOfN()
        bon.generate("p", client, n=3, temperature=0.42)
        self.assertEqual(client.calls[0]["temperature"], 0.42)

    def test_generate_uses_batched_path(self):
        outputs = [f"b-{i}" for i in range(4)]
        client = _BatchMockClient(outputs)
        bon = BestOfN()
        cands = bon.generate("p", client, n=4, temperature=0.7)
        self.assertEqual(cands, outputs)
        # Exactly one call (batched), with n=4 plumbed through.
        self.assertEqual(len(client.calls), 1)
        self.assertEqual(client.calls[0]["n"], 4)

    def test_generate_falls_back_to_per_sample_calls(self):
        # A client whose .generate() doesn't accept `n=` -> falls back.
        client = _CycleMockClient(["a", "b", "c", "d"])
        bon = BestOfN()
        cands = bon.generate("p", client, n=4, temperature=0.5)
        self.assertEqual(len(cands), 4)
        # Calls > 1 because batched path type-errored.
        self.assertGreater(len(client.calls), 1)

    def test_generate_supports_callable_client(self):
        client = _CallableMockClient(["z1", "z2", "z3"])
        bon = BestOfN()
        cands = bon.generate("p", client, n=3, temperature=0.2)
        self.assertEqual(cands, ["z1", "z2", "z3"])

    def test_generate_handles_n_zero(self):
        bon = BestOfN()
        self.assertEqual(bon.generate("p", _CycleMockClient([]), n=0), [])


# ---------------------------------------------------------------------------
# Scoring tests
# ---------------------------------------------------------------------------


class BestOfNScoreTests(unittest.TestCase):
    def setUp(self):
        self.bon = BestOfN()
        self.prompt = (
            "Find three creative business names for a cafe called Luna "
            "with cozy atmosphere"
        )
        self.crit = ScoringCriteria.from_prompt(self.prompt)

    def test_good_candidate_beats_bad_candidate(self):
        # Length ok, repeats prompt keywords, valid format.
        good = (
            "Luna Cafe: a cozy atmosphere for creatives. The name evokes "
            "moonlit calm, three creative words per business customer. "
            "Friendly and inviting."
        )
        # Too short, no keyword overlap, possibly invalid.
        bad = "nope"
        good_score = self.bon.score(good, self.prompt, self.crit)
        bad_score = self.bon.score(bad, self.prompt, self.crit)
        self.assertGreater(good_score, bad_score)

    def test_score_components_in_unit_interval(self):
        cands = ["x", "y z " * 100, self.prompt, "{} invalid json {"]
        for c in cands:
            bd = self.bon.score_breakdown(c, self.prompt, self.crit)
            for field in ("length", "keyword", "format", "diversity", "no_duplicate"):
                v = getattr(bd, field)
                self.assertGreaterEqual(v, 0.0)
                self.assertLessEqual(v, 1.0)

    def test_format_json_credit(self):
        # With non-trivial other components, valid JSON should outscore invalid.
        crit = ScoringCriteria(
            required_keywords=("alpha",),
            want_json=True,
        )
        ok = '{"alpha": 42}'
        not_json = "totally free text"
        self.assertGreater(self.bon.score(ok, "alpha", crit),
                           self.bon.score(not_json, "alpha", crit))
        # Underlying components
        self.assertEqual(self.bon._format_score(ok, True), 1.0)
        self.assertEqual(self.bon._format_score(not_json, True), 0.0)

    def test_format_json_braces_no_valid(self):
        crit = ScoringCriteria(want_json=True)
        # Looks JSON-ish but unparseable -> mid credit (0.3).
        bd = self.bon.score_breakdown("{not valid json}", "", crit)
        self.assertEqual(bd.format, 0.3)

    def test_diversity_score_drops_for_clones(self):
        crit = ScoringCriteria()
        same = "the quick brown fox jumps over the lazy dog"
        a = self.bon._diversity_score(same, [same])
        b = self.bon._diversity_score(same, ["completely different content here"])
        self.assertLess(a, b)

    def test_dup_score_zero_for_exact_dup(self):
        crit = ScoringCriteria()
        s = "duplicate content"
        self.assertEqual(self.bon._dup_score(s, [s]), 0.0)

    def test_keyword_score_proportional(self):
        crit = ScoringCriteria(required_keywords=("moonlit", "cozy", "quantum"))
        full = "moonlit cozy with a twist of quantum"
        partial = "moonlit and only moonlit"
        none = "no relevant words"
        s_full = self.bon.score(full, "", crit)
        s_partial = self.bon.score(partial, "", crit)
        s_none = self.bon.score(none, "", crit)
        self.assertGreater(s_full, s_partial)
        self.assertGreater(s_partial, s_none)

    def test_length_score_bell_curve(self):
        # Ideal length is midpoint of [lo, hi] => 1.0; too short / too long penalised.
        crit = ScoringCriteria(length_lo=10, length_hi=100)
        self.assertAlmostEqual(
            self.bon._length_score("a" * 55, crit.length_lo, crit.length_hi),
            1.0,
        )
        short = self.bon._length_score("hi", crit.length_lo, crit.length_hi)
        ideal = self.bon._length_score("a" * 55, crit.length_lo, crit.length_hi)
        long = self.bon._length_score("a" * 200, crit.length_lo, crit.length_hi)
        self.assertGreater(ideal, short)
        self.assertGreater(ideal, long)


# ---------------------------------------------------------------------------
# Selection tests
# ---------------------------------------------------------------------------


class BestOfNSelectTests(unittest.TestCase):
    def test_select_picks_best_score(self):
        cands = [
            "irrelevant one-liner",
            "The cozy cafe Luna invites creative patrons to enjoy the moonlit calm.",  # noqa: E501
            "another wordy entry here to fill the quota nicely thanks",
        ]
        prompt = "creative business names for Luna cafe cozy moonlit"
        crit = ScoringCriteria.from_prompt(prompt)
        bon = BestOfN()
        best, ranked = bon.select(cands, prompt, crit)
        self.assertIn("Luna", best)
        # Returns ranked list, sorted by score desc.
        scores = [r.score for r in ranked]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_select_empty(self):
        bon = BestOfN()
        best, ranked = bon.select([], "p", ScoringCriteria())
        self.assertEqual(best, "")
        self.assertEqual(ranked, [])

    def test_generate_best_one_shot(self):
        outputs = [f"answer variant {i}" for i in range(4)]
        client = _CycleMockClient(outputs)
        bon = BestOfN()
        best = bon.generate_best(
            "creative business naming prompt",
            client,
            n=4,
            criteria=ScoringCriteria.from_prompt("creative business naming prompt"),
            temperature=0.7,
        )
        self.assertIn(best, outputs)


# ---------------------------------------------------------------------------
# Determinism tests
# ---------------------------------------------------------------------------


class BestOfNDeterminismTests(unittest.TestCase):
    def test_same_inputs_same_outputs(self):
        outputs = ["alpha", "beta", "gamma"]
        c1 = _CycleMockClient(list(outputs))
        c2 = _CycleMockClient(list(outputs))

        bon1 = BestOfN()
        bon2 = BestOfN()

        r1 = bon1.generate_best(
            "select alpha",
            c1,
            n=3,
            criteria=ScoringCriteria(required_keywords=("alpha",)),
        )
        r2 = bon2.generate_best(
            "select alpha",
            c2,
            n=3,
            criteria=ScoringCriteria(required_keywords=("alpha",)),
        )
        self.assertEqual(r1, r2)

    def test_scorer_pure(self):
        bon = BestOfN()
        crit = ScoringCriteria(
            required_keywords=("x", "y"),
            want_json=True,
            length_lo=5,
            length_hi=50,
        )
        # Calling twice must return bit-identical floats.
        text = "x and y with reasonable length"
        a = bon.score(text, "x y", crit)
        b = bon.score(text, "x y", crit)
        self.assertEqual(a, b)


# ---------------------------------------------------------------------------
# QualityRouter tests
# ---------------------------------------------------------------------------


class QualityRouterTests(unittest.TestCase):
    def setUp(self):
        self.router = QualityRouter()

    def test_route_speculative(self):
        self.assertEqual(self.router.route("speculative"), "single_greedy_short")

    def test_route_committing(self):
        self.assertEqual(self.router.route("committing"), "best_of_n_rerank")

    def test_route_committed(self):
        self.assertEqual(self.router.route("committed"), "max_quality_validate")

    def test_route_reflex(self):
        self.assertEqual(self.router.route("reflex"), "no_llm")

    def test_route_unknown_state_raises(self):
        with self.assertRaises(ValueError):
            self.router.route("nonsense")

    def test_expected_n_ordering(self):
        # commitment increases -> cost (and width) increases; reflex = 0.
        self.assertLess(
            self.router.expected_n("speculative"),
            self.router.expected_n("committing"),
        )
        self.assertLess(
            self.router.expected_n("committing"),
            self.router.expected_n("committed"),
        )
        self.assertEqual(self.router.expected_n("reflex"), 0)

    def test_all_valid_states_routable(self):
        for state in self.router.valid_states:
            path = self.router.route(state)
            self.assertIsInstance(path, str)
            self.assertGreater(len(path), 0)


# ---------------------------------------------------------------------------
# Sanity tests for dataclasses
# ---------------------------------------------------------------------------


class DataclassTests(unittest.TestCase):
    def test_score_result_as_dict(self):
        bd = ScoreBreakdown(1, 1, 1, 1, 1)
        r = ScoreResult(text="x", score=5.0, breakdown=bd)
        d = r.as_dict()
        self.assertEqual(d["text"], "x")
        self.assertEqual(d["score"], 5.0)
        self.assertEqual(d["breakdown"]["length"], 1)

    def test_scoring_criteria_from_prompt(self):
        crit = ScoringCriteria.from_prompt("The moonlit cozy cafe finder task")
        self.assertGreater(len(crit.required_keywords), 0)


if __name__ == "__main__":
    unittest.main()
