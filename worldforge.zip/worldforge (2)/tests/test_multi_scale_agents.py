"""Tests for the generic multi-scale framework + economy / political instances.

Covers:

- Generic ``IndividualAgent`` / ``OrganizationAgent`` / ``CollectiveAgent``
  behaviour (threshold proposer, trust gate, action-vector mapping,
  reflux, determinism).
- Economy instance: merchant → guild → market — aggregation, collective
  behaviour, distrust → crash.
- Political instance: noble → faction → kingdom — reproduces the §5
  "leader distrusts the informed individual → information does not
  propagate → status quo under imminent threat → disaster" dynamic in a
  non-three-body vocabulary.
- Public world-agnostic framework surface remains importable.

No LLM, no unseeded randomness (spec §8.2 red line).  The kernel is the
only source of ground truth.
"""

from __future__ import annotations

import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.character_graph import CharacterGraph, Organization  # noqa: E402
from theater.cognitive_model import Belief  # noqa: E402
from theater.multi_scale_agents import (  # noqa: E402
    CollectiveAgent,
    IndividualAgent,
    MultiScaleCausalTrace,
    MultiScaleSim,
    MultiScaleSimConfig,
    OrganizationAgent,
    proposal_from_thresholds,
)
from theater.multi_scale_worlds import (  # noqa: E402
    FactionAgent,
    GuildAgent,
    InvasionRiskFilter,
    KingdomCollective,
    KingdomKernel,
    MarketCollective,
    MarketKernel,
    MerchantAgent,
    NobleAgent,
    PriceTrendFilter,
    build_economy_sim,
    build_political_sim,
    make_sim_agent,
)
from theater.sim_agent import CharacterDefinition, SimAgent  # noqa: E402


# ===========================================================================
# Generic framework — IndividualAgent
# ===========================================================================


def _ind(personality="理性", topic="risk", belief=None, insight=0.5, seed=None):
    char = CharacterDefinition(character_id="a", name="a", personality=personality)
    sim = SimAgent(char)
    if belief is not None:
        sim.mind_state.beliefs[topic] = Belief(
            predicted=belief, confidence=0.5, model_error=False,
            committed_values={})
    return IndividualAgent(
        sim, capability={"insight": insight}, agent_id="a",
        belief_topic=topic,
        propose_fn=proposal_from_thresholds(0.9, 0.66, "high", "mid", "low"),
        seed=seed,
    )


class _ConstFilter:
    """Returns a fixed observation dict (test stand-in for a world filter)."""

    def __init__(self, value=0.8, model_error=False):
        self._v = value
        self._me = model_error

    def observe(self, true_state, binding):
        return {"risk": self._v, "model_error": self._me}


def test_individual_threshold_proposer():
    ind = _ind(belief=0.2, topic="risk")
    assert ind.propose() == "low"
    ind.sim.mind_state.beliefs["risk"] = Belief(predicted=0.7, confidence=0.5)
    assert ind.propose() == "mid"
    ind.sim.mind_state.beliefs["risk"] = Belief(predicted=0.95, confidence=0.5)
    assert ind.propose() == "high"


def test_individual_observe_uses_filter():
    ind = _ind(topic="risk")
    f = _ConstFilter(value=0.9, model_error=False)
    obs = ind.observe(f, {"t": 0.0})
    assert obs["risk"] == 0.9


def test_individual_update_belief_rational_integrates():
    ind = _ind(personality="理性冷静", belief=0.2, topic="risk")
    posterior, trace = ind.update_belief(
        {"risk": 0.9, "model_error": False},
        evidence_field="risk",
    )
    assert trace.strategy == "rational"
    assert posterior.predicted > 0.2


def test_individual_update_belief_dogmatic_backfire():
    ind = _ind(personality="固执顽固", belief=0.2, topic="risk")
    posterior, trace = ind.update_belief(
        {"risk": 0.9, "model_error": False}, evidence_field="risk",
    )
    assert trace.strategy == "dogmatic"
    assert trace.accepted is False
    assert posterior.predicted < 0.2  # backfire


def test_individual_misperception_tagged_perception_error():
    ind = _ind(personality="理性", belief=0.5, topic="risk")
    _post, trace = ind.update_belief(
        {"risk": 0.1, "model_error": True}, evidence_field="risk",
    )
    assert trace.error_source == "perception_error"


def test_individual_belief_value_default():
    ind = _ind(topic="risk")
    assert ind.belief_value == 0.5  # unset → neutral


# ===========================================================================
# Generic framework — OrganizationAgent
# ===========================================================================


def _org_graph(members, leader_id="leader", trust=0.8):
    g = CharacterGraph()
    org = Organization(
        org_id="o", members=list(members) + [leader_id],
        roles={leader_id: "leader"}, decision_rule="vote",
        dictator_id=leader_id,
    )
    for m in members:
        g.add_relationship(leader_id, m, trust=trust)
        g.add_relationship(m, leader_id, trust=0.8)
    return g, org


def test_org_default_plan_when_no_trusted_proposal():
    g, org = _org_graph(["s1"], trust=-0.5)
    org.decision_rule = "dictator"
    body = OrganizationAgent(org, g, trust_threshold=0.0, default_plan="status_quo")
    decision, votes, received = body.decide({"s1": "high"})
    assert "s1" not in received["leader"]
    assert votes["leader"] == "status_quo"
    assert decision == "status_quo"


def test_org_trust_lets_proposal_through():
    g, org = _org_graph(["s1"], trust=0.8)
    org.decision_rule = "dictator"
    body = OrganizationAgent(org, g, trust_threshold=0.0, default_plan="status_quo")
    decision, votes, received = body.decide({"s1": "high"})
    assert "s1" in received["leader"]
    assert votes["leader"] == "high"
    assert decision == "high"


def test_org_vote_majority():
    g, org = _org_graph(["s1", "s2", "s3"])
    org.decision_rule = "vote"
    body = OrganizationAgent(org, g, default_plan="low")
    decision, _v, _r = body.decide({"s1": "mid", "s2": "mid", "s3": "low"})
    assert decision == "mid"


def test_org_consensus_blocks_on_dissent():
    g, org = _org_graph(["s1", "s2"])
    org.decision_rule = "consensus"
    body = OrganizationAgent(org, g, default_plan="low")
    decision, _v, _r = body.decide({"s1": "mid", "s2": "low"})
    assert decision is None


# ===========================================================================
# Generic framework — CollectiveAgent
# ===========================================================================


class _StubKernel:
    def __init__(self, kind="destroyed_x"):
        self._kind = kind
        self.calls = []

    def outcome(self, t, vector=None, **ctx):
        self.calls.append({"t": t, "vector": vector, "ctx": ctx})
        kind = self._kind

        class O:
            def __init__(self, k):
                self.kind = k

            def as_dict(self):
                return {"kind": self.kind}
        return O(kind)


def test_collective_maps_plan_to_action_vector():
    k = _StubKernel(kind="survived")
    coll = CollectiveAgent(
        k, plan_to_action_vector={"defend": {"defense": 1.0}},
        outcome_fn=lambda kern, v, t, **c: kern.outcome(t, v, **c),
    )
    outcome, vector = coll.decide_outcome("defend", 5.0)
    assert vector == {"defense": 1.0}
    assert outcome.kind == "survived"


def test_collective_none_decision_yields_none_vector():
    k = _StubKernel()
    coll = CollectiveAgent(
        k, plan_to_action_vector={"defend": {"defense": 1.0}},
        outcome_fn=lambda kern, v, t, **c: kern.outcome(t, v, **c),
    )
    _outcome, vector = coll.decide_outcome(None, 5.0)
    assert vector is None


def test_collective_outcome_verdict_destroyed():
    k = _StubKernel(kind="destroyed_chaos")
    coll = CollectiveAgent(
        k, plan_to_action_vector={"x": {}},
        outcome_fn=lambda kern, v, t, **c: kern.outcome(t, v, **c),
    )
    outcome, _v = coll.decide_outcome("x", 0.0)
    kind, destroyed = coll.outcome_verdict(outcome)
    assert kind == "destroyed_chaos"
    assert destroyed is True


def test_collective_outcome_verdict_survived_not_destroyed():
    k = _StubKernel(kind="survived")
    coll = CollectiveAgent(
        k, plan_to_action_vector={"x": {}},
        outcome_fn=lambda kern, v, t, **c: kern.outcome(t, v, **c),
    )
    outcome, _v = coll.decide_outcome("x", 0.0)
    _kind, destroyed = coll.outcome_verdict(outcome)
    assert destroyed is False


# ===========================================================================
# Generic framework — MultiScaleSim end-to-end + determinism
# ===========================================================================


def _build_generic_sim(seed=42, trust=0.8, leader_plan="low"):
    ind = _ind(personality="理性冷静", belief=0.5, topic="risk", seed=seed)
    g, org = _org_graph(["a"], trust=trust)
    org.decision_rule = "dictator"
    body = OrganizationAgent(org, g, trust_threshold=0.0, default_plan=leader_plan)
    kernel = _StubKernel(kind="destroyed_chaos")
    coll = CollectiveAgent(
        kernel, plan_to_action_vector={"high": {"x": 1.0}, "mid": {"x": 0.5},
                                        "low": {"x": 0.0}},
        outcome_fn=lambda kern, v, t, **c: kern.outcome(t, v, **c),
    )

    def true_state(kern, t):
        return {"t": t}

    config = MultiScaleSimConfig(true_state_fn=true_state,
                                 observation_filter=_ConstFilter(0.95, False))
    return MultiScaleSim(
        kernel=kernel, individuals={"a": ind}, organization=body,
        collective=coll, config=config, seed=seed,
        observation_filter=config.observation_filter,
        evidence_field="risk", model_error_field="model_error",
    )


def test_multiscale_sim_full_chain_structure():
    sim = _build_generic_sim()
    tr = sim.tick(0.0)
    assert "a" in tr.scientist_observations
    assert "a" in tr.belief_updates
    assert "a" in tr.proposals
    assert tr.org_decision is not None
    assert tr.decision_vector is not None
    assert tr.outcome_kind == "destroyed_chaos"
    assert tr.civ_destroyed is True
    assert "a" in tr.post_outcome_belief_updates
    assert tr.post_outcome_belief_updates["a"]["evidence"] == 1.0


def test_multiscale_sim_determinism_same_seed():
    def run():
        sim = _build_generic_sim(seed=7)
        return sim.tick(0.0).as_dict()
    assert run() == run()


def test_multiscale_sim_distrust_blocks_proposal():
    sim = _build_generic_sim(trust=-0.5, leader_plan="low")
    tr = sim.tick(0.0)
    # leader distrusts 'a' → proposal not received → leader votes 'low'
    assert "a" not in tr.info_propagation["leader"]
    assert tr.member_votes["leader"] == "low"
    assert tr.org_decision == "low"


def test_multiscale_causal_trace_roundtrip():
    sim = _build_generic_sim()
    tr = sim.tick(1.0)
    d = tr.as_dict()
    for key in ("t", "civ_tech_level", "scientist_observations",
                "belief_updates", "proposals", "member_votes",
                "info_propagation", "org_decision", "decision_vector",
                "outcome_kind", "outcome", "civ_destroyed",
                "post_outcome_belief_updates"):
        assert key in d


# ===========================================================================
# Economy instance — merchant → guild → market
# ===========================================================================


def _economy_sim(trust=0.8, insight=0.9, seed=1, true_trend=1.0):
    k = MarketKernel(base_price=100.0, true_trend=true_trend)
    f = PriceTrendFilter()
    m = MerchantAgent(make_sim_agent("m1", "理性冷静"), insight=insight,
                      agent_id="m1", seed=seed)
    g = CharacterGraph()
    org = Organization(org_id="guild", members=["m1", "master"],
                       decision_rule="dictator", dictator_id="master")
    g.add_relationship("master", "m1", trust=trust)
    guild = GuildAgent(org, g, trust_threshold=0.0)
    market = MarketCollective(k)
    return build_economy_sim(k, {"m1": m}, guild, market, f, seed=seed), k


def test_economy_high_insight_sees_trend():
    sim, _k = _economy_sim(insight=0.9)
    tr = sim.tick(0.0, civ_tech_level=0.0)
    obs = tr.scientist_observations["m1"]
    assert obs["model_error"] is False
    assert obs["trend_prob"] > 0.5


def test_economy_low_insight_misperceives():
    sim, _k = _economy_sim(insight=0.1)
    tr = sim.tick(0.0, civ_tech_level=0.0)
    obs = tr.scientist_observations["m1"]
    assert obs["model_error"] is True
    assert obs["trend_prob"] < 0.5


def test_economy_guild_aggregates_to_market_vector():
    sim, _k = _economy_sim(trust=0.8)
    tr = sim.tick(0.0, civ_tech_level=0.0)
    # decision_vector is one of the market vectors
    assert tr.decision_vector in ({"buy": 1.0, "hold": 0.0, "sell": 0.0},
                                  {"buy": 0.0, "hold": 1.0, "sell": 0.0},
                                  {"buy": 0.0, "hold": 0.0, "sell": 1.0})


def test_economy_distrust_leads_to_hold_status_quo():
    sim, _k = _economy_sim(trust=-0.5)
    tr = sim.tick(0.0, civ_tech_level=0.0)
    # master distrusts m1 → proposal blocked → master votes hold
    assert "m1" not in tr.info_propagation["master"]
    assert tr.member_votes["master"] == "hold"
    assert tr.org_decision == "hold"


def test_economy_reflux_evidence_on_no_crash():
    sim, _k = _economy_sim()
    tr = sim.tick(0.0, civ_tech_level=0.0)
    # a single aligned tick should not crash → reflux evidence 0.0
    assert tr.post_outcome_belief_updates["m1"]["evidence"] == 0.0


def test_economy_determinism():
    def run():
        sim, _k = _economy_sim(seed=42)
        return sim.tick(0.0).as_dict()
    assert run() == run()


# ===========================================================================
# Political instance — noble → faction → kingdom (§5 distrust→disaster)
# ===========================================================================


def _political_sim(trust=0.8, insight=0.9, seed=1, T_invasion=10.0, t=9.0):
    k = KingdomKernel(T_invasion=T_invasion, horizon=8.0)
    f = InvasionRiskFilter()
    n = NobleAgent(make_sim_agent("n1", "理性冷静"), insight=insight,
                   agent_id="n1", seed=seed)
    g = CharacterGraph()
    org = Organization(org_id="faction", members=["n1", "king"],
                       decision_rule="dictator", dictator_id="king")
    g.add_relationship("king", "n1", trust=trust)
    fac = FactionAgent(org, g, trust_threshold=0.0)
    kingdom = KingdomCollective(k)
    return build_political_sim(k, {"n1": n}, fac, kingdom, f, seed=seed), k


def test_political_high_insight_sees_invasion():
    sim, _k = _political_sim(t=9.0)
    tr = sim.tick(9.0, civ_tech_level=0.0)
    obs = tr.scientist_observations["n1"]
    assert obs["model_error"] is False
    assert obs["risk_prob"] > 0.5


def test_political_low_insight_misperceives():
    sim, _k = _political_sim(insight=0.1, t=9.0)
    tr = sim.tick(9.0, civ_tech_level=0.0)
    obs = tr.scientist_observations["n1"]
    assert obs["model_error"] is True
    assert obs["risk_prob"] < 0.5


def test_political_distrust_leads_to_kingdom_fallen():
    """§5 dynamic in political vocabulary: king distrusts noble → ignore → fallen."""
    sim, _k = _political_sim(trust=-0.5, t=9.0)
    tr = sim.tick(9.0, civ_tech_level=0.0)
    assert "n1" not in tr.info_propagation["king"]
    assert tr.member_votes["king"] == "ignore"
    assert tr.org_decision == "ignore"
    assert tr.outcome_kind == "kingdom_fallen"
    assert tr.civ_destroyed is True


def test_political_trust_keeps_kingdom_held():
    sim, _k = _political_sim(trust=0.8, t=9.0)
    tr = sim.tick(9.0, civ_tech_level=0.0)
    assert tr.outcome_kind in ("kingdom_held",)
    assert tr.civ_destroyed is False


def test_political_peace_before_invasion():
    sim, _k = _political_sim(t=0.0)
    tr = sim.tick(0.0, civ_tech_level=0.0)
    # t=0, invasion at 10, horizon 8 → not imminent → peace
    assert tr.outcome_kind == "peace"
    assert tr.civ_destroyed is False


def test_political_dogmatic_reinforcement_on_fall():
    """A dogmatic noble reinforces 'no invasion' even when the kingdom falls."""
    k = KingdomKernel(T_invasion=10.0, horizon=8.0)
    f = InvasionRiskFilter()
    n = NobleAgent(make_sim_agent("n1", "固执顽固"), insight=0.1,
                   agent_id="n1", seed=3)
    # force a low prior so reflux evidence=1.0 contradicts → dogmatic backfire
    n.sim.mind_state.beliefs["risk_prob"] = Belief(
        predicted=0.15, confidence=0.5, model_error=False, committed_values={})
    g = CharacterGraph()
    org = Organization(org_id="faction", members=["n1", "king"],
                       decision_rule="dictator", dictator_id="king")
    g.add_relationship("king", "n1", trust=-0.5)
    fac = FactionAgent(org, g, trust_threshold=0.0)
    kingdom = KingdomCollective(k)
    sim = build_political_sim(k, {"n1": n}, fac, kingdom, f, seed=3)
    tr = sim.tick(9.0, civ_tech_level=0.0)
    reflux = tr.post_outcome_belief_updates["n1"]
    assert reflux["strategy"] == "dogmatic"
    assert reflux["accepted"] is False
    assert reflux["posterior"]["predicted"] < 0.15


def test_political_determinism():
    def run():
        sim, _k = _political_sim(seed=42, t=9.0)
        return sim.tick(9.0).as_dict()
    assert run() == run()


# ===========================================================================
# Three-body subclass relationship (generality proof)
# ===========================================================================


def test_three_body_scientist_is_individual_agent():
    from theater.three_body_agents import ScientistAgent
    from theater.multi_scale_agents import IndividualAgent
    assert issubclass(ScientistAgent, IndividualAgent)


def test_three_body_decisionbody_is_organization_agent():
    from theater.three_body_agents import DecisionBody
    assert issubclass(DecisionBody, OrganizationAgent)


def test_three_body_civilization_is_collective_agent():
    from theater.three_body_agents import CivilizationAgent
    assert issubclass(CivilizationAgent, CollectiveAgent)


def test_three_body_sim_is_multiscale_sim():
    from theater.three_body_agents import MultiScaleThreeBodySim
    assert issubclass(MultiScaleThreeBodySim, MultiScaleSim)


def test_three_body_causal_trace_is_generic_trace():
    from theater.three_body_agents import CausalTrace
    assert issubclass(CausalTrace, MultiScaleCausalTrace)


# ===========================================================================
# Public framework import + smoke
# ===========================================================================


def test_generic_framework_public_surface_importable():
    import theater.multi_scale_agents as module

    assert module.__all__
    assert all(hasattr(module, name) for name in module.__all__)
    assert module.MultiScaleSim
    assert module.MultiScaleSimConfig
