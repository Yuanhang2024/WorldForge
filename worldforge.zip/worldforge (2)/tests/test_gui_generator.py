"""Tests for the GUI generator (gui_generation_design.md §7 + §8).

Coverage:
  - A hand-built valid GUISpec exercises the compilers.
  - compile_to_css output is valid CSS (escapes/braces balanced).
  - compile_to_html_template output is well-formed HTML.
  - binds vocabularies are honoured (closed intent set; actions allowlist).
  - generation without ``llm_fn`` fails explicitly.
  - LLM-shaped input round-trips through validation when correct, and
    malformed output fails.
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import List

import pytest

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from theater.gui_generator import (
    ALLOWED_ACTIONS,
    ALLOWED_INTENT_KINDS,
    ALLOWED_LAYOUT_TYPES,
    ALLOWED_MOTIONS,
    ALLOWED_ICON_STYLES,
    ALLOWED_WIDGET_TYPES,
    GUIGenerator,
    GUISpec,
    WidgetSpec,
    compile_to_css,
    compile_to_html_template,
    spec_to_json,
    validate_gui_spec,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

EXPECTED_SPEC_NAMES = ("sample",)


def _sample_spec() -> GUISpec:
    """Explicit test data; this is not a generator fallback."""
    return GUISpec(
        gui_spec_id="sample_gui",
        layout_type="console",
        grid={
            "columns": "2fr 1fr",
            "rows": "1fr auto",
            "areas": ["events status", "command command"],
        },
        chrome="instrument_bezel",
        widgets=[
            WidgetSpec(
                name="events",
                type="log_feed",
                area="events",
                binds={"read": "state:event_log"},
            ),
            WidgetSpec(
                name="status",
                type="canvas_panel",
                area="status",
                binds={"read": "state:status"},
            ),
            WidgetSpec(
                name="command",
                type="text_field",
                area="command",
                binds={"emit": "utterance", "action": "dispatch"},
            ),
        ],
        typography={"display": "Noto Sans", "mono": "IBM Plex Mono"},
        icon_style="instrument",
        motion="free",
    )


def _get_widgets(spec: GUISpec):
    return {(w.name, w.type) for w in spec.widgets}


def _braces_balanced(css: str) -> bool:
    return css.count("{") == css.count("}")


# ---------------------------------------------------------------------------
# Explicit specimen structure (§8)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("spec_name", list(EXPECTED_SPEC_NAMES))
def test_each_sample_has_required_fields(spec_name):
    spec = _sample_spec()
    assert isinstance(spec, GUISpec)
    assert spec.layout_type in ALLOWED_LAYOUT_TYPES
    assert spec.icon_style in ALLOWED_ICON_STYLES
    assert spec.motion in ALLOWED_MOTIONS
    assert spec.gui_spec_id
    assert spec.typography.get("display")
    assert spec.typography.get("mono")
    assert spec.grid.get("columns")
    assert spec.widgets, "sample must carry at least one widget"


@pytest.mark.parametrize("spec_name", list(EXPECTED_SPEC_NAMES))
def test_each_sample_widget_binds_are_allowlisted(spec_name):
    spec = _sample_spec()
    for w in spec.widgets:
        # Every widget must have a usable binds (either a closed emit, or a
        # kernel:/state: read), per §4.4 of the design doc.
        assert w.binds, f"{spec_name}/{w.name} has empty binds"
        binds = w.binds
        if "emit" in binds:
            assert binds["emit"] in ALLOWED_INTENT_KINDS, (
                f"{spec_name}/{w.name} emit={binds['emit']!r} not in closed set"
            )
        if "read" in binds:
            assert binds["read"].startswith(("kernel:", "state:")), (
                f"{spec_name}/{w.name} read={binds['read']!r}"
            )
        if "action" in binds:
            assert binds["action"] in ALLOWED_ACTIONS, (
                f"{spec_name}/{w.name} action={binds['action']!r}"
            )


def test_sample_layout_covers_text_world_controls():
    spec = _sample_spec()
    assert spec.layout_type == "console"
    types = {w.type for w in spec.widgets}
    for must in ("log_feed", "canvas_panel", "text_field"):
        assert must in types, f"sample missing {must}"


# ---------------------------------------------------------------------------
# compile_to_css
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("spec_name", list(EXPECTED_SPEC_NAMES))
def test_compile_to_css_is_well_formed(spec_name):
    spec = _sample_spec()
    css = compile_to_css(spec)
    # Balanced braces → likely a coherent stylesheet.
    assert _braces_balanced(css), f"{spec_name} braces unbalanced"
    # Grid plumbing present.
    assert "display: grid;" in css
    assert "grid-template-columns:" in css
    # Each emitted selector ends with `{` and a `}` — sanity scan.
    for chunk in css.split("}"):
        if chunk.strip():
            assert "{" in chunk
    # No hard-coded hex colors snuck in (the GUI layer doesn't paint).
    for hex_color in re.findall(r"#[0-9a-fA-F]{3,8}", css):
        pytest.fail(f"hardcoded color {hex_color!r} in css output")


@pytest.mark.parametrize("spec_name", list(EXPECTED_SPEC_NAMES))
def test_compile_to_css_quotes_grid_areas(spec_name):
    spec = _sample_spec()
    css = compile_to_css(spec)
    if not spec.grid.get("areas"):
        pytest.skip(f"{spec_name} has no explicit areas")
    # The grid-template-areas value list must consist of single-quoted rows.
    m = re.search(r"grid-template-areas:\s*([^;]+);", css)
    assert m is not None
    declaration = m.group(1).strip()
    # Walk the declaration char-by-char, splitting on top-level spaces only
    # (whitespace inside a quoted row token must NOT split).
    tokens: List[str] = []
    buf: List[str] = []
    in_quote = False
    for ch in declaration:
        if ch == "'":
            in_quote = not in_quote
            buf.append(ch)
        elif ch.isspace() and not in_quote:
            if buf:
                tokens.append("".join(buf))
                buf = []
        else:
            buf.append(ch)
    if buf:
        tokens.append("".join(buf))
    assert tokens, "no tokens parsed from grid-template-areas"
    for token in tokens:
        assert token.startswith("'") and token.endswith("'"), (
            f"non-quoted grid-area token {token!r} in {spec_name}"
        )
    # Sanity: every area name in the spec's grid should appear inside a quote
    for row in spec.grid["areas"]:
        for area in row.split():
            area = area.split(".", 1)[-1]
            assert f"'{area}" in declaration or f"{area}'" in declaration, (
                f"area {area!r} missing from CSS grid-template-areas"
            )


# ---------------------------------------------------------------------------
# compile_to_html_template
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("spec_name", list(EXPECTED_SPEC_NAMES))
def test_compile_to_html_renders_one_block_per_widget(spec_name):
    spec = _sample_spec()
    html = compile_to_html_template(spec)
    # Widget blocks are the OUTER div carrying data-widget; inner divs use
    # class="w-*" for sub-elements (w-panel-header, w-label, etc.). Only the
    # outer divs match `class="w-<type> role-..."` with role attribute.
    widget_divs = re.findall(
        r'<div class="w-[a-z_]+ role-[a-z_-]+"', html
    )
    assert len(widget_divs) == len(spec.widgets), (
        f"{spec_name}: expected {len(spec.widgets)} widget divs, "
        f"got {len(widget_divs)}"
    )
    # Each div should carry data-widget matching the spec
    for widget in spec.widgets:
        assert f'data-widget="{widget.name}"' in html


@pytest.mark.parametrize("spec_name", list(EXPECTED_SPEC_NAMES))
def test_compile_to_html_balanced_tags(spec_name):
    spec = _sample_spec()
    html = compile_to_html_template(spec)
    opens = len(re.findall(r"<(?!/)[a-zA-Z]+", html))
    closes = len(re.findall(r"</[a-zA-Z]+>", html))
    self_close = len(re.findall(r"<(?:input|br|img|meta|link)[^>]*>", html))
    assert opens - self_close == closes, (
        f"{spec_name}: unbalanced tags (opens={opens}, closes={closes})"
    )


# ---------------------------------------------------------------------------
# binds safety (§4.4 / §7)
# ---------------------------------------------------------------------------

def test_binds_rejects_unknown_emit():
    spec = GUISpec(
        gui_spec_id="unsafe",
        layout_type="dashboard",
        grid={"columns": "1fr", "areas": ["main"]},
        widgets=[
            WidgetSpec(
                name="evil",
                type="button",
                area="main",
                binds={"emit": "delete_universe"},
            )
        ],
    )
    with pytest.raises(ValueError, match="not in closed intent set"):
        validate_gui_spec(spec)


def test_binds_rejects_unknown_action():
    spec = GUISpec(
        gui_spec_id="unsafe",
        layout_type="dashboard",
        grid={"columns": "1fr", "areas": ["main"]},
        widgets=[
            WidgetSpec(
                name="rce",
                type="commit_bar",
                area="main",
                binds={"emit": "decision_vector",
                       "commit": True,
                       "action": "/etc/passwd"},
            )
        ],
    )
    with pytest.raises(ValueError, match="not in closed action set"):
        validate_gui_spec(spec)


def test_binds_rejects_unknown_read_target():
    spec = GUISpec(
        gui_spec_id="unsafe",
        layout_type="dashboard",
        grid={"columns": "1fr", "areas": ["main"]},
        widgets=[
            WidgetSpec(
                name="leaky",
                type="canvas_panel",
                area="main",
                binds={"read": "ftp://host/secret"},
            )
        ],
    )
    with pytest.raises(ValueError, match="must start with"):
        validate_gui_spec(spec)


def test_binds_rejects_widget_with_no_binds():
    spec = GUISpec(
        gui_spec_id="dead",
        layout_type="dashboard",
        grid={"columns": "1fr", "areas": ["main"]},
        widgets=[
            WidgetSpec(
                name="orphan",
                type="canvas_panel",
                area="main",
                binds={},
            )
        ],
    )
    with pytest.raises(ValueError, match="binds required"):
        validate_gui_spec(spec)


def test_binds_allows_emit_and_read_together():
    """A widget may legitimately carry both a read (display state) and an
    emit (produce intent on interaction) — allowed, not a conflict."""
    spec = GUISpec(
        gui_spec_id="weird",
        layout_type="dashboard",
        grid={"columns": "1fr", "areas": ["main"]},
        widgets=[
            WidgetSpec(
                name="double",
                type="slider",
                area="main",
                binds={"emit": "decision_vector",
                       "read": "kernel:something"},
            )
        ],
    )
    # Should NOT raise — emit + read coexistence is valid.
    validate_gui_spec(spec)


# ---------------------------------------------------------------------------
# Determinism (no LLM)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "prompt",
    [
        "潮汐湿地生态站",
        "跨区域交通调度",
        "mountain watershed council",
        "orbital resource planning",
        "",
    ],
)
def test_no_llm_fails_instead_of_selecting_a_preset(prompt):
    """Description vocabulary cannot select any implicit replacement."""
    with pytest.raises(RuntimeError, match="requires llm_fn"):
        GUIGenerator().generate(prompt)


# ---------------------------------------------------------------------------
# LLM path — happy + §7.8 fallback
# ---------------------------------------------------------------------------

def test_llm_fn_returning_valid_dict_wins():
    payload = {
        "gui_spec_id": "llm_custom_01",
        "layout": {
            "type": "terminal",
            "chrome": "crt_scanline",
            "grid": {
                "columns": "2fr 1fr",
                "rows": "auto 1fr auto",
                "areas": ["netmap ice", "netmap hack", "cmdline cmdline"],
            },
        },
        "widgets": [
            {
                "id": "netmap", "type": "canvas_panel", "area": "netmap",
                "role": "panel", "title": "NET://GRID",
                "binds": {"read": "kernel:netmap"},
            },
            {
                "id": "cmd", "type": "text_field", "area": "cmdline",
                "role": "accent", "placeholder": "> run",
                "binds": {"emit": "utterance"},
            },
        ],
        "icon_style": "line_terminal",
        "motion": "glitch",
        "typography": {"display": "IBM Plex Mono", "mono": "IBM Plex Mono",
                       "case": "upper"},
        "semantic_slots": {"neon_primary": 9},
    }

    def llm_fn(_prompt):
        return payload

    spec = GUIGenerator(llm_fn=llm_fn).generate("anything")
    assert spec.gui_spec_id == "llm_custom_01"
    assert spec.layout_type == "terminal"
    assert any(w.name == "netmap" for w in spec.widgets)


def test_llm_fn_returning_garbage_fails():
    def llm_fn(_prompt):
        return {"this": "is not a gui_spec"}

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("regional transit network")


def test_llm_fn_raising_fails():
    def llm_fn(_prompt):
        raise RuntimeError("model offline")

    with pytest.raises(RuntimeError, match="LLM GUI generation failed"):
        GUIGenerator(llm_fn=llm_fn).generate("watershed council")


# ---------------------------------------------------------------------------
# JSON serialisation
# ---------------------------------------------------------------------------

def test_spec_to_json_roundtrip():
    spec = _sample_spec()
    blob = spec_to_json(spec)
    parsed = json.loads(blob)
    assert parsed["layout_type"] == "console"
    assert parsed["widgets"]
    # widget names preserved
    names = {w["name"] for w in parsed["widgets"]}
    assert "command" in names


# ---------------------------------------------------------------------------
# Widget type vocabulary is genuinely closed
# ---------------------------------------------------------------------------

def test_widget_type_vocabulary_is_closed():
    assert "delete_universe" not in ALLOWED_WIDGET_TYPES
    assert "commit_bar" in ALLOWED_WIDGET_TYPES
    assert "canvas_panel" in ALLOWED_WIDGET_TYPES


def test_intent_vocabulary_matches_router_known_kinds():
    """Only generic text and deterministic-kernel inputs remain."""
    expected = {
        "utterance", "decision_vector", "playfield_action",
    }
    assert ALLOWED_INTENT_KINDS == frozenset(expected)


# ---------------------------------------------------------------------------
# Cross-preset sanity: every widget area referenced is declared in the grid.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("spec_name", list(EXPECTED_SPEC_NAMES))
def test_widget_areas_resolve_in_grid(spec_name):
    spec = _sample_spec()
    if not spec.grid.get("areas"):
        pytest.skip(f"{spec_name} has no explicit areas")
    declared = set()
    for row in spec.grid["areas"]:
        for token in row.split():
            declared.add(token.split(".", 1)[-1])
    for w in spec.widgets:
        assert w.area in declared, (
            f"{spec_name}/{w.name}: area {w.area!r} not in grid areas"
        )
