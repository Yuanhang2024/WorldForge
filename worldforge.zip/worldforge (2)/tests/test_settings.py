import os
import tempfile
import unittest

from theater.settings import Settings


class SettingsTests(unittest.TestCase):
    def test_settings_normalizes_openai_compatible_base_url_and_masks_key(self):
        settings = Settings(
            api_key="test-secret-token",
            base_url="api.requestme.top/v1/",
            model_fast="gpt5.4",
            model_deep="gpt5.5",
        )

        self.assertEqual(settings.normalized_base_url, "https://api.requestme.top/v1")
        self.assertEqual(settings.masked_api_key, "tes...oken")
        self.assertNotIn("test-secret-token", settings.public_dict().values())
        self.assertEqual(settings.public_dict()["model_fast"], "gpt5.4")
        self.assertEqual(settings.public_dict()["model_deep"], "gpt5.5")
        self.assertEqual(settings.provider_model_fast, "gpt-5.4")
        self.assertEqual(settings.provider_model_deep, "gpt-5.5")

    def test_agent_config_falls_back_to_global_settings(self):
        settings = Settings(
            api_key="global-key",
            base_url="https://global.example/v1",
            model_fast="gpt5.4",
            model_deep="gpt5.5",
            enable_live_api=True,
            auth_header_type="api-key",
        )
        agent = settings.agent_config("producer")
        self.assertEqual(agent.api_key, "global-key")
        self.assertEqual(agent.base_url, "https://global.example/v1")
        self.assertEqual(agent.model, "")
        self.assertTrue(agent.enable_live_api)
        self.assertEqual(agent.auth_header_type, "api-key")
        self.assertEqual(settings.agent_auth_headers("producer"), {"api-key": "global-key"})

    def test_agent_config_uses_per_agent_overrides(self):
        settings = Settings(
            api_key="global-key",
            base_url="https://global.example/v1",
            model_fast="gpt5.4",
            model_deep="gpt5.5",
            enable_live_api=True,
            auth_header_type="bearer",
            agents={
                "world_builder": Settings.__dataclass_fields__["agents"].type.__args__[1](  # type: ignore[attr-defined]
                    api_key="story-key",
                    base_url="https://story.example/v1",
                    model="story-model",
                    enable_live_api=False,
                    auth_header_type="x-api-key",
                )
            },
        )
        agent = settings.agent_config("world_builder")
        self.assertEqual(agent.api_key, "story-key")
        self.assertEqual(agent.base_url, "https://story.example/v1")
        self.assertEqual(agent.model, "story-model")
        self.assertFalse(agent.enable_live_api)
        self.assertEqual(agent.auth_header_type, "x-api-key")
        self.assertEqual(settings.agent_auth_headers("world_builder"), {"x-api-key": "story-key"})

    def test_agent_model_returns_override_or_fallback(self):
        settings = Settings(model_deep="gpt5.5")
        self.assertEqual(settings.agent_model("producer", "gpt5.5"), "gpt5.5")

        settings = Settings(
            model_deep="gpt5.5",
            agents={
                "producer": Settings.__dataclass_fields__["agents"].type.__args__[1](  # type: ignore[attr-defined]
                    model="custom-model"
                )
            },
        )
        self.assertEqual(settings.agent_model("producer", "gpt5.5"), "custom-model")

    def test_agent_masked_api_key_does_not_leak_secret(self):
        settings = Settings(
            api_key="global-key",
            agents={
                "producer": Settings.__dataclass_fields__["agents"].type.__args__[1](  # type: ignore[attr-defined]
                    api_key="producer-secret-token"
                )
            },
        )
        masked = settings.agent_masked_api_key("producer")
        self.assertNotIn("producer-secret-token", masked)
        self.assertNotEqual(masked, "not-configured")

    def test_agent_live_api_requires_flag_and_openai_key(self):
        self.assertFalse(
            Settings(api_key="", enable_live_api=True)
            .agent_live_api_enabled("world_builder")
        )
        self.assertFalse(
            Settings(api_key="configured", enable_live_api=False)
            .agent_live_api_enabled("world_builder")
        )
        self.assertTrue(
            Settings(api_key="configured", enable_live_api=True)
            .agent_live_api_enabled("world_builder")
        )

    def test_local_and_custom_providers_allow_an_empty_api_key(self):
        for base_url in (
            "http://127.0.0.1:1234/v1",
            "http://localhost:11434/v1",
            "https://custom-provider.example/v1",
        ):
            settings = Settings(
                base_url=base_url, api_key="", enable_live_api=True,
            )
            self.assertTrue(settings.live_api_ready)
            self.assertTrue(settings.agent_live_api_enabled("producer"))
            self.assertEqual(settings.auth_headers, {})
            self.assertEqual(settings.agent_auth_headers("producer"), {})
            self.assertTrue(settings.public_dict()["live_api_enabled"])

    def test_official_openai_empty_key_is_consistently_not_ready(self):
        settings = Settings(
            base_url="https://api.openai.com/v1",
            api_key="",
            enable_live_api=True,
        )
        self.assertFalse(settings.live_api_ready)
        self.assertFalse(settings.agent_live_api_enabled("producer"))
        self.assertFalse(settings.public_dict()["live_api_enabled"])

    def test_from_env_parses_agent_variables(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = dict(os.environ)
            try:
                os.environ.clear()
                os.environ["AI_THEATER_API_KEY"] = "global-key"
                os.environ["AI_THEATER_AUTH_HEADER_TYPE"] = "api-key"
                os.environ["AI_THEATER_AGENT_PRODUCER_API_KEY"] = "producer-key"
                os.environ["AI_THEATER_AGENT_PRODUCER_MODEL"] = "custom-producer"
                os.environ["AI_THEATER_AGENT_SCIENCE_DIRECTOR_BASE_URL"] = "https://science.example/v1"
                os.environ["AI_THEATER_AGENT_SCIENCE_DIRECTOR_AUTH_HEADER_TYPE"] = "x-api-key"
                os.environ["AI_THEATER_ENABLE_LIVE_API"] = "true"
                os.environ["AI_THEATER_DATA_DIR"] = directory
                settings = Settings.from_env()

                self.assertEqual(settings.auth_header_type, "api-key")
                self.assertEqual(settings.agent_config("producer").api_key, "producer-key")
                self.assertEqual(settings.agent_config("producer").model, "custom-producer")
                self.assertEqual(settings.agent_config("producer").auth_header_type, "api-key")
                self.assertEqual(settings.agent_config("science_director").base_url, "https://science.example/v1")
                self.assertEqual(settings.agent_config("science_director").auth_header_type, "x-api-key")
                self.assertEqual(settings.agent_config("world_builder").api_key, "global-key")
            finally:
                os.environ.clear()
                os.environ.update(previous)


if __name__ == "__main__":
    unittest.main()
