"""Tests for the world_creation module.

Covers all four WorldCreator entry points:
  - propose() with and without llm_fn
  - preview() produces readable summary
  - create() produces new world_id + empty state with pinned params
  - fork() copies params + applies overrides
  - 60-second default world constraint
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any, Dict
from uuid import UUID

import pytest

# ---------------------------------------------------------------------------
# We import the module-under-test and its dependencies directly from the
# backend/theater package, which sits on the PYTHONPATH.
# ---------------------------------------------------------------------------
from theater.world_creation import (
    DEFAULT_GUI_HINT,
    DEFAULT_NPCS,
    DEFAULT_OPENING_SCENE,
    DEFAULT_WORLD_PARAMS,
    WorldCreator,
    WorldPreview,
    WorldProposal,
)


# ===================================================================
# propose
# ===================================================================

class TestPropose:
    """propose() produces a valid WorldProposal in both llm_fn modes."""

    def test_default_when_no_llm(self) -> None:
        """Without llm_fn, semantic world generation fails explicitly."""
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            WorldCreator.propose("随便建个世界")

    def test_no_description_without_llm_also_fails(self) -> None:
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            WorldCreator.propose("  ")

    def test_keywords_do_not_select_a_world_type_or_kernel(self) -> None:
        """Descriptions are content, never implicit routing instructions."""
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            WorldCreator.propose("三体世界，包含恒纪元与乱纪元")

    def test_with_llm_fn(self) -> None:
        """llm_fn dict is unpacked into the WorldProposal."""
        def fake_llm(prompt: str) -> Dict[str, Any]:
            return {
                "world_id": "brain_world",
                "world_params": {"seed": 7, "enabled_kernels": ["three_body"]},
                "npcs": [{"name": "Neuron-1", "role": "thinker", "description": "firing"}],
                "opening_scene": "A synapse crackles.",
                "gui_hint": '{"style":"neural"}',
            }

        proposal = WorldCreator.propose("a world of pure thought", llm_fn=fake_llm)
        assert isinstance(proposal, WorldProposal)
        assert proposal.world_id == "brain_world"
        assert proposal.world_params["seed"] == 7
        assert proposal.npcs[0]["name"] == "Neuron-1"
        assert proposal.opening_scene == "A synapse crackles."

    def test_llm_fn_wrong_type_raises(self) -> None:
        """llm_fn must return a dict; anything else raises TypeError."""
        def bad_llm(_: str) -> str:
            return "not a dict"

        with pytest.raises(TypeError, match="llm_fn must return a dict"):
            WorldCreator.propose("test", llm_fn=bad_llm)

    def test_proposal_is_immutable(self) -> None:
        """Manual proposal instances do not share mutable defaults."""
        p1 = WorldProposal()
        original_npc_count = len(DEFAULT_NPCS)
        p1.npcs.clear()
        p1.world_params["enabled_kernels"].append("custom")
        # default must be unchanged (dataclass default factory copies each time)
        p2 = WorldProposal()
        assert len(p2.npcs) == original_npc_count
        assert p2.world_params["enabled_kernels"] == []
        assert DEFAULT_WORLD_PARAMS["enabled_kernels"] == []


# ===================================================================
# preview
# ===================================================================

class TestPreview:
    """preview() is neutral by default and adapts explicit kernels."""

    def test_preview_default_params_is_neutral(self) -> None:
        """Default world_params do not silently select a specialised kernel."""
        preview = WorldCreator.preview()
        assert isinstance(preview, WorldPreview)
        assert preview.summary_text == "世界草案已就绪；未启用可预跑的确定性内核。"
        assert preview.num_rises_falls == 0
        assert preview.avg_civ_duration == 0.0
        assert preview.earliest_evac_civ == 0

    def test_neutral_preview_does_not_eagerly_bind_three_body(self) -> None:
        import theater.world_creation as world_creation

        assert not hasattr(world_creation, "ThreeBodyKernel")
        preview = WorldCreator.preview({"seed": 77})
        assert "未启用" in preview.summary_text

    def test_preview_with_explicit_seed(self) -> None:
        """An explicitly enabled adapter and seed produce deterministic output."""
        params = {"seed": 12345, "enabled_kernels": ["three_body"]}
        p1 = WorldCreator.preview(params)
        p2 = WorldCreator.preview(params)
        assert p1.num_rises_falls == p2.num_rises_falls
        assert p1.summary_text == p2.summary_text

    def test_preview_accepts_explicit_proposal(self) -> None:
        proposal = WorldProposal(
            world_params={"seed": 77, "enabled_kernels": ["three_body"]},
        )
        preview = WorldCreator.preview(proposal)
        assert "文明平均存续" in preview.summary_text

    def test_preview_summary_format(self) -> None:
        """The explicit Three-Body adapter follows the spec §11.5 format."""
        preview = WorldCreator.preview(
            {"seed": 77, "enabled_kernels": ["three_body"]},
        )
        text = preview.summary_text
        assert "这个宇宙：" in text
        # At least one "万年" or a failure message
        assert "万年" in text or "失败" in text
        # The text is printable and non-empty
        assert len(text) > 10


# ===================================================================
# create
# ===================================================================

class TestCreate:
    """create() produces a new world_id + pinned state on disk."""

    def test_create_returns_world_id(self) -> None:
        """create() returns a non-empty string world_id."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            proposal = WorldProposal()
            wid = WorldCreator.create(proposal, root)
            assert isinstance(wid, str)
            assert len(wid) > 0

    def test_create_produces_state_file(self) -> None:
        """A JSON state file exists on disk after creation."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            proposal = WorldProposal()
            wid = WorldCreator.create(proposal, root)
            state_path = root / f"state_{wid}.json"
            assert state_path.exists()
            data = json.loads(state_path.read_text(encoding="utf-8"))
            assert isinstance(data, dict)

    def test_create_pins_world_params(self) -> None:
        """world_params are written into _meta and are not empty."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            params = {"seed": 99, "enabled_kernels": ["three_body"], "lambda": 0.5}
            proposal = WorldProposal(world_params=params)
            wid = WorldCreator.create(proposal, root)
            state_path = root / f"state_{wid}.json"
            data = json.loads(state_path.read_text(encoding="utf-8"))
            meta = data.get("_meta", {})
            assert meta.get("world_params") == params

    def test_create_separate_state_files(self) -> None:
        """Two creates produce two distinct state files."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            wid1 = WorldCreator.create(WorldProposal(), root)
            wid2 = WorldCreator.create(WorldProposal(), root)
            assert wid1 != wid2
            assert (root / f"state_{wid1}.json").exists()
            assert (root / f"state_{wid2}.json").exists()

    def test_repeated_requested_id_never_reopens_existing_world(self) -> None:
        """A duplicate human-readable ID gets a suffix and preserves state."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            wid1 = WorldCreator.create(
                WorldProposal(
                    world_id="shared_name",
                    world_params={"seed": 1, "enabled_kernels": []},
                ),
                root,
            )
            wid2 = WorldCreator.create(
                WorldProposal(
                    world_id="shared_name",
                    world_params={"seed": 2, "enabled_kernels": []},
                ),
                root,
            )

            assert wid1 == "shared_name"
            assert wid2.startswith("shared_name_")
            assert wid2 != wid1
            first = json.loads(
                (root / f"state_{wid1}.json").read_text(encoding="utf-8")
            )
            second = json.loads(
                (root / f"state_{wid2}.json").read_text(encoding="utf-8")
            )
            assert first["_meta"]["world_params"]["seed"] == 1
            assert second["_meta"]["world_params"]["seed"] == 2

    def test_create_empty_proposal(self) -> None:
        """A proposal with all defaults still produces a valid world."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            proposal = WorldProposal()
            wid = WorldCreator.create(proposal, root)
            state_path = root / f"state_{wid}.json"
            data = json.loads(state_path.read_text(encoding="utf-8"))
            assert "worldbook" in data
            assert "characters" in data
            assert "_meta" in data


# ===================================================================
# fork
# ===================================================================

class TestFork:
    """fork() copies an existing world with optional parameter overrides."""

    def test_fork_creates_new_world_id(self) -> None:
        """fork() returns a world_id different from the source."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            original_wid = WorldCreator.create(WorldProposal(), root)
            forked_wid = WorldCreator.fork(original_wid, {}, root)
            assert forked_wid != original_wid
            assert (root / f"state_{forked_wid}.json").exists()

    def test_fork_preserves_params(self) -> None:
        """Fork without overrides preserves the original params."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            params = {"seed": 111, "enabled_kernels": ["three_body"], "lambda": 0.3}
            original_wid = WorldCreator.create(
                WorldProposal(world_params=params), root
            )
            forked_wid = WorldCreator.fork(original_wid, {}, root)

            forked_state = json.loads(
                (root / f"state_{forked_wid}.json").read_text(encoding="utf-8")
            )
            assert forked_state["_meta"]["world_params"]["seed"] == 111

    def test_fork_applies_overrides(self) -> None:
        """Fork with overrides changes only the specified keys."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            original_wid = WorldCreator.create(
                WorldProposal(world_params={"seed": 1, "enabled_kernels": ["three_body"]}),
                root,
            )
            forked_wid = WorldCreator.fork(
                original_wid, {"seed": 999}, root
            )

            forked_state = json.loads(
                (root / f"state_{forked_wid}.json").read_text(encoding="utf-8")
            )
            forked_params = forked_state["_meta"]["world_params"]
            assert forked_params["seed"] == 999  # overridden
            assert forked_params["enabled_kernels"] == ["three_body"]  # preserved


# ===================================================================
# 60-second playable constraint (spec §11.4)
# ===================================================================

class TestSixtySecondPlayable:
    """A default world must be creatable and previewable in << 60 seconds."""

    def test_default_world_is_instant(self) -> None:
        """Creating a default world (no preview) is effectively instant."""
        import time
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            t0 = time.monotonic()
            wid = WorldCreator.create(WorldProposal(), root)
            elapsed = time.monotonic() - t0
            assert elapsed < 2.0, (
                f"create() took {elapsed:.2f}s, expected < 2s"
            )
            assert wid

    def test_preview_is_under_60_seconds(self) -> None:
        """Preview (kernel bake) must complete well within 60 s."""
        import time
        t0 = time.monotonic()
        preview = WorldCreator.preview(
            {"seed": 42, "enabled_kernels": ["three_body"]},
        )
        elapsed = time.monotonic() - t0
        assert elapsed < 60.0, (
            f"preview() took {elapsed:.1f}s, must be < 60s"
        )
        assert "文明平均存续" in preview.summary_text


# ===================================================================
# Integration (creation + storage round-trip)
# ===================================================================

class TestIntegration:
    """End-to-end: propose → preview → create → fork."""

    def test_full_lifecycle(self) -> None:
        """All four steps can run in sequence without errors."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)

            # 1. propose
            proposal = WorldCreator.propose(
                "三体世界",
                llm_fn=lambda _prompt: {
                    "opening_scene": "模型生成的开场",
                    "world_params": {
                        "seed": 42,
                        "enabled_kernels": [],
                    },
                },
            )
            assert isinstance(proposal, WorldProposal)
            assert proposal.world_params["enabled_kernels"] == []

            # Specialised behaviour is enabled by an explicit user choice,
            # never by matching the proposal description.
            proposal.world_params["enabled_kernels"] = ["three_body"]

            # 2. preview
            preview = WorldCreator.preview(proposal.world_params)
            assert preview.summary_text
            assert "文明平均存续" in preview.summary_text

            # 3. create
            wid1 = WorldCreator.create(proposal, root)
            assert wid1

            # 4. fork
            wid2 = WorldCreator.fork(wid1, {"seed": 999}, root)
            assert wid2 != wid1

            # All state files exist
            assert (root / f"state_{wid1}.json").exists()
            assert (root / f"state_{wid2}.json").exists()
