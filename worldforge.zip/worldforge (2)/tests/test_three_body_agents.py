"""Tests for P3 — three-body multi-scale agency (architecture spec §3 / §8.2).

Covers the three layers (ScientistAgent / DecisionBody / CivilizationAgent),
the multi-scale causal chain, the canonical §5 "leader distrusts scientist
→ information does not propagate → social disaster" example, CausalTrace
structure, and same-seed determinism with stable mistakes.

No LLM, no unseeded randomness — every assertion is a pure function of its
inputs (spec §8.2 red line).  The kernel is the only source of ground
truth; ``three_body.py``'s ``civilization_outcome`` / ``civilization_step``
are used unmodified.
"""

from __future__ import annotations

import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.belief_update import revise_belief  # noqa: E402
from theater.character_graph import (  # noqa: E402
    CharacterGraph,
    Organization,
)
from theater.cognitive_model import Belief, ThreeBodyCognitiveModel  # noqa: E402
from theater.kernels.three_body import ThreeBodyKernel  # noqa: E402
from theater.sim_agent import CharacterDefinition, SimAgent  # noqa: E402
from theater.three_body_agents import (  # noqa: E402
    CausalTrace,
    CivilizationAgent,
    DecisionBody,
    MultiScaleThreeBodySim,
    PLAN_DEHYDRATE,
    PLAN_EVACUATE,
    PLAN_PERSIST,
    PLAN_TO_DECISION_VECTOR,
    ScientistAgent,
    ThreeBodyObservationFilter,
)


# ---------------------------------------------------------------------------
# Stub kernel — fast, scripted, stands in for ThreeBodyKernel.civilization_outcome
# ---------------------------------------------------------------------------


class StubKernel:
    """Deterministic stand-in for ThreeBodyKernel.

    ``next_chaos`` is returned by ``next_chaotic_era_after``.  The outcome
    kind is scripted per call via ``outcomes``; if exhausted, falls back to
    ``destroyed_chaos``.  ``civilization_outcome`` delegates to the real
    :class:`ThreeBodyKernel.civilization_outcome` only when
    ``use_real_outcome`` is set (the integration test), otherwise it
    synthesises a minimal outcome object carrying the fields CausalTrace
    reads.
    """

    def __init__(self, next_chaos=None, lambda_=0.1, outcomes=None,
                 use_real_outcome=False, real_kernel=None):
        self._next_chaos = next_chaos
        self.lambda_ = lambda_
        self._outcomes = list(outcomes or [])
        self.use_real_outcome = use_real_outcome
        self.real_kernel = real_kernel
        self.calls = []

    def next_chaotic_era_after(self, t):
        return self._next_chaos

    def civilization_outcome(self, tech_level, t, decision_vector=None,
                             civ_count=None, evacuated=False):
        self.calls.append({
            "tech_level": tech_level, "t": t,
            "decision_vector": decision_vector, "civ_count": civ_count,
            "evacuated": evacuated,
        })
        if self.use_real_outcome and self.real_kernel is not None:
            return self.real_kernel.civilization_outcome(
                tech_level=tech_level, t=t, decision_vector=decision_vector,
                civ_count=civ_count, evacuated=evacuated,
            )
        kind = self._outcomes.pop(0) if self._outcomes else "destroyed_chaos"
        return _StubOutcome(kind=kind, t=t, tech_level=tech_level,
                            decision_vector=decision_vector)


class _StubOutcome:
    """Minimal outcome object carrying the fields CausalTrace reads."""

    def __init__(self, kind, t, tech_level, decision_vector,
                 cause="stub", decision_quality="neutral"):
        self.kind = kind
        self.t = t
        self.tech_level = tech_level
        self.decision_vector = decision_vector
        self.cause = cause
        self.decision_quality = decision_quality

    def as_dict(self):
        return {"kind": self.kind, "t": self.t, "tech_level": self.tech_level,
                "cause": self.cause,
                "decision_quality": self.decision_quality}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_scientist(personality: str, capability: dict, prior_prob=None,
                    scientist_id=None, seed=None) -> ScientistAgent:
    char = CharacterDefinition(
        character_id=scientist_id or personality,
        name=scientist_id or personality,
        personality=personality,
    )
    sim = SimAgent(char)
    if prior_prob is not None:
        sim.mind_state.beliefs["disaster_prob"] = Belief(
            predicted=prior_prob, confidence=0.5, model_error=False,
            committed_values={},
        )
    return ScientistAgent(sim, capability=capability,
                          scientist_id=scientist_id or personality, seed=seed)


def _high_capability():
    # High personal capability: horizon reaches far → sees chaos coming.
    return {"tech_level": 6.0, "delta_0": 1e-4, "T_predict": 1000.0}


def _low_capability():
    # Low personal capability: horizon falls short → model_error.
    return {"tech_level": 0.0, "delta_0": 0.5, "T_predict": 0.5}


# ---------------------------------------------------------------------------
# Layer 1 — ScientistAgent observation precision
# ---------------------------------------------------------------------------


def test_observation_high_capability_sees_disaster():
    """High-capability scientist observes high disaster_prob when chaos is near."""
    kernel = StubKernel(next_chaos=10.0)
    f = ThreeBodyObservationFilter(kernel)
    sci = _make_scientist("理性", _high_capability())
    obs = sci.observe(f, {"t": 0.0, "next_chaos": 10.0})
    assert obs["model_error"] is False
    assert obs["disaster_prob"] >= 0.5


def test_observation_low_capability_misperceives():
    """Low-capability scientist commits to 'no chaos' → model_error (dramatic irony)."""
    kernel = StubKernel(next_chaos=10.0)
    f = ThreeBodyObservationFilter(kernel)
    sci = _make_scientist("理性", _low_capability())
    obs = sci.observe(f, {"t": 0.0, "next_chaos": 10.0})
    assert obs["model_error"] is True
    assert obs["disaster_prob"] < 0.5


def test_observation_no_chaos_ahead_is_zero():
    """When the kernel has no next chaotic era, disaster_prob is 0 and clean."""
    kernel = StubKernel(next_chaos=None)
    f = ThreeBodyObservationFilter(kernel)
    sci = _make_scientist("理性", _low_capability())
    obs = sci.observe(f, {"t": 0.0, "next_chaos": None})
    assert obs["disaster_prob"] == 0.0
    assert obs["model_error"] is False


def test_observation_reuses_cognitive_model_model_error():
    """The filter's model_error matches ThreeBodyCognitiveModel's flag exactly."""
    kernel = StubKernel(next_chaos=10.0)
    f = ThreeBodyObservationFilter(kernel)
    cognitive = ThreeBodyCognitiveModel(kernel)
    for cap in (_high_capability(), _low_capability()):
        obs = f.observe({"t": 0.0, "next_chaos": 10.0},
                        {"tech_level": cap["tech_level"],
                         "delta_0": cap["delta_0"],
                         "T_predict": cap["T_predict"]})
        belief = cognitive.predict(
            {"next_chaos": 10.0},
            {"tech_level": cap["tech_level"], "delta_0": cap["delta_0"],
             "T_predict": cap["T_predict"]},
            0.0,
        )
        assert obs["model_error"] == belief.model_error


# ---------------------------------------------------------------------------
# Layer 1 — belief-update three strategies on scientists
# ---------------------------------------------------------------------------


def test_rational_scientist_integrates_evidence():
    """A rational scientist moves their belief toward the disaster evidence."""
    # prior 0.2 (no disaster), observation high (0.9) → rational moves up.
    sci = _make_scientist("理性冷静", _high_capability(), prior_prob=0.2)
    posterior, trace = sci.update_belief(
        {"disaster_prob": 0.9, "model_error": False})
    assert trace.strategy == "rational"
    assert trace.accepted is True
    assert posterior.predicted > 0.2


def test_dogmatic_scientist_backfires_on_counter_evidence():
    """A stubborn scientist rejects counter-evidence → 教条强化 (backfire)."""
    # prior 0.2 (no disaster), observation 0.9 (disaster) contradicts →
    # dogmatic backfire: posterior moves AWAY from evidence, tagged
    # cognitive_bias.
    sci = _make_scientist("固执顽固", _low_capability(), prior_prob=0.2)
    posterior, trace = sci.update_belief(
        {"disaster_prob": 0.9, "model_error": False})
    assert trace.strategy == "dogmatic"
    assert trace.accepted is False
    assert trace.error_source == "cognitive_bias"
    # backfire: posterior should be below the prior (moved away from 0.9)
    assert posterior.predicted < 0.2


def test_conspiratorial_scientist_reinforces_under_contradiction():
    """A conspiratorial scientist strengthens prior under contradiction."""
    sci = _make_scientist("偏执多疑 阴谋", _high_capability(),
                          prior_prob=0.8)
    posterior, trace = sci.update_belief(
        {"disaster_prob": 0.2, "model_error": False})
    assert trace.strategy == "conspiratorial"
    assert trace.accepted is False
    assert trace.error_source == "cognitive_bias"


def test_misperceived_observation_tagged_perception_error():
    """An observation flagged model_error tags the trace perception_error."""
    sci = _make_scientist("理性", _low_capability(), prior_prob=0.5)
    _posterior, trace = sci.update_belief(
        {"disaster_prob": 0.1, "model_error": True})
    assert trace.error_source == "perception_error"


def test_proposal_thresholds():
    """Proposal maps belief → plan at the documented thresholds."""
    sci_low = _make_scientist("理性", _high_capability(), prior_prob=0.2)
    assert sci_low.propose() == PLAN_PERSIST
    sci_mid = _make_scientist("理性", _high_capability(), prior_prob=0.7)
    assert sci_mid.propose() == PLAN_DEHYDRATE
    sci_hi = _make_scientist("理性", _high_capability(), prior_prob=0.95)
    assert sci_hi.propose() == PLAN_EVACUATE


# ---------------------------------------------------------------------------
# Layer 2 — DecisionBody / org_decide rules
# ---------------------------------------------------------------------------


def _org_graph_with_leader(scientist_ids, leader_id="leader",
                           leader_trust_in_scientist=0.8):
    graph = CharacterGraph()
    org = Organization(
        org_id="civ",
        members=list(scientist_ids) + [leader_id],
        roles={leader_id: "leader"},
        decision_rule="vote",
        dictator_id=leader_id,
    )
    for sid in scientist_ids:
        graph.add_relationship(leader_id, sid,
                               trust=leader_trust_in_scientist)
        graph.add_relationship(sid, leader_id, trust=0.8)
    return graph, org


def test_dictator_one_person_decides():
    """Dictator rule: the dictator's vote wins regardless of others."""
    graph, org = _org_graph_with_leader(["s1", "s2"])
    org.decision_rule = "dictator"
    body = DecisionBody(org, graph)
    proposals = {"s1": PLAN_DEHYDRATE, "s2": PLAN_EVACUATE}
    decision, votes, _received = body.decide(proposals)
    # dictator (leader) is not a scientist; with high trust in s1 (first
    # sorted) the leader votes dehydrate
    assert decision == votes["leader"]
    assert decision in (PLAN_DEHYDRATE, PLAN_EVACUATE)


def test_consensus_requires_unanimity():
    """Consensus: all voting members must agree, else None (no decision)."""
    graph, org = _org_graph_with_leader(["s1", "s2"])
    org.decision_rule = "consensus"
    body = DecisionBody(org, graph)
    # scientists disagree → no consensus
    decision, _v, _r = body.decide({"s1": PLAN_DEHYDRATE, "s2": PLAN_PERSIST})
    assert decision is None


def test_consensus_when_all_agree():
    graph, org = _org_graph_with_leader(["s1", "s2"])
    org.decision_rule = "consensus"
    body = DecisionBody(org, graph)
    decision, _v, _r = body.decide({"s1": PLAN_DEHYDRATE, "s2": PLAN_DEHYDRATE})
    assert decision == PLAN_DEHYDRATE


def test_vote_majority_wins():
    """Vote rule: strict majority of cast votes wins."""
    graph, org = _org_graph_with_leader(["s1", "s2", "s3"])
    org.decision_rule = "vote"
    body = DecisionBody(org, graph)
    decision, _v, _r = body.decide(
        {"s1": PLAN_DEHYDRATE, "s2": PLAN_DEHYDRATE, "s3": PLAN_PERSIST})
    assert decision == PLAN_DEHYDRATE


def test_vote_tie_returns_none():
    """Vote rule: a 1-1 tie (two scientists, no leader) yields no decision."""
    graph = CharacterGraph()
    org = Organization(org_id="civ", members=["s1", "s2"],
                       decision_rule="vote")
    body = DecisionBody(org, graph)
    decision, _v, _r = body.decide(
        {"s1": PLAN_DEHYDRATE, "s2": PLAN_PERSIST})
    assert decision is None


# ---------------------------------------------------------------------------
# The canonical §5 example — leader distrust → disaster
# ---------------------------------------------------------------------------


def test_leader_distrust_blocks_proposal_persist_wins():
    """Leader distrusts scientist → proposal does not land → leader votes persist."""
    graph, org = _org_graph_with_leader(["s1"],
                                        leader_trust_in_scientist=-0.5)
    org.decision_rule = "dictator"
    body = DecisionBody(org, graph, trust_threshold=0.0)
    proposals = {"s1": PLAN_DEHYDRATE}
    decision, votes, received = body.decide(proposals)
    # leader distrusts s1 → s1's proposal not received → leader votes persist
    assert "s1" not in received["leader"]
    assert votes["leader"] == PLAN_PERSIST
    assert decision == PLAN_PERSIST


def test_leader_trust_lets_proposal_through():
    """Positive-leader-trust control: the proposal reaches the leader."""
    graph, org = _org_graph_with_leader(["s1"],
                                        leader_trust_in_scientist=0.8)
    org.decision_rule = "dictator"
    body = DecisionBody(org, graph, trust_threshold=0.0)
    proposals = {"s1": PLAN_DEHYDRATE}
    decision, votes, received = body.decide(proposals)
    assert "s1" in received["leader"]
    assert votes["leader"] == PLAN_DEHYDRATE
    assert decision == PLAN_DEHYDRATE


def test_full_distrust_pipeline_leads_to_destroyed_decision(monkeypatch):
    """§5 example end-to-end: distrust → persist → hoard → destroyed_decision.

    Uses a real baked kernel so the §8.2 verdict (destroyed_decision under
    imminent chaos + mismatched decision) is the genuine kernel branch, not
    a stub.
    """
    k = _real_kernel()
    chaotic = k.chaotic_era_intervals()
    if not chaotic:
        pytest.skip("bake produced no chaotic era")
    # Stand near the next chaos (imminent) with low civ tech so the horizon
    # cannot cover it (destroyed branch), and force the planet bound so
    # ejection does not preempt the decision branch.
    vantage = max(0.0, chaotic[0].start - 5.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)

    # One high-capability scientist sees the disaster and proposes a prepare plan.
    sci = _make_scientist("理性冷静", _high_capability(),
                          prior_prob=0.8, scientist_id="s1")
    # Leader distrusts the scientist.
    graph, org = _org_graph_with_leader(["s1"],
                                        leader_trust_in_scientist=-0.5)
    org.decision_rule = "dictator"
    body = DecisionBody(org, graph, trust_threshold=0.0)
    civ_agent = CivilizationAgent(k)

    sim = MultiScaleThreeBodySim(
        kernel=k, scientists={"s1": sci}, decision_body=body,
        civilization_agent=civ_agent, seed=7,
    )
    trace = sim.tick(t=vantage, civ_tech_level=0.0)

    # The scientist proposed a prepare plan, but the leader never received it.
    assert trace.proposals["s1"] in (PLAN_DEHYDRATE, PLAN_EVACUATE)
    assert "s1" not in trace.info_propagation["leader"]
    assert trace.org_decision == PLAN_PERSIST
    assert trace.decision_vector == PLAN_TO_DECISION_VECTOR[PLAN_PERSIST]
    # Kernel verdict: hoarding under imminent chaos → mismatched → destroyed_decision.
    assert trace.outcome_kind == "destroyed_decision"
    assert trace.civ_destroyed is True


# ---------------------------------------------------------------------------
# Layer 3 — CivilizationAgent → decision_vector → kernel
# ---------------------------------------------------------------------------


def test_civilization_agent_maps_each_plan_to_decision_vector():
    """Each plan maps to its decision_vector and is passed to the kernel."""
    kernel = StubKernel(next_chaos=10.0, outcomes=["survived"])
    agent = CivilizationAgent(kernel)
    for plan, expected_dv in PLAN_TO_DECISION_VECTOR.items():
        kernel.calls.clear()
        outcome, dv = agent.decide_outcome(plan, tech_level=1.0, t=0.0)
        assert dv == expected_dv
        assert kernel.calls[0]["decision_vector"] == expected_dv


def test_civilization_agent_none_decision_yields_none_vector():
    """An org that failed to decide → None decision_vector (kernel neutral branch)."""
    kernel = StubKernel(next_chaos=10.0, outcomes=["destroyed_chaos"])
    agent = CivilizationAgent(kernel)
    _outcome, dv = agent.decide_outcome(None, tech_level=1.0, t=0.0)
    assert dv is None
    assert kernel.calls[0]["decision_vector"] is None


# ---------------------------------------------------------------------------
# Multi-scale causal chain — CausalTrace structure
# ---------------------------------------------------------------------------


def test_causal_trace_has_full_chain_structure():
    """CausalTrace records every layer of the chain in order."""
    kernel = StubKernel(next_chaos=10.0, outcomes=["destroyed_chaos"])
    sci = _make_scientist("理性", _high_capability(), prior_prob=0.5,
                          scientist_id="s1")
    graph, org = _org_graph_with_leader(["s1"],
                                        leader_trust_in_scientist=0.8)
    org.decision_rule = "dictator"
    body = DecisionBody(org, graph)
    sim = MultiScaleThreeBodySim(
        kernel=kernel, scientists={"s1": sci}, decision_body=body,
        civilization_agent=CivilizationAgent(kernel), seed=3,
    )
    trace = sim.tick(t=0.0, civ_tech_level=0.0)

    # every layer populated
    assert "s1" in trace.scientist_observations
    assert "s1" in trace.belief_updates
    assert "s1" in trace.proposals
    assert trace.org_decision is not None
    assert trace.decision_vector is not None
    assert trace.outcome_kind == "destroyed_chaos"
    assert trace.civ_destroyed is True
    # reflux populated
    assert "s1" in trace.post_outcome_belief_updates
    assert trace.post_outcome_belief_updates["s1"]["evidence"] == 1.0


def test_causal_trace_as_dict_roundtrip():
    kernel = StubKernel(next_chaos=10.0, outcomes=["survived"])
    sci = _make_scientist("理性", _high_capability(), scientist_id="s1")
    graph, org = _org_graph_with_leader(["s1"])
    org.decision_rule = "dictator"
    body = DecisionBody(org, graph)
    sim = MultiScaleThreeBodySim(
        kernel=kernel, scientists={"s1": sci}, decision_body=body,
        civilization_agent=CivilizationAgent(kernel), seed=1,
    )
    trace = sim.tick(t=0.0, civ_tech_level=1.0)
    d = trace.as_dict()
    for key in ("t", "civ_tech_level", "scientist_observations",
                "belief_updates", "proposals", "member_votes",
                "info_propagation", "org_decision", "decision_vector",
                "outcome_kind", "outcome", "civ_destroyed",
                "post_outcome_belief_updates"):
        assert key in d


# ---------------------------------------------------------------------------
# Determinism + stable mistakes
# ---------------------------------------------------------------------------


def test_same_seed_reproduces_trace_exactly():
    """Same inputs → same CausalTrace (§8.2 determinism)."""
    def run():
        kernel = StubKernel(next_chaos=10.0, outcomes=["destroyed_chaos"])
        sci = _make_scientist("固执", _low_capability(), prior_prob=0.3,
                              scientist_id="s1", seed=42)
        graph, org = _org_graph_with_leader(["s1"])
        org.decision_rule = "dictator"
        body = DecisionBody(org, graph)
        sim = MultiScaleThreeBodySim(
            kernel=kernel, scientists={"s1": sci}, decision_body=body,
            civilization_agent=CivilizationAgent(kernel), seed=42,
        )
        return sim.tick(t=0.0, civ_tech_level=0.0)

    t1 = run()
    t2 = run()
    assert t1.as_dict() == t2.as_dict()


def test_stable_mistake_low_capability_scientist_persists():
    """A low-capability scientist deterministically misperceives → proposes persist.

    This is the stable-mistake property (§8.2): the same seed reproduces
    the *same* misprediction every time — not a random fluke.
    """
    def run_plan():
        kernel = StubKernel(next_chaos=10.0)
        f = ThreeBodyObservationFilter(kernel)
        sci = _make_scientist("理性", _low_capability(), seed=99)
        obs = sci.observe(f, {"t": 0.0, "next_chaos": 10.0})
        sci.update_belief(obs)
        return sci.propose(), obs["disaster_prob"]

    p1, prob1 = run_plan()
    p2, prob2 = run_plan()
    assert p1 == p2 == PLAN_PERSIST   # misperceived → no disaster → persist
    assert prob1 == prob2             # identical misperception
    assert prob1 < 0.5                # the mistake: real chaos is coming


def test_dogmatic_reinforcement_survives_destruction():
    """A dogmatic scientist reinforces 'no disaster' even when destroyed.

    Post-outcome reflux feeds disaster=1.0 evidence; the dogmatic strategy
    backfires → posterior moves further from 1.0 (toward 'no disaster'),
    the 教条强化 effect.
    """
    kernel = StubKernel(next_chaos=10.0, outcomes=["destroyed_chaos"])
    sci = _make_scientist("固执顽固", _low_capability(), prior_prob=0.15,
                          scientist_id="s1", seed=5)
    graph, org = _org_graph_with_leader(["s1"])
    org.decision_rule = "dictator"
    body = DecisionBody(org, graph)
    sim = MultiScaleThreeBodySim(
        kernel=kernel, scientists={"s1": sci}, decision_body=body,
        civilization_agent=CivilizationAgent(kernel), seed=5,
    )
    trace = sim.tick(t=0.0, civ_tech_level=0.0)
    reflux = trace.post_outcome_belief_updates["s1"]
    assert reflux["strategy"] == "dogmatic"
    assert reflux["accepted"] is False
    # posterior should be below the prior 0.15 (moved away from evidence 1.0)
    assert reflux["posterior"]["predicted"] < 0.15


# ---------------------------------------------------------------------------
# Integration — real baked kernel, full pipeline
# ---------------------------------------------------------------------------


def _real_kernel(years: float = 600.0, seed: int = 42) -> ThreeBodyKernel:
    """Bake a real kernel with at least one chaotic era (mirrors existing tests)."""
    k = ThreeBodyKernel(seed=seed, dt=0.02,
                        lyapunov_renorms=8, lyapunov_renorm_steps=80)
    k.bake(years=years)
    return k


def test_integration_real_kernel_aligned_decision_survives(monkeypatch):
    """High civ tech + aligned dehydrate decision → survived (real kernel)."""
    k = _real_kernel()
    chaotic = k.chaotic_era_intervals()
    if not chaotic:
        pytest.skip("bake produced no chaotic era")
    vantage = max(0.0, chaotic[0].start - 1.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)

    sci = _make_scientist("理性冷静", _high_capability(), prior_prob=0.9,
                          scientist_id="s1")
    graph, org = _org_graph_with_leader(["s1"],
                                        leader_trust_in_scientist=0.9)
    org.decision_rule = "dictator"
    body = DecisionBody(org, graph)
    sim = MultiScaleThreeBodySim(
        kernel=k, scientists={"s1": sci}, decision_body=body,
        civilization_agent=CivilizationAgent(k), seed=11,
    )
    trace = sim.tick(t=vantage, civ_tech_level=10.0)
    # high civ tech → horizon covers → survived regardless of decision
    assert trace.outcome_kind == "survived"
    assert trace.civ_destroyed is False


def test_integration_real_kernel_distrust_disaster(monkeypatch):
    """Real-kernel replay of the §5 distrust→disaster example."""
    k = _real_kernel()
    chaotic = k.chaotic_era_intervals()
    if not chaotic:
        pytest.skip("bake produced no chaotic era")
    vantage = max(0.0, chaotic[0].start - 5.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)

    sci = _make_scientist("理性冷静", _high_capability(), prior_prob=0.8,
                          scientist_id="s1")
    graph, org = _org_graph_with_leader(["s1"],
                                        leader_trust_in_scientist=-0.5)
    org.decision_rule = "dictator"
    body = DecisionBody(org, graph, trust_threshold=0.0)
    sim = MultiScaleThreeBodySim(
        kernel=k, scientists={"s1": sci}, decision_body=body,
        civilization_agent=CivilizationAgent(k), seed=13,
    )
    trace = sim.tick(t=vantage, civ_tech_level=0.0)
    assert trace.org_decision == PLAN_PERSIST
    assert trace.outcome_kind == "destroyed_decision"
