"""Tests for the idle loop (spec §13.4): the world advances itself during player
silence, honours a saturation cap, resets on activity, and produces a regression
summary. The silence timer is delegated to the orchestrator's
``seconds_since_activity`` (one shared idle timer, 调研① 方案 A); this loop owns
only the saturation counter.
"""

from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.idle_loop import IdleLoop  # noqa: E402


# -- fakes -------------------------------------------------------------------

class FakeEntry:
    def __init__(self, title, content):
        self.title = title
        self.content = content


class FakeSnapshot:
    def __init__(self, worldbook):
        self.worldbook = worldbook


class FakeStore:
    def __init__(self, worldbook):
        self._worldbook = worldbook

    def snapshot(self):
        return FakeSnapshot(list(self._worldbook))


class FakeOrchestrator:
    """Records set_world/world_tick calls; world_tick returns a numbered beat.

    Exposes ``seconds_since_activity`` so the IdleLoop can delegate its silence
    timer here (single source of truth, 调研① 方案 A).
    """

    def __init__(self, worldbook=None, idle_seconds=0.0):
        self.state_store = FakeStore(worldbook or [])
        self.set_world_calls = []
        self.tick_count = 0
        self._idle_seconds = idle_seconds

    def set_world(self, world_id):
        self.set_world_calls.append(world_id)

    def world_tick(self):
        self.tick_count += 1
        return f"beat_{self.tick_count}"

    def seconds_since_activity(self):
        return self._idle_seconds

    def set_idle(self, seconds):
        self._idle_seconds = seconds


# -- silence triggers advance ------------------------------------------------

def test_silence_past_threshold_advances():
    orch = FakeOrchestrator(idle_seconds=31)
    loop = IdleLoop(orch, "main", idle_threshold=30)

    result = loop.tick()

    assert result == "beat_1"
    assert orch.tick_count == 1
    assert loop.advances_count == 1
    assert orch.set_world_calls == ["main"]


def test_below_threshold_does_not_advance():
    orch = FakeOrchestrator(idle_seconds=29)
    loop = IdleLoop(orch, "main", idle_threshold=30)

    result = loop.tick()

    assert result is None
    assert orch.tick_count == 0
    assert loop.advances_count == 0


# -- activity resets ---------------------------------------------------------

def test_user_activity_resets_counter():
    # The silence *timer* is owned by the orchestrator; on_user_activity only
    # resets the saturation counter (调研① 方案 A).
    orch = FakeOrchestrator(idle_seconds=31)
    loop = IdleLoop(orch, "main", idle_threshold=30)

    loop.tick()
    assert loop.advances_count == 1

    loop.on_user_activity()
    assert loop.advances_count == 0

    # Right after activity the orchestrator reports fresh activity: no advance.
    orch.set_idle(0)
    assert loop.tick() is None
    # Silence again → advances resume from a clean slate.
    orch.set_idle(31)
    assert loop.tick() == "beat_2"
    assert loop.advances_count == 1


def test_seconds_idle_delegates_to_orchestrator():
    orch = FakeOrchestrator(idle_seconds=42)
    loop = IdleLoop(orch, "main", idle_threshold=30)
    assert loop.seconds_idle() == 42
    orch.set_idle(100)
    assert loop.seconds_idle() == 100


# -- saturation cap ----------------------------------------------------------

def test_saturation_cap_stops_advancing():
    orch = FakeOrchestrator(idle_seconds=31)
    loop = IdleLoop(orch, "main", idle_threshold=30, max_advances=3)

    for _ in range(10):
        loop.tick()  # stays well past the threshold each round

    assert loop.advances_count == 3
    assert orch.tick_count == 3
    # The cap holds even with more silence.
    orch.set_idle(1000)
    assert loop.tick() is None
    assert orch.tick_count == 3


def test_cap_lifts_after_activity():
    orch = FakeOrchestrator(idle_seconds=31)
    loop = IdleLoop(orch, "main", idle_threshold=30, max_advances=2)

    loop.tick()
    loop.tick()
    assert loop.tick() is None  # saturated

    loop.on_user_activity()
    assert loop.tick() == "beat_3"
    assert loop.advances_count == 1


# -- offline summary ---------------------------------------------------------

def test_offline_summary_calls_llm_with_recent_entries():
    worldbook = [
        FakeEntry("清晨", "村庄醒来"),
        FakeEntry("正午", "商人抵达"),
        FakeEntry("黄昏", "篝火点起"),
    ]
    orch = FakeOrchestrator(worldbook)
    loop = IdleLoop(orch, "main")

    captured = {}

    def fake_llm(prompt):
        captured["prompt"] = prompt
        return "你离开时发生了很多事。"

    summary = loop.offline_summary(fake_llm)

    assert summary == "你离开时发生了很多事。"
    # The prompt carries the recent worldbook content and re-points the world.
    assert "村庄醒来" in captured["prompt"]
    assert "篝火点起" in captured["prompt"]
    assert orch.set_world_calls == ["main"]


def test_offline_summary_respects_max_entries():
    worldbook = [FakeEntry(f"t{i}", f"c{i}") for i in range(10)]
    orch = FakeOrchestrator(worldbook)
    loop = IdleLoop(orch, "main")

    captured = {}

    def fake_llm(prompt):
        captured["prompt"] = prompt
        return "ok"

    loop.offline_summary(fake_llm, max_entries=2)

    # Only the last two entries appear; earlier ones are excluded.
    assert "c9" in captured["prompt"]
    assert "c8" in captured["prompt"]
    assert "c7" not in captured["prompt"]


def test_offline_summary_empty_worldbook_returns_empty():
    orch = FakeOrchestrator([])
    loop = IdleLoop(orch, "main")

    called = []
    summary = loop.offline_summary(lambda p: called.append(p) or "x")

    assert summary == ""
    assert called == []  # llm not invoked when there is nothing to report
