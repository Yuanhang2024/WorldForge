"""Tests for backend.theater.rule_generator (LLM-driven DSL generator).

Covers:
  - No LLM → RuntimeError (preset fallback removed).
  - LLM returns valid DSL JSON → parsed + compiled.
  - LLM returns malformed/illegal DSL → RuntimeError (no fallback).
  - Generated specs validate via RuleCompiler.validate_spec (no errors).
  - Generated specs compile via RuleCompiler.compile (no exceptions).
  - Determinism: same input with same llm_fn → identical spec across calls.
  - System prompt mentions whitelist + key constraints (LLM guardrails).

Run with::

    PYTHONPATH=backend python -m pytest tests/test_rule_generator.py -q
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, List

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.rule_generator import RuleGenerator
from theater.world_kernel_host import (
    RuleCompiler,
    WorldKernelHost,
    WorldKernelSpec,
    WorldRule,
)


# =====================================================================
# Helpers
# =====================================================================


def _valid_economy_spec_dict() -> Dict[str, Any]:
    """A minimal, *valid* rule DSL as the LLM would emit it."""
    return {
        "world_type": "llm_economy",
        "rules": [
            {
                "rule_id": "llm_price_inflate",
                "kind": "dynamic",
                "trigger": "trade.executed",
                "condition": {
                    "op": "gt",
                    "args": [{"ref": "demand"}, {"ref": "supply"}],
                },
                "effect": {
                    "op": "writes",
                    "changes": [{
                        "path": "price",
                        "value": {"op": "add",
                                  "args": [{"ref": "price"}, {"const": 0.2}]},
                    }],
                },
                "description": "demand>supply → price up (LLM-proposed)",
                "priority": 10,
            },
            {
                "rule_id": "llm_price_floor",
                "kind": "invariant",
                "trigger": None,
                "effect": {
                    "op": "predicate",
                    "expr": {"op": "ge",
                             "args": [{"ref": "price"}, {"const": 0}]},
                },
                "description": "price non-negative",
                "priority": 100,
            },
        ],
        "params": {"seed": 7},
    }


def _mock_llm_factory(raw_outputs: List[str]):
    """Build an llm_fn that returns raw_outputs in order (one per call)."""
    iterator = iter(raw_outputs)

    def _fn(prompt: str) -> str:
        return next(iterator)

    return _fn


# =====================================================================
# No-LLM raises
# =====================================================================


class TestNoLLMRaises:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_generate_without_llm_raises(self) -> None:
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            self.gen.generate("供需决定价格")

    def test_empty_description_without_llm_raises(self) -> None:
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            self.gen.generate("")

    def test_none_description_without_llm_raises(self) -> None:
        with pytest.raises(RuntimeError, match="requires llm_fn"):
            self.gen.generate(None)  # type: ignore[arg-type]


# =====================================================================
# Generated specs validate + compile (via mock LLM)
# =====================================================================


class TestGeneratedSpecValidates:
    @pytest.mark.parametrize("description", [
        "经济世界：供需与价格",
        "physical simulation under gravity",
        "social relationships drive influence",
        "a card game scoring ruleset",
        "completely abstract world",
    ])
    def test_mock_llm_spec_validates_and_compiles(self, description: str) -> None:
        gen = RuleGenerator()
        raw = json.dumps(_valid_economy_spec_dict())
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate(description, llm_fn=llm_fn)
        # validate_spec: no errors
        issues = RuleCompiler().validate_spec(spec)
        assert issues == [], f"validation issues for {description!r}: {issues}"
        # compile: no exception
        kernel = RuleCompiler(seed=0).compile(spec)
        assert kernel.world_type == spec.world_type
        assert len(kernel.rule_ids()) == len(spec.rules)


# =====================================================================
# Determinism (same llm_fn → same spec)
# =====================================================================


class TestDeterminism:
    def test_same_input_same_spec(self) -> None:
        gen = RuleGenerator()
        raw = json.dumps(_valid_economy_spec_dict())
        a = gen.generate("供需决定价格的市集", llm_fn=_mock_llm_factory([raw]))
        b = gen.generate("供需决定价格的市集", llm_fn=_mock_llm_factory([raw]))
        assert a.world_type == b.world_type
        assert {r.rule_id for r in a.rules} == {r.rule_id for r in b.rules}
        # Spec bodies must be byte-identical for true determinism.
        assert json.dumps(a.params, sort_keys=True) == json.dumps(b.params, sort_keys=True)


# =====================================================================
# LLM-driven path (with mocks)
# =====================================================================


class TestLLMDrivenGeneration:
    def test_valid_json_parsed_and_used(self) -> None:
        gen = RuleGenerator()
        raw = json.dumps(_valid_economy_spec_dict())
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate("whatever", llm_fn=llm_fn)
        assert spec.world_type == "llm_economy"
        assert {r.rule_id for r in spec.rules} == {
            "llm_price_inflate", "llm_price_floor",
        }

    def test_json_in_code_fence_parsed(self) -> None:
        gen = RuleGenerator()
        raw = "```json\n" + json.dumps(_valid_economy_spec_dict()) + "\n```"
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate("anything", llm_fn=llm_fn)
        assert spec.world_type == "llm_economy"

    def test_json_with_prose_around_it_parsed(self) -> None:
        gen = RuleGenerator()
        body = json.dumps(_valid_economy_spec_dict())
        raw = "Here is the spec:\n" + body + "\nDone."
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate("anything", llm_fn=llm_fn)
        assert spec.world_type == "llm_economy"

    def test_invalid_op_raises(self) -> None:
        gen = RuleGenerator()
        # LLM emits an evil rule using op="eval" (must be rejected).
        bad = _valid_economy_spec_dict()
        bad["rules"][0]["condition"] = {"op": "eval", "args": [{"const": 1}]}
        raw = json.dumps(bad)
        llm_fn = _mock_llm_factory([raw])
        with pytest.raises(RuntimeError, match="LLM generation failed"):
            gen.generate("经济世界", llm_fn=llm_fn)

    def test_malformed_json_raises(self) -> None:
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory(["this is not json at all {{{"])
        with pytest.raises(RuntimeError, match="LLM generation failed"):
            gen.generate("gravity", llm_fn=llm_fn)

    def test_empty_llm_output_raises(self) -> None:
        gen = RuleGenerator()
        llm_fn = _mock_llm_factory([""])
        with pytest.raises(RuntimeError, match="LLM generation failed"):
            gen.generate("social", llm_fn=llm_fn)

    def test_llm_exception_raises(self) -> None:
        gen = RuleGenerator()
        calls = 0

        def _explode(prompt: str) -> str:
            nonlocal calls
            calls += 1
            raise RuntimeError("LLM down")

        with pytest.raises(RuntimeError, match="LLM generation failed"):
            gen.generate("card game rules", llm_fn=_explode)
        assert calls == 1

    def test_validation_failure_reprompts_with_rejected_json(self) -> None:
        gen = RuleGenerator()
        invalid = _valid_economy_spec_dict()
        invalid["rules"][0]["condition"] = {
            "op": "and",
            "args": [
                {"const": True},
                {"const": True},
                {"const": True},
            ],
        }
        valid = _valid_economy_spec_dict()
        prompts: List[str] = []
        replies = iter((json.dumps(invalid), json.dumps(valid)))

        def _repairing_llm(prompt: str) -> str:
            prompts.append(prompt)
            return next(replies)

        spec = gen.generate("floating laboratory", llm_fn=_repairing_llm)
        assert spec.world_type == "llm_economy"
        assert len(prompts) == 2
        assert "and needs 2 args" in prompts[1]
        assert '"world_type": "llm_economy"' in prompts[1]

    def test_llm_output_validates_and_compiles(self) -> None:
        gen = RuleGenerator()
        raw = json.dumps(_valid_economy_spec_dict())
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate("anything", llm_fn=llm_fn)
        issues = RuleCompiler().validate_spec(spec)
        assert issues == []
        kernel = RuleCompiler(seed=0).compile(spec)
        assert kernel.world_type == "llm_economy"
        # And we can actually host it.
        host = WorldKernelHost(
            spec,
            {"demand": 10, "supply": 5, "price": 1.0},
            seed=0,
        )
        changes = host.step({"trigger": "trade.executed"})
        assert any(c["path"] == "price" for c in changes)

    def test_llm_invariant_with_trigger_auto_repaired(self) -> None:
        """An invariant rule MUST have trigger=None.

        The generator now auto-fixes this (repaired to None) instead of
        falling back — see ``_repair_spec``.
        """
        gen = RuleGenerator()
        bad = _valid_economy_spec_dict()
        bad["rules"][1]["kind"] = "invariant"
        bad["rules"][1]["trigger"] = "should_be_none"
        raw = json.dumps(bad)
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate("anything", llm_fn=llm_fn)
        # Auto-fixed: spec used (not fallback).
        assert spec.world_type == "llm_economy"
        for r in spec.rules:
            if r.kind == "invariant":
                assert r.trigger is None

    def test_llm_missing_rule_id_raises(self) -> None:
        gen = RuleGenerator()
        bad = _valid_economy_spec_dict()
        del bad["rules"][0]["rule_id"]
        raw = json.dumps(bad)
        llm_fn = _mock_llm_factory([raw])
        with pytest.raises(RuntimeError, match="LLM generation failed"):
            gen.generate("gravity", llm_fn=llm_fn)


# =====================================================================
# System prompt guardrails (LLM is told the constraints)
# =====================================================================


class TestSystemPromptGuardrails:
    def test_system_prompt_mentions_whitelist(self) -> None:
        gen = RuleGenerator()
        prompt = gen._build_system_prompt()
        # The op whitelist must be present so LLM knows what it can emit.
        for op in ("add", "sub", "mul", "div", "lt", "gt", "eq",
                   "and", "or", "not", "lookup"):
            assert op in prompt, f"whitelist op {op!r} missing from system prompt"

    def test_system_prompt_forbids_eval_exec(self) -> None:
        gen = RuleGenerator()
        prompt = gen._build_system_prompt()
        # The LLM must be told eval/exec are forbidden.
        assert "eval" in prompt.lower() or "eval/exec" in prompt.lower()

    def test_system_prompt_states_separation_of_powers(self) -> None:
        """The LLM is told it does NOT decide results (I2)."""
        gen = RuleGenerator()
        prompt = gen._build_system_prompt()
        # The I2 separation-of-powers message must be present.
        assert "司法" in prompt or "result" in prompt.lower()
        # Invariants documented.
        assert "invariant" in prompt
        assert "predicate" in prompt

    def test_system_prompt_documents_effect_shapes(self) -> None:
        gen = RuleGenerator()
        prompt = gen._build_system_prompt()
        assert "writes" in prompt
        assert "predicate" in prompt
        assert "emit_event" in prompt


# =====================================================================
# Integration: generated spec runs in WorldKernelHost
# =====================================================================


class TestGeneratedSpecRunsInHost:
    def test_llm_generated_spec_walks_several_turns(self) -> None:
        gen = RuleGenerator()
        raw = json.dumps(_valid_economy_spec_dict())
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate("economic world", llm_fn=llm_fn)
        host = WorldKernelHost(
            spec,
            {
                "demand": 120,
                "supply": 100,
                "price": 1.0,
            },
            seed=42,
        )
        for _ in range(3):
            host.step({"trigger": "trade.executed"})
        assert host.check_invariants() == []
        # Determinism: re-run with same seed, same state.
        host2 = WorldKernelHost(
            spec,
            {
                "demand": 120,
                "supply": 100,
                "price": 1.0,
            },
            seed=42,
        )
        for _ in range(3):
            host2.step({"trigger": "trade.executed"})
        assert host.state() == host2.state()

    def test_llm_generated_spec_runs_in_host(self) -> None:
        gen = RuleGenerator()
        raw = json.dumps(_valid_economy_spec_dict())
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate("LLM world", llm_fn=llm_fn)
        host = WorldKernelHost(
            spec,
            {"demand": 10, "supply": 5, "price": 1.0},
            seed=0,
        )
        # demand > supply → inflate fires.
        changes = host.step({"trigger": "trade.executed"})
        assert host.query("price") == pytest.approx(1.2)


# =====================================================================
# Edge cases
# =====================================================================


class TestEdgeCases:
    def test_rule_generator_rejects_unknown_kind_in_dict(self) -> None:
        gen = RuleGenerator()
        bad = _valid_economy_spec_dict()
        bad["rules"][0]["kind"] = "nonsense"
        raw = json.dumps(bad)
        llm_fn = _mock_llm_factory([raw])
        with pytest.raises(RuntimeError, match="LLM generation failed"):
            gen.generate("经济", llm_fn=llm_fn)

    def test_dynamic_rule_without_trigger_auto_repaired(self) -> None:
        """A dynamic rule without a trigger is now auto-filled with ``turn.tick``
        via ``_repair_spec`` rather than falling back.
        """
        gen = RuleGenerator()
        bad = _valid_economy_spec_dict()
        bad["rules"][0]["trigger"] = None  # dynamic needs a trigger
        raw = json.dumps(bad)
        llm_fn = _mock_llm_factory([raw])
        spec = gen.generate("anything", llm_fn=llm_fn)
        assert spec.world_type == "llm_economy"
        assert spec.rules[0].trigger == "turn.tick"

    def test_custom_keyword_routing_is_rejected(self) -> None:
        with pytest.raises(ValueError, match="keyword routing was removed"):
            RuleGenerator(
                preset_map={"custom_zen": ["zen", "garden", "whisper"]},
            )
