"""Tests for the unified `create_character` entry point (manual / auto / mixed).

These are the onboarding stage-2 paths: manual direct-fill, auto (existing
description→LLM flow), and mixed (user fields + LLM completion). All tests
run offline with fake/stub model clients — no Spark dependency.
"""
import tempfile
import unittest
from pathlib import Path

from theater.agents import DeterministicModelClient
from theater.dispatcher import TheaterOrchestrator
from theater.gates import ScienceDirectorGate
from theater.models import ScienceApproval
from theater.storage import JsonStateStore


class _RecordingModelClient(DeterministicModelClient):
    """Offline model client that records card calls and returns a known card."""

    def __init__(self):
        super().__init__()
        self.card_calls = 0
        self.last_description = None

    def complete_character_card(self, description, model):
        self.card_calls += 1
        self.last_description = description
        return {
            "name": "LLM旅者",
            "summary": "LLM生成的旅者摘要",
            "personality": "LLM性格：沉默寡言",
            "appearance": "LLM外貌：深色斗篷",
            "sample_line": "LLM台词：这条路我走过。",
            "warnings": ["deterministic stub"],
            "provider_model": model,
        }


class _NeverCalledModelClient(DeterministicModelClient):
    """Model client whose card path must never run (manual mode)."""

    def complete_character_card(self, description, model):
        raise AssertionError("manual mode must not call complete_character_card")


class _FailingModelClient(DeterministicModelClient):
    def complete_character_card(self, description, model):
        raise RuntimeError("model unavailable")


def _build_orchestrator(root: Path, model_client=None):
    return TheaterOrchestrator(
        state_store=JsonStateStore(root / "state"),
        model_client=model_client or DeterministicModelClient(),
    )


class ManualModeTests(unittest.TestCase):
    def test_minimal_name_only_saves_without_llm(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            orch = _build_orchestrator(root, model_client=_NeverCalledModelClient())
            result = orch.create_character(mode="manual", fields={"name": "阿星"})
            self.assertTrue(result["ok"])
            self.assertTrue(result["character_id"])
            char = result["character"]
            self.assertEqual(char["name"], "阿星")
            self.assertTrue(char["summary"])  # auto-derived from name
            self.assertEqual(char["source"], "manual")
            self.assertEqual(char["appearance"], "")
            # persisted
            ids = {c.character_id for c in orch.state_store.snapshot().characters}
            self.assertIn(result["character_id"], ids)

    def test_missing_name_fails(self):
        with tempfile.TemporaryDirectory() as d:
            orch = _build_orchestrator(Path(d))
            result = orch.create_character(mode="manual", fields={"personality": "冷酷"})
            self.assertFalse(result["ok"])
            self.assertIn("name", result["error"])

    def test_full_text_fields_preserved(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            orch = _build_orchestrator(root)
            fields = {
                "name": "铁匠",
                "summary": "一个老铁匠",
                "personality": "沉默坚毅",
                "appearance": "右眼有疤",
                "sample_line": "打铁就是打命。",
            }
            result = orch.create_character(mode="manual", fields=fields, character_id="smith")
            self.assertTrue(result["ok"])
            char = result["character"]
            self.assertEqual(char["character_id"], "smith")
            self.assertEqual(char["personality"], "沉默坚毅")
            self.assertEqual(char["appearance"], "右眼有疤")
            self.assertEqual(char["sample_line"], "打铁就是打命。")


class AutoModeTests(unittest.TestCase):
    def test_auto_via_create_character_is_wrapper(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            model = _RecordingModelClient()
            orch = _build_orchestrator(root, model_client=model)
            result = orch.create_character(
                mode="auto", description="一个沉默寡言的老铁匠", character_id="smith",
            )
            self.assertTrue(result["ok"])
            self.assertEqual(model.card_calls, 1)
            self.assertEqual(result["character"]["character_id"], "smith")

    def test_auto_empty_description_fails(self):
        with tempfile.TemporaryDirectory() as d:
            orch = _build_orchestrator(Path(d))
            result = orch.create_character(mode="auto", description="   ")
            self.assertFalse(result["ok"])


class MixedModeTests(unittest.TestCase):
    def test_complete_fields_save_without_calling_llm(self):
        with tempfile.TemporaryDirectory() as d:
            fields = {
                "name": "铁匠",
                "summary": "一个老铁匠",
                "personality": "沉默坚毅",
                "appearance": "右眼有疤",
                "sample_line": "打铁就是打命。",
            }
            orch = _build_orchestrator(
                Path(d), model_client=_NeverCalledModelClient()
            )
            result = orch.create_character(mode="mixed", fields=fields)

            self.assertTrue(result["ok"])
            self.assertEqual(result["llm_filled_fields"], [])
            self.assertEqual(result["character"]["source"], "manual")

    def test_user_personality_not_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            model = _RecordingModelClient()
            orch = _build_orchestrator(root, model_client=model)
            result = orch.create_character(
                mode="mixed",
                description="一位冷酷剑客",
                fields={"name": "kenji", "personality": "冷酷无情"},
                character_id="kenji",
            )
            self.assertTrue(result["ok"])
            char = result["character"]
            # user-supplied personality preserved
            self.assertEqual(char["personality"], "冷酷无情")
            # user-supplied name preserved
            self.assertEqual(char["name"], "kenji")
            # LLM filled appearance (user omitted it)
            self.assertEqual(char["appearance"], "LLM外貌：深色斗篷")

    def test_llm_filled_fields_reported(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            model = _RecordingModelClient()
            orch = _build_orchestrator(root, model_client=model)
            result = orch.create_character(
                mode="mixed",
                description="一位剑客",
                fields={"name": "kenji", "personality": "冷酷"},
            )
            self.assertTrue(result["ok"])
            filled = set(result["llm_filled_fields"])
            # user supplied name + personality → those are NOT in llm_filled
            self.assertNotIn("name", filled)
            self.assertNotIn("personality", filled)
            # appearance/sample_line were filled by LLM
            self.assertIn("appearance", filled)
            self.assertIn("sample_line", filled)

    def test_mixed_requires_description(self):
        with tempfile.TemporaryDirectory() as d:
            orch = _build_orchestrator(Path(d))
            result = orch.create_character(mode="mixed", fields={"name": "x"})
            self.assertFalse(result["ok"])
            self.assertIn("description", result["error"])

    def test_missing_fields_reject_model_failure(self):
        with tempfile.TemporaryDirectory() as d:
            orch = _build_orchestrator(
                Path(d), model_client=_FailingModelClient()
            )
            result = orch.create_character(
                mode="mixed",
                description="一位剑客",
                fields={"name": "kenji"},
            )
            self.assertFalse(result["ok"])
            self.assertIn("failed", result["error"])


class GateAndErrorTests(unittest.TestCase):
    def test_science_gate_rejection_returns_not_ok(self):
        class _RejectingGate(ScienceDirectorGate):
            def validate_write(self, world_patches, character_patches):
                return ScienceApproval(approved=False, director_id="science_director",
                                       reasons=["stub rejection"])

        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            orch = _build_orchestrator(root, model_client=_RecordingModelClient())
            orch.science_gate = _RejectingGate()
            result = orch.create_character(mode="manual", fields={"name": "被拒者"})
            self.assertFalse(result["ok"])
            self.assertIn("stub rejection", result["reasons"])

    def test_unknown_mode_returns_error(self):
        with tempfile.TemporaryDirectory() as d:
            orch = _build_orchestrator(Path(d))
            result = orch.create_character(mode="bogus", fields={"name": "x"})
            self.assertFalse(result["ok"])
            self.assertIn("unknown mode", result["error"])

    def test_manual_character_id_override(self):
        with tempfile.TemporaryDirectory() as d:
            orch = _build_orchestrator(Path(d), model_client=_NeverCalledModelClient())
            result = orch.create_character(
                mode="manual", fields={"name": "阿星"}, character_id="custom_id",
            )
            self.assertTrue(result["ok"])
            self.assertEqual(result["character_id"], "custom_id")


if __name__ == "__main__":
    unittest.main()
