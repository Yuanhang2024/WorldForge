"""Tests for backend.theater.cognitive_model_generator (Q7 — LLM cognitive-model generation).

Covers the generate → validate → repair → fallback pipeline and the five
hard validator gates:

  - LLM returns valid spec → source="llm", repairs=0
  - LLM returns invalid spec → repair succeeds → source="llm", repairs=1
  - LLM returns invalid spec, repair fails → source="fallback"
  - no llm_fn → straight preset fallback (keyword matching)
  - Validator five gates each pass/fail on crafted inputs
  - to_cognitive_model produces a protocol-conformant, deterministic model
  - ≥3 world presets (three-body / economy / politics) carry world-specific
    failure_modes (误判结构 世界特异性)

Uses fake/stub llm_fn; no real Spark dependency.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_cognitive_model_generator.py -q
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, List

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.cognitive_model import Belief, CognitiveModel
from theater.cognitive_model_generator import (  # noqa: E402
    CMGenerationResult,
    CMValidationReport,
    CognitiveModelGenerator,
    CognitiveModelSpec,
    CognitiveModelValidator,
    PRESET_SPECS,
    match_preset,
)


# =====================================================================
# Fixtures / helpers
# =====================================================================


def _three_body_spec_dict() -> Dict[str, Any]:
    """A valid CognitiveModelSpec dict (three-body shape) that passes all gates."""
    return PRESET_SPECS["three_body"].to_dict()


def _make_llm_valid() -> "callable":
    """A fake llm_fn that returns a valid three-body spec JSON."""
    payload = json.dumps(_three_body_spec_dict(), ensure_ascii=False)

    def _fn(prompt: str) -> str:
        return payload
    return _fn


def _make_llm_invalid_then_valid() -> "callable":
    """Fake llm_fn: first call returns an invalid spec (bad op), then a valid one."""
    bad = json.dumps(_three_body_spec_dict(), ensure_ascii=False)
    bad_obj = json.loads(bad)
    # Inject a non-whitelisted op into model_error_expr.
    bad_obj["prediction_template"]["model_error_expr"] = {
        "op": "random", "args": [{"const": 0}, {"const": 1}]
    }
    bad_payload = json.dumps(bad_obj, ensure_ascii=False)
    good_payload = json.dumps(_three_body_spec_dict(), ensure_ascii=False)
    calls = {"n": 0}

    def _fn(prompt: str) -> str:
        calls["n"] += 1
        if calls["n"] == 1:
            return bad_payload
        return good_payload
    return _fn


def _make_llm_always_invalid() -> "callable":
    """Fake llm_fn that always returns a spec using a non-whitelisted op."""
    bad_obj = json.loads(json.dumps(_three_body_spec_dict(), ensure_ascii=False))
    bad_obj["prediction_template"]["predicted_expr"] = {
        "op": "random_in_range", "args": [{"const": 0}, {"const": 10}]
    }
    bad_payload = json.dumps(bad_obj, ensure_ascii=False)

    def _fn(prompt: str) -> str:
        return bad_payload
    return _fn


def _make_llm_unparseable() -> "callable":
    def _fn(prompt: str) -> str:
        return "this is not json at all"
    return _fn


# =====================================================================
# Validator — five gates, each pass/fail
# =====================================================================


def test_validator_passes_three_body_preset():
    v = CognitiveModelValidator()
    rep = v.validate_all(PRESET_SPECS["three_body"])
    assert isinstance(rep, CMValidationReport)
    assert rep.passed is True
    assert rep.reasons == []
    assert set(rep.checks.keys()) == {
        "compiles", "deterministic", "observable_subset",
        "failure_modes_plausible", "compiles_to_protocol",
    }


def test_validator_passes_economy_and_politics_presets():
    v = CognitiveModelValidator()
    for name in ("economy", "politics"):
        rep = v.validate_all(PRESET_SPECS[name])
        assert rep.passed is True, f"{name}: {rep.reasons}"


# --- CHECK 1: compiles -------------------------------------------------

def test_check_compiles_fails_on_missing_truth_variables():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.world_schema = {"world_type": "x", "description": "x"}  # no truth_variables
    r = CognitiveModelValidator().check_compiles(spec)
    assert r.passed is False
    assert "truth_variables" in r.reason


def test_check_compiles_fails_on_missing_template_expr():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    del spec.prediction_template["predicted_expr"]
    r = CognitiveModelValidator().check_compiles(spec)
    assert r.passed is False
    assert "predicted_expr" in r.reason


def test_check_compiles_fails_on_non_whitelisted_op():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.prediction_template["confidence_expr"] = {
        "op": "random", "args": [{"const": 0}, {"const": 1}]
    }
    r = CognitiveModelValidator().check_compiles(spec)
    assert r.passed is False
    assert "non-whitelisted" in r.reason


def test_check_compiles_fails_on_empty_agent_role():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.agent_role = ""
    r = CognitiveModelValidator().check_compiles(spec)
    assert r.passed is False
    assert "agent_role" in r.reason


# --- CHECK 2: deterministic -------------------------------------------

def test_check_deterministic_passes_for_preset():
    spec = PRESET_SPECS["three_body"]
    r = CognitiveModelValidator().check_prediction_deterministic(spec)
    assert r.passed is True


def test_check_deterministic_fails_on_random_op():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.prediction_template["predicted_expr"] = {
        "op": "random", "args": [{"const": 0}, {"const": 1}]
    }
    r = CognitiveModelValidator().check_prediction_deterministic(spec)
    assert r.passed is False
    assert "non-deterministic" in r.reason


def test_predict_is_pure_function_across_inputs():
    """Same inputs → same Belief; the compiled model is a pure function."""
    cm = PRESET_SPECS["economy"].to_cognitive_model()
    gt = {"fair_price": 100.0, "trend_direction": "up", "local_last_price": 130.0}
    cap = {"information_reach": 1.0, "analysis_skill": 1.0}
    b1 = cm.predict(gt, cap, 5.0)
    b2 = cm.predict(gt, cap, 5.0)
    assert b1 == b2
    # Different inputs may yield different beliefs (sanity: not trivially constant).
    b3 = cm.predict({**gt, "local_last_price": 100.0}, cap, 5.0)
    assert b3.predicted != b1.predicted


# --- CHECK 3: observable subset ---------------------------------------

def test_check_observable_subset_fails_on_unknown_variable():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.observable_variables = ["next_chaos", "nonexistent_var"]
    r = CognitiveModelValidator().check_observable_subset(spec)
    assert r.passed is False
    assert "nonexistent_var" in r.reason


def test_check_observable_subset_fails_on_both_observable_and_hidden():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.observable_variables = ["current_era", "next_chaos"]
    spec.hidden_variables = ["next_chaos"]
    r = CognitiveModelValidator().check_observable_subset(spec)
    assert r.passed is False
    assert "both" in r.reason


# --- CHECK 4: failure_modes plausible ---------------------------------

def test_check_failure_modes_fails_on_empty():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.failure_modes = []
    r = CognitiveModelValidator().check_failure_modes_plausible(spec)
    assert r.passed is False
    assert "empty" in r.reason


def test_check_failure_modes_fails_on_unknown_misjudged_variable():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.failure_modes = [{
        "name": "x", "description": "x",
        "misjudged_variable": "does_not_exist", "structure": "x",
    }]
    r = CognitiveModelValidator().check_failure_modes_plausible(spec)
    assert r.passed is False
    assert "does_not_exist" in r.reason


def test_check_failure_modes_fails_on_missing_keys():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.failure_modes = [{"name": "x"}]  # missing description/structure/misjudged_variable
    r = CognitiveModelValidator().check_failure_modes_plausible(spec)
    assert r.passed is False
    assert "missing keys" in r.reason


def test_check_failure_modes_fails_on_empty_structure():
    spec = CognitiveModelSpec.from_dict(_three_body_spec_dict())
    spec.failure_modes = [{
        "name": "x", "description": "x",
        "misjudged_variable": "next_chaos", "structure": "   ",
    }]
    r = CognitiveModelValidator().check_failure_modes_plausible(spec)
    assert r.passed is False
    assert "structure" in r.reason


# --- CHECK 5: compiles to protocol ------------------------------------

def test_check_compiles_to_protocol_passes_for_preset():
    spec = PRESET_SPECS["politics"]
    r = CognitiveModelValidator().check_compiles_to_protocol(spec)
    assert r.passed is True


def test_compiled_model_satisfies_protocol():
    cm = PRESET_SPECS["three_body"].to_cognitive_model()
    assert isinstance(cm, CognitiveModel)


def test_compiled_model_predict_returns_belief_with_bounded_confidence():
    cm = PRESET_SPECS["three_body"].to_cognitive_model()
    b = cm.predict({"next_chaos": 5.0}, {"tech_level": 3.0, "delta_0": 0.1, "T_predict": 2.0}, 0.0)
    assert isinstance(b, Belief)
    assert 0.0 <= b.confidence <= 1.0
    assert isinstance(b.model_error, bool)


# =====================================================================
# Generator — generate → validate → repair → fallback
# =====================================================================


def test_generator_llm_valid_spec_first_pass():
    gen = CognitiveModelGenerator()
    spec, result = gen.generate(
        "三体世界", agent_role="scientist", llm_fn=_make_llm_valid(),
    )
    assert result.source == "llm"
    assert result.repairs == 0
    assert isinstance(spec, CognitiveModelSpec)
    assert spec.world_type() == "three_body"
    assert isinstance(result.validation, CMValidationReport)
    assert result.validation.passed is True


def test_generator_llm_invalid_then_repair_succeeds():
    gen = CognitiveModelGenerator()
    spec, result = gen.generate(
        "三体世界", agent_role="scientist",
        llm_fn=_make_llm_invalid_then_valid(),
    )
    assert result.source == "llm"
    assert result.repairs == 1
    assert result.validation.passed is True


def test_generator_llm_always_invalid_raises():
    gen = CognitiveModelGenerator()
    with pytest.raises(RuntimeError, match="LLM failed to produce a valid spec"):
        gen.generate(
            "三体世界", agent_role="scientist",
            llm_fn=_make_llm_always_invalid(),
        )


def test_generator_llm_unparseable_raises():
    gen = CognitiveModelGenerator()
    with pytest.raises(RuntimeError, match="LLM failed to produce a valid spec"):
        gen.generate(
            "三体世界", agent_role="scientist",
            llm_fn=_make_llm_unparseable(),
        )


def test_generator_no_llm_fn_raises():
    gen = CognitiveModelGenerator()
    with pytest.raises(RuntimeError, match="requires llm_fn"):
        gen.generate("三体世界", agent_role="scientist", llm_fn=None)


def test_generator_no_llm_fn_keyword_matches_economy():
    gen = CognitiveModelGenerator()
    with pytest.raises(RuntimeError, match="requires llm_fn"):
        gen.generate("a busy stock market floor", agent_role="merchant")


def test_generator_no_llm_fn_keyword_matches_politics():
    gen = CognitiveModelGenerator()
    with pytest.raises(RuntimeError, match="requires llm_fn"):
        gen.generate("朝堂权力斗争", agent_role="noble")


def test_generation_result_to_dict_shape():
    gen = CognitiveModelGenerator()
    spec, result = gen.generate("三体世界", agent_role="scientist", llm_fn=_make_llm_valid())
    d = result.to_dict()
    assert d["ok"] is True
    assert d["source"] == "llm"
    assert "spec" in d and "validation" in d and "repairs" in d


# =====================================================================
# World-specificity of the failure structure (Q7 core)
# =====================================================================


def test_three_worlds_have_distinct_failure_structures():
    """三体/经济/政治 三世界的 failure_modes.structure 各不相同 (世界特异性)."""
    structures = {
        name: PRESET_SPECS[name].failure_modes[0]["structure"]
        for name in ("three_body", "economy", "politics")
    }
    # All three structure strings distinct.
    assert len(set(structures.values())) == 3, structures
    # Each names a different misjudgement shape.
    assert "capability_gated" in structures["three_body"]
    assert "information_incomplete" in structures["economy"]
    assert "source_biased" in structures["politics"]


def test_three_worlds_target_different_misjudged_variables():
    """The misjudged variable differs per world (世界特异性 of the error target)."""
    targets = {
        name: PRESET_SPECS[name].failure_modes[0]["misjudged_variable"]
        for name in ("three_body", "economy", "politics")
    }
    assert len(set(targets.values())) == 3
    assert targets["three_body"] == "next_chaos"
    assert targets["economy"] == "fair_price"
    assert targets["politics"] == "power_balance"


def test_three_body_compiled_model_reproduces_model_error_semantics():
    """The compiled three-body model reproduces the §8.2 dramatic-irony gap:
    low-tech → model_error=True (commits to 'no chaos'); high-tech → False."""
    cm = PRESET_SPECS["three_body"].to_cognitive_model()
    # Low tech, horizon short, chaos coming → misprediction.
    b_low = cm.predict({"next_chaos": 10.0},
                       {"tech_level": 0.0, "delta_0": 0.5, "T_predict": 1.0}, 0.0)
    assert b_low.model_error is True
    assert b_low.predicted is None
    # High tech, horizon reaches → correct.
    b_high = cm.predict({"next_chaos": 10.0},
                        {"tech_level": 10.0, "delta_0": 0.01, "T_predict": 20.0}, 0.0)
    assert b_high.model_error is False
    assert b_high.predicted == 10.0
    # Genuinely no chaos → correct no-chaos, no error.
    b_none = cm.predict({"next_chaos": None},
                        {"tech_level": 0.0, "delta_0": 0.5, "T_predict": 1.0}, 0.0)
    assert b_none.model_error is False
    assert b_none.predicted is None


def test_economy_compiled_model_flags_outlier_misjudgement():
    """Merchant predicts 0.6*local + 0.4*100; when local is a far outlier the
    predicted diverges from fair_price → model_error=True."""
    cm = PRESET_SPECS["economy"].to_cognitive_model()
    b = cm.predict({"fair_price": 100.0, "trend_direction": "up",
                    "local_last_price": 130.0},
                   {"information_reach": 0.5, "analysis_skill": 1.0}, 0.0)
    # predicted = 0.6*130 + 0.4*100 = 118; |118-100|=18 > 8 → error.
    assert b.predicted == pytest.approx(118.0)
    assert b.model_error is True


def test_politics_compiled_model_flags_bluff_misjudgement():
    """Noble over-trusts source A; when A bluffs (stated 0.9 vs true 0.3),
    predicted diverges → model_error=True."""
    cm = PRESET_SPECS["politics"].to_cognitive_model()
    b = cm.predict({"power_balance": 0.3, "stated_position_A": 0.9,
                    "stated_position_B": 0.4},
                   {"trust_network_bias": 0.9, "intelligence_skill": 1.0}, 0.0)
    # predicted = 0.9*0.9 + 0.1*0.4 = 0.85; |0.85-0.3|=0.55 > 0.15 → error.
    assert b.predicted == pytest.approx(0.85)
    assert b.model_error is True


# =====================================================================
# Explicit reference-adapter selection
# =====================================================================


def test_match_preset_three_body_by_exact_id():
    assert match_preset("three_body").world_type() == "three_body"


def test_match_preset_economy_by_exact_id():
    assert match_preset("economy").world_type() == "economy"


def test_match_preset_politics_by_exact_id():
    assert match_preset("politics").world_type() == "politics"


def test_match_preset_does_not_infer_from_world_prose():
    with pytest.raises(ValueError, match="unknown preset_id"):
        match_preset("三体世界 乱纪元")
    with pytest.raises(ValueError, match="unknown preset_id"):
        match_preset("a totally unfamiliar alien world")


def test_match_preset_returns_independent_copy():
    """Preset copies are independent (caller mutation doesn't leak)."""
    s1 = match_preset("three_body")
    s2 = match_preset("three_body")
    s1.agent_role = "mutated"
    assert s2.agent_role != "mutated"


# =====================================================================
# Spec serialization round-trip
# =====================================================================


def test_spec_round_trip_to_dict_from_dict():
    original = PRESET_SPECS["economy"]
    rt = CognitiveModelSpec.from_dict(original.to_dict())
    assert rt.world_type() == original.world_type()
    assert rt.agent_role == original.agent_role
    assert rt.observable_variables == original.observable_variables
    assert rt.hidden_variables == original.hidden_variables
    assert rt.failure_modes == original.failure_modes
    # Round-tripped spec still validates.
    assert CognitiveModelValidator().validate_all(rt).passed is True


def test_generate_cognitive_model_helper_requires_llm():
    from theater.cognitive_model_generator import generate_cognitive_model
    with pytest.raises(RuntimeError):
        generate_cognitive_model("三体世界", "scientist", llm_fn=None)


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-q"]))
