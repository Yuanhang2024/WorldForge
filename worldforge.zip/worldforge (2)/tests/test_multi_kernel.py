"""Tests for backend.theater.multi_kernel (micro-kernel skeleton + event bus).

Covers:
  - Two kernels tick in priority order with different owns_paths
  - Event bus routes physics-fresh state into the economy kernel
  - Ownership conflict at assembly is rejected
  - Priority order is honored (low first)
  - MAX_WAVES bounds cascading
  - Invariant failure rolls back the entire tick
  - Determinism (same input → same output)
  - DslKernelModule wraps an existing WorldKernelSpec (backward compatibility)
  - ThreeBodyKernelModule wraps the three-body kernel

Run with::

    PYTHONPATH=backend python -m pytest tests/test_multi_kernel.py -q
"""

from __future__ import annotations

import os
import sys
import copy

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.multi_kernel import (
    DslKernelModule,
    Event,
    EventBus,
    InvariantViolation,
    KernelModule,
    MAX_WAVES,
    MultiKernelHost,
    OwnershipConflict,
    ThreeBodyKernelModule,
)


# =====================================================================
# Test kernels — minimal in-test implementations
# =====================================================================


class PhysicsKernel:
    """A minimal 'physics' kernel that adds 'mass' to state and emits a probe event.

    owns_paths = ('physics',)
    priority  = 100
    """

    def __init__(self, name: str = "physics", mass: float = 1.0) -> None:
        self._name = name
        self._owns_paths = ("physics",)
        self._priority = 100
        self._mass = mass
        self._step_count = 0

    @property
    def name(self) -> str:
        return self._name

    @property
    def owns_paths(self):
        return self._owns_paths

    @property
    def priority(self) -> int:
        return self._priority

    def init(self, state):
        state.setdefault("physics", {})
        state["physics"]["mass"] = float(state["physics"].get("mass", 0.0)) + self._mass

    def step(self, state, events):
        self._step_count += 1
        # Read pending events and bump a counter (proves the bus feeds in).
        produced = []
        for ev in events:
            et = ev.get("type", "")
            if et == "probe":
                state["physics"]["last_probe"] = ev.get("payload", {}).get("value", 0)
            elif et == "tick.physics":
                # On a "tick.physics" pulse, emit a resource_produced event.
                produced.append({
                    "type": "resource_produced",
                    "source_kernel": self._name,
                    "path": "physics.mass",
                    "payload": {"mass": state["physics"].get("mass", 0.0)},
                })
        return produced

    def shutdown(self) -> None:
        return None

    def check_invariants(self, state):
        return []

    @property
    def step_count(self):
        return self._step_count


class EconomyKernel:
    """A minimal 'economy' kernel that consumes resource_produced and writes economy.*.

    owns_paths = ('economy',)
    priority  = 200
    """

    def __init__(self, name: str = "economy") -> None:
        self._name = name
        self._owns_paths = ("economy",)
        self._priority = 200
        self._step_count = 0

    @property
    def name(self) -> str:
        return self._name

    @property
    def owns_paths(self):
        return self._owns_paths

    @property
    def priority(self) -> int:
        return self._priority

    def init(self, state):
        state.setdefault("economy", {"gold": 0})

    def step(self, state, events):
        self._step_count += 1
        produced = []
        for ev in events:
            if ev.get("type") == "resource_produced":
                mass = ev.get("payload", {}).get("mass", 0.0)
                state["economy"]["gold"] = state["economy"].get("gold", 0) + mass
                produced.append({
                    "type": "trade.executed",
                    "source_kernel": self._name,
                    "path": "economy.gold",
                    "payload": {"gold": state["economy"]["gold"]},
                })
        return produced

    def shutdown(self) -> None:
        return None

    def check_invariants(self, state):
        return []

    @property
    def step_count(self):
        return self._step_count


class SocietyKernel:
    """A social kernel that subscribes to trade.executed events and updates unrest.

    owns_paths = ('society',)
    priority  = 300
    """

    def __init__(self, name: str = "society", forbidden: bool = False) -> None:
        self._name = name
        self._owns_paths = ("society",)
        self._priority = 300
        self._step_count = 0
        # If True, the kernel will try to write to 'economy.gold' (a forbidden path)
        # to verify the ownership check fires.
        self._forbidden = forbidden

    @property
    def name(self) -> str:
        return self._name

    @property
    def owns_paths(self):
        return self._owns_paths

    @property
    def priority(self) -> int:
        return self._priority

    def init(self, state):
        state.setdefault("society", {"unrest": 0})

    def step(self, state, events):
        self._step_count += 1
        for ev in events:
            if ev.get("type") == "trade.executed":
                gold = ev.get("payload", {}).get("gold", 0)
                state["society"]["unrest"] = state["society"].get("unrest", 0) + gold
        return []

    def shutdown(self) -> None:
        return None

    def check_invariants(self, state):
        return []


class CascadingKernel:
    """A kernel that always emits a follow-up event, creating a chain.

    Used to verify MAX_WAVES caps cascading.
    """

    def __init__(self, name: str = "cascader", stop_after: int = 100) -> None:
        self._name = name
        self._owns_paths = ("cascader",)
        self._priority = 500
        self._step_count = 0
        self._stop_after = stop_after

    @property
    def name(self) -> str:
        return self._name

    @property
    def owns_paths(self):
        return self._owns_paths

    @property
    def priority(self) -> int:
        return self._priority

    def init(self, state):
        state.setdefault("cascader", {"count": 0})

    def step(self, state, events):
        self._step_count += 1
        # Always emit a follow-up event (would create an infinite loop).
        new_count = state["cascader"]["count"] + 1
        state["cascader"]["count"] = new_count
        if new_count >= self._stop_after:
            return []
        return [{
            "type": "cascade.continue",
            "source_kernel": self._name,
            "path": "cascader.count",
            "payload": {"n": new_count},
        }]

    def shutdown(self) -> None:
        return None

    def check_invariants(self, state):
        return []


class InvariantFailer:
    """A kernel whose check_invariants always fails (used for rollback test)."""

    def __init__(self, name: str = "failer") -> None:
        self._name = name
        self._owns_paths = ("failer",)
        self._priority = 100

    @property
    def name(self) -> str:
        return self._name

    @property
    def owns_paths(self):
        return self._owns_paths

    @property
    def priority(self) -> int:
        return self._priority

    def init(self, state):
        state.setdefault("failer", {})

    def step(self, state, events):
        # Make a state mutation that should be rolled back.
        state["failer"]["poison"] = 42
        return []

    def shutdown(self) -> None:
        return None

    def check_invariants(self, state):
        return ["failer.deliberately_broken"]


# =====================================================================
# Basic tick mechanics
# =====================================================================


class TestBasicTick:
    def test_two_kernels_execute_in_one_tick(self) -> None:
        state = {}
        host = MultiKernelHost(
            [EconomyKernel(), PhysicsKernel()],
            state, seed=42,
        )
        # Send a tick.physics pulse to wake physics into emitting.
        host.tick(external_events=[{
            "type": "tick.physics",
            "source_kernel": "tester",
            "path": "tick",
            "payload": {},
        }])
        # Both modules ran exactly once (in-wave delivery).
        assert host.modules()[0].name == "physics"  # lower priority
        assert state["physics"]["mass"] == 1.0
        # Economy received the resource_produced event and credited gold.
        assert state["economy"]["gold"] == 1.0

    def test_priority_order_respected(self) -> None:
        # Provide them in the wrong order; the host should still run physics first.
        state = {}
        host = MultiKernelHost(
            [EconomyKernel(), PhysicsKernel()],
            state, seed=42,
        )
        # The sorted order is (priority, name) — physics 100, economy 200.
        names = [m.name for m in host.modules()]
        assert names.index("physics") < names.index("economy")

    def test_external_events_processed(self) -> None:
        state = {}
        host = MultiKernelHost(
            [PhysicsKernel(), EconomyKernel()],
            state, seed=1,
        )
        host.tick(external_events=[{
            "type": "probe",
            "source_kernel": "",
            "path": "physics.last_probe",
            "payload": {"value": 7},
        }])
        assert state["physics"].get("last_probe") == 7


# =====================================================================
# Event bus
# =====================================================================


class TestEventBus:
    def test_publish_and_subscribe(self) -> None:
        bus = EventBus()
        seen: list = []
        bus.subscribe("economy.", lambda ev: seen.append(ev.to_dict()))
        bus.publish(Event(type="trade.executed", source_kernel="x", path="economy.gold"))
        bus.publish(Event(type="unrelated", source_kernel="x", path="other"))
        bus.assign_seq(bus._queue)  # noqa: SLF001
        delivered = bus.drain()
        assert len(delivered) == 2
        assert len(seen) == 1
        assert seen[0]["type"] == "trade.executed"

    def test_max_waves_bounds_cascade(self) -> None:
        bus = EventBus(max_waves=MAX_WAVES)
        # Cascader always emits a follow-up.
        cas = CascadingKernel()
        # Subscribe so the bus processes events.  We don't actually care
        # what the subscriber does — just that drain terminates.
        bus.subscribe("cascade.", lambda ev: None)
        # Seed the cascade with one initial event.
        bus.publish(Event(type="cascade.continue", source_kernel="seed", path="cascader.count"))
        bus.assign_seq(bus._queue)  # noqa: SLF001
        # Manually inject the cascading emission by calling drain (which
        # also calls subscribers — but our subscriber doesn't enqueue, so
        # we need a different setup).
        # Instead, use a simpler test: simulate cascading by publish+assign_seq
        # many times, then drain and observe what survives.
        for _ in range(100):
            bus.publish(Event(type="cascade.continue", source_kernel="x", path="cascader.count"))
        bus.assign_seq(bus._queue)  # noqa: SLF001
        delivered = bus.drain()
        # MAX_WAVES batches means at most MAX_WAVES snapshots of pending
        # events get delivered.  Since we enqueued 101 events and
        # subscribers don't enqueue more, all 101 get delivered in one
        # wave (no cascading).  The cap is about *waves*, not events.
        assert len(delivered) == 101

    def test_max_waves_caps_when_subscribers_emit(self) -> None:
        bus = EventBus(max_waves=3)

        def subscriber(ev):
            # Each delivery enqueues a new event — would loop forever
            # without MAX_WAVES.
            bus.publish(Event(type="cascade.x", source_kernel="loop",
                              path="cascade."))

        bus.subscribe("cascade.", subscriber)
        bus.publish(Event(type="cascade.x", source_kernel="seed", path="cascade."))
        bus.assign_seq(bus._queue)  # noqa: SLF001
        delivered = bus.drain()
        # 3 waves, each delivering a batch.  Each wave's subscriber
        # enqueues a new event, so the next wave has 1 event to deliver.
        # After MAX_WAVES=3, drain stops.  Anything still queued is
        # dropped and recorded.
        assert len(delivered) == 3
        assert len(bus.dropped_events()) >= 1

    def test_seq_is_monotonic(self) -> None:
        bus = EventBus()
        # Publish and assign_seq — every event gets a unique seq.
        bus.publish(Event(type="a", source_kernel="", path=""))
        bus.publish(Event(type="b", source_kernel="", path=""))
        bus.assign_seq(bus._queue)  # noqa: SLF001
        bus.publish(Event(type="c", source_kernel="", path=""))
        bus.assign_seq(bus._queue)  # noqa: SLF001
        # Drain in deterministic order.
        bus.subscribe("", lambda ev: None)
        delivered = bus.drain()
        seqs = [e.seq for e in delivered]
        assert seqs == sorted(seqs)
        assert seqs[0] >= 1
        assert seqs == list(range(1, len(seqs) + 1))


# =====================================================================
# Ownership validation
# =====================================================================


class TestOwnership:
    def test_overlapping_paths_rejected(self) -> None:
        class KernelA:
            name = "a"
            owns_paths = ("economy",)
            priority = 100

            def init(self, state): pass
            def step(self, state, events): return []
            def shutdown(self): pass
            def check_invariants(self, state): return []

        class KernelB:
            name = "b"
            owns_paths = ("economy.price",)  # overlaps 'economy'
            priority = 200

            def init(self, state): pass
            def step(self, state, events): return []
            def shutdown(self): pass
            def check_invariants(self, state): return []

        with pytest.raises(OwnershipConflict):
            MultiKernelHost([KernelA(), KernelB()], {})

    def test_disjoint_paths_accepted(self) -> None:
        host = MultiKernelHost(
            [PhysicsKernel(), EconomyKernel(), SocietyKernel()],
            {}, seed=0,
        )
        assert len(host.modules()) == 3

    def test_add_module_conflict(self) -> None:
        host = MultiKernelHost([PhysicsKernel()], {}, seed=0)
        # A second kernel that ALSO claims "physics" — this should
        # conflict at add_module time.
        class DuplicatePhysics:
            name = "physics2"
            owns_paths = ("physics",)
            priority = 200
            def init(self, state): pass
            def step(self, state, events): return []
            def shutdown(self): pass
            def check_invariants(self, state): return []
        with pytest.raises(OwnershipConflict):
            host.add_module(DuplicatePhysics())

    def test_add_module_no_conflict(self) -> None:
        host = MultiKernelHost([PhysicsKernel()], {}, seed=0)
        host.add_module(EconomyKernel())
        assert len(host.modules()) == 2

    def test_add_module_duplicate_name_rejected(self) -> None:
        host = MultiKernelHost([PhysicsKernel()], {}, seed=0)
        with pytest.raises(Exception):
            host.add_module(PhysicsKernel())

    def test_remove_module(self) -> None:
        host = MultiKernelHost([PhysicsKernel(), EconomyKernel()], {}, seed=0)
        host.remove_module("economy")
        assert len(host.modules()) == 1
        with pytest.raises(Exception):
            host.remove_module("economy")


# =====================================================================
# Invariant rollback
# =====================================================================


class TestInvariantRollback:
    def test_rollback_when_invariant_fails(self) -> None:
        state = {}
        host = MultiKernelHost(
            [PhysicsKernel(), InvariantFailer()],
            state, seed=0,
        )
        # PhysicsKernel writes physics.mass; InvariantFailer writes
        # failer.poison.  Then invariants fail.
        with pytest.raises(InvariantViolation):
            host.tick()
        # After rollback, the state should be as it was pre-tick: physics
        # initialized by init() (mass=1.0), no failer.poison.
        assert state["physics"]["mass"] == 1.0
        assert "poison" not in state.get("failer", {})

    def test_commit_when_invariants_pass(self) -> None:
        state = {}
        host = MultiKernelHost([PhysicsKernel(), EconomyKernel()], state, seed=0)
        host.tick(external_events=[{
            "type": "tick.physics",
            "source_kernel": "tester",
            "path": "tick",
            "payload": {},
        }])
        # State should have advanced: physics.mass = 1 (from init), economy.gold
        # credited 1 from the resource_produced event.
        assert state["physics"]["mass"] == 1.0
        assert state["economy"]["gold"] == 1.0


# =====================================================================
# Determinism
# =====================================================================


class TestDeterminism:
    def test_same_seed_same_output(self) -> None:
        s1 = {}
        h1 = MultiKernelHost([PhysicsKernel(), EconomyKernel()], s1, seed=123)
        h1.tick()

        s2 = {}
        h2 = MultiKernelHost([PhysicsKernel(), EconomyKernel()], s2, seed=123)
        h2.tick()

        assert s1 == s2

    def test_event_seq_is_deterministic(self) -> None:
        bus1 = EventBus()
        bus2 = EventBus()
        for b in (bus1, bus2):
            for i in range(5):
                b.publish(Event(type="x", source_kernel="t", path="p", payload={"i": i}))
            b.assign_seq(b._queue)  # noqa: SLF001
        assert [e.seq for e in bus1._queue] == [e.seq for e in bus2._queue]  # noqa: SLF001


# =====================================================================
# DslKernelModule — backward-compatible wrapper
# =====================================================================


class TestDslKernelModule:
    def _build_spec(self):
        from theater.world_kernel_host import WorldRule, WorldKernelSpec
        # A simple supply→price economy spec, mirroring the existing tests.
        rule = WorldRule(
            rule_id="supply_to_price",
            kind="dynamic",
            trigger="tick.supply",
            effect={
                "op": "writes",
                "changes": [
                    {"path": "economy.gold", "value": {"op": "add",
                                                       "args": [{"ref": "economy.gold"},
                                                                {"const": 5.0}]}},
                ],
            },
        )
        spec = WorldKernelSpec(world_type="test_econ", rules=[rule])
        return spec

    def test_dsl_module_wraps_spec(self) -> None:
        spec = self._build_spec()
        m = DslKernelModule(name="econ_dsl", spec=spec, priority=200, seed=0)
        assert m.name == "econ_dsl"
        assert m.priority == 200
        # owns_paths should be inferred from the effect AST.
        assert "economy.gold" in m.owns_paths

    def test_dsl_module_runs_via_multikernel(self) -> None:
        spec = self._build_spec()
        state = {"economy": {"gold": 10}}
        dsl = DslKernelModule(name="econ_dsl", spec=spec, priority=200, seed=0)
        host = MultiKernelHost([dsl], state, seed=0)
        host.tick(external_events=[{
            "type": "tick.supply",
            "source_kernel": "tester",
            "path": "trigger",
            "payload": {},
        }])
        # The DSL rule fired: economy.gold = 10 + 5 = 15
        assert state["economy"]["gold"] == 15

    def test_dsl_module_backward_compat(self) -> None:
        """The 47-test path through WorldKernelHost must still work."""
        from theater.world_kernel_host import WorldKernelHost
        spec = self._build_spec()
        # Old API: WorldKernelHost(spec, state).step(event)
        host = WorldKernelHost(spec, {"economy": {"gold": 10}}, seed=0)
        changes = host.step({"trigger": "tick.supply"})
        assert any(c.get("path") == "economy.gold" for c in changes)
        # And the state has been updated.
        assert host.query("economy.gold") == 15

    def test_dsl_module_rejects_overlap_at_assembly(self) -> None:
        spec1 = self._build_spec()
        spec2 = self._build_spec()  # same owns_paths
        dsl1 = DslKernelModule(name="dsl1", spec=spec1, priority=100, seed=0)
        dsl2 = DslKernelModule(name="dsl2", spec=spec2, priority=200, seed=0)
        with pytest.raises(OwnershipConflict):
            MultiKernelHost([dsl1, dsl2], {})


# =====================================================================
# ThreeBodyKernelModule
# =====================================================================


class TestThreeBodyKernelModule:
    def test_module_wraps_three_body(self) -> None:
        # Small bake_years for fast tests.
        m = ThreeBodyKernelModule(name="three_body", priority=100, seed=88123,
                                  bake_years=200.0)
        state = {}
        m.init(state)
        # After init, three_body.baked is True and civilization exists.
        assert state["three_body"]["baked"] is True
        assert state["three_body"]["lambda_"] > 0
        assert "civilization" in state
        m.shutdown()

    def test_module_step_consumes_time_accelerate(self) -> None:
        m = ThreeBodyKernelModule(name="three_body", priority=100, seed=88123,
                                  bake_years=200.0)
        state = {}
        m.init(state)
        produced = m.step(state, [{
            "type": "time.accelerate",
            "source_kernel": "tester",
            "path": "time",
            "payload": {"t": 50.0, "tech_level": 2.0},
        }])
        # Should emit a civilization.tick event.
        types = [p["type"] for p in produced]
        assert "civilization.tick" in types
        # civilization.last_event should be populated.
        assert state["civilization"]["last_event"] is not None
        m.shutdown()

    def test_module_invariants_pass_when_baked(self) -> None:
        m = ThreeBodyKernelModule(name="three_body", priority=100, seed=88123,
                                  bake_years=200.0)
        state = {}
        m.init(state)
        failing = m.check_invariants(state)
        # energy_drift should be tiny (symplectic), lambda > 0.
        assert failing == []
        m.shutdown()

    def test_module_owns_paths(self) -> None:
        m = ThreeBodyKernelModule()
        # Default: civilization, three_body
        assert "civilization" in m.owns_paths
        assert "three_body" in m.owns_paths

    def test_module_disjoint_with_dsl_economy(self) -> None:
        """A world with a three-body kernel and a DSL economy kernel must assemble."""
        from theater.world_kernel_host import WorldRule, WorldKernelSpec
        spec = WorldKernelSpec(
            world_type="t", rules=[
                WorldRule(
                    rule_id="r", kind="dynamic", trigger="tick",
                    effect={"op": "writes", "changes": [
                        {"path": "economy.gold", "value": {"const": 1}},
                    ]},
                ),
            ],
        )
        dsl = DslKernelModule(name="econ", spec=spec, priority=200, seed=0)
        tb = ThreeBodyKernelModule(name="three_body", priority=100,
                                   seed=88123, bake_years=200.0)
        state: dict = {}
        host = MultiKernelHost([tb, dsl], state, seed=0)
        host.tick(external_events=[
            {"type": "time.accelerate", "source_kernel": "tester", "path": "time",
             "payload": {"t": 50.0, "tech_level": 2.0}},
            {"type": "tick", "source_kernel": "tester", "path": "trigger",
             "payload": {}},
        ])
        # three_body wrote civilization; dsl wrote economy.gold.
        assert state["economy"]["gold"] == 1
        assert state["civilization"]["last_event"] is not None


# =====================================================================
# Three-tier composition (physics → economy → society)
# =====================================================================


class TestThreeTierComposition:
    def test_phys_econ_society_same_tick(self) -> None:
        state = {}
        host = MultiKernelHost(
            [PhysicsKernel(), EconomyKernel(), SocietyKernel()],
            state, seed=0,
        )
        host.tick(external_events=[{
            "type": "tick.physics",
            "source_kernel": "tester",
            "path": "tick",
            "payload": {},
        }])
        # Physics wrote mass (init) + emitted resource_produced.
        # Economy consumed it and emitted trade.executed.
        # Society consumed trade.executed and bumped unrest.
        assert state["physics"]["mass"] == 1.0
        assert state["economy"]["gold"] == 1.0
        assert state["society"]["unrest"] == 1.0

    def test_priority_low_first(self) -> None:
        # Note execution order via a recording list.
        order: list = []

        class Recorder:
            def __init__(self, name, prio, owns=("r",)):
                self._name = name
                self._owns = owns
                self._prio = prio
            @property
            def name(self): return self._name
            @property
            def owns_paths(self): return self._owns
            @property
            def priority(self): return self._prio
            def init(self, state): pass
            def step(self, state, events):
                order.append(self._name)
                return []
            def shutdown(self): pass
            def check_invariants(self, state): return []

        # Distinct owns_paths so assembly doesn't reject on overlap.
        a = Recorder("a", 100, owns=("a.",))
        b = Recorder("b", 200, owns=("b.",))
        c = Recorder("c", 300, owns=("c.",))
        # Provide in reverse order; host should re-sort.
        host = MultiKernelHost([c, a, b], {}, seed=0)
        host.tick()
        assert order == ["a", "b", "c"]

    def test_max_waves_caps_multikernel_cascade(self) -> None:
        """A kernel that always emits a follow-up event must be capped at
        MAX_WAVES by the host's tick loop, not by the bus's drain."""
        host = MultiKernelHost([CascadingKernel(stop_after=1000)], {}, seed=0)
        # MAX_WAVES=5, so the cascader gets at most 5 chances to fire.
        host.tick(external_events=[{
            "type": "cascade.continue",
            "source_kernel": "seed",
            "path": "cascader.count",
            "payload": {},
        }])
        # The cascader's count is capped at MAX_WAVES+1 because it only
        # runs once per wave.
        assert host.state()["cascader"]["count"] <= MAX_WAVES + 1
