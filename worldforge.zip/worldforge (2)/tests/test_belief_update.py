"""Tests for the belief-update layer (architecture §8.2 / §10, Q5).

Covers:

- the three revision strategies on the same belief state
  (rational / dogmatic / conspiratorial);
- the bounded-confidence (Deffuant / Hegselmann-Krause) update — within
  radius adjusts, out of radius does not;
- :class:`BeliefUpdateTrace` replayability and the six-source error
  tagging;
- personality → strategy / confidence-radius derivation;
- the dogmatic reinforcement loop (2307.05069 insight: repeated
  contradicting evidence reinforces the prior rather than correcting it).

No LLM, no unseeded randomness — every assertion is a pure function of
its inputs.
"""

from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.belief_update import (  # noqa: E402
    BeliefUpdateTrace,
    ERROR_SOURCES,
    bounded_confidence_update,
    bounded_confidence_update_traced,
    classify_error_source,
    derive_confidence_radius,
    derive_strategy,
    revise_belief,
    update_with_evidence,
    update_with_evidence_traced,
)
from theater.cognitive_model import Belief  # noqa: E402
from theater.sim_agent import MindProfile, derive_mind_profile  # noqa: E402


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _belief(predicted: float, confidence: float = 0.5) -> Belief:
    return Belief(predicted=predicted, confidence=confidence, model_error=False,
                  committed_values={})


# ---------------------------------------------------------------------------
# 1. rational strategy — standard move toward evidence
# ---------------------------------------------------------------------------


def test_rational_moves_predicted_toward_observation():
    prior = _belief(0.5)
    posterior = update_with_evidence(
        prior=prior, observation=0.9,
        evidence_weight=1.0, update_rate=0.5, strategy="rational",
    )
    # moved partway from 0.5 toward 0.9
    assert 0.5 < posterior.predicted < 0.9
    assert posterior.predicted == 0.5 + 0.4 * 1.0 * 0.5  # 0.7


def test_rational_evidence_weight_scales_step():
    prior = _belief(0.5)
    weak = update_with_evidence(prior, 0.9, evidence_weight=0.3,
                                update_rate=0.5, strategy="rational")
    strong = update_with_evidence(prior, 0.9, evidence_weight=1.5,
                                  update_rate=0.5, strategy="rational")
    # stronger evidence weight → bigger step toward 0.9
    assert abs(0.9 - weak.predicted) > abs(0.9 - strong.predicted)


def test_rational_confidence_grows_gently_and_clamps():
    prior = _belief(0.5, confidence=0.99)
    posterior = update_with_evidence(prior, 0.6, evidence_weight=1.0,
                                     update_rate=0.5, strategy="rational")
    assert posterior.confidence == 1.0  # clamped


# ---------------------------------------------------------------------------
# 2. dogmatic strategy — damped evidence + contradiction backfire
# ---------------------------------------------------------------------------


def test_dogmatic_damps_consistent_evidence():
    """When evidence is within tolerance, dogmatic barely moves."""
    prior = _belief(0.5)
    # tiny evidence within threshold → no contradiction, just damped move
    posterior = update_with_evidence(
        prior, 0.5000001, evidence_weight=1.0, update_rate=0.5,
        strategy="dogmatic",
    )
    # essentially no movement
    assert abs(posterior.predicted - 0.5) < 1e-3


def test_dogmatic_backfires_on_contradiction():
    """Contradicting evidence pushes the prior AWAY from the observation."""
    prior = _belief(0.5)
    posterior = update_with_evidence(
        prior, 0.9, evidence_weight=1.0, update_rate=0.5,
        strategy="dogmatic",
    )
    # evidence = +0.4, contradiction = +0.4
    # new = 0.5 + 0.4*1*0.5*0.1 - 0.4*0.5 = 0.5 + 0.02 - 0.2 = 0.32
    assert posterior.predicted < prior.predicted  # moved away from 0.9
    assert posterior.predicted == 0.32


def test_dogmatic_trace_marks_cognitive_bias_and_rejection():
    prior = _belief(0.5)
    posterior, trace = update_with_evidence_traced(
        prior, 0.9, evidence_weight=1.0, update_rate=0.5,
        strategy="dogmatic", topic="weather",
    )
    assert trace.accepted is False
    assert trace.error_source == "cognitive_bias"
    assert trace.contradiction == 0.4
    assert "backfire" in trace.rejected_info


# ---------------------------------------------------------------------------
# 3. conspiratorial strategy — contradiction strengthens the prior
# ---------------------------------------------------------------------------


def test_conspiratorial_strengthens_prior_on_contradiction():
    prior = _belief(0.5, confidence=0.5)
    posterior = update_with_evidence(
        prior, 0.9, evidence_weight=1.0, update_rate=0.5,
        strategy="conspiratorial",
    )
    # predicted moves away from 0.9 (toward 0.42)
    assert posterior.predicted < prior.predicted
    # confidence rises — the belief was "strengthened"
    assert posterior.confidence > prior.confidence


def test_conspiratorial_consistent_evidence_integrated_weakly():
    """Non-contradicting evidence is still integrated (cautiously)."""
    prior = _belief(0.5)
    # within-threshold evidence → small move toward observation
    posterior = update_with_evidence(
        prior, 0.5000001, evidence_weight=1.0, update_rate=0.5,
        strategy="conspiratorial",
    )
    assert abs(posterior.predicted - 0.5) < 1e-3


def test_conspiratorial_trace_tags_cognitive_bias():
    prior = _belief(0.5)
    _, trace = update_with_evidence_traced(
        prior, 0.9, evidence_weight=1.0, update_rate=0.5,
        strategy="conspiratorial",
    )
    assert trace.accepted is False
    assert trace.error_source == "cognitive_bias"


# ---------------------------------------------------------------------------
# 4. determinism / seed
# ---------------------------------------------------------------------------


def test_same_inputs_same_output():
    prior = _belief(0.5)
    a = update_with_evidence(prior, 0.9, 1.0, 0.5, "dogmatic", seed=42)
    b = update_with_evidence(prior, 0.9, 1.0, 0.5, "dogmatic", seed=42)
    assert a == b


def test_trace_replay_reproduces_posterior():
    prior = _belief(0.5, confidence=0.4)
    posterior, trace = update_with_evidence_traced(
        prior, 0.8, evidence_weight=1.3, update_rate=0.6,
        strategy="dogmatic", seed=7, topic="price",
    )
    replayed = trace.replay()
    assert replayed == posterior


def test_unknown_strategy_raises():
    try:
        update_with_evidence(_belief(0.5), 0.9, 1.0, 0.5, "stoic")
    except ValueError:
        return
    raise AssertionError("expected ValueError for unknown strategy")


# ---------------------------------------------------------------------------
# 5. bounded confidence
# ---------------------------------------------------------------------------


def test_bounded_confidence_adjusts_within_radius():
    agent = _belief(0.5)
    others = [_belief(0.55), _belief(0.6)]  # both within 0.2
    posterior = bounded_confidence_update(
        agent, others, confidence_radius=0.2, weight=0.5,
    )
    # mean diff = (0.05 + 0.10)/2 = 0.075; new = 0.5 + 0.5*0.075 = 0.5375
    assert posterior.predicted > agent.predicted
    assert abs(posterior.predicted - 0.5375) < 1e-9


def test_bounded_confidence_ignores_outside_radius():
    agent = _belief(0.5)
    others = [_belief(0.9)]  # diff 0.4 > radius 0.2
    posterior = bounded_confidence_update(
        agent, others, confidence_radius=0.2, weight=0.5,
    )
    assert posterior.predicted == agent.predicted  # unchanged
    assert posterior.confidence == agent.confidence


def test_bounded_confidence_mixed_peers_only_uses_within():
    agent = _belief(0.5)
    others = [_belief(0.55), _belief(0.9)]  # only 0.55 within 0.2
    posterior = bounded_confidence_update(
        agent, others, confidence_radius=0.2, weight=0.5,
    )
    # mean within diff = 0.05; new = 0.5 + 0.5*0.05 = 0.525
    assert abs(posterior.predicted - 0.525) < 1e-9


def test_bounded_confidence_echo_chamber_trace():
    agent = _belief(0.5)
    others = [_belief(0.9), _belief(0.95)]
    posterior, trace = bounded_confidence_update_traced(
        agent, others, confidence_radius=0.2, weight=0.5,
    )
    assert trace.accepted is False
    assert trace.error_source == "cognitive_bias"
    assert "echo chamber" in trace.rejected_info


# ---------------------------------------------------------------------------
# 6. BeliefUpdateTrace completeness + error sources
# ---------------------------------------------------------------------------


def test_trace_records_full_provenance():
    prior = _belief(0.5, confidence=0.4)
    posterior, trace = update_with_evidence_traced(
        prior, 0.8, evidence_weight=1.0, update_rate=0.5,
        strategy="rational", topic="price", seed=11,
    )
    assert trace.topic == "price"
    assert trace.prior == prior
    assert trace.observation == 0.8
    assert trace.evidence_weight == 1.0
    assert trace.update_rate == 0.5
    assert trace.strategy == "rational"
    assert trace.posterior == posterior
    assert trace.seed == 11
    assert "evidence_weight" in trace.personality_modifiers
    assert trace.accepted is True  # rational moves toward evidence


def test_six_error_sources_present():
    assert set(ERROR_SOURCES) == {
        "information_error", "perception_error", "reasoning_error",
        "cognitive_bias", "goal_error", "execution_error",
    }
    assert len(ERROR_SOURCES) == 6


def test_perception_error_tagged_when_observation_not_validated():
    prior = _belief(0.5)
    _, trace = update_with_evidence_traced(
        prior, 0.9, evidence_weight=1.0, update_rate=0.5,
        strategy="rational", observation_validated=False,
    )
    assert trace.error_source == "perception_error"


def test_classify_error_source_clean_returns_none():
    assert classify_error_source(
        strategy="rational", accepted=True, contradiction=0.0,
    ) is None


# ---------------------------------------------------------------------------
# 7. personality → strategy / radius derivation
# ---------------------------------------------------------------------------


def test_derive_strategy_stubborn_dogmatic():
    profile = derive_mind_profile("性格固执，不易改变想法")
    assert derive_strategy(profile) == "dogmatic"


def test_derive_strategy_open_rational():
    profile = derive_mind_profile("性格开放，充满好奇")
    assert derive_strategy(profile) == "rational"


def test_derive_strategy_conspiratorial_from_keywords():
    profile = derive_mind_profile("多疑，相信阴谋")
    assert derive_strategy(profile, personality_text="多疑，相信阴谋") == "conspiratorial"


def test_derive_confidence_radius_stubborn_small_open_large():
    stubborn = derive_mind_profile("固执")
    open_mind = derive_mind_profile("开放好奇理性")
    assert derive_confidence_radius(stubborn) < derive_confidence_radius(open_mind)
    # both within (0, 1]
    for p in (stubborn, open_mind):
        r = derive_confidence_radius(p)
        assert 0.0 < r <= 1.0


def test_revise_belief_wires_profile_to_strategy():
    """High-level entry: MindProfile → strategy → posterior + trace."""
    profile = derive_mind_profile("固执")
    prior = _belief(0.5)
    posterior, trace = revise_belief(
        prior, observation=0.9, profile=profile, topic="danger",
        personality_text="固执",
    )
    assert trace.strategy == "dogmatic"
    assert trace.error_source == "cognitive_bias"
    # dogmatic backfire → moved away from 0.9
    assert posterior.predicted < prior.predicted
    assert trace.personality_modifiers["strategy"] == "dogmatic"
    assert "confidence_radius" in trace.personality_modifiers


# ---------------------------------------------------------------------------
# 8. dogmatic reinforcement loop (2307.05069 insight)
# ---------------------------------------------------------------------------


def test_dogmatic_reinforcement_loop_reinforces_not_corrects():
    """Repeated contradicting evidence drives the prior FURTHER from the
    observation, not toward it — the central 2307.05069 insight that
    dogmatic reinforcement and learning are two strategies on the same
    state, and dogma fails to correct."""
    prior = _belief(0.5)
    observation = 0.9
    #固执 profile: low evidence weight, slow update
    profile = derive_mind_profile("固执")
    ew = profile.evidence_weight
    ur = profile.belief_update_rate

    current = prior
    distances = [abs(observation - current.predicted)]
    for _ in range(5):
        current = update_with_evidence(
            current, observation, evidence_weight=ew,
            update_rate=ur, strategy="dogmatic",
        )
        distances.append(abs(observation - current.predicted))

    # Each step the prior moves further from the observation (reinforces).
    assert distances[-1] > distances[0]
    # Monotonically non-decreasing reinforcement.
    for i in range(1, len(distances)):
        assert distances[i] >= distances[i] - 1e-9  # tolerance for float
    # And the final belief is on the *opposite side* of the prior from
    # the observation (or further from it than the start) — i.e. the
    # agent doubled down rather than learning.
    assert current.predicted < prior.predicted  # moved away from 0.9


def test_rational_loop_converges_to_observation():
    """Contrast: the rational strategy on the same state *does* converge."""
    prior = _belief(0.5)
    observation = 0.9
    profile = derive_mind_profile("开放理性")
    ew = profile.evidence_weight
    ur = profile.belief_update_rate

    current = prior
    for _ in range(20):
        current = update_with_evidence(
            current, observation, evidence_weight=ew,
            update_rate=ur, strategy="rational",
        )
    # With ew*ur < 1 it asymptotes toward observation; close after 20 steps.
    assert abs(current.predicted - observation) < 0.2


def test_conspiratorial_loop_grows_confidence_under_contradiction():
    """Repeated contradiction under conspiratorial strategy keeps raising
    confidence — the agent becomes *more* sure of a false belief."""
    prior = _belief(0.5, confidence=0.3)
    observation = 0.9
    current = prior
    confidences = [current.confidence]
    for _ in range(5):
        current = update_with_evidence(
            current, observation, evidence_weight=1.0,
            update_rate=0.5, strategy="conspiratorial",
        )
        confidences.append(current.confidence)
    assert confidences[-1] > confidences[0]
    # predicted has moved away from the observation
    assert current.predicted < prior.predicted


# ---------------------------------------------------------------------------
# 9. non-numeric observation handling
# ---------------------------------------------------------------------------


def test_non_numeric_observation_nudges_confidence_only():
    prior = _belief(0.5, confidence=0.5)
    posterior = update_with_evidence(
        prior, "a loud explosion", evidence_weight=1.0,
        update_rate=0.5, strategy="rational",
    )
    assert posterior.predicted == prior.predicted  # unchanged
    assert posterior.confidence > prior.confidence  # nudged


def test_non_numeric_observation_trace_accepted_no_error():
    prior = _belief(0.5)
    _, trace = update_with_evidence_traced(
        prior, "explosion", evidence_weight=1.0, update_rate=0.5,
        strategy="rational",
    )
    assert trace.accepted is True
    assert trace.error_source is None
    assert trace.contradiction == 0.0
