import unittest
import urllib.error

from theater.agents import DeterministicModelClient, ProviderDiagnostics
from theater.settings import Settings


class FakeResponse:
    def __init__(self, body):
        self.body = body

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self):
        return self.body


class ProviderDiagnosticsTests(unittest.TestCase):
    def test_provider_diagnostics_reports_disabled_live_api_without_secret(self):
        diagnostics = ProviderDiagnostics(Settings(api_key="test-secret-token", enable_live_api=False))

        report = diagnostics.report()

        self.assertIs(report["live_api_enabled"], False)
        self.assertEqual(report["models"], [])
        self.assertNotIn("test-secret-token", str(report))

    def test_deterministic_client_uses_provider_model_alias_in_trace(self):
        result = DeterministicModelClient().complete_json("producer", "生成档案馆", "gpt-5.5")

        self.assertEqual(result["provider_model"], "gpt-5.5")

    def test_provider_diagnostics_can_probe_chat_upstream_permissions(self):
        def fake_urlopen(req):
            if req.full_url.endswith("/models"):
                return FakeResponse(b'{"data":[{"id":"gpt-5.4"},{"id":"gpt-5.5"}]}')
            raise urllib.error.HTTPError(req.full_url, 502, "Bad Gateway", {}, None)

        diagnostics = ProviderDiagnostics(
            Settings(api_key="test-secret-token", enable_live_api=True, model_fast="gpt5.4", model_deep="gpt5.5"),
            urlopen=fake_urlopen,
        )

        report = diagnostics.report(probe_chat=True)

        self.assertIs(report["supports_fast"], True)
        self.assertIs(report["supports_deep"], True)
        self.assertEqual(report["chat_probe"]["fast"]["status"], "error")
        self.assertIn("HTTP 502", report["chat_probe"]["fast"]["error"])
        self.assertNotIn("test-secret-token", str(report))

    def test_local_provider_diagnostics_allow_empty_key_and_send_no_auth(self):
        requests = []

        def fake_urlopen(req):
            requests.append(req)
            return FakeResponse(b'{"data":[{"id":"local-model"}]}')

        diagnostics = ProviderDiagnostics(
            Settings(
                base_url="http://127.0.0.1:1234/v1",
                api_key="",
                model_fast="local-model",
                model_deep="local-model",
                enable_live_api=True,
            ),
            urlopen=fake_urlopen,
        )
        report = diagnostics.report()

        self.assertTrue(report["live_api_enabled"])
        self.assertEqual(report["status"], "ok")
        self.assertEqual(report["models"], ["local-model"])
        self.assertNotIn("Authorization", dict(requests[0].headers))


if __name__ == "__main__":
    unittest.main()
