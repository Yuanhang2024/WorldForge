import json
import os
import sys
import tempfile
import traceback
from pathlib import Path

os.environ["AI_THEATER_BASE_URL"] = "http://127.0.0.1:1234/v1"
os.environ["AI_THEATER_API_KEY"] = ""
os.environ["AI_THEATER_MODEL_FAST"] = "deepseek-v4-flash"
os.environ["AI_THEATER_MODEL_DEEP"] = "deepseek-v4-flash"
sys.path.insert(0, str(Path(__file__).resolve().parent / "backend"))

from theater.onboarding import OnboardingFlow


DESCRIPTION = (
    "漂浮在气态巨行星上层的自治研究站，居民通过可验证实验协商公共资源；"
    "初始状态包含氧气、能源、信任与当前轮次。"
)


def emit(stage, result):
    print(
        json.dumps(
            {
                "stage": stage,
                "ok": result.get("ok"),
                "error_code": result.get("error_code"),
                "error": result.get("error"),
                "source": result.get("source"),
            },
            ensure_ascii=False,
        ),
        flush=True,
    )


with tempfile.TemporaryDirectory(prefix="worldforge_llm_e2e_") as temp_dir:
    root = Path(temp_dir)
    flow = OnboardingFlow(state_root=root)
    try:
        world = flow.propose_world(DESCRIPTION)
        emit("world.propose", world)
        if not world.get("ok"):
            raise RuntimeError(world)
        confirmed_world = flow.confirm_world(DESCRIPTION, world["draft"])
        emit("world.confirm", confirmed_world)
        if not confirmed_world.get("ok"):
            raise RuntimeError(confirmed_world)
        world_id = confirmed_world["world_id"]

        characters = flow.propose_characters(world_id, DESCRIPTION)
        emit("characters.propose", characters)
        if not characters.get("ok"):
            raise RuntimeError(characters)
        confirmed_characters = flow.confirm_characters(
            world_id, characters["draft"],
        )
        emit("characters.confirm", confirmed_characters)
        if not confirmed_characters.get("ok"):
            raise RuntimeError(confirmed_characters)

        rules_gui = flow.propose_rules_gui(world_id, DESCRIPTION)
        emit("rules_gui.propose", rules_gui)
        if not rules_gui.get("ok"):
            raise RuntimeError(rules_gui)
        confirmed_rules_gui = flow.confirm_rules_gui(
            world_id,
            rules_gui["draft_rules"],
            rules_gui["draft_gui"],
        )
        emit("rules_gui.confirm", confirmed_rules_gui)
        if not confirmed_rules_gui.get("ok"):
            raise RuntimeError(confirmed_rules_gui)

        gameplay = flow.propose_gameplay(world_id, DESCRIPTION)
        emit("gameplay.propose", gameplay)
        if not gameplay.get("ok"):
            raise RuntimeError(gameplay)
        confirmed_gameplay = flow.confirm_gameplay(
            world_id, gameplay["draft"],
        )
        emit("gameplay.confirm", confirmed_gameplay)
        if not confirmed_gameplay.get("ok"):
            raise RuntimeError(confirmed_gameplay)

        finalized = flow.finalize(world_id)
        emit("finalize", finalized)
        if not finalized.get("ok"):
            raise RuntimeError(finalized)

        print(
            json.dumps(
                {
                    "result": "PASS",
                    "world_id": world_id,
                    "artifacts": sorted(
                        str(path.relative_to(root))
                        for path in root.rglob("*")
                        if path.is_file()
                    ),
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
    except Exception:
        traceback.print_exc()
        print(json.dumps({"result": "FAIL"}), flush=True)
        raise
