"""Tests for backend.theater.rule_generator normalization + repair.

Covers the auto-fix surface used when the LLM emits op aliases (gte/lte/neq/
multiply/divide/subtract/...) or omits trigger/priority/effect.op fields.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_rule_normalizer.py -q
"""

from __future__ import annotations

import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.rule_generator import RuleGenerator
from theater.world_kernel_host import (
    ExprEvaluator,
    LEAF_OPS,
    RuleCompiler,
    WorldKernelHost,
    WorldKernelSpec,
    WorldRule,
)


# =====================================================================
# Op alias rewriting in _normalize_ast
# =====================================================================


class TestNormalizeOpAliases:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_gte_to_ge(self) -> None:
        node = {"op": "gte", "args": [{"ref": "price"}, {"const": 0}]}
        self.gen._normalize_ast(node)
        assert node["op"] == "ge"

    def test_lte_to_le(self) -> None:
        node = {"op": "lte", "args": [{"ref": "x"}, {"const": 10}]}
        self.gen._normalize_ast(node)
        assert node["op"] == "le"

    def test_neq_to_ne(self) -> None:
        node = {"op": "neq", "args": [{"ref": "x"}, {"const": 0}]}
        self.gen._normalize_ast(node)
        assert node["op"] == "ne"

    def test_ge_le_ne_already_canonical_unchanged(self) -> None:
        for op in ("ge", "le", "ne", "lt", "gt", "eq"):
            node = {"op": op, "args": [{"const": 1}, {"const": 2}]}
            self.gen._normalize_ast(node)
            assert node["op"] == op  # no-op for canonical names

    def test_gteq_synonym_to_ge(self) -> None:
        node = {"op": "greater_or_equal", "args": [{"const": 1}, {"const": 2}]}
        self.gen._normalize_ast(node)
        assert node["op"] == "ge"

    def test_le_symbol_to_le(self) -> None:
        for alias in ("<=", "≤"):
            node = {"op": alias, "args": [{"const": 1}, {"const": 2}]}
            self.gen._normalize_ast(node)
            assert node["op"] == "le", alias

    def test_ne_symbol_to_ne(self) -> None:
        for alias in ("!=", "≠"):
            node = {"op": alias, "args": [{"const": 1}, {"const": 2}]}
            self.gen._normalize_ast(node)
            assert node["op"] == "ne", alias


# =====================================================================
# Long-name arithmetic aliases
# =====================================================================


class TestNormalizeArithAliases:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_multiply_to_mul(self) -> None:
        node = {"op": "multiply",
                "args": [{"ref": "rate"}, {"ref": "qty"}]}
        self.gen._normalize_ast(node)
        assert node["op"] == "mul"

    def test_divide_to_div(self) -> None:
        node = {"op": "divide", "args": [{"ref": "x"}, {"ref": "y"}]}
        self.gen._normalize_ast(node)
        assert node["op"] == "div"

    def test_subtract_to_sub(self) -> None:
        node = {"op": "subtract", "args": [{"const": 5}, {"const": 3}]}
        self.gen._normalize_ast(node)
        assert node["op"] == "sub"

    def test_add_synonyms(self) -> None:
        for alias in ("plus", "addition"):
            node = {"op": alias, "args": [{"const": 1}, {"const": 2}]}
            self.gen._normalize_ast(node)
            assert node["op"] == "add", alias

    def test_negate_to_neg(self) -> None:
        node = {"op": "negate", "args": [{"const": 5}]}
        self.gen._normalize_ast(node)
        assert node["op"] == "neg"


# =====================================================================
# Nested AST recursion
# =====================================================================


class TestNormalizeRecursive:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_nested_args_rewritten(self) -> None:
        node = {
            "op": "and",
            "args": [
                {"op": "gte", "args": [{"ref": "x"}, {"const": 0}]},
                {"op": "lte", "args": [{"ref": "x"}, {"const": 100}]},
            ],
        }
        self.gen._normalize_ast(node)
        assert node["args"][0]["op"] == "ge"
        assert node["args"][1]["op"] == "le"

    def test_deeply_nested_args_rewritten(self) -> None:
        node = {
            "op": "multiply",
            "args": [
                {"op": "add", "args": [
                    {"op": "gte", "args": [{"ref": "a"}, {"const": 0}]},
                    {"const": 1},
                ]},
                {"op": "subtract", "args": [{"ref": "b"}, {"const": 2}]},
            ],
        }
        self.gen._normalize_ast(node)
        assert node["op"] == "mul"
        assert node["args"][0]["op"] == "add"
        assert node["args"][0]["args"][0]["op"] == "ge"
        assert node["args"][1]["op"] == "sub"

    def test_list_args_rewritten(self) -> None:
        # Inside a 'changes' list, each entry is a dict; nested op must rewrite.
        effect = {
            "op": "writes",
            "changes": [
                {"path": "x",
                 "value": {"op": "gte", "args": [{"ref": "x"}, {"const": 0}]}},
                {"path": "y",
                 "value": {"op": "multiply", "args": [{"const": 2}, {"const": 3}]}},
            ],
        }
        self.gen._normalize_ast(effect)
        assert effect["changes"][0]["value"]["op"] == "ge"
        assert effect["changes"][1]["value"]["op"] == "mul"

    def test_unknown_op_left_intact_with_warning(self) -> None:
        node = {"op": "exec_thing", "args": [{"const": 1}]}
        self.gen._normalize_ast(node)
        # Unknown op is NOT rewritten.
        assert node["op"] == "exec_thing"
        warns = self.gen.get_normalize_warnings()
        assert any("exec_thing" in w for w in warns)


# =====================================================================
# Rule-level structural repair
# =====================================================================


class TestRepairSpec:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def test_invariant_trigger_forced_to_none(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[
                WorldRule(
                    rule_id="inv1",
                    kind="invariant",
                    trigger="bogus_event",   # bad — will be forced to None
                    condition=None,
                    effect={"op": "predicate",
                            "expr": {"const": True}},
                ),
            ],
        )
        self.gen._repair_spec(spec)
        assert spec.rules[0].trigger is None

    def test_dynamic_missing_trigger_defaults_to_turn_tick(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[
                WorldRule(
                    rule_id="dyn1",
                    kind="dynamic",
                    trigger="",   # falsy → defaults to turn.tick
                    condition=None,
                    effect={"op": "writes",
                            "changes": [{"path": "x",
                                          "value": {"const": 1}}]},
                ),
            ],
        )
        self.gen._repair_spec(spec)
        assert spec.rules[0].trigger == "turn.tick"

    def test_minigame_missing_trigger_defaults_to_turn_tick(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[
                WorldRule(
                    rule_id="mg1",
                    kind="minigame",
                    trigger=None,
                    condition=None,
                    effect={"op": "writes",
                            "changes": [{"path": "x",
                                          "value": {"const": 1}}]},
                ),
            ],
        )
        self.gen._repair_spec(spec)
        assert spec.rules[0].trigger == "turn.tick"

    def test_missing_priority_defaults_to_zero(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[
                WorldRule(
                    rule_id="d1",
                    kind="dynamic",
                    trigger="tick",
                    condition=None,
                    effect={"op": "writes",
                            "changes": [{"path": "x",
                                          "value": {"const": 1}}]},
                    priority=None,   # repair → 0
                ),
            ],
        )
        self.gen._repair_spec(spec)
        assert spec.rules[0].priority == 0

    def test_existing_priority_preserved(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[
                WorldRule(
                    rule_id="d1",
                    kind="dynamic",
                    trigger="tick",
                    condition=None,
                    effect={"op": "writes",
                            "changes": [{"path": "x",
                                          "value": {"const": 1}}]},
                    priority=42,
                ),
            ],
        )
        self.gen._repair_spec(spec)
        assert spec.rules[0].priority == 42

    def test_missing_description_defaults_to_empty_string(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[
                WorldRule(
                    rule_id="d1",
                    kind="dynamic",
                    trigger="tick",
                    condition=None,
                    effect={"op": "writes",
                            "changes": [{"path": "x",
                                          "value": {"const": 1}}]},
                    description=None,
                ),
            ],
        )
        self.gen._repair_spec(spec)
        assert spec.rules[0].description == ""

    def test_effect_change_missing_op_defaults_to_set(self) -> None:
        spec = WorldKernelSpec(
            world_type="x",
            rules=[
                WorldRule(
                    rule_id="d1",
                    kind="dynamic",
                    trigger="tick",
                    condition=None,
                    effect={
                        "op": "writes",
                        "changes": [
                            {"path": "x", "value": {"const": 1}},  # no 'op'
                            {"path": "y", "op": "delete"},          # keeps 'delete'
                        ],
                    },
                ),
            ],
        )
        self.gen._repair_spec(spec)
        changes = spec.rules[0].effect["changes"]
        assert changes[0]["op"] == "set"
        assert changes[1]["op"] == "delete"


# =====================================================================
# End-to-end via RuleGenerator.generate (LLM path with slop)
# =====================================================================


def _spec_with_aliases() -> dict:
    """A spec dict an LLM might emit: ``gte``, ``lte``, ``multiply``,
    ``divide``, no explicit priority, no trigger on a dynamic rule, etc."""
    return {
        "world_type": "llm_aliased",
        "rules": [
            {
                "rule_id": "llm_price_inflate",
                "kind": "dynamic",
                "trigger": "trade.executed",
                "condition": {"op": "gte",
                              "args": [{"ref": "demand"},
                                       {"ref": "supply"}]},
                "effect": {
                    "op": "writes",
                    "changes": [{
                        "path": "price",
                        "value": {"op": "multiply",
                                  "args": [{"ref": "price"}, {"const": 1.1}]},
                    }],
                },
                "description": "demand>=supply → price * 1.1",
                # no priority field → repair fills 0
            },
            {
                "rule_id": "llm_price_floor",
                "kind": "invariant",
                # invariant with a trigger (illegal) → repair forces None
                "trigger": "should_be_none",
                "condition": None,
                "effect": {
                    "op": "predicate",
                    "expr": {"op": "lte",
                             "args": [{"const": 0},
                                      {"ref": "price"}]},
                },
                "description": "price is non-negative (LLM wrote it backwards)",
                "priority": 100,
            },
        ],
        "params": {},
    }


class TestGenerateAutoFixesLLMSlop:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    def _run_once(self, raw: str) -> WorldKernelSpec:
        calls = {"n": 0}

        def _llm(prompt: str) -> str:
            calls["n"] += 1
            return raw

        # Description that contains no preset keyword → forces LLM path,
        # but if LLM output is repaired we use it directly (no fallback).
        spec = self.gen.generate(
            "a totally abstract zen garden of whispers", llm_fn=_llm
        )
        assert calls["n"] == 1
        return spec

    def test_gte_lte_in_condition_rewritten_then_validated(self) -> None:
        raw = json.dumps(_spec_with_aliases())
        spec = self._run_once(raw)
        # Spec must have been accepted (NOT fallen back to economy preset).
        assert spec.world_type == "llm_aliased"
        # Condition op is now 'ge' (canonical).
        cond = spec.rules[0].condition
        assert cond["op"] == "ge"
        # Effect is now in the flat writes form
        # ``{"writes": path, "op": ..., "value": <ast>}`` and the
        # underlying value op is 'mul' (not 'multiply').
        eff = spec.rules[0].effect
        assert eff["writes"] == "price"
        assert eff["value"]["op"] == "mul"

    def test_invariant_trigger_repaired_to_none(self) -> None:
        raw = json.dumps(_spec_with_aliases())
        spec = self._run_once(raw)
        assert spec.rules[1].kind == "invariant"
        assert spec.rules[1].trigger is None

    def test_priority_repaired(self) -> None:
        raw = json.dumps(_spec_with_aliases())
        spec = self._run_once(raw)
        assert spec.rules[0].priority == 0  # missing → 0

    def test_full_pipeline_validates_and_compiles(self) -> None:
        raw = json.dumps(_spec_with_aliases())
        spec = self._run_once(raw)
        issues = RuleCompiler().validate_spec(spec)
        assert issues == [], f"unexpected issues: {issues}"
        kernel = RuleCompiler(seed=0).compile(spec)
        assert kernel.world_type == "llm_aliased"

    def test_repaired_spec_runs_in_host(self) -> None:
        raw = json.dumps(_spec_with_aliases())
        spec = self._run_once(raw)
        host = WorldKernelHost(
            spec,
            {"demand": 10, "supply": 5, "price": 1.0},
            seed=0,
        )
        # demand >= supply (gte→ge): rule fires, price *= 1.1
        changes = host.step({"trigger": "trade.executed"})
        assert any(c["path"] == "price" for c in changes)
        assert host.query("price") == pytest.approx(1.1)


# =====================================================================
# New whitelisted ops (if / sum / avg / count) round-trip via ExprEvaluator
# =====================================================================


class TestNewWhitelistOps:
    def setup_method(self) -> None:
        # Sanity check the ops are actually on the whitelist now.
        from theater.world_kernel_host import WHITELIST_OPS
        assert "if" in WHITELIST_OPS
        assert "sum" in WHITELIST_OPS
        assert "avg" in WHITELIST_OPS
        assert "count" in WHITELIST_OPS
        self.ev = ExprEvaluator(rng=None)

    def test_if_true_branch(self) -> None:
        node = {"op": "if",
                "args": [{"const": True}, {"const": 10}, {"const": 20}]}
        assert self.ev.eval(node, {}) == 10

    def test_if_false_branch(self) -> None:
        node = {"op": "if",
                "args": [{"const": False}, {"const": 10}, {"const": 20}]}
        assert self.ev.eval(node, {}) == 20

    def test_if_with_ref_condition(self) -> None:
        node = {"op": "if",
                "args": [{"ref": "flag"},
                         {"const": "on"},
                         {"const": "off"}]}
        assert self.ev.eval(node, {"flag": True}) == "on"
        assert self.ev.eval(node, {"flag": False}) == "off"

    def test_sum_of_list(self) -> None:
        node = {"op": "sum", "args": [{"const": [1, 2, 3, 4]}]}
        assert self.ev.eval(node, {}) == 10

    def test_sum_empty_list(self) -> None:
        node = {"op": "sum", "args": [{"const": []}]}
        assert self.ev.eval(node, {}) == 0

    def test_avg_of_list(self) -> None:
        node = {"op": "avg", "args": [{"const": [2, 4, 6, 8]}]}
        assert self.ev.eval(node, {}) == 5.0

    def test_count_of_list(self) -> None:
        node = {"op": "count", "args": [{"const": ["a", "b", "c"]}]}
        assert self.ev.eval(node, {}) == 3

    def test_count_via_ref(self) -> None:
        node = {"op": "count", "args": [{"ref": "items"}]}
        assert self.ev.eval(node, {"items": [1, 2, 3, 4, 5]}) == 5

    def test_nested_sum_in_ge(self) -> None:
        node = {"op": "ge",
                "args": [
                    {"op": "sum", "args": [{"const": [5, 6, 7]}]},
                    {"const": 18},
                ]}
        # 5+6+7 = 18, so 18 >= 18 → True
        assert self.ev.eval(node, {}) is True

    def test_aggregations_validate_via_compiler(self) -> None:
        rule = WorldRule(
            rule_id="agg_rule",
            kind="dynamic",
            trigger="tick",
            condition={"op": "ge",
                       "args": [
                           {"op": "sum", "args": [{"ref": "xs"}]},
                           {"const": 0},
                       ]},
            effect={"op": "writes",
                    "changes": [{"path": "score",
                                  "value": {"op": "avg",
                                            "args": [{"ref": "xs"}]}}]},
        )
        spec = WorldKernelSpec(world_type="x", rules=[rule])
        issues = RuleCompiler().validate_spec(spec)
        assert issues == []


# =====================================================================
# Determinism: warnings list is safe to read repeatedly
# =====================================================================


class TestNormalizerAPIStability:
    def test_get_normalize_warnings_returns_copy(self) -> None:
        gen = RuleGenerator()
        node = {"op": "exec_thing", "args": [{"const": 1}]}
        gen._normalize_ast(node)
        a = gen.get_normalize_warnings()
        b = gen.get_normalize_warnings()
        assert a == b
        assert a is not b  # different list objects

    def test_unknown_op_reach_validator_rejected(self) -> None:
        # An unknown op that we cannot rewrite → must fail validation.
        rule = WorldRule(
            rule_id="r",
            kind="dynamic",
            trigger="t",
            condition={"op": "exec_thing", "args": [{"const": 1}]},
            effect={"op": "writes",
                    "changes": [{"path": "p", "value": {"const": 1}}]},
        )
        spec = WorldKernelSpec(world_type="x", rules=[rule])
        issues = RuleCompiler().validate_spec(spec)
        assert any("exec_thing" in m for m in issues)
