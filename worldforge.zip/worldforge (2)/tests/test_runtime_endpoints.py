import json
import os
import tempfile
import threading
import unittest
from urllib import request

from theater.agents import DeterministicModelClient
from theater.server import create_server


class RuntimeEndpointTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.previous = dict(os.environ)
        os.environ["AI_THEATER_ENABLE_LIVE_API"] = "true"
        os.environ["AI_THEATER_BASE_URL"] = "http://127.0.0.1:1/v1"
        os.environ["AI_THEATER_MODEL_FAST"] = "test-model"
        os.environ["AI_THEATER_MODEL_DEEP"] = "test-model"
        os.environ["AI_THEATER_DATA_DIR"] = self.directory.name
        self.server = create_server(host="127.0.0.1", port=0)
        # Runtime endpoint plumbing is isolated with an explicit test double.
        self.server.orchestrator.model_client = DeterministicModelClient()
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        os.environ.clear()
        os.environ.update(self.previous)
        self.directory.cleanup()

    def post_json(self, path, payload):
        req = request.Request(
            f"{self.base_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        return json.loads(request.urlopen(req, timeout=5).read())

    def test_dispatch_persists_task_queue_and_state_exposes_runtime_managers(self):
        body = self.post_json("/api/dispatch", {"session_id": "story_runtime", "message": "生成档案馆场景"})
        self.assertTrue(body["tasks"])

        state = json.loads(request.urlopen(f"{self.base_url}/api/state", timeout=5).read())

        self.assertIn("task_queue", state)
        self.assertIn("game_sessions", state)
        self.assertEqual([task["task_id"] for task in state["task_queue"]], [task["task_id"] for task in body["tasks"]])

    def test_runtime_endpoints_support_game_and_possession_exit(self):
        possession = self.post_json("/api/dispatch", {"session_id": "story_possess", "message": "我要夺舍 Aster"})
        self.assertTrue(possession["character_updates"][0]["possessed"])

        game = self.post_json("/api/game/step", {"session_id": "story_possess", "command": "inspect"})
        self.assertEqual(game["tick"], 1)

        exit_body = self.post_json("/api/possession/exit", {"character_id": "aster"})
        self.assertFalse(exit_body["character"]["possessed"])
        self.assertEqual(exit_body["character"]["pending_ai_actions"], [])

    def test_task_status_endpoint_marks_persisted_task(self):
        body = self.post_json("/api/dispatch", {"session_id": "story_tasks", "message": "生成档案馆场景"})
        task_id = body["tasks"][0]["task_id"]

        marked = self.post_json("/api/tasks/mark", {"session_id": "story_tasks", "task_id": task_id, "status": "running"})

        self.assertEqual(marked["task"]["task_id"], task_id)
        self.assertEqual(marked["task"]["status"], "running")

    def test_embedding_endpoint_returns_local_vector_without_secrets(self):
        embedding = self.post_json("/api/memory/embed", {"text": "Storm Archive memory"})
        self.assertEqual(embedding["dimensions"], 32)
        self.assertEqual(len(embedding["embedding"]), 32)
        self.assertNotIn("sk-", json.dumps(embedding))


if __name__ == "__main__":
    unittest.main()
