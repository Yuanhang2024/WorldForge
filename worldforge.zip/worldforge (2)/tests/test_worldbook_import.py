"""Tests for the worldbook (lorebook) import pipeline.

Covers:
- parse_lorebook: Tavern dict-of-entries, Tavern list-of-entries, naive,
  top-level list, key→content folding, default source
- validate: empty title/content, duplicate titles
- compile_worldbook: shape, count, empty input, world_id pass-through
- merge / dedup behavior (via the compile output)
"""

import unittest

from theater.worldbook_import import WorldBookEntry, WorldbookImporter


class ParseLorebookTests(unittest.TestCase):
    def test_tavern_dict_of_entries(self):
        data = {
            "entries": {
                "0": {"comment": "Seville", "content": "A city in Spain.",
                      "key": ["seville", "spain"]},
                "1": {"comment": "Carmen", "content": "A fiery gypsy."},
            }
        }
        entries = WorldbookImporter.parse_lorebook(data)
        self.assertEqual(len(entries), 2)
        self.assertEqual(entries[0].title, "Seville")
        self.assertEqual(entries[1].title, "Carmen")
        # key folded into content as a keyword tag
        self.assertIn("[关键词: seville, spain]", entries[0].content)
        self.assertIn("A city in Spain.", entries[0].content)
        # entries without key have no keyword tag
        self.assertNotIn("[关键词", entries[1].content)

    def test_tavern_list_of_entries(self):
        data = {"entries": [
            {"comment": "Tavern", "content": "A dark tavern."},
            {"comment": "Inn", "content": "A cozy inn.", "key": ["inn"]},
        ]}
        entries = WorldbookImporter.parse_lorebook(data)
        self.assertEqual(len(entries), 2)
        self.assertEqual(entries[0].title, "Tavern")
        self.assertEqual(entries[1].title, "Inn")

    def test_naive_format_with_title_content_source(self):
        data = {"entries": [
            {"title": "Dragon", "content": "Scales the beast.", "source": "bestiary"},
            {"title": "Castle", "content": "A tall keep."},
        ]}
        entries = WorldbookImporter.parse_lorebook(data)
        self.assertEqual(len(entries), 2)
        self.assertEqual(entries[0].title, "Dragon")
        self.assertEqual(entries[0].source, "bestiary")
        # default source when missing
        self.assertEqual(entries[1].source, "imported_lorebook")

    def test_top_level_list(self):
        data = [
            {"title": "A", "content": "aaa"},
            {"title": "B", "content": "bbb"},
        ]
        entries = WorldbookImporter.parse_lorebook(data)
        self.assertEqual(len(entries), 2)
        self.assertEqual(entries[1].title, "B")

    def test_key_string_folds_into_content(self):
        data = {"entries": [{"comment": "X", "content": "body", "key": "solo"}]}
        entries = WorldbookImporter.parse_lorebook(data)
        self.assertIn("[关键词: solo]", entries[0].content)

    def test_empty_input_returns_empty(self):
        self.assertEqual(WorldbookImporter.parse_lorebook({}), [])
        self.assertEqual(WorldbookImporter.parse_lorebook(None), [])
        self.assertEqual(WorldbookImporter.parse_lorebook({"entries": []}), [])

    def test_skips_non_dict_entries(self):
        data = {"entries": [{"title": "ok", "content": "ok"}, "junk", 42, None]}
        entries = WorldbookImporter.parse_lorebook(data)
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].title, "ok")

    def test_skips_entries_without_title_and_content(self):
        data = {"entries": [{"random": "field"}, {"title": "", "content": ""}]}
        entries = WorldbookImporter.parse_lorebook(data)
        self.assertEqual(entries, [])


class ValidateTests(unittest.TestCase):
    def test_clean_entries_no_warnings(self):
        entries = [
            WorldBookEntry(title="A", content="aaa", source="s"),
            WorldBookEntry(title="B", content="bbb", source="s"),
        ]
        self.assertEqual(WorldbookImporter.validate(entries), [])

    def test_empty_title_warns(self):
        entries = [WorldBookEntry(title="", content="aaa", source="s")]
        warnings = WorldbookImporter.validate(entries)
        self.assertTrue(any("title is empty" in w for w in warnings))

    def test_empty_content_warns(self):
        entries = [WorldBookEntry(title="A", content="", source="s")]
        warnings = WorldbookImporter.validate(entries)
        self.assertTrue(any("content is empty" in w for w in warnings))

    def test_duplicate_title_warns(self):
        entries = [
            WorldBookEntry(title="dup", content="a", source="s"),
            WorldBookEntry(title="dup", content="b", source="s"),
        ]
        warnings = WorldbookImporter.validate(entries)
        self.assertTrue(any("duplicate title 'dup'" in w for w in warnings))


class CompileWorldbookTests(unittest.TestCase):
    def test_compile_returns_full_shape(self):
        data = {"entries": [{"title": "A", "content": "aaa", "source": "s"}]}
        result = WorldbookImporter.compile_worldbook(data, target_world_id="w1")
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["world_id"], "w1")
        self.assertEqual(result["worldbook"][0],
                         {"title": "A", "content": "aaa", "source": "s"})
        self.assertEqual(result["warnings"], [])

    def test_compile_empty_input(self):
        result = WorldbookImporter.compile_worldbook({})
        self.assertEqual(result["count"], 0)
        self.assertEqual(result["worldbook"], [])

    def test_compile_carries_validation_warnings(self):
        data = {"entries": [
            {"title": "dup", "content": "a"},
            {"title": "dup", "content": "b"},
        ]}
        result = WorldbookImporter.compile_worldbook(data)
        self.assertEqual(result["count"], 2)
        self.assertTrue(any("duplicate title 'dup'" in w for w in result["warnings"]))

    def test_compile_tavern_dict_keys_folded(self):
        data = {"entries": {"0": {"comment": "c", "content": "x", "key": ["k1"]}}}
        result = WorldbookImporter.compile_worldbook(data)
        self.assertEqual(result["count"], 1)
        self.assertIn("[关键词: k1]", result["worldbook"][0]["content"])


if __name__ == "__main__":
    unittest.main()
