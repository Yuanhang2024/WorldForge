"""Tests for backend.theater.gameplay_validator (spec §9.2 库外玩法验收).

Covers the four hard gates:
  - legal action generator (pass / fail)
  - termination (pass / fail with infinite loop)
  - no dominant pure strategy (pass / fail with trivial always-win game)
  - no deadlock (pass / fail with dead-end non-terminal state)
  - validate_all aggregation
  - restricted-expression DSL evaluation (whitelist, ref/const leaves, ops)
  - GameplaySpec serialization round-trip

Run with::

    PYTHONPATH=backend python -m pytest tests/test_gameplay_validator.py -q
"""

from __future__ import annotations

import os
import sys
from typing import Any, Dict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.gameplay_validator import (
    GameplaySpec,
    GameplayValidator,
    ExprEvalError,
)


# =====================================================================
# Spec factories
# =====================================================================


def _countdown_spec() -> GameplaySpec:
    """A valid, termination-safe countdown game (passes all four gates).

    State: count (10→0), turn (0→∞).  Action "dec" decrements count.
    Terminal when count≤0 OR turn≥50 (structural termination guarantee).
    Payoff = turn (fewer turns = better, but both first/last strategies
    pick the only action → all tie → no dominant strategy).
    """
    return GameplaySpec(
        name="countdown",
        description="count down from 10",
        state_schema={"count": 10, "turn": 0},
        legal_actions=[
            {"id": "dec",
             "condition": {"op": "gt", "args": [{"ref": "count"}, {"const": 0}]}},
        ],
        terminal={"op": "or", "args": [
            {"op": "le", "args": [{"ref": "count"}, {"const": 0}]},
            {"op": "ge", "args": [{"ref": "turn"}, {"const": 50}]},
        ]},
        payoff={"op": "ref", "path": "turn"},
        apply={"dec": {"writes": [
            {"path": "count",
             "value": {"op": "sub", "args": [{"ref": "count"}, {"const": 1}]}},
            {"path": "turn",
             "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
        ]}},
    )


def _infinite_spec() -> GameplaySpec:
    """Never terminates: terminal predicate is always false; turn grows."""
    return GameplaySpec(
        name="infinite",
        state_schema={"turn": 0},
        legal_actions=[{"id": "tick"}],
        # terminal never true (turn is never < -1)
        terminal={"op": "lt", "args": [{"ref": "turn"}, {"const": -1}]},
        payoff={"op": "ref", "path": "turn"},
        apply={"tick": {"writes": [
            {"path": "turn",
             "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}}]}},
    )


def _deadlock_spec() -> GameplaySpec:
    """Dead-end: actions stop at turn<5 but terminal requires turn>=10."""
    return GameplaySpec(
        name="deadlock",
        state_schema={"turn": 0, "score": 0},
        legal_actions=[
            {"id": "tick",
             "condition": {"op": "lt", "args": [{"ref": "turn"}, {"const": 5}]}},
        ],
        terminal={"op": "ge", "args": [{"ref": "turn"}, {"const": 10}]},
        payoff={"op": "ref", "path": "score"},
        apply={"tick": {"writes": [
            {"path": "turn",
             "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}}]}},
    )


def _dominant_spec() -> GameplaySpec:
    """Dominant strategy: "good" gives +10, "bad" gives -10.  The "first"
    strategy (always pick actions[0]="good") wins every decided game."""
    return GameplaySpec(
        name="dominant",
        state_schema={"score": 0, "turn": 0},
        legal_actions=[
            {"id": "good",
             "condition": {"op": "lt", "args": [{"ref": "turn"}, {"const": 1}]}},
            {"id": "bad",
             "condition": {"op": "lt", "args": [{"ref": "turn"}, {"const": 1}]}},
        ],
        terminal={"op": "ge", "args": [{"ref": "turn"}, {"const": 1}]},
        payoff={"op": "ref", "path": "score"},
        apply={
            "good": {"writes": [
                {"path": "score",
                 "value": {"op": "add", "args": [{"ref": "score"}, {"const": 10}]}},
                {"path": "turn",
                 "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
            ]},
            "bad": {"writes": [
                {"path": "score",
                 "value": {"op": "sub", "args": [{"ref": "score"}, {"const": 10}]}},
                {"path": "turn",
                 "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
            ]},
        },
    )


def _no_legal_action_spec() -> GameplaySpec:
    """Non-terminal initial state with zero legal actions."""
    return GameplaySpec(
        name="no_legal",
        state_schema={"turn": 0},
        legal_actions=[],  # no actions at all
        terminal={"op": "ge", "args": [{"ref": "turn"}, {"const": 10}]},
        payoff={"op": "ref", "path": "turn"},
        apply={},
    )


# =====================================================================
# CHECK 1: legal action generator
# =====================================================================


def test_legal_action_generator_pass():
    v = GameplayValidator()
    r = v.check_legal_action_generator(_countdown_spec())
    assert r.passed, r.reason


def test_legal_action_generator_fail_empty_actions():
    v = GameplayValidator()
    r = v.check_legal_action_generator(_no_legal_action_spec())
    assert not r.passed
    assert "no legal actions" in r.reason


# =====================================================================
# CHECK 2: termination
# =====================================================================


def test_termination_pass():
    v = GameplayValidator()
    r = v.check_termination(_countdown_spec(), max_steps=100)
    assert r.passed, r.reason


def test_termination_fail_infinite_loop():
    v = GameplayValidator()
    r = v.check_termination(_infinite_spec(), max_steps=50)
    assert not r.passed
    assert "terminate" in r.reason or "cycle" in r.reason


def test_termination_fail_dead_end():
    v = GameplayValidator()
    # Deadlock spec reaches a non-terminal state with no actions → not terminating.
    r = v.check_termination(_deadlock_spec(), max_steps=100)
    assert not r.passed


# =====================================================================
# CHECK 3: no dominant pure strategy
# =====================================================================


def test_no_dominant_strategy_pass():
    v = GameplayValidator()
    r = v.check_no_dominant_strategy(_countdown_spec(), samples=60)
    assert r.passed, r.reason


def test_no_dominant_strategy_fail_trivial_win():
    v = GameplayValidator()
    r = v.check_no_dominant_strategy(_dominant_spec(), samples=60)
    assert not r.passed
    assert "dominant" in r.reason


# =====================================================================
# CHECK 4: no deadlock
# =====================================================================


def test_no_deadlock_pass():
    v = GameplayValidator()
    r = v.check_no_deadlock(_countdown_spec())
    assert r.passed, r.reason


def test_no_deadlock_fail_dead_end():
    v = GameplayValidator()
    r = v.check_no_deadlock(_deadlock_spec())
    assert not r.passed
    assert "deadlock" in r.reason or "no legal actions" in r.reason


def test_no_deadlock_fail_non_terminating_region():
    v = GameplayValidator()
    r = v.check_no_deadlock(_infinite_spec())
    assert not r.passed
    # infinite spec never reaches a terminal → non-terminating region
    assert "terminal" in r.reason or "deadlock" in r.reason


# =====================================================================
# AGGREGATE: validate_all
# =====================================================================


def test_validate_all_pass_for_valid_spec():
    v = GameplayValidator()
    report = v.validate_all(_countdown_spec())
    assert report.passed, report.reasons
    assert set(report.checks.keys()) == {"legal", "termination",
                                         "no_dominant", "no_deadlock"}
    assert report.reasons == []


def test_validate_all_fail_aggregates_reasons():
    v = GameplayValidator()
    report = v.validate_all(_dominant_spec())
    assert not report.passed
    assert any("no_dominant" in r for r in report.reasons)


def test_validate_all_to_dict_json_safe():
    v = GameplayValidator()
    report = v.validate_all(_countdown_spec())
    d = report.to_dict()
    assert d["passed"] is True
    assert "checks" in d and "reasons" in d
    # Must be JSON-serializable (no dataclass objects leaking).
    import json
    json.dumps(d)


# =====================================================================
# Restricted-expression DSL
# =====================================================================


def test_eval_expr_arithmetic_and_logic():
    v = GameplayValidator()
    state = {"a": 3, "b": 4}
    assert v.eval_expr({"op": "add", "args": [{"ref": "a"}, {"const": 1}]}, state) == 4.0
    assert v.eval_expr({"op": "mul", "args": [{"ref": "a"}, {"ref": "b"}]}, state) == 12.0
    assert v.eval_expr({"op": "gt", "args": [{"ref": "b"}, {"ref": "a"}]}, state) is True
    assert v.eval_expr({"op": "and", "args": [
        {"op": "gt", "args": [{"ref": "b"}, {"const": 0}]},
        {"op": "lt", "args": [{"ref": "a"}, {"const": 10}]},
    ]}, state) is True
    assert v.eval_expr({"op": "if", "args": [
        {"op": "gt", "args": [{"ref": "a"}, {"const": 5}]},
        {"const": "big"},
        {"const": "small"},
    ]}, state) == "small"


def test_eval_expr_rejects_non_whitelisted_op():
    v = GameplayValidator()
    state = {"a": 1}
    with pytest.raises(ExprEvalError):
        v.eval_expr({"op": "eval", "args": [{"const": "print('pwned')"}]}, state)
    with pytest.raises(ExprEvalError):
        v.eval_expr({"op": "random_in_range", "args": [{"const": 1}, {"const": 10}]}, state)


def test_eval_expr_clamp_and_aggregations():
    v = GameplayValidator()
    state = {"a": 15, "lst": [1, 2, 3, 4]}
    assert v.eval_expr({"op": "clamp", "args": [{"ref": "a"}, {"const": 0}, {"const": 10}]}, state) == 10
    assert v.eval_expr({"op": "sum", "args": [{"ref": "lst"}]}, state) == 10.0
    assert v.eval_expr({"op": "avg", "args": [{"ref": "lst"}]}, state) == 2.5


def test_eval_expr_depth_bounded():
    v = GameplayValidator()
    # Deeply nested AST should hit the depth cap, not recurse forever.
    node = {"const": 1}
    for _ in range(100):
        node = {"op": "add", "args": [node, {"const": 1}]}
    with pytest.raises(ExprEvalError):
        v.eval_expr(node, {})


# =====================================================================
# GameplaySpec serialization
# =====================================================================


def test_gameplay_spec_roundtrip():
    spec = _countdown_spec()
    d = spec.to_dict()
    assert d["name"] == "countdown"
    spec2 = GameplaySpec.from_dict(d)
    assert spec2.name == spec.name
    assert spec2.state_schema == spec.state_schema
    assert spec2.legal_actions == spec.legal_actions
    assert spec2.apply == spec.apply


def test_gameplay_spec_json_safe():
    import json
    d = _countdown_spec().to_json_safe()
    json.dumps(d)  # must not raise


# =====================================================================
# Cross-check: fallback spec from generator passes validator
# =====================================================================


def test_fallback_spec_passes_validation():
    from theater.gameplay_generator import _kernel_spec_for
    v = GameplayValidator()
    for kernel in ("deck", "dice_pool", "betting"):
        spec = _kernel_spec_for(kernel)
        report = v.validate_all(spec)
        assert report.passed, (kernel, report.reasons)
