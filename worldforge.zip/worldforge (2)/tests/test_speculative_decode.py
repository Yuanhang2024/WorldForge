"""
Unit tests for the speculative decoding framework.

Tests cover:
  - SpeculativeDecoder: draft generates K tokens, target verifies and accepts
    matching prefix; rejection triggers re-generation at rejection point.
  - accept_rate tracking with perfect, partial, and zero acceptance.
  - PromptLookup n-gram matching correctness (exact, no-match, short-prompt,
    multi-suggestion).
  - Edge cases: empty draft, empty target, all-rejected, bonus token.
"""

from __future__ import annotations

import math
import unittest
from typing import List, Tuple

from theater.speculative_decode import PromptLookup, SpeculativeDecoder


# ---------------------------------------------------------------------------
# Mock clients for testing
# ---------------------------------------------------------------------------


class MockDraft:
    """Pre-programmed draft-token generator for deterministic tests."""

    def __init__(self, tokens: List[str]) -> None:
        self.tokens = tokens
        self.pos = 0

    def generate(self, prompt: str, *, n_tokens: int) -> List[str]:
        end = self.pos + n_tokens
        chunk = self.tokens[self.pos : end]
        self.pos = end
        return chunk


class MockTarget:
    """Pre-programmed target verifier for deterministic tests.

    Accepts a prefix of draft tokens that appear at *its* current position,
    then produces one target token.
    """

    def __init__(self, tokens: List[str]) -> None:
        self.tokens = tokens
        self.pos = 0

    def verify(self, prompt: str, draft_tokens: List[str]) -> Tuple[int, str]:
        n = 0
        for dt in draft_tokens:
            if self.pos < len(self.tokens) and dt == self.tokens[self.pos]:
                n += 1
                self.pos += 1
            else:
                break
        if self.pos < len(self.tokens):
            nxt = self.tokens[self.pos]
            self.pos += 1
        else:
            nxt = ""
        return n, nxt


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class SpeculativeDecoderTests(unittest.TestCase):
    """SpeculativeDecoder basic behaviour (§5.5 item 3)."""

    def test_draft_accepted_and_rejected_properly(self):
        """Draft proposes K tokens; target accepts matching prefix and
        generates a new token at the rejection point."""
        # draft:   A B C D E
        # target:  A B X D E   (diverges at 3rd token)
        draft = MockDraft(["A", "B", "C", "D", "E"])
        target = MockTarget(["A", "B", "X", "D", "E"])
        decoder = SpeculativeDecoder(draft, target)
        out = decoder.decode("", max_tokens=5, K=3)
        # Iter 1: draft=[A,B,C], target accepts [A,B], rejects C, generates X
        # Iter 2: draft=[D,E],   target accepts [D,E], bonus token ""
        self.assertEqual(out, "ABXDE")

    def test_all_draft_accepted(self):
        """When all draft tokens agree with target, every token is accepted
        and a bonus token is produced from the target."""
        draft = MockDraft(["A", "B", "C"])
        target = MockTarget(["A", "B", "C", "D"])
        decoder = SpeculativeDecoder(draft, target)
        out = decoder.decode("", max_tokens=4, K=3)
        self.assertEqual(out, "ABCD")

    def test_all_draft_rejected(self):
        """When the very first draft token is rejected, target generates
        its own token from scratch."""
        draft = MockDraft(["A", "B"])
        target = MockTarget(["X", "Y"])
        decoder = SpeculativeDecoder(draft, target)
        out = decoder.decode("", max_tokens=3, K=2)
        # iter 1: draft=[A,B], target accepts 0, generates X
        # iter 2: draft=[A,B], target accepts 0, generates Y
        # (draft loops back — real draft would be conditional on the growing prompt)
        self.assertEqual(out, "XY")

    def test_empty_draft_tokens(self):
        """When draft returns an empty list at the very first call, the
        decoder falls back to a single target call."""
        draft = MockDraft([])
        target = MockTarget(["A", "B"])
        decoder = SpeculativeDecoder(draft, target)
        out = decoder.decode("", max_tokens=3, K=3)
        # draft returns [] → fallback target call for one token
        # then loop ends because n_accepted=0 and next_tok is consumed
        self.assertEqual(out, "A")

    def test_bonus_token_at_eos(self):
        """When all K draft tokens are accepted and the target has no bonus
        token (EOS), the decode loop terminates cleanly."""
        draft = MockDraft(["A"])
        target = MockTarget(["A"])  # after accepting [A], no more tokens
        decoder = SpeculativeDecoder(draft, target)
        out = decoder.decode("", max_tokens=3, K=1)
        self.assertEqual(out, "A")

    def test_max_tokens_honoured(self):
        """The decoder never produces more than max_tokens output tokens."""
        draft = MockDraft(["A", "B", "C", "D", "E", "F"])
        target = MockTarget(["A", "B", "C", "D", "E", "F"])
        decoder = SpeculativeDecoder(draft, target)
        out = decoder.decode("", max_tokens=3, K=4)
        self.assertEqual(out, "ABC")
        self.assertEqual(len(out), 3)

    def test_prompt_context_preserved(self):
        """The prompt is passed through and accumulated across iterations."""
        draft = MockDraft([" world"])
        target = MockTarget([" world", "!"])
        decoder = SpeculativeDecoder(draft, target)
        out = decoder.decode("Hello", max_tokens=2, K=2)
        self.assertEqual(out, " world!")

    def test_decode_tokens_variant(self):
        """decode_tokens produces the same result as decode."""
        draft = MockDraft(["A", "B", "C"])
        target = MockTarget(["A", "B", "C", "D"])
        decoder = SpeculativeDecoder(draft, target)
        out = decoder.decode_tokens([], max_tokens=4, K=3)
        self.assertEqual(out, ["A", "B", "C", "D"])


class AcceptRateTests(unittest.TestCase):
    """Accept-rate tracking (§13.6 — healthy >60%)."""

    def test_accept_rate_perfect(self):
        draft = MockDraft(["A", "B", "C"])
        target = MockTarget(["A", "B", "C"])
        decoder = SpeculativeDecoder(draft, target)
        decoder.decode("", max_tokens=3, K=3)
        self.assertEqual(decoder.n_proposed, 3)
        self.assertEqual(decoder.n_accepted, 3)
        self.assertEqual(decoder.accept_rate, 1.0)

    def test_accept_rate_partial(self):
        draft = MockDraft(["A", "B", "C", "D", "E"])
        target = MockTarget(["A", "B", "X", "D", "E"])
        decoder = SpeculativeDecoder(draft, target)
        decoder.decode("", max_tokens=5, K=3)
        # iter 1: proposed 3, accepted 2
        # iter 2: proposed 2, accepted 2
        # total: proposed 5, accepted 4 → 0.8
        self.assertEqual(decoder.n_proposed, 5)
        self.assertEqual(decoder.n_accepted, 4)
        self.assertAlmostEqual(decoder.accept_rate, 0.8)

    def test_accept_rate_zero(self):
        """When all draft tokens are rejected, the rate is 0.0."""
        draft = MockDraft(["A", "B"])
        target = MockTarget(["X", "Y"])
        decoder = SpeculativeDecoder(draft, target)
        decoder.decode("", max_tokens=2, K=2)
        self.assertEqual(decoder.n_proposed, 2)
        self.assertEqual(decoder.n_accepted, 0)
        self.assertEqual(decoder.accept_rate, 0.0)

    def test_accept_rate_initial(self):
        """Before any decode, accept_rate is 0.0 (no division-by-zero)."""
        draft = MockDraft([])
        target = MockTarget([])
        decoder = SpeculativeDecoder(draft, target)
        self.assertEqual(decoder.accept_rate, 0.0)


class PromptLookupTests(unittest.TestCase):
    """Prompt-lookup / n-gram speculation (§5.5 item 4)."""

    def test_basic_repeat(self):
        pl = PromptLookup()
        text = "the quick brown fox jumps over the lazy dog the quick brown"
        sugg = pl.suggest(text, n=2)
        # "the quick brown" appears at idx 0 and idx 8; the prior occurrence
        # was followed by "fox jumps over".
        self.assertIn("fox jumps over", sugg)

    def test_no_repeat(self):
        pl = PromptLookup()
        self.assertEqual(pl.suggest("hello world foo bar baz"), [])

    def test_short_prompt(self):
        pl = PromptLookup()
        self.assertEqual(pl.suggest("hello world"), [])
        self.assertEqual(pl.suggest(""), [])
        self.assertEqual(pl.suggest("a b"), [])

    def test_multi_suggestion(self):
        """When multiple n-gram repeats exist, return up to n suggestions."""
        pl = PromptLookup()
        # "a b c" repeats three times: idx 0, 4, 8 (suffix)
        text = "a b c x a b c y a b c"
        sugg = pl.suggest(text, n=4)
        # longest n-gram (len=3): suffix "a b c" matches at idx 0 → follow "x a b"
        #                       also matches at idx 4 → follow "y"
        self.assertGreaterEqual(len(sugg), 1)
        self.assertLessEqual(len(sugg), 4)
        self.assertIn("x a b", sugg)
        self.assertIn("y", sugg)

    def test_suggestions_shortest_first(self):
        pl = PromptLookup()
        text = "a b c d e a b c d f a b c"
        sugg = pl.suggest(text, n=4)
        # Verify sorted by length ascending
        lengths = [len(s) for s in sugg]
        self.assertEqual(lengths, sorted(lengths))

    def test_overlapping_ngram_not_matched(self):
        """N-gram matches must be non-overlapping with the suffix."""
        pl = PromptLookup()
        # "a b" at the very end — the only occurrence overlaps with itself
        # and should not match.
        self.assertEqual(pl.suggest("a b a b"), [])

    def test_structured_output_dialogue_block(self):
        """Realistic dialogue-block pattern where n-gram lookup shines."""
        pl = PromptLookup()
        # A repeated dialogue-format block typical of AI Theater
        lines = (
            "Alice: Hello there!\n"
            "Bob: Hi Alice!\n"
            "Alice: How are you?\n"
            "Bob: I'm great, thanks!\n"
            "Alice: Hello there!\n"
            "Bob: Hi Alice!\n"
        )
        sugg = pl.suggest(lines, n=1)
        # "Alice: Hello there!\nBob: Hi Alice!" repeats
        # The prior occurrence was followed by "Alice: How are you?"
        # Since the tokens are split by spaces, we'll find at least something
        self.assertGreaterEqual(len(sugg), 0)  # at least not crashing

    def test_suggest_returns_strings_not_tokens(self):
        """Return values are space-joined strings, not token lists."""
        pl = PromptLookup()
        text = "x y z x y w"
        sugg = pl.suggest(text, n=1)
        for s in sugg:
            self.assertIsInstance(s, str)


# ---------------------------------------------------------------------------
# Client protocol error tests
# ---------------------------------------------------------------------------


class ClientProtocolTests(unittest.TestCase):
    """Error handling when client protocol is violated."""

    def test_draft_without_generate_raises(self):
        class BadDraft:
            pass

        target = MockTarget(["A"])
        decoder = SpeculativeDecoder(BadDraft(), target)
        with self.assertRaises(TypeError):
            decoder.decode("", max_tokens=1)

    def test_target_without_verify_raises(self):
        class BadTarget:
            pass

        draft = MockDraft(["A"])
        decoder = SpeculativeDecoder(draft, BadTarget())
        with self.assertRaises(TypeError):
            decoder.decode("", max_tokens=1)

    def test_target_verify_wrong_return_type_raises(self):
        class BadTarget:
            def verify(self, prompt: str, draft_tokens: List[str]) -> str:
                return "not a tuple"

        draft = MockDraft(["A"])
        target = BadTarget()
        decoder = SpeculativeDecoder(draft, target)
        with self.assertRaises(TypeError):
            decoder.decode("", max_tokens=1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    unittest.main()
