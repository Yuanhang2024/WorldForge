"""P0 — 张力2: onboarding LLM rules must reach the runtime (立法→颁布).

Before this fix, onboarding stage 3 compiled the LLM-authored WorldKernelSpec
into a CompiledKernel, extracted its ``spec_hash``, then threw the kernel
away — so the LLM's "legislation" was never "promulgated": subsequent
``world_tick`` calls never executed the rules. These tests pin the fix:

  * onboarding registers the compiled spec on the orchestrator (``registered``)
  * a subsequent ``world_tick`` actually runs the DSL rules
  * the kernel's emitted changes land in the worldbook as a kernel-origin fact
  * three-body worlds are NOT affected (they use three_body_tick, §8.2)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict

import pytest

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.onboarding import OnboardingFlow  # noqa: E402
from theater.settings import Settings  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402


# A spec whose ``turn.tick`` rule increments ``supply`` by ``production_rate``
# each beat — so a tick visibly mutates state.
_RULE_JSON = json.dumps({
    "world_type": "economy",
    "rules": [
        {
            "rule_id": "production_each_turn",
            "kind": "dynamic",
            "trigger": "turn.tick",
            "effect": {"writes": "supply", "op": "add",
                       "value": {"op": "add", "args": [
                           {"ref": "supply"}, {"ref": "production_rate"}]}},
            "description": "每回合按产能增加供给",
            "priority": 30,
        },
    ],
    "params": {"seed": 42},
    "initial_state": {"supply": 100, "production_rate": 8.0},
})

_GAMEPLAY_JSON = json.dumps({
    "name": "countdown", "description": "bounded test gameplay",
    "state_schema": {"count": 10, "turn": 0},
    "legal_actions": [{"id": "dec", "condition": {"op": "gt", "args": [{"ref": "count"}, {"const": 0}]}}],
    "terminal": {"op": "or", "args": [
        {"op": "le", "args": [{"ref": "count"}, {"const": 0}]},
        {"op": "ge", "args": [{"ref": "turn"}, {"const": 50}]},
    ]},
    "payoff": {"op": "ref", "path": "turn"},
    "apply": {"dec": {"writes": [
        {"path": "count", "value": {"op": "sub", "args": [{"ref": "count"}, {"const": 1}]}},
        {"path": "turn", "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
    ]}},
})


class _FakeLLMClient:
    def __init__(self, rule_text: str = _RULE_JSON):
        self._rule_text = rule_text

    def as_text_fn(self, temperature=0.2, max_tokens=2048):
        def _fn(prompt: str) -> str:
            return _GAMEPLAY_JSON if "gameplay rule compiler" in prompt else self._rule_text
        return _fn

    def as_dict_fn(self, temperature=0.4, max_tokens=2048):
        def _fn(world_style: str) -> Dict[str, Any]:
            if "世界设计架构师" in world_style:
                return {
                    "world_type": "test_economy", "seed": 42, "lambda": 0.5,
                    "initial_state": {"supply": 100, "production_rate": 8.0},
                }
            return {
                "gui_spec_id": "llm_test", "world_id": "test_world",
                "layout_type": "dashboard",
                "grid": {"columns": "1fr", "areas": ["main"]},
                "widgets": [{"id": "readout", "type": "text", "area": "main",
                             "binds": {"read": "kernel:tick"}}],
            }
        return _fn


def _build_orchestrator(root: Path) -> TheaterOrchestrator:
    settings = Settings(data_dir=root, enable_live_api=False)
    return TheaterOrchestrator(
        state_store=JsonStateStore(root / "state"),
        model_client=DeterministicModelClient(),
        settings=settings,
    )


@pytest.fixture
def tmp_root(tmp_path):
    return tmp_path


# ---------------------------------------------------------------------------
# registration: onboarding installs the compiled kernel
# ---------------------------------------------------------------------------


def test_onboarding_registers_compiled_kernel(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run("一个供需经济世界", characters=[], use_llm=True)
    rules = result["stages"]["rules"]
    assert rules["compiled"] is True
    assert rules["registered"] is True
    # The orchestrator now holds the spec for this world.
    wid = result["world_id"]
    assert wid in flow.orchestrator._world_kernel_hosts


def test_onboarding_without_llm_is_explicitly_blocked(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("一个经济世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"
    assert result["stages"] == {}
    assert not flow.orchestrator._world_kernel_hosts


def test_register_world_kernel_rejects_invalid_spec(tmp_root):
    """A spec that fails static validation must be rejected at registration."""
    from theater.world_kernel_host import WorldKernelSpec, WorldRule
    orch = _build_orchestrator(tmp_root)
    bad = WorldKernelSpec(
        world_type="economy",
        rules=[WorldRule(rule_id="", kind="dynamic", trigger="turn.tick")],  # empty rule_id
    )
    with pytest.raises(ValueError):
        orch.register_world_kernel("main", bad)


def test_registered_kernel_has_no_host_until_first_tick(tmp_root):
    """Registration is lazy — host built on first step, not at register time."""
    from theater.world_kernel_host import WorldKernelSpec, WorldRule
    orch = _build_orchestrator(tmp_root)
    spec = WorldKernelSpec(
        world_type="economy",
        rules=[WorldRule(rule_id="r1", kind="dynamic", trigger="turn.tick",
                         effect={"writes": "x", "value": {"const": 1}})],
        initial_state={"x": 0},
    )
    orch.register_world_kernel("main", spec)
    # No host built yet.
    assert orch.get_world_kernel_state("main") == {}
    # Step builds it.
    orch.set_world("main")
    orch._step_world_kernel("main")
    assert orch.get_world_kernel_state("main")["x"] == 1


# ---------------------------------------------------------------------------
# tick: the compiled kernel actually runs
# ---------------------------------------------------------------------------


def test_world_tick_runs_llm_rules_and_persists_event(tmp_root):
    """End-to-end: onboarding → world_tick → kernel event in worldbook."""
    orch = _build_orchestrator(tmp_root)
    flow = OnboardingFlow(
        orchestrator=orch,
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run("一个供需经济世界", characters=[], use_llm=True)
    wid = result["world_id"]
    orch.set_world(wid)

    # Host is built lazily on first step — no state until then.
    assert orch.get_world_kernel_state(wid) == {}

    beat = orch.world_tick(session_id="test")
    # The kernel ran: supply advanced by production_rate (100 + 8 = 108).
    state_after = orch.get_world_kernel_state(wid)
    assert state_after["supply"] == 108.0

    # The kernel event landed as a worldbook entry with origin=kernel.
    entries = orch.state_store.snapshot().worldbook
    kernel_entries = [e for e in entries if e.source == "world_kernel_tick"]
    assert kernel_entries, "kernel event not persisted to worldbook"
    assert "supply" in kernel_entries[-1].content


def test_world_tick_without_kernel_is_noop(tmp_root):
    """A world with no registered kernel still ticks via dispatch (no crash)."""
    orch = _build_orchestrator(tmp_root)
    orch.set_world("main")
    # No kernel registered → _step_world_kernel returns [].
    assert orch._step_world_kernel("main") == []
    # world_tick still runs (dispatch path); we only assert no crash + no
    # kernel event entry.
    orch.world_tick(session_id="test")
    entries = orch.state_store.snapshot().worldbook
    assert not [e for e in entries if e.source == "world_kernel_tick"]


def test_three_body_tick_does_not_run_dsl_kernel(tmp_root):
    """three_body_tick uses physics (§8.2); DSL rules must NOT fire there.

    Guards the coexistence decision: a three-body world with a registered DSL
    kernel still runs purely through three_body_tick, which never calls
    _step_world_kernel.
    """
    from theater.kernels.three_body import ThreeBodyKernel
    from theater.world_kernel_host import WorldKernelSpec, WorldRule

    class StubKernel:
        def __init__(self):
            self.calls = []

        def civilization_step(self, tech_level, t, Delta=0.1):
            self.calls.append((tech_level, t))
            return ThreeBodyKernel.CivilizationEvent(
                kind="survived", tech_level=tech_level, delta_0=0.01,
                T_predict=999.0, t=t, next_chaos=None, note="stub")

        def evacuation_check(self, max_tech, Delta=0.1):
            return False

    orch = _build_orchestrator(tmp_root)
    orch._three_body_kernel = StubKernel()
    orch._narrate_three_body = lambda el, h: {
        "title": "t", "narrative": "n", "dialogue": "d", "warnings": []}

    # Register a DSL kernel on the three-body world — it must be ignored.
    spec = WorldKernelSpec(
        world_type="economy",
        rules=[WorldRule(rule_id="r1", kind="dynamic", trigger="turn.tick",
                         effect={"writes": "x", "value": {"const": 999}})],
        initial_state={"x": 0},
    )
    orch.register_world_kernel("three_body", spec)
    orch.three_body_tick(world_id="three_body")

    # DSL state untouched — three_body_tick never stepped it.
    assert orch.get_world_kernel_state("three_body") == {}


def test_kernel_state_isolated_per_world(tmp_root):
    """Two worlds each registered with a kernel keep independent state."""
    from theater.world_kernel_host import WorldKernelSpec, WorldRule
    orch = _build_orchestrator(tmp_root)

    def _spec(val):
        return WorldKernelSpec(
            world_type="economy",
            rules=[WorldRule(rule_id="r1", kind="dynamic", trigger="turn.tick",
                             effect={"writes": "x", "value": {"const": val}})],
            initial_state={"x": 0},
        )
    orch.register_world_kernel("world_a", _spec(1))
    orch.register_world_kernel("world_b", _spec(100))
    orch.set_world("world_a")
    orch._step_world_kernel("world_a")
    orch.set_world("world_b")
    orch._step_world_kernel("world_b")
    assert orch.get_world_kernel_state("world_a")["x"] == 1
    assert orch.get_world_kernel_state("world_b")["x"] == 100
