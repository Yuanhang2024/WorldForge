"""Tests for WorldClock ↔ IdleLoop integration (spec §13.4, 调研① 方案 A).

The WorldClock now wraps an IdleLoop and drives ``idle_loop.tick()`` instead of
calling ``orchestrator.world_tick()`` directly. The silence timer is the
orchestrator's own ``_last_activity`` (shared), and the saturation cap lives on
the IdleLoop. Possession guard: autonomous advancement must not manipulate a
possessed character.
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.idle_loop import IdleLoop  # noqa: E402
from theater.models import CharacterPatch  # noqa: E402
from theater.runtime import WorldClock  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402


def _orch(tmp: Path) -> TheaterOrchestrator:
    return TheaterOrchestrator(
        state_store=JsonStateStore(tmp / "state"),
        model_client=DeterministicModelClient(),
    )


@pytest.fixture
def tmp_root(tmp_path):
    return tmp_path


# -- WorldClock ↔ IdleLoop merge -------------------------------------------


def test_world_clock_holds_idle_loop_and_attaches(tmp_root):
    orch = _orch(tmp_root)
    clock = WorldClock(orch, interval=10, max_advances=3)
    assert isinstance(clock.idle_loop, IdleLoop)
    assert clock.idle_loop.max_advances == 3
    assert clock.idle_loop.idle_threshold == 10.0
    # The loop is registered on the orchestrator so dispatch() can reset it.
    assert orch._idle_loop is clock.idle_loop


def test_world_clock_start_requires_positive_interval(tmp_root):
    orch = _orch(tmp_root)
    clock = WorldClock(orch, interval=0)
    assert clock.start() is False  # disabled — safety grey grade (spec §13.4)


def test_world_clock_idle_loop_respects_orchestrator_timer(tmp_root):
    """The loop's seconds_idle() delegates to orchestrator.seconds_since_activity
    — one shared idle timer (调研① 方案 A)."""
    orch = _orch(tmp_root)
    clock = WorldClock(orch, interval=5)
    # Right after construction the player is "active": no advance.
    assert clock.idle_loop.tick() is None
    assert clock.idle_loop.advances_count == 0


def test_dispatch_resets_idle_loop_saturation_cap(tmp_root):
    """Player dispatch resets the IdleLoop's saturation counter."""
    orch = _orch(tmp_root)
    clock = WorldClock(orch, interval=5)
    # Simulate saturation manually.
    clock.idle_loop._advances = clock.idle_loop.max_advances
    assert clock.idle_loop.tick() is None  # saturated
    # A player dispatch resets the cap.
    orch.dispatch(message="继续探索档案馆", session_id="s1")
    assert clock.idle_loop.advances_count == 0


def test_world_tick_tags_advancement_origin_idle_advance(tmp_root):
    """world_tick → dispatch tags the beat's model_trace with
    advancement_origin=idle_advance (spec §13.4 算正典, origin-tagged)."""
    orch = _orch(tmp_root)
    result = orch.world_tick(session_id="idle_test")
    assert result is not None
    assert result.model_trace.get("advancement_origin") == "idle_advance"


def test_player_dispatch_has_no_advancement_origin(tmp_root):
    orch = _orch(tmp_root)
    result = orch.dispatch(message="生成雷雨档案馆", session_id="s1")
    assert result is not None
    assert result.model_trace.get("advancement_origin") is None


# -- Possession guard (调研① bug fix) ----------------------------------------


def _possess_aster(orch: TheaterOrchestrator):
    orch.upsert_character(
        CharacterPatch(character_id="aster", name="Aster",
                       summary="primary actor", source="test",
                       possession_limit={"max_duration": 3600,
                                         "allowed_actions": ["move", "speak"]}),
        approved_by="science_director")
    orch.possession_manager.enter_possession("aster", "player_01", reason="test")


def test_autonomous_tick_does_not_clobber_possessed_character(tmp_root):
    """Regression: before the fix, world_tick → dispatch wrote a CharacterPatch
    for "aster" with possessed=False, clobbering an active possession. Now the
    possessed actor is left untouched and the AI's intent is queued."""
    orch = _orch(tmp_root)
    _possess_aster(orch)
    assert orch.state_store.snapshot().characters[0].possessed is True

    result = orch.world_tick(session_id="idle_possess")

    # The beat still produces a worldbook entry (continuity preserved)...
    assert result is not None
    entries = orch.state_store.snapshot().worldbook
    assert len(entries) >= 1
    # ...but the possessed actor stays possessed (not clobbered).
    aster = next(c for c in orch.state_store.snapshot().characters
                 if c.character_id == "aster")
    assert aster.possessed is True
    assert aster.possessed_by == "player_01"


def test_autonomous_tick_queues_pending_ai_action_when_possessed(tmp_root):
    """When the actor is possessed, the AI's beat is queued as a
    pending_ai_action instead of being written onto the character."""
    orch = _orch(tmp_root)
    _possess_aster(orch)
    before = len(orch.state_store.snapshot().characters[0].pending_ai_actions)
    orch.world_tick(session_id="idle_possess")
    after = len(orch.state_store.snapshot().characters[0].pending_ai_actions)
    assert after >= before  # at least one pending action was queued


def test_player_dispatch_still_clobbers_when_not_possessed(tmp_root):
    """Sanity: the guard only fires when the actor is actually possessed."""
    orch = _orch(tmp_root)
    # Create a non-possessed aster.
    orch.upsert_character(
        CharacterPatch(character_id="aster", name="Aster",
                       summary="free actor", source="test"),
        approved_by="science_director")
    orch.world_tick(session_id="idle_free")
    aster = next(c for c in orch.state_store.snapshot().characters
                 if c.character_id == "aster")
    assert aster.possessed is False  # normal autonomous write path
