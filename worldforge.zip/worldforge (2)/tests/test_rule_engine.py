"""Tests for the deterministic rule engine (rule_engine.py).

Covers all five validation checks plus LLM-adjudication heuristics.
Run with::

    PYTHONPATH=backend python -m pytest tests/test_rule_engine.py -q
"""

from __future__ import annotations

import pytest

from backend.theater.dag import PrerequisiteDAG
from backend.theater.rule_engine import (
    ConservationChecker,
    RuleEngine,
    RuleResult,
)
from backend.theater.transactions import StateChange


# ======================================================================
# Fixtures
# ======================================================================


@pytest.fixture
def empty_state() -> dict:
    return {}


@pytest.fixture
def sample_state() -> dict:
    return {
        "characters": [
            {"character_id": "alice", "name": "Alice", "health": 100},
            {"character_id": "bob", "name": "Bob", "health": 80},
        ],
        "objects": [
            {"object_id": "sword", "name": "Magic Sword", "state": "intact"},
            {"object_id": "door", "name": "Iron Door", "state": "closed"},
        ],
        "worldbook": [
            {"title": "Lore of the Ancients", "content": "..."},
        ],
        "technology": {
            "combat": 3,
            "industry": 5,
        },
        "resources": {
            "gold": 100,
            "wood": 50,
        },
        "economy": {
            "total_wealth": 150,
        },
        "inventory": {
            "potions": 5,
            "arrows": 20,
        },
    }


@pytest.fixture
def valid_change() -> StateChange:
    return StateChange.new(
        origin="kernel",
        changes=[
            {"path": "resources.gold", "op": "set", "value": 80},
            {"path": "resources.wood", "op": "set", "value": 70},
        ],
        prerequisites_checked=["observe"],
    )


@pytest.fixture
def dag() -> PrerequisiteDAG:
    d = PrerequisiteDAG()
    d.add_node("observe")
    d.add_node("curve_fit")
    d.add_node("escape")
    d.add_edge("observe", "curve_fit")
    d.add_edge("curve_fit", "escape")
    d.unlock("observe")
    return d


@pytest.fixture
def engine(dag: PrerequisiteDAG) -> RuleEngine:
    return RuleEngine(dag=dag)


# ======================================================================
# RuleResult helpers
# ======================================================================


class TestRuleResult:
    def test_ok(self) -> None:
        r = RuleResult.ok()
        assert r.approved is True
        assert r.needs_llm is False
        assert r.llm_question is None

    def test_ok_with_llm(self) -> None:
        r = RuleResult.ok(needs_llm=True, llm_question="Is this valid?")
        assert r.approved is True
        assert r.needs_llm is True
        assert r.llm_question == "Is this valid?"

    def test_deny(self) -> None:
        r = RuleResult.deny("nope")
        assert r.approved is False
        assert "nope" in r.reasons

    def test_deny_multiple(self) -> None:
        r = RuleResult.deny("first", "second", "third")
        assert r.reasons == ["first", "second", "third"]


# ======================================================================
# Schema validity
# ======================================================================


class TestCheckSchema:
    def test_empty_changes_denied(self, engine: RuleEngine, sample_state: dict) -> None:
        change = StateChange.new(
            origin="kernel", changes=[], prerequisites_checked=["observe"]
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "no entries" in result.reasons[0]

    def test_non_dict_change_denied(self, engine: RuleEngine, sample_state: dict) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=["not_a_dict"],  # type: ignore[list-item]
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False

    def test_missing_path_denied(self, engine: RuleEngine, sample_state: dict) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"op": "set", "value": 42}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "path" in result.reasons[0]

    def test_invalid_op_denied(self, engine: RuleEngine, sample_state: dict) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "x", "op": "fly", "value": 42}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False

    def test_set_without_value_denied(self, engine: RuleEngine, sample_state: dict) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "x", "op": "set"}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False

    def test_llm_origin_needs_ref(self, engine: RuleEngine, sample_state: dict) -> None:
        change = StateChange.new(
            origin="llm_adjudication",
            changes=[{"path": "x", "op": "set", "value": 1}],
            prerequisites_checked=["observe"],
            adjudication_ref=None,
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "adjudication_ref" in result.reasons[0]

    def test_valid_schema_passes(self, engine: RuleEngine, sample_state: dict) -> None:
        # use a non-resource path to avoid conservation check interference
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "technology.combat", "op": "set", "value": 5}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True


# ======================================================================
# Numerical ranges
# ======================================================================


class TestCheckRanges:
    def test_technology_below_min_denied(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "technology.combat", "op": "set", "value": -1}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "below minimum" in result.reasons[0]

    def test_technology_above_max_denied(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "technology.combat", "op": "set", "value": 11}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "above maximum" in result.reasons[0]

    def test_technology_valid(self, engine: RuleEngine, sample_state: dict) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "technology.combat", "op": "set", "value": 7}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True

    def test_character_level_below_min(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "character_stats.level", "op": "set", "value": 0}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False

    def test_character_level_valid(self, engine: RuleEngine, sample_state: dict) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "character_stats.level", "op": "set", "value": 50}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True


# ======================================================================
# Reference integrity
# ======================================================================


class TestCheckReferences:
    def test_unknown_character_denied(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {
                    "path": "character_stats.alice.relationship",
                    "op": "set",
                    "value": {"character_id": "nonexistent"},
                }
            ],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "unknown character" in result.reasons[0]

    def test_unknown_object_denied(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {
                    "path": "scene.props",
                    "op": "set",
                    "value": {"object_id": "ghost_sword"},
                }
            ],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "unknown object" in result.reasons[0]

    def test_unknown_worldbook_denied(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {
                    "path": "scene.lore",
                    "op": "set",
                    "value": {"worldbook_title": "Fake Title"},
                }
            ],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "unknown worldbook" in result.reasons[0]

    def test_known_references_pass(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {
                    "path": "character_stats.alice.relationship",
                    "op": "set",
                    "value": {"ref_character": "bob"},
                }
            ],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True

    def test_non_dict_value_skips_ref_check(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "x", "op": "set", "value": 42}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True


# ======================================================================
# DAG reachability
# ======================================================================


class TestCheckDAG:
    def test_unknown_prereq_node_denied(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "x", "op": "set", "value": 1}],
            prerequisites_checked=["nonexistent_node"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "does not exist in DAG" in result.reasons[0]

    def test_unreachable_prereq_denied(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "x", "op": "set", "value": 1}],
            prerequisites_checked=["escape"],  # observe is unlocked, but escape needs curve_fit
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "not reachable" in result.reasons[0]

    def test_reachable_prereq_passes(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "x", "op": "set", "value": 1}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True

    def test_no_dag_skips_check(self, sample_state: dict) -> None:
        engine = RuleEngine(dag=None)
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "x", "op": "set", "value": 1}],
            prerequisites_checked=["whatever"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True


# ======================================================================
# Conservation laws
# ======================================================================


class TestCheckConservation:
    def test_resource_total_violated(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        # gold 100 -> 200 without a produce/consume node
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "resources.gold", "op": "set", "value": 200}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "conservation" in " ".join(result.reasons).lower()

    def test_resource_with_produce_node_passes(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {"path": "resources.gold", "op": "set", "value": 200},
                {"path": "resources.produce.gold_mine", "op": "set", "value": 100},
            ],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True

    def test_economy_conservation_violated(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "economy.total_wealth", "op": "set", "value": 999}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False
        assert "conservation" in " ".join(result.reasons).lower()

    def test_economy_with_transfer_passes(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {"path": "economy.total_wealth", "op": "set", "value": 100},
                {"path": "economy.transfer.tax", "op": "set", "value": 50},
            ],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True

    def test_inventory_negative_denied(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "inventory.potions", "op": "set", "value": -3}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False

    def test_inventory_delete_denied(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "inventory.potions", "op": "delete"}],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is False

    def test_valid_resource_change_passes(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        # gold 100->80, wood 50->70: total 150->150, conserved
        change = StateChange.new(
            origin="kernel",
            changes=[
                {"path": "resources.gold", "op": "set", "value": 80},
                {"path": "resources.wood", "op": "set", "value": 70},
            ],
            prerequisites_checked=["observe"],
        )
        result = engine.validate(change, sample_state)
        assert result.approved is True


# ======================================================================
# needs_llm_adjudication
# ======================================================================


class TestNeedsLLM:
    def test_simple_numeric_change_no_llm(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "technology.combat", "op": "set", "value": 5}],
            prerequisites_checked=["observe"],
        )
        assert engine.needs_llm_adjudication(change, sample_state) is False

    def test_temporal_path_triggers_llm(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "temporal.paradox_flag", "op": "set", "value": True}],
            prerequisites_checked=["observe"],
        )
        assert engine.needs_llm_adjudication(change, sample_state) is True

    def test_character_death_triggers_llm(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "characters.alice.status", "op": "set", "value": "dead"}],
            prerequisites_checked=["observe"],
        )
        assert engine.needs_llm_adjudication(change, sample_state) is True

    def test_continuity_path_triggers_llm(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {"path": "continuity.timeline_branch", "op": "set", "value": "alt"}
            ],
            prerequisites_checked=["observe"],
        )
        assert engine.needs_llm_adjudication(change, sample_state) is True

    def test_narrative_path_triggers_llm(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {"path": "narrative.arc", "op": "set", "value": "tragedy"}
            ],
            prerequisites_checked=["observe"],
        )
        assert engine.needs_llm_adjudication(change, sample_state) is True

    def test_killed_value_triggers_llm(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "characters.bob.status", "op": "set", "value": "killed"}],
            prerequisites_checked=["observe"],
        )
        assert engine.needs_llm_adjudication(change, sample_state) is True

    def test_cross_chapter_delete_triggers_llm(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "chapter.3", "op": "delete"}],
            prerequisites_checked=["observe"],
        )
        assert engine.needs_llm_adjudication(change, sample_state) is True

    def test_mixed_triggers_llm(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {"path": "technology.combat", "op": "set", "value": 3},
                {"path": "temporal.true", "op": "set", "value": True},
            ],
            prerequisites_checked=["observe"],
        )
        assert engine.needs_llm_adjudication(change, sample_state) is True


# ======================================================================
# ConservationChecker standalone
# ======================================================================


class TestConservationChecker:
    def test_empty_changes_pass(self) -> None:
        checker = ConservationChecker()
        assert checker.check([], {}) is True

    def test_register_custom_invariant(self) -> None:
        checker = ConservationChecker()

        def always_fail(changes, state):
            return False

        checker.register("always_fail", always_fail)
        assert "always_fail" in checker.invariant_names
        assert checker.check([], {}) is False
        assert "always_fail" in checker.failing([], {})

    def test_unregister_invariant(self) -> None:
        checker = ConservationChecker()
        checker.unregister("resource_total_conserved")
        assert "resource_total_conserved" not in checker.invariant_names

    def test_failing_returns_names(self) -> None:
        checker = ConservationChecker()
        changes = [{"path": "resources.gold", "op": "set", "value": 999}]
        state = {"resources": {"gold": 100}}
        failed = checker.failing(changes, state)
        assert len(failed) >= 1  # at least resource_total_conserved

    def test_to_dict_serialization(self) -> None:
        checker = ConservationChecker()
        d = checker.to_dict()
        assert d["kind"] == "conservation_checker"
        assert "resource_total_conserved" in d["invariants"]


# ======================================================================
# build_llm_question
# ======================================================================


class TestBuildLLMQuestion:
    def test_question_contains_paths(
        self, engine: RuleEngine, sample_state: dict
    ) -> None:
        change = StateChange.new(
            origin="kernel",
            changes=[
                {"path": "characters.alice.status", "op": "set", "value": "dead"}
            ],
            prerequisites_checked=["observe"],
        )
        q = engine.build_llm_question(change, sample_state)
        assert "characters.alice.status" in q
        assert "dead" not in q  # paths, not values
