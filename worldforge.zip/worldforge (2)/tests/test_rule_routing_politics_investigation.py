"""Rule routing refinement tests for politics + investigation presets (LLM-only).

After preset removal, all generation requires llm_fn.  These tests verify that
a mock LLM output can produce politics/investigation specs and that keyword
routing (now purely informative for the LLM prompt) still works.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_rule_routing_politics_investigation.py -q
"""

from __future__ import annotations

import json
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.rule_generator import RuleGenerator
from theater.world_kernel_host import (
    RuleCompiler,
    WorldKernelSpec,
    WorldRule,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_spec(world_type: str, rule_ids: list[str] | None = None) -> str:
    """Return a minimal valid spec JSON for the given world_type."""
    return json.dumps({
        "world_type": world_type,
        "rules": [
            {
                "rule_id": rid,
                "kind": "dynamic",
                "trigger": "turn.tick",
                "condition": None,
                "effect": {
                    "op": "writes",
                    "changes": [{"path": "x", "value": {"const": 1}}],
                },
                "description": "mock rule",
                "priority": 10,
            }
            for rid in (rule_ids or ["mock_rule"])
        ],
        "params": {},
        "initial_state": {"x": 0},
    })


def _mock_llm(raw: str):
    def _fn(prompt: str) -> str:
        return raw
    return _fn


# ---------------------------------------------------------------------------
# Politics preset routing (§9.3③ social-adjacent: power transfer)
# ---------------------------------------------------------------------------


class TestPoliticsRouting:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    @pytest.mark.parametrize("desc", [
        "封建王朝贵族派系",
        "朝廷权谋政治",
        "王国叛乱王座",
        "feudal dynasty faction politics",
        "noble court intrigue realm",
    ])
    def test_routes_to_politics_via_llm(self, desc):
        raw = _make_spec("politics", ["political_action_shifts_influence",
                                      "low_loyalty_raises_rebellion",
                                      "influence_non_negative"])
        spec = self.gen.generate(desc, llm_fn=_mock_llm(raw))
        assert spec.world_type == "politics", (
            f"{desc!r}: expected politics, got {spec.world_type}"
        )

    def test_politics_has_faction_influence_rules(self):
        raw = _make_spec("politics", [
            "political_action_shifts_influence",
            "low_loyalty_raises_rebellion",
            "influence_non_negative",
        ])
        spec = self.gen.generate("封建王朝派系", llm_fn=_mock_llm(raw))
        ids = {r.rule_id for r in spec.rules}
        assert "political_action_shifts_influence" in ids
        assert "low_loyalty_raises_rebellion" in ids
        assert "influence_non_negative" in ids

    def test_politics_not_economy(self):
        """政治奇幻不该再走 economy preset."""
        raw = _make_spec("politics")
        spec = self.gen.generate("封建王朝派系政治", llm_fn=_mock_llm(raw))
        assert spec.world_type != "economy"
        assert spec.world_type != "social"

    def test_politics_validates_and_compiles(self):
        raw = _make_spec("politics", ["r1", "r2"])
        spec = self.gen.generate("feudal faction politics", llm_fn=_mock_llm(raw))
        issues = RuleCompiler().validate_spec(spec)
        assert issues == [], f"validation issues: {issues}"
        kernel = RuleCompiler(seed=0).compile(spec)
        assert kernel.world_type == "politics"
        assert len(kernel.rule_ids()) == len(spec.rules)

    def test_politics_does_not_write_forbidden_paths(self):
        """§12.1 — politics rules must never touch sealed_solutions/permissions."""
        raw = _make_spec("politics", ["pr"])
        spec = self.gen.generate("封建政治", llm_fn=_mock_llm(raw))
        from theater.world_kernel_host import _extract_write_paths
        for rule in spec.rules:
            paths = _extract_write_paths(rule.effect or {})
            for p in paths:
                assert not p.startswith(("sealed_solutions.",
                                         "permissions.",
                                         "_meta.world_params.")), (
                    f"politics rule {rule.rule_id} writes forbidden path {p!r}"
                )


# ---------------------------------------------------------------------------
# Investigation preset routing (§9.3① — sealed solution is §17 Q5 TODO)
# ---------------------------------------------------------------------------


class TestInvestigationRouting:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    @pytest.mark.parametrize("desc", [
        "侦探推理破案",
        "解谜凶手调查",
        "线索嫌疑人案件",
        "detective murder mystery",
        "whodunit investigation clue",
    ])
    def test_routes_to_investigation_via_llm(self, desc):
        raw = _make_spec("investigation", [
            "clue_reveals_suspicion",
            "high_suspicion_enables_accusation",
            "suspicion_non_negative",
        ])
        spec = self.gen.generate(desc, llm_fn=_mock_llm(raw))
        assert spec.world_type == "investigation", (
            f"{desc!r}: expected investigation, got {spec.world_type}"
        )

    def test_investigation_has_clue_suspicion_rules(self):
        raw = _make_spec("investigation", [
            "clue_reveals_suspicion",
            "high_suspicion_enables_accusation",
            "suspicion_non_negative",
        ])
        spec = self.gen.generate("侦探推理破案", llm_fn=_mock_llm(raw))
        ids = {r.rule_id for r in spec.rules}
        assert "clue_reveals_suspicion" in ids
        assert "high_suspicion_enables_accusation" in ids
        assert "suspicion_non_negative" in ids

    def test_investigation_not_economy_or_social(self):
        raw = _make_spec("investigation")
        spec = self.gen.generate("侦探推理破案", llm_fn=_mock_llm(raw))
        assert spec.world_type != "economy"
        assert spec.world_type != "social"

    def test_investigation_validates_and_compiles(self):
        raw = _make_spec("investigation")
        spec = self.gen.generate("detective murder mystery", llm_fn=_mock_llm(raw))
        issues = RuleCompiler().validate_spec(spec)
        assert issues == [], f"validation issues: {issues}"
        kernel = RuleCompiler(seed=0).compile(spec)
        assert kernel.world_type == "investigation"
        assert len(kernel.rule_ids()) == len(spec.rules)

    def test_investigation_does_not_seal_solution(self):
        """§17 Q5: sealed-solution mechanism is a human decision."""
        raw = _make_spec("investigation", ["ir"])
        spec = self.gen.generate("侦探推理破案", llm_fn=_mock_llm(raw))
        from theater.world_kernel_host import _extract_write_paths
        for rule in spec.rules:
            paths = _extract_write_paths(rule.effect or {})
            for p in paths:
                assert not p.startswith("sealed_solutions."), (
                    f"investigation rule {rule.rule_id} writes {p!r} — "
                    "sealed-solution is §17 Q5, must not be implemented here"
                )


# ---------------------------------------------------------------------------
# No regression on existing presets (now via LLM)
# ---------------------------------------------------------------------------

class TestNoRoutingRegression:
    def setup_method(self) -> None:
        self.gen = RuleGenerator()

    @pytest.mark.parametrize("desc,expected", [
        ("经济贸易市场", "economy"),
        ("supply and demand", "economy"),
        ("社交关系信任", "social"),
        ("瘟疫疫情", "social"),
        ("赛博朋克城市管理", "simulation"),
        ("city management simulation", "simulation"),
        ("牌局扑克", "card_game"),
        ("物理重力抛物线", "physical"),
    ])
    def test_existing_routes_unchanged_via_llm(self, desc, expected):
        raw = json.dumps({
            "world_type": expected,
            "rules": [
                {
                    "rule_id": "mock_rule",
                    "kind": "dynamic",
                    "trigger": "turn.tick",
                    "condition": None,
                    "effect": {
                        "op": "writes",
                        "changes": [{"path": "x", "value": {"const": 1}}],
                    },
                    "description": "mock",
                    "priority": 10,
                },
            ],
            "params": {},
            "initial_state": {"x": 0},
        })
        spec = self.gen.generate(desc, llm_fn=_mock_llm(raw))
        assert spec.world_type == expected, (
            f"{desc!r}: expected {expected}, got {spec.world_type}"
        )
