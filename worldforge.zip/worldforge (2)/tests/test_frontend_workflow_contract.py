"""Static user-flow contracts for the browser entry points.

These checks intentionally avoid a browser dependency.  They pin the stable
selectors used by Playwright while the DOM behaviour remains covered by the
existing Node-based front-end tests.
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"


def _read(name: str) -> str:
    return (WEB / name).read_text(encoding="utf-8")


def test_entry_page_defaults_to_editable_prefill_flow():
    html = _read("index.html")
    script = _read("index.js")

    assert 'data-testid="start-editable-wizard"' in html
    assert 'data-testid="start-manual-wizard"' in html
    assert 'data-testid="entry-workflow"' in html
    assert 'role="status"' in html
    assert '"/onboarding.html?autoprefill="' in script
    assert "openEditableWizard" in script
    assert 'fetch("/api/onboarding"' not in script


def test_onboarding_exposes_five_accessible_edit_confirm_steps():
    html = _read("onboarding.html")
    script = _read("onboarding.js")

    for step in range(1, 6):
        assert f'data-testid="onboarding-step-{step}"' in html
    for test_id in (
        "prefill-world",
        "confirm-world",
        "prefill-characters",
        "confirm-characters",
        "prefill-rules-gui",
        "confirm-rules-gui",
        "prefill-gameplay",
        "confirm-gameplay",
        "finalize-world",
    ):
        assert f'data-testid="{test_id}"' in html

    assert 'aria-live="polite"' in html
    assert "state.completed" in script
    assert "markStepComplete(1)" in script
    assert "markStepComplete(2)" in script
    assert "markStepComplete(3)" in script
    assert "markStepComplete(4)" in script
    assert "markStepComplete(5)" in script


def test_every_creative_stage_requires_llm_and_blocks_without_a_draft():
    script = _read("onboarding.js")

    for endpoint in (
        "/api/onboarding/world/propose",
        "/api/onboarding/characters/propose",
        "/api/onboarding/rules_gui/propose",
        "/api/onboarding/gameplay/propose",
    ):
        assert endpoint in script

    for removed_fallback in (
        "fillGenericWorldDraft",
        "fillGenericCharacters",
        "fillGenericRules",
        "fillGenericGameplay",
    ):
        assert removed_fallback not in script

    assert "FROM_SCRATCH_PROMPTS" in script
    assert "blockDraftStep" in script
    assert "LLM_REQUIRED" in script
    assert 'rulesSource !== "llm"' in script
    assert 'guiSource !== "llm"' in script
    assert 'result.source !== "llm"' in script

    # Provider credentials are configured by the launcher, never generated
    # or submitted by creative-stage JavaScript.
    lowered = script.lower()
    assert "api_key" not in lowered
    assert "base_url" not in lowered
    assert "model_fast" not in lowered
    assert "model_deep" not in lowered


def test_world_gui_only_loads_persisted_gui_and_routes_creation_to_wizard():
    html = _read("world_gui.html")
    script = _read("world_gui.js")

    assert 'data-testid="gui-workflow"' in html
    assert 'data-testid="open-gui-wizard"' in html
    assert 'data-testid="gui-status"' in html
    assert "openGuiWizard" in script
    assert "confirmGeneratedGUI" not in script
    assert "pendingGuiPayload" not in script
    assert 'source !== "persisted"' in script
    assert 'proposedBy !== "llm"' in script
    assert "CONFIRMED_GUI_REQUIRED" in script
    assert "/api/world/gui?world_id=" in script
    assert "use_llm=1&description" not in script
    assert 'id="description"' in html
    assert 'id="description"\n      name="description"' in html
    assert 'name="description"\n      placeholder=' in html
    description_tag = re.search(r'<input\s+[^>]*id="description"[^>]*>', html)
    assert description_tag is not None
    assert "required" not in description_tag.group(0)
    assert 'openEditableGenerator(3)' in script
    assert 'openEditableGenerator(4)' in script
    assert "/onboarding.html?autoprefill=1&description=" in script


def test_local_html_script_references_exist():
    for page_name in ("index.html", "onboarding.html", "world_gui.html"):
        html = _read(page_name)
        test_ids = re.findall(r'data-testid="([^"]+)"', html)
        assert len(test_ids) == len(set(test_ids)), (
            f"{page_name} contains duplicate data-testid values"
        )
        for src in re.findall(r'<script[^>]+src="(/[^"]+)"', html):
            local_path = WEB / src.lstrip("/")
            assert local_path.is_file(), f"{page_name} references missing {src}"
