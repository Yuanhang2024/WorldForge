from pathlib import Path
import tempfile
import unittest

from theater.gates import ScienceDirectorGate
from theater.models import CharacterPatch, WorldBookPatch
from theater.storage import JsonStateStore


class WorldAndCharacterTests(unittest.TestCase):
    def test_world_and_character_writes_require_science_director_approval(self):
        with tempfile.TemporaryDirectory() as directory:
            store = JsonStateStore(Path(directory))
            gate = ScienceDirectorGate()

            world_patch = WorldBookPatch(
                title="River Loop",
                content="A coastal city repeats the same storm every seven days.",
                source="unit-test",
            )
            character_patch = CharacterPatch(
                character_id="actor_a",
                name="Aster",
                summary="Archivist with a fractured second memory.",
                source="unit-test",
            )

            self.assertIs(store.add_world_entry(world_patch, approved_by=None), False)
            self.assertIs(store.upsert_character(character_patch, approved_by=None), False)

            approval = gate.validate_write([world_patch], [character_patch])

            self.assertIs(approval.approved, True)
            self.assertIs(store.add_world_entry(world_patch, approved_by=approval.director_id), True)
            self.assertIs(store.upsert_character(character_patch, approved_by=approval.director_id), True)
            snapshot = store.snapshot()
            self.assertTrue(any(entry.approved_by == "science_director" and entry.title == "River Loop" for entry in snapshot.worldbook))
            self.assertTrue(any(actor.character_id == "actor_a" for actor in snapshot.characters))


if __name__ == "__main__":
    unittest.main()
