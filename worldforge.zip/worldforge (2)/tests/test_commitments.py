"""Tests for the decision-commitment lifecycle (architecture spec — decisions
as persistent causal mechanisms).

Covers:
- Commitment state machine (all transitions + illegal ones rejected)
- DecisionResolver statuses (rejected/authorized/partial/delayed/sabotaged/completed)
- Effect-formula factors (authority/resource/org/exec/time/environment each move
  execution_ratio)
- cognitive error vs execution failure distinction
- ScheduledEffect trigger / cancel / delay
- WorldModifier apply / revert (start_tick / end_tick)
- AgentAgenda initiative → proactive proposal
- 3 generic actions (launch_project / establish_policy / mobilize_faction)
- 4-layer consequences (immediate_deltas / resource_transfers /
  relationship_changes / scheduled_effects / world_modifiers / spawned_commitments)
- time structure (social reactions land next tick, not telepathically this tick)
- observable-event broadcast (secrecy-gated per-subject projection)
- three-body example (scientist proposes emergency observatory → partial 40% +
  delayed 3 ticks → long-lived modifier)
- backward compatibility (enable_commitments=False is a no-op)

Pure stdlib, deterministic, no LLM.
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.commitments import (  # noqa: E402
    ACTION_TEMPLATES,
    AgentAgenda,
    Commitment,
    CommitmentExecutor,
    CommitmentStatus,
    DecisionEffects,
    ScheduledEffect,
    WorldModifier,
    authority_for_action,
    build_establish_policy_proposal,
    build_launch_project_proposal,
    build_mobilize_faction_proposal,
    customize_effects,
    is_terminal_status,
    proposal_from_template,
    resource_requirements_for,
    transition_commitment,
    valid_transition,
)
from theater.decision_resolver import (  # noqa: E402
    AuthorityCheck,
    DecisionResolver,
    Environment,
    Opposition,
    OrgSupport,
)
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.settings import Settings  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _orch(tmp: Path, *, enable_commitments: bool = False,
          enable_agent_mind: bool = False) -> TheaterOrchestrator:
    settings = Settings(
        data_dir=tmp / "runtime",
        enable_commitments=enable_commitments,
        enable_agent_mind=enable_agent_mind,
    )
    return TheaterOrchestrator(
        state_store=JsonStateStore(tmp / "state"),
        model_client=DeterministicModelClient(),
        settings=settings,
    )


# ---------------------------------------------------------------------------
# Commitment state machine
# ---------------------------------------------------------------------------


def test_state_machine_legal_transitions():
    """proposed→authorized→active→completed is the happy path."""
    c = Commitment(commitment_id="c1", actor_id="a", decision_type="launch_project")
    assert c.status == CommitmentStatus.PROPOSED
    transition_commitment(c, CommitmentStatus.AUTHORIZED, reason="auth ok")
    transition_commitment(c, CommitmentStatus.ACTIVE, reason="resources allocated")
    transition_commitment(c, CommitmentStatus.COMPLETED, reason="done")
    assert c.status == CommitmentStatus.COMPLETED
    assert is_terminal_status(c.status)
    # history is event-sourced + replayable
    events = [h["event"] for h in c.history]
    assert events.count("transition") == 3


def test_state_machine_blocked_can_resume():
    """active→blocked→active (opposition then unblock)."""
    c = Commitment(commitment_id="c2", actor_id="a", decision_type="launch_project",
                   status=CommitmentStatus.ACTIVE)
    transition_commitment(c, CommitmentStatus.BLOCKED, reason="opposition")
    transition_commitment(c, CommitmentStatus.ACTIVE, reason="unblocked")
    assert c.status == CommitmentStatus.ACTIVE


def test_state_machine_illegal_transition_rejected():
    """completed is terminal — cannot transition out."""
    c = Commitment(commitment_id="c3", actor_id="a", decision_type="launch_project",
                   status=CommitmentStatus.COMPLETED)
    with pytest.raises(ValueError):
        transition_commitment(c, CommitmentStatus.ACTIVE, reason="nope")
    # proposed→active is illegal (must pass through authorized)
    c2 = Commitment(commitment_id="c4", actor_id="a", decision_type="launch_project")
    with pytest.raises(ValueError):
        transition_commitment(c2, CommitmentStatus.ACTIVE)


def test_state_machine_terminal_states():
    """completed / abandoned / failed are all terminal."""
    for term in (CommitmentStatus.COMPLETED, CommitmentStatus.ABANDONED,
                 CommitmentStatus.FAILED):
        assert is_terminal_status(term)
    for nonterm in (CommitmentStatus.PROPOSED, CommitmentStatus.AUTHORIZED,
                    CommitmentStatus.ACTIVE, CommitmentStatus.BLOCKED):
        assert not is_terminal_status(nonterm)
    # valid_transition idempotent re-affirmation
    assert valid_transition(CommitmentStatus.ACTIVE, CommitmentStatus.ACTIVE)


def test_commitment_resource_gap():
    """resource_gap = required − allocated, clamped ≥ 0."""
    c = Commitment(commitment_id="c5", actor_id="a", decision_type="launch_project",
                   required_resources={"budget": 10.0, "labor": 4.0},
                   allocated_resources={"budget": 6.0})
    assert c.resource_gap == 8.0  # (10+4) − 6


# ---------------------------------------------------------------------------
# DecisionResolver statuses
# ---------------------------------------------------------------------------


def test_resolver_rejected_when_authority_infeasible():
    """Authority gate fails → rejected outright, no commitment created."""
    r = DecisionResolver()
    p = build_launch_project_proposal("a", proposed_tick=1)
    res = r.resolve(p, authority=AuthorityCheck(feasible=False, factor=0.0,
                                                reason="no mandate"))
    assert res.status == "rejected"
    assert res.execution_ratio == 0.0
    assert res.effects.is_empty
    assert res.commitment_id is None


def test_resolver_completed_instantaneous_action():
    """A strong instantaneous action (duration=1) landing fully → completed."""
    r = DecisionResolver()
    p = proposal_from_template("a", "launch_project", proposed_tick=1,
                               expected_duration=1, decision_strength=1.5,
                               required_resources={"budget": 1.0})
    res = r.resolve(p, resources={"budget": 1.0})
    assert res.status == "completed"
    assert res.execution_ratio == 1.0


def test_resolver_partial_under_resourced():
    """Allocated < required → partial (runs slower / weaker)."""
    r = DecisionResolver()
    p = build_launch_project_proposal("a", proposed_tick=1, scale=1.0)
    # only 40% of budget, full labor → resource factor = 0.4
    res = r.resolve(p, resources={"budget": 4.0, "labor": 8.0})
    assert res.status == "partial"
    assert res.execution_ratio < 0.5


def test_resolver_delayed_on_cognitive_error():
    """info_error ≥ 0.5 + net below partial threshold → delayed."""
    r = DecisionResolver()
    p = proposal_from_template("a", "launch_project", proposed_tick=1,
                               required_resources={"budget": 1.0})
    res = r.resolve(p, resources={"budget": 1.0},
                    environment=Environment(info_error=0.7, fit=0.6))
    assert res.status == "delayed"
    assert res.trace.cognitive_error is True
    assert res.trace.execution_failure is False


def test_resolver_sabotaged_on_active_opposition():
    """Active sabotage with strength ≥ sabotage_threshold → sabotaged."""
    r = DecisionResolver()
    p = build_mobilize_faction_proposal("a", proposed_tick=1)
    res = r.resolve(p, opposition=Opposition(strength=0.8, refs=["enemy"],
                                             sabotage=True))
    assert res.status == "sabotaged"
    assert res.trace.execution_failure is True


def test_resolver_authorized_happy_path():
    """Full resources + no opposition + duration>1 → authorized."""
    r = DecisionResolver()
    p = build_launch_project_proposal("a", proposed_tick=1)
    res = r.resolve(p, resources={"budget": 10.0, "labor": 8.0})
    assert res.status == "authorized"
    assert res.execution_ratio > 0.5
    assert res.creates_commitment


# ---------------------------------------------------------------------------
# Effect-formula factors (each independently moves execution_ratio)
# ---------------------------------------------------------------------------


def test_factor_authority_scales_effect():
    """Lower authority factor → lower net effect (holding all else equal)."""
    r = DecisionResolver()
    p = proposal_from_template("a", "launch_project", proposed_tick=1,
                                      required_resources={"budget": 1.0})
    full = r.resolve(p, authority=AuthorityCheck(feasible=True, factor=1.0),
                     resources={"budget": 1.0})
    half = r.resolve(p, authority=AuthorityCheck(feasible=True, factor=0.4),
                     resources={"budget": 1.0})
    assert full.execution_ratio > half.execution_ratio


def test_factor_resource_scales_effect():
    """resource factor = allocated/required (per-key min) drives net."""
    r = DecisionResolver()
    p = build_launch_project_proposal("a", proposed_tick=1)
    full = r.resolve(p, resources={"budget": 10.0, "labor": 8.0})
    starved = r.resolve(p, resources={"budget": 2.0, "labor": 8.0})
    assert full.execution_ratio > starved.execution_ratio
    assert starved.status == "partial"


def test_factor_org_compliance_scales_effect():
    """Lower org compliance → lower net effect."""
    r = DecisionResolver()
    p = proposal_from_template("a", "launch_project", proposed_tick=1,
                                      required_resources={"budget": 1.0})
    obedient = r.resolve(p, resources={"budget": 1.0},
                         org_support=OrgSupport(compliance=1.0))
    resistant = r.resolve(p, resources={"budget": 1.0},
                          org_support=OrgSupport(compliance=0.4))
    assert obedient.execution_ratio > resistant.execution_ratio


def test_factor_environment_fit_scales_effect():
    """Poor environment fit → lower net effect."""
    r = DecisionResolver()
    p = proposal_from_template("a", "launch_project", proposed_tick=1,
                                      required_resources={"budget": 1.0})
    good = r.resolve(p, resources={"budget": 1.0},
                     environment=Environment(fit=1.0))
    bad = r.resolve(p, resources={"budget": 1.0},
                    environment=Environment(fit=0.3))
    assert good.execution_ratio > bad.execution_ratio


def test_factor_time_scales_effect():
    """Less time_available → lower net effect."""
    r = DecisionResolver()
    p = proposal_from_template("a", "launch_project", proposed_tick=1,
                                      required_resources={"budget": 1.0})
    ample = r.resolve(p, resources={"budget": 1.0},
                      environment=Environment(time_available=1.0))
    rushed = r.resolve(p, resources={"budget": 1.0},
                       environment=Environment(time_available=0.3))
    assert ample.execution_ratio > rushed.execution_ratio


def test_factor_opposition_depresses_effect():
    """opposition strength multiplies net down by (1 − opposition)."""
    r = DecisionResolver()
    p = proposal_from_template("a", "launch_project", proposed_tick=1,
                                      required_resources={"budget": 1.0})
    none_ = r.resolve(p, resources={"budget": 1.0})
    opposed = r.resolve(p, resources={"budget": 1.0},
                        opposition=Opposition(strength=0.5, refs=["x"]))
    assert none_.execution_ratio > opposed.execution_ratio


# ---------------------------------------------------------------------------
# cognitive error vs execution failure distinction
# ---------------------------------------------------------------------------


def test_cognitive_error_flagged_separately_from_execution_failure():
    """info_error → cognitive_error=True; failure_pressure → execution_failure.
    Both depress net but for different narrative reasons."""
    r = DecisionResolver()
    base = proposal_from_template("a", "launch_project", proposed_tick=1,
                                         required_resources={"budget": 1.0})
    cog = r.resolve(base, environment=Environment(info_error=0.8))
    exe = r.resolve(base, environment=Environment(failure_pressure=0.8))
    assert cog.trace.cognitive_error is True
    assert cog.trace.execution_failure is False
    assert exe.trace.execution_failure is True
    assert exe.trace.cognitive_error is False


def test_decision_sound_but_execution_failed():
    """A sound decision (no cognitive error) can still fail at execution —
    the resolver tags execution_failure, not cognitive_error."""
    r = DecisionResolver()
    p = build_mobilize_faction_proposal("a", proposed_tick=1)
    res = r.resolve(p, opposition=Opposition(strength=0.7, refs=["x"],
                                             sabotage=True))
    assert res.status == "sabotaged"
    assert res.trace.cognitive_error is False
    assert res.trace.execution_failure is True


def test_actor_judgement_wrong_is_cognitive_not_execution():
    """info_error high → delayed (cognitive), not sabotaged (execution)."""
    r = DecisionResolver()
    p = proposal_from_template("a", "launch_project", proposed_tick=1,
                                      required_resources={"budget": 1.0})
    res = r.resolve(p, resources={"budget": 1.0},
                    environment=Environment(info_error=0.9, fit=0.5))
    assert res.trace.cognitive_error is True
    assert res.trace.execution_failure is False
    assert res.status == "delayed"


# ---------------------------------------------------------------------------
# ScheduledEffect — trigger / cancel / delay
# ---------------------------------------------------------------------------


def test_scheduled_effect_fires_at_due_tick_when_condition_holds():
    eff = ScheduledEffect(source_id="s1", due_tick=3,
                          effect={"op": "set", "path": "x", "value": 1})
    assert not eff.should_fire({}, 2)
    assert eff.should_fire({}, 3)
    # should_fire is a pure check; the executor sets `triggered` when it
    # actually applies the effect (next test covers that path).
    eff.triggered = True
    assert not eff.should_fire({}, 3)  # already triggered → no re-fire


def test_scheduled_effect_condition_false_blocks_fire():
    eff = ScheduledEffect(source_id="s2", due_tick=1,
                          effect={"op": "event"},
                          condition=lambda ws, t: ws.get("go") is True)
    assert not eff.should_fire({}, 1)
    assert eff.should_fire({"go": True}, 1)


def test_scheduled_effect_cancel_condition_aborts():
    eff = ScheduledEffect(source_id="s3", due_tick=2,
                          effect={"op": "event"},
                          cancel_conditions=[lambda ws, t: ws.get("abort") is True])
    assert eff.should_cancel({"abort": True}, 1)
    assert eff.cancelled
    assert not eff.should_fire({}, 2)


def test_executor_triggers_scheduled_effect_into_deltas():
    ex = CommitmentExecutor()
    state: Dict[str, Any] = {"counter": 0.0}
    eff = ScheduledEffect(source_id="s", due_tick=1,
                          effect={"op": "add", "path": "counter", "value": 5.0})
    ex.register_scheduled_effect(eff)
    rec = ex.tick_commitments(state, 1)
    assert eff.triggered
    assert state["counter"] == 5.0
    assert "counter" in rec.immediate_deltas


# ---------------------------------------------------------------------------
# WorldModifier — apply / revert
# ---------------------------------------------------------------------------


def test_world_modifier_applied_at_start_tick():
    ex = CommitmentExecutor()
    state: Dict[str, Any] = {}
    mod = WorldModifier(modifier_id="m1", source_decision_id="d1",
                        scope="policy", start_tick=2, end_tick=5,
                        rule_modifiers=[{"path": "policy.tax", "op": "set",
                                         "value": 0.3}])
    ex.register_world_modifier(mod)
    ex.tick_commitments(state, 1)
    assert not mod.applied
    ex.tick_commitments(state, 2)
    assert mod.applied
    assert state["policy"]["tax"] == 0.3


def test_world_modifier_reverted_after_end_tick():
    ex = CommitmentExecutor()
    state: Dict[str, Any] = {"policy": {"tax": 0.1}}
    mod = WorldModifier(modifier_id="m2", source_decision_id="d2",
                        scope="policy", start_tick=1, end_tick=3,
                        rule_modifiers=[{"path": "policy.tax", "op": "set",
                                         "value": 0.4}])
    ex.register_world_modifier(mod)
    ex.tick_commitments(state, 1)
    assert state["policy"]["tax"] == 0.4
    ex.tick_commitments(state, 4)  # past end_tick → reverted
    assert state["policy"]["tax"] == 0.1  # prior restored


def test_world_modifier_add_op_reverts_by_subtracting():
    ex = CommitmentExecutor()
    state: Dict[str, Any] = {"funding": 10.0}
    mod = WorldModifier(modifier_id="m3", source_decision_id="d3",
                        scope="x", start_tick=1, end_tick=2,
                        rule_modifiers=[{"path": "funding", "op": "add",
                                         "value": 5.0}])
    ex.register_world_modifier(mod)
    ex.tick_commitments(state, 1)
    assert state["funding"] == 15.0
    ex.tick_commitments(state, 3)
    assert state["funding"] == 10.0


# ---------------------------------------------------------------------------
# AgentAgenda initiative → proactive proposal
# ---------------------------------------------------------------------------


def test_agenda_initiative_below_threshold_no_proposal():
    ag = AgentAgenda(initiative_threshold=1.5, personality_drive=0.2)
    ag.add_goal("g", urgency=0.3, cost=0.4, authority_barrier=0.3,
                uncertainty=0.3)
    assert not ag.should_propose(current_tick=1)


def test_agenda_initiative_above_threshold_proposes():
    ag = AgentAgenda(initiative_threshold=0.3, personality_drive=0.8)
    ag.add_goal("build_x", urgency=0.9, cost=0.1, authority_barrier=0.1,
                uncertainty=0.1)
    assert ag.should_propose(current_tick=1, opportunity_fit=0.5)


def test_agenda_deadline_pressure_boosts_initiative():
    ag = AgentAgenda(initiative_threshold=0.8, personality_drive=0.3)
    ag.add_goal("urgent", urgency=0.4, cost=0.2, authority_barrier=0.1,
                uncertainty=0.1)
    ag.deadlines["urgent"] = 2  # due next tick → +1.0 urgency
    assert ag.should_propose(current_tick=1, opportunity_fit=0.3)


# ---------------------------------------------------------------------------
# 3 generic actions
# ---------------------------------------------------------------------------


def test_launch_project_proposal_uses_template_defaults():
    p = build_launch_project_proposal("sci", proposed_tick=1)
    assert p.decision_type == "launch_project"
    assert p.expected_duration == ACTION_TEMPLATES["launch_project"]["default_duration"]
    assert set(p.required_resources.keys()) == {"budget", "labor"}
    assert p.reversibility == ACTION_TEMPLATES["launch_project"]["default_reversibility"]


def test_establish_policy_proposal_canonical_resources():
    p = build_establish_policy_proposal("ruler", proposed_tick=1)
    assert p.decision_type == "establish_policy"
    assert set(p.required_resources.keys()) == {"authority"}
    # policy is sticky → low reversibility
    assert p.reversibility < 0.2


def test_mobilize_faction_proposal_stashes_opposition_refs():
    p = build_mobilize_faction_proposal("leader", target_ids=["f1"],
                                        opposition_refs=["f2", "f3"],
                                        proposed_tick=1)
    assert p.decision_type == "mobilize_faction"
    assert set(p.required_resources.keys()) == {"personnel", "morale"}
    assert getattr(p, "_opposition_refs") == ["f2", "f3"]


def test_resource_requirements_scale_with_size():
    small = resource_requirements_for("launch_project", scale=1.0)
    big = resource_requirements_for("launch_project", scale=3.0)
    assert big["budget"] == 3.0 * small["budget"]


def test_authority_for_action_rejects_zero_mandate():
    auth = authority_for_action("launch_project", "a", mandate=0.0)
    assert not auth.feasible
    auth2 = authority_for_action("launch_project", "a", mandate=0.5)
    assert auth2.feasible
    assert auth2.factor == 0.5


# ---------------------------------------------------------------------------
# 4-layer consequences
# ---------------------------------------------------------------------------


def test_four_layer_consequences_present_for_authorized_resolution():
    r = DecisionResolver()
    p = build_launch_project_proposal("a", proposed_tick=1)
    res = r.resolve(p, resources={"budget": 10.0, "labor": 8.0})
    e = res.effects
    # 1. immediate_deltas — reputation staked
    assert any("reputation" in k for k in e.immediate_deltas)
    # 2. resource_transfers — consumed resources flow out
    assert any(t["resource"] == "budget" for t in e.resource_transfers)
    # 4. scheduled_effects — outcome event at project end
    assert len(e.scheduled_effects) >= 1
    # 5. world_modifiers — template modifier
    assert len(e.world_modifiers) >= 1


def test_mobilize_faction_relationship_changes():
    """customize_effects adds relationship_changes for rallied + opposed."""
    r = DecisionResolver()
    p = build_mobilize_faction_proposal("leader", target_ids=["ally1"],
                                        opposition_refs=["enemy1"],
                                        proposed_tick=1)
    res = r.resolve(p, resources={"personnel": 8.0, "morale": 5.0})
    rc = res.effects.relationship_changes
    allies = [c for c in rc if c["to"] == "ally1"]
    enemies = [c for c in rc if c["to"] == "enemy1"]
    assert allies and allies[0]["trust_delta"] > 0
    assert enemies and enemies[0]["conflict_delta"] > 0


def test_establish_policy_immediate_enact_flag():
    """customize_effects adds an immediate policy.enacted delta for policy."""
    r = DecisionResolver()
    p = build_establish_policy_proposal("ruler", proposed_tick=1)
    res = r.resolve(p, resources={"authority": 6.0})
    assert any(k.startswith("policy.") for k in res.effects.immediate_deltas)


def test_spawned_commitments_initially_empty():
    """The generic resolver does not spawn sub-commitments by default."""
    r = DecisionResolver()
    p = build_launch_project_proposal("a", proposed_tick=1)
    res = r.resolve(p, resources={"budget": 10.0, "labor": 8.0})
    assert res.effects.spawned_commitments == []


# ---------------------------------------------------------------------------
# CommitmentExecutor progress + completion
# ---------------------------------------------------------------------------


def test_executor_advances_active_commitment_to_completion():
    r = DecisionResolver()
    ex = CommitmentExecutor()
    p = build_launch_project_proposal("a", proposed_tick=1, expected_duration=4)
    res = r.resolve_and_commit(p, ex, resources={"budget": 10.0, "labor": 8.0})
    cid = res.commitment_id
    assert cid is not None
    c = ex.commitments[cid]
    # activate
    transition_commitment(c, CommitmentStatus.ACTIVE, reason="start")
    state: Dict[str, Any] = {}
    # 4 ticks at full resources → progress reaches 1.0 → completed
    for t in range(2, 8):
        rec = ex.tick_commitments(state, t)
        if c.status == CommitmentStatus.COMPLETED:
            break
    assert c.status == CommitmentStatus.COMPLETED
    assert cid in rec.completed_commitments


def test_executor_blocks_on_zero_step():
    """An active commitment with no allocated resources → step 0 → blocked.
    (A zero-resource proposal is rejected by the resolver; this test builds
    the commitment directly to exercise the executor's zero-step → blocked
    transition.)"""
    ex = CommitmentExecutor()
    c = Commitment(commitment_id="cz", actor_id="a",
                   decision_type="launch_project",
                   required_resources={"budget": 10.0},
                   allocated_resources={"budget": 0.0},
                   expected_duration=4, status=CommitmentStatus.ACTIVE)
    c._execution_ratio = 1.0  # type: ignore[attr-defined]
    ex.register_commitment(c)
    rec = ex.tick_commitments({}, 2)
    assert c.status == CommitmentStatus.BLOCKED
    assert c.commitment_id in rec.blocked_commitments


def test_executor_blocked_resumes_when_resource_gap_closes():
    """A blocked commitment auto-resumes when allocated catches up."""
    ex = CommitmentExecutor()
    c = Commitment(commitment_id="cb", actor_id="a",
                   decision_type="launch_project",
                   required_resources={"budget": 10.0},
                   allocated_resources={"budget": 0.0},
                   expected_duration=4, status=CommitmentStatus.BLOCKED)
    c._execution_ratio = 1.0  # type: ignore[attr-defined]
    ex.register_commitment(c)
    # gap still open → stays blocked
    rec = ex.tick_commitments({}, 1)
    assert c.status == CommitmentStatus.BLOCKED
    # close the gap
    c.allocated_resources["budget"] = 10.0
    rec = ex.tick_commitments({}, 2)
    assert c.status == CommitmentStatus.ACTIVE


# ---------------------------------------------------------------------------
# Tick wiring — time structure (social reactions land next tick)
# ---------------------------------------------------------------------------


def test_world_tick_commitments_trace_present_when_enabled():
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_commitments=True)
        orch.set_world("w")
        prop = build_launch_project_proposal("sci1", proposed_tick=1)
        orch.register_commitment_proposal("w", prop)
        result = orch.world_tick()
        assert result is not None
        cs = result.model_trace["commitments"]
        assert len(cs["resolutions"]) == 1
        assert cs["resolutions"][0]["proposal"]["decision_type"] == "launch_project"


def test_social_reaction_lands_next_tick_not_telepathic():
    """A commitment created this tick is NOT progressed this tick — it only
    starts advancing on the *next* tick (no telepathic same-tick completion).
    Phase 8 this tick activates + advances once, but social reactions from
    other agents come via their own next-tick agendas, not this tick."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_commitments=True)
        orch.set_world("w")
        prop = build_launch_project_proposal("sci1", proposed_tick=1,
                                             expected_duration=8)
        orch.register_commitment_proposal("w", prop)
        orch.world_tick()  # tick 1: proposed → authorized → active → 1 step
        ex = orch.get_commitment_executor("w")
        c = ex.commitments["commit:sci1:launch_project:1"]
        assert c.status == CommitmentStatus.ACTIVE
        progress_after_tick1 = c.progress
        assert 0.0 < progress_after_tick1 < 1.0  # not done yet
        # tick 2: advances further (social reaction / next-beat progression)
        prop2 = build_launch_project_proposal("sci1", proposed_tick=2,
                                              expected_duration=8)
        orch.register_commitment_proposal("w", prop2)
        orch.world_tick()
        c = ex.commitments["commit:sci1:launch_project:1"]
        assert c.progress > progress_after_tick1


def test_observable_broadcast_secrecy_gated():
    """A secret commitment's events have low visibility → other agents don't
    see them in the per-subject projection."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_commitments=True)
        orch.set_world("w")
        # observer agenda so projection has a subject
        obs = AgentAgenda(initiative_threshold=2.0)  # never proposes
        obs.add_goal("watch", urgency=0.1)
        orch.register_agent_agenda("w", "observer", obs)
        # secret proposal
        prop = build_mobilize_faction_proposal("spy", target_ids=["f1"],
                                               secrecy=0.9, proposed_tick=1)
        orch.register_commitment_proposal("w", prop)
        result = orch.world_tick()
        cs = result.model_trace["commitments"]
        # broadcast has the decision_resolved event with low visibility
        visibilities = [ev.get("visibility", 1.0) for ev in cs["broadcast"]]
        assert any(v < 0.2 for v in visibilities)
        # observer's projection: secret event (vis < 0.3) not seen
        seen = cs["projections"].get("observer", [])
        assert all(ev["visibility"] >= 0.3 for ev in seen)


def test_observable_broadcast_public_visible_to_all():
    """A public commitment is visible to every observer in projection."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_commitments=True)
        orch.set_world("w")
        obs = AgentAgenda(initiative_threshold=2.0)
        obs.add_goal("watch", urgency=0.1)
        orch.register_agent_agenda("w", "observer", obs)
        prop = build_launch_project_proposal("sci", proposed_tick=1, secrecy=0.0)
        orch.register_commitment_proposal("w", prop)
        result = orch.world_tick()
        cs = result.model_trace["commitments"]
        seen = cs["projections"].get("observer", [])
        assert len(seen) >= 1


def test_commitment_beat_recorded_in_worldbook():
    """Phase 6 records a canonical worldbook fact (origin=commitment) so the
    world has continuity."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_commitments=True)
        orch.set_world("w")
        prop = build_launch_project_proposal("sci1", proposed_tick=1)
        orch.register_commitment_proposal("w", prop)
        orch.world_tick()
        wb = orch.state_store.snapshot().worldbook
        entries = [e for e in wb if e.source == "commitment_tick"]
        assert len(entries) == 1
        assert entries[0].provenance == "canonical_event"
        assert "sci1" in entries[0].content


# ---------------------------------------------------------------------------
# Backward compatibility
# ---------------------------------------------------------------------------


def test_enable_commitments_off_is_noop():
    """With enable_commitments=False (opt-out), world_tick does NOT run the
    commitment Phase 4-8 even if an agenda + proposal are registered."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_commitments=False)
        orch.set_world("w")
        ag = AgentAgenda(initiative_threshold=0.1, personality_drive=0.9)
        ag.add_goal("g", urgency=0.9)
        orch.register_agent_agenda("w", "a", ag)
        prop = build_launch_project_proposal("a", proposed_tick=1)
        orch.register_commitment_proposal("w", prop)
        result = orch.world_tick()
        assert result is not None
        assert "commitments" not in result.model_trace
        # no commitment worldbook entry
        wb = orch.state_store.snapshot().worldbook
        assert not [e for e in wb if e.source == "commitment_tick"]
        # executor empty (layer lazily created only on access, but no
        # commitments registered since tick didn't run)
        assert orch.get_commitment_executor("w").commitments == {}


def test_enable_commitments_default_on():
    """Settings north-star default: enable_commitments is True (a one-shot
    world's major decisions persist without extra flags). Env can turn off."""
    s = Settings()
    assert s.enable_commitments is True


# ---------------------------------------------------------------------------
# Three-body example — scientist proposes emergency observatory
# ---------------------------------------------------------------------------


def test_three_body_emergency_observatory_partial_plus_delayed_modifier():
    """The spec's three-body example: a scientist proposes an emergency
    observatory. Partial authority (40% mandate) + cognitive uncertainty
    → partial resolution (~40% exec) → the project still produces a
    long-lived world modifier (the observatory's output), just weaker.

    We assert:
    - status is partial (authority factor 0.4 < partial threshold routing)
    - execution_ratio ≈ 0.4 (authority-capped)
    - a WorldModifier is produced whose duration > 0 (long-lived)
    - the commitment is registered + activated
    """
    r = DecisionResolver()
    ex = CommitmentExecutor()
    # emergency observatory: launch_project, 8-tick duration
    prop = build_launch_project_proposal(
        "scientist_s1", target_ids=["observatory_site"],
        goal="emergency_observatory", scale=1.0, proposed_tick=1,
        expected_duration=8,
    )
    # full authority (self-authored) but only 40% of the budget approved by
    # the org → resource factor 0.4 → partial resolution (~32% exec after the
    # mild cognitive uncertainty on the chaotic-era timing).
    auth = authority_for_action("launch_project", "scientist_s1", mandate=1.0)
    res = r.resolve_and_commit(
        prop, ex, authority=auth,
        resources={"budget": 4.0, "labor": 8.0},
        environment=Environment(info_error=0.2, fit=0.8),
    )
    assert res.status == "partial"
    # exec ratio depressed by the 40% budget allocation
    assert 0.15 <= res.execution_ratio < 0.5
    assert res.commitment_id is not None
    # a long-lived modifier is produced (end > start, duration > 0)
    mods = res.effects.world_modifiers
    assert len(mods) == 1
    m = mods[0]
    assert m.end_tick > m.start_tick
    # the commitment is registered + authorized
    c = ex.commitments[res.commitment_id]
    assert c.status == CommitmentStatus.AUTHORIZED
    assert c.decision_type == "launch_project"
    # activate + advance a few ticks → progress grows (not instant)
    transition_commitment(c, CommitmentStatus.ACTIVE, reason="start")
    state: Dict[str, Any] = {}
    p0 = c.progress
    ex.tick_commitments(state, 2)
    assert c.progress > p0


def test_three_body_delayed_then_authorized_next_ticks():
    """The 'delayed 3 ticks' branch: a proposal with high cognitive error is
    delayed this tick. Re-proposed with cleared info_error on tick 4 →
    authorized. Confirms the delayed status is non-terminal and the
    commitment can still land once the actor's judgement clears."""
    r = DecisionResolver()
    # tick 1: high info_error → delayed
    prop1 = proposal_from_template("s1", "launch_project", proposed_tick=1,
                                          expected_duration=4,
                                          required_resources={"budget": 1.0})
    res1 = r.resolve(prop1, resources={"budget": 1.0},
                     environment=Environment(info_error=0.8, fit=0.6))
    assert res1.status == "delayed"
    # a delayed decision still creates a (paused) commitment — it is
    # non-terminal and resumes once the actor's judgement clears.
    assert res1.creates_commitment
    assert res1.trace.cognitive_error is True
    # tick 4: info cleared → authorized (decision sound all along)
    prop4 = proposal_from_template("s1", "launch_project", proposed_tick=4,
                                          expected_duration=4,
                                          required_resources={"budget": 1.0})
    res4 = r.resolve(prop4, environment=Environment(info_error=0.0, fit=0.9),
                     resources={"budget": 1.0})
    assert res4.status in ("authorized", "completed")
    assert res4.creates_commitment


def test_agenda_driven_proposal_via_world_tick():
    """A registered AgentAgenda whose initiative crosses threshold produces a
    CommitmentProposal inside world_tick (no external queueing)."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_commitments=True)
        orch.set_world("w")
        ag = AgentAgenda(initiative_threshold=0.3, personality_drive=0.8)
        ag.add_goal("build_observatory", urgency=0.9, cost=0.1,
                    authority_barrier=0.1, uncertainty=0.1)
        orch.register_agent_agenda("w", "sci1", ag)
        result = orch.world_tick()
        cs = result.model_trace["commitments"]
        # the agenda proposed a launch_project
        assert any(p["actor_id"] == "sci1" and p["decision_type"] == "launch_project"
                   for p in cs["proposals"])


# ---------------------------------------------------------------------------
# Spawned commitment via scheduled effect (path dependence)
# ---------------------------------------------------------------------------


def test_scheduled_effect_can_spawn_commitment():
    """A scheduled effect with op=spawn_commitment registers a new commitment
    in the executor (path dependence — a decision begets a decision)."""
    ex = CommitmentExecutor()
    state: Dict[str, Any] = {}
    child_spec = {
        "commitment_id": "child:1", "actor_id": "a",
        "decision_type": "launch_project", "expected_duration": 2,
    }
    eff = ScheduledEffect(source_id="parent", due_tick=1,
                          effect={"op": "spawn_commitment",
                                  "commitment": child_spec})
    ex.register_scheduled_effect(eff)
    rec = ex.tick_commitments(state, 1)
    assert "child:1" in ex.commitments
    assert "child:1" in rec.spawned_commitments


def test_customize_effects_idempotent_for_unknown_action():
    """customize_effects on an unknown verb returns effects unchanged."""
    p = proposal_from_template("a", "launch_project", proposed_tick=1)
    e = DecisionEffects(immediate_deltas={"x": 1.0})
    out = customize_effects("unknown_verb", p, e, 0.5)
    assert out is e
    assert out.immediate_deltas == {"x": 1.0}


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-q"]))
