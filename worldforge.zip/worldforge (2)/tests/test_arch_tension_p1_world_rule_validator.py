"""P1 — 张力1: world rules get a dynamic acceptance gate (parity with gameplay).

Before this fix, RuleCompiler.validate_spec only did *static* syntax checks
on a WorldKernelSpec, while gameplay rules got a four-gate dynamic validator.
World rules have larger blast radius, so the gate was asymmetrically loose.

These tests pin :class:`WorldRuleValidator` (dynamic gate) + its onboarding
wiring: a spec that compiles statically but explodes / breaks invariants
dynamically is rejected and blocks onboarding.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.onboarding import OnboardingFlow  # noqa: E402
from theater.settings import Settings  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402
from theater.world_kernel_host import WorldKernelSpec, WorldRule  # noqa: E402
from theater.world_rule_validator import WorldRuleValidator  # noqa: E402


@pytest.fixture
def tmp_root(tmp_path):
    return tmp_path


# ---------------------------------------------------------------------------
# validator: presets + well-formed specs pass
# ---------------------------------------------------------------------------


def test_validator_accepts_well_formed_dynamic_spec():
    spec = WorldKernelSpec(
        world_type="economy",
        rules=[
            WorldRule(rule_id="produce", kind="dynamic", trigger="turn.tick",
                      effect={"writes": "supply", "value": {"op": "add",
                              "args": [{"ref": "supply"}, {"const": 1}]}}),
        ],
        initial_state={"supply": 10},
    )
    r = WorldRuleValidator().validate(spec, beats=8)
    assert r.passed, r.reasons
    assert r.checks["compiles"].passed
    assert r.checks["invariants_hold"].passed
    assert r.checks["no_divergence"].passed
    assert r.checks["bounded_growth"].passed


def test_validator_accepts_preset_economy():
    from theater.rule_generator import _PRESET_BUILDERS
    spec = _PRESET_BUILDERS["economy"]()
    r = WorldRuleValidator().validate(spec, beats=16)
    assert r.passed, r.reasons


def test_validator_rejects_static_syntax_error():
    """A spec with a duplicate rule_id fails the compile precondition."""
    spec = WorldKernelSpec(
        world_type="economy",
        rules=[
            WorldRule(rule_id="dup", kind="dynamic", trigger="turn.tick",
                      effect={"writes": "x", "value": {"const": 1}}),
            WorldRule(rule_id="dup", kind="dynamic", trigger="turn.tick",
                      effect={"writes": "x", "value": {"const": 2}}),
        ],
        initial_state={"x": 0},
    )
    r = WorldRuleValidator().validate(spec)
    assert not r.passed
    assert "compiles" in r.checks
    assert not r.checks["compiles"].passed


# ---------------------------------------------------------------------------
# validator: explosive growth is rejected (the headline case)
# ---------------------------------------------------------------------------


def test_validator_rejects_explosive_growth():
    """population *= 2 each tick — compiles statically, explodes dynamically."""
    spec = WorldKernelSpec(
        world_type="economy",
        rules=[WorldRule(rule_id="grow", kind="dynamic", trigger="turn.tick",
                         effect={"writes": "population", "op": "set",
                                 "value": {"op": "mul", "args": [
                                     {"ref": "population"}, {"const": 2}]}})],
        initial_state={"population": 10},
    )
    r = WorldRuleValidator().validate(spec, beats=64, explosion_limit=1e6)
    assert not r.passed
    assert not r.checks["bounded_growth"].passed
    assert any("bounded_growth" in reason for reason in r.reasons)


def test_validator_rejects_invariant_break():
    """A rule that mutates gold breaks the gold==constant invariant."""
    spec = WorldKernelSpec(
        world_type="economy",
        rules=[
            WorldRule(rule_id="mint", kind="dynamic", trigger="turn.tick",
                      effect={"writes": "gold", "value": {"op": "add",
                              "args": [{"ref": "gold"}, {"const": 5}]}}),
            WorldRule(rule_id="gold_const", kind="invariant", trigger=None,
                      effect={"predicate": {"op": "eq", "args": [
                          {"ref": "gold"}, {"const": 100}]}}),
        ],
        initial_state={"gold": 100},
    )
    r = WorldRuleValidator().validate(spec, beats=4)
    assert not r.passed
    assert not r.checks["invariants_hold"].passed


def test_validator_rejects_divergence_to_nan():
    """Division that yields inf/nan-like blowup is caught by no_divergence or
    bounded_growth. Construct a div-by-zero protected path that still explodes."""
    # 1/x where x shrinks each tick — but div by zero raises DSLError (skip).
    # Instead use unbounded mul to trigger bounded_growth; verify no_divergence
    # check exists and passes for a benign spec.
    spec = WorldKernelSpec(
        world_type="economy",
        rules=[WorldRule(rule_id="grow", kind="dynamic", trigger="turn.tick",
                         effect={"writes": "x", "op": "set",
                                 "value": {"op": "mul", "args": [
                                     {"ref": "x"}, {"const": 3}]}})],
        initial_state={"x": 1},
    )
    r = WorldRuleValidator().validate(spec, beats=40, explosion_limit=1e6)
    assert not r.passed
    # Either bounded_growth fires (most likely) — no_divergence should be True.
    assert r.checks["no_divergence"].passed


def test_validator_require_all_seeds_stricter():
    """With require_all_seeds=True, perturbed-seed failures also block."""
    from theater.rule_generator import _PRESET_BUILDERS
    spec = _PRESET_BUILDERS["economy"]()
    # Default: preset passes (seed 0 ok, perturbed warnings non-blocking).
    r_default = WorldRuleValidator().validate(spec, beats=16)
    assert r_default.passed
    # Strict: perturbed-seed price_non_negative failure now blocks.
    r_strict = WorldRuleValidator().validate(spec, beats=16, require_all_seeds=True)
    assert not r_strict.passed


def test_validator_report_to_dict_shape():
    spec = WorldKernelSpec(
        world_type="economy",
        rules=[WorldRule(rule_id="r", kind="dynamic", trigger="turn.tick",
                         effect={"writes": "x", "value": {"const": 1}})],
        initial_state={"x": 0},
    )
    r = WorldRuleValidator().validate(spec, beats=4)
    d = r.to_dict()
    assert d["passed"] is True
    assert "checks" in d
    assert "reasons" in d
    for name in ("compiles", "invariants_hold", "no_divergence", "bounded_growth"):
        assert name in d["checks"]


# ---------------------------------------------------------------------------
# onboarding wiring: dynamic failure → explicit block
# ---------------------------------------------------------------------------


_EXPLOSIVE_RULE_JSON = json.dumps({
    "world_type": "economy",
    "rules": [{
        "rule_id": "explode",
        "kind": "dynamic",
        "trigger": "turn.tick",
        "effect": {"writes": "population", "op": "set",
                   "value": {"op": "mul", "args": [{"ref": "population"},
                                                    {"const": 2}]}},
        "description": "每拍人口翻倍（会爆炸）",
        "priority": 30,
    }],
    "params": {"seed": 42},
    "initial_state": {"population": 10},
})


class _ExplosiveLLMClient:
    def as_text_fn(self, temperature=0.2, max_tokens=2048):
        def _fn(prompt: str) -> str:
            return _EXPLOSIVE_RULE_JSON
        return _fn

    def as_dict_fn(self, temperature=0.4, max_tokens=2048):
        def _fn(world_style: str) -> Dict[str, Any]:
            if "世界设计架构师" in world_style:
                return {
                    "world_type": "test_economy", "seed": 42, "lambda": 0.5,
                    "initial_state": {"population": 10},
                }
            return {"gui_spec_id": "x", "world_id": "w", "layout_type": "dashboard",
                    "grid": {"columns": "1fr", "areas": ["main"]},
                    "widgets": [{"id": "r", "type": "text", "area": "main",
                                 "binds": {"read": "k"}}]}
        return _fn


def _build_orchestrator(root: Path) -> TheaterOrchestrator:
    settings = Settings(data_dir=root, enable_live_api=False)
    return TheaterOrchestrator(
        state_store=JsonStateStore(root / "state"),
        model_client=DeterministicModelClient(),
        settings=settings,
    )


def test_onboarding_dynamic_gate_rejects_explosive_without_fallback(tmp_root):
    """An explosive LLM rule blocks onboarding; no safety preset is installed."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_ExplosiveLLMClient(),
    )
    result = flow.run("一个未指定类型的世界", characters=[], use_llm=True)
    rules = result["stages"]["rules"]
    assert result["ok"] is False
    assert result["error_code"] == "rules_gui_generation_failed"
    assert rules["ok"] is False
    assert "dynamic validation" in rules["error"]
    assert rules["source"] == "unavailable"
    assert rules["world_type"] == ""
    assert rules["registered"] is False
    assert not flow.orchestrator._world_kernel_hosts
