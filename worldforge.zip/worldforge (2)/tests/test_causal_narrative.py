"""Tests for the two-stage causal narrative pipeline (architecture spec §14).

Covers:

  - :class:`CausalTraceBuilder`: forward topological order, the six edge
    types (physical_cause / informational / epistemic / motivational /
    social_influence / institutional).
  - :class:`NarrativePlanner`: fake-LLM JSON plan and explicit failures.
  - :class:`CausalValidator`: the four rejections (belief not held /
    out-of-permission / unknown fact / outcome flip) and the accept case.
  - :class:`NarrativeRealizer`: approved graph → LLM prose.
  - End-to-end: tick → CausalGraph → Planner → Validator → Realizer →
    NLI guard.
  - Counter-intuitive ending protection (research note Q2): "the
    civilisation dehydrated correctly but was destroyed anyway" must
    pass the validator and the realizer must NOT flip it to survival.

No real Spark / torch dependency — every LLM is a fake ``llm_fn`` and
every NLI guard is an injected stub.
"""

from __future__ import annotations

import json
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.belief_update import BeliefUpdateTrace  # noqa: E402
from theater.causal_narrative import (  # noqa: E402
    EDGE_TYPES,
    CausalNarrativeEngine,
    CausalPlan,
    CausalTraceBuilder,
    CausalValidator,
    CommittedTick,
    NarrativePlanner,
    NarrativeRealizer,
    _keyword_consistent,
)
from theater.cognitive_model import Belief  # noqa: E402
from theater.nli_guard import NliGuard  # noqa: E402
from theater.sim_agent import (  # noqa: E402
    AgentMindState,
    CharacterDefinition,
    SimAgent,
    WorldBinding,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _agent(actor_id="lu", personality="理性", allowed=("dehydrate", "observe", "speak"),
           beliefs=None, goals=("survive",)):
    char = CharacterDefinition(character_id=actor_id, name=actor_id,
                               personality=personality, social_role="observer")
    binding = WorldBinding(world_id="three_body",
                           permissions={"allowed_actions": list(allowed)})
    ms = AgentMindState(beliefs=beliefs or {"next_chaos": Belief(predicted=12.5,
                                                                 confidence=0.7)},
                        goals=list(goals))
    return SimAgent(character=char, world_binding=binding, mind_state=ms)


def _trace(topic="next_chaos", actor_id="lu", strategy="rational",
           accepted=True):
    return BeliefUpdateTrace(
        topic=topic,
        prior=Belief(predicted=10.0),
        observation=12.5,
        evidence_weight=1.0,
        update_rate=0.5,
        strategy=strategy,
        personality_modifiers={},
        contradiction=0.0,
        accepted=accepted,
        rejected_info=None,
        posterior=Belief(predicted=12.5, confidence=0.7),
    )


def _tick(actor_id="lu", outcome_kind="destroyed_chaos",
          outcome_cause="乱纪元灾变", verb="dehydrate",
          decision_rationale="乱纪元将至",
          beliefs=None, agents=None, observations=None,
          canonical_facts=None, traces=None, goals=("survive",)):
    agent = (agents or {}).get(actor_id) or _agent(
        actor_id=actor_id, beliefs=beliefs, goals=goals)
    return CommittedTick(
        tick=3,
        actor_id=actor_id,
        belief_traces=traces if traces is not None else [_trace(actor_id=actor_id)],
        decision={"actor_id": actor_id, "verb": verb,
                  "rationale": decision_rationale},
        outcome={"kind": outcome_kind, "cause": outcome_cause},
        canonical_facts=canonical_facts if canonical_facts is not None else [
            {"id": "f1", "summary": "三颗太阳无序跃动"}],
        actors={actor_id: agent, **(agents or {})},
        observations=observations if observations is not None else {
            actor_id: [{"fact_id": "f1"}]},
    )


def _make_good_planner_llm(actor_id="lu", effect="destroyed_chaos",
                            cause="乱纪元灾变", mechanism="physical_cause",
                            reason="预见灾变故脱水",
                            belief_refs=None, fact_refs=None):
    """Return a fake planner_llm that returns a valid plan."""
    payload = {
        "cause": cause,
        "mechanism": mechanism,
        "effect": effect,
        "subjective_reason": reason,
        "belief_refs": belief_refs or ["next_chaos"],
        "fact_refs": fact_refs or ["f1"],
        "confidence": 0.8,
    }

    def planner_llm(prompt: str) -> str:
        return json.dumps(payload)
    return planner_llm


# ---------------------------------------------------------------------------
# CausalTraceBuilder — edge vocabulary + forward order
# ---------------------------------------------------------------------------


def test_edge_types_are_exactly_six():
    assert len(EDGE_TYPES) == 6
    assert set(EDGE_TYPES) == {
        "physical_cause", "informational", "epistemic", "motivational",
        "social_influence", "institutional",
    }


def test_builder_produces_forward_topological_order():
    tick = _tick()
    graph = CausalTraceBuilder().build(tick)
    order = graph.topo_order()
    # decision must come before outcome (physical_cause edge).
    assert order.index("decision") < order.index("outcome")
    # belief must come before decision (epistemic edge).
    assert order.index("belief:lu:next_chaos") < order.index("decision")
    # fact must come before belief (informational edge).
    assert order.index("f1") < order.index("belief:lu:next_chaos")
    # goal must come before decision (motivational edge).
    assert order.index("goal:lu:survive") < order.index("decision")
    # permissions must come before decision (institutional edge).
    assert order.index("permissions:lu") < order.index("decision")


def test_builder_emits_physical_cause_decision_to_outcome():
    graph = CausalTraceBuilder().build(_tick())
    types = {(e.from_id, e.to_id): e.edge_type for e in graph.edges}
    assert types.get(("decision", "outcome")) == "physical_cause"


def test_builder_emits_informational_fact_to_belief():
    graph = CausalTraceBuilder().build(_tick())
    assert any(e.edge_type == "informational"
               and e.from_id == "f1"
               and e.to_id == "belief:lu:next_chaos"
               for e in graph.edges)


def test_builder_emits_epistemic_belief_to_decision():
    graph = CausalTraceBuilder().build(_tick())
    assert any(e.edge_type == "epistemic"
               and e.from_id == "belief:lu:next_chaos"
               and e.to_id == "decision"
               for e in graph.edges)


def test_builder_emits_motivational_goal_to_decision():
    graph = CausalTraceBuilder().build(_tick())
    assert any(e.edge_type == "motivational"
               and e.from_id == "goal:lu:survive"
               and e.to_id == "decision"
               for e in graph.edges)


def test_builder_emits_institutional_permission_to_decision():
    graph = CausalTraceBuilder().build(_tick())
    assert any(e.edge_type == "institutional"
               and e.from_id == "permissions:lu"
               and e.to_id == "decision"
               for e in graph.edges)


def test_builder_emits_social_influence_between_peers():
    # Two actors holding a belief trace on the same topic → peer edge.
    lu = _agent(actor_id="lu")
    su = _agent(actor_id="su")
    tick = CommittedTick(
        tick=3, actor_id="lu",
        belief_traces=[_trace(topic="next_chaos", actor_id="lu"),
                       _trace(topic="next_chaos", actor_id="su")],
        trace_owners=["lu", "su"],
        decision={"actor_id": "lu", "verb": "dehydrate", "rationale": "r"},
        outcome={"kind": "destroyed_chaos", "cause": "乱纪元"},
        canonical_facts=[{"id": "f1", "summary": "灾变"}],
        actors={"lu": lu, "su": su},
        observations={"lu": [{"fact_id": "f1"}], "su": []},
    )
    graph = CausalTraceBuilder().build(tick)
    peer_edges = [e for e in graph.edges if e.edge_type == "social_influence"]
    assert peer_edges, "expected at least one social_influence edge"
    # Each peer edge connects two distinct actors on the same topic.
    for e in peer_edges:
        assert e.from_id != e.to_id
        assert "next_chaos" in e.from_id and "next_chaos" in e.to_id


def test_builder_only_emits_valid_edge_types():
    """Every edge the builder produces must carry a type in EDGE_TYPES."""
    tick = _tick()
    graph = CausalTraceBuilder().build(tick)
    assert graph.edges, "expected a non-empty graph"
    for e in graph.edges:
        assert e.edge_type in EDGE_TYPES


# ---------------------------------------------------------------------------
# NarrativePlanner — LLM + fallback
# ---------------------------------------------------------------------------


def test_planner_fallback_without_llm_raises():
    tick = _tick()
    graph = CausalTraceBuilder().build(tick)
    planner = NarrativePlanner(llm_fn=None)
    with pytest.raises(RuntimeError, match="llm_fn is required"):
        planner.plan(graph, tick)


def test_planner_llm_returns_parsed_json():
    tick = _tick()
    graph = CausalTraceBuilder().build(tick)
    payload = {
        "cause": "乱纪元灾变",
        "mechanism": "physical_cause",
        "effect": "destroyed_chaos",
        "subjective_reason": "陆远预见灾变",
        "belief_refs": ["next_chaos"],
        "fact_refs": ["f1"],
        "confidence": 0.82,
    }

    def fake_llm(prompt: str) -> str:
        return json.dumps(payload)

    plan = NarrativePlanner(llm_fn=fake_llm).plan(graph, tick)
    assert plan.cause == "乱纪元灾变"
    assert plan.mechanism == "physical_cause"
    assert plan.effect == "destroyed_chaos"
    assert plan.subjective_reason == "陆远预见灾变"
    assert plan.confidence == pytest.approx(0.82)


def test_planner_llm_unparseable_raises():
    tick = _tick()
    graph = CausalTraceBuilder().build(tick)

    def fake_llm(prompt: str) -> str:
        return "这是叙事，不是 JSON"

    planner = NarrativePlanner(llm_fn=fake_llm)
    with pytest.raises(RuntimeError, match="failed to produce a valid plan"):
        planner.plan(graph, tick)


def test_planner_llm_raises_runtime_error():
    tick = _tick()
    graph = CausalTraceBuilder().build(tick)

    def fake_llm(prompt: str) -> str:
        raise RuntimeError("spark down")

    planner = NarrativePlanner(llm_fn=fake_llm)
    with pytest.raises(RuntimeError, match="LLM failed|spark down"):
        planner.plan(graph, tick)


# ---------------------------------------------------------------------------
# CausalValidator — the four checks
# ---------------------------------------------------------------------------


def _valid_plan(actor_id="lu", effect="destroyed_chaos"):
    return CausalPlan(
        cause="乱纪元灾变", mechanism="physical_cause", effect=effect,
        subjective_reason="预见灾变故脱水",
        belief_refs=["next_chaos"], fact_refs=["f1"],
        confidence=0.8, actor_id=actor_id,
    )


def test_validator_accepts_valid_plan():
    tick = _tick()
    res = CausalValidator().validate(_valid_plan(), tick)
    assert res.ok
    assert res.errors == []


def test_validator_rejects_belief_not_held():
    tick = _tick()
    plan = _valid_plan()
    plan.belief_refs = ["next_chaos", "secret_conspiracy"]  # 2nd not held
    res = CausalValidator().validate(plan, tick)
    assert not res.ok
    assert any("secret_conspiracy" in e for e in res.errors)


def test_validator_rejects_out_of_permission_verb():
    tick = _tick(verb="launch_missile")  # not in allowed_actions
    plan = _valid_plan()
    res = CausalValidator().validate(plan, tick)
    assert not res.ok
    assert any("launch_missile" in e for e in res.errors)


def test_validator_rejects_unknown_fact_reference():
    tick = _tick()
    plan = _valid_plan()
    plan.fact_refs = ["f1", "f_secret"]  # f_secret never observed
    res = CausalValidator().validate(plan, tick)
    assert not res.ok
    assert any("f_secret" in e for e in res.errors)


def test_validator_rejects_outcome_flip():
    """Q2 core: the LLM may not flip a destroyed outcome to survived."""
    tick = _tick(outcome_kind="destroyed_chaos")
    plan = _valid_plan(effect="survived")  # flipped!
    res = CausalValidator().validate(plan, tick)
    assert not res.ok
    assert any("outcome" in e or "effect" in e for e in res.errors)


# ---------------------------------------------------------------------------
# NarrativeRealizer
# ---------------------------------------------------------------------------


def test_realizer_without_llm_raises():
    tick = _tick()
    graph = CausalTraceBuilder().build(tick)
    plan = _valid_plan()
    with pytest.raises(RuntimeError, match="llm_fn is required"):
        NarrativeRealizer(llm_fn=None).realize(graph, plan, tick.outcome)


def test_realizer_llm_text_passes_through():
    tick = _tick()
    graph = CausalTraceBuilder().build(tick)
    plan = _valid_plan()

    def fake_llm(prompt: str) -> str:
        return "乱纪元撕裂了大地，文明在灾变中归于沉寂。"

    text = NarrativeRealizer(llm_fn=fake_llm).realize(graph, plan, tick.outcome)
    assert text == "乱纪元撕裂了大地，文明在灾变中归于沉寂。"


# ---------------------------------------------------------------------------
# End-to-end pipeline
# ---------------------------------------------------------------------------


def test_end_to_end_pipeline_without_llm_raises():
    tick = _tick()
    eng = CausalNarrativeEngine(planner_llm=None, realizer_llm=None)
    with pytest.raises(RuntimeError, match="llm_fn is required"):
        eng.narrate_tick(tick)


def test_end_to_end_pipeline_with_fake_llms():
    tick = _tick()
    plan_payload = {
        "cause": "乱纪元灾变", "mechanism": "physical_cause",
        "effect": "destroyed_chaos", "subjective_reason": "预见灾变",
        "belief_refs": ["next_chaos"], "fact_refs": ["f1"],
        "confidence": 0.9,
    }

    def planner_llm(prompt: str) -> str:
        return json.dumps(plan_payload)

    def realizer_llm(prompt: str) -> str:
        return "三颗太阳无序跃动，文明在乱纪元中覆灭。"

    eng = CausalNarrativeEngine(planner_llm=planner_llm,
                                realizer_llm=realizer_llm)
    res = eng.narrate_tick(tick)
    assert res.validation.ok
    assert res.narrative == "三颗太阳无序跃动，文明在乱纪元中覆灭。"
    assert res.plan.cause == "乱纪元灾变"


def test_engine_retries_planner_then_raises_on_invalid():
    """A planner that always cites an un-held belief → retries exhausted → raise."""
    tick = _tick()

    bad_payload = {
        "cause": "x", "mechanism": "physical_cause",
        "effect": "destroyed_chaos", "subjective_reason": "x",
        "belief_refs": ["nonexistent_belief"], "fact_refs": ["f1"],
        "confidence": 0.5,
    }

    def planner_llm(prompt: str) -> str:
        return json.dumps(bad_payload)

    eng = CausalNarrativeEngine(planner_llm=planner_llm, realizer_llm=None,
                                max_retries=1)
    with pytest.raises(RuntimeError, match="plan invalid"):
        eng.narrate_tick(tick)


# ---------------------------------------------------------------------------
# Counter-intuitive ending protection (Q2)
# ---------------------------------------------------------------------------


def test_counter_intuitive_ending_validator_does_not_reject():
    """"正确脱水却灭亡" — the civilisation did the right thing (dehydrate)
    but was destroyed anyway.  The validator must NOT reject this: the
    outcome is kernel-owned and the plan correctly echoes it."""
    tick = _tick(outcome_kind="destroyed_chaos",
                 outcome_cause="乱纪元强度超出预测",
                 verb="dehydrate",
                 decision_rationale="正确脱水备灾")
    plan = CausalPlan(
        cause="乱纪元强度超出预测", mechanism="physical_cause",
        effect="destroyed_chaos",
        subjective_reason="已按规程脱水，但灾变强度超出预测",
        belief_refs=["next_chaos"], fact_refs=["f1"],
        confidence=0.6, actor_id="lu",
    )
    res = CausalValidator().validate(plan, tick)
    assert res.ok, f"validator wrongly rejected counter-intuitive ending: {res.errors}"


def test_counter_intuitive_ending_realizer_needs_llm():
    """The realizer must raise when no llm_fn is provided."""
    tick = _tick(outcome_kind="destroyed_chaos",
                 outcome_cause="乱纪元强度超出预测",
                 verb="dehydrate", decision_rationale="正确脱水备灾")
    graph = CausalTraceBuilder().build(tick)
    plan = CausalPlan(
        cause="乱纪元强度超出预测", mechanism="physical_cause",
        effect="destroyed_chaos",
        subjective_reason="已按规程脱水",
        belief_refs=["next_chaos"], fact_refs=["f1"],
        confidence=0.6, actor_id="lu",
    )
    with pytest.raises(RuntimeError, match="llm_fn is required"):
        NarrativeRealizer(llm_fn=None).realize(graph, plan, tick.outcome)


# ---------------------------------------------------------------------------
# NLI final-consistency guard wiring
# ---------------------------------------------------------------------------


class _StubNliGuard(NliGuard):
    """An NliGuard whose backend is a programmable entailment oracle.

    Avoids real transformers / Spark: we override ``available`` and
    ``check_entailment`` directly.
    """

    def __init__(self, consistent: bool):
        super().__init__()
        self._stub_consistent = consistent
        self._stub_backend = "stub"

    def available(self) -> bool:
        return True

    def check_entailment(self, source: str, hypothesis: str):
        return {
            "forward": "entail" if self._stub_consistent else "contradict",
            "backward": "entail" if self._stub_consistent else "contradict",
            "consistent": bool(self._stub_consistent),
            "available": True,
        }


def test_nli_guard_rejects_flipped_narrative():
    tick = _tick(outcome_kind="destroyed_chaos")

    def realizer_llm(prompt: str) -> str:
        # LLM flips the destruction into survival — Q2 failure mode.
        return "文明幸存了下来，安然度过乱纪元。"

    eng = CausalNarrativeEngine(
        planner_llm=_make_good_planner_llm(), realizer_llm=realizer_llm,
        nli_guard=_StubNliGuard(consistent=False),
    )
    with pytest.raises(RuntimeError, match="consistency validation"):
        eng.narrate_tick(tick)


def test_nli_guard_accepts_consistent_narrative():
    tick = _tick(outcome_kind="destroyed_chaos")

    def realizer_llm(prompt: str) -> str:
        return "乱纪元降临，文明在灾变中覆灭，科技归零。"

    eng = CausalNarrativeEngine(
        planner_llm=_make_good_planner_llm(), realizer_llm=realizer_llm,
        nli_guard=_StubNliGuard(consistent=True),
    )
    res = eng.narrate_tick(tick)
    assert res.nli["consistent"] is True
    assert not any("NLI" in w for w in res.warnings)


# ---------------------------------------------------------------------------
# Explicit adapter lexical guard (NLI unavailable)
# ---------------------------------------------------------------------------

_TEST_OUTCOME_LEXICON = {
    "destroyed": {
        "need": ("destroyed",),
        "forbid": ("survived",),
    },
}


def test_keyword_consistent_accepts_adapter_aligned_narrative():
    assert _keyword_consistent(
        "the subject was destroyed", "destroyed", _TEST_OUTCOME_LEXICON,
    ) is True


def test_keyword_consistent_rejects_adapter_flipped_narrative():
    assert _keyword_consistent(
        "the subject survived", "destroyed", _TEST_OUTCOME_LEXICON,
    ) is False


def test_keyword_consistent_without_adapter_lexicon_is_lenient():
    assert _keyword_consistent("任何模糊叙事", "unknown_kind") is True
    assert _keyword_consistent("文明幸存，存续于三体", "destroyed_chaos") is True
