from pathlib import Path
import tempfile
import unittest

from theater.agents import DeterministicModelClient
from theater.dispatcher import TheaterOrchestrator
from theater.models import CharacterPatch, WorldBookPatch
from theater.storage import JsonStateStore


class StringWarningModelClient(DeterministicModelClient):
    def complete_json(self, role, prompt, model):
        result = super().complete_json(role, prompt, model)
        result["warnings"] = "single warning"
        return result


class UnknownIntentModelClient(DeterministicModelClient):
    def complete_json(self, role, prompt, model):
        result = super().complete_json(role, prompt, model)
        result["intent"] = "control_actor_scene"
        result["warnings"] = []
        return result


class AcceptedStubModelClient(DeterministicModelClient):
    def complete_json(self, role, prompt, model):
        result = super().complete_json(role, prompt, model)
        result["warnings"] = []
        return result


class FailingModelClient(DeterministicModelClient):
    def complete_json(self, role, prompt, model):
        raise RuntimeError("model unavailable")


class CapturingModelClient(DeterministicModelClient):
    def __init__(self):
        self.prompts = []

    def complete_json(self, role, prompt, model):
        self.prompts.append(prompt)
        return super().complete_json(role, prompt, model)


class DispatcherTests(unittest.TestCase):
    def test_every_runtime_llm_call_receives_persisted_world_context(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            client = CapturingModelClient()
            orchestrator = TheaterOrchestrator(
                state_store=JsonStateStore(root / "state", world_id="continuity"),
                model_client=client,
            )
            orchestrator.add_world_entry(
                WorldBookPatch(
                    title="上一拍",
                    content="桥梁已经坍塌",
                    source="test",
                ),
                approved_by="science_director",
            )
            orchestrator.upsert_character(
                CharacterPatch(
                    character_id="keeper",
                    name="守门人",
                    summary="守护北门",
                    source="test",
                ),
                approved_by="science_director",
            )

            orchestrator.dispatch("继续推进", session_id="continuity")

            prompt = client.prompts[-1]
            self.assertIn("已持久化的当前世界上下文", prompt)
            self.assertIn('"world_id": "continuity"', prompt)
            self.assertIn("桥梁已经坍塌", prompt)
            self.assertIn("守门人", prompt)

    def test_dispatcher_normalizes_string_warning_from_live_model(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            orchestrator = TheaterOrchestrator(
                state_store=JsonStateStore(root / "state"),
                model_client=StringWarningModelClient(),
            )

            result = orchestrator.dispatch(message="生成档案馆场景", session_id="story_warning")

            self.assertEqual(result.warnings[0], "single warning")
            self.assertNotIn("s\ni\nn", "\n".join(result.warnings))

    def test_dispatcher_exits_possession_before_matching_generic_possession_intent(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            orchestrator = TheaterOrchestrator(
                state_store=JsonStateStore(root / "state"),
                model_client=AcceptedStubModelClient(),
            )

            entered = orchestrator.dispatch(message="我要夺舍 Aster", session_id="story_possession")
            exited = orchestrator.dispatch(message="退出夺舍", session_id="story_possession")

            self.assertTrue(entered.character_updates[0].possessed)
            self.assertFalse(exited.character_updates[0].possessed)
            self.assertIsNone(exited.character_updates[0].possessed_by)

    def test_dispatcher_normalizes_unknown_live_model_intent_to_supported_contract(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            orchestrator = TheaterOrchestrator(
                state_store=JsonStateStore(root / "state"),
                model_client=UnknownIntentModelClient(),
            )

            with self.assertRaisesRegex(RuntimeError, "unsupported intent"):
                orchestrator.dispatch(
                    message="生成档案馆场景",
                    session_id="story_unknown_intent",
                )

    def test_dispatch_rejects_model_failure_before_writes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            orchestrator = TheaterOrchestrator(
                state_store=JsonStateStore(root / "state"),
                model_client=FailingModelClient(),
            )

            with self.assertRaisesRegex(RuntimeError, "generation failed"):
                orchestrator.dispatch("生成档案馆场景")
            self.assertEqual(orchestrator.state_store.snapshot().worldbook, [])

    def test_create_character_rejects_empty_description(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            orchestrator = TheaterOrchestrator(
                state_store=JsonStateStore(root / "state"),
                model_client=DeterministicModelClient(),
            )
            result = orchestrator.create_character_from_description("   ")
            self.assertFalse(result["ok"])


if __name__ == "__main__":
    unittest.main()
