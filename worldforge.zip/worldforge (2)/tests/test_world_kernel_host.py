"""Tests for backend.theater.world_kernel_host (declarative rule DSL + host).

Covers:
  - AST evaluator whitelist (rejects ``eval``, ``exec``, lambda, recursion)
  - Compiler validation (rejects contradictions, dead rules)
  - Economy world (supply→price) determinism
  - Card game world (play→score) determinism
  - add_rule is append-only (rejects duplicate rule_id)
  - Determinism (same seed → same outcome)
  - Deny-writes blacklist honored
  - Invariants checked by ``check_invariants``

Run with::

    PYTHONPATH=backend python -m pytest tests/test_world_kernel_host.py -q
"""

from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.world_kernel_host import (
    CompiledKernel,
    DENY_WRITES_DEFAULT,
    DuplicateRuleError,
    ExprEvaluator,
    ForbiddenWriteError,
    RuleCompiler,
    ValidationError,
    WorldKernelHost,
    WorldKernelSpec,
    WorldRule,
)


# =====================================================================
# AST evaluator
# =====================================================================


class TestExprEvaluator:
    def test_arith_ops(self) -> None:
        ev = ExprEvaluator(rng=None)
        state = {"a": 3, "b": 4}
        assert ev.eval({"op": "add", "args": [{"ref": "a"}, {"ref": "b"}]}, state) == 7
        assert ev.eval({"op": "sub", "args": [{"ref": "a"}, {"ref": "b"}]}, state) == -1
        assert ev.eval({"op": "mul", "args": [{"ref": "a"}, {"ref": "b"}]}, state) == 12
        assert ev.eval({"op": "div", "args": [{"ref": "b"}, {"ref": "a"}]}, state) == pytest.approx(4 / 3)
        assert ev.eval({"op": "abs", "args": [{"const": -7}]}, state) == 7
        assert ev.eval({"op": "neg", "args": [{"const": 5}]}, state) == -5
        assert ev.eval({"op": "min", "args": [{"const": 3}, {"const": 8}]}, state) == 3
        assert ev.eval({"op": "max", "args": [{"const": 3}, {"const": 8}]}, state) == 8

    def test_clamp(self) -> None:
        ev = ExprEvaluator(rng=None)
        n = {"op": "clamp", "value": {"const": 5}, "args": [{"const": 0}, {"const": 3}]}
        assert ev.eval(n, {}) == 3
        n2 = {"op": "clamp", "value": {"const": -1}, "args": [{"const": 0}, {"const": 3}]}
        assert ev.eval(n2, {}) == 0

    def test_comparison_and_logic(self) -> None:
        ev = ExprEvaluator(rng=None)
        st = {"x": 5, "y": 10}
        assert ev.eval({"op": "lt", "args": [{"ref": "x"}, {"ref": "y"}]}, st) is True
        assert ev.eval({"op": "gt", "args": [{"ref": "x"}, {"ref": "y"}]}, st) is False
        assert ev.eval({"op": "eq", "args": [{"ref": "x"}, {"const": 5}]}, st) is True
        assert ev.eval({"op": "ne", "args": [{"ref": "x"}, {"const": 5}]}, st) is False
        assert ev.eval({"op": "le", "args": [{"ref": "x"}, {"const": 5}]}, st) is True
        assert ev.eval({"op": "ge", "args": [{"ref": "x"}, {"const": 5}]}, st) is True
        assert ev.eval({"op": "and", "args": [{"const": True}, {"const": False}]}, st) is False
        assert ev.eval({"op": "or", "args": [{"const": False}, {"const": True}]}, st) is True
        assert ev.eval({"op": "not", "args": [{"const": True}]}, st) is False

    def test_lookup_via_dot_path(self) -> None:
        ev = ExprEvaluator(rng=None)
        st = {"economy": {"gold": 100, "price": 1.5}}
        assert ev.eval("economy.gold", st) == 100
        assert ev.eval({"op": "lookup", "path": "economy.price"}, st) == 1.5
        assert ev.eval("missing.path", st) is None

    def test_random_in_range_is_seeded(self) -> None:
        import random
        ev1 = ExprEvaluator(rng=random.Random(7))
        ev2 = ExprEvaluator(rng=random.Random(7))
        out1 = [ev1.eval({"op": "random_in_range",
                          "args": [{"const": 1}, {"const": 100}]}, {})
                for _ in range(5)]
        out2 = [ev2.eval({"op": "random_in_range",
                          "args": [{"const": 1}, {"const": 100}]}, {})
                for _ in range(5)]
        assert out1 == out2

    def test_eval_op_rejected(self) -> None:
        from theater.world_kernel_host import UnknownOpError
        ev = ExprEvaluator(rng=None)
        with pytest.raises(UnknownOpError):
            ev.eval({"op": "eval", "args": [{"const": 1}]}, {})

    def test_exec_op_rejected(self) -> None:
        from theater.world_kernel_host import UnknownOpError
        ev = ExprEvaluator(rng=None)
        with pytest.raises(UnknownOpError):
            ev.eval({"op": "exec", "args": [{"const": "print(1)"}]}, {})

    def test_lambda_op_rejected(self) -> None:
        from theater.world_kernel_host import UnknownOpError
        ev = ExprEvaluator(rng=None)
        with pytest.raises(UnknownOpError):
            ev.eval({"op": "lambda", "args": [{"const": 1}, {"const": 2}]}, {})

    def test_division_by_zero_rejected(self) -> None:
        from theater.world_kernel_host import DSLError
        ev = ExprEvaluator(rng=None)
        with pytest.raises(DSLError):
            ev.eval({"op": "div", "args": [{"const": 1}, {"const": 0}]}, {})

    def test_depth_cap(self) -> None:
        from theater.world_kernel_host import DSLError
        ev = ExprEvaluator(rng=None)
        # Build a 200-deep nested add — exceeds the 64 cap.
        node: dict = {"const": 1}
        for _ in range(200):
            node = {"op": "add", "args": [node, {"const": 1}]}
        with pytest.raises(DSLError):
            ev.eval(node, {})


# =====================================================================
# Compiler validation
# =====================================================================


def _good_economy_rules() -> list:
    """A small set of well-formed rules used by multiple tests."""
    return [
        WorldRule(
            rule_id="price_inflate_on_demand",
            kind="dynamic",
            trigger="trade.executed",
            condition={
                "op": "gt",
                "args": [{"ref": "economy.demand"}, {"ref": "economy.supply"}],
            },
            effect={
                "op": "writes",
                "changes": [{
                    "path": "economy.price",
                    "value": {
                        "op": "add",
                        "args": [{"ref": "economy.price"}, {"const": 0.1}],
                    },
                }],
            },
            description="demand > supply → price up",
            priority=10,
        ),
        WorldRule(
            rule_id="price_deflate_on_surplus",
            kind="dynamic",
            trigger="trade.executed",
            condition={
                "op": "lt",
                "args": [{"ref": "economy.demand"}, {"ref": "economy.supply"}],
            },
            effect={
                "op": "writes",
                "changes": [{
                    "path": "economy.price",
                    "value": {
                        "op": "sub",
                        "args": [{"ref": "economy.price"}, {"const": 0.1}],
                    },
                }],
            },
            description="supply > demand → price down",
            priority=10,
        ),
        WorldRule(
            rule_id="gold_conservation",
            kind="invariant",
            trigger=None,
            condition=None,
            effect={
                "op": "predicate",
                "expr": {
                    "op": "ge",
                    "args": [{"ref": "economy.gold"}, {"const": 0}],
                },
            },
            description="gold is non-negative",
            priority=100,
        ),
    ]


class TestRuleCompiler:
    def test_compile_good_spec(self) -> None:
        spec = WorldKernelSpec(world_type="economy", rules=_good_economy_rules())
        k = RuleCompiler(seed=42).compile(spec)
        assert isinstance(k, CompiledKernel)
        assert k.world_type == "economy"
        assert k.rule_ids() == {
            "price_inflate_on_demand",
            "price_deflate_on_surplus",
            "gold_conservation",
        }
        # priority-sorted
        assert k.rules[0].rule_id == "gold_conservation"

    def test_validate_spec_rejects_unknown_op(self) -> None:
        bad = WorldRule(
            rule_id="evil_rule",
            kind="dynamic",
            trigger="x",
            condition={"op": "eval", "args": [{"const": 1}]},
            effect={"op": "writes", "changes": []},
        )
        spec = WorldKernelSpec(world_type="x", rules=[bad])
        issues = RuleCompiler().validate_spec(spec)
        assert any("eval" in m for m in issues)

    def test_validate_spec_rejects_duplicate_id(self) -> None:
        rules = _good_economy_rules() + [_good_economy_rules()[0]]
        spec = WorldKernelSpec(world_type="x", rules=rules)
        issues = RuleCompiler().validate_spec(spec)
        assert any("duplicate" in m for m in issues)

    def test_validate_rule_rejects_invariant_with_trigger(self) -> None:
        bad = WorldRule(
            rule_id="bad_inv",
            kind="invariant",
            trigger="should_be_none",
            condition=None,
            effect={"op": "predicate", "expr": {"const": True}},
        )
        issues = RuleCompiler().validate_rule(bad)
        assert any("trigger" in m for m in issues)

    def test_validate_rule_rejects_dynamic_without_trigger(self) -> None:
        bad = WorldRule(
            rule_id="bad_dyn",
            kind="dynamic",
            trigger=None,
            condition=None,
            effect={"op": "writes", "changes": [{"path": "x",
                                                  "value": {"const": 1}}]},
        )
        issues = RuleCompiler().validate_rule(bad)
        assert any("trigger" in m for m in issues)

    def test_validate_rule_rejects_invalid_kind(self) -> None:
        bad = WorldRule(
            rule_id="x",
            kind="nonsense",
            trigger="t",
            effect={"op": "writes", "changes": [{"path": "p",
                                                  "value": {"const": 1}}]},
        )
        issues = RuleCompiler().validate_rule(bad)
        assert any("kind" in m for m in issues)

    def test_validate_rule_rejects_no_op_effect(self) -> None:
        bad = WorldRule(
            rule_id="noop",
            kind="dynamic",
            trigger="t",
            effect={
                "op": "writes",
                "changes": [{"path": "x", "value": {
                    "op": "add", "args": [{"const": 1}, {"const": 2}]}}],
            },
        )
        # This one is *not* a no-op (has const leaves), should be clean.
        issues = RuleCompiler().validate_rule(bad)
        assert not any("no-op" in m for m in issues)

        # Now genuinely empty (writes with no changes):
        bad2 = WorldRule(
            rule_id="noop2",
            kind="dynamic",
            trigger="t",
            effect={"op": "writes", "changes": []},
        )
        issues2 = RuleCompiler().validate_rule(bad2)
        assert any("no-op" in m for m in issues2)

    def test_compile_raises_on_invalid_spec(self) -> None:
        bad = WorldRule(
            rule_id="evil",
            kind="dynamic",
            trigger="x",
            condition={"op": "exec", "args": [{"const": "x"}]},
            effect={"op": "writes", "changes": [{"path": "p",
                                                  "value": {"const": 1}}]},
        )
        spec = WorldKernelSpec(world_type="x", rules=[bad])
        with pytest.raises(ValidationError):
            RuleCompiler().compile(spec)


# =====================================================================
# Economy world (supply/demand → price)
# =====================================================================


class TestEconomyWorld:
    def _host(self, state=None):
        spec = WorldKernelSpec(world_type="economy", rules=_good_economy_rules())
        s = state or {
            "economy": {"gold": 100, "supply": 50, "demand": 60, "price": 1.0},
        }
        return WorldKernelHost(spec, s, seed=42), s

    def test_price_rises_when_demand_gt_supply(self) -> None:
        host, _ = self._host()
        changes = host.step({"trigger": "trade.executed"})
        # Exactly the inflate rule fired (1 change)
        write_changes = [c for c in changes if c["path"] == "economy.price"]
        assert len(write_changes) == 1
        assert write_changes[0]["value"] == pytest.approx(1.1)
        assert host.query("economy.price") == pytest.approx(1.1)

    def test_price_falls_when_supply_gt_demand(self) -> None:
        host, _ = self._host(state={
            "economy": {"gold": 100, "supply": 80, "demand": 30, "price": 2.0},
        })
        changes = host.step({"trigger": "trade.executed"})
        write_changes = [c for c in changes if c["path"] == "economy.price"]
        assert len(write_changes) == 1
        assert write_changes[0]["value"] == pytest.approx(1.9)
        assert host.query("economy.price") == pytest.approx(1.9)

    def test_price_stable_when_balanced(self) -> None:
        host, _ = self._host(state={
            "economy": {"gold": 100, "supply": 50, "demand": 50, "price": 1.0},
        })
        changes = host.step({"trigger": "trade.executed"})
        write_changes = [c for c in changes if c["path"] == "economy.price"]
        # Neither rule fires (no lt/gt)
        assert write_changes == []
        assert host.query("economy.price") == pytest.approx(1.0)

    def test_invariant_passes_when_gold_positive(self) -> None:
        host, _ = self._host()
        failing = host.check_invariants()
        assert failing == []

    def test_invariant_flags_negative_gold(self) -> None:
        host, _ = self._host(state={
            "economy": {"gold": -1, "supply": 50, "demand": 50, "price": 1.0},
        })
        failing = host.check_invariants()
        assert "gold_conservation" in failing

    def test_determinism_same_seed(self) -> None:
        spec = WorldKernelSpec(world_type="economy", rules=_good_economy_rules())
        s1 = {"economy": {"gold": 100, "supply": 50, "demand": 60, "price": 1.0}}
        s2 = {"economy": {"gold": 100, "supply": 50, "demand": 60, "price": 1.0}}
        h1 = WorldKernelHost(spec, s1, seed=123)
        h2 = WorldKernelHost(spec, s2, seed=123)
        c1 = h1.step({"trigger": "trade.executed"})
        c2 = h2.step({"trigger": "trade.executed"})
        assert c1 == c2

    def test_multi_step_walk(self) -> None:
        host, _ = self._host()
        # 5 trade events with demand>supply → price rises by 0.1 each
        for _ in range(5):
            host.step({"trigger": "trade.executed"})
        assert host.query("economy.price") == pytest.approx(1.5)


# =====================================================================
# Card-game world (play card → score)
# =====================================================================


def _card_game_rules() -> list:
    return [
        WorldRule(
            rule_id="play_scores_high_card",
            kind="dynamic",
            trigger="card.played",
            condition={
                "op": "ge",
                "args": [{"ref": "game.last_rank"}, {"const": 11}],
            },
            effect={
                "op": "writes",
                "changes": [{
                    "path": "game.score.p1",
                    "value": {
                        "op": "add",
                        "args": [{"ref": "game.score.p1"}, {"const": 1}],
                    },
                }],
            },
            description="J/Q/K/A scored",
            priority=1,
        ),
        WorldRule(
            rule_id="invalid_play_sets_penalty",
            kind="dynamic",
            trigger="card.played",
            condition={
                "op": "lt",
                "args": [{"ref": "game.last_rank"}, {"const": 5}],
            },
            effect={
                "op": "writes",
                "changes": [{
                    "path": "game.score.p1",
                    "value": {
                        "op": "sub",
                        "args": [{"ref": "game.score.p1"}, {"const": 1}],
                    },
                }],
            },
            description="low card penalised",
            priority=1,
        ),
    ]


class TestCardGameWorld:
    def _host(self):
        spec = WorldKernelSpec(world_type="card_game", rules=_card_game_rules())
        state = {"game": {"last_rank": 13, "score": {"p1": 0, "p2": 0}}}
        return WorldKernelHost(spec, state, seed=42)

    def test_high_card_increments_score(self) -> None:
        host = self._host()
        changes = host.step({"trigger": "card.played"})
        scored = [c for c in changes if c["path"] == "game.score.p1"]
        assert len(scored) == 1
        assert scored[0]["value"] == 1
        assert host.query("game.score.p1") == 1

    def test_low_card_decrements_score(self) -> None:
        host = self._host()
        host._state["game"]["last_rank"] = 3
        changes = host.step({"trigger": "card.played"})
        scored = [c for c in changes if c["path"] == "game.score.p1"]
        assert len(scored) == 1
        assert scored[0]["value"] == -1
        assert host.query("game.score.p1") == -1

    def test_middle_card_no_effect(self) -> None:
        host = self._host()
        host._state["game"]["last_rank"] = 7
        changes = host.step({"trigger": "card.played"})
        scored = [c for c in changes if c["path"] == "game.score.p1"]
        assert scored == []
        assert host.query("game.score.p1") == 0

    def test_determinism_replay(self) -> None:
        spec = WorldKernelSpec(world_type="card_game", rules=_card_game_rules())
        s1 = {"game": {"last_rank": 13, "score": {"p1": 0, "p2": 0}}}
        s2 = {"game": {"last_rank": 13, "score": {"p1": 0, "p2": 0}}}
        h1 = WorldKernelHost(spec, s1, seed=99)
        h2 = WorldKernelHost(spec, s2, seed=99)
        c1 = h1.step({"trigger": "card.played"})
        c2 = h2.step({"trigger": "card.played"})
        assert c1 == c2


# =====================================================================
# add_rule — runtime supplement, append-only
# =====================================================================


class TestAddRule:
    def test_add_rule_accepts_new(self) -> None:
        spec = WorldKernelSpec(world_type="x", rules=[])
        host = WorldKernelHost(spec, {}, seed=0)
        new = WorldRule(
            rule_id="late_bloom",
            kind="dynamic",
            trigger="tick",
            effect={
                "op": "writes",
                "changes": [{"path": "world.age",
                              "value": {"op": "add",
                                         "args": [{"ref": "world.age"},
                                                  {"const": 1}]}}],
            },
        )
        issues = host.add_rule(new)
        assert issues == []
        host.step({"trigger": "tick"})
        assert host.query("world.age") == 1

    def test_add_rule_rejects_duplicate(self) -> None:
        spec = WorldKernelSpec(world_type="x", rules=_good_economy_rules()[:1])
        host = WorldKernelHost(spec, {"economy": {"price": 1}}, seed=0)
        dup = WorldRule(
            rule_id="price_inflate_on_demand",
            kind="dynamic",
            trigger="trade.executed",
            effect={"op": "writes",
                     "changes": [{"path": "economy.price",
                                   "value": {"const": 99}}]},
        )
        issues = host.add_rule(dup)
        assert any("duplicate" in m for m in issues)

    def test_add_rule_rejects_invalid(self) -> None:
        spec = WorldKernelSpec(world_type="x", rules=[])
        host = WorldKernelHost(spec, {}, seed=0)
        bad = WorldRule(
            rule_id="bad",
            kind="dynamic",
            trigger="t",
            condition={"op": "eval", "args": [{"const": 1}]},
            effect={"op": "writes", "changes": []},
        )
        issues = host.add_rule(bad)
        assert any("eval" in m for m in issues)

    def test_add_rule_then_step(self) -> None:
        spec = WorldKernelSpec(world_type="x", rules=[])
        host = WorldKernelHost(spec, {"counter": 0}, seed=0)
        r = WorldRule(
            rule_id="bump",
            kind="dynamic",
            trigger="bump",
            effect={
                "op": "writes",
                "changes": [{"path": "counter",
                              "value": {"op": "add",
                                         "args": [{"ref": "counter"},
                                                  {"const": 1}]}}],
            },
        )
        assert host.add_rule(r) == []
        host.step({"trigger": "bump"})
        host.step({"trigger": "bump"})
        assert host.query("counter") == 2


# =====================================================================
# Deny-writes (security — blacklisted paths)
# =====================================================================


class TestDenyWrites:
    def test_blacklisted_path_write_blocked(self) -> None:
        rule = WorldRule(
            rule_id="evil",
            kind="dynamic",
            trigger="x",
            effect={
                "op": "writes",
                "changes": [{"path": "permissions.admin",
                              "value": {"const": True}}],
            },
        )
        spec = WorldKernelSpec(world_type="x", rules=[rule])
        host = WorldKernelHost(spec, {}, seed=0)
        with pytest.raises(ForbiddenWriteError):
            host.step({"trigger": "x"})

    def test_blacklisted_sealed_solutions_blocked(self) -> None:
        rule = WorldRule(
            rule_id="evil2",
            kind="dynamic",
            trigger="x",
            effect={
                "op": "writes",
                "changes": [{"path": "sealed_solutions.answer",
                              "value": {"const": "hacked"}}],
            },
        )
        spec = WorldKernelSpec(world_type="x", rules=[rule])
        host = WorldKernelHost(spec, {}, seed=0)
        with pytest.raises(ForbiddenWriteError):
            host.step({"trigger": "x"})

    def test_normal_write_allowed(self) -> None:
        rule = WorldRule(
            rule_id="ok",
            kind="dynamic",
            trigger="x",
            effect={
                "op": "writes",
                "changes": [{"path": "world.day",
                              "value": {"const": 1}}],
            },
        )
        spec = WorldKernelSpec(world_type="x", rules=[rule])
        host = WorldKernelHost(spec, {}, seed=0)
        host.step({"trigger": "x"})
        assert host.query("world.day") == 1

    def test_default_deny_includes_world_params(self) -> None:
        assert any("world_params" in p for p in DENY_WRITES_DEFAULT)


# =====================================================================
# Whitelist enforcement via spec validation
# =====================================================================


class TestWhitelistEnforcement:
    @pytest.mark.parametrize("op_name", [
        "eval", "exec", "import", "open", "getattr", "setattr",
        "lambda", "for", "while", "__import__",
    ])
    def test_blacklisted_op_rejected_by_validator(self, op_name: str) -> None:
        bad = WorldRule(
            rule_id="bad",
            kind="dynamic",
            trigger="t",
            condition={"op": op_name, "args": [{"const": 1}, {"const": 2}]},
            effect={
                "op": "writes",
                "changes": [{"path": "p", "value": {"const": 1}}],
            },
        )
        spec = WorldKernelSpec(world_type="x", rules=[bad])
        issues = RuleCompiler().validate_spec(spec)
        assert any(op_name in m for m in issues), f"op {op_name!r} should be rejected"