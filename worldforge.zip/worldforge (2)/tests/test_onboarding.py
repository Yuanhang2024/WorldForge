"""Tests for backend.theater.onboarding.OnboardingFlow (onboarding orchestrator).

The flow sequences the 4 onboarding stages (world → characters → rules+GUI →
narrative handoff). All tests run offline with stub/fake LLM clients and a
deterministic TheaterOrchestrator — no real Spark dependency.

Run with::

    PYTHONPATH=backend python -m pytest tests/test_onboarding.py -q
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict

import pytest

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.onboarding import OnboardingFlow, load_gui_spec  # noqa: E402
from theater.settings import Settings  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402


# ---------------------------------------------------------------------------
# fixtures / helpers
# ---------------------------------------------------------------------------


_VALID_RULE_JSON = json.dumps({
    "world_type": "economy",
    "rules": [
        {
            "rule_id": "production_each_turn",
            "kind": "dynamic",
            "trigger": "turn.tick",
            "effect": {"op": "writes", "changes": [{
                "path": "supply",
                "value": {"op": "add", "args": [
                    {"ref": "supply"}, {"ref": "production_rate"}
                ]},
            }]},
            "description": "每回合按产能增加供给",
            "priority": 30,
        },
        {
            "rule_id": "gold_conservation",
            "kind": "invariant",
            "trigger": None,
            "effect": {"op": "predicate", "expr": {"op": "eq", "args": [
                {"ref": "total_gold"}, {"ref": "gold_constant"}
            ]}},
            "description": "总货币量恒定",
            "priority": 100,
        },
    ],
    "params": {"seed": 42},
    "initial_state": {
        "supply": 100, "production_rate": 8.0,
        "total_gold": 10000, "gold_constant": 10000,
    },
})

_VALID_WORLD_PARAMS = {
    "world_type": "economy",
    "seed": 42,
    "lambda": 0.5,
    "initial_state": {
        "supply": 100,
        "production_rate": 8.0,
        "total_gold": 10000,
        "gold_constant": 10000,
    },
}

_VALID_CHARACTER_CARDS_JSON = json.dumps([{
    "name": "LLM旅者",
    "personality": "沉默寡言",
    "appearance": "深色斗篷",
    "sample_line": "这条路我走过。",
}])

_VALID_GAMEPLAY_JSON = json.dumps({
    "name": "countdown",
    "description": "count down from 10",
    "state_schema": {"count": 10, "turn": 0},
    "legal_actions": [{
        "id": "dec",
        "condition": {"op": "gt", "args": [{"ref": "count"}, {"const": 0}]},
    }],
    "terminal": {"op": "or", "args": [
        {"op": "le", "args": [{"ref": "count"}, {"const": 0}]},
        {"op": "ge", "args": [{"ref": "turn"}, {"const": 50}]},
    ]},
    "payoff": {"op": "ref", "path": "turn"},
    "apply": {"dec": {"writes": [
        {"path": "count", "value": {"op": "sub", "args": [{"ref": "count"}, {"const": 1}]}},
        {"path": "turn", "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
    ]}},
})


class _FakeLLMClient:
    """A complete LLM fixture for all mandatory onboarding stages."""

    def __init__(self, rule_text: str = _VALID_RULE_JSON,
                 gui_payload: Dict[str, Any] | None = None,
                 gameplay_text: str = _VALID_GAMEPLAY_JSON):
        self._rule_text = rule_text
        self._gameplay_text = gameplay_text
        self._gui_payload = gui_payload or {
            "gui_spec_id": "llm_test",
            "world_id": "test_world",
            "layout_type": "dashboard",
            "grid": {"columns": "1fr", "areas": ["main"]},
            "widgets": [{
                "id": "readout", "type": "text", "area": "main",
                "binds": {"read": "kernel:tick"},
            }],
        }

    def as_text_fn(self, temperature=0.2, max_tokens=2048):
        def _fn(prompt: str) -> str:
            if "角色设计师" in prompt:
                return _VALID_CHARACTER_CARDS_JSON
            if "gameplay rule compiler" in prompt.lower():
                return self._gameplay_text
            return self._rule_text
        return _fn

    def as_dict_fn(self, temperature=0.4, max_tokens=2048):
        def _fn(prompt: str) -> Dict[str, Any]:
            if "世界设计架构师" in prompt:
                return dict(_VALID_WORLD_PARAMS)
            return dict(self._gui_payload)
        return _fn


class _RecordingModelClient(DeterministicModelClient):
    """Deterministic client returning a known character card (auto mode)."""

    def complete_character_card(self, description, model):
        return {
            "name": "LLM旅者",
            "summary": "LLM生成的旅者摘要",
            "personality": "沉默寡言",
            "appearance": "深色斗篷",
            "sample_line": "这条路我走过。",
            "warnings": ["deterministic stub"],
            "provider_model": model,
        }


def _build_orchestrator(root: Path) -> TheaterOrchestrator:
    settings = Settings(data_dir=root, enable_live_api=False)
    return TheaterOrchestrator(
        state_store=JsonStateStore(root / "state"),
        model_client=_RecordingModelClient(),
        settings=settings,
    )


def _gui_confirmation_draft(draft: Dict[str, Any]) -> Dict[str, Any]:
    """Adapt the editable LLM GUI draft to confirm_rules_gui's layout form."""
    confirmed = dict(draft)
    confirmed["layout"] = {
        "type": draft["layout_type"],
        "grid": draft["grid"],
    }
    return confirmed


@pytest.fixture
def tmp_root(tmp_path):
    return tmp_path


# ---------------------------------------------------------------------------
# Stage 1 — world
# ---------------------------------------------------------------------------


def test_world_creation_requires_llm(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("三体世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_world_id_is_slugified_description(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run("赛博朋克城市", characters=[], use_llm=True)
    assert result["ok"]
    assert result["world_id"] == "赛博朋克城市"


# ---------------------------------------------------------------------------
# Stage 2 — characters
# ---------------------------------------------------------------------------


def test_characters_created_via_auto_mode(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run(
        "三体世界",
        characters=[
            {"mode": "auto", "description": "一个沉默寡言的老铁匠"},
            {"mode": "manual", "fields": {"name": "阿星"}},
        ],
        use_llm=True,
    )
    chars = result["stages"]["characters"]
    assert len(chars) == 2
    assert all(c["ok"] for c in chars)
    names = {c["name"] for c in chars}
    assert "LLM旅者" in names
    assert "阿星" in names


def test_characters_string_items_use_default_mode(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run(
        "三体世界",
        characters=["一个冷酷剑客", "一位老学者"],
        use_llm=True,
        mode="auto",
    )
    chars = result["stages"]["characters"]
    assert len(chars) == 2
    assert all(c["ok"] for c in chars)


def test_skip_characters_when_empty_list(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run("三体世界", characters=[], use_llm=True)
    assert result["stages"]["characters"] == []
    assert any("no characters" in w for w in result["warnings"])
    # narrative still ready
    assert result["stages"]["narrative"]["ready"]


def test_character_failure_recorded_not_fatal(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run(
        "三体世界",
        characters=[
            {"mode": "manual", "fields": {}},  # missing name → fails
            {"mode": "manual", "fields": {"name": "阿星"}},
        ],
        use_llm=True,
    )
    chars = result["stages"]["characters"]
    assert chars[0]["ok"] is False
    assert chars[1]["ok"] is True
    assert any("character[0]" in w for w in result["warnings"])
    # flow still reaches narrative
    assert result["stages"]["narrative"]["ready"]


def test_character_card_import(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    card = {
        "character_id": "swordsman",
        "name": "导入剑客",
        "description": "一位冷酷剑客",
        "personality": "冷酷无情",
        "appearance": "黑衣长刀",
    }
    result = flow.run(
        "三体世界",
        characters=[],
        character_cards=[card],
        use_llm=True,
    )
    chars = result["stages"]["characters"]
    assert len(chars) == 1
    assert chars[0]["ok"]
    assert chars[0]["source"] == "imported_card"


# ---------------------------------------------------------------------------
# Stage 3 — rules + GUI
# ---------------------------------------------------------------------------


def test_rules_gui_llm_path(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run("一个供需经济世界", characters=[], use_llm=True)
    rules = result["stages"]["rules"]
    gui = result["stages"]["gui"]
    assert rules["source"] == "llm"
    assert rules["rules"] == 2
    assert rules["compiled"] is True
    assert rules["spec_hash"]
    assert gui["source"] == "llm"
    assert gui["widgets"] >= 1


def test_rules_gui_requires_llm(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("一个经济世界", characters=[], use_llm=False)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_stage3_fails_when_llm_unavailable(tmp_root, monkeypatch):
    # build_llm returns (None, msg) when no API key configured
    for k in ("AI_THEATER_API_KEY", "AI_THEATER_BASE_URL", "THEATER_LLM_BASE_URL"):
        monkeypatch.delenv(k, raising=False)
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run("三体世界", characters=[], use_llm=True)
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_stage3_rules_compile_failure_fails(tmp_root):
    """Malformed LLM rules fail hard; no generic rules are installed."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(rule_text="not valid json at all"),
    )
    result = flow.run("一个没有预设类型的世界", characters=[], use_llm=True)
    assert result["ok"] is False
    assert result["error_code"] == "rules_gui_generation_failed"
    assert result["stages"]["rules"]["ok"] is False


# ---------------------------------------------------------------------------
# Stage 1 worldbook import path
# ---------------------------------------------------------------------------


def test_worldbook_import_path(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    worldbook = {
        "entries": [
            {"keys": ["三体"], "content": "三体文明的秘密", "comment": "红岸基地收到的讯息"},
            {"keys": ["红岸"], "content": "红岸基地的故事", "comment": "叶文洁的工作地点"},
        ],
    }
    result = flow.run(
        "三体世界",
        characters=[],
        worldbook=worldbook,
        use_llm=True,
    )
    world = result["stages"]["world"]
    assert world["ok"]
    assert world["imported_entries"] >= 1
    # entries landed in the world's worldbook (Tavern: comment→title)
    flow.orchestrator.set_world(world["world_id"])
    entries = flow.orchestrator.state_store.snapshot().worldbook
    titles = {e.title for e in entries}
    assert "红岸基地收到的讯息" in titles
    assert "叶文洁的工作地点" in titles


# ---------------------------------------------------------------------------
# Stage 4 — narrative handoff
# ---------------------------------------------------------------------------


def test_narrative_handoff_shape(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run("三体世界", characters=[], use_llm=True)
    narrative = result["stages"]["narrative"]
    assert narrative["ready"] is True
    assert narrative["world_id"] == result["world_id"]
    assert narrative["preview"]["summary_text"]


def test_full_4_stage_flow_with_llm(tmp_root):
    """End-to-end: world + character + LLM rules/GUI + narrative ready."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    result = flow.run(
        "三体世界",
        characters=[{"mode": "manual", "fields": {"name": "叶文洁"}}],
        use_llm=True,
    )
    assert result["ok"]
    assert result["world_id"]
    assert len(result["stages"]["characters"]) == 1
    assert result["stages"]["characters"][0]["ok"]
    assert result["stages"]["rules"]["compiled"]
    assert result["stages"]["gui"]["ok"]
    assert result["stages"]["narrative"]["ready"]


def test_unconfigured_flow_rejects_creation_before_orchestrator(tmp_root):
    """The flow never creates an offline world when no LLM is configured."""
    flow = OnboardingFlow(state_root=tmp_root / "state")
    assert flow._orchestrator is None
    result = flow.run(
        "三体世界",
        characters=[{"mode": "manual", "fields": {"name": "阿星"}}],
        use_llm=False,
    )
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"
    assert flow._orchestrator is None


# ---------------------------------------------------------------------------
# Stage 4 — gameplay
# ---------------------------------------------------------------------------


def _valid_gameplay_spec_dict():
    """A GameplaySpec dict that passes all four validator gates."""
    return {
        "name": "countdown",
        "description": "count down from 10",
        "state_schema": {"count": 10, "turn": 0},
        "legal_actions": [
            {"id": "dec",
             "condition": {"op": "gt", "args": [{"ref": "count"}, {"const": 0}]}},
        ],
        "terminal": {"op": "or", "args": [
            {"op": "le", "args": [{"ref": "count"}, {"const": 0}]},
            {"op": "ge", "args": [{"ref": "turn"}, {"const": 50}]},
        ]},
        "payoff": {"op": "ref", "path": "turn"},
        "apply": {"dec": {"writes": [
            {"path": "count",
             "value": {"op": "sub", "args": [{"ref": "count"}, {"const": 1}]}},
            {"path": "turn",
             "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
        ]}},
    }


class _GameplayFakeLLMClient(_FakeLLMClient):
    """Complete onboarding fixture with a configurable gameplay response."""

    def __init__(self, gameplay_text: str | None = None):
        super().__init__(gameplay_text=gameplay_text or _VALID_GAMEPLAY_JSON)


def test_gameplay_llm_path(tmp_root):
    """LLM authors a valid GameplaySpec → stages.gameplay.source == 'llm'."""
    import json as _json
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_GameplayFakeLLMClient(_json.dumps(_valid_gameplay_spec_dict())),
    )
    result = flow.run(
        "三体世界",
        characters=[],
        use_llm=True,
        gameplay={"description": "猜数字倒数游戏", "use_llm": True},
    )
    gp = result["stages"]["gameplay"]
    assert gp["ok"] is True
    assert gp["skipped"] is False
    assert gp["source"] == "llm"
    assert gp["spec_name"] == "countdown"
    assert gp["kernel"] is None
    assert gp["validation"]["passed"] is True
    assert gp["repairs"] == 0
    assert gp["persisted"] is True


def test_gameplay_uses_llm_when_none(tmp_root):
    """The ordinary flow always generates a valid LLM gameplay spec."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_GameplayFakeLLMClient(),
    )
    result = flow.run("三体世界", characters=[], use_llm=True, gameplay=None)
    gp = result["stages"]["gameplay"]
    assert gp["ok"] is True
    assert gp["source"] == "llm"
    assert result["stages"]["narrative"]["ready"]


def test_gameplay_uses_llm_when_description_is_empty(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_GameplayFakeLLMClient(),
    )
    result = flow.run(
        "三体世界", characters=[], use_llm=True,
        gameplay={"description": "   "},
    )
    assert result["stages"]["gameplay"]["source"] == "llm"


def test_gameplay_requires_llm(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run(
        "三体世界", characters=[], use_llm=True,
        gameplay={"description": "竞价拍卖", "use_llm": True},
    )
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_gameplay_fails_when_llm_unavailable(tmp_root, monkeypatch):
    for k in ("AI_THEATER_API_KEY", "AI_THEATER_BASE_URL", "THEATER_LLM_BASE_URL"):
        monkeypatch.delenv(k, raising=False)
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.run(
        "三体世界", characters=[], use_llm=True,
        gameplay={"description": "猜数字", "use_llm": True},
    )
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_gameplay_spec_persisted_cross_instance(tmp_root):
    """GameplaySpec is written to gameplay_<world_id>.json and reloadable
    by a fresh orchestrator instance (P0 persistence pattern)."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_GameplayFakeLLMClient(),
    )
    result = flow.run(
        "三体世界", characters=[], use_llm=True,
        gameplay={"description": "竞价拍卖", "use_llm": True},
    )
    world_id = result["world_id"]
    gameplay_path = tmp_root / "state" / f"gameplay_{world_id}.json"
    assert gameplay_path.exists()

    # A fresh orchestrator instance recovers the spec on set_world.
    orch2 = _build_orchestrator(tmp_root)
    orch2.set_world(world_id)
    spec = orch2.get_gameplay_spec(world_id)
    assert spec is not None
    assert spec["name"] == "countdown"
    assert "source_kernel" not in spec["parameters"]


def test_gameplay_generation_failure_is_fatal(tmp_root):
    """A gameplay generation error records a warning but the flow still
    is fatal rather than falling back."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_GameplayFakeLLMClient(),
    )
    # Patch GameplayGenerator.generate to raise.
    import theater.onboarding as onb_mod

    class _BoomGen:
        def generate(self, *a, **kw):
            raise RuntimeError("boom")

    orig = onb_mod.__dict__
    # Monkeypatch the GameplayGenerator symbol used inside _stage_gameplay.
    import theater.gameplay_generator as gg_mod
    real_gen = gg_mod.GameplayGenerator
    gg_mod.GameplayGenerator = _BoomGen
    try:
        result = flow.run(
            "三体世界", characters=[], use_llm=True,
            gameplay={"description": "任何玩法", "use_llm": True},
        )
    finally:
        gg_mod.GameplayGenerator = real_gen
    assert result["ok"] is False
    assert result["error_code"] == "gameplay_generation_failed"


def test_gameplay_descriptions_are_llm_generated_not_preset_routed(tmp_root):
    """Different prose descriptions use the LLM output rather than presets."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_GameplayFakeLLMClient(),
    )
    card_result = flow.run(
        "三体世界", characters=[], use_llm=True,
        gameplay={"description": "打牌决胜负", "use_llm": True},
    )
    auction_result = flow.run(
        "另一个世界", characters=[], use_llm=True,
        gameplay={"description": "竞价拍卖", "use_llm": True},
    )
    card_gp = card_result["stages"]["gameplay"]
    auction_gp = auction_result["stages"]["gameplay"]
    assert card_gp["source"] == "llm"
    assert auction_gp["source"] == "llm"
    assert card_gp["kernel"] is None
    assert auction_gp["kernel"] is None
    assert card_gp["spec_name"] == auction_gp["spec_name"] == "countdown"


def test_full_5_stage_flow_with_gameplay(tmp_root):
    """End-to-end: world + character + LLM rules/GUI + gameplay + narrative."""
    import json as _json

    class _RoutingLLM:
        """Single client whose as_text_fn routes on the prompt:
        gameplay prompt → GameplaySpec JSON; else → world rules JSON."""
        def __init__(self):
            self._rules = _VALID_RULE_JSON
            self._gameplay = _json.dumps(_valid_gameplay_spec_dict())

        def as_text_fn(self, temperature=0.2, max_tokens=2048):
            def _fn(prompt: str) -> str:
                if "gameplay" in prompt.lower():
                    return self._gameplay
                return self._rules
            return _fn

        def as_dict_fn(self, temperature=0.4, max_tokens=2048):
            def _fn(world_style: str) -> Dict[str, Any]:
                return {
                    "gui_spec_id": "llm_test", "world_id": "test_world",
                    "layout_type": "dashboard",
                    "grid": {"columns": "1fr", "areas": ["main"]},
                    "widgets": [{"id": "readout", "type": "text", "area": "main",
                                 "binds": {"read": "kernel:tick"}}],
                }
            return _fn

    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_GameplayFakeLLMClient(),
    )
    result = flow.run(
        "三体世界",
        characters=[{"mode": "manual", "fields": {"name": "叶文洁"}}],
        use_llm=True,
        gameplay={"description": "猜数字倒数游戏", "use_llm": True},
    )
    assert result["ok"]
    assert result["stages"]["rules"]["compiled"]
    assert result["stages"]["gui"]["ok"]
    gp = result["stages"]["gameplay"]
    assert gp["ok"] and gp["source"] == "llm" and gp["persisted"]
    assert result["stages"]["narrative"]["ready"]


# ---------------------------------------------------------------------------
# Per-stage propose + confirm  (user-editable each step)
# ---------------------------------------------------------------------------


def test_propose_world_requires_llm(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.propose_world("赛博朋克城市")
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_propose_world_strips_model_routing_hints(tmp_root):
    """Generic onboarding cannot be redirected into a built-in adapter."""

    class _RoutingHintLLM:
        def as_dict_fn(self, temperature=0.3, max_tokens=1024):
            def _fn(prompt):
                assert "不得选择或引用任何内置世界" in prompt
                return {
                    "world_type": "model_created",
                    "seed": 7,
                    "lambda": 0.1,
                    "initial_state": {"turn": 0},
                    "enabled_kernels": ["three_body"],
                    "kernel_id": "deck",
                    "preset": "economy",
                    "adapter": "three_body",
                }
            return _fn

    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_RoutingHintLLM(),
    )
    result = flow.propose_world("从零生成的世界")
    assert result["ok"]
    assert result["source"] == "llm"
    params = result["draft"]["world_params"]
    assert params["world_type"] == "model_created"
    assert params["initial_state"] == {"turn": 0}
    for key in ("enabled_kernels", "kernel_id", "preset", "adapter"):
        assert key not in params


def test_confirm_world_creates_on_disk(tmp_root):
    """confirm_world with edited params creates the world file."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    # First propose to get a valid draft
    proposal = flow.propose_world("测试世界")
    assert proposal["ok"]
    draft = proposal["draft"]

    # User edits the draft (in this test we just pass it through)
    result = flow.confirm_world("测试世界", draft)
    assert result["ok"]
    assert result["world_id"]
    assert result["preview"]["summary_text"]
    # World state file should exist
    state_file = tmp_root / "state" / f"state_{result['world_id']}.json"
    assert state_file.exists()


def test_confirmed_drafts_do_not_activate_world_before_finalize(tmp_root):
    """Background clients must not enter a half-authored onboarding world."""
    orchestrator = _build_orchestrator(tmp_root)
    flow = OnboardingFlow(
        orchestrator=orchestrator,
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    assert orchestrator.world_id == "main"

    proposed_world = flow.propose_world("隔离中的新世界")
    world = flow.confirm_world("隔离中的新世界", proposed_world["draft"])
    world_id = world["world_id"]
    assert orchestrator.world_id == "main"

    characters = flow.propose_characters(world_id, "")
    assert flow.confirm_characters(world_id, characters["draft"])["ok"]
    assert orchestrator.world_id == "main"

    rules_gui = flow.propose_rules_gui(world_id, "")
    assert flow.confirm_rules_gui(
        world_id,
        rules_gui["draft_rules"],
        rules_gui["draft_gui"],
    )["ok"]
    assert orchestrator.world_id == "main"

    gameplay = flow.propose_gameplay(world_id, "")
    assert flow.confirm_gameplay(world_id, gameplay["draft"])["ok"]
    assert orchestrator.world_id == "main"

    assert flow.finalize(world_id)["ok"]
    assert orchestrator.world_id == world_id


def test_blank_world_description_uses_llm_world_type_as_world_id(tmp_root):
    """An internal from-scratch prompt must never leak into asset filenames."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    proposal = flow.propose_world("")
    assert proposal["ok"]
    assert proposal["draft"]["world_id"] == "economy"

    confirmed = flow.confirm_world("", {
        "world_params": proposal["draft"]["world_params"],
    })
    assert confirmed["ok"]
    assert confirmed["world_id"] == "economy"
    assert (tmp_root / "state" / "state_economy.json").exists()


def test_propose_confirm_world_round_trip(tmp_root):
    """propose → edit → confirm round-trip for world stage."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    p = flow.propose_world("星际贸易站")
    assert p["ok"]
    draft = p["draft"]

    # User edits: change seed
    draft["world_params"]["seed"] = 999

    c = flow.confirm_world("星际贸易站", draft)
    assert c["ok"]
    assert c["world_id"] == "星际贸易站"


def test_confirm_world_rejects_empty_params(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.confirm_world("空世界", {})
    assert result["ok"] is False
    assert "world_params is required" in result["error"]


def test_propose_characters_requires_llm(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.propose_characters("test_world", "一个奇幻世界", "auto")
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_confirm_characters_creates_characters(tmp_root):
    """confirm_characters creates character entities via orchestrator."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    # First create a world to get world_id
    proposal = flow.propose_world("角色测试世界")
    world = flow.confirm_world("角色测试世界", proposal["draft"])
    world_id = world["world_id"]

    # Confirm characters
    chars = [
        {"name": "阿星", "personality": "勇敢", "appearance": "蓝衣",
         "sample_line": "我来！"},
        {"name": "老李", "personality": "谨慎", "appearance": "灰袍",
         "sample_line": "等等。"},
    ]
    result = flow.confirm_characters(world_id, chars)
    assert result["ok"]
    assert len(result["characters"]) == 2
    assert all(c["ok"] for c in result["characters"])


def test_propose_rules_gui_requires_llm(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.propose_rules_gui("test_world", "一个未指定类型的世界")
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_confirm_rules_gui_with_fake_llm(tmp_root):
    """confirm_rules_gui compiles and registers user-edited rules."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    # Create a world first
    proposal_world = flow.propose_world("规则测试世界")
    world = flow.confirm_world("规则测试世界", proposal_world["draft"])
    world_id = world["world_id"]

    # Propose to get drafts
    proposal = flow.propose_rules_gui(world_id, "一个供需经济世界")
    assert proposal["ok"]
    draft_rules = proposal["draft_rules"]
    draft_gui = proposal["draft_gui"]

    # User edits (pass through in test) and confirm
    result = flow.confirm_rules_gui(
        world_id, draft_rules, _gui_confirmation_draft(draft_gui),
    )
    assert result["ok"]
    assert result["rules"]["ok"]
    assert result["rules"]["compiled"]
    assert result["rules"]["registered"] or not world_id
    assert result["gui"]["ok"]
    saved_gui_path = tmp_root / "state" / "gui_specs" / f"{world_id}.json"
    assert saved_gui_path.exists()


def test_confirm_rules_gui_invalid_rules(tmp_root):
    """confirm with malformed rules records the error."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    proposal_world = flow.propose_world("规则错误测试")
    world = flow.confirm_world("规则错误测试", proposal_world["draft"])
    world_id = world["world_id"]

    result = flow.confirm_rules_gui(world_id, {"world_type": "invalid", "rules": [], "params": {}, "initial_state": {}, "enabled_kernels": [], "deny_writes": []}, {})
    assert result["ok"] is False
    assert result["gui"]["ok"] is False


def test_propose_gameplay_requires_llm(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
    )
    result = flow.propose_gameplay("test_world", "猜数字")
    assert result["ok"] is False
    assert result["error_code"] == "llm_required"


def test_confirm_gameplay_persists(tmp_root):
    """confirm_gameplay persists the spec."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    proposal_world = flow.propose_world("玩法测试世界")
    world = flow.confirm_world("玩法测试世界", proposal_world["draft"])
    world_id = world["world_id"]

    gameplay_spec = {
        "name": "test_countdown",
        "description": "count down from 10",
        "state_schema": {"count": 10, "turn": 0},
        "legal_actions": [
            {"id": "dec",
             "condition": {"op": "gt", "args": [{"ref": "count"}, {"const": 0}]}},
        ],
        "terminal": {"op": "or", "args": [
            {"op": "le", "args": [{"ref": "count"}, {"const": 0}]},
            {"op": "ge", "args": [{"ref": "turn"}, {"const": 50}]},
        ]},
        "payoff": {"op": "ref", "path": "turn"},
        "apply": {"dec": {"writes": [
            {"path": "count",
             "value": {"op": "sub", "args": [{"ref": "count"}, {"const": 1}]}},
            {"path": "turn",
             "value": {"op": "add", "args": [{"ref": "turn"}, {"const": 1}]}},
        ]}},
        "source": "llm",
    }
    result = flow.confirm_gameplay(world_id, gameplay_spec)
    assert result["ok"]
    assert result["world_id"] == world_id


def test_finalize_requires_rules_gui_and_gameplay_confirmation(tmp_root):
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_FakeLLMClient(),
    )
    proposal = flow.propose_world("最终世界")
    world = flow.confirm_world("最终世界", proposal["draft"])
    world_id = world["world_id"]

    result = flow.finalize(world_id)
    assert result["ok"] is False
    assert result["ready"] is False
    assert result["world_id"] == world_id
    assert "rules are not confirmed" in result["error"]


def test_propose_confirm_full_fake_llm_round_trip(tmp_root):
    """End-to-end: propose all 4 stages → edit → confirm → finalize."""
    flow = OnboardingFlow(
        orchestrator=_build_orchestrator(tmp_root),
        state_root=tmp_root / "state",
        llm_client=_GameplayFakeLLMClient(),
    )

    # Stage 1: world
    p1 = flow.propose_world("一个奇幻经济世界")
    assert p1["ok"], f"propose_world failed: {p1.get('error')}"
    c1 = flow.confirm_world("一个奇幻经济世界", p1["draft"])
    assert c1["ok"]
    world_id = c1["world_id"]

    # Stage 2: characters
    p2 = flow.propose_characters(world_id, "一个奇幻经济世界", "auto")
    assert p2["ok"]
    c2 = flow.confirm_characters(world_id, p2["draft"])
    assert c2["ok"]

    # Stage 3: rules + GUI
    p3 = flow.propose_rules_gui(world_id, "一个奇幻经济世界")
    assert p3["ok"], f"propose_rules_gui failed: {p3.get('error')}"
    c3 = flow.confirm_rules_gui(
        world_id,
        p3["draft_rules"],
        _gui_confirmation_draft(p3["draft_gui"]),
    )
    assert c3["ok"]

    # Stage 4: gameplay
    p4 = flow.propose_gameplay(world_id, "一个奇幻经济世界")
    assert p4["ok"], f"propose_gameplay failed: {p4.get('error')}"
    c4 = flow.confirm_gameplay(world_id, p4["draft"])
    assert c4["ok"]

    # Stage 5: finalize only succeeds after all three confirmations.
    f = flow.finalize(world_id)
    assert f["ok"]
    assert f["ready"] is True
    assert f["world_id"] == world_id
