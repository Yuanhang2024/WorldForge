"""Tests for the dispatcher single write point (spec §I4 / §2.3).

Covers:
  - _write_point exists and is callable
  - approved → StateChange queued for commit + returns RuleResult.ok
  - needs_llm → queues async question + returns approved with needs_llm flag
  - denied → returns RuleResult.deny (caller degrades)
  - public wrappers (add_world_entry / upsert_character / upsert_object)
    route through _write_point and persist via state_store
  - on RuleEngine denial: warning is emitted + degraded direct write still
    succeeds (progressive hardening, not a hard block)
  - origin=llm_adjudication requires adjudication_ref
  - origin defaults: rule_engine for dispatcher-mediated writes
"""

from __future__ import annotations

import os
import sys
import tempfile
import warnings
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import DeterministicModelClient
from theater.dispatcher import TheaterOrchestrator
from theater.models import CharacterPatch, SceneObjectPatch, WorldBookPatch
from theater.rule_engine import RuleResult
from theater.storage import JsonStateStore
from theater.transactions import StateChange


# -- helpers -----------------------------------------------------------------


def _orch(directory: str) -> TheaterOrchestrator:
    """A minimal orchestrator against a tmp state dir."""
    root = Path(directory)
    return TheaterOrchestrator(
        state_store=JsonStateStore(root / "state"),
        model_client=DeterministicModelClient(),
    )


# -- _write_point exists ----------------------------------------------------


def test_write_point_method_exists():
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        assert hasattr(orch, "_write_point")
        assert callable(orch._write_point)


# -- approval path ----------------------------------------------------------


def test_write_point_approves_valid_change():
    """RuleEngine approves a structurally valid change → returns ok."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        change = StateChange.new(
            origin="rule_engine",
            changes=[
                {"path": "worldbook.append.title", "op": "set", "value": "x"},
                {"path": "worldbook.append.content", "op": "set", "value": "y"},
                {"path": "worldbook.append.source", "op": "set", "value": "s"},
            ],
            prerequisites_checked=["science_gate:science_director"],
        )
        result = orch._write_point(change)
        assert isinstance(result, RuleResult)
        assert result.approved is True
        assert result.needs_llm is False


def test_write_point_kernel_origin_accepted():
    """origin='kernel' with prereqs is accepted by RuleEngine."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        change = StateChange.new(
            origin="kernel",
            changes=[{"path": "civilization.tech_level", "op": "set", "value": 5}],
            prerequisites_checked=["dag:gravity_law", "kernel:baked"],
        )
        result = orch._write_point(change)
        assert result.approved is True


def test_write_point_llm_adjudication_requires_ref():
    """origin='llm_adjudication' without adjudication_ref → RuleEngine denies."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        change = StateChange.new(
            origin="llm_adjudication",
            changes=[{"path": "worldbook.append.x", "op": "set", "value": 1}],
            prerequisites_checked=["prereq:test"],
            # adjudication_ref missing → denial
        )
        result = orch._write_point(change)
        assert result.approved is False
        assert any("adjudication_ref" in r for r in result.reasons)


def test_write_point_llm_adjudication_with_ref_needs_llm():
    """origin='llm_adjudication' with valid ref → approved + needs_llm."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        # Use a semantic path that triggers the LLM-adjudication heuristic
        change = StateChange.new(
            origin="llm_adjudication",
            changes=[
                {"path": "narrative.arc", "op": "set", "value": "tragedy"},
            ],
            prerequisites_checked=["prereq:narrative"],
            adjudication_ref="llm_output_log:42",
        )
        result = orch._write_point(change)
        assert result.approved is True
        assert result.needs_llm is True
        assert result.llm_question is not None
        # queued for async
        assert any(c is change for c, _ in orch._pending_llm_adjudications)


# -- denial path: empty changes is structurally invalid --------------------


def test_write_point_denies_empty_changes():
    """Empty changes list → RuleEngine.deny with 'no entries'."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        change = StateChange.new(
            origin="rule_engine",
            changes=[],
            prerequisites_checked=["prereq:x"],
        )
        result = orch._write_point(change)
        assert result.approved is False
        assert any("no entries" in r for r in result.reasons)


def test_write_point_denies_missing_path():
    """A change dict missing 'path' → RuleEngine.deny."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        change = StateChange.new(
            origin="rule_engine",
            changes=[{"op": "set", "value": 1}],
            prerequisites_checked=["prereq:x"],
        )
        result = orch._write_point(change)
        assert result.approved is False


def test_write_point_denies_invalid_op():
    """op='fly' (not set/delete) → RuleEngine.deny."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        change = StateChange.new(
            origin="rule_engine",
            changes=[{"path": "x", "op": "fly", "value": 1}],
            prerequisites_checked=["prereq:x"],
        )
        result = orch._write_point(change)
        assert result.approved is False


# -- degraded path: warning + still writes ----------------------------------


def test_wrapper_warns_and_writes_on_denial():
    """add_world_entry with bad change → warn + still persist (degraded path)."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            # patch is valid, but the synthesized StateChange inside _write_point
            # passes; we test the degraded path by monkey-patching the change to
            # be invalid AFTER the patch is built (via StateChange.new with empty
            # changes). Simpler: directly call _write_point with a bad change,
            # then check that the wrapper falls through to direct state_store
            # write. We do that by issuing a normal wrapper call and verifying
            # the warning machinery is wired (no error if RuleEngine passes).
            ok = orch.add_world_entry(
                WorldBookPatch(title="hello", content="world", source="director"),
                approved_by="science_director",
            )
            assert ok is True
            # no denial warning on a clean write
            denial_warnings = [w for w in caught if "write_point" in str(w.message)
                               and "denied" in str(w.message)]
            assert not denial_warnings


def test_wrapper_persists_on_clean_path():
    """add_world_entry with a normal patch → persists via state_store."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        ok = orch.add_world_entry(
            WorldBookPatch(title="A", content="B", source="director"),
            approved_by="science_director",
        )
        assert ok is True
        snap = orch.state_store.snapshot()
        assert any(e.title == "A" and e.content == "B" for e in snap.worldbook)


def test_wrapper_upsert_character_persists():
    """upsert_character → persists via state_store."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        ok = orch.upsert_character(
            CharacterPatch(character_id="aster", name="Aster", summary="anchor",
                           source="director_group"),
            approved_by="science_director",
        )
        assert ok is True
        snap = orch.state_store.snapshot()
        assert any(c.character_id == "aster" and c.name == "Aster"
                   for c in snap.characters)


def test_wrapper_upsert_object_persists():
    """upsert_object → persists via state_store."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        ok = orch.upsert_object(
            SceneObjectPatch(object_id="desk", name="档案馆办公桌", state="intact"),
            approved_by="science_director",
        )
        assert ok is True
        snap = orch.state_store.snapshot()
        assert any(o.object_id == "desk" and o.name == "档案馆办公桌"
                   for o in snap.objects)


# -- denial actually triggers warning + degraded write ----------------------


def test_wrapper_degrades_when_rule_engine_denies():
    """Force RuleEngine denial via a syntactically invalid StateChange.

    We construct a valid patch but invoke the wrapper after monkey-patching
    StateChange.new to produce an invalid change. The wrapper should warn
    (denial) AND still persist the patch (degraded path).
    """
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        # monkey-patch the wrapper's StateChange.new to produce invalid change
        from theater import dispatcher as disp_mod
        from theater.transactions import StateChange as SC

        original_new = SC.new
        call_count = {"n": 0}

        def bad_new(*args, **kwargs):
            call_count["n"] += 1
            if call_count["n"] == 1:
                # produce a StateChange with empty changes (structurally invalid)
                return original_new(
                    origin="rule_engine",
                    changes=[],
                    prerequisites_checked=["prereq:fake"],
                )
            # subsequent calls (none expected, but be safe) fall through
            return original_new(*args, **kwargs)

        disp_mod.StateChange.new = bad_new
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                ok = orch.add_world_entry(
                    WorldBookPatch(title="degraded", content="fallback",
                                   source="director"),
                    approved_by="science_director",
                )
                # degraded path: still writes
                assert ok is True
                # warning was emitted
                denial = [w for w in caught
                          if "write_point" in str(w.message)
                          and "denied" in str(w.message)]
                assert denial
        finally:
            disp_mod.StateChange.new = original_new
        # verify the entry persisted despite the RuleEngine denial
        snap = orch.state_store.snapshot()
        assert any(e.title == "degraded" for e in snap.worldbook)


# -- origin default is rule_engine for dispatcher-mediated writes -----------


def test_default_origin_is_rule_engine():
    """The synthesized StateChange inside add_world_entry uses origin='rule_engine'."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        seen_origins = []
        original_write_point = orch._write_point

        def spy(state_change):
            seen_origins.append(state_change.origin)
            return original_write_point(state_change)

        orch._write_point = spy
        orch.add_world_entry(
            WorldBookPatch(title="x", content="y", source="z"),
            approved_by="science_director",
        )
        assert seen_origins == ["rule_engine"]


def test_user_action_origin_propagates():
    """The origin kwarg flows into the StateChange that _write_point sees."""
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(d)
        seen_origins = []
        original_write_point = orch._write_point

        def spy(state_change):
            seen_origins.append(state_change.origin)
            return original_write_point(state_change)

        orch._write_point = spy
        orch.upsert_character(
            CharacterPatch(character_id="c1", name="n", summary="s", source="t"),
            approved_by="science_director",
            origin="user_action",
        )
        assert seen_origins == ["user_action"]
