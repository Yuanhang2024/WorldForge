"""Tests for the save/archive manager (SaveManager)."""

from __future__ import annotations

import json
import os
import sys
import zipfile
from pathlib import Path

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

import pytest

from theater.migrations import get_default_chain
from theater.save_manager import (
    LLM_LOG_META_KEY,
    LoadResult,
    SaveManager,
    SaveResult,
)
from theater.storage import JsonStateStore


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def manager() -> SaveManager:
    return SaveManager(migration_chain=get_default_chain())


@pytest.fixture
def tmp_state_root(tmp_path) -> Path:
    """Typical layout: <tmp>/state/<state_xxx.json>."""
    state = tmp_path / "state"
    state.mkdir()
    return state


def _sample_llm_log() -> list[dict]:
    return [
        {"beat": 1, "t": 1.5, "kind": "stable", "title": "晨光",
         "narrative": "恒星平稳", "dialogue": "继续观察"},
        {"beat": 2, "t": 3.0, "kind": "chaotic", "title": "乱纪元",
         "narrative": "三体异常", "dialogue": "脱水"},
    ]


# ---------------------------------------------------------------------------
# save → zip 存在 + 含必需文件
# ---------------------------------------------------------------------------

class TestSave:
    def test_save_returns_path_and_meta(self, manager, tmp_state_root, tmp_path):
        world_id = "三体世界"
        store = JsonStateStore(tmp_state_root, world_id=world_id)
        state = store._load()
        state["characters"].append({"name": "三体一号", "character_id": "s1"})

        out = tmp_path / "save.zip"
        result = manager.save(
            world_id, out,
            world_state=state,
            llm_output_log=_sample_llm_log(),
        )

        assert isinstance(result, SaveResult)
        assert result.path == out
        assert result.world_id == world_id
        assert out.exists()
        with zipfile.ZipFile(out) as zf:
            names = set(zf.namelist())
        assert "state.json" in names
        assert "meta.json" in names
        assert "llm_log.json" in names

    def test_save_contains_only_world_state_log_and_meta(self, manager, tmp_state_root, tmp_path):
        world_id = "text_world"
        store = JsonStateStore(tmp_state_root, world_id=world_id)

        out = tmp_path / "save.zip"
        result = manager.save(
            world_id, out,
            world_state=store._load(),
        )
        assert not hasattr(result, "asset_count")
        with zipfile.ZipFile(out) as zf:
            names = set(zf.namelist())
        assert names == {"state.json", "llm_log.json", "meta.json"}

    def test_save_embeds_llm_log_in_state_meta(
        self, manager, tmp_state_root, tmp_path,
    ):
        world_id = "llm_world"
        store = JsonStateStore(tmp_state_root, world_id=world_id)
        out = tmp_path / "save.zip"
        manager.save(
            world_id, out, world_state=store._load(),
            llm_output_log=_sample_llm_log(),
        )
        with zipfile.ZipFile(out) as zf:
            state = json.loads(zf.read("state.json").decode("utf-8"))
            log = json.loads(zf.read("llm_log.json").decode("utf-8"))
        # 13.2: 日志同时进入 _meta 与独立 llm_log.json，重放读日志非重生成
        assert state["_meta"][LLM_LOG_META_KEY] == _sample_llm_log()
        assert log == _sample_llm_log()

    def test_save_meta_has_world_id_and_schema_version(
        self, manager, tmp_state_root, tmp_path,
    ):
        world_id = "meta_world"
        store = JsonStateStore(tmp_state_root, world_id=world_id)
        out = tmp_path / "save.zip"
        manager.save(world_id, out, world_state=store._load())

        with zipfile.ZipFile(out) as zf:
            state = json.loads(zf.read("state.json").decode("utf-8"))
        assert state["_meta"]["world_id"] == world_id
        assert state["_meta"]["schema_version"] >= 1


# ---------------------------------------------------------------------------
# load → 解压 + 迁移 + world_id
# ---------------------------------------------------------------------------

class TestLoad:
    def test_load_returns_world_id_and_state(
        self, manager, tmp_state_root, tmp_path,
    ):
        world_id = "load_world"
        # 先 save
        store = JsonStateStore(tmp_state_root, world_id=world_id)
        save_path = tmp_path / "save.zip"
        manager.save(world_id, save_path, world_state=store._load())

        # 模拟一个干净的目标 state_root（load 落地）
        target_root = tmp_path / "loaded_state"
        target_root.mkdir()
        result = manager.load(save_path, target_root)

        assert isinstance(result, LoadResult)
        assert result.world_id == world_id
        # state 文件落地
        assert (target_root / f"state_{world_id}.json").exists()
        # 迁移到目标 schema
        loaded = json.loads(
            (target_root / f"state_{world_id}.json").read_text(encoding="utf-8")
        )
        assert loaded["_meta"]["schema_version"] >= JsonStateStore.SCHEMA_VERSION

    def test_load_runs_migration_chain(self, manager, tmp_state_root, tmp_path):
        """存一盘 v1 state，load 应该把它升级到 SCHEMA_VERSION。"""
        world_id = "old_world"
        # 直接造一份 v1 状态
        v1_state = {
            "characters": [], "worldbook": [],
            "_meta": {"schema_version": 1, "world_id": world_id},
        }
        out = tmp_path / "v1.zip"
        manager.save(world_id, out, world_state=v1_state)

        target = tmp_path / "loaded_state"
        target.mkdir()
        result = manager.load(out, target)
        assert result.schema_version == JsonStateStore.SCHEMA_VERSION

# ---------------------------------------------------------------------------
# sandbox 标记 → load 时警告
# ---------------------------------------------------------------------------

class TestSandbox:
    def test_sandbox_load_warns(self, manager, tmp_state_root, tmp_path):
        world_id = "sandbox_world"
        state = {
            "characters": [], "worldbook": [],
            "_meta": {"schema_version": 1, "world_id": world_id,
                      "sandbox": True, "constraint_mutations": ["open_ended_time"]},
        }
        out = tmp_path / "sbx.zip"
        manager.save(world_id, out, world_state=state)

        target = tmp_path / "loaded_state"
        target.mkdir()
        result = manager.load(out, target)

        assert result.sandbox_warning is not None
        assert "sandbox" in result.sandbox_warning
        assert "正典" in result.sandbox_warning or "约束突变" in result.sandbox_warning

    def test_non_sandbox_no_warning(self, manager, tmp_state_root, tmp_path):
        world_id = "normal_world"
        store = JsonStateStore(tmp_state_root, world_id=world_id)
        out = tmp_path / "normal.zip"
        manager.save(world_id, out, world_state=store._load())

        target = tmp_path / "loaded_state"
        target.mkdir()
        result = manager.load(out, target)
        assert result.sandbox_warning is None


# ---------------------------------------------------------------------------
# list_saves
# ---------------------------------------------------------------------------

class TestListSaves:
    def test_list_empty(self, manager, tmp_state_root):
        assert manager.list_saves(tmp_state_root) == []

    def test_list_returns_each_world(self, manager, tmp_state_root):
        # 写两个 world 的 state
        for wid in ("三体世界", "奇幻世界"):
            store = JsonStateStore(tmp_state_root, world_id=wid)
            store._save({
                "worldbook": [{"title": "条目"}],
                "characters": [{"name": "X"}, {"name": "Y"}],
                "objects": [],
                "_meta": {"schema_version": 1, "world_id": wid,
                          "sandbox": False},
            })

        out = manager.list_saves(tmp_state_root)
        ids = sorted(s["world_id"] for s in out)
        assert ids == sorted(["三体世界", "奇幻世界"])
        sb = next(s for s in out if s["world_id"] == "三体世界")
        assert sb["worldbook_count"] == 1
        assert sb["characters_count"] == 2

    def test_list_main_world(self, manager, tmp_state_root):
        (tmp_state_root / "state.json").write_text(
            json.dumps({
                "worldbook": [], "characters": [], "objects": [],
                "_meta": {"schema_version": 2, "world_id": "main"},
            }, ensure_ascii=False),
            encoding="utf-8",
        )
        out = manager.list_saves(tmp_state_root)
        assert any(s["world_id"] == "main" for s in out)

    def test_list_corrupt_marked(self, manager, tmp_state_root):
        (tmp_state_root / "state_broken.json").write_text("{ not json", encoding="utf-8")
        out = manager.list_saves(tmp_state_root)
        assert out and out[0]["corrupt"] is True


# ---------------------------------------------------------------------------
# verify
# ---------------------------------------------------------------------------

class TestVerify:
    def test_verify_clean_world_returns_empty(
        self, manager, tmp_state_root, tmp_path,
    ):
        world_id = "verify_clean"
        store = JsonStateStore(tmp_state_root, world_id=world_id)
        out = tmp_path / "save.zip"
        manager.save(world_id, out, world_state=store._load())

        target = tmp_path / "loaded_state"
        target.mkdir()
        manager.load(out, target)
        problems = manager.verify(world_id, target)
        assert problems == []

    def test_verify_missing_state(self, manager, tmp_state_root):
        problems = manager.verify("ghost_world", tmp_state_root)
        assert any("缺少 state" in p for p in problems)

    def test_verify_corrupt_state(self, manager, tmp_state_root):
        (tmp_state_root / "state_broken.json").write_text(
            "{not json", encoding="utf-8",
        )
        problems = manager.verify("broken", tmp_state_root)
        assert any("JSON 损坏" in p for p in problems)

# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------

class TestDelete:
    def test_delete_removes_state(
        self, manager, tmp_state_root, tmp_path,
    ):
        world_id = "to_delete"
        store = JsonStateStore(tmp_state_root, world_id=world_id)
        out = tmp_path / "save.zip"
        manager.save(world_id, out, world_state=store._load())

        target = tmp_path / "loaded_state"
        target.mkdir()
        manager.load(out, target)
        assert (target / f"state_{world_id}.json").exists()

        ok = manager.delete(world_id, target)
        assert ok is True
        assert not (target / f"state_{world_id}.json").exists()

    def test_delete_missing_returns_false(self, manager, tmp_state_root):
        assert manager.delete("nope_world", tmp_state_root) is False


# ---------------------------------------------------------------------------
# export_readable
# ---------------------------------------------------------------------------

class TestExportReadable:
    def test_export_readable_creates_file(
        self, manager, tmp_state_root, tmp_path,
    ):
        world_id = "readable_world"
        store = JsonStateStore(tmp_state_root, world_id=world_id)
        state = store._load()
        state["characters"].append({"name": "三体一号", "summary": "恒星观察者"})
        state["worldbook"].append({"title": "纪年", "content": "三体危机纪元"})
        store._save(state)

        out = tmp_path / "history.txt"
        returned = manager.export_readable(world_id, out, state_root=tmp_state_root)
        assert returned == out
        text = out.read_text(encoding="utf-8")
        assert "三体一号" in text
        assert "WORLD STATE EXPORT" in text

    def test_export_readable_unknown_world_raises(
        self, manager, tmp_state_root, tmp_path,
    ):
        with pytest.raises(FileNotFoundError):
            manager.export_readable(
                "ghost", tmp_path / "h.txt", state_root=tmp_state_root,
            )


# ---------------------------------------------------------------------------
# Roundtrip: save → load → save → load — 不掉数据
# ---------------------------------------------------------------------------

class TestRoundtrip:
    def test_save_load_save_state_stable(
        self, manager, tmp_state_root, tmp_path,
    ):
        world_id = "rt_world"
        store = JsonStateStore(tmp_state_root, world_id=world_id)
        original = store._load()
        original["characters"].append(
            {"name": "Aria", "character_id": "aria", "summary": "吟游诗人"}
        )
        original["worldbook"].append({"title": "北境", "content": "寒冰与风雪"})

        first_zip = tmp_path / "first.zip"
        manager.save(world_id, first_zip,
                     world_state=original,
                     llm_output_log=_sample_llm_log())

        loaded_root = tmp_path / "loaded"
        loaded_root.mkdir()
        manager.load(first_zip, loaded_root)

        # 第二轮 save：从 loaded_root 读，再 save
        loaded_state = json.loads(
            (loaded_root / f"state_{world_id}.json").read_text(encoding="utf-8")
        )
        second_zip = tmp_path / "second.zip"
        manager.save(world_id, second_zip,
                     world_state=loaded_state)

        with zipfile.ZipFile(first_zip) as z1, zipfile.ZipFile(second_zip) as z2:
            s1 = json.loads(z1.read("state.json").decode("utf-8"))
            s2 = json.loads(z2.read("state.json").decode("utf-8"))
        # 同样的世界条目都要在
        assert s1["characters"] == s2["characters"]
        assert s1["worldbook"] == s2["worldbook"]
        # schema_version 也一致（迁移收敛后不动）
        assert s1["_meta"]["schema_version"] == s2["_meta"]["schema_version"]
