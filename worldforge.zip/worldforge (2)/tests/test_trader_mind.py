"""Tests for the P2 economy closed loop (spec §8 / §9.3② / §10 / §12).

Covers:
  - TraderMind implements the CognitiveModel protocol (generalisation)
  - TraderMind composes SimAgent (P1 reuse, not re-derivation)
  - TraderMind.predict: high-info accurate, low-info misprediction
  - MarketObservationFilter: the four §8 imperfection types
  - BeliefUpdateTrace: numerical, replayable, personality-weighted
  - choose_action: subjective-belief scoring + softmax (no hard if/else)
  - CausalTrace: structured belief → decision → market edges
  - minimal closed loop: observe → update → decide → market change → trace
  - the canonical user example: greedy stubborn trader, crash precursors,
    subjective "up ~72%" → buy → ruin, traceable to cognitive bias + info error

No LLM, no ambient randomness — every assertion is a pure function of its
inputs.
"""

from __future__ import annotations

import math
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.cognitive_model import Belief, CognitiveModel  # noqa: E402
from theater.observation_filter import (  # noqa: E402
    MarketObservation,
    MarketObservationFilter,
    ObservationFilter,
)
from theater.sim_agent import CharacterDefinition, WorldBinding  # noqa: E402
from theater.trader_mind import (  # noqa: E402
    ActionIntent,
    BeliefUpdateTrace,
    CausalTrace,
    TraderMind,
    TraderProfile,
    derive_trader_profile,
)


def _character(personality: str = "理性", cid: str = "t") -> CharacterDefinition:
    return CharacterDefinition(
        character_id=cid, name=cid, personality=personality,
        social_role="商人")


def _economy_state(**over):
    s = {"supply": 100, "demand": 50, "price": 1.0,
         "production_rate": 8.0, "consumption_rate": 0.5, "population": 50}
    s.update(over)
    return s


# 1. CognitiveModel protocol generalisation + P1 reuse


def test_trader_mind_is_cognitive_model():
    tm = TraderMind(_character())
    assert isinstance(tm, CognitiveModel)
    assert hasattr(tm, "predict")


def test_trader_mind_composes_simagent():
    from theater.sim_agent import SimAgent
    tm = TraderMind(_character("贪婪而固执"))
    assert isinstance(tm._sim, SimAgent)
    assert tm.character_id == tm._sim.character.character_id
    tm.predict(_economy_state(), {"seed": 1, "own_cash": 100}, t=0)
    assert "price_trend" in tm.mind_state.beliefs


def test_predict_returns_belief():
    tm = TraderMind(_character("理性"), seed=1)
    belief = tm.predict(_economy_state(), {"seed": 1, "own_cash": 100}, t=0)
    assert isinstance(belief, Belief)
    assert belief.predicted is not None
    assert -1.0 <= belief.predicted <= 1.0
    assert 0.0 <= belief.confidence <= 1.0


# 2. MarketObservationFilter — four imperfection types


def test_filter_implements_protocol():
    assert isinstance(MarketObservationFilter(), ObservationFilter)


def test_filter_own_ledger_is_exact():
    f = MarketObservationFilter()
    obs = f.observe(_economy_state(),
                    {"agent_id": "a", "t": 0,
                     "own_inventory": 3.0, "own_cash": 50.0}, seed=1)
    assert obs.field("own_inventory").imperfection == "exact"
    assert obs.field("own_cash").value == 50.0


def test_filter_aggregates_are_invisible():
    f = MarketObservationFilter()
    obs = f.observe(_economy_state(supply=999, demand=1),
                    {"agent_id": "a", "t": 0}, seed=1)
    assert obs.field("supply").imperfection == "invisible"
    assert obs.field("supply").value is None
    assert obs.field("demand").imperfection == "invisible"


def test_filter_delayed_price():
    f = MarketObservationFilter(delay_ticks=2)
    f.observe(_economy_state(price=1.0), {"agent_id": "a", "t": 0}, seed=1)
    f.observe(_economy_state(price=2.0), {"agent_id": "a", "t": 1}, seed=1)
    obs = f.observe(_economy_state(price=3.0), {"agent_id": "a", "t": 2}, seed=1)
    pf = obs.field("price")
    assert pf.imperfection == "delayed"
    assert pf.value == 1.0
    assert pf.delay == 2


def test_filter_noisy_price_deterministic():
    f = MarketObservationFilter(noise_amp=0.2)
    o1 = f.observe(_economy_state(price=1.0), {"agent_id": "a", "t": 0}, seed=7)
    f2 = MarketObservationFilter(noise_amp=0.2)
    o2 = f2.observe(_economy_state(price=1.0), {"agent_id": "a", "t": 0}, seed=7)
    assert o1.field("price").imperfection == "noisy"
    assert o1.field("price").value == o2.field("price").value
    assert o1.field("price").noise != 0.0


def test_filter_interpretation_bias_tag():
    f = MarketObservationFilter()
    obs = f.observe(_economy_state(official_claim="market_stable"),
                    {"agent_id": "a", "t": 0}, seed=1)
    cf = obs.field("official_claim")
    assert cf is not None
    assert cf.imperfection == "interpretation_bias"
    assert cf.source == "official"
    assert "stable" in cf.bias_tag


def test_filter_determinism_same_seed_same_obs():
    f = MarketObservationFilter(noise_amp=0.3, delay_ticks=0)
    state = _economy_state(price=2.5)
    binding = {"agent_id": "x", "t": 3}
    a = f.observe(state, binding, seed=42)
    b = f.observe(state, binding, seed=42)
    assert a.field("price").value == b.field("price").value
    assert a.field("price").noise == b.field("price").noise


# 3. TraderProfile — cognitive-bias derivation


def test_derive_trader_profile_greedy_stubborn():
    p = derive_trader_profile("贪婪而固执的商人")
    assert p.greed > 0.6
    assert p.stubbornness > 0.4
    assert p.official_trust > 0.5


def test_derive_trader_profile_rational_cautious():
    p = derive_trader_profile("谨慎理性的商人")
    assert p.loss_aversion > 0.5
    assert p.stubbornness < 0.3


def test_evidence_weight_disconfirming_stubborn():
    p = TraderProfile(stubbornness=1.0)
    w_confirm = p.evidence_weight_for("public_tape", confirms_prior=True)
    w_disconfirm = p.evidence_weight_for("public_tape", confirms_prior=False)
    assert w_disconfirm < w_confirm * 0.5


def test_evidence_weight_aggregate_is_zero():
    p = TraderProfile()
    assert p.evidence_weight_for("aggregate", confirms_prior=True) == 0.0


# 4. BeliefUpdateTrace — numerical, replayable, personality-weighted


def test_belief_update_numerical_and_traced():
    tm = TraderMind(_character("开放理性"), seed=1)
    tm.predict(_economy_state(price=1.0), {"seed": 1, "own_cash": 100}, t=0)
    f = MarketObservationFilter()
    obs = f.observe(_economy_state(price=1.5),
                    {"agent_id": tm.character_id, "t": 1}, seed=1)
    trace = tm.update_belief(obs)
    assert isinstance(trace, BeliefUpdateTrace)
    assert trace.posterior > trace.prior
    assert trace.evidence_signal > 0
    assert trace.rejected is False
    assert trace.evidence_weight > 0
    assert trace.personality_modifier


def test_belief_update_stubborn_rejects_disconfirming():
    tm = TraderMind(_character("固执"), seed=2)
    for i in range(3):
        tm.predict(_economy_state(price=1.0 + 0.1 * i),
                   {"seed": 2, "own_cash": 100}, t=i)
    f = MarketObservationFilter()
    obs = f.observe(_economy_state(price=0.5),
                    {"agent_id": tm.character_id, "t": 3}, seed=2)
    trace = tm.update_belief(obs)
    assert trace.evidence_signal < 0
    assert trace.evidence_weight < 1.0
    assert ("stubborn" in trace.personality_modifier
            or trace.evidence_weight < 0.7)


def test_belief_update_rate_gates_speed():
    f = MarketObservationFilter()

    def run(rate):
        tm = TraderMind(_character("开放"), seed=1)
        tm.predict(_economy_state(price=1.0), {"seed": 1, "own_cash": 100}, t=0)
        obs = f.observe(_economy_state(price=1.5),
                        {"agent_id": tm.character_id, "t": 1}, seed=1)
        return tm.update_belief(obs, belief_update_rate=rate)

    fast = run(0.9).posterior
    slow = run(0.1).posterior
    assert abs(fast) >= abs(slow)


def test_belief_update_rejected_for_invisible():
    tm = TraderMind(_character("理性"), seed=1)
    tm.predict(_economy_state(price=1.0), {"seed": 1, "own_cash": 100}, t=0)
    from theater.observation_filter import ObservationField, Observation
    obs = Observation(agent_id=tm.character_id, t=1)
    obs.fields["supply"] = ObservationField(name="supply", value=None,
                                            imperfection="invisible",
                                            source="aggregate")
    trace = tm.update_belief(obs)
    assert trace.rejected is True
    assert trace.error_source == "information_error"
    assert trace.posterior == trace.prior


# 5. choose_action — subjective scoring + softmax, no hard if/else


def test_choose_action_returns_intent():
    tm = TraderMind(_character("理性"), seed=1)
    belief = Belief(predicted=0.5, confidence=0.7)
    intent = tm.choose_action(belief, own_cash=100, current_price=1.0, seed=3)
    assert isinstance(intent, ActionIntent)
    assert intent.verb in {"buy", "sell", "hold"}
    assert intent.quantity >= 0
    assert set(intent.subjective_scores) == {"buy", "sell", "hold"}


def test_choose_action_no_hard_branching():
    tm = TraderMind(_character("贪婪"), seed=1)
    for pred in (-0.9, -0.3, 0.0, 0.3, 0.9):
        belief = Belief(predicted=pred, confidence=0.8)
        intent = tm.choose_action(belief, own_cash=100, current_price=1.0,
                                  decision_temperature=0.1, seed=1)
        assert len(intent.subjective_scores) == 3
        assert all(isinstance(v, float) for v in intent.subjective_scores.values())


def test_choose_action_bullish_leans_buy():
    tm = TraderMind(_character("贪婪"), seed=1)
    belief = Belief(predicted=0.9, confidence=0.9)
    counts = {"buy": 0, "sell": 0, "hold": 0}
    for s in range(50):
        intent = tm.choose_action(belief, own_cash=100, current_price=1.0,
                                  decision_temperature=0.3, seed=s)
        counts[intent.verb] += 1
    assert counts["buy"] > counts["sell"]
    assert counts["buy"] > counts["hold"]


def test_choose_action_bearish_leans_sell():
    tm = TraderMind(_character("谨慎"), seed=1)
    belief = Belief(predicted=-0.9, confidence=0.9)
    counts = {"buy": 0, "sell": 0, "hold": 0}
    for s in range(50):
        intent = tm.choose_action(belief, own_inventory=20, own_cash=0,
                                  current_price=1.0,
                                  decision_temperature=0.3, seed=s)
        counts[intent.verb] += 1
    assert counts["sell"] >= counts["buy"]


def test_choose_action_temperature_makes_it_impulsive():
    tm = TraderMind(_character("贪婪"), seed=1)
    belief = Belief(predicted=0.5, confidence=0.6)
    low = {"buy": 0, "sell": 0, "hold": 0}
    for s in range(60):
        low[tm.choose_action(belief, own_cash=100, current_price=1.0,
                             decision_temperature=0.05, seed=s).verb] += 1
    high = {"buy": 0, "sell": 0, "hold": 0}
    for s in range(60):
        high[tm.choose_action(belief, own_cash=100, current_price=1.0,
                              decision_temperature=5.0, seed=s).verb] += 1
    assert low["buy"] > high["buy"]
    assert high["sell"] + high["hold"] > low["sell"] + low["hold"]


def test_choose_action_pressure_raises_temperature():
    tm = TraderMind(_character("贪婪"), seed=1)
    belief = Belief(predicted=0.3, confidence=0.5)
    cool = tm.choose_action(belief, own_cash=100, current_price=1.0, seed=5)
    hot = tm.choose_action(belief, own_cash=0.0, current_price=1.0, seed=5)
    assert hot.decision_temperature > cool.decision_temperature


def test_choose_action_deterministic_same_seed():
    tm = TraderMind(_character("贪婪"), seed=1)
    belief = Belief(predicted=0.4, confidence=0.6)
    a = tm.choose_action(belief, own_cash=100, current_price=1.0, seed=99)
    b = tm.choose_action(belief, own_cash=100, current_price=1.0, seed=99)
    assert a.verb == b.verb
    assert a.quantity == b.quantity


# 6. Stable misprediction (determinism ≠ infallibility)


def test_low_info_stable_misprediction():
    for seed in (1, 2, 3):
        tm = TraderMind(_character("贪婪"), seed=seed)
        b = tm.predict(_economy_state(price=1.0),
                       {"seed": seed, "own_cash": 100}, t=0)
        assert b.predicted > 0


def test_same_seed_same_belief_and_action():
    tm1 = TraderMind(_character("贪婪而固执"), seed=7)
    tm2 = TraderMind(_character("贪婪而固执"), seed=7)
    cap = {"seed": 7, "own_cash": 100}
    b1 = tm1.predict(_economy_state(price=1.0), cap, t=0)
    b2 = tm2.predict(_economy_state(price=1.0), cap, t=0)
    assert b1.predicted == b2.predicted
    a1 = tm1.choose_action(b1, own_cash=100, current_price=1.0, seed=7)
    a2 = tm2.choose_action(b2, own_cash=100, current_price=1.0, seed=7)
    assert a1.verb == a2.verb


# 7. CausalTrace structure


def test_causal_trace_edges_and_sources():
    tm = TraderMind(_character("贪婪而固执"), seed=1)
    belief = Belief(predicted=0.5, confidence=0.7)
    intent = tm.choose_action(belief, own_cash=100, current_price=1.0, seed=1)
    upd = BeliefUpdateTrace(
        topic="price_trend", prior=0.0, prior_confidence=0.5,
        observation=1.5, source="public_tape", imperfection="noisy",
        evidence_signal=0.5, evidence_weight=0.8,
        personality_modifier="stubborn×0.30 (disconfirming) → w=0.800",
        rejected=False, posterior=0.5, posterior_confidence=0.6,
        error_source="cognitive_bias")
    trace = tm.explain_trace(
        t=1, belief_before=0.0, belief_update=upd, action=intent,
        market_before={"price": 1.0, "supply": 100, "demand": 50},
        market_after={"price": 1.2, "supply": 95, "demand": 55})
    assert isinstance(trace, CausalTrace)
    types = [e["type"] for e in trace.edges]
    assert "perception" in types
    assert "decision" in types
    assert "settlement" in types
    assert "cognitive_bias" in trace.error_sources


def test_causal_trace_irony_when_subjective_diverges():
    tm = TraderMind(_character("贪婪而固执"), seed=1)
    intent = ActionIntent(actor_id=tm.character_id, verb="buy", quantity=5,
                          rationale="", decision_temperature=0.5)
    trace = tm.explain_trace(
        t=1, belief_before=0.5, belief_update=None, action=intent,
        market_before={"price": 1.0},
        market_after={"price": 0.7})
    assert any(e["type"] == "irony" for e in trace.edges)


# 8. Minimal closed loop


def test_minimal_closed_loop_runs():
    tm = TraderMind(_character("贪婪"), seed=1)
    f = MarketObservationFilter()
    state = _economy_state(price=1.0)
    market_before = {"price": state["price"], "supply": state["supply"],
                     "demand": state["demand"]}
    b0 = tm.predict(state, {"seed": 1, "own_cash": 100, "own_inventory": 0}, t=0)
    state2 = _economy_state(price=1.2)
    obs = f.observe(state2, {"agent_id": tm.character_id, "t": 1,
                             "own_cash": 100, "own_inventory": 0}, seed=1)
    upd = tm.update_belief(obs)
    intent = tm.choose_action(upd.posterior if isinstance(upd.posterior, float)
                              else None, own_cash=100,
                              current_price=state2["price"], seed=1)
    settled_price = state2["price"] + 0.01 * intent.quantity
    market_after = {"price": settled_price,
                     "supply": state2["supply"] - intent.quantity,
                     "demand": state2["demand"]}
    trace = tm.explain_trace(
        t=1, belief_before=b0.predicted, belief_update=upd, action=intent,
        market_before=market_before, market_after=market_after)
    assert trace.action.verb in {"buy", "sell", "hold"}
    assert len(trace.edges) >= 3
    assert trace.market_after["price"] >= trace.market_before["price"] * 0.9


# 9. THE CANONICAL USER EXAMPLE


def test_canonical_greedy_stubborn_trader_ruins():
    """Greedy stubborn trader + crash precursors + user's weights →
    subjective P(up)~72% → buy → ruin, traceable to cognitive_bias +
    information_error (the hidden supply glut was invisible)."""
    profile = TraderProfile(
        greed=0.85, stubbornness=0.9,
        official_trust=0.8, rumour_trust=0.7, loss_aversion=0.2)
    profile.base.evidence_weight = 1.0
    profile.base.belief_update_rate = 0.5
    tm = TraderMind(_character("贪婪而固执"), profile=profile, seed=42)

    state = _economy_state(price=1.2, supply=500, demand=50,
                           official_claim="market_stable",
                           _next_price=0.0)
    cap = {"seed": 42, "own_cash": 1000.0, "own_inventory": 0,
           "public_tape": [{"price": 1.0}, {"price": 1.1}, {"price": 1.2}]}
    belief = tm.predict(state, cap, t=0)
    assert belief.predicted > 0, "greedy+stubborn trader commits bullish"

    f = MarketObservationFilter()
    obs = f.observe(state, {"agent_id": tm.character_id, "t": 1,
                            "own_cash": 1000.0, "own_inventory": 0,
                            "public_tape": cap["public_tape"]}, seed=42)
    upd = tm.update_belief(obs)
    p_up = 1.0 / (1.0 + math.exp(-upd.posterior))
    assert 0.65 < p_up < 0.85, (
        f"expected subjective P(up)~72%, got {p_up:.3f}; "
        f"posterior={upd.posterior:.3f}")

    intent = tm.choose_action(upd.posterior if isinstance(upd.posterior, float)
                              else None, own_cash=1000.0,
                              current_price=1.2,
                              decision_temperature=0.15, seed=42)
    assert intent.verb == "buy", (
        f"greedy bullish trader should buy; got {intent.verb} "
        f"(scores={intent.subjective_scores})")
    assert intent.quantity > 0

    settled_price = 0.0
    spent = intent.quantity * 1.2
    own_cash_after = 1000.0 - spent
    own_inventory_after = intent.quantity
    assert own_cash_after < 1000.0
    assert own_inventory_after > 0
    net_worth_after = own_cash_after + own_inventory_after * settled_price
    assert net_worth_after < 1000.0, "trader should be ruined by the crash"

    trace = tm.explain_trace(
        t=1, belief_before=0.0, belief_update=upd, action=intent,
        market_before={"price": 1.2, "supply": 500, "demand": 50},
        market_after={"price": 0.0, "supply": 500, "demand": 50})
    assert "cognitive_bias" in trace.error_sources
    assert any(e["type"] == "irony" for e in trace.edges)
    assert obs.field("supply").imperfection == "invisible"


# 10. Generalisation sanity: same protocol, different world


def test_protocol_shared_with_three_body():
    from theater.cognitive_model import ThreeBodyCognitiveModel
    tm = TraderMind(_character())

    class _StubKernel:
        pass
    tb = ThreeBodyCognitiveModel(_StubKernel())
    assert isinstance(tm, CognitiveModel)
    assert hasattr(tb, "predict")
