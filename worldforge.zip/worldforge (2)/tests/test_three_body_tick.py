"""Tests for kernel-driven / LLM-narrated three_body_tick (spec §8.2 I2).

The red line (spec §8.2): the LLM must NOT compute physics or adjudicate the
outcome — the deterministic ThreeBodyKernel decides survival / civilization
count / evacuation, those are committed with origin="kernel" through the single
transactional write point, and the LLM only turns the kernel's structured event
log into prose.

These tests inject a *stub* kernel (no slow bake) and monkeypatch the LLM
narration to a fixed string so behaviour is deterministic.
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.kernels.three_body import ThreeBodyKernel  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402


# -- stub kernel -------------------------------------------------------------

class StubKernel:
    """A deterministic stand-in for ThreeBodyKernel with scripted verdicts.

    ``verdicts`` is a list consumed one per civilization_step; each is
    ("survived"|"destroyed", next_chaos_or_None). ``evac`` fixes what
    evacuation_check returns.
    """

    def __init__(self, verdicts, evac=False):
        self._verdicts = list(verdicts)
        self._evac = evac
        self.calls = []  # (tech_level, t) recorded per step

    def civilization_step(self, tech_level, t, Delta=0.1):
        self.calls.append((tech_level, t))
        kind, next_chaos = self._verdicts.pop(0)
        # T_predict is chosen consistent with kind vs (next_chaos - t) but the
        # dispatcher only reads .kind for the verdict, so exact value is cosmetic.
        if next_chaos is None:
            t_pred = 999.0
        elif kind == "survived":
            t_pred = (next_chaos - t) + 10.0
        else:
            t_pred = max(0.0, (next_chaos - t) - 10.0)
        return ThreeBodyKernel.CivilizationEvent(
            kind=kind, tech_level=tech_level, delta_0=0.01,
            T_predict=t_pred, t=t, next_chaos=next_chaos, note="stub",
        )

    def evacuation_check(self, max_tech, Delta=0.1):
        return self._evac


def _orch(tmp: Path, kernel, narration=None):
    """Build an orchestrator with an injected kernel + patched narration."""
    orch = TheaterOrchestrator(
        state_store=JsonStateStore(tmp / "state"),
        model_client=DeterministicModelClient(),
    )
    orch._three_body_kernel = kernel  # pre-set → _ensure_ never bakes
    fixed = narration or {"title": "固定标题", "narrative": "固定叙述内容。",
                          "dialogue": "固定台词", "warnings": []}
    orch._narrate_three_body = lambda event_log, history: dict(fixed)
    return orch


# -- kernel truth is committed with origin=kernel ---------------------------

def test_survived_verdict_written_as_kernel_truth():
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d), StubKernel([("survived", 100.0)]))
        result = orch.three_body_tick(decision=2.0)
        assert result is not None
        civ = orch._three_body_civ["civilization"]
        # survived → tech accumulates (2.0 + 1.0), count unchanged, alive
        assert civ["tech_level"] == 3.0
        assert civ["count"] == 1
        assert civ["alive"] is True
        assert civ["last_event"] == "survived"
        # kernel verdict surfaced in the trace event log
        assert "civ_survived" in result.model_trace["kernel_event_log"]
        assert result.model_trace["kernel_verdict"] == "survived"


def test_destroyed_verdict_resets_tech_and_bumps_count():
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d), StubKernel([("destroyed", 5.0)]))
        result = orch.three_body_tick(decision=4.0)
        assert result is not None
        civ = orch._three_body_civ["civilization"]
        # destroyed → tech reset to 0, civilization count +1
        assert civ["tech_level"] == 0.0
        assert civ["count"] == 2
        assert civ["last_event"] == "destroyed"
        assert "civ_destroyed" in result.model_trace["kernel_event_log"]


def test_kernel_write_uses_single_transaction_point_origin_kernel(monkeypatch):
    """The civilization scalars must be committed through StateTransaction with
    a StateChange of origin='kernel' — never a bare assignment."""
    import theater.dispatcher as disp

    seen = {"begin": 0, "origins": []}
    real_apply = disp.StateTransaction.apply

    def spy_apply(self, change):
        seen["origins"].append(change.origin)
        return real_apply(self, change)

    real_begin = disp.StateTransaction.begin

    def spy_begin(self):
        seen["begin"] += 1
        return real_begin(self)

    monkeypatch.setattr(disp.StateTransaction, "apply", spy_apply)
    monkeypatch.setattr(disp.StateTransaction, "begin", spy_begin)

    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d), StubKernel([("survived", 100.0)]))
        orch.three_body_tick(decision=1.0)

    assert seen["begin"] >= 1
    assert seen["origins"] == ["kernel"]


# -- LLM only narrates; it does not change the numbers ----------------------

def test_llm_narration_does_not_alter_state_numbers():
    """Even a hostile narration that 'claims' different outcomes must not move
    the kernel-owned scalars."""
    lying = {"title": "谎言", "narrative": "文明灭绝了,科技归零,已经逃离!",
             "dialogue": "我们都死了", "warnings": []}
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d), StubKernel([("survived", 100.0)]), narration=lying)
        result = orch.three_body_tick(decision=2.0)
        civ = orch._three_body_civ["civilization"]
        # kernel said survived → numbers reflect survival regardless of prose
        assert civ["tech_level"] == 3.0
        assert civ["alive"] is True
        assert civ["evacuated"] is False
        # the prose IS stored (as story), but only as narration
        beat = next(e for e in result.world_updates
                    if e.source == "three_body_kernel_narration")
        assert beat.content == lying["narrative"]
        # llm output is logged separately as discardable audit
        assert orch._three_body_llm_log[-1]["narrative"] == lying["narrative"]


def test_empty_llm_narration_fails_explicitly():
    empty = {"title": "", "narrative": "", "dialogue": "", "warnings": ["llm down"]}
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d), StubKernel([("survived", 100.0)]), narration=empty)
        with pytest.raises(RuntimeError, match="empty prose"):
            orch.three_body_tick(decision=1.0)


# -- evacuation proof is written when the kernel proves it ------------------

def test_evacuation_proof_writes_worldbook_decision():
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d), StubKernel([("survived", 100.0)], evac=True))
        result = orch.three_body_tick(decision=2.0)
        civ = orch._three_body_civ["civilization"]
        assert civ["evacuated"] is True
        assert result.model_trace["evacuation_proven"] is True
        # a proven-evacuation worldbook fact is written
        evac = [e for e in result.world_updates
                if e.source == "three_body_kernel_evacuation"]
        assert len(evac) == 1
        assert "逃离三体星系" in evac[0].title
        assert "science_director" == evac[0].approved_by


def test_no_evacuation_when_not_proven():
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d), StubKernel([("survived", 100.0)], evac=False))
        result = orch.three_body_tick(decision=2.0)
        assert orch._three_body_civ["civilization"]["evacuated"] is False
        assert not [e for e in result.world_updates
                    if e.source == "three_body_kernel_evacuation"]


def test_evacuation_written_only_once():
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d),
                     StubKernel([("survived", 100.0), ("survived", 200.0)], evac=True))
        r1 = orch.three_body_tick(decision=2.0)
        r2 = orch.three_body_tick(decision=2.0)
        evac1 = [e for e in r1.world_updates if e.source == "three_body_kernel_evacuation"]
        evac2 = [e for e in r2.world_updates if e.source == "three_body_kernel_evacuation"]
        assert len(evac1) == 1
        assert len(evac2) == 0  # not repeated on the second beat


# -- decision vector resolution ---------------------------------------------

def test_decision_resource_dict_sums_to_tech_proxy():
    with tempfile.TemporaryDirectory() as d:
        kernel = StubKernel([("survived", 100.0)])
        orch = _orch(Path(d), kernel)
        orch.three_body_tick(decision={"resources": {"iron": 2, "energy": 3}})
        # kernel was fed tech_level = 2 + 3 = 5
        assert kernel.calls[0][0] == 5.0


def test_decision_none_carries_stored_tech_forward():
    with tempfile.TemporaryDirectory() as d:
        kernel = StubKernel([("survived", 100.0), ("survived", 200.0)])
        orch = _orch(Path(d), kernel)
        orch.three_body_tick(decision=3.0)   # survives → stored tech = 4.0
        orch.three_body_tick(decision=None)  # carry 4.0 forward
        assert kernel.calls[1][0] == 4.0


# -- THREE_BODY_STAGES prose crutch is gone ---------------------------------

def test_three_body_stages_prose_removed():
    assert not hasattr(TheaterOrchestrator, "THREE_BODY_STAGES")


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-q"]))
