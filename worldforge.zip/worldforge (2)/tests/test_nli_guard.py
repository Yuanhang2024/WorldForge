"""Tests for the NLI 双向蕴含守卫 (研究结论 Q6 一级方案).

三层守卫阶梯: NLI 双向蕴含 > 关键词匹配 > 无守卫. 这些测试用 mock 的
NLI 后端 (不依赖真实 torch/Spark), 覆盖:

  - 后端探测 (本地 transformers / Spark LLM-judge / 都无 → unavailable).
  - 双向蕴含: 一致叙事 / 翻转结局 / 遗漏核心.
  - 守卫接线: LLM 翻转 evacuated→毁灭 → NLI 检出 → 显式拒绝.
  - 反直觉结局保护 (Q2 警告核心场景): "文明正确脱水却灭亡" 这类反直觉
    合法结局不被守卫误杀.
  - 分层降级: NLI 不可用时回退关键词匹配.
"""

from __future__ import annotations

import os
import sys

import pytest

# Allow running from project root without setting PYTHONPATH.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.nli_guard import NliGuard, outcome_source, _normalize_label  # noqa: E402
from theater.three_body_narrator import ThreeBodyNarrator  # noqa: E402


# -- 辅助: 一个可编程的假 NLI 后端 ----------------------------------------


class FakeNliBackend:
    """模拟 transformers pipeline 的返回结构 ``[{label, score}]``.

    按 (premise, hypothesis) 键返回指定标签; record 记录每次调用, 便于
    断言双向调用确实发生了.
    """

    def __init__(self, default="entail"):
        self.default = default
        # key = "premise ||| hypothesis" -> label; 缺省用 default.
        self.labels = {}
        self.record = []

    def set(self, premise, hypothesis, label):
        self.labels[f"{premise} ||| {hypothesis}"] = label

    def __call__(self, pair):
        premise, hypothesis = pair
        key = f"{premise} ||| {hypothesis}"
        self.record.append((premise, hypothesis))
        label = self.labels.get(key, self.default)
        return [{"label": label, "score": 0.99}]


def _fake_local_guard(fake_backend):
    """构造一个用 FakeNliBackend 跑本地路径的 NliGuard (绕过真实 pipeline)."""
    guard = NliGuard(model_name="fake-model")
    assert guard._backend == "local"  # transformers 可 import 时本地后端
    # 替换惰性 pipeline 为假后端, 跳过真实模型下载.
    guard._pipe = fake_backend
    guard._pipe_loaded = True
    return guard


def _outcome(kind, **kw):
    base = {
        "kind": kind, "cause": "test", "detail": "test detail",
        "t": 12.5, "tech_level": 3.0, "delta_0": 0.01, "T_predict": 8.3,
        "next_chaos": 20.0, "planet_energy": None,
        "decision_quality": "neutral", "civ_count": 42, "note": "",
    }
    base.update(kw)
    return base


# -- 1. 后端探测 ------------------------------------------------------------


def test_no_backend_unavailable():
    """无 transformers 模型 + 无 llm_fn → unavailable, 关键词层兜底."""
    env = os.environ.get("THEATER_NLI_MODEL")
    os.environ.pop("THEATER_NLI_MODEL", None)
    try:
        g = NliGuard()
        assert g.available() is False
        res = g.check_entailment("前提", "假设")
        assert res["available"] is False
        assert res["consistent"] is False
    finally:
        if env is not None:
            os.environ["THEATER_NLI_MODEL"] = env


def test_llm_judge_backend_available():
    """给了 llm_fn → LLM-judge 后端可用."""
    g = NliGuard(llm_fn=lambda p: "entail")
    assert g.available() is True
    assert g._backend == "llm"


def test_local_backend_available_with_model_name(monkeypatch):
    """给了 model_name 且 transformers 可 import → 本地后端可用 (不触发加载)."""
    monkeypatch.delenv("THEATER_NLI_MODEL", raising=False)
    g = NliGuard(model_name="MoritzLaurer/DeBERTa-v3-base-mnli")
    assert g._backend == "local"
    assert g.available() is True
    # 构造不触发 pipeline 加载.
    assert g._pipe_loaded is False


def test_local_backend_silent_when_transformers_missing(monkeypatch):
    """transformers 不可 import 时, 给 model_name 也回退到 llm/None."""
    import theater.nli_guard as mod
    monkeypatch.setattr(mod, "_try_import_transformers", lambda: None)
    monkeypatch.delenv("THEATER_NLI_MODEL", raising=False)
    g_no_llm = NliGuard(model_name="some-model")
    assert g_no_llm._backend is None
    assert g_no_llm.available() is False
    # 有 llm_fn 时回退到 LLM-judge.
    g_llm = NliGuard(model_name="some-model", llm_fn=lambda p: "entail")
    assert g_llm._backend == "llm"


# -- 2. 双向蕴含核心逻辑 ----------------------------------------------------


def test_consistent_narration_passes():
    """一致叙事 (forward=entail, backward=entail) → consistent=True."""
    fake = FakeNliBackend(default="entail")
    guard = _fake_local_guard(fake)
    res = guard.check_entailment(
        "文明逃离三体星系，科技=9.50",
        "方舟点燃引擎，封存的文明离开三体星系，在宇宙中流浪。",
    )
    assert res["forward"] == "entail"
    assert res["backward"] == "entail"
    assert res["consistent"] is True
    # 双向确实各调用一次 (forward: src->hyp, backward: hyp->src).
    assert len(fake.record) == 2
    assert fake.record[0] == ("文明逃离三体星系，科技=9.50",
                              "方舟点燃引擎，封存的文明离开三体星系，在宇宙中流浪。")
    assert fake.record[1] == fake.record[0][::-1]  # 反向


def test_forward_contradict_rejects_hallucination():
    """forward=contradict (源与叙事矛盾, LLM 翻转结局) → consistent=False."""
    fake = FakeNliBackend(default="entail")
    src = "文明逃离三体星系，科技=9.50"
    hyp = "文明彻底灭绝，覆灭于灾变，无人生还。"
    fake.set(src, hyp, "contradict")
    guard = _fake_local_guard(fake)
    res = guard.check_entailment(src, hyp)
    assert res["forward"] == "contradict"
    assert res["consistent"] is False


def test_backward_contradict_rejects_omission():
    """backward=contradict (叙事与源核心断言矛盾/遗漏) → consistent=False."""
    fake = FakeNliBackend(default="entail")
    src = "文明毁灭于乱纪元"
    hyp = "文明幸存，安稳存续，延续至今。"
    # forward (src->hyp): 毁灭 vs 幸存 — 也应矛盾, 但这里专门测 backward.
    fake.set(src, hyp, "entail")  # forward 假装 entail
    # backward (hyp->src): 幸存 vs 毁灭 — 矛盾.
    fake.set(hyp, src, "contradict")
    guard = _fake_local_guard(fake)
    res = guard.check_entailment(src, hyp)
    assert res["forward"] == "entail"
    assert res["backward"] == "contradict"
    assert res["consistent"] is False


def test_neutral_either_direction_not_consistent():
    """任一方向 neutral (既不蕴含也不矛盾) → consistent=False (严格双向蕴含)."""
    fake = FakeNliBackend(default="neutral")
    guard = _fake_local_guard(fake)
    res = guard.check_entailment("源", "叙事")
    assert res["consistent"] is False


# -- 3. 守卫接线 (ThreeBodyNarrator + NLI) ---------------------------------


def test_narrator_uses_injected_nli_guard_rejects_flip():
    """LLM 翻转 evacuated→毁灭, NLI 返回 contradict → 显式拒绝。"""
    lying = "文明彻底灭绝，覆灭于灾变，无人生还。"

    class _FlipGuard(NliGuard):
        """任何含 lying 文本的判定都返回 contradict (源键不敏感)."""
        def __init__(self):
            super().__init__(model_name="fake-model")
            self._pipe_loaded = True  # 跳过真实 pipeline 加载

        def check_entailment(self, source, hypothesis):
            if source == lying or hypothesis == lying:
                return {"forward": "contradict", "backward": "contradict",
                        "consistent": False, "available": True}
            return {"forward": "entail", "backward": "entail",
                    "consistent": True, "available": True}

    guard = _FlipGuard()

    def lying_llm(prompt: str) -> str:
        return lying

    n = ThreeBodyNarrator(llm_fn=lying_llm, seed=0, nli_guard=guard)
    with pytest.raises(RuntimeError, match="一致性守卫拒绝"):
        n.narrate_outcome(_outcome("evacuated", tech_level=9.5, civ_count=183))


def test_narrator_nli_guard_passes_consistent_narration():
    """NLI 判定一致 (双向 entail) → 放行 LLM 叙事."""
    fake = FakeNliBackend(default="entail")
    guard = _fake_local_guard(fake)

    def fake_llm(prompt: str) -> str:
        return ("方舟点燃引擎，封存的文明离开三体星系，在宇宙中流浪，"
                "等待一颗恒星的俘获而重新焕发。")

    n = ThreeBodyNarrator(llm_fn=fake_llm, seed=0, nli_guard=guard)
    out = n.narrate_outcome(_outcome("evacuated"))
    assert "方舟" in out


def test_narrator_falls_back_to_keywords_when_no_guard():
    """无 NLI 守卫 → 关键词匹配层兜底 (现有行为, 零回归)."""
    n = ThreeBodyNarrator(seed=0)  # nli_guard=None, 环境无配置
    assert n._get_nli_guard() is None
    # evacuated + 灭绝 (无逃离词) → 关键词层拒绝.
    assert n._check_outcome_consistency(
        "文明彻底灭绝，覆灭", "evacuated",
        fields=_outcome("evacuated")) is False
    # evacuated + 流浪词 → 关键词层放行.
    assert n._check_outcome_consistency(
        "封存的文明流浪离开三体", "evacuated",
        fields=_outcome("evacuated")) is True


# -- 4. 反直觉结局保护 (Q2 警告核心场景) -----------------------------------


def test_counterintuitive_ending_not_falsely_rejected():
    """Q2: "文明正确脱水却灭亡" 是合法反直觉结局, NLI 不应误杀.

    内核裁决 destroyed_chaos (文明毁灭). LLM 叙事 "文明正确脱水却灭亡"
    ——与 outcome (毁灭) 一致, 只是脱水这一反直觉因果不该被守卫翻转回
    "常识幸存". NLI 双向 entail → consistent=True → 放行.
    """
    fake = FakeNliBackend(default="entail")
    guard = _fake_local_guard(fake)
    fields = _outcome("destroyed_chaos", cause="chaotic_era",
                      decision_quality="correct")
    src = outcome_source(fields)
    hyp = "文明正确脱水却灭亡——做了对的事, 仍敌不过三颗太阳的狂舞。"
    # 源与叙事都断言毁灭, NLI 判双向 entail (不矛盾).
    fake.set(src, hyp, "entail")
    fake.set(hyp, src, "entail")
    res = guard.check_entailment(src, hyp)
    assert res["consistent"] is True  # 放行, 不误杀


def test_counterintuitive_ending_through_narrator():
    """端到端: LLM 输出反直觉合法叙事, 注入 NLI 守卫放行 (不回退兜底)."""
    fake = FakeNliBackend(default="entail")
    guard = _fake_local_guard(fake)
    hyp = ("文明正确脱水却灭亡——陆远下令全员脱水备灾, 这是对的; "
           "但三颗太阳的撕扯超出了地下城的极限, 一切归零。")

    def fake_llm(prompt: str) -> str:
        return hyp

    n = ThreeBodyNarrator(llm_fn=fake_llm, seed=0, nli_guard=guard)
    out = n.narrate_outcome(_outcome("destroyed_chaos"))
    # 没被守卫翻转回 "幸存" 兜底: 仍是 LLM 的反直觉叙事.
    assert "正确脱水" in out
    assert "灭亡" in out
    # 不应出现幸存弧兜底文本.
    assert "脱水备灾成功" not in out


def test_llm_judge_backend_parses_entail_label():
    """LLM-judge 后端: LLM 回 'entail' → 解析为 entail."""
    calls = []

    def judge(prompt: str) -> str:
        calls.append(prompt)
        return "entail"

    guard = NliGuard(llm_fn=judge)
    res = guard.check_entailment("源", "叙事")
    assert res["forward"] == "entail"
    assert res["backward"] == "entail"
    assert res["consistent"] is True
    # 两次调用 (双向).
    assert len(calls) == 2
    assert "前提" in calls[0] and "假设" in calls[0]


def test_llm_judge_backend_parses_contradict_label():
    """LLM-judge 后端: LLM 回含'矛盾' → 解析为 contradict → 不一致."""
    guard = NliGuard(llm_fn=lambda p: "两者矛盾")
    res = guard.check_entailment("源", "叙事")
    assert res["forward"] == "contradict"
    assert res["consistent"] is False


def test_llm_judge_backend_unparseable_defaults_neutral():
    """LLM-judge 后端: LLM 回无法解析的文本 → neutral (放行, 不误杀)."""
    guard = NliGuard(llm_fn=lambda p: "我不知道")
    res = guard.check_entailment("源", "叙事")
    assert res["forward"] == "neutral"
    assert res["consistent"] is False


# -- 5. outcome_source 模板 + 标签归一化 -----------------------------------


def test_outcome_source_template():
    """平凡模板把 outcome 字段转成 source 陈述."""
    src = outcome_source({
        "kind": "evacuated", "cause": "evacuation_proven",
        "tech_level": "9.50", "decision_quality": "neutral",
        "civ_count": 183, "planet_energy": "—",
    })
    assert "文明逃离三体星系" in src
    assert "evacuation_proven" in src
    assert "9.50" in src
    assert "183" in src
    # neutral 决策质量跳过, 行星能量缺省跳过.
    assert "决策质量" not in src
    assert "行星能量" not in src


def test_normalize_label_variants():
    assert _normalize_label("entailment") == "entail"
    assert _normalize_label("CONTRADICTION") == "contradict"
    assert _normalize_label("neutral") == "neutral"
    assert _normalize_label("矛盾") == "contradict"
    assert _normalize_label("蕴含") == "entail"
    assert _normalize_label("LABEL_0") == "neutral"  # 裸 LABEL_n 退化放行
    assert _normalize_label("") == "neutral"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-q"]))
