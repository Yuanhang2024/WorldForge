"""Tests for AgentMind → tick runtime wiring (architecture spec §4.2 / §8 / §14).

The AgentMind stack (SimAgent / belief_update / three_body_agents /
causal_narrative / observation_filter) was built but not connected to the
tick.  These tests exercise the surgical wiring added to ``dispatcher.py``:

- ``world_tick`` runs the registered SimAgents' observe→update_belief→
  choose_action cycle and routes their ActionIntents through the single
  write point (§12).
- ``three_body_tick`` runs the multi-scale sim (scientist→org→civilisation)
  and feeds the ``decision_vector`` to the kernel; the §5 distrust example
  drives the kernel to ``destroyed_decision``.
- The two-stage causal narrative (§14) runs over a tick's belief traces.
- Everything is backward compatible: with the flags off (the default) the
  ticks degrade to the existing pure kernel+LLM-narration behaviour.

No live Spark / LLM — every semantic stage uses explicit fakes or stubs.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import DeterministicModelClient  # noqa: E402
from theater.character_graph import CharacterGraph, Organization  # noqa: E402
from theater.dispatcher import AgentMindBinding, TheaterOrchestrator  # noqa: E402
from theater.kernels.three_body import ThreeBodyKernel  # noqa: E402
from theater.settings import Settings  # noqa: E402
from theater.sim_agent import (  # noqa: E402
    CharacterDefinition,
    SimAgent,
    WorldBinding,
)
from theater.storage import JsonStateStore  # noqa: E402
from theater.three_body_agents import (  # noqa: E402
    CivilizationAgent,
    DecisionBody,
    MultiScaleThreeBodySim,
    PLAN_DEHYDRATE,
    PLAN_EVACUATE,
    PLAN_PERSIST,
    PLAN_TO_DECISION_VECTOR,
    ScientistAgent,
)
from theater.causal_narrative import (  # noqa: E402
    CausalNarrativeEngine,
    CommittedTick,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _orch(
    tmp: Path, *, enable_agent_mind: bool = False,
) -> TheaterOrchestrator:
    settings = Settings(
        data_dir=tmp / "runtime",
        enable_agent_mind=enable_agent_mind,
    )
    class _AcceptedDirector(DeterministicModelClient):
        def complete_json(self, role, prompt, model):
            result = super().complete_json(role, prompt, model)
            result["warnings"] = []
            return result

    orchestrator = TheaterOrchestrator(
        state_store=JsonStateStore(tmp / "state"),
        model_client=_AcceptedDirector(),
        settings=settings,
    )
    if enable_agent_mind:
        def _fake_plan(_prompt: str) -> str:
            return json.dumps({
                "cause": "observed world change",
                "mechanism": "informational",
                "effect": "unspecified",
                "subjective_reason": "acted on current beliefs",
                "belief_refs": ["price"],
                "fact_refs": [],
                "confidence": 0.7,
            })

        orchestrator.attach_causal_narrative_engine(
            CausalNarrativeEngine(
                planner_llm=_fake_plan,
                realizer_llm=lambda _prompt: "The agent acted on the observed change.",
            )
        )
    return orchestrator


class _PriceFilter:
    """Minimal ObservationFilter stub: projects a price from true_state."""

    def observe(self, true_state: Dict[str, Any],
                agent_binding: Dict[str, Any]) -> Dict[str, Any]:
        price = true_state.get("price", 10.0)
        return {"price": float(price), "filter_flags": ["exact"]}


def _make_sim_agent(cid: str = "trader_a", personality: str = "理性冷静") -> SimAgent:
    char = CharacterDefinition(
        character_id=cid, name=cid, personality=personality,
    )
    binding = WorldBinding(
        world_id="market",
        permissions={"allowed_actions": ["buy", "sell", "wait"]},
    )
    return SimAgent(character=char, world_binding=binding)


def _market_binding(agent: SimAgent, *, topic: str = "price",
                    candidates: Optional[List[Dict[str, Any]]] = None,
                    ) -> AgentMindBinding:
    return AgentMindBinding(
        agent=agent,
        observation_filter=_PriceFilter(),
        belief_topic=topic,
        action_candidates=candidates or [
            {"verb": "buy", "target": "market", "benefit": 1.0, "cost": 0.5,
             "risk": 0.2, "belief_topic": "price"},
            {"verb": "sell", "target": "market", "benefit": 0.8, "cost": 0.4,
             "risk": 0.3, "belief_topic": "price"},
            {"verb": "wait", "target": None, "benefit": 0.1, "cost": 0.0,
             "risk": 0.0, "belief_topic": "price"},
        ],
    )


class _StubKernel:
    """Deterministic stand-in for ThreeBodyKernel (scripted verdicts)."""

    def __init__(self, verdicts, evac: bool = False):
        self._verdicts = list(verdicts)
        self._evac = evac

    def civilization_step(self, tech_level, t, Delta=0.1):
        kind, next_chaos = self._verdicts.pop(0)
        if next_chaos is None:
            t_pred = 999.0
        elif kind == "survived":
            t_pred = (next_chaos - t) + 10.0
        else:
            t_pred = max(0.0, (next_chaos - t) - 10.0)
        return ThreeBodyKernel.CivilizationEvent(
            kind=kind, tech_level=tech_level, delta_0=0.01,
            T_predict=t_pred, t=t, next_chaos=next_chaos, note="stub",
        )

    def evacuation_check(self, max_tech, Delta=0.1):
        return self._evac

    def civilization_outcome(self, tech_level, t, decision_vector=None,
                             civ_count=None, evacuated=False):
        kind = self._verdicts[0][0] if self._verdicts else "survived"
        return _StubOutcome(kind=kind, t=t, tech_level=tech_level,
                            decision_vector=decision_vector)

    def next_chaotic_era_after(self, t):
        return None

    @property
    def lambda_(self):
        return 0.1


class _StubOutcome:
    kind = "survived"
    t = 0.0
    tech_level = 0.0
    decision_vector = None
    cause = "stub"
    decision_quality = "neutral"

    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)

    def as_dict(self):
        return {"kind": self.kind, "t": self.t, "tech_level": self.tech_level,
                "cause": self.cause, "decision_quality": self.decision_quality}


# ---------------------------------------------------------------------------
# world_tick + AgentMind (Phases B/C/D)
# ---------------------------------------------------------------------------


def test_world_tick_agent_observe_belief_intent():
    """world_tick with AgentMind on: agent observes → updates belief → emits
    an ActionIntent → the intent is recorded in model_trace."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch.set_world("market")
        agent = _make_sim_agent()
        orch.register_agent_mind_binding(
            "market", agent.character_id, _market_binding(agent))
        result = orch.world_tick()
        assert result is not None
        am = result.model_trace["agent_mind"]
        assert agent.character_id in am["agents"]
        rec = am["agents"][agent.character_id]
        # belief was revised on the "price" topic
        assert rec["belief"] is not None
        # an ActionIntent verb was chosen from the allowed set
        assert rec["intent"]["verb"] in {"buy", "sell", "wait"}
        assert rec["intent"]["actor_id"] == agent.character_id


def test_world_tick_agent_intent_routed_through_write_point():
    """The agent's ActionIntent becomes a canonical worldbook fact written
    through add_world_entry (origin=agent_mind) — the agent never writes
    state directly (§12)."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch.set_world("market")
        agent = _make_sim_agent()
        orch.register_agent_mind_binding(
            "market", agent.character_id, _market_binding(agent))
        orch.world_tick()
        wb = orch.state_store.snapshot().worldbook
        agent_entries = [e for e in wb if e.source == "agent_mind_tick"]
        assert len(agent_entries) == 1
        assert agent_entries[0].provenance == "canonical_event"
        assert agent.character_id in agent_entries[0].content


def test_world_tick_agent_belief_revision_uses_filtered_observation():
    """The agent's belief moves toward the observed price (10.0); the
    observation came through the filter, not from raw truth."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch.set_world("market")
        agent = _make_sim_agent()
        orch.register_agent_mind_binding(
            "market", agent.character_id, _market_binding(agent))
        orch.world_tick()
        # the belief on "price" should be committed near 10.0
        belief = agent.mind_state.beliefs.get("price")
        assert belief is not None
        assert belief.predicted is not None
        assert 5.0 < belief.predicted < 15.0
        # the filtered observation was recorded in memory
        envelopes = [m for m in agent.mind_state.memory
                     if isinstance(m, dict) and m.get("type") == "filtered_observation"]
        assert len(envelopes) >= 1


def test_world_tick_agent_choose_action_uses_softmax_and_candidates():
    """choose_action returns subjective_scores for every candidate and a
    confidence value (softmax over permitted candidates)."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch.set_world("market")
        agent = _make_sim_agent()
        orch.register_agent_mind_binding(
            "market", agent.character_id, _market_binding(agent))
        result = orch.world_tick()
        intent = result.model_trace["agent_mind"]["agents"][agent.character_id]["intent"]
        assert set(intent["subjective_scores"].keys()) >= {"buy", "sell", "wait"}
        assert "temperature" in intent
        assert intent["confidence"] >= 0.0


def test_world_tick_causal_narrative_runs_over_belief_traces():
    """Phase D (§14): the two-stage causal narrative runs over the tick's
    belief traces + applied intents and surfaces in model_trace."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch.set_world("market")
        agent = _make_sim_agent()
        orch.register_agent_mind_binding(
            "market", agent.character_id, _market_binding(agent))
        # The helper explicitly attaches fake model-backed planner/realizer
        # stages. The test verifies their accepted artifact is surfaced.
        result = orch.world_tick()
        causal = result.model_trace["agent_mind"]["causal_narrative"]
        assert causal is not None
        assert "causal_graph" in causal
        assert "plan" in causal
        assert "narrative" in causal
        # the causal graph should reference the agent's belief topic
        assert "price" in str(causal["causal_graph"])


def test_world_tick_causal_narrative_none_without_agents():
    """No registered agents → no belief traces → causal narrative is None
    (graceful no-op, not an error)."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch.set_world("market")
        result = orch.world_tick()
        assert result is not None
        # no agent_mind key when no agents ran
        assert "agent_mind" not in result.model_trace


def test_world_tick_with_agents_requires_attached_narrative_engine():
    with tempfile.TemporaryDirectory() as d:
        orch = _orch(Path(d), enable_agent_mind=True)
        orch._causal_narrative_engine = None
        orch.set_world("market")
        agent = _make_sim_agent()
        orch.register_agent_mind_binding(
            "market", agent.character_id, _market_binding(agent)
        )
        with pytest.raises(RuntimeError, match="requires an explicitly attached"):
            orch.world_tick()


# ---------------------------------------------------------------------------
# Backward compatibility (flags off → existing behaviour)
# ---------------------------------------------------------------------------


def test_world_tick_agent_mind_off_is_noop():
    """With enable_agent_mind=False (opt-out), world_tick does NOT run the
    AgentMind cycle even if a binding is registered."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=False)
        orch.set_world("market")
        agent = _make_sim_agent()
        orch.register_agent_mind_binding(
            "market", agent.character_id, _market_binding(agent))
        result = orch.world_tick()
        assert result is not None
        assert "agent_mind" not in result.model_trace
        # no agent_mind_tick worldbook entry was written
        wb = orch.state_store.snapshot().worldbook
        assert not [e for e in wb if e.source == "agent_mind_tick"]
        # the agent's belief was not touched
        assert "price" not in agent.mind_state.beliefs


def test_three_body_tick_agents_off_uses_legacy_decision():
    """With enable_agent_mind=False, three_body_tick uses the passed
    decision directly (legacy path) and attaches no agent_causal_trace."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=False)
        # inject a stub kernel so we don't bake
        orch._three_body_kernel = _StubKernel([("survived", 100.0)])
        orch._narrate_three_body = lambda el, h: {
            "title": "t", "narrative": "n", "dialogue": "", "warnings": []}
        result = orch.three_body_tick(decision=2.0)
        assert result is not None
        assert result.model_trace["agent_causal_trace"] is None
        assert result.model_trace["kernel_verdict"] == "survived"


# ---------------------------------------------------------------------------
# three_body_tick + multi-scale (§5 distrust → disaster)
# ---------------------------------------------------------------------------


def _real_kernel(years: float = 600.0, seed: int = 42) -> ThreeBodyKernel:
    k = ThreeBodyKernel(seed=seed, dt=0.02,
                        lyapunov_renorms=8, lyapunov_renorm_steps=80)
    k.bake(years=years)
    return k


def _make_scientist(personality: str, capability: dict,
                    prior_prob: float, scientist_id: str) -> ScientistAgent:
    from theater.cognitive_model import Belief
    char = CharacterDefinition(
        character_id=scientist_id, name=scientist_id, personality=personality,
    )
    sim = SimAgent(char)
    sim.mind_state.beliefs["disaster_prob"] = Belief(
        predicted=prior_prob, confidence=0.5, model_error=False,
        committed_values={},
    )
    return ScientistAgent(sim, capability=capability,
                          scientist_id=scientist_id, seed=7)


def _distrust_graph_org(scientist_id: str, leader_id: str = "leader"):
    graph = CharacterGraph()
    org = Organization(
        org_id="civ",
        members=[scientist_id, leader_id],
        roles={leader_id: "leader"},
        decision_rule="dictator",
        dictator_id=leader_id,
    )
    # leader distrusts the scientist → proposal does not propagate
    graph.add_relationship(leader_id, scientist_id, trust=-0.5)
    graph.add_relationship(scientist_id, leader_id, trust=0.8)
    return graph, org


def test_three_body_tick_multiscale_distrust_leads_to_destroyed(monkeypatch):
    """§5 example: leader distrusts scientist → proposal blocked → org picks
    persist → kernel returns destroyed_decision. The multi-scale sim's
    CausalTrace is attached to model_trace."""
    k = _real_kernel()
    chaotic = k.chaotic_era_intervals()
    if not chaotic:
        pytest.skip("bake produced no chaotic era")
    vantage = max(0.0, chaotic[0].start - 5.0)
    # keep the planet bound so ejection does not preempt the decision branch
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)

    sci = _make_scientist("理性冷静",
                          {"tech_level": 6.0, "delta_0": 1e-4, "T_predict": 1000.0},
                          prior_prob=0.8, scientist_id="s1")
    graph, org = _distrust_graph_org("s1")
    body = DecisionBody(org, graph, trust_threshold=0.0)
    sim = MultiScaleThreeBodySim(
        kernel=k, scientists={"s1": sci}, decision_body=body,
        civilization_agent=CivilizationAgent(k), seed=7,
    )

    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch._three_body_kernel = k
        orch._narrate_three_body = lambda el, h: {
            "title": "t", "narrative": "n", "dialogue": "", "warnings": []}
        # advance the cursor to the vantage point so the sim observes the
        # imminent chaos
        orch._three_body_cursor = vantage
        orch.register_multi_scale_sim("three_body", sim)
        result = orch.three_body_tick()
        assert result is not None
        trace = result.model_trace["agent_causal_trace"]
        assert trace is not None
        # the scientist proposed a prepare plan but the leader never received it
        assert trace["proposals"]["s1"] in (PLAN_DEHYDRATE, "evacuate")
        assert "s1" not in trace["info_propagation"]["leader"]
        assert trace["org_decision"] == PLAN_PERSIST
        assert trace["decision_vector"] == PLAN_TO_DECISION_VECTOR[PLAN_PERSIST]
        # kernel verdict: hoarding under imminent chaos → destroyed_decision
        assert trace["outcome_kind"] == "destroyed_decision"
        assert trace["civ_destroyed"] is True
        assert result.model_trace["kernel_verdict"] == "destroyed_decision"
        # civ scalars reflect the kernel verdict
        civ = orch._three_body_civ["civilization"]
        assert civ["tech_level"] == 0.0
        assert civ["count"] == 2


def test_three_body_tick_multiscale_trust_leads_to_survive(monkeypatch):
    """Control: when the leader trusts the scientist, the prepare plan lands
    and the civilisation survives (high civ tech)."""
    k = _real_kernel()
    chaotic = k.chaotic_era_intervals()
    if not chaotic:
        pytest.skip("bake produced no chaotic era")
    vantage = max(0.0, chaotic[0].start - 1.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)

    sci = _make_scientist("理性冷静",
                          {"tech_level": 6.0, "delta_0": 1e-4, "T_predict": 1000.0},
                          prior_prob=0.9, scientist_id="s1")
    graph = CharacterGraph()
    org = Organization(org_id="civ", members=["s1", "leader"],
                       roles={"leader": "leader"},
                       decision_rule="dictator", dictator_id="leader")
    graph.add_relationship("leader", "s1", trust=0.9)
    graph.add_relationship("s1", "leader", trust=0.8)
    body = DecisionBody(org, graph, trust_threshold=0.0)
    sim = MultiScaleThreeBodySim(
        kernel=k, scientists={"s1": sci}, decision_body=body,
        civilization_agent=CivilizationAgent(k), seed=11,
    )

    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch._three_body_kernel = k
        orch._narrate_three_body = lambda el, h: {
            "title": "t", "narrative": "n", "dialogue": "", "warnings": []}
        orch._three_body_cursor = vantage
        orch.register_multi_scale_sim("three_body", sim)
        # high civ tech → horizon covers → survived regardless
        orch._three_body_civ_state()["civilization"]["tech_level"] = 10.0
        result = orch.three_body_tick()
        assert result is not None
        trace = result.model_trace["agent_causal_trace"]
        assert trace is not None
        assert trace["org_decision"] in (PLAN_DEHYDRATE, PLAN_EVACUATE)
        assert trace["outcome_kind"] == "survived"
        assert trace["civ_destroyed"] is False


def test_three_body_tick_multiscale_decision_vector_feeds_kernel(monkeypatch):
    """The decision_vector the multi-scale sim produces is the one the kernel
    consumes (§8.2 red line): the tech proxy fed to civilization_step matches
    PLAN_TO_DECISION_VECTOR[persist].sum()."""
    k = _real_kernel()
    chaotic = k.chaotic_era_intervals()
    if not chaotic:
        pytest.skip("bake produced no chaotic era")
    vantage = max(0.0, chaotic[0].start - 5.0)
    monkeypatch.setattr(k, "planet_orbital_energy_at", lambda t: -1.0)

    sci = _make_scientist("理性冷静",
                          {"tech_level": 6.0, "delta_0": 1e-4, "T_predict": 1000.0},
                          prior_prob=0.8, scientist_id="s1")
    graph, org = _distrust_graph_org("s1")
    body = DecisionBody(org, graph, trust_threshold=0.0)
    sim = MultiScaleThreeBodySim(
        kernel=k, scientists={"s1": sci}, decision_body=body,
        civilization_agent=CivilizationAgent(k), seed=7,
    )

    calls: List[float] = []
    real_step = k.civilization_step

    def spy_step(tech_level, t, Delta=0.1):
        calls.append(float(tech_level))
        return real_step(tech_level, t=t, Delta=Delta)

    monkeypatch.setattr(k, "civilization_step", spy_step)

    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch._three_body_kernel = k
        orch._narrate_three_body = lambda el, h: {
            "title": "t", "narrative": "n", "dialogue": "", "warnings": []}
        orch._three_body_cursor = vantage
        orch.register_multi_scale_sim("three_body", sim)
        orch.three_body_tick()
        # the last civilization_step call used the persist decision_vector's
        # tech proxy (sum of {tech:0, shelter:0, hoard:1, gamble:0} = 1.0)
        assert calls[-1] == sum(PLAN_TO_DECISION_VECTOR[PLAN_PERSIST].values())


# ---------------------------------------------------------------------------
# Causal narrative wiring (§14) — injected engine
# ---------------------------------------------------------------------------


def test_causal_narrative_engine_injection():
    """attach_causal_narrative_engine lets a caller inject a pre-built
    CausalNarrativeEngine; world_tick uses it instead of the default."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch.set_world("market")
        agent = _make_sim_agent()
        orch.register_agent_mind_binding(
            "market", agent.character_id, _market_binding(agent))
        # inject a real engine with fake llm_fn so the planner/realizer
        # have something to call (de-fallout: None raises RuntimeError).
        def _fake_plan(prompt: str) -> str:
            return json.dumps({
                "cause": "market oscillation",
                "mechanism": "informational",
                "effect": "unspecified",
                "subjective_reason": "observed price shift",
                "belief_refs": ["price"],
                "fact_refs": [],
                "confidence": 0.7,
            })
        def _fake_realize(prompt: str) -> str:
            return "The trader watched the price shift and acted."
        orch.attach_causal_narrative_engine(
            CausalNarrativeEngine(planner_llm=_fake_plan, realizer_llm=_fake_realize, seed=42))
        result = orch.world_tick()
        causal = result.model_trace["agent_mind"]["causal_narrative"]
        assert causal is not None
        assert "causal_graph" in causal
        # validation should pass (the fake plan cites held beliefs + facts)
        assert isinstance(causal["validation_ok"], bool)
        causal = result.model_trace["agent_mind"]["causal_narrative"]
        assert causal is not None
        assert "causal_graph" in causal
        # validation should pass (the model plan cites held beliefs + facts)
        assert isinstance(causal["validation_ok"], bool)


def test_apply_agent_intents_writes_canonical_fact_per_beat():
    """_apply_agent_intents records one canonical fact per beat summarising
    all agents' committed actions, with provenance=canonical_event."""
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        orch = _orch(tmp, enable_agent_mind=True)
        orch.set_world("market")
        orch._world_beat = 3
        intents = [
            {"actor_id": "a1", "verb": "buy", "target": "market",
             "subjective_reason": "price up", "subjective_scores": {},
             "belief_refs": [], "confidence": 0.6},
            {"actor_id": "a2", "verb": "wait", "target": None,
             "subjective_reason": "uncertain", "subjective_scores": {},
             "belief_refs": [], "confidence": 0.4},
        ]
        facts = orch._apply_agent_intents("market", intents, beat=3)
        assert len(facts) == 2
        wb = orch.state_store.snapshot().worldbook
        entry = next(e for e in wb if e.source == "agent_mind_tick")
        assert "第3拍" in entry.title
        assert "a1" in entry.content and "a2" in entry.content
        assert entry.provenance == "canonical_event"


# ---------------------------------------------------------------------------
# Stub kernel helper (defined above in the helpers section)
# ---------------------------------------------------------------------------


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-q"]))
