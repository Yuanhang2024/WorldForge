"""Tests for the WorldForge launcher (launcher.py).

Tests the pure logic functions: URL building, model parsing, search filter,
config IO, server env, server-wait helper. tkinter GUI plumbing is not
exercised (needs a display); main() imports tkinter lazily so importing
launcher.py on a headless box is safe.
"""

from __future__ import annotations

import json
import socket
import threading
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request

import pytest

import launcher


# --- import / module sanity ------------------------------------------------


def test_imports_clean_and_constants():
    # importing the module must not require a display (tkinter is lazy)
    assert launcher.DEFAULT_BASE_URL.startswith("http")
    assert launcher.WORLDFORGE_PORT == 8787
    assert launcher.WORLDFORGE_URL.endswith("/index.html")
    # env var names match what backend settings.py reads
    assert launcher.ENV_BASE_URL == "AI_THEATER_BASE_URL"
    assert launcher.ENV_API_KEY == "AI_THEATER_API_KEY"
    assert launcher.ENV_MODEL_FAST == "AI_THEATER_MODEL_FAST"
    assert launcher.ENV_MODEL_DEEP == "AI_THEATER_MODEL_DEEP"
    assert launcher.DEFAULT_API_KEY == ""
    assert launcher.PROVIDER_OPTIONS == ("OpenAI", "LM Studio", "Ollama", "Custom")


# --- build_models_url ------------------------------------------------------


@pytest.mark.parametrize("base,expected", [
    ("http://127.0.0.1:18899/v1", "http://127.0.0.1:18899/v1/models"),
    ("http://127.0.0.1:18899/v1/", "http://127.0.0.1:18899/v1/models"),
    ("https://api.requestme.top/v1", "https://api.requestme.top/v1/models"),
    ("https://api.openai.com/v1", "https://api.openai.com/v1/models"),
    ("http://localhost:18899/v1/models", "http://localhost:18899/v1/models"),
    ("http://localhost:18899/v1/models/", "http://localhost:18899/v1/models"),
])
def test_build_models_url(base, expected):
    assert launcher.build_models_url(base) == expected


def test_build_models_url_empty_raises():
    with pytest.raises(ValueError):
        launcher.build_models_url("")
    with pytest.raises(ValueError):
        launcher.build_models_url("   ")


# --- build_auth_headers ----------------------------------------------------


def test_auth_headers_bearer():
    h = launcher.build_auth_headers("sk-abc")
    assert h == {"Authorization": "Bearer sk-abc"}


def test_auth_headers_empty():
    assert launcher.build_auth_headers("") == {}
    assert launcher.build_auth_headers("   ") == {}


# --- parse_models_response -------------------------------------------------


def test_parse_openai_shape():
    payload = {"data": [{"id": "gpt-4o"}, {"id": "qwen3-coder"}, {"id": "deepseek-r1"}]}
    assert launcher.parse_models_response(payload) == ["gpt-4o", "qwen3-coder", "deepseek-r1"]


def test_parse_list_shape():
    payload = [{"id": "a"}, {"id": "b"}]
    assert launcher.parse_models_response(payload) == ["a", "b"]


def test_parse_bare_strings():
    assert launcher.parse_models_response(["x", "y", "x"]) == ["x", "y"]


def test_parse_dedupes_and_skips_empty():
    payload = {"data": [{"id": "m1"}, {"id": "m1"}, {"id": ""}, {"name": "no-id"}]}
    assert launcher.parse_models_response(payload) == ["m1"]


def test_parse_garbage_returns_empty():
    assert launcher.parse_models_response(None) == []
    assert launcher.parse_models_response("not a dict") == []
    assert launcher.parse_models_response({}) == []


# --- filter_models ---------------------------------------------------------


def test_filter_no_query_returns_copy():
    src = ["gpt-4o", "qwen3-coder"]
    out = launcher.filter_models(src, "")
    assert out == src
    assert out is not src  # copy, not alias


def test_filter_case_insensitive_substring():
    src = ["gpt-4o", "gpt-3.5", "qwen3-coder", "deepseek-r1", "Qwen3-32B"]
    out = launcher.filter_models(src, "qwen3")
    assert out == ["qwen3-coder", "Qwen3-32B"]


def test_filter_no_match():
    assert launcher.filter_models(["a", "b"], "zzz") == []


def test_model_selection_uses_single_model_for_both_lanes():
    assert launcher.normalize_model_selection("provider/model-a", "") == (
        "provider/model-a", "provider/model-a",
    )
    assert launcher.normalize_model_selection("(none)", "provider/model-b") == (
        "provider/model-b", "provider/model-b",
    )


def test_model_selection_requires_at_least_one_model():
    with pytest.raises(ValueError, match="at least one model"):
        launcher.normalize_model_selection("", "(none)")


def test_launch_requires_an_api_key_for_openai_but_not_local_providers():
    with pytest.raises(ValueError, match="OpenAI requires"):
        launcher.validate_launch_configuration("OpenAI", "https://api.openai.com/v1", "", "gpt", "")
    assert launcher.validate_launch_configuration(
        "LM Studio", "http://127.0.0.1:1234/v1", "", "local-model", "",
    ) == ("local-model", "local-model")


def test_launcher_next_step_explains_the_four_step_flow():
    assert launcher.launcher_next_step("", [], "", "").startswith("Step 1/4")
    assert launcher.launcher_next_step("http://localhost/v1", [], "", "").startswith("Step 2/4")
    assert launcher.launcher_next_step(
        "http://localhost/v1", ["model-a"], "", "",
    ).startswith("Step 3/4")
    assert launcher.launcher_next_step(
        "http://localhost/v1", ["model-a"], "model-a", "",
    ).startswith("Step 4/4")
    assert "requires an API Key" in launcher.launcher_next_step(
        "https://api.openai.com/v1", [], "", "", "OpenAI", "",
    )


@pytest.mark.parametrize(("provider", "expected"), [
    ("OpenAI", "https://api.openai.com/v1"),
    ("LM Studio", "http://127.0.0.1:1234/v1"),
    ("Ollama", "http://127.0.0.1:11434/v1"),
])
def test_provider_selection_uses_the_provider_endpoint(provider, expected):
    assert launcher.provider_base_url(provider, "http://existing/v1") == expected


def test_custom_provider_selection_preserves_the_entered_endpoint():
    assert launcher.provider_base_url("Custom", "https://example.test/v1") == "https://example.test/v1"


@pytest.mark.parametrize(("base_url", "expected"), [
    ("https://api.openai.com/v1", "OpenAI"),
    ("http://127.0.0.1:1234/v1/", "LM Studio"),
    ("http://127.0.0.1:11434/v1", "Ollama"),
    ("https://example.test/v1", "Custom"),
])
def test_saved_endpoint_keeps_provider_dropdown_consistent(base_url, expected):
    assert launcher.provider_for_base_url(base_url) == expected


# --- config IO -------------------------------------------------------------


def test_save_load_roundtrip(tmp_path: Path):
    cfg = tmp_path / "cfg.json"
    launcher.save_config("http://x/v1", "sk-1", "fast-m", "deep-m", path=cfg)
    loaded = launcher.load_config(path=cfg)
    assert loaded == {
        "base_url": "http://x/v1",
        "model_fast": "fast-m",
        "model_deep": "deep-m",
    }
    assert "api_key" not in json.loads(cfg.read_text(encoding="utf-8"))


def test_save_config_clears_a_legacy_persisted_api_key(tmp_path: Path):
    cfg = tmp_path / "cfg.json"
    cfg.write_text(json.dumps({"base_url": "http://old/v1", "api_key": "sk-old"}), encoding="utf-8")

    launcher.save_config("http://new/v1", "sk-new", "fast-m", "deep-m", path=cfg)

    assert "api_key" not in json.loads(cfg.read_text(encoding="utf-8"))


def test_load_missing_returns_empty(tmp_path: Path):
    assert launcher.load_config(path=tmp_path / "nope.json") == {}


def test_load_corrupt_returns_empty(tmp_path: Path):
    cfg = tmp_path / "bad.json"
    cfg.write_text("{ not json", encoding="utf-8")
    assert launcher.load_config(path=cfg) == {}


def test_save_to_unwritable_path_does_not_raise(tmp_path: Path):
    # point at a path inside a non-existent nested dir; save must swallow OSError
    bad = tmp_path / "no" / "dir" / "cfg.json"
    launcher.save_config("u", "k", "f", "d", path=bad)  # must not raise
    assert not bad.exists()


# --- build_server_env ------------------------------------------------------


def test_build_server_env_sets_all_vars():
    env = launcher.build_server_env("http://x/v1", "sk-1", "fast-m", "deep-m")
    assert env[launcher.ENV_BASE_URL] == "http://x/v1"
    assert env[launcher.ENV_API_KEY] == "sk-1"
    assert env[launcher.ENV_MODEL_FAST] == "fast-m"
    assert env[launcher.ENV_MODEL_DEEP] == "deep-m"
    assert str(launcher.BACKEND_DIR) in env["PYTHONPATH"]


def test_build_server_env_inherits_existing():
    env = launcher.build_server_env("http://x/v1", "sk", "f", "d")
    # PATH should be inherited from the current process
    assert "PATH" in env


# --- fetch_models (mocked urllib) ------------------------------------------


class _FakeResp:
    def __init__(self, data: bytes):
        self._data = data

    def read(self) -> bytes:
        return self._data

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def test_fetch_models_success(monkeypatch):
    payload = json.dumps({"data": [{"id": "m1"}, {"id": "m2"}]}).encode()
    captured = {}

    def fake_urlopen(req: Request):
        captured["url"] = req.full_url
        captured["headers"] = dict(req.header_items())
        return _FakeResp(payload)

    monkeypatch.setattr(launcher, "urlopen", fake_urlopen)
    models = launcher.fetch_models("http://127.0.0.1:18899/v1", "sk-xyz")
    assert models == ["m1", "m2"]
    assert captured["url"] == "http://127.0.0.1:18899/v1/models"
    # Bearer header must be present
    auth = captured["headers"].get("Authorization") or captured["headers"].get("authorization")
    assert auth == "Bearer sk-xyz"


def test_fetch_models_401_raises_value_error(monkeypatch):
    def fake_urlopen(req):
        raise HTTPError(req.full_url, 401, "Unauthorized", {}, None)

    monkeypatch.setattr(launcher, "urlopen", fake_urlopen)
    with pytest.raises(ValueError, match="API key rejected"):
        launcher.fetch_models("http://x/v1", "bad-key")


def test_fetch_models_connection_error(monkeypatch):
    from urllib.error import URLError
    def fake_urlopen(req):
        raise URLError("connection refused")
    monkeypatch.setattr(launcher, "urlopen", fake_urlopen)
    with pytest.raises(ValueError, match="Cannot reach"):
        launcher.fetch_models("http://x/v1", "k")


def test_fetch_models_bad_json(monkeypatch):
    def fake_urlopen(req):
        return _FakeResp(b"<<not json>>")
    monkeypatch.setattr(launcher, "urlopen", fake_urlopen)
    with pytest.raises(ValueError, match="not valid JSON"):
        launcher.fetch_models("http://x/v1", "k")


# --- wait_for_server -------------------------------------------------------


def test_wait_for_server_success():
    # open a real listening socket on an ephemeral port
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    host, port = srv.getsockname()
    try:
        assert launcher.wait_for_server(host, port, timeout=3.0) is True
    finally:
        srv.close()


def test_wait_for_server_timeout():
    # nothing listening on an ephemeral port we grabbed+closed
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    host, port = srv.getsockname()
    srv.close()
    assert launcher.wait_for_server(host, port, timeout=1.0) is False


def test_wait_for_server_stops_when_child_exits(monkeypatch):
    class _Exited:
        @staticmethod
        def poll():
            return 1

    assert launcher.wait_for_server(
        "127.0.0.1", 65534, timeout=3.0, process=_Exited(),
    ) is False


def test_port_is_in_use():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    host, port = srv.getsockname()
    try:
        assert launcher.port_is_in_use(host, port) is True
    finally:
        srv.close()
    assert launcher.port_is_in_use(host, port, timeout=0.1) is False


# --- GUI class smoke (no display) ------------------------------------------


def test_launcher_app_class_exists_and_methods_exist():
    # We can't instantiate Tk without a display, but the class + its methods
    # must be importable and reference the expected hooks.
    cls = launcher.LauncherApp
    for name in ("on_pull", "on_launch", "on_close", "_populate_combos",
                 "_apply_filter", "_pull_done", "_pull_failed", "_server_up",
                 "_show_next_step", "_apply_provider_url"):
        assert callable(getattr(cls, name)), name
