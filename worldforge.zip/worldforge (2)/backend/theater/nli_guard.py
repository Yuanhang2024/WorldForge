"""NLI 双向蕴含守卫 (研究结论 Q6 一级方案).

三层守卫阶梯的最底层升级：把 ``ThreeBodyNarrator._check_outcome_consistency``
从"关键词匹配"升级到"NLI 双向蕴含"。

为什么需要它（研究背景 Q2 实证警告）
------------------------------------
Yamin et al. 证明 LLM 会系统性地把反直觉因果"改正"回常识。三体里"文明因正确
脱水反而灭亡""行星被甩出但文明幸存"这类反直觉结局最容易被 LLM 悄悄翻转。
关键词匹配对词汇变化脆弱——LLM 换个说法（"熄灭"替"毁灭"、"出走"替"逃离"）
就能绕过 ``_OUTCOME_KEYWORDS`` 的 need/forbid 词族。NLI 对词汇变化鲁棒。

双向蕴含
--------
把结构化 outcome dict 用平凡模板转成文本 ``source``，再用 NLI 模型双向检查
``hypothesis``（LLM 生成的叙事）与 ``source`` 的蕴含关系：

  - forward  = NLI(source -> hypothesis)：暴露**幻觉**（LLM 叙事说了 outcome
    没有的东西，与源矛盾）。
  - backward = NLI(hypothesis -> source)：暴露**遗漏/翻转**（LLM 叙事缺了
    outcome 的核心断言，或把结局翻过来了）。

``consistent = (forward == entail) and (backward == entail)``。任一方向
``contradict`` 即不一致 → 守卫拒绝 → 回退确定性兜底模板。

后端选择（方案 c 混合）
-----------------------
WorldForge 是纯 stdlib+numpy，没有 torch/transformers 硬依赖。守卫**不硬依赖**
torch：

  1. 若本地装了 ``transformers`` 且显式配置了模型（``THEATER_NLI_MODEL`` 或
     构造参数 ``model_name``）→ 用 MNLI 微调的 DeBERTa-v3 类小模型，本地推理
     成本可忽略。
  2. 否则若提供了一个 ``llm_fn``（str->str，典型是 Spark the configured LLM 的
     判定包装）→ 用 LLM 当 NLI 判定器（prompt 让 LLM 判断蕴含关系）。
  3. 两者皆无 → ``available()`` 返回 False，调用方回退到关键词匹配层
     (``_OUTCOME_KEYWORDS``)，再往下是无守卫。

凭据走环境变量（``SPARK_*`` / ``THEATER_LLM_*`` / ``THEATER_NLI_*``），不硬编码。
本地模型**不自动启用**——必须显式配置模型名，避免测试套件意外触发模型下载。
"""

from __future__ import annotations

import os
from typing import Any, Callable, Dict, Optional


__all__ = ["NliGuard", "outcome_source"]


# ---------------------------------------------------------------------------
# 默认配置 (可被环境变量覆盖). 非机密.
# ---------------------------------------------------------------------------

_DEFAULT_LOCAL_MODEL = "MoritzLaurer/DeBERTa-v3-base-mnli"


# outcome kind -> 中文语义标签 (平凡模板用).
_KIND_LABEL: Dict[str, str] = {
    "survived": "文明幸存",
    "destroyed_chaos": "文明毁灭于乱纪元",
    "destroyed_decision": "文明毁灭于错误决策",
    "destroyed_resource": "文明毁灭于资源耗尽",
    "planet_ejected": "行星被甩出三体星系",
    "evacuated": "文明逃离三体星系",
}


def outcome_source(fields: Dict[str, Any]) -> str:
    """把 outcome 字段 dict 用平凡模板转成 NLI 用的 source 文本陈述.

    模板刻意平凡: 只罗列内核裁决的核心断言 (结局类型/原因/科技/决策质量/
    文明计数/行星能量), 不做任何润色——NLI 要比对的正是"LLM 叙事是否与这些
    核心断言一致". 缺字段就跳过, 不臆造.
    """
    kind = str(fields.get("kind", "") or "")
    label = _KIND_LABEL.get(kind, kind or "未知结局")
    parts: list = [label]
    cause = fields.get("cause", "")
    if cause:
        parts.append(f"原因={cause}")
    tech = fields.get("tech_level", "")
    if tech != "":
        parts.append(f"科技={tech}")
    dq = fields.get("decision_quality", "")
    if dq and dq != "neutral":
        parts.append(f"决策质量={dq}")
    civ = fields.get("civ_count", "")
    if civ not in ("", None, "—"):
        parts.append(f"文明计数={civ}")
    pe = fields.get("planet_energy", "—")
    if pe not in ("—", None, ""):
        parts.append(f"行星能量={pe}")
    return "，".join(str(p) for p in parts)


# ---------------------------------------------------------------------------
# transformers 探测 (模块级, 便于测试 monkeypatch).
# ---------------------------------------------------------------------------


def _try_import_transformers() -> Any:
    """尝试 import transformers; 失败返回 None. 不抛异常."""
    try:
        import transformers  # type: ignore
        return transformers
    except Exception:
        return None


def _load_pipeline(model_name: str) -> Any:
    """惰性加载 transformers text-classification pipeline.

    模块级函数, 测试可 monkeypatch 掉以避免真实模型下载. 只在本地后端
    第一次 ``check_entailment`` 时调用——构造 :class:`NliGuard` 不触发加载.
    """
    tf = _try_import_transformers()
    if tf is None:
        raise RuntimeError("transformers not importable")
    return tf.pipeline("text-classification", model=model_name)


# ---------------------------------------------------------------------------
# NliGuard
# ---------------------------------------------------------------------------


class NliGuard:
    """双向蕴含守卫.

    Parameters
    ----------
    llm_fn:
        可选的 ``str -> str`` 判定 LLM (典型: Spark the configured LLM 的
        包装). 仅在本地 transformers 后端不可用时作为 LLM-judge 后端.
    model_name:
        可选的本地 MNLI 模型 id (如 ``MoritzLaurer/DeBERTa-v3-base-mnli``).
        给定且 transformers 可 import 时启用本地后端. 默认从环境变量
        ``THEATER_NLI_MODEL`` 读取; 设为 ``"0"``/空可禁用.
    """

    def __init__(
        self,
        llm_fn: Optional[Callable[[str], str]] = None,
        model_name: Optional[str] = None,
    ) -> None:
        self._llm_fn = llm_fn
        if model_name is None:
            model_name = os.environ.get("THEATER_NLI_MODEL") or None
        if model_name in ("", "0", "false", "False"):
            model_name = None
        self._model_name = model_name
        self._pipe: Any = None  # 惰性
        self._pipe_loaded = False

        # 后端选择: 本地模型优先 (专门模型比 LLM-judge 准), 否则 LLM-judge.
        if self._model_name is not None and _try_import_transformers() is not None:
            self._backend = "local"
        elif self._llm_fn is not None:
            self._backend = "llm"
        else:
            self._backend = None

    # -- 公开 API -----------------------------------------------------------

    def available(self) -> bool:
        """是否有可用 NLI 后端. False 时调用方应回退关键词匹配层."""
        return self._backend is not None

    def check_entailment(self, source: str, hypothesis: str) -> Dict[str, Any]:
        """双向蕴含检查.

        Returns ``{forward, backward, consistent, available}``:
          - forward / backward: ``"entail"`` | ``"contradict"`` | ``"neutral"``
          - consistent: ``forward == "entail" and backward == "entail"``
            (LLM 叙事既没加幻觉也没遗漏核心). 任一方向 contradict 即不一致.
          - available: 后端是否真的跑了 (False 时返回 neutral 占位, 调用方
            应据此回退关键词匹配).
        """
        if not self.available():
            return {
                "forward": "neutral",
                "backward": "neutral",
                "consistent": False,
                "available": False,
            }
        if self._backend == "local":
            fwd = self._classify_local(source, hypothesis)
            bwd = self._classify_local(hypothesis, source)
        else:  # "llm"
            fwd = self._classify_llm(source, hypothesis)
            bwd = self._classify_llm(hypothesis, source)
        consistent = (fwd == "entail") and (bwd == "entail")
        return {
            "forward": fwd,
            "backward": bwd,
            "consistent": consistent,
            "available": True,
        }

    # -- 本地 transformers 后端 ---------------------------------------------

    def _classify_local(self, premise: str, hypothesis: str) -> str:
        if not self._pipe_loaded:
            self._pipe = _load_pipeline(self._model_name)  # type: ignore[arg-type]
            self._pipe_loaded = True
        try:
            result = self._pipe((premise, hypothesis))
        except Exception:
            return "neutral"
        # pipeline 可能返回 list 或 dict; 统一取 label.
        label = ""
        if isinstance(result, list) and result:
            label = str(result[0].get("label", "") if isinstance(result[0], dict)
                    else result[0])
        elif isinstance(result, dict):
            label = str(result.get("label", ""))
        return _normalize_label(label)

    # -- LLM-judge 后端 -----------------------------------------------------

    def _classify_llm(self, premise: str, hypothesis: str) -> str:
        prompt = (
            "你是自然语言推理(NLI)判定器。判断【前提】是否蕴含【假设】。\n"
            "只回答一个词，三选一：\n"
            "  entail   —— 前提蕴含假设（假设的内容可由前提推出）\n"
            "  contradict —— 前提与假设矛盾\n"
            "  neutral   —— 两者既不蕴含也不矛盾\n"
            f"【前提】{premise}\n"
            f"【假设】{hypothesis}\n"
            "回答（仅一个词）："
        )
        try:
            raw = self._llm_fn(prompt)  # type: ignore[misc]
        except Exception:
            return "neutral"
        if not isinstance(raw, str):
            return "neutral"
        return _parse_judge_label(raw)


# ---------------------------------------------------------------------------
# 标签归一化
# ---------------------------------------------------------------------------


def _normalize_label(label: str) -> str:
    """把模型/LLM 输出的标签归一成 entail/contradict/neutral."""
    s = (label or "").strip().lower()
    if not s:
        return "neutral"
    # LABEL_0/1/2 (MNLI 约定: 0=entailment,1=neutral,2=contradiction, 但因模型而异)
    # 优先按词义匹配, 忽略 LABEL_ 数字歧义.
    if "contradict" in s or "矛盾" in s:
        return "contradict"
    if "entail" in s or "蕴含" in s or "推出" in s:
        return "entail"
    if "neutral" in s or "中立" in s or "无关" in s:
        return "neutral"
    # 退化: LABEL_0 常见为 entailment (多数 MNLI 模型), 但不保证——
    # 遇到裸 LABEL_n 又无词义线索时判 neutral (放行, 不误杀).
    return "neutral"


def _parse_judge_label(raw: str) -> str:
    """从 LLM 自由文本里抽 entail/contradict/neutral."""
    s = raw.strip().lower()
    if "contradict" in s or "矛盾" in s:
        return "contradict"
    if "entail" in s or "蕴含" in s or "推出" in s:
        return "entail"
    if "neutral" in s or "中立" in s or "无关" in s:
        return "neutral"
    # 无法解析时判 neutral (放行, 不误杀——关键词层仍兜底).
    return "neutral"
