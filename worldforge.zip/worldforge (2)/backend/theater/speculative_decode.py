"""
Speculative decoding framework for AI Theater.

Implements ARCHITECTURE_SPEC(2).md §5.5 items 3-4:

  - Speculative decoding (1B draft + 12B target) with rejection-based
    verification, per §5.5 item 3.  Theater dialogue is highly predictable
    (persona + format + scene constraints), so accept rate should exceed 60%.
  - Prompt-lookup / n-gram speculation (§5.5 item 4): zero-model-cost
    suggestions from repeated n-grams in the prompt itself.

Pure Python, no dispatcher/agents/server dependencies.  Unit-testable with
mock LLM clients.

Usage::

    decoder = SpeculativeDecoder(draft_client, target_client)
    text = decoder.decode("Once upon a time", max_tokens=50)
    print(f"accept_rate={decoder.accept_rate:.0%}")
"""

from __future__ import annotations

from typing import List, Tuple


# ---------------------------------------------------------------------------
# Client protocol (duck-typed, same style as best_of_n.py)
# ---------------------------------------------------------------------------

#: A fast drafter model (1B).  Must provide a ``generate(prompt, n_tokens)``
#: callable that returns a list of candidate next-token strings (greedy
#: or sampled).  The list length may be shorter than *n_tokens* when EOS or
#: the end of generation capacity is reached.
DraftClient = object

#: An accurate target model (12B).  Must provide a ``verify(prompt,
#: draft_tokens)`` callable that returns ``(n_accepted, next_token)``.
#:
#:   *n_accepted* (int) — how many draft tokens (from the beginning) were
#:   accepted, in range [0, len(draft_tokens)].
#:
#:   *next_token* (str) — the next token the target generates at the
#:   rejection position, or the bonus token when all K draft tokens are
#:   accepted.
TargetClient = object


# ---------------------------------------------------------------------------
# Helpers for client dispatch
# ---------------------------------------------------------------------------

def _call_draft(draft: DraftClient, prompt: str, n_tokens: int) -> List[str]:
    """Call ``draft.generate(prompt, n_tokens=n_tokens)``."""
    fn = getattr(draft, "generate", None)
    if fn is None:
        raise TypeError(
            f"Draft client of type {type(draft).__name__} has no .generate()"
        )
    tokens = fn(prompt, n_tokens=n_tokens)
    if tokens is None:
        return []
    return list(tokens)


def _call_target(target: TargetClient, prompt: str, draft_tokens: List[str]) -> Tuple[int, str]:
    """Call ``target.verify(prompt, draft_tokens)``."""
    fn = getattr(target, "verify", None)
    if fn is None:
        raise TypeError(
            f"Target client of type {type(target).__name__} has no .verify()"
        )
    result = fn(prompt, draft_tokens)
    if result is None:
        return 0, ""
    if not isinstance(result, tuple) or len(result) != 2:
        raise TypeError(
            f"target.verify() must return (int, str), got {result!r}"
        )
    n_accepted, next_token = result
    return int(n_accepted), str(next_token)


# ---------------------------------------------------------------------------
# SpeculativeDecoder
# ---------------------------------------------------------------------------


class SpeculativeDecoder:
    """Speculative decoding — draft model proposes, target model verifies.

    Architecture spec §5.5 item 3.

    Per iteration:
      1. Draft generates up to *K* candidate tokens.
      2. Target runs a single forward pass over the extended sequence,
         accepting a prefix of the draft tokens matching its distribution.
      3. The target generates one token at the rejection point (or a bonus
         token if all *K* were accepted).

    Attributes:
        accept_rate: Fraction of proposed draft tokens accepted.
                     Healthy threshold is >0.6 per §13.6.
    """

    def __init__(
        self,
        draft_client: DraftClient,
        target_client: TargetClient,
    ) -> None:
        self._draft = draft_client
        self._target = target_client
        self._accepted: int = 0
        self._proposed: int = 0

    @property
    def accept_rate(self) -> float:
        """Fraction of proposed draft tokens that were accepted."""
        if self._proposed == 0:
            return 0.0
        return self._accepted / self._proposed

    @property
    def n_accepted(self) -> int:
        """Total count of accepted draft tokens."""
        return self._accepted

    @property
    def n_proposed(self) -> int:
        """Total count of proposed draft tokens."""
        return self._proposed

    # ------------------------------------------------------------------
    # Public decode API
    # ------------------------------------------------------------------

    def decode(
        self,
        prompt: str,
        max_tokens: int,
        K: int = 5,
    ) -> str:
        """Generate text using speculative decoding.

        Args:
            prompt: Input prompt (prefix).
            max_tokens: Maximum number of **target** tokens to generate.
            K: Number of draft tokens per speculation iteration.

        Returns:
            Generated text **without** the prompt prefix.
        """
        output_tokens: List[str] = []

        while len(output_tokens) < max_tokens:
            # --- 1. Draft proposes candidate tokens ------------------------
            budget = min(K, max_tokens - len(output_tokens))
            draft_tokens = _call_draft(self._draft, prompt, n_tokens=budget)
            if not draft_tokens:
                # Draft exhausted — fall back to one target step and exit.
                _, next_tok = _call_target(self._target, prompt, [])
                if next_tok:
                    output_tokens.append(next_tok)
                break

            self._proposed += len(draft_tokens)

            # --- 2. Target verifies the draft -----------------------------
            n_accepted, next_tok = _call_target(
                self._target, prompt, draft_tokens
            )
            self._accepted += n_accepted

            # --- 3. Keep accepted prefix ----------------------------------
            for i in range(n_accepted):
                output_tokens.append(draft_tokens[i])

            # --- 4. Append target's token (rejection point or bonus) ------
            if next_tok and len(output_tokens) < max_tokens:
                output_tokens.append(next_tok)

            # --- 5. Rebuild prompt for next iteration ---------------------
            prompt = prompt + "".join(output_tokens)

            # Safety: if neither accepted tokens nor a new target token were
            # produced, break to avoid an infinite loop.
            if n_accepted == 0 and not next_tok:
                break

        return "".join(output_tokens)

    # ------------------------------------------------------------------
    # Token-level API (for use with real tokeniser-based clients)
    # ------------------------------------------------------------------

    def decode_tokens(
        self,
        prompt_tokens: List[str],
        max_tokens: int,
        K: int = 5,
    ) -> List[str]:
        """Token-list variant of :meth:`decode`.

        Operates on lists of string tokens rather than a single prompt
        string.  Useful when the caller already has a tokeniser.
        """
        output: List[str] = []

        def _mk_prompt(toks: List[str]) -> str:
            # Glue tokens back into a flat string for the duck-typed
            # client protocol.
            return "".join(toks)

        while len(output) < max_tokens:
            budget = min(K, max_tokens - len(output))
            draft_tokens = _call_draft(
                self._draft, _mk_prompt(prompt_tokens), n_tokens=budget
            )
            if not draft_tokens:
                _, next_tok = _call_target(
                    self._target, _mk_prompt(prompt_tokens), []
                )
                if next_tok:
                    output.append(next_tok)
                break

            self._proposed += len(draft_tokens)
            n_accepted, next_tok = _call_target(
                self._target, _mk_prompt(prompt_tokens), draft_tokens
            )
            self._accepted += n_accepted

            for i in range(n_accepted):
                output.append(draft_tokens[i])
            if next_tok:
                output.append(next_tok)

            prompt_tokens = prompt_tokens + output
            if n_accepted == 0 and not next_tok:
                break

        return output


# ---------------------------------------------------------------------------
# PromptLookup — n-gram speculation (§5.5 item 4)
# ---------------------------------------------------------------------------


class PromptLookup:
    """Prompt-lookup / n-gram speculation.

    Zero model calls.  Finds repeated n-grams in the prompt to suggest
    likely continuations at no computational cost.

    The algorithm:
      1. Split the prompt into word tokens.
      2. For each suffix length L (from longest to shortest), find a prior
         occurrence of that L-word suffix.
      3. If found, collect the text that followed the prior occurrence as a
         suggestion.
      4. Return up to *n* unique suggestions, sorted shortest-first.

    This is especially effective for structured output scenarios (§5.5 item 4):
    world-book references, formatted dialogue blocks, template-driven output.
    """

    def suggest(self, prompt: str, n: int = 4) -> List[str]:
        """Find possible continuation strings by n-gram lookup.

        Args:
            prompt: The input text to search for repeated n-grams.
            n: Maximum number of suggestions to return.

        Returns:
            Up to *n* unique continuation strings, sorted shortest-first.
            Empty list when no n-gram match is found.
        """
        words = prompt.split()
        if len(words) < 3:
            return []

        suggestions: List[str] = []
        # Longest n-gram we'll search for — at most half the prompt length,
        # capped at 10 words for practicality.
        max_ngram = min(len(words) // 2, 10)

        for ngram_len in range(max_ngram, 1, -1):
            if len(suggestions) >= n:
                break
            suffix = words[-ngram_len:]
            # Search for prior non-overlapping occurrence
            search_end = len(words) - ngram_len
            for i in range(search_end):
                if words[i : i + ngram_len] == suffix:
                    # The follow region must not overlap with the suffix
                    follow_end = min(i + ngram_len + ngram_len, search_end)
                    if follow_end <= i + ngram_len:
                        continue
                    follow = " ".join(words[i + ngram_len : follow_end])
                    if follow and follow not in suggestions:
                        suggestions.append(follow)
                    if len(suggestions) >= n:
                        break

        # Sort shortest-first so the caller gets the most conservative
        # suggestion first.
        suggestions.sort(key=len)
        return suggestions


# ---------------------------------------------------------------------------
# Public surface
# ---------------------------------------------------------------------------

__all__ = [
    "SpeculativeDecoder",
    "PromptLookup",
]


# ---------------------------------------------------------------------------
# Self-check (python -m theater.speculative_decode)
# ---------------------------------------------------------------------------


def _selftest() -> None:  # pragma: no cover
    # --- PromptLookup smoke ---
    pl = PromptLookup()
    text = "the quick brown fox jumps over the lazy dog the quick brown"
    sugg = pl.suggest(text, n=2)
    # "the quick brown" appears twice; the prior occurrence is at index 0,
    # followed by "fox jumps over".
    assert "fox jumps over" in sugg, f"expected 'fox jumps over', got {sugg}"

    # No match when nothing repeats
    assert pl.suggest("hello world foo bar baz") == []

    # Very short prompt
    assert pl.suggest("hello world") == []

    # --- SpeculativeDecoder smoke (with inline mocks) ---
    class _MockDraft:
        def __init__(self, tokens: List[str]):
            self._tokens = tokens
            self._pos = 0

        def generate(self, prompt: str, *, n_tokens: int) -> List[str]:
            end = self._pos + n_tokens
            chunk = self._tokens[self._pos:end]
            self._pos = end
            return chunk

    class _MockTarget:
        def __init__(self, tokens: List[str]):
            self._tokens = tokens
            self._pos = 0

        def verify(self, prompt: str, draft_tokens: List[str]) -> Tuple[int, str]:
            n = 0
            for dt in draft_tokens:
                if self._pos < len(self._tokens) and dt == self._tokens[self._pos]:
                    n += 1
                    self._pos += 1
                else:
                    break
            if self._pos < len(self._tokens):
                nxt = self._tokens[self._pos]
                self._pos += 1
            else:
                nxt = ""
            return n, nxt

    draft = _MockDraft(["A", "B", "C", "D", "E"])
    target = _MockTarget(["A", "B", "X", "D", "E"])  # diverges at 3rd token
    decoder = SpeculativeDecoder(draft, target)
    out = decoder.decode("", max_tokens=5, K=3)
    # draft proposes [A,B,C], target accepts [A,B], rejects C, generates X
    # => output so far: [A,B,X]
    # next iter: draft proposes [D,E], target accepts [D,E], bonus token ...
    assert out == "ABXDE", f"got {out!r}"
    assert decoder.accept_rate > 0.0

    # With perfect alignment the rate should be higher.
    draft2 = _MockDraft(["A", "B", "C"])
    target2 = _MockTarget(["A", "B", "C", "D"])
    decoder2 = SpeculativeDecoder(draft2, target2)
    decoder2.decode("", max_tokens=4, K=3)
    # All 3 draft tokens accepted, 3/3 = 1.0
    import math
    assert math.isclose(decoder2.accept_rate, 1.0), (
        f"expected 1.0, got {decoder2.accept_rate}"
    )

    print("ok")


if __name__ == "__main__":  # pragma: no cover
    _selftest()
    print("SpeculativeDecode self-check: PASS")
