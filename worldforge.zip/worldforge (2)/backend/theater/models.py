from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


def _clean(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, list):
        return [_clean(item) for item in value]
    if isinstance(value, dict):
        return {key: _clean(item) for key, item in value.items()}
    return value


class Serializable:
    def to_dict(self) -> Dict[str, Any]:
        return _clean(asdict(self))


@dataclass
class Task(Serializable):
    task_id: str
    type: str
    priority: int
    payload: Dict[str, Any]
    status: str = "queued"


@dataclass
class WorldBookPatch(Serializable):
    title: str
    content: str
    source: str
    provenance: str = "canonical_event"


@dataclass
class WorldBookEntry(Serializable):
    title: str
    content: str
    source: str
    approved_by: str
    provenance: str = "canonical_event"


# §17 P0 事实隔离: WorldBookEntry.provenance 的合法取值。世界事实 ≠ 角色相信的
# 事实 —— 下一拍叙事按 provenance 筛选, 禁止 LLM prose 污染世界状态。
WORLDBOOK_PROVENANCE_TYPES = (
    "canonical_event",       # 内核确定性事实 (world_tick / three_body kernel / outcome)
    "narrative_rendering",    # LLM 文学表达 (narration / director beat)
    "agent_observation",      # 角色观察
    "agent_belief",           # 角色信念 (世界事实 ≠ 角色相信的事实)
    "rumor",                  # 谣言
    "lore",                   # 设定 (导入的 lorebook)
)


@dataclass
class CharacterPatch(Serializable):
    character_id: str
    name: str
    summary: str
    source: str
    personality: str = ""
    appearance: str = ""
    sample_line: str = ""
    possessed: bool = False
    possessed_by: Optional[str] = None
    ai_subconscious: str = ""
    pending_ai_actions: List[Dict[str, Any]] = field(default_factory=list)
    possession_limit: Dict[str, Any] = field(default_factory=lambda: {"max_duration": 3600, "allowed_actions": ["move", "speak", "inspect"]})


@dataclass
class CharacterEntry(CharacterPatch):
    approved_by: str = "science_director"


@dataclass
class SceneObjectPatch(Serializable):
    """An interactive scene object — a first-class citizen with state,
    properties and affordances (Inform-7/immersive-sim style). Lets an LLM
    reason about "can the berserker break this table" from the object's data,
    and lets the consequence ("table is broken") persist.
    """
    object_id: str
    name: str
    kind: str = "prop"            # furniture / container / prop / … (kind defaults)
    location: str = ""            # scene/room id (containment relation)
    state: str = "intact"         # current mutable state: intact|broken|burning|…
    source: str = "director_group"
    material: str = "wood"        # wood|metal|glass|stone … (drives rule resolution)
    durability: int = 3           # 0..N; hits reduce; 0 → breaks
    is_destructible: bool = True
    is_takeable: bool = False
    is_movable: bool = True
    affordances: List[str] = field(default_factory=lambda: ["inspect", "push"])


@dataclass
class SceneObjectEntry(SceneObjectPatch):
    approved_by: str = "science_director"


@dataclass
class ScienceApproval(Serializable):
    approved: bool
    director_id: str = "science_director"
    reasons: List[str] = field(default_factory=list)


@dataclass
class StateSnapshot(Serializable):
    worldbook: List[WorldBookEntry] = field(default_factory=list)
    characters: List[CharacterEntry] = field(default_factory=list)
    objects: List[SceneObjectEntry] = field(default_factory=list)


@dataclass
class DispatchResult(Serializable):
    session_id: str
    intent: str
    director_brief: str
    dialogue: str
    tasks: List[Task]
    world_updates: List[WorldBookEntry]
    character_updates: List[CharacterEntry]
    model_trace: Dict[str, Any]
    warnings: List[str] = field(default_factory=list)
