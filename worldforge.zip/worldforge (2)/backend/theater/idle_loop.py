"""Idle loop — the world advances itself while the player is silent (spec §13.4).

When the user stops interacting, the world should not freeze; it keeps living.
But an *offline* world must not run the whole story to its end — there is a
saturation cap on how many beats it may advance without the player. When the
player returns, we hand them a "你离开时发生了……" regression summary so they can
catch up.

This module is deliberately pure: it owns only a counter, and it drives the
orchestrator through its existing public surface
(``set_world`` / ``world_tick`` / ``seconds_since_activity`` /
``state_store.snapshot``). No dispatcher, agent, or server internals are
touched. The silence *timer* is the orchestrator's own ``_last_activity``
(see ``seconds_since_activity``) — this module no longer keeps a duplicate, so
there is one source of truth for "how long has the player been quiet" shared
by the background WorldClock thread and any in-process caller (调研① 方案 A:
消除重复计时器).
"""

from __future__ import annotations

from typing import Callable


class IdleLoop:
    """Advance a single world autonomously during player silence.

    Bound to one ``world_id``: every tick re-points the orchestrator at that
    world before advancing, so the loop is safe to run per-world.

    The silence timer is **delegated** to ``orchestrator.seconds_since_activity``
    so the orchestrator's ``_last_activity`` (reset on every player dispatch)
    is the single source of truth. This class owns only the saturation counter.

    Parameters
    ----------
    orchestrator:
        Anything exposing ``set_world(world_id)``, ``world_tick()``,
        ``seconds_since_activity()`` and a ``state_store`` with
        ``snapshot().worldbook``.
    world_id:
        The world this loop is responsible for.
    idle_threshold:
        Seconds of player silence before the world may advance a beat.
    max_advances:
        Saturation cap — the most beats the world advances during one silent
        stretch. Prevents an offline world from running the story to its end.
    """

    def __init__(
        self,
        orchestrator,
        world_id: str,
        idle_threshold: float = 30,
        max_advances: int = 5,
    ):
        self.orchestrator = orchestrator
        self.world_id = world_id
        self.idle_threshold = idle_threshold
        self.max_advances = max_advances
        self._advances: int = 0

    @property
    def advances_count(self) -> int:
        """Beats advanced during the current silent stretch."""
        return self._advances

    def seconds_idle(self) -> float:
        """How long the player has been silent — delegated to the orchestrator
        so there is one shared idle timer (no duplicate clock)."""
        return self.orchestrator.seconds_since_activity()

    def on_user_activity(self) -> None:
        """The player did something — reset the saturation counter so the next
        idle stretch may advance afresh. The silence *timer* itself is reset
        by the orchestrator's dispatch path (it owns ``_last_activity``)."""
        self._advances = 0

    def tick(self):
        """Advance the world one beat iff the player has been silent past the
        threshold and the saturation cap has not been reached.

        Returns the beat produced by ``orchestrator.world_tick()``, or ``None``
        when no advance was warranted (still active, or saturated).
        """
        if self._advances >= self.max_advances:
            return None
        if self.seconds_idle() < self.idle_threshold:
            return None
        self.orchestrator.set_world(self.world_id)
        result = self.orchestrator.world_tick()
        self._advances += 1
        return result

    def offline_summary(
        self, llm_fn: Callable[[str], str], max_entries: int = 5
    ) -> str:
        """Summarize what the world did while the player was away.

        Reads the most recent worldbook entries for this world and asks
        ``llm_fn`` to turn them into a short second-person recap. Returns an
        empty string when there is nothing to report.
        """
        self.orchestrator.set_world(self.world_id)
        snapshot = self.orchestrator.state_store.snapshot()
        worldbook = snapshot.worldbook or []
        recent = worldbook[-max_entries:]
        if not recent:
            return ""
        history = "；".join(f"{entry.title}: {entry.content}" for entry in recent)
        prompt = (
            "用户离开期间，世界自主推进了以下进展："
            f"{history}。"
            "请用第二人称生成一段简短的回归摘要，以“你离开时发生了……”开头，"
            "只概括关键变化，不要逐条罗列。"
        )
        return llm_fn(prompt)
