"""Three-body narration layer (architecture spec §8.2 — 红线: LLM 只翻译数字).

The deterministic :class:`~theater.kernels.three_body.ThreeBodyKernel` produces
the ground truth: orbits, light series, Lyapunov exponent, chaotic-era
boundaries, survival verdicts, evacuation proof.  This module turns those
numbers into prose.  It **never** computes physics and **never** adjudicates
an outcome — spec §8.2 red line:

    科学导演（LLM）不得计算物理、不得裁决观测结果。物理是确定性内核算出的
    地面真相，LLM 只把数字翻译成剧情。一旦让 LLM 决定"这次预测成功了没有"，
    逃离就失去必然性。

Structured kernel fields are handed to the LLM with a system prompt that
forbids inventing numbers or flipping verdicts. The prose is checked by
``_check_verdict_consistency``. Missing model access, an empty response, or a
contradiction raises; this module never substitutes template prose.

``llm_fn`` signature: ``llm_fn(prompt: str) -> str``.  If your preferred
coder model (e.g. the configured LLM) produces thin prose, point ``llm_fn`` at the
DGX-Spark gemma service instead — same ``llm_fn(prompt)->str`` contract, the
only change is the HTTP endpoint the callable hits (e.g. a gemma model
served on the Spark node at ``:1234``).  Nothing in this module changes.

Pure stdlib; no numpy / scipy dependency at this layer.
"""

from __future__ import annotations

import os
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from .nli_guard import NliGuard, outcome_source


__all__ = ["ThreeBodyNarrator"]


# ---------------------------------------------------------------------------
# Era label helpers
# ---------------------------------------------------------------------------

_ERA_LABEL = {"stable": "恒纪元", "chaotic": "乱纪元"}


def _era_kind_at(timeline: Any, t: float) -> str:
    """Return ``"stable"`` / ``"chaotic"`` for time *t* on *timeline*.

    Falls back to ``"stable"`` when *t* is outside every baked segment (the
    kernel itself does the same).  Never raises.
    """
    eras = getattr(timeline, "eras", None) or []
    for era in eras:
        start = getattr(era, "start", None)
        end = getattr(era, "end", None)
        if start is None or end is None:
            continue
        if start <= t < end:
            return getattr(era, "kind", "stable")
    return "stable"


def _light_at(timeline: Any, t_index: int) -> float:
    """Total illumination (sum over stars) at sample *t_index*.

    Tolerates either a (n,3) array-like or a flat sequence; never raises.
    """
    series = getattr(timeline, "light_series", None)
    if series is None:
        return 0.0
    try:
        row = series[t_index]
    except (IndexError, TypeError, KeyError):
        return 0.0
    total = 0.0
    try:
        for v in row:
            total += float(v)
    except TypeError:
        try:
            return float(row)
        except (TypeError, ValueError):
            return 0.0
    return total


def _fmt(value: Any, digits: int = 3) -> str:
    """Format a number for prose; non-numbers → ``str(value)``."""
    try:
        f = float(value)
    except (TypeError, ValueError):
        return str(value)
    return f"{f:.{digits}f}"


# ---------------------------------------------------------------------------
# Sparkline (§11.5 文明计数曲线)
# ---------------------------------------------------------------------------

_SPARK_BLOCKS = "▁▂▃▄▅▆▇█"


def _sparkline(values: Sequence[float]) -> str:
    """Render a sequence of scalars as an 8-level block sparkline.

    All-equal sequences collapse to the middle block so the curve is still
    visible.  Empty input → empty string.
    """
    nums: List[float] = []
    for v in values:
        try:
            nums.append(float(v))
        except (TypeError, ValueError):
            continue
    if not nums:
        return ""
    lo = min(nums)
    hi = max(nums)
    if hi <= lo:
        # Degenerate: pick the middle block so the curve isn't a flat line
        # of the lowest glyph (which reads as "nothing happened").
        return _SPARK_BLOCKS[len(_SPARK_BLOCKS) // 2] * len(nums)
    out: List[str] = []
    span = hi - lo
    for v in nums:
        idx = int(round((v - lo) / span * (len(_SPARK_BLOCKS) - 1)))
        idx = max(0, min(len(_SPARK_BLOCKS) - 1, idx))
        out.append(_SPARK_BLOCKS[idx])
    return "".join(out)


# ---------------------------------------------------------------------------
# ThreeBodyNarrator
# ---------------------------------------------------------------------------


class ThreeBodyNarrator:
    """Translate deterministic three-body kernel output into prose.

    Parameters
    ----------
    llm_fn:
        Required ``llm_fn(prompt: str) -> str`` for ``narrate_*`` calls. The
        LLM renders the given fields into prose and its output is
        consistency-checked. Missing or rejected output raises.
    temperature:
        Recorded into the prompt as a sampling hint to the LLM.  The actual
        sampling temperature is controlled server-side by ``llm_fn``'s
        caller; this parameter only shapes the prompt wording.
    seed:
        Reserved for compatibility with existing construction sites.

    Note on the LLM backend
    -----------------------
    If ``the configured LLM`` prose feels thin, point ``llm_fn`` at the the configured
    ``gemma`` service (same ``:1234`` style endpoint, same
    ``llm_fn(prompt)->str`` contract).  Nothing in this module changes —
    only the HTTP endpoint the callable hits.
    """

    def __init__(
        self,
        llm_fn: Optional[Callable[[str], str]] = None,
        temperature: float = 0.8,
        seed: Optional[int] = None,
        nli_guard: Optional["NliGuard"] = None,
    ) -> None:
        self._llm_fn = llm_fn
        self._temperature = float(temperature)
        self._seed = seed
        # NLI 双向蕴含守卫 (Q6 一级方案). None = 未注入, 由 _get_nli_guard()
        # 按环境变量惰性探测. 探测失败 (无 torch/无 Spark 凭据) → None →
        # _check_outcome_consistency 回退关键词匹配层.
        self._nli_guard = nli_guard

    # -- system prompt -------------------------------------------------------

    def _build_system_prompt(self) -> str:
        """Teach the LLM the §8.2 red line: translate, never adjudicate."""
        return (
            "你是三体世界的叙述者（科学导演）。架构红线 §8.2：你只能把确定性内核"
            "给出的数字翻译成 1-3 句剧情旁白。\n"
            "禁止行为：\n"
            "  - 禁止臆造任何未在输入中给出的物理数值（轨道、温度、λ、视界等）。\n"
            "  - 禁止改写文明存亡判定（survived/destroyed 由内核裁决，你只能复述）。\n"
            "  - 禁止改写逃离证明的结论（evac_possible 为 True 时必须说\"逃离可行\"，"
            "为 False 时必须说\"无法逃离/长期不可能幸存\"）。\n"
            "  - 禁止编造新的文明序号、新的纪元时刻、新的科技等级。\n"
            "你可以做的：润色措辞、营造氛围（恒纪元=温暖沐浴，乱纪元=脱水毁灭），"
            "但所有事实必须来自输入字段。\n\n"
            "示例 1\n"
            "输入: era_type=乱纪元 t=12.50 total_light=0.83 lambda=0.003\n"
            "输出: 乱纪元降临，三颗太阳在天穹无序跃动，大地在烈日与严寒间脱水。"
            "光照骤至 0.83，文明瑟缩于地下。\n\n"
            "示例 2\n"
            "输入: civ_index=4 survived=False tech_level=2.0 T_predict=8.30\n"
            "输出: 第 4 号文明在科技水平 2.0 下走完了它的一生。预测视界仅 8.30，"
            "未能触及下一次乱纪元，文明在灾难中重启，文明计数 +1。\n\n"
            "示例 3\n"
            "输入: evac_possible=False mean_chaos_gap=120.0 T_pred_best=45.0 "
            "max_tech=20.0\n"
            "输出: 理性已证明：即便倾尽科技至 20.0 级，预测视界仍止步于 45.0，"
            "远短于乱纪元 120.0 的平均间隔。长期不可能幸存——逃离，是唯一的出路。\n"
        )

    def _call_llm(self, user_prompt: str) -> Optional[str]:
        """Call the LLM if available; return ``None`` on any failure.

        ``llm_fn`` is the single-arg ``llm_fn(prompt) -> str`` contract
        (:meth:`OpenAILLMClient.as_text_fn`).
        """
        if self._llm_fn is None:
            return None
        try:
            raw = self._llm_fn(user_prompt)
        except Exception:
            return None
        if not isinstance(raw, str):
            return None
        text = raw.strip()
        return text or None

    # -- public narrate API --------------------------------------------------

    def narrate_era(self, timeline: Any, t_index: int) -> str:
        """Translate one moment of the baked timeline into 1-3 sentences.

        Reads ``timeline.t``, ``timeline.light_series``, ``timeline.eras``
        and ``timeline.lambda_`` at sample *t_index*.  Only those fields
        are referenced — nothing is invented.
        """
        t_grid = getattr(timeline, "t", None)
        try:
            t_val = float(t_grid[t_index]) if t_grid is not None else float(t_index)
        except (IndexError, TypeError, ValueError):
            t_val = float(t_index)
        kind = _era_kind_at(timeline, t_val)
        era_label = _ERA_LABEL.get(kind, "恒纪元")
        total_light = _light_at(timeline, t_index)
        lam = getattr(timeline, "lambda_", 0.0)
        try:
            lam = float(lam)
        except (TypeError, ValueError):
            lam = 0.0

        fields = {
            "era_type": era_label,
            "t": _fmt(t_val, 2),
            "total_light": _fmt(total_light, 3),
            "lambda": _fmt(lam, 5),
        }
        if self._llm_fn is None:
            raise RuntimeError("需配置 LLM 生成叙事 (narrate_era)")
        user_prompt = self._build_user_prompt(fields, task="era")
        narrated = self._call_llm(user_prompt)
        if narrated is None:
            raise RuntimeError("LLM 调用失败或返回空，无法生成叙事 (narrate_era)")
        return narrated

    def narrate_civilization_cycle(
        self,
        civ_index: int,
        survived: bool,
        tech_level: float,
        prediction_horizon_val: float,
    ) -> str:
        """Narrate one civilization cycle (rise + survival/destruction)."""
        fields = {
            "civ_index": int(civ_index),
            "survived": bool(survived),
            "tech_level": _fmt(tech_level, 2),
            "T_predict": _fmt(prediction_horizon_val, 2),
        }
        if self._llm_fn is None:
            raise RuntimeError("需配置 LLM 生成叙事 (narrate_civilization_cycle)")
        user_prompt = self._build_user_prompt(fields, task="civ_cycle")
        narrated = self._call_llm(user_prompt)
        if narrated is None:
            raise RuntimeError("LLM 调用失败或返回空，无法生成叙事 (narrate_civilization_cycle)")
        # The kernel verdict (survived) is ground truth; if the LLM
        # flips it, reject.
        if not self._civ_consistent(narrated, survived):
            raise RuntimeError(
                "LLM 翻转了文明存亡判定 (survived={})，一致性守卫拒绝".format(survived)
            )
        return narrated

    def narrate_evacuation_verdict(self, verdict: Dict[str, Any]) -> str:
        """Dramatise the evacuation proof verdict.

        Red-line guard: *verdict* MUST come from the kernel and carry an
        ``evac_possible`` key.  The narration's "can we escape?" conclusion
        MUST agree with ``verdict['evac_possible']``; contradictory output is
        rejected.
        """
        if not isinstance(verdict, dict) or "evac_possible" not in verdict:
            raise AssertionError(
                "evacuation verdict must be a kernel-produced dict carrying "
                "the 'evac_possible' key (§8.2 red line: narration must "
                "translate kernel truth, not invent it)"
            )
        evac_possible = bool(verdict["evac_possible"])
        fields = {
            "evac_possible": evac_possible,
            "mean_chaos_gap": _fmt(verdict.get("mean_chaos_gap", 0.0), 2),
            "T_pred_best": _fmt(verdict.get("T_pred_best", 0.0), 2),
            "max_tech": _fmt(verdict.get("max_tech", 0.0), 2),
            "lambda": _fmt(verdict.get("lambda_", 0.0), 5),
        }
        if self._llm_fn is None:
            raise RuntimeError("需配置 LLM 生成叙事 (narrate_evacuation_verdict)")
        user_prompt = self._build_user_prompt(fields, task="evac")
        narrated = self._call_llm(user_prompt)
        if narrated is None:
            raise RuntimeError("LLM 调用失败或返回空，无法生成叙事 (narrate_evacuation_verdict)")
        if not self._check_verdict_consistency(narrated, evac_possible):
            raise RuntimeError(
                "LLM 翻转了逃离证明结论 (evac_possible={})，一致性守卫拒绝".format(evac_possible)
            )
        return narrated

    def narrate_chaos_gap(
        self,
        mean_chaos_gap: float,
        prediction_horizon_val: float,
        tech_level: float,
    ) -> str:
        """Narrate the cognitive shock of the Lyapunov wall."""
        fields = {
            "mean_chaos_gap": _fmt(mean_chaos_gap, 2),
            "T_predict": _fmt(prediction_horizon_val, 2),
            "tech_level": _fmt(tech_level, 2),
        }
        if self._llm_fn is None:
            raise RuntimeError("需配置 LLM 生成叙事 (narrate_chaos_gap)")
        user_prompt = self._build_user_prompt(fields, task="chaos_gap")
        narrated = self._call_llm(user_prompt)
        if narrated is None:
            raise RuntimeError("LLM 调用失败或返回空，无法生成叙事 (narrate_chaos_gap)")
        return narrated

    def summarize_timeline(self, timeline: Any) -> str:
        """Epic summary of a whole baked timeline (§11.5 文明计数曲线)."""
        civ_curve = self._extract_civ_curve(timeline)
        n_civs = len(civ_curve)
        peak = max(civ_curve) if civ_curve else 0
        spark = _sparkline(civ_curve)
        lam = getattr(timeline, "lambda_", 0.0)
        try:
            lam = float(lam)
        except (TypeError, ValueError):
            lam = 0.0
        fields: Dict[str, Any] = {
            "n_civilizations": n_civs,
            "peak_civ_count": peak,
            "lambda": _fmt(lam, 5),
            "sparkline": spark,
        }
        if self._llm_fn is None:
            raise RuntimeError("需配置 LLM 生成叙事 (summarize_timeline)")
        user_prompt = self._build_user_prompt(fields, task="summary")
        narrated = self._call_llm(user_prompt)
        if narrated is None:
            raise RuntimeError("LLM 调用失败或返回空，无法生成叙事 (summarize_timeline)")
        if spark and spark not in narrated:
            raise RuntimeError(
                "LLM 删除了 sparkline ({!r})，一致性守卫拒绝".format(spark)
            )
        return narrated

    # -- outcome narration: comprehensive story arcs (§8.2 upgrade) ---------

    def narrate_outcome(
        self,
        outcome: Any,
        history: str = "",
        llm_fn: Optional[Callable[[str], str]] = None,
    ) -> str:
        """Dramatise a diversified kernel ``Outcome`` into a story arc.

        Unlike the single-verdict translators above, this method
        *synthesises* every kernel field the outcome carries — kind, cause,
        tech_level, decision_quality, chaotic-era history, civilisation
        count, planet orbital energy — into one imaginative scene with
        concrete characters and emotional tension (per user feedback: the
        LLM should do comprehensive story deduction, not single-translation).

        Six arcs, keyed on ``outcome['kind']`` (and tech_level for
        ``planet_ejected``):

          - ``evacuated`` / ``planet_ejected``+high-tech → 流浪弧 (wandering):
            封存的文明离开三体星系，宇宙中流浪，等待恒星俘获重新焕发.
          - ``planet_ejected``+low-tech → 失家弧 (lost home): 行星被甩出，
            文明随漂泊行星在黑暗中封存或消亡.
          - ``destroyed_chaos`` → 毁灭弧.
          - ``destroyed_decision`` → 悲剧弧 (聚焦错误决策的瞬间).
          - ``destroyed_resource`` → 耗尽弧.
          - ``survived`` → 幸存弧.

        Red-line guard: ``_check_outcome_consistency`` rejects any LLM prose
        that flips the outcome ``kind`` (e.g. calling an ``evacuated``
        outcome "毁灭"). Rejected prose raises and is never persisted.

        ``llm_fn`` overrides the instance LLM for one call (tests use this);
        ``None`` uses the instance LLM.
        """
        kind, tech, fields = self._outcome_fields(outcome)
        llm = llm_fn if llm_fn is not None else self._llm_fn
        if llm is None:
            raise RuntimeError(
                "需配置 LLM 生成叙事 (narrate_outcome requires llm_fn)"
            )
        user_prompt = self._build_outcome_prompt(fields, history)
        narrated = None
        try:
            try:
                raw = llm(user_prompt)
            except TypeError:
                raw = llm("你是三体世界的史诗叙述者。", user_prompt)
            if isinstance(raw, str):
                narrated = raw.strip() or None
        except Exception:
            narrated = None
        if narrated is None:
            raise RuntimeError(
                "LLM 调用失败或返回空，无法生成叙事"
            )
        if not self._check_outcome_consistency(
            narrated, kind, tech, fields=fields,
        ):
            raise RuntimeError(
                f"LLM 输出与内核裁决矛盾 (kind={kind})，一致性守卫拒绝"
            )
        return narrated

    @staticmethod
    def _outcome_fields(
        outcome: Any,
    ) -> Tuple[str, float, Dict[str, Any]]:
        """Normalize a kernel outcome for prompting and consistency checks."""
        od = outcome.as_dict() if hasattr(outcome, "as_dict") else dict(outcome)
        kind = str(od.get("kind", "survived"))
        try:
            tech = float(od.get("tech_level", 0.0) or 0.0)
        except (TypeError, ValueError):
            tech = 0.0
        fields: Dict[str, Any] = {
            "kind": kind,
            "cause": str(od.get("cause", "") or ""),
            "detail": str(od.get("detail", "") or ""),
            "t": _fmt(od.get("t", 0.0), 2),
            "tech_level": _fmt(tech, 2),
            "delta_0": _fmt(od.get("delta_0", 0.0), 3),
            "T_predict": _fmt(od.get("T_predict", 0.0), 2),
            "next_chaos": (
                _fmt(od.get("next_chaos"), 2)
                if od.get("next_chaos") is not None else "无"
            ),
            "planet_energy": (
                _fmt(od.get("planet_energy"), 4)
                if od.get("planet_energy") is not None else "—"
            ),
            "decision_quality": str(
                od.get("decision_quality", "neutral") or "neutral"
            ),
            "civ_count": (
                od.get("civ_count")
                if od.get("civ_count") is not None else "—"
            ),
        }
        return kind, tech, fields

    def _build_outcome_prompt(self, fields: Dict[str, Any], history: str) -> str:
        """Build the综合演绎 prompt — many fields + few-shot arcs."""
        sys_prompt = (
            "你是三体世界的史诗叙述者（科学导演）。架构红线 §8.2：物理结局由确定性内核"
            "裁定，你只负责**综合演绎**——把内核给出的多个字段（结局类型/原因/科技等级/"
            "决策质量/乱纪元历史/文明计数/行星能量）编织成一个有想象力、有具体人物、"
            "有情感张力的场景（约 150-300 字中文）。\n"
            "禁止行为：\n"
            "  - 禁止改写结局类型（kind 字段）。evacuated 不能说成 destroyed，"
            "planet_ejected 不能说成安稳幸存，destroyed_* 不能说成幸存。\n"
            "  - 禁止臆造未在输入中给出的物理数值。\n"
            "  - 禁止编造新的文明序号或纪元时刻。\n"
            "你可以做的：围绕结局类型选择叙事弧——\n"
            "  - 流浪弧（evacuated / planet_ejected+高科技）：封存的文明离开苦难的"
            "三体星系，在宇宙中流浪，等待某颗恒星的引力俘获而重新焕发生机。\n"
            "  - 失家弧（planet_ejected+低科技）：行星被甩出，文明随漂泊行星在光照"
            "衰减的黑暗中封存或消亡。\n"
            "  - 毁灭弧（destroyed_chaos）/ 悲剧弧（destroyed_decision，聚焦错误"
            "决策的瞬间）/ 耗尽弧（destroyed_resource）/ 幸存弧（survived）。\n\n"
            "示例 1（流浪弧）\n"
            "输入: kind=evacuated tech_level=9.50 civ_count=183\n"
            "输出: 最后一艘方舟点燃了聚变尾焰，陆远从舷窗回望那三颗纠缠了文明一百八十"
            "三代的太阳。封存的文明随着这个世界离开了苦难的三体星系，在宇宙中流浪，"
            "等待着被某颗恒星的引力俘获而重新焕发生机。苏青把那块上一文明留下的晶体板"
            "贴在胸前——它是他们唯一的家谱。\n\n"
            "示例 2（失家弧）\n"
            "输入: kind=planet_ejected tech_level=1.20 planet_energy=0.0034\n"
            "输出: 没有预兆，行星在三颗太阳的引力拔河中获得了逃逸速度，被甩出了星系。"
            "光照一点点衰减，天空从炽白褪向墨蓝。低科技的文明无力造船，只能把最后一代"
            "人封进脱水仓，随这颗漂泊的行星滑入永夜——或许某一天，一颗陌生恒星的引力"
            "会再次唤醒他们。\n\n"
            "示例 3（悲剧弧）\n"
            "输入: kind=destroyed_decision tech_level=4.00 decision_quality=mismatched\n"
            "输出: 议会投票通过了囤积法案——在乱纪元的边缘，他们选择了仓库而非脱水仓。"
            "陆远在观测台上嘶吼无人理会。三天后，三颗太阳无序跃动，烈日与严寒交替撕扯"
            "大地，仓库里的粮食化为灰烬。这是文明的自杀，不是灾难的谋杀。"
        )
        lines = [sys_prompt, ""]
        lines.append(f"[采样温度提示: {self._temperature:.2f}]")
        lines.append("任务: 根据下列内核结局字段综合演绎一个场景（不要逐字段翻译）。")
        lines.append("输入字段:")
        for k, v in fields.items():
            lines.append(f"  {k}={v}")
        if history:
            lines.append("")
            lines.append(f"世界书最近进展(用于连贯人物,不要重复):\n{history}")
        lines.append("")
        lines.append("只输出 150-300 字剧情旁白，不要输出字段名、不要输出 JSON。")
        return "\n".join(lines)

    # -- outcome consistency guard (red line) -------------------------------

    # Keyword families per outcome kind.  A narration is *inconsistent* (→
    # fall back) only when it carries a forbid-signal WITHOUT any need-signal
    # for that kind — mirroring the lenient style of
    # ``_check_verdict_consistency``.  Ambiguous prose is accepted.
    _OUTCOME_KEYWORDS: Dict[str, Dict[str, Tuple[str, ...]]] = {
        "survived": {
            "need": ("幸存", "存活", "存续", "延续", "保住", "脱水备灾", "度过"),
            "forbid": ("灭绝", "毁灭", "覆灭", "终结", "灭亡", "甩出", "逃离",
                       "流浪", "离开三体"),
        },
        "destroyed_chaos": {
            "need": ("毁灭", "灭绝", "覆灭", "终结", "重启", "灭亡", "废墟", "崩塌"),
            "forbid": ("幸存", "存活", "存续", "延续", "逃离", "流浪", "甩出"),
        },
        "destroyed_decision": {
            "need": ("毁灭", "灭绝", "覆灭", "终结", "重启", "灭亡", "决策", "错误",
                     "错判", "自杀"),
            "forbid": ("幸存", "存活", "存续", "延续", "逃离", "流浪", "甩出"),
        },
        "destroyed_resource": {
            "need": ("毁灭", "灭绝", "覆灭", "终结", "重启", "灭亡", "耗尽", "枯竭",
                     "资源", "饥荒"),
            "forbid": ("幸存", "存活", "存续", "延续", "逃离", "流浪", "甩出"),
        },
        "planet_ejected": {
            "need": ("甩出", "抛射", "漂泊", "流浪", "俘获", "失去", "飘", "逃逸速度",
                     "离开"),
            "forbid": ("安稳幸存", "存续于三体", "幸存于三体", "恒纪元延续"),
        },
        "evacuated": {
            "need": ("逃离", "离开", "出走", "流浪", "驶向", "启程", "远航", "封存",
                     "方舟"),
            "forbid": ("灭绝", "毁灭", "覆灭", "终结", "灭亡", "无法逃离", "不可能幸存"),
        },
    }

    def _get_nli_guard(self) -> Optional[NliGuard]:
        """惰性获取 NLI 守卫: 注入的优先, 否则按环境变量探测构造一次.

        探测规则 (方案 c 混合, 不硬依赖 torch):
          - ``THEATER_NLI_MODEL`` 设置 + transformers 可 import → 本地 DeBERTa
            类 MNLI 模型后端;
          - ``THEATER_NLI_JUDGE=1`` 设置 → 构造一个 Spark LLM 判定器后端
            (凭据走 SPARK_* / THEATER_LLM_*);
          - 都没有 → None (回退关键词匹配).
        构造异常被吞掉 (LLM 未配置等) → None.
        """
        if self._nli_guard is not None:
            return self._nli_guard
        guard: Optional[NliGuard] = None
        if os.environ.get("THEATER_NLI_MODEL"):
            guard = NliGuard()
        elif os.environ.get("THEATER_NLI_JUDGE") == "1":
            try:
                from .onboarding_llm import build_llm
                client, _msg = build_llm()
                if client is not None:
                    def _judge(prompt: str) -> str:
                        return client.complete(prompt, temperature=0.0,
                                               max_tokens=8)

                    guard = NliGuard(llm_fn=_judge)
            except Exception:
                guard = None
        self._nli_guard = guard
        return self._nli_guard

    def _check_outcome_consistency(
        self, narrated: str, kind: str, tech_level: float = 0.0,
        fields: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Return True iff *narrated* does not contradict the kernel outcome.

        守卫分层 (Q6): NLI 双向蕴含 > 关键词匹配 > 无守卫.

          1. 若 NLI 后端可用 (本地 transformers 模型或 Spark LLM-judge) 且
             *fields* 给出了构造 source 所需的 outcome 字段 → 用 NLI 双向蕴含
             判定. consistent = forward=entail 且 backward=entail. 任一方向
             contradict (LLM 翻转了结局/物理真值) → 拒绝, 回退兜底.
          2. NLI 不可用 → 回退到 ``_OUTCOME_KEYWORDS`` 关键词匹配 (原逻辑,
             need/forbid 词族, 对模糊叙事宽松放行).
          3. 关键词也无匹配 (未知 kind) → 接受 (最宽松, 同旧策略).

        ``planet_ejected`` 特殊: 按 tech_level 分流浪/失家弧, 但两支共享
        ejected-planet 词汇, 单一关键词集即可.
        """
        # 1. NLI 双向蕴含层 (Q6 一级方案).
        guard = self._get_nli_guard()
        if guard is not None and guard.available() and fields is not None:
            source = outcome_source(fields)
            res = guard.check_entailment(source, narrated or "")
            return bool(res.get("consistent", False))

        # 2. 关键词匹配层 (降级路径, 保留旧逻辑).
        return self._keyword_outcome_consistent(narrated or "", kind)

    def _keyword_outcome_consistent(self, narrated: str, kind: str) -> bool:
        """关键词匹配降级层 (NLI 不可用时用).

        用 ``_OUTCOME_KEYWORDS[kind]``. 有 forbid 信号且无 need 信号对冲
        时才判不一致 (宽松, 同 ``_check_verdict_consistency``). 未知 kind
        接受模糊叙事.
        """
        kw = self._OUTCOME_KEYWORDS.get(kind)
        if kw is None:
            return True
        need = kw.get("need", ())
        forbid = kw.get("forbid", ())
        has_need = any(k in narrated for k in need)
        has_forbid = any(k in narrated for k in forbid)
        # Contradiction only when a forbid-signal is present unopposed.
        return not (has_forbid and not has_need)

    # -- beat narration: the runtime entry point (张力3 fix) ----------------

    def narrate_beat(
        self,
        event_log: List[str],
        history: str,
        llm_content: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Narrate one dispatcher beat — the runtime path (spec §8.2 红线).

        This is the single entry point the dispatcher's ``_narrate_three_body``
        calls. It consolidates the §8.2 red-line guards that previously lived
        only on the orphaned narrator (张力3: the narrator had guards + 21
        tests but the dispatcher never called it, running its own unguarded
        LLM path instead).

        Parameters
        ----------
        event_log:
            The kernel's structured event log (list of strings, as built by
            ``TheaterOrchestrator.three_body_tick``). These are ground truth.
        history:
            Recent worldbook text for continuity (read-only context).
        llm_content:
            The raw LLM output the dispatcher already fetched from its
            OpenAI-compatible endpoint (``None`` when the call failed). The
            dispatcher keeps the HTTP contract; the narrator owns parsing +
            the §8.2 guard.

        Returns ``{title, narrative, dialogue, warnings}``. Missing output,
        parse failure, or guard rejection raises; rejected prose is never
        persisted.
        """
        verdict = _kernel_verdict_from_event_log(event_log)
        if not llm_content:
            raise RuntimeError("three-body beat narration requires LLM output")
        parsed = _parse_beat_json(llm_content)

        narrative = parsed.get("narrative", "").strip()
        title = parsed.get("title", "").strip()
        dialogue = parsed.get("dialogue", "").strip()
        if not narrative:
            raise RuntimeError(
                "LLM three-body beat narration was empty or malformed"
            )

        # §8.2 red-line guards: the LLM must not flip the kernel verdict.
        if not self._civ_consistent(narrative, verdict["survived"]):
            raise RuntimeError(
                "narration flipped survival verdict; LLM output rejected "
                "(§8.2 red line)"
            )
        if not self._check_verdict_consistency(
                narrative, verdict["evac_possible"]
        ):
            raise RuntimeError(
                "narration flipped evacuation verdict; LLM output rejected "
                "(§8.2 red line)"
            )

        return {
            "title": title,
            "narrative": narrative,
            "dialogue": dialogue,
            "warnings": [],
        }

    # -- prompt builder ------------------------------------------------------

    def _build_user_prompt(self, fields: Dict[str, Any], task: str) -> str:
        """Assemble the user prompt: system prompt + fields + task hint."""
        lines = [self._build_system_prompt(), ""]
        lines.append(f"[采样温度提示: {self._temperature:.2f}]")
        lines.append("任务: " + _TASK_HINTS.get(task, "把下列字段翻译成剧情旁白。"))
        lines.append("输入字段:")
        for k, v in fields.items():
            lines.append(f"  {k}={v}")
        lines.append("")
        lines.append("只输出 1-3 句剧情旁白，不要输出字段名、不要输出 JSON。")
        return "\n".join(lines)

    # -- consistency guards (red line) --------------------------------------

    # Keywords that signal "escape IS possible" vs "escape is NOT possible".
    _POSSIBLE_KEYWORDS = (
        "逃离可行", "可以逃离", "逃离是可能的", "证明逃离", "逃离有望",
        "逃离是唯一出路", "出路已开", " evac_possible",
    )
    _IMPOSSIBLE_KEYWORDS = (
        "无法逃离", "逃离不可能", "逃离无望", "不可逃离", "不可能幸存",
        "逃离无门", "证明长期不可能", "长期不可能幸存", "无路可逃",
    )

    def _check_verdict_consistency(
        self, narrated: str, evac_possible: bool
    ) -> bool:
        """Return True iff *narrated* agrees with the kernel verdict.

        A narration agrees when it does not contradict the verdict:
          - evac_possible=True  must NOT carry an impossible-signal (unless
            it also carries a possible-signal that overrides it).
          - evac_possible=False must NOT carry a possible-signal (unless it
            also carries an impossible-signal that overrides it).
        Ambiguous narrations (neither signal) are accepted — we only fall
        back on a clear contradiction, per the §8.2 red line.
        """
        text = narrated or ""
        has_possible = any(k in text for k in self._POSSIBLE_KEYWORDS)
        has_impossible = any(k in text for k in self._IMPOSSIBLE_KEYWORDS)
        if evac_possible:
            # Contradiction: says impossible AND not possible.
            return not (has_impossible and not has_possible)
        # evac_possible is False: contradiction if says possible AND not impossible.
        return not (has_possible and not has_impossible)

    def _civ_consistent(self, narrated: str, survived: bool) -> bool:
        """Light check that the LLM did not flip the survival verdict."""
        text = narrated or ""
        survived_signals = ("幸存", "存活", "存续", "延续", "survived", "保住")
        destroyed_signals = ("灭绝", "毁灭", "重启", "终结", "灭亡", "destroyed",
                              "覆灭", "崩塌")
        has_survived = any(k in text for k in survived_signals)
        has_destroyed = any(k in text for k in destroyed_signals)
        if survived:
            return not (has_destroyed and not has_survived)
        return not (has_survived and not has_destroyed)

    # -- helpers -------------------------------------------------------------

    @staticmethod
    def _extract_civ_curve(timeline: Any) -> List[int]:
        """Pull a civilization-count curve off *timeline*.

        Supports, in order:
          * ``timeline.civ_curve``  — an explicit list of ints.
          * ``timeline.civilization_events`` — a list of objects/dicts with
            a ``kind`` field; we walk it and produce the running count
            (each ``destroyed`` bumps the count).
          * ``timeline.n_civilizations`` — a scalar; expands to a single
            trivial point.
        Returns an empty list when nothing is available.
        """
        curve = getattr(timeline, "civ_curve", None)
        if curve is not None:
            try:
                return [int(v) for v in curve]
            except (TypeError, ValueError):
                pass
        events = getattr(timeline, "civilization_events", None)
        if events:
            counts: List[int] = []
            running = 0
            for ev in events:
                kind = None
                if isinstance(ev, dict):
                    kind = ev.get("kind")
                else:
                    kind = getattr(ev, "kind", None)
                if kind == "destroyed":
                    running += 1
                counts.append(running if running > 0 else 1)
            if counts:
                return counts
        n = getattr(timeline, "n_civilizations", None)
        if n is not None:
            try:
                return [int(n)]
            except (TypeError, ValueError):
                pass
        return []


# Task hints surfaced to the LLM in the user prompt.
_TASK_HINTS: Dict[str, str] = {
    "era": "把该时刻的纪元/光照/λ翻译成 1-3 句剧情旁白。",
    "civ_cycle": "把这个文明周期的兴亡翻译成 1-3 句剧情旁白。survived 字段决定存亡，不得改写。",
    "evac": "把逃离证明的判决翻译成 1-3 句戏剧化旁白。evac_possible 决定结论方向，不得改写。",
    "chaos_gap": "把混沌墙的认知冲击翻译成 1-3 句旁白。",
    "summary": "把整条时间线汇总成史诗摘要，必须原样保留给出的 sparkline 字符串。",
    "outcome": "根据内核结局的多个字段综合演绎一个 150-300 字场景，kind 决定叙事弧，不得改写 kind。",
}


# ---------------------------------------------------------------------------
# Beat narration — the runtime entry point used by the dispatcher (§8.2).
# ---------------------------------------------------------------------------


def _parse_beat_json(content: str) -> Dict[str, str]:
    """Parse the LLM's free-form output into ``{title, narrative, dialogue}``.

    Tolerant of markdown fences, leading ``json`` markers, and bulleted
    outlines (the gemma model often emits ``* Title: ...`` prose). Mirrors the
    dispatcher's historical parsing so behaviour is preserved when the
    narrator takes over the beat narration path.
    """
    import json as _json
    import re
    if not content:
        return {}
    stripped = content.strip().strip("`").strip()
    if stripped.lower().startswith("json"):
        stripped = stripped[4:].strip()
    parsed: Dict[str, Any] = {}
    try:
        parsed = _json.loads(stripped)
    except _json.JSONDecodeError:
        start = stripped.find("{")
        end = stripped.rfind("}")
        if start != -1 and end > start:
            try:
                parsed = _json.loads(stripped[start:end + 1])
            except _json.JSONDecodeError:
                parsed = {}
    if not isinstance(parsed, dict) or not parsed:
        # Alternative bulleted-outline parser (common gemma style).
        result: Dict[str, str] = {}
        patterns = [
            ("title", re.compile(r"\*\s*\*?title\*?\s*[:：]\s*\*?\"?(.+?)\*?\"?\s*$",
                                 re.IGNORECASE | re.MULTILINE)),
            ("narrative", re.compile(
                r"\*\s*\*?narrative\*?\s*[:：]\s*(.+?)(?=\n\s*\*\s*\*?(?:dialogue|title)|$)",
                re.IGNORECASE | re.DOTALL)),
            ("dialogue", re.compile(r"\*\s*\*?dialogue\*?\s*[:：]\s*\*?[\"“”]?(.+?)[\"“”]?\s*$",
                                    re.IGNORECASE | re.MULTILINE)),
        ]
        for key, regex in patterns:
            matches = list(regex.finditer(stripped))
            if matches:
                result[key] = matches[-1].group(1).strip().strip("*").strip()
        if "title" not in result and "narrative" in result:
            seed = "".join(c for c in result["narrative"]
                           if ("一" <= c <= "鿿") or c.isalnum())[:14]
            if seed:
                result["title"] = seed
        return result
    return {
        "title": str(parsed.get("title") or "").strip(),
        "narrative": str(parsed.get("narrative") or "").strip(),
        "dialogue": str(parsed.get("dialogue") or "").strip(),
    }


def _kernel_verdict_from_event_log(event_log: List[str]) -> Dict[str, Any]:
    """Extract the kernel's ground-truth verdict from a dispatcher event log.

    The dispatcher builds ``event_log`` as a list of ``key=value`` / flag
    strings (e.g. ``"civ_destroyed"``, ``"evacuation_proven"``, ``"beat=3"``).
    We pull out only what the §8.2 guards need:

      - ``survived``  : True unless ``civ_destroyed`` is present.
      - ``evac_possible``: True iff ``evacuation_proven`` is present.

    These are the kernel's numbers; the LLM narration must not flip them.
    """
    blob = " ".join(event_log or [])
    survived = "civ_destroyed" not in blob
    evac_possible = "evacuation_proven" in blob
    return {"survived": survived, "evac_possible": evac_possible}
