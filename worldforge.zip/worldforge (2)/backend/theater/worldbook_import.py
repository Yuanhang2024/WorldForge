"""Worldbook (lorebook) import pipeline — pure deterministic parse, no LLM.

§11.1: Import = compile, not load.  Lorebook JSON  →  deterministic parse
→ field-map (Tavern / naive) → validate → typed WorldBookEntry list.

Mirrors ``world_import.py``'s style: pure stdlib, dataclasses, fully
unit-testable.  Card text is untrusted (§12.1) — it lands in
WorldBookEntry.content which the engine routes through a restricted user
turn, never spliced into a system prompt.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


_DEFAULT_SOURCE = "imported_lorebook"


@dataclass
class WorldBookEntry:
    """Deterministically compiled worldbook entry.

    Mirrors ``models.WorldBookEntry`` shape (title / content / source) but
    lives here as a plain dataclass so the importer has zero dependency on
    the storage layer — the caller is responsible for approval + persist.
    """

    title: str
    content: str
    source: str


class WorldbookImporter:
    """Deterministic lorebook compiler.  Pure Python, no dispatcher/agent
    dependencies, fully unit-testable."""

    # ------------------------------------------------------------------
    # parse
    # ------------------------------------------------------------------
    @staticmethod
    def parse_lorebook(data: dict) -> List[WorldBookEntry]:
        """Parse a lorebook payload into WorldBookEntry list.

        Supported shapes:
        - Tavern lorebook (dict): ``{"entries": {"0": {...}, ...}}`` or
          ``{"entries": [ {...}, ... ]}``.
        - Naive (dict): ``{"entries": [{"title","content","source"}, ...]}``.
        - Top-level list of entry dicts.

        Tavern field mapping: ``comment``→title, ``content``→content,
        ``key``→folded into content as a keyword tag.  ``source`` defaults
        to "imported_lorebook" when absent.
        """
        if data is None:
            return []
        if isinstance(data, list):
            raw_entries = data
        elif isinstance(data, dict):
            raw_entries = data.get("entries", [])
            # Tavern shape: dict-of-entries keyed by ordinal strings.
            if isinstance(raw_entries, dict):
                raw_entries = list(raw_entries.values())
            if not isinstance(raw_entries, list):
                raw_entries = []
        else:
            return []

        entries: List[WorldBookEntry] = []
        for raw in raw_entries:
            if not isinstance(raw, dict):
                continue
            entry = WorldbookImporter._map_entry(raw)
            if entry is not None:
                entries.append(entry)
        return entries

    @staticmethod
    def _map_entry(raw: dict) -> Optional[WorldBookEntry]:
        """Map a single raw entry dict → WorldBookEntry (None if empty)."""
        # Tavern: comment is the human-readable title; naive: title.
        title = str(raw.get("title") or raw.get("comment") or raw.get("name") or "").strip()
        content = str(raw.get("content") or raw.get("text") or "").strip()
        source = str(raw.get("source") or "").strip() or _DEFAULT_SOURCE

        # Tavern `key` is a list of trigger keywords — fold into content as a
        # keyword tag so the worldbook carries the trigger metadata without
        # needing a separate field on WorldBookEntry.
        keys = raw.get("key")
        if keys:
            if isinstance(keys, str):
                keys_list = [keys]
            elif isinstance(keys, list):
                keys_list = [str(k) for k in keys if k]
            else:
                keys_list = []
            if keys_list:
                tag = "[关键词: " + ", ".join(keys_list) + "]"
                content = f"{tag}\n{content}" if content else tag

        if not title and not content:
            return None
        return WorldBookEntry(title=title, content=content, source=source)

    # ------------------------------------------------------------------
    # validate
    # ------------------------------------------------------------------
    @staticmethod
    def validate(entries: List[WorldBookEntry]) -> List[str]:
        """Return a list of validation warnings (empty = clean).

        Checks:
        - every entry has a non-empty title and content
        - duplicate titles produce one warning per repeat
        """
        warnings: List[str] = []
        seen_titles: Dict[str, int] = {}
        for i, entry in enumerate(entries):
            if not entry.title:
                warnings.append(f"entry #{i}: title is empty")
            if not entry.content:
                warnings.append(f"entry #{i}: content is empty")
            if entry.title:
                seen_titles[entry.title] = seen_titles.get(entry.title, 0) + 1
        for title, count in seen_titles.items():
            if count > 1:
                warnings.append(f"duplicate title '{title}' appears {count} times")
        return warnings

    # ------------------------------------------------------------------
    # compile
    # ------------------------------------------------------------------
    @staticmethod
    def compile_worldbook(
        data: Any,
        target_world_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Full compile pipeline.  Returns::

            {"worldbook": [ {title,content,source}, ... ],
             "warnings":  [ "...", ... ],
             "count":     N,
             "world_id":  target_world_id or None}

        Pure deterministic — no persistence.  The caller is responsible for
        approval + writing through the orchestrator's add_world_entry().
        """
        data_dict = data if isinstance(data, (dict, list)) else {}
        entries = WorldbookImporter.parse_lorebook(data_dict)  # type: ignore[arg-type]
        warnings = WorldbookImporter.validate(entries)
        return {
            "worldbook": [
                {"title": e.title, "content": e.content, "source": e.source}
                for e in entries
            ],
            "warnings": warnings,
            "count": len(entries),
            "world_id": target_world_id,
        }
