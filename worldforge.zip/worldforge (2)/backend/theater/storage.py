import json
import os
import threading
from pathlib import Path
from typing import Dict, List, Optional

from .models import CharacterEntry, CharacterPatch, SceneObjectEntry, SceneObjectPatch, StateSnapshot, WorldBookEntry, WorldBookPatch


# §17 P0 事实隔离: 旧 worldbook 条目无 provenance 时, 按 source 字段推断类型.
# narrative_rendering 的 source 标记词; lore / 其余回退 canonical_event (保守默认).
_NARRATIVE_SOURCE_HINTS = ("narration", "narrative", "director_group")
_LORE_SOURCE_HINTS = ("imported_lorebook", "lore", "worldbook_import")


def _infer_provenance(source: str) -> str:
    """Infer a WorldBookEntry.provenance from its legacy ``source`` string.

    Used only by the v3→v4 migration (old entries predate the provenance
    field). New writes set provenance explicitly at the call site.
    """
    src = (source or "").lower()
    if any(h in src for h in _NARRATIVE_SOURCE_HINTS):
        return "narrative_rendering"
    if any(h in src for h in _LORE_SOURCE_HINTS):
        return "lore"
    return "canonical_event"


class JsonStateStore:
    # Schema versioning (ARCHITECTURE_SPEC §13.1, §15.2). When the state shape
    # changes, bump SCHEMA_VERSION + add a migration in _migrate(). Old saves
    # load through the chain to current. world_id namespaces a world (§15.2) —
    # the default "main" world keeps backward compat with existing single-state files.
    SCHEMA_VERSION = 6

    def __init__(self, root: Path, world_id: str = "main"):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.world_id = world_id
        self.path = self.root / f"state_{world_id}.json" if world_id != "main" else self.root / "state.json"
        self.kernel_path = self.root / f"kernel_{world_id}.json"
        self.gameplay_path = self.root / f"gameplay_{world_id}.json"
        self._lock = threading.RLock()   # guard concurrent read/modify/write
        if not self.path.exists():
            self._save(self._seed_state())
        else:
            self._migrate_if_needed()

    def _migrate_if_needed(self) -> None:
        """Run the registered migration chain forward to ``SCHEMA_VERSION``."""
        with self._lock:
            state = self._load_raw()
            ver = 0
            if isinstance(state.get("_meta"), dict):
                ver = int(state["_meta"].get("schema_version") or 0)
            if ver >= self.SCHEMA_VERSION:
                return
            state = self._migrate(state, ver)
            self._save(state)

    def _migrate(self, state: Dict, from_ver: int) -> Dict:
        from .migrations import get_default_chain

        state = get_default_chain().migrate(
            state,
            target_version=self.SCHEMA_VERSION,
        )
        meta = state.setdefault("_meta", {})
        if not meta.get("world_id") or (
            meta.get("world_id") == "main" and self.world_id != "main"
        ):
            meta["world_id"] = self.world_id
        return state

    def _seed_state(self) -> Dict[str, List[Dict[str, object]]]:
        seed_root = Path(__file__).resolve().parents[2] / "data" / "seed"
        worldbook: List[Dict[str, object]] = []
        characters: List[Dict[str, object]] = []
        worldbook_path = seed_root / "worldbook.json"
        characters_path = seed_root / "characters.json"
        if worldbook_path.exists():
            worldbook = json.loads(worldbook_path.read_text(encoding="utf-8"))
        if characters_path.exists():
            characters = json.loads(characters_path.read_text(encoding="utf-8"))
        return {
            "worldbook": worldbook,
            "characters": characters,
            "objects": [],
            "_meta": {
                "schema_version": self.SCHEMA_VERSION,
                "world_id": self.world_id,
                "created_from": None,
                "generator_ids": {"llm": None, "gui_compiler": None},
                "world_params": {
                    "lambda": None,
                    "initial_conditions_seed": None,
                    "enabled_kernels": [],
                    "sealed_solutions": {},
                },
                "integrity_flags": {
                    "sandbox": False,
                    "constraint_mutations": [],
                },
            },
        }

    def _load_raw(self) -> Dict[str, List[Dict[str, object]]]:
        with self._lock:
            return json.loads(self.path.read_text(encoding="utf-8"))

    def _load(self) -> Dict[str, List[Dict[str, object]]]:
        return self._load_raw()

    def _save(self, state: Dict[str, List[Dict[str, object]]]) -> None:
        # atomic write: temp file + rename, so a concurrent _load never sees a
        # half-written file
        with self._lock:
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(tmp, self.path)

    def add_world_entry(self, patch: WorldBookPatch, approved_by: Optional[str]) -> bool:
        if not approved_by:
            return False
        state = self._load()
        entry = WorldBookEntry(
            title=patch.title,
            content=patch.content,
            source=patch.source,
            approved_by=approved_by,
            provenance=patch.provenance,
        )
        state["worldbook"].append(entry.to_dict())
        self._save(state)
        return True

    def upsert_character(self, patch: CharacterPatch, approved_by: Optional[str]) -> bool:
        if not approved_by:
            return False
        state = self._load()
        entry = CharacterEntry(
            character_id=patch.character_id,
            name=patch.name,
            summary=patch.summary,
            source=patch.source,
            personality=patch.personality,
            appearance=patch.appearance,
            sample_line=patch.sample_line,
            possessed=patch.possessed,
            possessed_by=patch.possessed_by,
            ai_subconscious=patch.ai_subconscious,
            pending_ai_actions=patch.pending_ai_actions,
            possession_limit=patch.possession_limit,
            approved_by=approved_by,
        )
        state["characters"] = [item for item in state["characters"] if item.get("character_id") != patch.character_id]
        state["characters"].append(entry.to_dict())
        self._save(state)
        return True

    def snapshot(self) -> StateSnapshot:
        state = self._load()
        return StateSnapshot(
            worldbook=[WorldBookEntry(**item) for item in state.get("worldbook", [])],
            characters=[CharacterEntry(**item) for item in state.get("characters", [])],
            objects=[SceneObjectEntry(**item) for item in state.get("objects", [])],
        )

    def upsert_object(self, patch: SceneObjectPatch, approved_by: Optional[str]) -> bool:
        """Add or update a scene object (through the science gate's approval)."""
        if not approved_by:
            return False
        state = self._load()
        entry = SceneObjectEntry(
            object_id=patch.object_id, name=patch.name, kind=patch.kind,
            location=patch.location, state=patch.state, source=patch.source,
            material=patch.material, durability=patch.durability,
            is_destructible=patch.is_destructible, is_takeable=patch.is_takeable,
            is_movable=patch.is_movable, affordances=patch.affordances,
            approved_by=approved_by,
        )
        state["objects"] = [o for o in state.get("objects", []) if o.get("object_id") != patch.object_id]
        state["objects"].append(entry.to_dict())
        self._save(state)
        return True

    def get_object(self, object_id: str) -> Optional[SceneObjectEntry]:
        for o in self._load().get("objects", []):
            if o.get("object_id") == object_id:
                return SceneObjectEntry(**o)
        return None

    def remove_object(self, object_id: str) -> bool:
        state = self._load()
        items = state.get("objects", [])
        kept = [o for o in items if o.get("object_id") != object_id]
        state["objects"] = kept
        self._save(state)
        return len(kept) != len(items)

    # -- compiled world-rule kernel spec persistence (P0: 立法→颁布) -----
    # The compiled WorldKernelSpec is persisted to its own file
    # ``kernel_<world_id>.json`` so a new orchestrator instance (new process)
    # can reload it on ``set_world``. Lives outside ``state_<world_id>.json``
    # so the frequent state rewrites never risk truncating it, and so no
    # schema_version bump is needed.
    def save_world_kernel_spec(self, spec_dict: Dict) -> None:
        """Persist a serialized WorldKernelSpec for this world (atomic write)."""
        with self._lock:
            tmp = self.kernel_path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(spec_dict, ensure_ascii=False, indent=2),
                           encoding="utf-8")
            os.replace(tmp, self.kernel_path)

    def load_world_kernel_spec(self) -> Optional[Dict]:
        """Return the persisted WorldKernelSpec dict, or ``None`` if absent."""
        with self._lock:
            if not self.kernel_path.exists():
                return None
            try:
                return json.loads(self.kernel_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                return None

    def delete_world_kernel_spec(self) -> bool:
        """Remove the persisted spec file. Returns True if one was removed."""
        with self._lock:
            if self.kernel_path.exists():
                try:
                    self.kernel_path.unlink()
                    return True
                except OSError:
                    return False
        return False

    # -- compiled gameplay spec persistence (onboarding stage 4: 玩法) -----
    # The onboarding-generated GameplaySpec (spec §9.2 库外玩法) is persisted
    # to its own file ``gameplay_<world_id>.json`` so a new orchestrator
    # instance (new process) can reload it on ``set_world`` — same atomic
    # write + separate-file discipline as the world kernel spec.
    def save_gameplay_spec(self, spec_dict: Dict) -> None:
        """Persist a serialized GameplaySpec for this world (atomic write)."""
        with self._lock:
            tmp = self.gameplay_path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(spec_dict, ensure_ascii=False, indent=2),
                           encoding="utf-8")
            os.replace(tmp, self.gameplay_path)

    def load_gameplay_spec(self) -> Optional[Dict]:
        """Return the persisted GameplaySpec dict, or ``None`` if absent."""
        with self._lock:
            if not self.gameplay_path.exists():
                return None
            try:
                return json.loads(self.gameplay_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                return None

    def delete_gameplay_spec(self) -> bool:
        """Remove the persisted gameplay spec file. Returns True if one was removed."""
        with self._lock:
            if self.gameplay_path.exists():
                try:
                    self.gameplay_path.unlink()
                    return True
                except OSError:
                    return False
        return False
