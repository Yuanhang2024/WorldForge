"""LLM-driven World Kernel rule generator (spec §2, I2, I3).

The last mile of "世界内核随世界观实时生成": given a natural-language world
description and an LLM, return a validated :class:`WorldKernelSpec` ready to
feed into :class:`RuleCompiler`. No description, world type, keyword, or
embedding lookup selects a built-in ruleset.

Key invariants (the LLM is 立法 only — never 司法):

* The LLM never writes executable code; it only emits a JSON document using
  the whitelisted expression AST.  No ``eval``, ``exec``, ``__import__``, no
  Python values that aren't ``int / float / bool / str / list / dict / None``.
* The LLM never decides *what happened* — that is the deterministic kernel's
  job.  It only decides the *shape* of the rules (when they fire, what they
  write, what they assert).
* If the LLM output fails validation, generation fails — we never substitute
  an unrelated ruleset or ship a half-baked spec.

Pure stdlib; no external deps; unit-testable in isolation.
"""

from __future__ import annotations

import json
import re
from typing import Any, Callable, Dict, List, Optional

from .world_kernel_host import (
    RULE_KINDS,
    WorldKernelSpec,
    WorldRule,
)


# ---------------------------------------------------------------------------
# Public surface
# ---------------------------------------------------------------------------


__all__ = ["RuleGenerator"]


class _RuleOutputError(ValueError):
    """Rejected model output plus bounded context for the next LLM turn."""

    def __init__(self, reason: str, raw: str = "") -> None:
        super().__init__(reason)
        rejected = str(raw or "").strip()
        self.repair_feedback = reason
        if rejected:
            self.repair_feedback += (
                "\n\nHere is the previous rejected JSON. Preserve its intended "
                "world semantics, but return a complete corrected object:\n"
                + rejected[:12000]
            )


def _nest_dotted_keys(flat: Dict[str, Any]) -> Dict[str, Any]:
    """Convert ``{"a.b": v}`` → ``{"a": {"b": v}}`` recursively.

    The WorldKernelHost lookup splits state paths on ``.`` and walks
    nested dicts, so initial_state keys must already be nested.  Keys
    without a dot pass through unchanged; values that are dicts (after
    the partition) are themselves normalised.
    """
    out: Dict[str, Any] = {}
    for k, v in flat.items():
        if "." in k:
            head, _, rest = k.partition(".")
            sub = out.setdefault(head, {})
            if not isinstance(sub, dict):
                sub = {}
                out[head] = sub
            sub[rest] = v
        else:
            if isinstance(v, dict):
                out[k] = _nest_dotted_keys(v)
            else:
                out[k] = v
    # Recurse into nested sub-dicts so a key like ``game.score.p1`` that
    # arrived under a flat parent (``"game": {"score.p1": 0}``) gets
    # normalised on the second pass.
    for k, v in list(out.items()):
        if isinstance(v, dict):
            out[k] = _nest_dotted_keys(v)
    return out

# ---------------------------------------------------------------------------
# RuleGenerator
# ---------------------------------------------------------------------------


class RuleGenerator:
    """Generate :class:`WorldKernelSpec` from a natural-language world description.

    Constructor parameters:
        model_label:  Human-readable label for the LLM used (recorded in errors).
        preset_map:   Removed legacy keyword-routing argument. Passing it is
                      rejected so callers cannot silently restore that policy.

    The generator is **stateless** (apart from its routing table).  Tests can
    instantiate it freely and call ``generate`` repeatedly.
    """

    def __init__(
        self,
        *,
        model_label: str = "rule-llm",
        preset_map: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        if preset_map is not None:
            raise ValueError(
                "preset_map keyword routing was removed; generate rules from "
                "the LLM or invoke a reference builder explicitly"
            )
        self._model_label = model_label

    # -- main entry ----------------------------------------------------------

    def generate(
        self,
        world_description: str,
        llm_fn: Optional[Callable[[str], str]] = None,
    ) -> WorldKernelSpec:
        """Generate a :class:`WorldKernelSpec` for *world_description*.

        *llm_fn* is **required**.  Call as ``generate(descr, llm_fn=fn)``
        where ``fn(prompt) -> str`` (single-arg; the system prompt is
        folded into *prompt* by :meth:`_generate_via_llm`).

        Raises ``RuntimeError`` if *llm_fn* is ``None``. Every generation
        must go through the LLM; no substitute ruleset is installed.
        """
        description = (world_description or "").strip()

        if llm_fn is None:
            raise RuntimeError(
                "RuleGenerator.generate() requires llm_fn — "
                "set base_url+api_key before calling generate()."
            )

        # Transport or malformed-output failures are surfaced here. The
        # integration boundary must block the current step rather than
        # substituting an unrelated ruleset.
        attempts = 3
        last_error: Optional[Exception] = None
        for attempt in range(attempts):
            try:
                return self._generate_via_llm(
                    description,
                    llm_fn,
                    feedback=(
                        str(
                            getattr(
                                last_error,
                                "repair_feedback",
                                str(last_error),
                            )
                        )[:14000]
                        if attempt and last_error is not None else ""
                    ),
                )
            except Exception as exc:
                last_error = exc
                # Retry only model-output/schema problems. Transport and
                # provider failures are already explicit and repeating the
                # same unavailable request would not repair the artifact.
                if not isinstance(exc, ValueError):
                    break
        detail = f" ({last_error})" if last_error is not None else ""
        raise RuntimeError(
            f"LLM generation failed for {description!r} after at most "
            f"{attempts} attempts{detail}. No substitute ruleset is available."
        )

    # -- system prompt -------------------------------------------------------

    def _build_system_prompt(self) -> str:
        """Build the system prompt that teaches the LLM the rule DSL.

        Hard constraints encoded:
          * Output is **only** declarative JSON (no prose, no code fences).
          * All expression ASTs use whitelisted ops only.
          * Every rule has trigger / condition / effect.
          * ``invariant`` rules carry a predicate (conservation check).
          * LLM only shapes rules — never decides results (I2).
        """
        ops = (
            "add, sub, mul, div, abs, neg, min, max, clamp, "
            "lt, gt, eq, ne, le, ge, "
            "and, or, not, "
            "if, sum, avg, count, "
            "lookup, random_in_range"
        )
        leaves = (
            "leaves: {\"const\": <number|bool|string>}  or  "
            "{\"ref\": \"dot.path.to.state\"}  or  "
            "{\"op\":\"ref\",\"path\":\"...\"}  or  "
            "{\"op\":\"lookup\",\"path\":\"...\"}"
        )
        rules_shape = (
            "{"
            "\"rule_id\": \"snake_case_id\", "
            "\"kind\": \"invariant|dynamic|minigame\", "
            "\"trigger\": \"event.path\" or null, "
            "\"condition\": <AST or null>, "
            "\"effect\": <effect AST>, "
            "\"description\": \"free text\", "
            "\"priority\": <int>"
            "}"
        )
        effect_shapes = (
            "writes:   {\"op\":\"writes\",\"changes\":[{\"path\":\"x\",\"value\":<AST>}, ...]} | "
            "predicate: {\"op\":\"predicate\",\"expr\":<AST>} | "
            "emit_event: {\"op\":\"emit_event\",\"value\":<any>}"
        )
        return (
            "You are a rule DSL compiler for a deterministic world-kernel engine.\n"
            "Your output is a JSON object — no prose, no code fences, no markdown.\n\n"
            "ROLE (I2 — separation of 立法 / 司法):\n"
            "  You only define the SHAPE of rules (when they fire, what they write,\n"
            "  what they assert). You NEVER decide results. The deterministic kernel\n"
            "  applies your rules; you do not narrate outcomes.\n\n"
            "OUTPUT (a single JSON object with these keys):\n"
            "{\n"
            "  \"world_type\": \"snake_case_identifier\",\n"
            "  \"rules\": [<rule>, <rule>, ...],\n"
            "  \"params\": {\"<name>\": <value>, ...},\n"
            "  \"initial_state\": {<state path> : <initial value>, ...}\n"
            "}\n\n"
            f"EACH RULE ({rules_shape}):\n"
            "  - rule_id:  stable, unique snake_case identifier.\n"
            "  - kind:     \"invariant\" (always-on conservation check, trigger=null),\n"
            "             \"dynamic\" (fires on event trigger), or\n"
            "             \"minigame\" (sub-game scoring, fires on trigger).\n"
            "  - trigger:  dotted event path like \"turn.tick\" / \"trade.executed\".\n"
            "              MUST be null when kind=\"invariant\".\n"
            "              MUST be a non-empty string when kind=\"dynamic\"/\"minigame\".\n"
            "  - condition: gate AST; null means \"always true\".\n"
            "  - effect:   see EFFECT SHAPES below. Required.\n"
            "  - description: short human-readable explanation.\n"
            "  - priority: int; higher fires first.\n\n"
            f"EFFECT SHAPES ({effect_shapes})\n\n"
            f"EXPRESSION AST — op WHITELIST ONLY ({ops}).\n"
            "  AST nodes are {\"op\": \"<name>\", \"args\": [<AST>, ...]}.\n"
            "  Binary ops need exactly 2 args; \"not\"/\"neg\"/\"abs\" need 1.\n"
            "  \"and\" and \"or\" are binary too: NEVER give them 3+ args. "
            "Nest additional terms, e.g. and(A, and(B, C)) is "
            "{\"op\":\"and\",\"args\":[A,{\"op\":\"and\",\"args\":[B,C]}]}.\n"
            "  \"if\" needs 3 args (cond, then, else); \"sum\"/\"avg\"/\"count\" need 1 (a list).\n"
            "  \"clamp\" needs {\"op\":\"clamp\",\"value\":<expr>,\"args\":[lo,hi]}.\n"
            "  \"random_in_range\" needs {\"op\":\"random_in_range\",\"args\":[lo,hi]}.\n\n"
            f"  {leaves}\n\n"
            "HARD RULES:\n"
            "  1. Output ONLY the JSON object — no commentary, no markdown fences.\n"
            "  2. Every AST must use ONLY whitelisted ops; never emit eval/exec/import.\n"
            "  3. Every rule MUST have rule_id / kind / effect (trigger may be null\n"
            "     only for invariant).\n"
            "  4. Invariant rules use {\"op\":\"predicate\",\"expr\":<AST>} as their effect.\n"
            "  5. Do NOT include executable code, lambdas, or functions — AST only.\n"
            "  6. Do NOT include paths beginning with \"permissions.\", "
            "\"sealed_solutions.\", or \"_meta.world_params.\" (forbidden writes).\n"
            "  7. Pick 3-7 rules that capture the essence of the world. Fewer is better.\n"
            "  8. ALWAYS output ``initial_state`` — a JSON dict whose KEYS are the\n"
            "     exact dotted state paths every rule reads (e.g. ``\"supply\"``,\n"
            "     ``\"population.infected\"``, ``\"city.infection_rate\"``) and whose\n"
            "     VALUES are sensible starting values. The runtime applies\n"
            "     ``initial_state`` before any step; missing keys default to 0.\n"
            "     Without matching paths, every rule evaluates to 0 and the\n"
            "     world does nothing — so this field is REQUIRED.\n"
        )

    # -- LLM-driven path -----------------------------------------------------

    def _generate_via_llm(
        self,
        description: str,
        llm_fn: Callable[[str], str],
        *,
        feedback: str = "",
    ) -> WorldKernelSpec:
        """Call the LLM and return a valid spec or raise with repair feedback.

        Flow:  parse JSON  →  ``_normalize_ast`` (rewrite op aliases)  →
               ``_repair_spec`` (fill missing fields)  →  ``validate_spec``.
        Anything still invalid raises. :meth:`generate` feeds that validation
        reason into the next LLM attempt; no local ruleset is substituted.
        """
        system_prompt = self._build_system_prompt()
        repair_instruction = ""
        if feedback:
            repair_instruction = (
                "\n\nThe previous model output was rejected for this reason:\n"
                f"{feedback}\n"
                "Regenerate the COMPLETE JSON object and fix every listed "
                "problem. In particular, all binary operators including and/or "
                "must contain exactly two args; nest them for additional terms. "
                "Do not return a patch or explanation."
            )
        user_prompt = (
            f"Generate the rule DSL for this world:\n\n{description}\n\n"
            "Return ONLY the JSON object as specified."
            f"{repair_instruction}"
        )
        raw = llm_fn(f"{system_prompt}\n\n{user_prompt}")
        spec = self._parse_llm_output(raw or "")
        if spec is None:
            text = str(raw or "").strip()
            reason = "empty output" if not text else (
                "output was not a complete WorldKernelSpec JSON object"
            )
            raise _RuleOutputError(reason, str(raw or ""))
        # Auto-fix common LLM sloppiness before validation.
        # (1) rewrite op aliases (gte→ge, multiply→mul, ...) recursively
        # (2) fill missing trigger / priority / description / effect.op
        # Both are in-place; spec object is the same.
        for rule in spec.rules:
            if rule.condition is not None:
                self._normalize_ast(rule.condition)
            if rule.effect is not None:
                self._normalize_ast(rule.effect)
        self._repair_spec(spec)
        # Final validation gate — never ship a spec that won't compile.
        from .world_kernel_host import RuleCompiler
        issues = RuleCompiler().validate_spec(spec)
        if issues:
            raise _RuleOutputError(
                "rule validation failed: " + "; ".join(issues),
                str(raw or ""),
            )
        return spec

    # -- parsing -------------------------------------------------------------

    def _parse_llm_output(self, raw: str) -> Optional[WorldKernelSpec]:
        """Parse the LLM's raw output into a :class:`WorldKernelSpec`.

        Tolerant of common LLM sloppiness:
          - leading/trailing whitespace
          - ``\\`\\`\\`json`` / ``\\`\\`\\``` code fences
          - prose before/after the JSON object (we scan for the outermost braces)
        """
        text = (raw or "").strip()
        if not text:
            return None
        # Strip code fences if present.
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```\s*$", "", text)
        # Try direct parse first.
        obj: Any = None
        try:
            obj = json.loads(text)
        except json.JSONDecodeError:
            # Scan for the outermost { ... } block.
            start = text.find("{")
            end = text.rfind("}")
            if start == -1 or end == -1 or end <= start:
                return None
            try:
                obj = json.loads(text[start : end + 1])
            except json.JSONDecodeError:
                return None
        if not isinstance(obj, dict):
            return None
        spec = self._dict_to_spec(obj)
        return spec

    def _dict_to_spec(self, obj: Dict[str, Any]) -> Optional[WorldKernelSpec]:
        """Convert a raw dict (from LLM JSON) into a :class:`WorldKernelSpec`.

        Tolerant of structural issues — ``invariant`` with stray trigger,
        missing priority, etc. — because :meth:`_repair_spec` will fill them
        in before validation.  Validation happens in
        :meth:`_generate_via_llm` *after* normalise + repair.
        """
        world_type = obj.get("world_type")
        if not isinstance(world_type, str) or not world_type:
            return None
        rules_raw = obj.get("rules")
        if not isinstance(rules_raw, list) or not rules_raw:
            return None
        rules: List[WorldRule] = []
        for r in rules_raw:
            if not isinstance(r, dict):
                return None
            rule = self._dict_to_rule(r)
            if rule is None:
                return None
            rules.append(rule)
        params = obj.get("params") or {}
        if not isinstance(params, dict):
            return None
        initial_state_raw = obj.get("initial_state")
        if initial_state_raw is None:
            initial_state: Dict[str, Any] = {}
        elif isinstance(initial_state_raw, dict):
            initial_state = _nest_dotted_keys(dict(initial_state_raw))
        else:
            initial_state = {}
        try:
            return WorldKernelSpec(
                world_type=world_type,
                rules=rules,
                params=dict(params),
                initial_state=initial_state,
            )
        except Exception:
            return None

    @staticmethod
    def _dict_to_rule(r: Dict[str, Any]) -> Optional[WorldRule]:
        """Convert a single rule dict into a :class:`WorldRule`.

        Permissive: structural issues (missing/extra trigger, bad priority,
        etc.) are tolerated here — :meth:`_repair_spec` will fill them in
        before validation.  Only fatal shape errors return ``None``.
        """
        rule_id = r.get("rule_id")
        if not isinstance(rule_id, str) or not rule_id:
            return None
        kind = r.get("kind")
        if kind not in RULE_KINDS:
            return None
        trigger = r.get("trigger")
        if trigger is not None and not isinstance(trigger, str):
            trigger = None  # normalize str-or-None; repair fills later
        effect = r.get("effect")
        if effect is None:
            return None
        description = r.get("description") or ""
        if not isinstance(description, str):
            description = ""
        # priority may be missing or non-int — repair defaults to 0
        priority = r.get("priority")
        if not isinstance(priority, int):
            priority = 0
        return WorldRule(
            rule_id=rule_id,
            kind=kind,
            trigger=trigger,
            condition=r.get("condition"),
            effect=effect,
            description=description,
            priority=priority,
        )

    # -- AST normalization (LLM slop → canonical whitelist) -----------------
    #
    # Real LLMs emit operator aliases humans naturally use:
    #   gte/lte/neq, "≥"/"≤", multiply/divide/subtract/add, etc.
    # They also forget structural pieces (trigger/priority/effect.op).  Rather
    # than rejecting these specs, we repair them in-place before validation.
    # -----------------------------------------------------------------------

    # Map alias → canonical op.  Canonical names must be in WHITELIST_OPS.
    _OP_ALIASES: Dict[str, str] = {
        # comparisons
        "gte": "ge", "ge_": "ge", "greater_or_equal": "ge", ">=": "ge", "≥": "ge",
        "lte": "le", "le_": "le", "less_or_equal": "le", "<=": "le", "≤": "le",
        "neq": "ne", "not_equal": "ne", "!=": "ne", "≠": "ne",
        "lt_": "lt", "less_than": "lt", "<": "lt",
        "gt_": "gt", "greater_than": "gt", ">": "gt",
        "equal": "eq", "==": "eq", "is": "eq",
        # arithmetic (long names LLMs reach for)
        "multiply": "mul", "multiplication": "mul", "product": "mul", "times": "mul",
        "divide": "div", "division": "div", "quotient": "div",
        "subtract": "sub", "subtraction": "sub", "minus": "sub", "difference": "sub",
        "plus": "add", "addition": "add",
        "absolute": "abs", "absolute_value": "abs",
        "negate": "neg", "negative": "neg",
        # logic
        "and_": "and", "&&": "and", "logical_and": "and",
        "or_": "or", "||": "or", "logical_or": "or",
        "not_": "not", "!": "not", "logical_not": "not",
        # ternary & aggregations
        "if_then_else": "if", "ternary": "if",
        "average": "avg", "mean": "avg",
        "len": "count", "size": "count", "length": "count",
        # misc
        "lookup_": "lookup", "read": "lookup", "get": "lookup",
        "randint": "random_in_range", "random": "random_in_range",
    }

    # Defaults for missing rule fields.
    _DEFAULT_PRIORITY: int = 0
    _DEFAULT_DYNAMIC_TRIGGER: str = "turn.tick"

    def _normalize_ast(self, node: Any) -> Any:
        """Recursively rewrite LLM op aliases inside *node* in place.

        Walks dict nodes and lists.  Rewrites ``{"op": "gte", "args": [...]}``
        into ``{"op": "ge", "args": [...]}``.  Unknown ops are recorded as
        warnings (on ``self._normalize_warnings``) but left intact so the
        downstream validator can reject them cleanly.

        Returns *node* (mutated in place; same object also returned for
        chainability).
        """
        if not hasattr(self, "_normalize_warnings"):
            self._normalize_warnings: List[str] = []
        self._normalize_ast_in_place(node)
        return node

    def get_normalize_warnings(self) -> List[str]:
        """Return the list of warnings collected during the last ``_normalize_ast``."""
        return list(getattr(self, "_normalize_warnings", []) or [])

    def _normalize_ast_in_place(self, node: Any) -> None:
        if isinstance(node, dict):
            # 1. Unwrap ``{"op":"const","value":V}`` → ``{"const": V}`` shorthand.
            #    The validator accepts both, but normalising to the shorthand
            #    keeps the AST compact and consistent.
            op = node.get("op")
            if op == "const" and "value" in node and set(node.keys()) <= {"op", "value"}:
                value = node["value"]
                node.clear()
                node["const"] = value
                return

            # 2. ``{"op":"lookup","path":"x"}`` → ``{"op":"lookup","args":["x"]}``
            if op == "lookup" and isinstance(node.get("path"), str) and "args" not in node:
                path = node.pop("path")
                node["args"] = [path]
                op = "lookup"  # unchanged but flag for alias check below

            # 3. ``{"op":"var","name":"x"}`` → ``{"op":"lookup","args":["x"]}``
            if op == "var" and isinstance(node.get("name"), str):
                name = node.pop("name")
                node["op"] = "lookup"
                node["args"] = [name]
                op = "lookup"

            # 4. Rewrite ``{"op":"ref","path":"x"}`` → ``{"ref":"x"}`` shorthand.
            if op == "ref" and isinstance(node.get("path"), str) and "ref" not in node:
                path = node.pop("path")
                node.clear()
                node["ref"] = path
                return

            # 5. ``{"op":"writes","changes":[{"path":p,"value":<ast>}, ...]}``
            #    Flatten a single-change writes into the canonical flat form
            #    ``{"writes": p, "value": <ast>, "op": "set"|...}``.  Multi-
            #    change writes are left intact (their downstream effect needs
            #    the list shape).
            if op == "writes" and isinstance(node.get("changes"), list):
                changes = node["changes"]
                if len(changes) == 1 and isinstance(changes[0], dict):
                    ch = changes[0]
                    if "path" in ch and "value" in ch:
                        new_node = {
                            "writes": ch["path"],
                            "value": ch["value"],
                            "op": ch.get("op", "set"),
                        }
                        node.clear()
                        node.update(new_node)
                        # Recurse into the new value
                        self._normalize_ast_in_place(node["value"])
                        return
                # Multi-change writes — leave the wrapping but normalize each
                # change dict recursively (so its ``value`` AST aliases get
                # rewritten).
                for ch in changes:
                    self._normalize_ast_in_place(ch)
                return

            # Standard op alias rewriting
            if isinstance(op, str):
                canonical = self._OP_ALIASES.get(op)
                if canonical is not None and canonical != op:
                    node["op"] = canonical
                elif not self._is_known_op(op):
                    self._normalize_warnings.append(
                        f"unknown op alias {op!r} left intact (validator will reject)"
                    )
            # Walk children
            for v in node.values():
                self._normalize_ast_in_place(v)
        elif isinstance(node, list):
            for v in node:
                self._normalize_ast_in_place(v)

    @staticmethod
    def _is_known_op(op: str) -> bool:
        # Lazy import to avoid circular at module-import time
        from .world_kernel_host import WHITELIST_OPS
        return op in WHITELIST_OPS

    # -- helpers shared by repair --------------------------------------------

    @staticmethod
    def _nest_dotted_keys(flat: Dict[str, Any]) -> Dict[str, Any]:
        """Convert dotted keys ``{"a.b": v}`` into nested ``{"a": {"b": v}}``.

        The host's ``_lookup`` splits paths on ``.`` and walks nested dicts,
        so initial_state keys must already be nested.  Keys without a dot
        pass through unchanged.  Conflicting dotted/nested shapes raise —
        callers never reach this point with ambiguous input (the LLM
        prompt mandates the dotted-path convention).
        """
        return _nest_dotted_keys(flat)

    @staticmethod
    def _walk_ast_paths(node: Any, out: List[str]) -> None:
        """Collect every dotted state path referenced anywhere in *node*.

        Recognised leaves: ``{"ref": "x.y"}`` shorthand, ``{"op":"ref",
        "path":"x.y"}`` AST, and ``{"op":"lookup","path":"x.y"}`` /
        ``{"op":"lookup","args":["x.y"]}`` forms. Also picks up the
        ``"writes"`` path key from effect shapes (legacy nested
        ``{"op":"writes","changes":[{"path":"x.y",...}]}`` and flat
        ``{"writes":"x.y",...}``). Walks recursively through dict values
        and list args.
        """
        if isinstance(node, dict):
            if "ref" in node and isinstance(node["ref"], str):
                out.append(node["ref"])
            op = node.get("op")
            if op in ("ref", "lookup"):
                p = node.get("path")
                if isinstance(p, str):
                    out.append(p)
                else:
                    args = node.get("args")
                    if isinstance(args, list):
                        for a in args:
                            if isinstance(a, str):
                                out.append(a)
            # Effect's "writes" path: legacy nested ``{"op":"writes",
            # "changes":[{"path":"x.y",...}]}`` — pull every path leaf.
            if op == "writes":
                changes = node.get("changes")
                if isinstance(changes, list):
                    for c in changes:
                        if isinstance(c, dict):
                            p = c.get("path")
                            if isinstance(p, str):
                                out.append(p)
            # Flat writes: ``{"writes": "x.y", "op": ..., "value": ...}``.
            w = node.get("writes")
            if isinstance(w, str):
                out.append(w)
            for v in node.values():
                RuleGenerator._walk_ast_paths(v, out)
        elif isinstance(node, list):
            for v in node:
                RuleGenerator._walk_ast_paths(v, out)
        elif isinstance(node, str):
            # Bare-string ref shorthand (e.g. ``"economy.price"``).  Only
            # treat strings that **look like dotted paths** as refs — bare
            # identifier strings (e.g. op aliases like ``"add"``) are not.
            if "." in node and not node.startswith(("_", "$")):
                out.append(node)

    @classmethod
    def _infer_initial_state_from_rules(cls,
                                        rules: List[WorldRule]) -> Dict[str, Any]:
        """Infer a default ``initial_state`` from every path the rules read.

        Walks each rule's ``condition`` and ``effect`` (including nested
        writes), collects every dotted path, and returns a dict
        ``{path: <default value>}``. Defaults are 0 for paths that look like
        scalars and 1 for boolean-flavored names (``infected``, ``enabled``,
        ``active``); a cheap heuristic — good enough for the "LLM forgot to
        emit initial_state" repair path.
        """
        paths: List[str] = []
        for r in rules:
            if r.condition is not None:
                cls._walk_ast_paths(r.condition, paths)
            if r.effect is not None:
                cls._walk_ast_paths(r.effect, paths)
        # De-dup, preserve first-seen order. (No namespace filter here — the
        # walker only descends into AST nodes, never into the rule's ``trigger``
        # field, so event paths like "trade.executed" never enter this list.)
        inferred: Dict[str, Any] = {}
        BOOL_TOKENS = ("infected", "active", "enabled", "locked", "open", "alive", "dead")
        for p in paths:
            if not p or not isinstance(p, str):
                continue
            if p in inferred:
                continue
            leaf = p.split(".")[-1].lower()
            # boolean-flavored last segment → 1 (default "yes"); else 0.
            inferred[p] = 1 if leaf in BOOL_TOKENS else 0
        return inferred

    # -- repair --------------------------------------------------------------

    def _repair_spec(self, spec: WorldKernelSpec) -> WorldKernelSpec:
        """Apply rule-level structural fixes in place; return the same object.

        Fixes applied per rule:
          - ``invariant`` with stray trigger      → trigger = None.
          - ``dynamic`` / ``minigame`` missing trigger → ``"turn.tick"``.
          - missing / non-int ``priority``          → ``0``.
          - missing ``description``                 → empty string.

        Effect shape normalisation (LLM often emits messy variants):
          - ``{"op":"writes","changes":[{"path":"x","value":V}]}``
            (single-change legacy) → ``{"writes":"x","op":"set","value":V}``
          - ``{"writes":"x","value":V}`` missing ``op`` → ``"op":"set"``
          - ``{"writes":"x","op":"add","value":V}`` already canonical → kept
          - Multi-change ``{"op":"writes","changes":[{...},{...}]}`` kept
            (downstream supports the list shape).
          - Invariant ``{"predicate": <ast>}`` kept (flat predicate shape).
        """
        for rule in spec.rules:
            if not getattr(rule, "description", None) or not isinstance(
                rule.description, str
            ):
                rule.description = ""
            if rule.priority is None:
                rule.priority = self._DEFAULT_PRIORITY
            if rule.kind in {"dynamic", "minigame"} and not rule.trigger:
                rule.trigger = self._DEFAULT_DYNAMIC_TRIGGER
            if rule.kind == "invariant":
                rule.trigger = None
            # Effect shape normalisation — legacy nested writes → flat form.
            effect = rule.effect
            if not isinstance(effect, dict):
                continue
            op = effect.get("op")
            # Legacy writes with single change → flat writes form.
            if op == "writes":
                changes = effect.get("changes")
                if isinstance(changes, list) and len(changes) == 1 and isinstance(
                    changes[0], dict
                ):
                    ch = changes[0]
                    if "path" in ch:
                        flat = {
                            "writes": ch["path"],
                            "value": ch.get("value"),
                        }
                        # Default the write op to "set" unless the change
                        # entry explicitly carries one.
                        flat["op"] = ch.get("op", "set")
                        rule.effect = flat
                        continue
                # Multi-change writes: ensure each entry has op="set" default.
                if isinstance(changes, list):
                    for c in changes:
                        if isinstance(c, dict) and not c.get("op"):
                            c["op"] = "set"
            # Flat writes shape: ensure op is set (default to "set").
            elif "writes" in effect and op in (None, "set", "add", "delete"):
                if op is None:
                    effect["op"] = "set"
                elif op == "set":
                    # keep canonical
                    pass
            # Flat predicate form for invariants is already accepted by the
            # downstream validator/host — leave it as-is.
        # Repair spec-level fields.
        if not getattr(spec, "initial_state", None):
            spec.initial_state = _nest_dotted_keys(
                self._infer_initial_state_from_rules(spec.rules)
            )
        elif isinstance(spec.initial_state, dict):
            # Re-normalise so flat dotted keys become nested (the host
            # lookup splits on "." and walks nested dicts).
            spec.initial_state = _nest_dotted_keys(spec.initial_state)
        return spec

# ---------------------------------------------------------------------------
# Explicit reference rule templates
# ---------------------------------------------------------------------------
#
# Each preset is a pure factory returning a validated WorldKernelSpec.
# The economy preset is the same set economy_demo uses, so a generator-driven
# world is byte-identical to the hand-written one (modulo rule ordering, which
# the compiler normalises by priority).
# ---------------------------------------------------------------------------


def _economy_preset() -> WorldKernelSpec:
    """Supply → price preset (the canonical economy_demo ruleset)."""
    return WorldKernelSpec(
        world_type="economy",
        rules=[
            WorldRule(
                rule_id="production_each_turn",
                kind="dynamic",
                trigger="turn.tick",
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "supply",
                        "value": {"op": "add",
                                  "args": [{"ref": "supply"},
                                           {"ref": "production_rate"}]},
                    }],
                },
                description="每回合按产能增加供给",
                priority=30,
            ),
            WorldRule(
                rule_id="consumption_each_turn",
                kind="dynamic",
                trigger="turn.tick",
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "demand",
                        "value": {"op": "add", "args": [
                            {"ref": "demand"},
                            {"op": "mul", "args": [{"ref": "population"},
                                                   {"ref": "consumption_rate"}]},
                        ]},
                    }],
                },
                description="每回合按人口与人均消费增加需求",
                priority=20,
            ),
            WorldRule(
                rule_id="price_tracks_supply_demand",
                kind="dynamic",
                trigger="turn.tick",
                condition={"op": "gt", "args": [{"ref": "supply"}, {"const": 0}]},
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "price",
                        "value": {"op": "add", "args": [
                            {"ref": "price"},
                            {"op": "mul", "args": [
                                {"const": 0.1},
                                {"op": "div", "args": [
                                    {"op": "sub", "args": [{"ref": "demand"},
                                                           {"ref": "supply"}]},
                                    {"ref": "supply"},
                                ]},
                            ]},
                        ]},
                    }],
                },
                description="供需失衡驱动价格：demand>supply 涨价，反之跌价",
                priority=10,
            ),
            WorldRule(
                rule_id="gold_conservation",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "eq", "args": [{"ref": "total_gold"},
                                                  {"ref": "gold_constant"}]},
                },
                description="总货币量恒定（交易不造钱）",
                priority=100,
            ),
            WorldRule(
                rule_id="price_non_negative",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "ge", "args": [{"ref": "price"}, {"const": 0}]},
                },
                description="价格非负",
                priority=90,
            ),
        ],
        params={"seed": 42},
        initial_state={
            "supply": 100,
            "demand": 50,
            "price": 1.0,
            "population": 50,
            "production_rate": 8.0,
            "consumption_rate": 0.5,
            "total_gold": 10000,
            "gold_constant": 10000,
        },
    )


def _physics_preset() -> WorldKernelSpec:
    """Simplified gravity → position preset.

    State model: ``body.{name}.{y, vy, mass}`` plus ``gravity`` (default -9.8).
    One dynamic rule per ``physics.tick`` updates velocity + position under
    constant gravity; one invariant pins mass conservation (no spawning).
    """
    return WorldKernelSpec(
        world_type="physical",
        rules=[
            WorldRule(
                rule_id="gravity_updates_velocity",
                kind="dynamic",
                trigger="physics.tick",
                # vy += gravity  (gravity is negative for downward)
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "vy",
                        "value": {"op": "add",
                                  "args": [{"ref": "vy"}, {"ref": "gravity"}]},
                    }],
                },
                description="每步按重力更新速度",
                priority=20,
            ),
            WorldRule(
                rule_id="velocity_updates_position",
                kind="dynamic",
                trigger="physics.tick",
                # y += vy
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "y",
                        "value": {"op": "add",
                                  "args": [{"ref": "y"}, {"ref": "vy"}]},
                    }],
                },
                description="每步按速度更新位置",
                priority=10,
            ),
            WorldRule(
                rule_id="no_negative_time",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "ge", "args": [{"ref": "tick"}, {"const": 0}]},
                },
                description="时间单调递增",
                priority=100,
            ),
            WorldRule(
                rule_id="finite_gravity",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "ne", "args": [{"ref": "gravity"}, {"const": 0}]},
                },
                description="重力非零（系统需有动力学）",
                priority=90,
            ),
        ],
        params={"gravity": -9.8, "tick": 0},
        initial_state={
            "y": 0.0,
            "vy": 0.0,
            "mass": 1.0,
            "gravity": -9.8,
            "tick": 0,
        },
    )


def _social_preset() -> WorldKernelSpec:
    """Simplified relationship → influence preset.

    State model: flat ``{alice.trust, bob.trust, alice.influence, ...}``.
    On a ``social.interaction`` event, two rules fire in priority order:
    a friendly encounter bumps trust, trust in turn drives influence.
    """
    return WorldKernelSpec(
        world_type="social",
        rules=[
            WorldRule(
                rule_id="friendly_interaction_bumps_trust",
                kind="dynamic",
                trigger="social.interaction",
                condition={
                    "op": "gt",
                    "args": [{"ref": "interaction.tone"}, {"const": 0}],
                },
                # trust += interaction.tone * 0.1
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "trust",
                        "value": {"op": "add", "args": [
                            {"ref": "trust"},
                            {"op": "mul", "args": [{"ref": "interaction.tone"},
                                                   {"const": 0.1}]},
                        ]},
                    }],
                },
                description="正向互动提升信任",
                priority=20,
            ),
            WorldRule(
                rule_id="trust_drives_influence",
                kind="dynamic",
                trigger="social.interaction",
                # influence = max(0, trust)
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "influence",
                        "value": {"op": "max",
                                  "args": [{"const": 0}, {"ref": "trust"}]},
                    }],
                },
                description="信任度（≥0）驱动影响力",
                priority=10,
            ),
            WorldRule(
                rule_id="trust_non_negative",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "ge", "args": [{"ref": "trust"}, {"const": 0}]},
                },
                description="信任度非负",
                priority=100,
            ),
        ],
        params={"trust": 0, "influence": 0, "interaction": {"tone": 0}},
        initial_state={
            "trust": 0,
            "influence": 0,
            "interaction": {"tone": 0},
        },
    )


def _card_game_preset() -> WorldKernelSpec:
    """Simplified card-play → score preset (mirrors test_card_game_rules)."""
    return WorldKernelSpec(
        world_type="card_game",
        rules=[
            WorldRule(
                rule_id="high_card_scores",
                kind="dynamic",
                trigger="card.played",
                condition={"op": "ge",
                           "args": [{"ref": "game.last_rank"}, {"const": 11}]},
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "game.score.p1",
                        "value": {"op": "add",
                                  "args": [{"ref": "game.score.p1"}, {"const": 1}]},
                    }],
                },
                description="J/Q/K/A 得分",
                priority=1,
            ),
            WorldRule(
                rule_id="low_card_penalty",
                kind="dynamic",
                trigger="card.played",
                condition={"op": "lt",
                           "args": [{"ref": "game.last_rank"}, {"const": 5}]},
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "game.score.p1",
                        "value": {"op": "sub",
                                  "args": [{"ref": "game.score.p1"}, {"const": 1}]},
                    }],
                },
                description="小牌扣分",
                priority=1,
            ),
            WorldRule(
                rule_id="score_bounded",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "ge",
                             "args": [{"ref": "game.score.p1"}, {"const": -100}]},
                },
                description="分数下限（避免无限下挫）",
                priority=100,
            ),
        ],
        params={"game": {"last_rank": 7, "score": {"p1": 0, "p2": 0}}},
        initial_state={
            "game": {"last_rank": 7, "score": {"p1": 0, "p2": 0}},
        },
    )


def _simulation_preset() -> WorldKernelSpec:
    """City/resource simulation preset.

    State model: flat ``{resources, capacity, population, growth_rate}``.
    One dynamic rule drives resource value growth, one applies decay when
    over capacity, and one invariant enforces capacity conservation.
    """
    return WorldKernelSpec(
        world_type="simulation",
        rules=[
            WorldRule(
                rule_id="resource_value_grows",
                kind="dynamic",
                trigger="turn.tick",
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "resources",
                        "value": {"op": "add", "args": [
                            {"ref": "resources"},
                            {"op": "mul", "args": [
                                {"ref": "population"},
                                {"ref": "growth_rate"},
                            ]},
                        ]},
                    }],
                },
                description="每回合按人口与增长率增加资源",
                priority=30,
            ),
            WorldRule(
                rule_id="over_capacity_decay",
                kind="dynamic",
                trigger="turn.tick",
                condition={
                    "op": "gt",
                    "args": [{"ref": "population"}, {"ref": "capacity"}],
                },
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "population",
                        "value": {"op": "sub", "args": [
                            {"ref": "population"},
                            {"op": "mul", "args": [
                                {"ref": "population"},
                                {"const": 0.05},
                            ]},
                        ]},
                    }],
                },
                description="人口超容量时衰减",
                priority=20,
            ),
            WorldRule(
                rule_id="capacity_conservation",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "ge", "args": [{"ref": "capacity"}, {"const": 0}]},
                },
                description="容量非负",
                priority=100,
            ),
        ],
        params={"seed": 42},
        initial_state={
            "resources": 100,
            "capacity": 200,
            "population": 50,
            "growth_rate": 0.1,
        },
    )


def _politics_preset() -> WorldKernelSpec:
    """派系影响力 + 忠诚度 → 权力转移 / 叛乱概率 preset (§9.3③ 社交邻接).

    政治奇幻的机器是权力转移，不是说服：派系通过政治行动积累影响力；
    影响力过高侵蚀忠诚（功高震主）；忠诚过低抬升叛乱风险。与 social
    preset 的区别：social 的是信任→影响力，politics 的是影响力→忠诚→叛乱，
    多一层权力转移的动力学。
    """
    return WorldKernelSpec(
        world_type="politics",
        rules=[
            WorldRule(
                rule_id="political_action_shifts_influence",
                kind="dynamic",
                trigger="political.action",
                # faction.influence += action.weight
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "faction.influence",
                        "value": {"op": "add", "args": [
                            {"ref": "faction.influence"},
                            {"ref": "action.weight"},
                        ]},
                    }],
                },
                description="政治行动改变派系影响力",
                priority=30,
            ),
            WorldRule(
                rule_id="influence_erodes_loyalty",
                kind="dynamic",
                trigger="turn.tick",
                # 影响力过高 → 忠诚度下降（功高震主）
                condition={"op": "gt",
                           "args": [{"ref": "faction.influence"}, {"const": 50}]},
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "faction.loyalty",
                        "value": {"op": "sub", "args": [
                            {"ref": "faction.loyalty"},
                            {"const": 1},
                        ]},
                    }],
                },
                description="影响力过高侵蚀忠诚（功高震主）",
                priority=20,
            ),
            WorldRule(
                rule_id="low_loyalty_raises_rebellion",
                kind="dynamic",
                trigger="turn.tick",
                condition={"op": "lt",
                           "args": [{"ref": "faction.loyalty"}, {"const": 20}]},
                # rebellion.risk += 0.1
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "rebellion.risk",
                        "value": {"op": "add", "args": [
                            {"ref": "rebellion.risk"},
                            {"const": 0.1},
                        ]},
                    }],
                },
                description="低忠诚度提升叛乱概率",
                priority=10,
            ),
            WorldRule(
                rule_id="influence_non_negative",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "ge",
                             "args": [{"ref": "faction.influence"}, {"const": 0}]},
                },
                description="影响力非负",
                priority=100,
            ),
            WorldRule(
                rule_id="rebellion_risk_bounded",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "le",
                             "args": [{"ref": "rebellion.risk"}, {"const": 1}]},
                },
                description="叛乱风险上界 1.0",
                priority=90,
            ),
        ],
        params={"seed": 42},
        initial_state={
            "faction": {"influence": 30, "loyalty": 50},
            "rebellion": {"risk": 0.0},
            "action": {"weight": 0},
        },
    )


def _investigation_preset() -> WorldKernelSpec:
    """线索 DAG + 嫌疑人怀疑度 preset (§9.3① 推理/调查).

    §9.3① 推理类需要"密封解 + 线索 DAG"——真相必须在用户开始查之前密封，
    LLM 只能读取已解锁线索，不能创造证据。**密封解机制本身是 §17 Q5 人工
    决策项**，这里只建模线索→怀疑度的动力学，不强做密封解（留 TODO）。

    状态：clues.revealed（已解锁线索数）、suspects.suspicion（怀疑度）、
    case.solved（是否结案）。规则：发现线索抬升怀疑度；怀疑度过高可指控；
    invariant 保怀疑度非负 + 上界。
    """
    return WorldKernelSpec(
        world_type="investigation",
        rules=[
            WorldRule(
                rule_id="clue_reveals_suspicion",
                kind="dynamic",
                trigger="clue.found",
                # suspects.suspicion += clue.weight
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "suspects.suspicion",
                        "value": {"op": "add", "args": [
                            {"ref": "suspects.suspicion"},
                            {"ref": "clue.weight"},
                        ]},
                    }],
                },
                description="解锁线索抬升嫌疑人怀疑度",
                priority=30,
            ),
            WorldRule(
                rule_id="high_suspicion_enables_accusation",
                kind="dynamic",
                trigger="turn.tick",
                # 怀疑度超阈值 → case.can_accuse = 1
                condition={"op": "ge",
                           "args": [{"ref": "suspects.suspicion"}, {"const": 10}]},
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "case.can_accuse",
                        "value": {"const": 1},
                    }],
                },
                description="怀疑度足够时开启指控路径",
                priority=20,
            ),
            WorldRule(
                rule_id="accusation_closes_case",
                kind="dynamic",
                trigger="case.accuse",
                # 指控发生 → case.solved = 1
                effect={
                    "op": "writes",
                    "changes": [{
                        "path": "case.solved",
                        "value": {"const": 1},
                    }],
                },
                description="提交指控后案件结案",
                priority=10,
            ),
            WorldRule(
                rule_id="suspicion_non_negative",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "ge",
                             "args": [{"ref": "suspects.suspicion"}, {"const": 0}]},
                },
                description="怀疑度非负",
                priority=100,
            ),
            WorldRule(
                rule_id="suspicion_bounded",
                kind="invariant",
                trigger=None,
                effect={
                    "op": "predicate",
                    "expr": {"op": "le",
                             "args": [{"ref": "suspects.suspicion"}, {"const": 100}]},
                },
                description="怀疑度上界 100",
                priority=90,
            ),
        ],
        params={"seed": 42},
        initial_state={
            "clues": {"revealed": 0},
            "suspects": {"suspicion": 0},
            "case": {"solved": 0, "can_accuse": 0},
            "clue": {"weight": 0},
        },
    )


# Reference builders are preserved for explicit fixture/demo use. They are not
# reachable from ``generate()`` and descriptions are never matched against
# their IDs.
_PRESET_BUILDERS: Dict[str, Callable[[], WorldKernelSpec]] = {
    "economy": _economy_preset,
    "physical": _physics_preset,
    "social": _social_preset,
    "card_game": _card_game_preset,
    "simulation": _simulation_preset,
    "politics": _politics_preset,
    "investigation": _investigation_preset,
}
