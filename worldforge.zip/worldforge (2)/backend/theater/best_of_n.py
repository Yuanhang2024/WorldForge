"""
Best-of-N sampling + lightweight rerank, plus commitment-state routing.

Implements ARCHITECTURE_SPEC(2).md §5.4 ("quality comes from width, not depth")
and §5.6 ("route quality cost by commitment state").

Pure Python, no dispatcher/agents/server dependencies, no LLM calls in the
scorer itself. Designed to be unit-testable with a mock LLM client.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, List, Mapping, Sequence

# ---------------------------------------------------------------------------
# Scorer config
# ---------------------------------------------------------------------------

#: Weights for the rerank scoring components. Tuned so that, in aggregate,
#: a candidate doing well on every dimension lands near 1.0.
DEFAULT_WEIGHTS: Mapping[str, float] = {
    "length": 0.20,
    "keyword": 0.35,
    "format": 0.20,
    "diversity": 0.15,
    "no_duplicate": 0.10,
}

#: Soft targets for length scoring. Tokens/words outside [lo, hi] get
#: penalized but not hard-rejected.
LENGTH_LO = 30
LENGTH_HI = 400


# ---------------------------------------------------------------------------
# Public dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ScoreBreakdown:
    """Per-component scores that compose into the final rerank score."""

    length: float
    keyword: float
    format: float
    diversity: float
    no_duplicate: float

    def total(self, weights: Mapping[str, float]) -> float:
        return (
            weights["length"] * self.length
            + weights["keyword"] * self.keyword
            + weights["format"] * self.format
            + weights["diversity"] * self.diversity
            + weights["no_duplicate"] * self.no_duplicate
        )


@dataclass
class ScoreResult:
    """Scored candidate — breakdown for inspectability + weighted total."""

    text: str
    score: float
    breakdown: ScoreBreakdown

    def as_dict(self) -> dict:
        return {
            "text": self.text,
            "score": self.score,
            "breakdown": {
                "length": self.breakdown.length,
                "keyword": self.breakdown.keyword,
                "format": self.breakdown.format,
                "diversity": self.breakdown.diversity,
                "no_duplicate": self.breakdown.no_duplicate,
            },
        }


@dataclass
class ScoringCriteria:
    """Optional knobs for the rerank scorer."""

    required_keywords: Sequence[str] = field(default_factory=tuple)
    want_json: bool = False
    known_candidates: Sequence[str] = field(default_factory=tuple)
    weights: Mapping[str, float] = field(
        default_factory=lambda: dict(DEFAULT_WEIGHTS)
    )
    length_lo: int = LENGTH_LO
    length_hi: int = LENGTH_HI

    @classmethod
    def from_prompt(
        cls,
        prompt: str,
        *,
        want_json: bool = False,
        known_candidates: Sequence[str] = (),
    ) -> "ScoringCriteria":
        """Convenience constructor: pull keywords from the prompt heuristically."""
        if not prompt:
            return cls(want_json=want_json, known_candidates=known_candidates)
        # Distinct alphabetic tokens of length >= 4 (lowercased), cap at 12.
        words = re.findall(r"[A-Za-z一-鿿]{4,}", prompt.lower())
        seen: List[str] = []
        for w in words:
            if w not in seen:
                seen.append(w)
                if len(seen) >= 12:
                    break
        return cls(
            required_keywords=tuple(seen),
            want_json=want_json,
            known_candidates=known_candidates,
        )


# ---------------------------------------------------------------------------
# LLM client protocol
# ---------------------------------------------------------------------------


LLMClient = Any  # duck-typed: .complete(prompt, *, temperature) -> str
CompletionFn = Callable[[str, float], str]


def _default_client_call(
    client: LLMClient,
    prompt: str,
    temperature: float,
) -> str:
    """Invoke the LLM client. Supports three common shapes:

    1. ``client.generate(prompt, temperature=temperature)``
    2. ``client.complete(prompt, temperature=temperature)``
    3. plain callable ``client(prompt)`` (temperature ignored)

    Raises ``TypeError`` if the shape is unknown — surfaces wiring bugs
    early instead of silently returing ``None``.
    """
    for name in ("generate", "complete", "chat"):
        fn = getattr(client, name, None)
        if callable(fn):
            return fn(prompt, temperature=temperature)
    if callable(client):
        return client(prompt)
    raise TypeError(
        f"LLM client of type {type(client).__name__} has no .generate/.complete/"
        f".chat callable nor is callable directly"
    )


# ---------------------------------------------------------------------------
# BestOfN — sampling + scoring + selection
# ---------------------------------------------------------------------------


class BestOfN:
    """Best-of-N sampler with lightweight, deterministic rerank.

    The scorer is pure-Python so it does not consume the LLM budget or add
    LLM variance. Total score = weighted sum of 5 components, each in [0, 1].
    """

    def __init__(
        self,
        *,
        client_call: CompletionFn | None = None,
        rng_seed: int | None = 0,
    ) -> None:
        self._client_call = client_call or _default_client_call
        # Deterministic mode by default so tests are reproducible. Pass
        # ``rng_seed=None`` to disable seeding.
        self._rng_seed = rng_seed
        self._call_count = 0

    # --- sampling --------------------------------------------------------

    def generate(
        self,
        prompt: str,
        llm_client: LLMClient,
        n: int = 8,
        temperature: float = 0.9,
    ) -> List[str]:
        """Sample N candidates for the same prompt.

        Tries the client with a single ``n=...`` kwarg first (some clients
        expose batched sampling). On ``TypeError`` falls back to N independent
        calls. Strings are de-duplicated while preserving first-seen order
        so the reranker still has distinct candidates to compare.
        """
        if n <= 0:
            return []
        candidates = self._try_batched(prompt, llm_client, n, temperature)
        if candidates is None:
            candidates = [
                self._client_call(llm_client, prompt, temperature)
                for _ in range(n)
            ]
        # Filter empties, dedupe, but always return at least one item if any
        # string came back (even if all collapsed to the same value).
        seen: set[str] = set()
        unique: List[str] = []
        for item in candidates:
            if item is None:
                continue
            s = str(item)
            if not s:
                continue
            if s in seen:
                continue
            seen.add(s)
            unique.append(s)
        return unique or [str(c) for c in candidates if c] or [""]

    def _try_batched(
        self,
        prompt: str,
        llm_client: LLMClient,
        n: int,
        temperature: float,
    ) -> List[str] | None:
        """Try ``client.generate(prompt, temperature=..., n=...)`` once.

        Returns the list only when the client actually returns >= n items
        (treats shorter results as if the client doesn't support batching).
        """
        for name in ("generate", "complete", "chat"):
            fn = getattr(llm_client, name, None)
            if not callable(fn):
                continue
            try:
                result = fn(prompt, temperature=temperature, n=n)
            except TypeError:
                continue
            else:
                self._call_count += 1
                if isinstance(result, str):
                    # Single string back means per-sample client — refuse
                    # the "batched" claim and let the caller fall back.
                    return None
                if isinstance(result, Iterable):
                    items = [str(x) for x in result]
                    if len(items) < n:
                        # Client accepted n= but returned fewer items — count
                        # the call but don't trust the batch path; fall back
                        # to per-sample so we still produce N.
                        return None
                    return items
                return None
        return None

    # --- scoring ---------------------------------------------------------

    @staticmethod
    def _length_score(text: str, lo: int, hi: int) -> float:
        n = len(text.strip())
        if n == 0:
            return 0.0
        # Bell curve peaking at the midpoint; clamped to [0, 1].
        mid = (lo + hi) / 2.0
        if lo <= n <= hi:
            return 1.0 - 0.5 * abs(n - mid) / max(1.0, (hi - lo) / 2.0)
        # Outside the window: fall off quadratically.
        if n < lo:
            return max(0.0, 1.0 - ((lo - n) / max(1.0, lo)) ** 2)
        return max(0.0, 1.0 - ((n - hi) / max(1.0, hi)) ** 2)

    @staticmethod
    def _keyword_score(text: str, keywords: Sequence[str]) -> float:
        if not keywords:
            return 1.0
        text_l = text.lower()
        hits = sum(1 for k in keywords if k.lower() in text_l)
        return hits / len(keywords)

    @staticmethod
    def _format_score(text: str, want_json: bool) -> float:
        if not want_json:
            return 1.0
        s = text.strip()
        if not (s.startswith("{") and s.endswith("}")):
            return 0.0
        try:
            json.loads(s)
        except (ValueError, TypeError):
            return 0.3  # braces present but malformed → small credit
        return 1.0

    @staticmethod
    def _diversity_score(text: str, others: Sequence[str]) -> float:
        """Average 1 - ngram_jaccard against the known set."""
        if not others:
            return 1.0
        grams = _ngrams(text, n=3)
        if not grams:
            return 0.0
        scores = [1.0 - _jaccard(grams, _ngrams(o, n=3)) for o in others]
        return sum(scores) / len(scores)

    @staticmethod
    def _dup_score(text: str, others: Sequence[str]) -> float:
        # Lower score = exact duplicate. Identical but unseen = 1.0.
        # Substring duplication only counts against the *longer* string.
        if not others:
            return 1.0
        text_l = text.lower()
        for o in others:
            o_l = o.lower()
            if o_l == text_l:
                return 0.0
            longer, shorter = (text_l, o_l) if len(text_l) >= len(o_l) else (o_l, text_l)
            if shorter and shorter in longer:
                return 0.2
        return 1.0

    @classmethod
    def score(
        cls,
        candidate: str,
        prompt: str,
        criteria: ScoringCriteria,
        *,
        known_candidates: Sequence[str] = (),
    ) -> float:
        """Compute a single rerank score in [0, 1]."""
        bd = cls.score_breakdown(
            candidate, prompt, criteria, known_candidates=known_candidates
        )
        return bd.total(criteria.weights)

    @classmethod
    def score_breakdown(
        cls,
        candidate: str,
        prompt: str,
        criteria: ScoringCriteria,
        *,
        known_candidates: Sequence[str] = (),
    ) -> ScoreBreakdown:
        bd = ScoreBreakdown(
            length=cls._length_score(
                candidate, criteria.length_lo, criteria.length_hi
            ),
            keyword=cls._keyword_score(candidate, criteria.required_keywords),
            format=cls._format_score(candidate, criteria.want_json),
            diversity=cls._diversity_score(candidate, known_candidates),
            no_duplicate=cls._dup_score(candidate, known_candidates),
        )
        return bd

    # --- selection -------------------------------------------------------

    def select(
        self,
        candidates: Sequence[str],
        prompt: str,
        criteria: ScoringCriteria,
    ) -> tuple[str, List[ScoreResult]]:
        """Score all candidates, return ``(best, ranked_desc)``."""
        scored = self.score_all(candidates, prompt, criteria)
        if not scored:
            return "", []
        scored_sorted = sorted(scored, key=lambda r: r.score, reverse=True)
        return scored_sorted[0].text, scored_sorted

    def score_all(
        self,
        candidates: Sequence[str],
        prompt: str,
        criteria: ScoringCriteria,
    ) -> List[ScoreResult]:
        """Score all candidates, with diversity/no_duplicate calibrated against
        the *full* candidate set so no candidate gets unfair isolation.
        """
        results: List[ScoreResult] = []
        for c in candidates:
            others = [x for x in candidates if x is not c]
            bd = self.score_breakdown(
                c,
                prompt,
                criteria,
                known_candidates=others + list(criteria.known_candidates),
            )
            results.append(ScoreResult(text=c, score=bd.total(criteria.weights), breakdown=bd))
        return results

    # --- one-shot convenience -------------------------------------------

    def generate_best(
        self,
        prompt: str,
        llm_client: LLMClient,
        n: int = 8,
        criteria: ScoringCriteria | None = None,
        temperature: float = 0.9,
    ) -> str:
        crit = criteria or ScoringCriteria.from_prompt(prompt)
        candidates = self.generate(prompt, llm_client, n=n, temperature=temperature)
        best, _ = self.select(candidates, prompt, crit)
        return best


# ---------------------------------------------------------------------------
# QualityRouter — §5.6 route quality cost by commitment state
# ---------------------------------------------------------------------------

#: which path name corresponds to which commitment state
_ROUTES: Mapping[str, str] = {
    # speculative: may be invalidated, never trust the budget to it.
    "speculative": "single_greedy_short",
    # committing: about to be flushed into canon; spend the buffer on width.
    "committing": "best_of_n_rerank",
    # committed: already in canon; needs highest quality + validation.
    "committed": "max_quality_validate",
    # reflex: no LLM at all.
    "reflex": "no_llm",
}

_VALID_STATES = frozenset(_ROUTES)


class QualityRouter:
    """Map a commitment state to the path that matches its cost budget.

    §5.6 of the architecture spec:

    | state        | path                          | cost   |
    | ------------ | ----------------------------- | ------ |
    | speculative  | single greedy, short          | lowest |
    | committing   | best-of-N + rerank            | high,  |
    |              |                               | hidden |
    |              |                               | in     |
    |              |                               | buffer |
    | committed    | max quality + validation      | highest|
    | reflex       | no LLM                        | zero   |
    """

    def route(self, commitment_state: str) -> str:
        if commitment_state not in _VALID_STATES:
            raise ValueError(
                f"unknown commitment_state={commitment_state!r}; "
                f"expected one of {sorted(_VALID_STATES)}"
            )
        return _ROUTES[commitment_state]

    def expected_n(self, commitment_state: str) -> int:
        """Default batch width for the path. Useful for downstream budgeting."""
        n_map = {
            "speculative": 1,
            "committing": 8,
            "committed": 16,
            "reflex": 0,
        }
        if commitment_state not in n_map:
            raise ValueError(f"unknown commitment_state={commitment_state!r}")
        return n_map[commitment_state]

    @property
    def valid_states(self) -> frozenset[str]:
        return _VALID_STATES


# ---------------------------------------------------------------------------
# Token-level helpers (used by diversity scoring)
# ---------------------------------------------------------------------------


_WORD_RE = re.compile(r"\w+")


def _ngrams(text: str, n: int = 3) -> set[tuple[str, ...]]:
    tokens = _WORD_RE.findall(text.lower())
    if len(tokens) < n:
        return {tuple(tokens)} if tokens else set()
    return {tuple(tokens[i : i + n]) for i in range(len(tokens) - n + 1)}


def _jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 0.0
    union = a | b
    if not union:
        return 0.0
    return len(a & b) / len(union)


# ---------------------------------------------------------------------------
# Public surface
# ---------------------------------------------------------------------------

__all__ = [
    "BestOfN",
    "QualityRouter",
    "ScoringCriteria",
    "ScoreBreakdown",
    "ScoreResult",
]


# ---------------------------------------------------------------------------
# Self-check (python -m theater.best_of_n)
# ---------------------------------------------------------------------------


def _selftest() -> None:  # pragma: no cover - manual smoke
    router = QualityRouter()
    for state in router.valid_states:
        assert router.route(state) and router.expected_n(state) >= 0

    bon = BestOfN(client_call=lambda prompt, t: f"ANS[{prompt}][t={t}]")
    crit = ScoringCriteria.from_prompt("Find three creative business names")
    out = bon.generate_best(
        "Find three creative business names",
        llm_client=None,  # not used; client_call replaces it
        n=4,
        criteria=crit,
        temperature=0.7,
    )
    assert out.startswith("ANS[")


if __name__ == "__main__":  # pragma: no cover
    _selftest()
    print("ok")
