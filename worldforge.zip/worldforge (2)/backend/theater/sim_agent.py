"""SimAgent — runtime subjectification of characters (architecture spec §4.2).

A character card defines *who a character is / how they express themselves*
(§4.1).  A ``SimAgent`` turns that static definition into a *simulated
subject*: something that holds beliefs, remembers events, pursues goals,
and is bound to a particular world with particular permissions.

Structure (§4.2)::

    SimAgent
    ├── CharacterDefinition   (SillyTavern card: identity / background / role)
    ├── MindProfile           (stable personality → belief/utility/update params)
    ├── AgentMindState        (dynamic beliefs / memory / goals)
    ├── RuntimeState          (current objective state)
    └── WorldBinding          (world identity / permissions / knowledge scope)

P1 scope (this file): the data structures + a deterministic
``observe → update_belief → choose_action`` skeleton.  The skeleton returns
stub / deterministic defaults; the concrete bounded-confidence belief update
and decision policy arrive in P2 (paired with the economy kernel).  No LLM,
no randomness — everything here is a pure function of its inputs (§8.2 red
line).

Design notes
------------
- ``MindProfile`` does **not** map personality directly to decisions
  (stubborn→hoard+20 is the game-y trap Q3 rejected).  It only shapes three
  *epistemic* knobs the future belief-update / decision layers will read:
  evidence weight, risk profile, and belief-update rate.  Big Five is kept
  as an optional derived vocabulary (arxiv 2410.19238).
- ``AgentMindState`` reuses :class:`theater.cognitive_model.Belief` so the
  three-body model-error-limit work is shared infrastructure.
- ``WorldBinding.permissions`` mirrors the夺舍 ``possession_limit`` shape
  (allowed_actions) so a possessed character and a sim-agent speak the same
  authority language.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .belief_update import (
    DEFAULT_CONTRADICTION_THRESHOLD,
    BeliefUpdateTrace,
    derive_confidence_radius,
    derive_strategy,
    revise_belief,
)
from .cognitive_model import Belief


__all__ = [
    "CharacterDefinition",
    "MindProfile",
    "AgentMindState",
    "RuntimeState",
    "WorldBinding",
    "SimAgent",
]


# ---------------------------------------------------------------------------
# CharacterDefinition — static "who / how" (from card, §4.1)
# ---------------------------------------------------------------------------


@dataclass
class CharacterDefinition:
    """Static character definition sourced from a SillyTavern-style card.

    This is the *card* layer: it answers "who is this character / how do they
    express themselves".  It does **not** carry beliefs or goals — those live
    on :class:`AgentMindState`.  Field names mirror :class:`CharacterPatch`
    so the adapter can copy card fields across without renaming.
    """

    character_id: str = ""
    name: str = ""
    personality: str = ""
    appearance: str = ""
    sample_line: str = ""
    background: str = ""        # description / scenario from the card
    social_role: str = ""       # e.g. "商人" / "剑士" / "祭司"


# ---------------------------------------------------------------------------
# MindProfile — stable personality parameters (§4.2 / §10)
# ---------------------------------------------------------------------------


@dataclass
class MindProfile:
    """Stable personality parameters that shape belief formation / utility /
    update — **not** direct decisions.

    Three epistemic knobs (§10):

    - ``evidence_weight``: how much weight a new piece of evidence carries
      when the agent revises a belief.  固执 (stubborn) → low (×0.3);
      开放 (open) → high (×1.5).  Neutral default 1.0.
    - ``risk_profile``: how the agent weighs losses vs gains in a future
      utility layer.  谨慎 (cautious) → loss_weight > gain_weight;
      赌徒 (gambler) → the reverse.
    - ``belief_update_rate``: how fast beliefs move toward new evidence.
      固执 → slow; 理性 (rational) → fast.

    Big Five (openness / conscientiousness / extraversion / agreeableness /
    neuroticism, arxiv 2410.19238) is carried as an optional derived
    vocabulary in ``big_five`` — each axis in ``[0, 1]``.  It is *not* read
    by the P1 skeleton; downstream layers may use it as a stable trait
    vocabulary.
    """

    evidence_weight: float = 1.0
    risk_profile: Dict[str, float] = field(
        default_factory=lambda: {"loss_weight": 1.0, "gain_weight": 1.0}
    )
    belief_update_rate: float = 0.5
    big_five: Dict[str, float] = field(
        default_factory=lambda: {
            "openness": 0.5,
            "conscientiousness": 0.5,
            "extraversion": 0.5,
            "agreeableness": 0.5,
            "neuroticism": 0.5,
        }
    )


# Keyword → MindProfile influence tables.
#
# Matching is deterministic substring matching on the personality/appearance
# text (lowercased).  This is deliberately simple — P1 only needs the
# derived profile to exist and be stable; refinement is a later step.
#
# Each entry: (keywords, {knob: delta}).  Deltas are accumulated on top of
# the neutral defaults; the final value is clamped to a sane range.
_PERSONALITY_KEYWORDS: List[tuple] = [
    # stubborn / fixed mindset → low evidence weight, slow update
    (("固执", "顽固", "倔强", "stubborn", "inflexible"),
     {"evidence_weight": -0.7, "belief_update_rate": -0.3}),
    # open / curious → high evidence weight
    (("开放", "好奇", "open", "curious", "inquisitive"),
     {"evidence_weight": +0.5, "belief_update_rate": +0.1}),
    # cautious / careful → loss-averse
    (("谨慎", "小心", "cautious", "careful", "prudent"),
     {"loss_weight": +0.5}),
    # gambler / risk-taker → gain-seeking
    (("赌徒", "冒险", "鲁莽", "gambler", "reckless", "risk-seeking"),
     {"gain_weight": +0.5}),
    # rational → fast update
    (("理性", "冷静", "rational", "analytical"),
     {"belief_update_rate": +0.2}),
    # emotional / neurotic
    (("情绪", "敏感", "emotional", "sensitive", "neurotic"),
     {"neuroticism": +0.3}),
    # agreeable / warm
    (("友善", "温和", "agreeable", "warm", "kind"),
     {"agreeableness": +0.3}),
    # extraverted
    (("外向", "健谈", "extraverted", "outgoing", "talkative"),
     {"extraversion": +0.3}),
    # conscientious
    (("尽责", "勤勉", "conscientious", "diligent", "disciplined"),
     {"conscientiousness": +0.3}),
]


def _clamp(value: float, low: float = 0.0, high: float = 1.5) -> float:
    return max(low, min(high, value))


def derive_mind_profile(personality: str, appearance: str = "") -> MindProfile:
    """Derive a :class:`MindProfile` from card text, deterministically.

    No LLM, no randomness.  Keyword matching on the concatenated
    personality+appearance text shapes the three epistemic knobs and the
    Big Five vocabulary.  Missing keywords leave the neutral defaults in
    place.
    """
    text = f"{personality} {appearance}".lower()
    ew = 1.0
    bur = 0.5
    loss_w = 1.0
    gain_w = 1.0
    big_five = dict(MindProfile().big_five)

    for keywords, deltas in _PERSONALITY_KEYWORDS:
        if any(kw.lower() in text for kw in keywords):
            ew += deltas.get("evidence_weight", 0.0)
            bur += deltas.get("belief_update_rate", 0.0)
            loss_w += deltas.get("loss_weight", 0.0)
            gain_w += deltas.get("gain_weight", 0.0)
            for axis in ("openness", "conscientiousness", "extraversion",
                         "agreeableness", "neuroticism"):
                if axis in deltas:
                    big_five[axis] = _clamp(big_five[axis] + deltas[axis])

    return MindProfile(
        evidence_weight=_clamp(ew, 0.1, 2.0),
        risk_profile={
            "loss_weight": _clamp(loss_w, 0.0, 2.0),
            "gain_weight": _clamp(gain_w, 0.0, 2.0),
        },
        belief_update_rate=_clamp(bur, 0.05, 1.0),
        big_five=big_five,
    )


# ---------------------------------------------------------------------------
# AgentMindState — dynamic beliefs / memory / goals
# ---------------------------------------------------------------------------


@dataclass
class AgentMindState:
    """Dynamic mental state: what the agent currently believes / wants.

    - ``beliefs``: keyed beliefs, each a :class:`Belief` (Sabre commitment,
      reused from the cognitive-model layer so model-error / dramatic-irony
      infrastructure is shared).
    - ``memory``: append-only event history the agent has observed.
    - ``goals``: ordered list of active goals (free-form strings for P1;
      typed goals arrive with the decision layer).
    """

    beliefs: Dict[str, Belief] = field(default_factory=dict)
    memory: List[Dict[str, Any]] = field(default_factory=list)
    goals: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# RuntimeState — current objective state
# ---------------------------------------------------------------------------


@dataclass
class RuntimeState:
    """The agent's current objective state in the world.

    A thin, intentionally-generic bag for P1: location, possession flag,
    and a free-form ``extra`` map.  Worlds with richer objective state
    (three-body civ scalars, economy inventory) keep that state on their
    own kernels; this is the per-agent view the sim layer reads.
    """

    location: str = ""
    possessed: bool = False
    extra: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# WorldBinding — world identity / permissions / knowledge scope
# ---------------------------------------------------------------------------


@dataclass
class WorldBinding:
    """How the agent is bound to a world: identity, knowledge, authority.

    - ``world_id``: the world this agent lives in (world isolation §I4/§10.4).
    - ``knowledge_scope``: what the agent can perceive.  ``"*"`` = full
      visibility; otherwise a list of scope tags (e.g. ``["market"]``).
    - ``permissions.allowed_actions``: the action verbs this agent may take,
      mirroring夺舍 ``possession_limit.allowed_actions`` (§10.6) so a
      possessed character and a sim-agent share one authority vocabulary.
    """

    world_id: str = ""
    knowledge_scope: Any = "*"  # "*" or List[str]
    permissions: Dict[str, Any] = field(
        default_factory=lambda: {
            "allowed_actions": ["move", "speak", "inspect"],
        }
    )


# ---------------------------------------------------------------------------
# SimAgent — the composed runtime subject
# ---------------------------------------------------------------------------


class SimAgent:
    """A character turned into a simulated subject (§4.2).

    Composes :class:`CharacterDefinition` (static), :class:`MindProfile`
    (stable personality), :class:`AgentMindState` (dynamic), and
    :class:`WorldBinding` (world authority), plus a small
    :class:`RuntimeState`.

    The P1 skeleton exposes ``observe → update_belief → choose_action``.
    Each step is deterministic and returns a stable default; P2 fills in
    the bounded-confidence belief update and the decision policy.
    """

    def __init__(
        self,
        character: CharacterDefinition,
        mind: Optional[MindProfile] = None,
        world_binding: Optional[WorldBinding] = None,
        mind_state: Optional[AgentMindState] = None,
        runtime_state: Optional[RuntimeState] = None,
        character_graph: Any = None,
    ) -> None:
        self.character = character
        self.mind = mind if mind is not None else derive_mind_profile(
            character.personality, character.appearance)
        self.world_binding = world_binding if world_binding is not None else WorldBinding()
        self.mind_state = mind_state if mind_state is not None else AgentMindState()
        self.runtime = runtime_state if runtime_state is not None else RuntimeState()
        # Optional CharacterGraph binding (§5): when set, update_belief pulls
        # trust-weighted social_pressure from neighbours as extra evidence.
        # Left as Any so this module does not import character_graph at the
        # type level (avoids a cycle; the graph is keyed by agent id).
        self.character_graph = character_graph
        # Caller-stashable snapshot of peer beliefs for social_pressure:
        # ``{agent_id: {topic: float}}``.  Populated by the world each tick.
        self.peer_beliefs: Dict[str, Dict[str, float]] = {}
        # Last belief-revision trace (for quick introspection / narration).
        self.last_trace: Optional[BeliefUpdateTrace] = None

    # -- identity shortcuts -------------------------------------------------

    @property
    def character_id(self) -> str:
        return self.character.character_id

    @property
    def name(self) -> str:
        return self.character.name

    # -- perception / cognition / action skeleton --------------------------

    # ------------------------------------------------------------------
    # observe
    # ------------------------------------------------------------------

    #: Keys placed in the agent_binding handed to an ObservationFilter.
    #: The filter reads what it needs (e.g. ``trader_id``, ``tick``) and
    #: ignores the rest; ``character_id`` / ``world_id`` / ``seed`` are
    #: included so any filter can key noise/visibility off the subject.
    _BINDING_KEYS = ("character_id", "world_id", "knowledge_scope")

    def _build_binding(self, seed: Optional[int]) -> Dict[str, Any]:
        binding: Dict[str, Any] = {
            "character_id": self.character.character_id,
            "world_id": self.world_binding.world_id,
            "knowledge_scope": self.world_binding.knowledge_scope,
            "seed": seed,
        }
        # Flatten any extra objective state the filter may want (tick etc.).
        for k, v in self.runtime.extra.items():
            binding.setdefault(k, v)
        return binding

    @staticmethod
    def _looks_like_filter(obj: Any) -> bool:
        """Duck-type an ObservationFilter (has a callable ``observe``)."""
        return (
            obj is not None
            and not isinstance(obj, (dict, list, tuple, str, bytes, int, float, bool))
            and callable(getattr(obj, "observe", None))
        )

    def observe(
        self,
        observation_or_filter: Any = None,
        true_state: Optional[Dict[str, Any]] = None,
        *,
        seed: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """Take in an observation (spec §8 — the subject reads a *filtered*
        projection of kernel ground truth, never the raw truth).

        Two modes, selected by the first argument:

        - **Filter mode**: pass an :class:`ObservationFilter` as the first
          argument and the kernel's ``true_state`` as the second.  The
          filter projects ``true_state`` through this subject's binding
          (``character_id`` / ``world_id`` / ``knowledge_scope`` / ``seed``)
          into the observation the agent actually sees.  The filtered
          observation is appended to ``memory`` under a
          ``filtered_observation`` envelope (auditable: it records that the
          agent did *not* see raw truth) and returned.
        - **Stub mode** (backward compatibility): pass a raw dict / value
          with no filter.  It is appended verbatim, exactly as the P1
          skeleton did — so existing callers and tests keep working.

        Either way the agent never reads ground truth directly in filter
        mode; this is the structural seat of information/perception errors
        (§8 error sources ① / ②).
        """
        if self._looks_like_filter(observation_or_filter):
            filt = observation_or_filter
            binding = self._build_binding(seed)
            filtered = filt.observe(true_state or {}, binding)
            if not isinstance(filtered, dict):
                filtered = {"observation": filtered}
            envelope: Dict[str, Any] = {
                "type": "filtered_observation",
                "observation": filtered,
                "binding": binding,
                "filter_flags": filtered.get("filter_flags", []),
            }
            self.mind_state.memory.append(envelope)
            return filtered

        # ---- stub path: backward-compatible raw append ------------------
        if observation_or_filter is None:
            return None
        if isinstance(observation_or_filter, dict):
            self.mind_state.memory.append(observation_or_filter)
        else:
            self.mind_state.memory.append({"raw": observation_or_filter})
        return None

    # ------------------------------------------------------------------
    # update_belief
    # ------------------------------------------------------------------

    def _initial_belief_for(self, evidence: Any) -> Belief:
        """Build the fresh prior for a brand-new topic.

        Sabre commitment: the agent commits to a concrete value, not a
        distribution.  The first piece of numerical evidence becomes the
        committed ``predicted``; non-numeric evidence leaves
        ``predicted=None`` (qualitative — only confidence moves).
        Initial confidence is neutral (0.5); the revise step then nudges
        it per personality.
        """
        if isinstance(evidence, bool):
            predicted = None
        elif isinstance(evidence, (int, float)):
            predicted = float(evidence)
        else:
            try:
                predicted = float(evidence)
            except (TypeError, ValueError):
                predicted = None
        return Belief(
            predicted=predicted,
            confidence=0.5,
            model_error=False,
            committed_values={} if predicted is None else {"seed_evidence": predicted},
        )

    def _resolve_social_evidence(
        self,
        topic: str,
        primary_observation: Any,
        peer_beliefs: Optional[Dict[str, Dict[str, float]]],
    ) -> Dict[str, Any]:
        """Blend social_pressure into the primary observation (§5).

        When the agent is bound to a CharacterGraph and a peer-beliefs
        snapshot is available, the trust-weighted average of neighbours'
        beliefs on ``topic`` is folded into the primary observation.  The
        primary evidence still dominates (×0.7); social pressure contributes
        ×0.3 — enough to tilt a close call, not enough to override direct
        evidence.  Non-numeric primary observations skip blending (social
        pressure is a scalar; it cannot combine with a qualitative event).

        Returns ``{"observation": ..., "social_pressure": float, "blended": bool}``.
        """
        result = {
            "observation": primary_observation,
            "social_pressure": 0.0,
            "blended": False,
        }
        graph = self.character_graph
        if graph is None:
            return result
        peers = peer_beliefs if peer_beliefs is not None else self.peer_beliefs
        if not peers:
            return result
        # Local import — character_graph is optional and we avoid a hard
        # module-level dependency for agents that never use it.
        from .character_graph import social_pressure
        try:
            sp = social_pressure(graph, self.character.character_id, topic, peers)
        except Exception:
            sp = 0.0
        result["social_pressure"] = float(sp)
        if sp == 0.0:
            return result
        # Blend only when the primary observation is numeric.
        try:
            primary_float = float(primary_observation)
        except (TypeError, ValueError):
            return result
        blended = 0.7 * primary_float + 0.3 * float(sp)
        result["observation"] = blended
        result["blended"] = True
        return result

    def update_belief(
        self,
        topic: Optional[str] = None,
        evidence: Any = None,
        *,
        peer_beliefs: Optional[Dict[str, Dict[str, float]]] = None,
        seed: Optional[int] = None,
        observation_validated: bool = True,
    ) -> BeliefUpdateTrace:
        """Revise the agent's belief about ``topic`` given ``evidence``.

        Wires :func:`theater.belief_update.revise_belief` — the agent's
        :class:`MindProfile` derives the revision strategy (rational /
        dogmatic / conspiratorial), evidence weight, update rate and
        bounded-confidence radius.  The posterior is committed back into
        ``mind_state.beliefs[topic]`` and a full :class:`BeliefUpdateTrace`
        is recorded in ``memory`` (replayable) and returned.

        Social pressure (§5): when ``character_graph`` is bound and
        ``peer_beliefs`` is provided (or stashed on the agent), the
        trust-weighted neighbour average is blended into the observation
        before revision — the "decision = self belief + relationship belief
        + social pressure" composition.

        Determinism: pure function of ``(prior, evidence, mind, seed)``;
        no LLM, no unseeded randomness (§8.2 red line).
        """
        key = topic or "default"
        prior = self.mind_state.beliefs.get(key)
        if prior is None:
            prior = self._initial_belief_for(evidence)

        social = self._resolve_social_evidence(key, evidence, peer_beliefs)
        observation = social["observation"]

        personality_text = f"{self.character.personality} {self.character.appearance}"
        posterior, trace = revise_belief(
            prior=prior,
            observation=observation,
            profile=self.mind,
            topic=key,
            personality_text=personality_text,
            contradiction_threshold=DEFAULT_CONTRADICTION_THRESHOLD,
            seed=seed,
            observation_validated=observation_validated,
        )

        # Annotate the trace with the social-pressure contribution so the
        # full input set is replayable / auditable.
        trace.personality_modifiers["social_pressure"] = social["social_pressure"]
        trace.personality_modifiers["blended"] = social["blended"]
        trace.personality_modifiers["confidence_radius"] = derive_confidence_radius(self.mind)
        trace.personality_modifiers["strategy"] = derive_strategy(
            self.mind, personality_text)

        self.mind_state.beliefs[key] = posterior
        self.last_trace = trace
        # Store the trace in memory for replay / narration.
        self.mind_state.memory.append({
            "type": "belief_update",
            "topic": key,
            "trace": trace,
        })
        return trace

    # ------------------------------------------------------------------
    # choose_action
    # ------------------------------------------------------------------

    #: Base softmax temperature.  Higher → flatter → more impulsive.
    DECISION_TEMPERATURE_BASE: float = 1.0
    #: How many degrees of temperature one unit of social/perceived
    #: pressure adds.  Pressure high → temperature high → impulse.
    PRESSURE_TEMP_GAIN: float = 2.0
    #: Floor for temperature (never zero — zero would make softmax argmax).
    TEMPERATURE_FLOOR: float = 0.05

    def _candidate_score(
        self,
        candidate: Dict[str, Any],
    ) -> tuple:
        """Subjective score for one candidate action.

        ``score = subjective_belief × benefit − cost − risk × loss_weight
        + personality_modifier``

        - ``subjective_belief``: the agent's *committed* belief on the
          candidate's ``belief_topic`` (its subjective disaster/probability
          read — **not** the kernel's true probability).  Defaults to 0.0
          when the agent has no belief on that topic.
        - ``loss_weight``: from :attr:`mind.risk_profile` — cautious agents
          penalise risky actions more.
        - ``personality_modifier``: ``0.5 × (evidence_weight − 1.0)`` —
          open agents lean slightly toward acting on their beliefs,
          stubborn agents slightly against.  Kept small so personality
          shapes, never dictates (Q3 rejection of stubborn→hoard+20).

        Returns ``(verb, score, detail)`` where ``detail`` carries the
        decomposed pieces for the intent's ``subjective_scores`` /
        ``subjective_reason``.
        """
        verb = str(candidate.get("verb", "act"))
        target = candidate.get("target")
        benefit = float(candidate.get("benefit", 0.0))
        cost = float(candidate.get("cost", 0.0))
        risk = float(candidate.get("risk", 0.0))
        belief_topic = candidate.get("belief_topic")
        belief = self.mind_state.beliefs.get(belief_topic) if belief_topic else None
        subjective_belief = (
            float(belief.predicted) if (belief is not None
                                        and belief.predicted is not None) else 0.0
        )
        loss_weight = float(self.mind.risk_profile.get("loss_weight", 1.0))
        personality_mod = 0.5 * (float(self.mind.evidence_weight) - 1.0)
        score = (
            subjective_belief * benefit
            - cost
            - risk * loss_weight
            + personality_mod
        )
        detail = {
            "verb": verb,
            "target": target,
            "subjective_belief": subjective_belief,
            "benefit": benefit,
            "cost": cost,
            "risk": risk,
            "loss_weight": loss_weight,
            "personality_modifier": personality_mod,
            "score": score,
            "belief_topic": belief_topic,
            "belief_confidence": (
                float(belief.confidence) if belief is not None else 0.0
            ),
        }
        return verb, score, detail

    @staticmethod
    def _softmax_sample(scores: List[float], temperature: float,
                        rng: random.Random) -> int:
        """Seed-driven softmax sampling over ``scores``.

        Standard softmax with the temperature in the denominator; the
        highest-scoring action is favoured but not guaranteed — pressure
        raises the temperature and flattens the distribution toward
        impulsive choice.  Pure function of ``(scores, temperature, seed)``.
        """
        if not scores:
            return -1
        if temperature <= 0.0:
            temperature = 1.0
        m = max(scores)
        exps = [math.exp((s - m) / temperature) for s in scores]
        total = sum(exps)
        if total <= 0.0:
            return rng.randrange(len(scores))
        probs = [e / total for e in exps]
        r = rng.random()
        cum = 0.0
        for i, p in enumerate(probs):
            cum += p
            if r <= cum:
                return i
        return len(scores) - 1

    def choose_action(
        self,
        context: Optional[Dict[str, Any]] = None,
        *,
        seed: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Pick an action via subjective-utility softmax (§9.3 / §10).

        Each candidate is scored on the agent's **subjective** beliefs
        (subjective disaster probability, not the kernel's true
        probability) and personality-shaped utility, then sampled through a
        softmax whose temperature rises with perceived pressure (pressure
        high → temperature high → impulse).  Candidates are filtered
        through ``WorldBinding.permissions.allowed_actions`` first — the
        agent cannot choose a verb it is not authorised to take.

        Returns an :class:`ActionIntent`-shaped dict (verb / target /
        subjective_reason / belief_refs / subjective_scores / confidence).
        The intent is a *commitment to act*; it does not mutate the world
        (§12 red line — the kernel owns mutation).

        ``context`` shape::

            {
              "candidates": [
                {"verb": "flee", "target": "gate",
                 "benefit": 10.0, "cost": 2.0, "risk": 0.3,
                 "belief_topic": "danger"},
                ...
              ],
              "pressure": 0.0,   # optional — raises temperature
              "seed": 123,        # optional — overrides kwarg
            }

        When ``context`` is ``None`` or has no permitted candidates the
        agent falls back to ``"wait"`` (the P1 stub contract, preserved).
        """
        allowed = list(
            self.world_binding.permissions.get("allowed_actions") or []
        )
        allowed_set = set(allowed)

        ctx = context or {}
        raw_candidates = ctx.get("candidates") or []
        pressure = float(ctx.get("pressure", 0.0))
        rng_seed = seed if seed is not None else ctx.get("seed")

        # Filter candidates through the permission gate.
        permitted = [
            c for c in raw_candidates
            if str(c.get("verb", "act")) in allowed_set
        ]

        if not permitted:
            # No permitted candidates → deterministic fallback (stub parity).
            # When the agent has allowed actions but was given no candidates,
            # fall back to the first allowed verb (P1 skeleton contract).
            # When there are candidates but none are permitted, or there are
            # no allowed actions at all, the agent waits.
            fallback_verb = allowed[0] if allowed else "wait"
            return {
                "actor_id": self.character.character_id,
                "verb": fallback_verb,
                "target": None,
                "subjective_reason": "no permitted candidates; default",
                "belief_refs": [],
                "subjective_scores": {},
                "confidence": 0.0,
            }

        scored = [self._candidate_score(c) for c in permitted]
        scores = [s for _, s, _ in scored]
        details = [d for _, _, d in scored]

        temperature = max(
            self.TEMPERATURE_FLOOR,
            self.DECISION_TEMPERATURE_BASE + pressure * self.PRESSURE_TEMP_GAIN,
        )
        rng = random.Random(rng_seed)
        idx = self._softmax_sample(scores, temperature, rng)
        chosen = details[idx]

        # Build subjective_scores keyed by verb (last one wins on collision,
        # which is fine — verbs are unique within a candidate list normally).
        subjective_scores = {d["verb"]: d["score"] for d in details}

        belief_refs = [
            d["belief_topic"] for d in details
            if d.get("belief_topic") and d["belief_topic"] in self.mind_state.beliefs
        ]
        # Deduplicate while preserving order.
        seen = set()
        belief_refs = [b for b in belief_refs if not (b in seen or seen.add(b))]

        # Confidence in the chosen action: the confidence the agent has in
        # the belief that drove it (or the mean of referenced beliefs).
        if chosen.get("belief_topic") and chosen["belief_topic"] in self.mind_state.beliefs:
            confidence = float(
                self.mind_state.beliefs[chosen["belief_topic"]].confidence)
        elif belief_refs:
            confidence = sum(
                float(self.mind_state.beliefs[b].confidence) for b in belief_refs
            ) / len(belief_refs)
        else:
            confidence = 0.5

        reason = (
            f"softmax(T={temperature:.3f}) over {len(permitted)} permitted "
            f"candidate(s); chose '{chosen['verb']}' "
            f"(score={chosen['score']:.3f}, "
            f"subjective_belief={chosen['subjective_belief']:.3f}, "
            f"benefit={chosen['benefit']:.3f}, cost={chosen['cost']:.3f}, "
            f"risk×loss={chosen['risk'] * chosen['loss_weight']:.3f})"
        )

        return {
            "actor_id": self.character.character_id,
            "verb": chosen["verb"],
            "target": chosen["target"],
            "subjective_reason": reason,
            "belief_refs": belief_refs,
            "subjective_scores": subjective_scores,
            "confidence": confidence,
            "temperature": temperature,
            "pressure": pressure,
        }
