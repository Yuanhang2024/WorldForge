"""Prerequisite DAG + reachability checker (architecture spec §8.3, §8.1, §9.4).

One of the four universal machines (spec §8.1). Used by both the three-body
cognitive DAG and the fantasy recipe DAG; it is intentionally generic —
nodes are opaque ids, edges are "prereq must be unlocked before node".

Reachability queries are microsecond-level rule-engine work (spec §9.4
step ②): "can the user jump to this action?" is answered by
`can_reach(node_id)`. The user may *accelerate* along the DAG (resource
investment, priority changes) but may never *skip* nodes — `advance`
enforces this and rejects with an exception when prerequisites are unmet.

This module is pure stdlib Python. No external dependencies.
"""

from __future__ import annotations

from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Set, Tuple


class CycleError(ValueError):
    """Raised when an edge would introduce a cycle into the DAG."""

    def __init__(self, prereq_id: str, node_id: str) -> None:
        super().__init__(
            f"adding edge {prereq_id!r} -> {node_id!r} would create a cycle"
        )
        self.prereq_id = prereq_id
        self.node_id = node_id


class PrerequisiteError(ValueError):
    """Raised when a node operation requires prerequisites that are not met."""

    def __init__(self, node_id: str, missing: Iterable[str]) -> None:
        missing_list = sorted(missing)
        super().__init__(
            f"node {node_id!r} cannot be unlocked; "
            f"missing prerequisites: {missing_list}"
        )
        self.node_id = node_id
        self.missing: List[str] = missing_list


class UnknownNodeError(KeyError):
    """Raised when an unknown node id is referenced."""

    def __init__(self, node_id: str) -> None:
        super().__init__(node_id)
        self.node_id = node_id


class PrerequisiteDAG:
    """A directed acyclic graph of prerequisite relationships.

    Edge direction: `add_edge(prereq_id, node_id)` means "prereq_id is a
    prerequisite of node_id". A node is *unlocked* exactly when every
    prerequisite of that node has been unlocked.

    The graph is acyclic by construction — `add_edge` rejects edges that
    would close a cycle. The unlocked-set is independent of topological
    order: any node whose prerequisites are all in the unlocked-set may be
    unlocked next.
    """

    def __init__(self) -> None:
        # node_id -> metadata (arbitrary user-supplied dict, may be None)
        self._nodes: Dict[str, Optional[Dict[str, Any]]] = {}
        # node_id -> set of direct prerequisite ids
        self._prereqs: Dict[str, Set[str]] = {}
        # node_id -> set of direct dependent ids (reverse index, for queries)
        self._dependents: Dict[str, Set[str]] = {}
        # node_id -> True once unlocked (immutable per spec §8.2-style rule:
        # in a real game world unlocking is typically monotonic)
        self._unlocked: Dict[str, bool] = {}

    # -- mutation -------------------------------------------------------------

    def add_node(self, node_id: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Add a node (idempotent on existing id; metadata is overwritten).

        Returns self to allow chaining.
        """
        if node_id not in self._nodes:
            self._prereqs[node_id] = set()
            self._dependents[node_id] = set()
            self._unlocked[node_id] = False
        self._nodes[node_id] = metadata
        return self

    def add_edge(self, prereq_id: str, node_id: str) -> None:
        """Add 'prereq_id is a prerequisite of node_id'. Raises on cycle.

        Both endpoints must already exist (use `add_node` first).
        Returns self to allow chaining.
        """
        if prereq_id not in self._nodes:
            raise UnknownNodeError(prereq_id)
        if node_id not in self._nodes:
            raise UnknownNodeError(node_id)
        if prereq_id == node_id:
            # A self-loop is a trivial cycle; reject explicitly.
            raise CycleError(prereq_id, node_id)
        if self._would_create_cycle(prereq_id, node_id):
            raise CycleError(prereq_id, node_id)
        # No-op if the edge already exists.
        if prereq_id in self._prereqs[node_id]:
            return self
        self._prereqs[node_id].add(prereq_id)
        self._dependents[prereq_id].add(node_id)
        return self

    def unlock(self, node_id: str) -> None:
        """Mark a node as unlocked. No prerequisite check.

        Prefer `advance` (which enforces reachability). This lower-level
        method exists for restoring saves or seeding initial unlocked
        nodes (e.g. an entry-point node in a three-body DAG).
        """
        if node_id not in self._nodes:
            raise UnknownNodeError(node_id)
        self._unlocked[node_id] = True

    # -- queries --------------------------------------------------------------

    def has_node(self, node_id: str) -> bool:
        return node_id in self._nodes

    def nodes(self) -> List[str]:
        """All node ids (unspecified order)."""
        return list(self._nodes.keys())

    def prerequisites(self, node_id: str) -> List[str]:
        """Direct prerequisites of a node (unspecified order)."""
        if node_id not in self._nodes:
            raise UnknownNodeError(node_id)
        return list(self._prereqs[node_id])

    def dependents(self, node_id: str) -> List[str]:
        """Direct dependents of a node (unspecified order)."""
        if node_id not in self._nodes:
            raise UnknownNodeError(node_id)
        return list(self._dependents[node_id])

    def is_unlocked(self, node_id: str) -> bool:
        if node_id not in self._nodes:
            raise UnknownNodeError(node_id)
        return self._unlocked[node_id]

    def is_locked(self, node_id: str) -> bool:
        return not self.is_unlocked(node_id)

    def can_reach(self, node_id: str) -> bool:
        """True iff every prerequisite of node_id is unlocked.

        This is the microsecond-level rule-engine check used at scene-arrival
        time (spec §9.4 step ②): "is this action reachable in the DAG?"
        Recursive over the transitive prerequisite set.
        """
        if node_id not in self._nodes:
            raise UnknownNodeError(node_id)
        return all(self._unlocked[p] for p in self._prereqs[node_id])

    def missing_prerequisites(self, node_id: str) -> List[str]:
        """Prerequisites of node_id that are *not* yet unlocked.

        The list reflects only the *direct* prerequisites of `node_id` —
        transitively-missing prerequisites of those prereqs are surfaced by
        calling `missing_prerequisites` on each item in turn.
        """
        if node_id not in self._nodes:
            raise UnknownNodeError(node_id)
        return [p for p in self._prereqs[node_id] if not self._unlocked[p]]

    def advance(self, node_id: str) -> None:
        """Unlock `node_id` iff every prerequisite is already unlocked.

        Implements the spec §8.3 rule: the user may *accelerate* along the
        DAG but may never *skip* a node. If any direct or transitive
        prerequisite is still locked, raises PrerequisiteError and does
        not change state.
        """
        if node_id not in self._nodes:
            raise UnknownNodeError(node_id)
        if self._unlocked[node_id]:
            return  # idempotent: already unlocked
        missing = self.missing_prerequisites(node_id)
        if missing:
            raise PrerequisiteError(node_id, missing)
        self._unlocked[node_id] = True

    def path_to(self, node_id: str) -> List[str]:
        """Shortest path from the unlocked frontier to `node_id`.

        "From the unlocked frontier" is interpreted as: from any node X
        that is `is_unlocked(X)`. We BFS backward from `node_id` along
        prerequisite edges, restricted to nodes whose own prerequisites
        are already met or unlocked — i.e. nodes the player can *walk*
        given the current unlock state. The first such already-unlocked
        node we reach is the path's origin.

        The returned list is in forward unlock order: each successive
        element's prerequisites are all already in the list (or were
        unlocked before the call). The starting (already-unlocked)
        node is **not** included — the returned path represents the
        sequence of nodes the player still needs to unlock to reach
        `node_id`.

        If no such path exists (target not in graph, or target's
        prereqs are not met, or the graph has no connection from any
        unlocked node) the returned list is empty. An already-unlocked
        target returns an empty list (nothing to walk).
        """
        if node_id not in self._nodes:
            raise UnknownNodeError(node_id)

        if self._unlocked[node_id]:
            return []

        # A node is walkable if it's already unlocked or all its prereqs
        # are unlocked (i.e. it could be the next `advance`).
        def walkable(n: str) -> bool:
            return self._unlocked[n] or self.can_reach(n)

        # BFS backward from `node_id` along prerequisite edges. The first
        # already-unlocked node we pop is the shortest-path origin.
        from collections import deque

        visited: Set[str] = {node_id}
        parent: Dict[str, str] = {}
        queue: deque[str] = deque([node_id])
        goal_start: Optional[str] = None
        while queue:
            cur = queue.popleft()
            if cur != node_id and self._unlocked[cur]:
                goal_start = cur
                break
            for pre in self._prereqs[cur]:
                if pre in visited:
                    continue
                if not walkable(pre):
                    continue
                visited.add(pre)
                parent[pre] = cur
                queue.append(pre)

        if goal_start is None:
            return []

        # Reconstruct forward path: goal_start -> ... -> node_id.
        path_back: List[str] = [goal_start]
        cur = goal_start
        while cur != node_id:
            nxt = parent[cur]
            path_back.append(nxt)
            cur = nxt
        # Drop the leading already-unlocked origin; what remains is the
        # unlock sequence the player still needs to walk.
        return path_back[1:]

    def topological_order(self) -> List[str]:
        """Topological sort of all nodes (Kahn's algorithm).

        Raises CycleError if the graph is not a DAG — but `add_edge`
        prevents cycles, so this is defensive.
        """
        in_degree: Dict[str, int] = {n: len(self._prereqs[n]) for n in self._nodes}
        from collections import deque

        ready: deque[str] = deque(
            sorted(n for n, d in in_degree.items() if d == 0)
        )
        order: List[str] = []
        while ready:
            n = ready.popleft()
            order.append(n)
            for dep in sorted(self._dependents[n]):
                in_degree[dep] -= 1
                if in_degree[dep] == 0:
                    ready.append(dep)
        if len(order) != len(self._nodes):
            # Should be unreachable given add_edge's cycle check, but keep it.
            remaining = [n for n in self._nodes if n not in order]
            raise CycleError("<cycle-detected>", remaining[0] if remaining else "?")
        return order

    def unlocked_set(self) -> FrozenSet[str]:
        """Snapshot of currently-unlocked node ids."""
        return frozenset(n for n, u in self._unlocked.items() if u)

    # -- serialization --------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a JSON-friendly dict.

        Pairs with §13.1 archive schema — the dict contains a version
        field so future migrations can dispatch on it.
        """
        nodes_list: List[Dict[str, Any]] = []
        for nid in sorted(self._nodes.keys()):
            nodes_list.append({
                "id": nid,
                "metadata": self._nodes[nid],
                "prerequisites": sorted(self._prereqs[nid]),
                "unlocked": self._unlocked[nid],
            })
        return {
            "schema_version": 1,
            "kind": "prerequisite_dag",
            "nodes": nodes_list,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PrerequisiteDAG":
        """Inverse of `to_dict`. Schema-version dispatch lives here.

        Raises ValueError if the schema version is not understood.
        """
        version = data.get("schema_version")
        if version != 1:
            raise ValueError(
                f"unsupported prerequisite_dag schema_version: {version!r}"
            )
        dag = cls()
        nodes = data.get("nodes", [])
        # Two passes so all nodes exist before any edge is added.
        for entry in nodes:
            dag.add_node(entry["id"], metadata=entry.get("metadata"))
        for entry in nodes:
            for pre in entry.get("prerequisites", []):
                dag.add_edge(pre, entry["id"])
            if entry.get("unlocked", False):
                dag.unlock(entry["id"])
        return dag

    # -- internal -------------------------------------------------------------

    def _would_create_cycle(self, prereq_id: str, node_id: str) -> bool:
        """True iff the edge prereq_id -> node_id would close a cycle.

        An edge would create a cycle iff `node_id` is already (transitively)
        a prerequisite of `prereq_id`. Reach forward from `node_id` along
        dependent edges and check whether `prereq_id` is in that set.
        """
        # Iterative DFS forward from node_id over dependents.
        stack: List[str] = list(self._dependents[node_id])
        seen: Set[str] = set()
        while stack:
            cur = stack.pop()
            if cur == prereq_id:
                return True
            if cur in seen:
                continue
            seen.add(cur)
            stack.extend(self._dependents[cur])
        return False


# ---------------------------------------------------------------------------
# Factory: three-body cognitive DAG (spec §8.3)
# ---------------------------------------------------------------------------

# (node_id, metadata) for the canonical three-body cognitive progression.
_THREE_BODY_COGNITION_NODES: Tuple[Tuple[str, Dict[str, Any]], ...] = (
    ("observe",            {"label": "观测记录",          "stage": "myth"}),
    ("curve_fit",          {"label": "曲线拟合",          "stage": "empirical"}),
    ("periodicity",        {"label": "周期性假说",        "stage": "empirical"}),
    ("falsify_periodic",   {"label": "证伪周期性",        "stage": "paradigm_shift"}),
    ("gravity_law",        {"label": "引力定律",          "stage": "classical"}),
    ("three_body_eq",      {"label": "三体方程",          "stage": "classical"}),
    ("numerical_integrate",{"label": "数值积分",          "stage": "computational"}),
    ("sensitive_dependence",{"label": "敏感依赖",         "stage": "computational"}),
    ("chaos",              {"label": "混沌",              "stage": "computational"}),
    ("lyapunov_wall",      {"label": "Lyapunov 墙",       "stage": "limit"}),
    ("escape",             {"label": "逃离",              "stage": "limit"}),
)

# (prereq_id, node_id) edges. Mirrors the spec §8.3 ASCII diagram:
#   观测记录 -> 曲线拟合 -> 周期性假说
#                          \-> (证伪) -> 引力定律 -> 三体方程 -> 数值积分
#                                                       \-> 敏感依赖 -> 混沌
#                                                                     \-> Lyapunov 墙 -> 逃离
_THREE_BODY_COGNITION_EDGES: Tuple[Tuple[str, str], ...] = (
    ("observe",            "curve_fit"),
    ("curve_fit",          "periodicity"),
    ("periodicity",        "falsify_periodic"),
    ("falsify_periodic",   "gravity_law"),
    ("gravity_law",        "three_body_eq"),
    ("three_body_eq",      "numerical_integrate"),
    ("numerical_integrate","sensitive_dependence"),
    ("numerical_integrate","lyapunov_wall"),  # also reachable via sensitive_dependence -> chaos -> lyapunov_wall
    ("sensitive_dependence","chaos"),
    ("chaos",              "lyapunov_wall"),
    ("lyapunov_wall",      "escape"),
)


def three_body_cognition_dag() -> PrerequisiteDAG:
    """Build the canonical three-body cognitive DAG from spec §8.3.

    The returned DAG has all nodes and edges wired up but every node is
    locked. Callers (e.g. world creation) decide which entry-point node
    is initially unlocked.

    This factory is the single source of truth for the three-body
    cognitive graph structure; tests and runtime code consume it via
    this function rather than re-listing edges.
    """
    dag = PrerequisiteDAG()
    for nid, meta in _THREE_BODY_COGNITION_NODES:
        dag.add_node(nid, metadata=dict(meta))
    for pre, nxt in _THREE_BODY_COGNITION_EDGES:
        dag.add_edge(pre, nxt)
    return dag