"""CharacterCardAdapter — SillyTavern card → SimAgent (architecture §5).

Import flow (§5)::

    SillyTavern Card → CharacterCardAdapter.adapt
        → CharacterDefinition   (card fields, copied across)
        → MindProfile           (derived from personality/appearance text)
        → WorldBinding          (defaults: world_id placeholder,
                                 full knowledge, default permissions)
        → SimAgent

This is an **upper-layer wrapper** over :mod:`theater.world_import`: it calls
``WorldImporter.parse_card`` to do the deterministic card parse (injection
scan, gap detection, field aliases — all reused) and repackages the result
into the SimAgent layer's typed structures.  ``world_import`` remains
independently usable; nothing here changes its behaviour.

No LLM, no randomness — the adapter is a pure transform.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

from .sim_agent import (
    AgentMindState,
    CharacterDefinition,
    MindProfile,
    RuntimeState,
    SimAgent,
    WorldBinding,
    derive_mind_profile,
)
from .world_import import WorldImporter


__all__ = ["CharacterCardAdapter", "adapt_card"]


# Default allowed_actions mirrors夺舍 possession_limit (§10.6) so a sim-agent
# and a possessed character share one authority vocabulary.
_DEFAULT_ALLOWED_ACTIONS = ["move", "speak", "inspect"]


class CharacterCardAdapter:
    """Adapt a SillyTavern-style card JSON into SimAgent components (§5).

    Wraps :class:`WorldImporter.parse_card` for the deterministic parse
    (reusing its injection scan + field aliasing) and layers the SimAgent
    typing on top.  The adapter never calls an LLM; MindProfile is derived
    deterministically from card text via :func:`derive_mind_profile`.
    """

    @staticmethod
    def adapt(card_json: Dict[str, Any], *,
              world_id: str = "",
              knowledge_scope: Any = "*",
              allowed_actions: Optional[list] = None,
              ) -> Tuple[CharacterDefinition, MindProfile, WorldBinding]:
        """Adapt a card JSON → (CharacterDefinition, MindProfile, WorldBinding).

        Parameters
        ----------
        card_json:
            SillyTavern-style card dict (flat v2 or nested v1 aliases —
            handled by ``WorldImporter.parse_card``).
        world_id:
            World to bind the agent to (world isolation §I4).  Empty
            string = placeholder; the dispatcher fills the real id when it
            installs the agent.
        knowledge_scope:
            What the agent can perceive.  ``"*"`` (default) = full
            visibility; otherwise a list of scope tags.
        allowed_actions:
            Permission verbs.  Defaults to ``["move", "speak", "inspect"]``
            mirroring夺舍 ``possession_limit``.
        """
        parsed = WorldImporter.parse_card(card_json or {})

        character = CharacterDefinition(
            character_id=parsed.character_id or parsed.name,
            name=parsed.name,
            personality=parsed.personality,
            appearance="",  # card v2 has no separate appearance field
            sample_line=parsed.first_mes,
            background=parsed.description,
            social_role=str(parsed.extended.get("social_role", "")),
        )

        mind = derive_mind_profile(parsed.personality)

        world_binding = WorldBinding(
            world_id=world_id,
            knowledge_scope=knowledge_scope,
            permissions={
                "allowed_actions": list(
                    allowed_actions if allowed_actions is not None
                    else _DEFAULT_ALLOWED_ACTIONS
                ),
            },
        )

        return character, mind, world_binding

    @staticmethod
    def to_sim_agent(card_json: Dict[str, Any], **kwargs) -> SimAgent:
        """Convenience: adapt a card straight to a ready :class:`SimAgent`."""
        character, mind, world_binding = CharacterCardAdapter.adapt(
            card_json, **kwargs)
        return SimAgent(
            character=character,
            mind=mind,
            world_binding=world_binding,
            mind_state=AgentMindState(),
            runtime_state=RuntimeState(),
        )


def adapt_card(card_json: Dict[str, Any], **kwargs) -> SimAgent:
    """Module-level convenience wrapper around
    :meth:`CharacterCardAdapter.to_sim_agent`."""
    return CharacterCardAdapter.to_sim_agent(card_json, **kwargs)
