"""Schema migration chain framework (§13.1).

Defines Migration (single step), MigrationChain (pipeline with pathfinding),
and the pre-registered chain (v0→…→v6). Pure Python, no heavy imports —
testable standalone.

Usage:

    chain = get_default_chain()
    state = {"characters": [], "worldbook": []}          # v0 (no _meta)
    state = chain.migrate(state, target_version=2)       # → v2 with _meta
    print(chain.downgrade_export(state))                 # → readable text
"""

from __future__ import annotations

import json
from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple


@dataclass
class Migration:
    """A single migration step from one schema version to another."""

    from_version: int
    to_version: int
    migrate_fn: Callable[[dict], dict]
    description: str


class MigrationError(Exception):
    """Raised when migration fails or no path exists."""


class MigrationChain:
    """A directed graph of schema migrations with BFS pathfinding.

    Register migrations with ``register()``, then call ``migrate()`` to
    advance a state dict from its current version to the target version
    by applying the shortest chain of registered steps.
    """

    def __init__(self) -> None:
        self._migrations: dict[tuple[int, int], Migration] = {}

    # -----------------------------------------------------------------
    # Registration
    # -----------------------------------------------------------------

    def register(
        self,
        from_version: int,
        to_version: int,
        migrate_fn: Callable[[dict], dict],
        description: str,
    ) -> None:
        """Register a migration step *from_version* → *to_version*.

        Raises ``ValueError`` if the same edge is already registered.
        """
        key = (from_version, to_version)
        if key in self._migrations:
            raise ValueError(
                f"Migration {from_version}→{to_version} already registered"
            )
        self._migrations[key] = Migration(
            from_version, to_version, migrate_fn, description,
        )

    # -----------------------------------------------------------------
    # Introspection
    # -----------------------------------------------------------------

    @staticmethod
    def current_version(state: dict) -> int:
        """Read the ``schema_version`` from ``state["_meta"]``.

        Returns 0 when the state has no ``_meta`` or no ``schema_version``
        key — the convention for pre-migration save files.
        """
        meta = state.get("_meta")
        if isinstance(meta, dict):
            return int(meta.get("schema_version", 0))
        return 0

    def needs_migration(self, state: dict, target_version: int) -> bool:
        """Return ``True`` if *state* is behind *target_version*."""
        return self.current_version(state) < target_version

    # -----------------------------------------------------------------
    # Pathfinding & migration
    # -----------------------------------------------------------------

    def _find_path(self, from_version: int, to_version: int) -> list[Migration]:
        """BFS across registered edges to find a shortest path.

        Returns ``[]`` when *from_version* == *to_version*.
        Raises ``MigrationError`` when no path exists.
        """
        if from_version == to_version:
            return []

        # adjacency: from_version -> [(to_version, Migration)]
        adj: dict[int, list[tuple[int, Migration]]] = {}
        for m in self._migrations.values():
            adj.setdefault(m.from_version, []).append((m.to_version, m))

        visited: set[int] = {from_version}
        queue: deque = deque()
        queue.append((from_version, []))

        while queue:
            cur, path = queue.popleft()
            for next_ver, mig in adj.get(cur, []):
                new_path = [*path, mig]
                if next_ver == to_version:
                    return new_path
                if next_ver not in visited:
                    visited.add(next_ver)
                    queue.append((next_ver, new_path))

        raise MigrationError(
            f"No migration path from v{from_version} to v{to_version}"
        )

    def migrate(self, state: dict, target_version: int) -> dict:
        """Run all necessary migration steps to reach *target_version*.

        Returns the migrated state dict.  Raises ``MigrationError`` on
        pathfinding failure or if any step's ``migrate_fn`` raises.
        """
        current = self.current_version(state)
        if current == target_version:
            return state

        path = self._find_path(current, target_version)
        result = state
        for mig in path:
            try:
                result = mig.migrate_fn(result)
            except Exception as exc:
                raise MigrationError(
                    f"Migration v{mig.from_version}→v{mig.to_version} failed: {exc}"
                ) from exc
            # Ensure _meta exists and the version is bumped
            result.setdefault("_meta", {})
            result["_meta"]["schema_version"] = mig.to_version
        return result

    # -----------------------------------------------------------------
    # Degradation strategy (§13.1 fallback)
    # -----------------------------------------------------------------

    def downgrade_export(self, state: dict) -> str:
        """Render *state* as human-readable plain text.

        Called when migration is impossible so the user gets something
        readable ("even if they can't play, it wasn't for nothing").
        """
        ver = self.current_version(state)
        meta = state.get("_meta", {})
        lines: list[str] = [
            "=" * 60,
            "  WORLD STATE EXPORT  (unable to migrate — §13.1 fallback)",
            "=" * 60,
            f"  Schema version : {ver}",
            f"  World ID       : {meta.get('world_id', 'unknown')}",
            f"  Characters     : {len(state.get('characters', []))}",
            f"  World book     : {len(state.get('worldbook', []))}",
            f"  Scene objects  : {len(state.get('objects', []))}",
        ]

        # --- Characters ---
        lines.extend(["", "── Characters ──"])
        chars = state.get("characters", [])
        if chars:
            for c in chars:
                name = c.get("name") or c.get("character_id") or "?"
                summary = c.get("summary", "")
                snippet = (summary[:120] + "...") if len(summary) > 120 else summary
                lines.append(f"  {name}")
                if snippet:
                    lines.append(f"    {snippet}")
        else:
            lines.append("  (none)")

        # --- World book ---
        lines.extend(["", "── World Book ──"])
        wb = state.get("worldbook", [])
        if wb:
            for entry in wb:
                title = entry.get("title", "?")
                content = entry.get("content", "")
                if len(content) > 200:
                    content = content[:200] + "…"
                lines.append(f"  [{title}] {content}")
        else:
            lines.append("  (none)")

        # --- Scene objects ---
        lines.extend(["", "── Scene Objects ──"])
        objs = state.get("objects", [])
        if objs:
            for o in objs:
                name = o.get("name") or o.get("object_id") or "?"
                loc = o.get("location", "?")
                lines.append(f"  {name}  @ {loc}")
        else:
            lines.append("  (none)")

        # --- Raw metadata block ---
        if meta:
            lines.extend(
                ["", "── Raw Metadata ──", json.dumps(meta, indent=2, ensure_ascii=False)]
            )

        lines.extend(["", "=" * 60, "  END OF EXPORT", "=" * 60])
        return "\n".join(lines)


# =====================================================================
# Pre-registered migrations
# =====================================================================

def _v0_to_v1(state: dict) -> dict:
    """v0 → v1: mark bare state with schema_version = 1."""
    state.setdefault("_meta", {})
    state["_meta"].setdefault("schema_version", 1)
    return state


def _v1_to_v2(state: dict) -> dict:
    """v1 → v2: add world metadata (_meta block)."""
    state.setdefault("_meta", {})
    meta = state["_meta"]
    meta.setdefault("world_id", "main")
    meta.setdefault("created_from", None)
    meta.setdefault("sandbox", False)
    meta.setdefault("constraint_mutations", [])
    return state


def _v2_to_v3(state: dict) -> dict:
    """v2 → v3: add text/GUI provenance and deterministic world metadata."""
    meta = state.setdefault("_meta", {})
    meta.setdefault("generator_ids", {"llm": None, "gui_compiler": None})
    meta.setdefault("world_params", {
        "lambda": None,
        "initial_conditions_seed": None,
        "enabled_kernels": [],
        "sealed_solutions": {},
    })
    # Move sandbox + constraint_mutations into integrity_flags sub-object
    sandbox = meta.pop("sandbox", False)
    mutations = meta.pop("constraint_mutations", [])
    meta.setdefault("integrity_flags", {
        "sandbox": sandbox,
        "constraint_mutations": mutations,
    })
    return state


def _v3_to_v4(state: dict) -> dict:
    """v3 → v4: backfill WorldBookEntry.provenance (§17 P0 事实隔离).

    Old worldbook entries predate the provenance field. Infer a type from
    each entry's ``source`` string (narration / lore / canonical default) so
    LLM prose doesn't masquerade as canonical truth after the bump.
    """
    # Imported lazily so ``migrations`` stays decoupled from ``storage`` at
    # module load (storage imports migrations at its module top).
    from .storage import _infer_provenance
    for entry in state.get("worldbook", []):
        if isinstance(entry, dict) and not entry.get("provenance"):
            entry["provenance"] = _infer_provenance(entry.get("source", ""))
    return state


# Character fields removed when the art/music/animation pipeline was deleted
# (WorldForge is a pure world engine). Old saves still carrying these keys
# would break CharacterEntry(**item) at load time, so strip them on migration.
_DROPPED_CHARACTER_FIELDS = (
    "voice_id", "portrait_asset_id", "chardoll_bundle_id",
    "views", "motion_clips", "equipment",
)


def _v4_to_v5(state: dict) -> dict:
    """v4 → v5: drop removed art/animation fields from character records."""
    for char in state.get("characters", []):
        if not isinstance(char, dict):
            continue
        for key in _DROPPED_CHARACTER_FIELDS:
            char.pop(key, None)
    return state


def _v5_to_v6(state: dict) -> dict:
    """v5 → v6: remove the retired media and character-animation contracts.

    Old saves remain readable, but media-generation provenance, synthesized
    voice settings, bone attachments and per-state visual bindings are no
    longer copied into the active world schema.
    """
    for char in state.get("characters", []):
        if not isinstance(char, dict):
            continue
        for key in (
            "voice_style",
            "voice_id",
            "voice_identity",
            "portrait_asset_id",
            "chardoll_bundle_id",
            "views",
            "motion_clips",
            "equipment",
        ):
            char.pop(key, None)
        cleaned_actions = []
        for action in char.get("pending_ai_actions", []) or []:
            if not isinstance(action, dict):
                continue
            action = dict(action)
            for key in (
                "bones",
                "keyframes",
                "expression",
                "mouth_open",
                "look_at",
                "facing",
                "easing",
                "duration",
                "loop",
            ):
                action.pop(key, None)
            if action:
                cleaned_actions.append(action)
        char["pending_ai_actions"] = cleaned_actions

    for obj in state.get("objects", []):
        if isinstance(obj, dict):
            obj.pop("state_assets", None)

    state.pop("attachments", None)
    state.pop("assets", None)

    meta = state.setdefault("_meta", {})
    generator_ids = meta.get("generator_ids")
    if isinstance(generator_ids, dict):
        meta["generator_ids"] = {
            key: value
            for key, value in generator_ids.items()
            if key in {"llm", "gui_compiler"}
        }
        meta["generator_ids"].setdefault("llm", None)
        meta["generator_ids"].setdefault("gui_compiler", None)
    else:
        meta["generator_ids"] = {"llm": None, "gui_compiler": None}
    return state


# Singleton with all built-in migrations
_default_chain = MigrationChain()
_default_chain.register(0, 1, _v0_to_v1, "Mark bare state as schema v1")
_default_chain.register(1, 2, _v1_to_v2, "Add world metadata (_meta)")
_default_chain.register(2, 3, _v2_to_v3,
                         "Add generator_ids / world_params / integrity_flags (§15.2)")
_default_chain.register(3, 4, _v3_to_v4,
                         "Backfill WorldBookEntry.provenance (§17 P0 事实隔离)")
_default_chain.register(4, 5, _v4_to_v5,
                         "Drop removed art/animation character fields")
_default_chain.register(5, 6, _v5_to_v6,
                         "Drop retired media and character-animation contracts")


def get_default_chain() -> MigrationChain:
    """Return the singleton default migration chain."""
    return _default_chain
