"""Cognitive model layer (architecture spec §8.2 — model-error limit).

A world's subjects model reality imperfectly.  Spec §8.2 distinguishes two
limits on predictability: the *model-error limit* (breakable — a better
theory/tech sharpens δ₀) and the *Lyapunov / chaos limit* (unbreakable).
This module factors the *model-error limit* out of the kernel into an
explicit, BDI-flavoured protocol so the same notion of "subjective,
possibly-wrong prediction" can be reused by worlds beyond three-body
(economy / social / card-game in later steps).

BDI vocabulary (ported from the Sabre tradition, name kept light):

  - **ground truth**  — what the deterministic kernel knows is true
    (read-only to the subject).  This is the kernel's territory.
  - **belief**       — the subject's *committed* prediction (Sabre
    commitment: the subject commits to concrete values, never "maybe A
    maybe B").  Built from the subject's capability, may differ from
    ground truth.
  - **desire/intention** — not represented here; they belong to the
    decision layer (``decision_vector`` in three-body, future kernels'
    own policy layers).  This module only models the *epistemic* side.

The gap between ``ground_truth_state`` and ``Belief.predicted`` is the
literary device known as **dramatic irony**: the audience (holding the
kernel's ground truth) knows more than the subject.  That gap is the
source of narrative tension the narrator layer dramatises.

Step 1 scope (this file): protocol + three-body adapter, **pure refactor**.
No belief revision / bounded-confidence update yet (step 2), no economy
adapter (step 3).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Protocol, runtime_checkable


__all__ = ["Belief", "CognitiveModel", "ThreeBodyCognitiveModel"]


# ---------------------------------------------------------------------------
# Belief — a subject's committed prediction (Sabre commitment)
# ---------------------------------------------------------------------------


@dataclass
class Belief:
    """A subject's committed prediction of reality.

    Sabre-style commitment: the subject commits to *concrete* values, it
    does not carry "A with 40% chance, B with 60%".  ``confidence`` is a
    scalar self-assessment of that committed prediction, not a distribution
    over alternatives.  When the commitment disagrees with the kernel's
    ground truth, ``model_error`` is set — the dramatic-irony flag the
    narrator can lean on.

    Fields
    ------
    predicted:
        The subject's committed prediction of the world's next salient
        event (kernel-specific: for three-body this is the next chaotic
        era time the subject believes it will face, or ``None`` when the
        subject believes no such event is coming within its horizon).
    confidence:
        Scalar in ``[0, 1]`` — how confident the subject is in its
        committed prediction.  Derived from capability (e.g. tech_level).
    model_error:
        ``True`` when the committed prediction disagrees with ground
        truth (the subject's horizon failed to cover an event that the
        kernel knows is coming).  This is the dramatic-irony gap.
    committed_values:
        Concrete auxiliary values the subject committed to (e.g.
        ``T_predict``, ``delta_0``).  Committed, not probabilistic —
        Sabre commitment.  Step 2 (belief revision) will read/update
        this dict; step 1 only populates it.
    """

    predicted: Optional[float] = None
    confidence: float = 1.0
    model_error: bool = False
    committed_values: Dict[str, float] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# CognitiveModel protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class CognitiveModel(Protocol):
    """A world's subjects model reality imperfectly (spec §8.2 model-error limit).

    BDI-flavoured: ``belief`` (subjective prediction) vs ground truth
    (kernel).  Implementations are deterministic and seed-driven — no
    randomness, no LLM (spec §8.2 red line: physics and observations are
    kernel-owned; the LLM only narrates).

    Implementations must be pure functions of ``(ground_truth_state,
    agent_capability, t)`` — the same inputs yield the same ``Belief``.
    This is what makes ``model_error`` a *deterministic* misprediction
    (seed-driven), not a random fluke.
    """

    def predict(
        self,
        ground_truth_state: Dict[str, Any],
        agent_capability: Dict[str, Any],
        t: float,
    ) -> Belief:
        """Build a committed prediction from the subject's (imperfect) capability.

        Parameters
        ----------
        ground_truth_state:
            What the kernel knows is true (read-only to the subject).
            For three-body: ``{"next_chaos": float | None}`` — the real
            next chaotic-era start time.
        agent_capability:
            What determines prediction accuracy.  For three-body:
            ``{"tech_level": float, "delta_0": float, "T_predict": float}``
            — the subject's observation precision and the horizon it buys.
        t:
            The subject's current time.

        Returns
        -------
        Belief
            The subject's committed prediction.  ``model_error`` is set
            when the prediction disagrees with ``ground_truth_state``.
        """
        ...


# ---------------------------------------------------------------------------
# Three-body adapter
# ---------------------------------------------------------------------------


class ThreeBodyCognitiveModel:
    """Wraps the three-body δ₀→horizon misprediction as a ``CognitiveModel``.

    The three-body civilisation's epistemic state is the prediction
    horizon ``T_predict = (1/λ)·ln(Δ/δ₀)`` (spec §8.2) where ``δ₀`` is
    set by the civilisation's tech level.  When the horizon does **not**
    reach the next chaotic era, the subject commits to "no chaos
    coming" — a misprediction (``model_error=True``), because the kernel
    knows chaos is coming.  This is the model-error limit made explicit;
    it was previously implicit inside ``civilization_outcome``.

    Behaviour-preserving: the ``survived``/``destroyed`` verdict is
    still computed by the kernel's existing horizon logic; this class
    only names the belief and its ``model_error`` flag so the narrator
    and future belief-revision steps have a handle to read.

    Determinism: every input (λ from the baked kernel, next_chaos from
    the baked era list, tech_level → δ₀) is deterministic in the seed,
    so ``predict`` is a pure function — the same misprediction every
    time for the same seed/tech.
    """

    def __init__(self, kernel: Any) -> None:
        self._kernel = kernel

    def predict(
        self,
        ground_truth_state: Dict[str, Any],
        agent_capability: Dict[str, Any],
        t: float,
    ) -> Belief:
        """Subject predicts whether the next chaotic era is within reach.

        ``agent_capability`` carries the kernel-computed ``T_predict`` and
        ``delta_0`` (the civilisation's observation precision).  The
        subject commits to:

          - ``predicted = next_chaos`` when its horizon reaches the next
            chaotic era — it sees the disaster coming (no model error).
          - ``predicted = None`` when its horizon falls short — it
            commits to "no chaos coming", which disagrees with ground
            truth → ``model_error = True`` (dramatic irony).
          - ``predicted = None`` with ``model_error = False`` when there
            genuinely is no next chaotic era in the baked timeline.
        """
        next_chaos = ground_truth_state.get("next_chaos")
        try:
            T_predict = float(agent_capability.get("T_predict", 0.0))
        except (TypeError, ValueError):
            T_predict = 0.0
        try:
            delta_0 = float(agent_capability.get("delta_0", 0.0))
        except (TypeError, ValueError):
            delta_0 = 0.0
        try:
            tech_level = float(agent_capability.get("tech_level", 0.0))
        except (TypeError, ValueError):
            tech_level = 0.0

        # Confidence: a coarse, deterministic self-assessment derived from
        # tech_level (higher tech → tighter δ₀ → more confident).  It only
        # shapes prose; the verdict is owned by the kernel.  Step 2 will
        # replace this with a bounded-confidence belief-revision value.
        confidence = _sigmoid_confidence(tech_level)

        if next_chaos is None:
            # No chaotic era after t in the baked timeline — the subject
            # commits to "no chaos coming" and is correct about it.
            return Belief(
                predicted=None,
                confidence=confidence,
                model_error=False,
                committed_values={
                    "T_predict": T_predict, "delta_0": delta_0,
                    "tech_level": tech_level,
                },
            )

        gap = float(next_chaos) - float(t)
        if T_predict >= gap:
            # Horizon reaches the next chaos — the subject sees it coming.
            return Belief(
                predicted=float(next_chaos),
                confidence=confidence,
                model_error=False,
                committed_values={
                    "T_predict": T_predict, "delta_0": delta_0,
                    "tech_level": tech_level,
                },
            )
        # Horizon falls short — the subject commits to "no chaos coming"
        # even though the kernel knows chaos is coming.  Dramatic irony.
        return Belief(
            predicted=None,
            confidence=confidence,
            model_error=True,
            committed_values={
                "T_predict": T_predict, "delta_0": delta_0,
                "tech_level": tech_level,
            },
        )


def _sigmoid_confidence(tech_level: float, alpha: float = 1.5) -> float:
    """Deterministic tech → confidence mapping in (0, 1).

    ``1 / (1 + exp(-alpha * tech_level))``.  Low tech → low confidence
    (but never exactly 0 — Sabre commitment still commits to a value),
    high tech → near-1.  Pure stdlib; no randomness.
    """
    import math
    try:
        return float(1.0 / (1.0 + math.exp(-alpha * float(tech_level))))
    except (OverflowError, ValueError):
        # Very negative tech_level → exp overflows → confidence → 0.
        return 0.0
