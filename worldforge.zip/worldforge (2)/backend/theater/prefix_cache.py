"""RadixAttention 前缀缓存模块（架构规范 §5.2, §13.6）。

纯 Python 实现，不依赖任何后端框架（dispatcher/agents/server）。
可在没有 GPU 或推理引擎的环境下单测。
"""

from __future__ import annotations

from collections import OrderedDict
from typing import Optional


class PrefixCache:
    """带钉住支持的前缀缓存 —— RadixAttention 的简化纯 Python 模拟。

    核心职责：
      - 以完整 prompt 为输入，通过 **最长前缀匹配** 返回缓存条目。
      - 钉住（pin）的世界状态前缀永不淘汰（§5.2）。
      - 提供命中率统计供 §13.6 指标采集。

    Parameters
    ----------
    max_entries : int
        LRU 部分的最大条数。pinned 条目不计入此上限。
    """

    def __init__(self, max_entries: int = 100) -> None:
        if max_entries < 1:
            raise ValueError("max_entries must be >= 1")
        self._max = max_entries
        self._cache: OrderedDict[str, str] = OrderedDict()
        self._pinned: OrderedDict[str, str] = OrderedDict()
        self._hits = 0
        self._misses = 0

    # ------------------------------------------------------------------
    # 公共接口
    # ------------------------------------------------------------------

    def get(self, prompt: str) -> Optional[str]:
        """返回与 *prompt* 最长前缀匹配的缓存条目，无匹配返回 ``None``。

        先扫描 pinned 区域再扫描 LRU 区域，相同长度时 pinned 优先。
        命中 LRU 条目时会将其移到末尾（LRU 保活）。
        """
        best: Optional[str] = None
        best_key: Optional[str] = None

        for prefix, output in self._pinned.items():
            if prompt.startswith(prefix) and (
                best_key is None or len(prefix) > len(best_key)
            ):
                best, best_key = output, prefix

        for prefix, output in self._cache.items():
            if prompt.startswith(prefix) and (
                best_key is None or len(prefix) > len(best_key)
            ):
                best, best_key = output, prefix

        if best_key is not None:
            self._hits += 1
            if best_key in self._cache:
                self._cache.move_to_end(best_key)
            return best

        self._misses += 1
        return None

    def put(self, prompt: str, output: str) -> None:
        """存入一个 prompt → output 映射。

        - 如果 prompt 已在 pinned 中 → 更新值。
        - 如果已在 LRU 中 → 移动到末尾 + 更新值。
        - 否则插入 LRU，超出上限时自动淘汰最久未用条目。
        """
        if prompt in self._pinned:
            self._pinned[prompt] = output
            return
        if prompt in self._cache:
            self._cache.move_to_end(prompt)
            self._cache[prompt] = output
            return
        self._cache[prompt] = output
        # 淘汰超出部分（pinned 不计入上限，不会出现在 _cache）
        while len(self._cache) > self._max:
            self._cache.popitem(last=False)

    def pin(self, prefix: str) -> None:
        """钉住一个前缀（世界状态前缀，永不淘汰，§5.2）。

        如果该前缀当前在 LRU 中，移入 pinned 区域。
        """
        if prefix in self._cache:
            self._pinned[prefix] = self._cache.pop(prefix)
        elif prefix not in self._pinned:
            self._pinned[prefix] = ""

    def unpin(self, prefix: str) -> None:
        """解除钉住。条目本身仍留在缓存中（回到 LRU 区域）。"""
        if prefix in self._pinned:
            output = self._pinned.pop(prefix)
            self._cache[prefix] = output

    def evict(self) -> None:
        """LRU 淘汰 —— 移除最久未使用的 **非 pinned** 条目。

        pinned 条目不受影响。
        """
        if self._cache:
            self._cache.popitem(last=False)

    # ------------------------------------------------------------------
    # 统计 / 属性
    # ------------------------------------------------------------------

    @property
    def hit_rate(self) -> float:
        """缓存命中率（§13.6：健康值 > 80%）。"""
        total = self._hits + self._misses
        return self._hits / total if total > 0 else 0.0

    def stats(self) -> dict:
        """返回命中率、缓存大小、pinned 数的快照。"""
        return {
            "hit_rate": self.hit_rate,
            "cache_size": len(self._cache),
            "pinned_count": len(self._pinned),
        }

    # ------------------------------------------------------------------
    # 内部钩子（供 SharedPrefixManager.invalidate_world_state 使用）
    # ------------------------------------------------------------------

    def _clear_non_pinned(self) -> None:
        """清空所有非 pinned 条目并重置命中统计。

        这是框架内部协作方法，外部通常通过
        ``SharedPrefixManager.invalidate_world_state`` 触发。
        """
        self._cache.clear()
        self._hits = 0
        self._misses = 0


class SharedPrefixManager:
    """管理世界状态前缀的钉住与 prompt 组装（§5.2）。

    职责：
      - 维护一个被钉住的世界状态前缀（构造时自动 pin）。
      - 提供 ``build_prompt`` 方法拼接 世界状态+幕上下文+人格。
      - 世界状态变更时调用 ``invalidate_world_state`` 清除非 pinned 缓存。

    Parameters
    ----------
    cache : PrefixCache
        底层前缀缓存实例（外部传入以共享同一缓存）。
    initial_world_prefix : str
        初始的世界状态前缀，构造后立即被钉住。
    """

    def __init__(
        self, cache: PrefixCache, initial_world_prefix: str = ""
    ) -> None:
        self._cache = cache
        self._prefix = initial_world_prefix
        if initial_world_prefix:
            self._cache.pin(initial_world_prefix)

    # ------------------------------------------------------------------
    # 世界状态前缀
    # ------------------------------------------------------------------

    @property
    def world_state_prefix(self) -> str:
        """当前被钉住的世界状态前缀。"""
        return self._prefix

    @world_state_prefix.setter
    def world_state_prefix(self, prefix: str) -> None:
        """设置新的世界状态前缀并钉住（自动解钉旧前缀）。"""
        old = self._prefix
        self._prefix = prefix
        if old:
            self._cache.unpin(old)
        if prefix:
            self._cache.pin(prefix)

    # ------------------------------------------------------------------
    # Prompt 构建
    # ------------------------------------------------------------------

    def build_prompt(
        self, world_state: str, scene_ctx: str, persona: str
    ) -> str:
        """拼接完整 prompt： ``world_state + scene_ctx + persona``。

        其中 ``world_state`` 部分被所有角色共享，是 RadixAttention
        前缀缓存的主要受益对象。
        """
        return world_state + scene_ctx + persona

    # ------------------------------------------------------------------
    # 失效
    # ------------------------------------------------------------------

    def invalidate_world_state(self) -> None:
        """世界状态变更时清除非 pinned 缓存（pinned 前缀保留）。

        注意：此方法**不**自动更新 ``world_state_prefix`` 属性；
        调用者应先设置新前缀再清缓存，或反之。
        """
        self._cache._clear_non_pinned()
