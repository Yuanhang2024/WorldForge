"""Character Graph — structured relationships between SimAgents (spec §5/§6).

The architecture review (§5) flags that multi-character play lacks a
*relationship graph*: ``leader_trait`` is single-body.  A ``CharacterGraph``
turns relationships into first-class structure so that multi-character
games have something to sit on::

    Leader --trust 0.8--> Scientist
    Leader --conflict -0.7--> General

Decisions become ``self belief + relationship belief + social pressure``.
The canonical example (§5): a scientist knows a disaster is 90% likely,
but the leader distrusts the scientist → the information cannot propagate
→ a social disaster unfolds.  This module is the structural substrate for
that dynamic.

Design (Q4 / user principle: relationships are *structured* and shape
belief update — trusted counterparts' evidence weighs more; distrusted
counterparts' evidence weighs less or does not arrive at all).

- **Pure stdlib, no LLM, no randomness.**  Where noise is wanted the
  caller passes a ``seed``; a fixed seed is fully deterministic (§8.2 red
  line).
- **Directed relationships.** A trusts B does *not* imply B trusts A —
  ``get_trust(a, b)`` and ``get_trust(b, a)`` read independent edges.
- **Event-sourced history.** Every mutation to a relationship appends a
  history event so the graph is auditable (mirrors the
  event-sourcing / 世界隔离 red line in §I4/§10.4).

Three public mechanisms are exposed (§9.3③ — social/persuasion needs
"倾向向量 + 惯性 + 检定"; this module supplies the structural half of
that — the *who listens to whom* graph. The persuasion *检定* itself is
the belief-update layer's job; here we provide the trust-weighted channels
it reads.):

1. :func:`propagate_info` — information flows from a source to neighbours
   gated by trust.  Distrusted sources do not reach a neighbour → the
   scientist's 90% warning never lands on the leader who distrusts them.
2. :func:`social_pressure` — the trust-weighted average of neighbours'
   beliefs on a topic, fed into an agent's belief update as the social
   input.
3. :class:`Organization` + :func:`org_decide` — §6 WorldCompiler outputs
   organisations; decisions aggregate member votes by a rule
   (dictator / consensus / vote).

This module deliberately does **not** depend on ``sim_agent`` /
``cognitive_model`` at runtime — it keys everything by ``agent_id``
(``str``) so it can be wired into a world without importing the agent
types.  ``SimAgent`` supplies ``character_id`` (the node id); the graph
holds the edges.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

__all__ = [
    "Relationship",
    "CharacterGraph",
    "Organization",
    "propagate_info",
    "social_pressure",
    "org_decide",
]


# ---------------------------------------------------------------------------
# Relationship — a directed edge between two agents
# ---------------------------------------------------------------------------


@dataclass
class Relationship:
    """A directed relationship from ``from_id`` to ``to_id``.

    Three epistemic knobs (§9.3③ — 倾向向量 + 惯性 + 检定, structural
    half):

    - ``trust`` in ``[-1.0, 1.0]``.  Positive = the source will listen to
      the target / treat their evidence as credible.  Negative = the
      source distrusts the target (information from the target is filtered
      out / discounted).  Zero = neutral.
    - ``conflict`` in ``[0.0, 1.0]``.  How much the two are in active
      opposition.  High conflict suppresses social-pressure weight even
      when grudging trust exists.
    - ``influence`` in ``[0.0, 1.0]``.  Authority bias (§9.3③): how much
      the source defers to the target's position.  High-influence targets
      propagate information further and weigh more in social pressure.

    ``history`` is an append-only event log (event sourcing): every
    ``update_trust`` / ``add_relationship`` records what changed and why.
    """

    from_id: str
    to_id: str
    trust: float = 0.0
    conflict: float = 0.0
    influence: float = 0.0
    history: List[Dict[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.trust = max(-1.0, min(1.0, float(self.trust)))
        self.conflict = max(0.0, min(1.0, float(self.conflict)))
        self.influence = max(0.0, min(1.0, float(self.influence)))


# ---------------------------------------------------------------------------
# CharacterGraph — nodes + directed edges
# ---------------------------------------------------------------------------


class CharacterGraph:
    """Directed graph of :class:`Relationship` edges keyed by agent id.

    Nodes are implicit: any agent id mentioned in an edge is a node.
    ``add_node`` lets a caller register an isolated node (an agent with no
    relationships yet) so that ``neighbors`` / ``social_pressure`` have
    something to iterate over.
    """

    def __init__(self) -> None:
        # node id -> set of node ids (membership only; edges live in _edges)
        self._nodes: set = set()
        # (from_id, to_id) -> Relationship
        self._edges: Dict[Tuple[str, str], Relationship] = {}

    # -- node management ----------------------------------------------------

    def add_node(self, agent_id: str) -> None:
        """Register an agent id as a node (no-op if already present)."""
        self._nodes.add(agent_id)

    @property
    def nodes(self) -> List[str]:
        return sorted(self._nodes)

    @property
    def edges(self) -> List[Relationship]:
        return [self._edges[k] for k in sorted(self._edges.keys())]

    def has_node(self, agent_id: str) -> bool:
        return agent_id in self._nodes

    # -- edge management ----------------------------------------------------

    def add_relationship(
        self,
        from_id: str,
        to_id: str,
        trust: float = 0.0,
        conflict: float = 0.0,
        influence: float = 0.0,
        reason: str = "",
    ) -> Relationship:
        """Create or overwrite the directed edge ``from_id → to_id``.

        Replaces any prior relationship between the same pair (use
        :meth:`update_trust` to *mutate* an existing edge).  Both
        endpoints are registered as nodes.  The creation is logged to
        the relationship's history (event sourcing).
        """
        self._nodes.add(from_id)
        self._nodes.add(to_id)
        rel = Relationship(
            from_id=from_id,
            to_id=to_id,
            trust=trust,
            conflict=conflict,
            influence=influence,
        )
        rel.history.append({
            "event": "add_relationship",
            "trust": rel.trust,
            "conflict": rel.conflict,
            "influence": rel.influence,
            "reason": reason,
        })
        self._edges[(from_id, to_id)] = rel
        return rel

    def get_relationship(self, from_id: str, to_id: str) -> Optional[Relationship]:
        """Return the directed edge ``from_id → to_id`` or ``None``."""
        return self._edges.get((from_id, to_id))

    def get_trust(self, a: str, b: str) -> float:
        """Trust that ``a`` has in ``b`` (directed — not symmetric).

        Returns 0.0 when no edge exists (no relationship = neutral).
        """
        rel = self._edges.get((a, b))
        return rel.trust if rel is not None else 0.0

    def get_influence(self, a: str, b: str) -> float:
        """How much ``a`` defers to ``b`` (directed).  0.0 if no edge."""
        rel = self._edges.get((a, b))
        return rel.influence if rel is not None else 0.0

    def get_conflict(self, a: str, b: str) -> float:
        """Conflict on the ``a → b`` edge.  0.0 if no edge."""
        rel = self._edges.get((a, b))
        return rel.conflict if rel is not None else 0.0

    def update_trust(
        self,
        a: str,
        b: str,
        delta: float,
        reason: str = "",
    ) -> float:
        """Nudge ``a``'s trust in ``b`` by ``delta``, clamped to ``[-1, 1]``.

        If no edge ``a → b`` exists, one is created at trust 0.0 first
        (so the graph can grow from observed interactions, not just
        from a seed).  The change is appended to the edge history with
        the reason, making the relationship's evolution auditable
        (event-sourcing red line, §I4/§10.4).
        """
        rel = self._edges.get((a, b))
        if rel is None:
            rel = self.add_relationship(a, b, trust=0.0)
            # add_relationship already logged a creation event; drop it
            # so the history starts with this mutation (cleaner audit).
            rel.history.clear()
        old = rel.trust
        new = max(-1.0, min(1.0, old + float(delta)))
        rel.trust = new
        rel.history.append({
            "event": "update_trust",
            "old": old,
            "new": new,
            "delta": new - old,
            "reason": reason,
        })
        return new

    def neighbors(
        self,
        agent_id: str,
        min_trust: Optional[float] = None,
    ) -> List[str]:
        """Agents that ``agent_id`` has an outgoing edge to.

        With ``min_trust`` set, only neighbours whose
        ``trust(agent_id → neighbour)`` is ``>= min_trust`` are returned —
        the structural filter for "who does this agent actually listen
        to".
        """
        out: List[str] = []
        for (frm, to), rel in self._edges.items():
            if frm != agent_id:
                continue
            if min_trust is not None and rel.trust < min_trust:
                continue
            out.append(to)
        return sorted(out)

    # -- serialisation -----------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": self.nodes,
            "edges": [
                {
                    "from_id": r.from_id,
                    "to_id": r.to_id,
                    "trust": r.trust,
                    "conflict": r.conflict,
                    "influence": r.influence,
                    "history": list(r.history),
                }
                for r in self.edges
            ],
        }


# ---------------------------------------------------------------------------
# 1. Information propagation
# ---------------------------------------------------------------------------


def propagate_info(
    graph: CharacterGraph,
    source_id: str,
    info: Any,
    info_quality: float = 1.0,
    *,
    trust_threshold: float = 0.0,
    max_hops: int = 3,
    seed: Optional[int] = None,
) -> Dict[str, bool]:
    """Propagate ``info`` from ``source_id`` outward over trust edges.

    Model (§5 — relationships gate information flow):

    - A neighbour ``b`` of the current holder ``a`` receives the info iff
      ``trust(a → b) > trust_threshold``.  Distrust (trust below
      threshold) **blocks** propagation along that edge — the scientist's
      warning never reaches a leader who distrusts them.  This is the
      "信息错误来源①：角色没看到重要信息" failure mode made structural.
    - ``info_quality`` is the credibility carried with the info; it is
      attenuated by each hop's trust (a weak-trust channel degrades the
      signal) and boosted by the source's ``influence`` at hop 0
      (authoritative sources travel further — §9.③ authority bias).
    - ``max_hops`` bounds the BFS depth (rumours do not travel forever).
    - ``seed``: reserved RNG seed for future per-edge noise.  When
      provided, the seed is consumed deterministically (same seed → same
      spread); the current propagation is a pure deterministic function
      of the graph regardless (§8.2 red line — no hidden RNG).

    Returns a ``{agent_id: received}`` map.  ``received`` is True iff the
    agent ended up with the info (the source is always True).
    """
    rng = random.Random(seed) if seed is not None else None

    received: Dict[str, bool] = {source_id: True}
    # (holder, quality_at_holder)
    frontier: List[Tuple[str, float]] = [(source_id, float(info_quality))]

    for _ in range(max(0, int(max_hops))):
        if not frontier:
            break
        next_frontier: List[Tuple[str, float]] = []
        for holder, q in frontier:
            for nbr in graph.neighbors(holder):
                if nbr in received:
                    continue
                trust = graph.get_trust(holder, nbr)
                if trust <= trust_threshold:
                    continue
                # reserve seed consumption so future noise is reproducible
                if rng is not None:
                    rng.random()
                # attenuate quality by trust; a grudging channel degrades
                new_q = q * max(0.0, min(1.0, trust))
                # also factor in the holder's authority over the neighbour
                new_q *= 0.5 + 0.5 * graph.get_influence(holder, nbr)
                if new_q <= 0.0:
                    continue
                received[nbr] = True
                next_frontier.append((nbr, new_q))
        frontier = next_frontier

    # agents never reached are explicitly False
    for n in graph.nodes:
        received.setdefault(n, False)
    return received


# ---------------------------------------------------------------------------
# 2. Social pressure
# ---------------------------------------------------------------------------


def social_pressure(
    graph: CharacterGraph,
    agent_id: str,
    topic: str,
    beliefs: Dict[str, Dict[str, float]],
    *,
    min_trust: float = 0.0,
) -> float:
    """Trust-weighted average of neighbours' beliefs on ``topic``.

    The social input to an agent's belief update (§5: decision = self
    belief + relationship belief + social pressure).  Neighbours the
    agent trusts weigh more; distrusted neighbours are filtered out
    (``min_trust``); high-conflict edges are further suppressed.

    - ``beliefs``: ``{agent_id: {topic: belief_value}}`` — the caller
      supplies the current belief snapshot (the graph does not own
      beliefs; that is :class:`SimAgent`'s job).
    - Returns 0.0 when the agent has no trusted neighbours with an
      opinion on ``topic`` (no social pressure — the agent falls back
      to self belief).
    """
    total_w = 0.0
    total_v = 0.0
    for nbr in graph.neighbors(agent_id):
        trust = graph.get_trust(agent_id, nbr)
        if trust < min_trust:
            continue
        conflict = graph.get_conflict(agent_id, nbr)
        nbr_beliefs = beliefs.get(nbr, {})
        if topic not in nbr_beliefs:
            continue
        # weight = trust (only positive trust contributes meaningfully;
        # negative trust is filtered by min_trust default 0.0) scaled by
        # (1 - conflict) — a high-conflict neighbour's opinion is
        # discounted even if grudgingly trusted.
        w = max(0.0, trust) * (1.0 - conflict)
        if w <= 0.0:
            continue
        total_w += w
        total_v += w * float(nbr_beliefs[topic])
    if total_w <= 0.0:
        return 0.0
    return total_v / total_w


# ---------------------------------------------------------------------------
# 3. Organizations (§6 — WorldCompiler outputs)
# ---------------------------------------------------------------------------


@dataclass
class Organization:
    """A named group of agents with a decision rule (§6).

    - ``members``: agent ids in the org.
    - ``roles``: ``{agent_id: role}`` — e.g. ``{"leader": "dictator"}``.
    - ``decision_rule``: one of ``dictator`` / ``consensus`` / ``vote``.
      ``dictator`` defers to a named ``dictator_id``;
      ``consensus`` requires *unanimous* agreement (any dissent blocks);
      ``vote`` is simple majority (>50% of cast votes).
    """

    org_id: str
    members: List[str] = field(default_factory=list)
    roles: Dict[str, str] = field(default_factory=dict)
    decision_rule: str = "vote"
    dictator_id: str = ""


def org_decide(
    org: Organization,
    member_votes: Dict[str, Any],
    rule: Optional[str] = None,
) -> Any:
    """Aggregate ``member_votes`` per the org's ``decision_rule``.

    - ``member_votes``: ``{agent_id: vote}`` — votes are free-form
      (string choice, bool, number).  Members who did not cast a vote
      are absentees (not counted).
    - ``rule`` overrides ``org.decision_rule`` when provided.

    Rules:

    - ``dictator``: return the dictator's vote (``org.dictator_id``);
      raise ``ValueError`` if no dictator is set or did not vote.
    - ``consensus``: return the vote iff every cast vote agrees;
      otherwise return ``None`` (no decision — dissent blocks).
    - ``vote``: return the choice with the strict majority of cast
      votes; on a tie / no majority return ``None`` (re- runoff needed).
    """
    decision_rule = rule or org.decision_rule
    # restrict to org members who actually cast a vote
    cast = {
        m: v for m, v in member_votes.items()
        if m in org.members and v is not None
    }

    if decision_rule == "dictator":
        if not org.dictator_id:
            raise ValueError("dictator rule requires org.dictator_id")
        if org.dictator_id not in cast:
            raise ValueError(f"dictator {org.dictator_id} cast no vote")
        return cast[org.dictator_id]

    if decision_rule == "consensus":
        if not cast:
            return None
        choices = set(cast.values())
        if len(choices) == 1:
            return next(iter(choices))
        return None

    if decision_rule == "vote":
        if not cast:
            return None
        tally: Dict[Any, int] = {}
        for v in cast.values():
            tally[v] = tally.get(v, 0) + 1
        # hashable votes; pick strict majority
        n = len(cast)
        winner = None
        best = -1
        for choice, count in tally.items():
            if count > best:
                best = count
                winner = choice
        # strict majority check
        if best > n / 2:
            return winner
        # tie or plurality without majority → no decision
        # if two choices tie at the top, no majority
        top = [c for c in tally if tally[c] == best]
        if len(top) == 1 and best > n / 2:
            return top[0]
        return None

    raise ValueError(f"unknown decision_rule: {decision_rule!r}")
