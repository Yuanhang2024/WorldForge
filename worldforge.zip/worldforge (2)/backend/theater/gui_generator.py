"""WorldForge GUI generator — deterministic LLM-shaped GUI config compiler.

Implements gui_generation_design.md §4 (gui_spec DSL) and §6 (compile target):

  - GUISpec / WidgetSpec dataclasses (the §4 DSL, plain Python).
  - GUIGenerator.generate(world_style, llm_fn) — LLM when available, otherwise
    a deterministic world-agnostic control surface.
  - compile_to_css(gui_spec) — layout CSS + typography rules, no colors
    (colors ride on GuiTheme.applyTheme as CSS variables — keep this layer
    presentation-only).
  - compile_to_html_template(gui_spec) — HTML skeleton driven by widgets[].

Safety (§4.4 of the design): widget.binds emit is closed-vocabulary against
the router.js intent kinds + a small action allowlist, validated centrally
in ``ALLOWED_INTENT_KINDS`` / ``ALLOWED_ACTIONS`` so the GUI can never invent
a state-writing path. Read binds resolve to a known kernel output or a
``state:<path>`` projection — anything else is rejected at validation.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Optional
import json
import re


# ---------------------------------------------------------------------------
# Closed vocabularies — single source of truth for "what a generated GUI may
# bind to". Mirrors the intent kinds emitted by web/input/router.js (§4.4).
# ---------------------------------------------------------------------------

# Mirror of router.js DEFAULT_FANOUT intent kinds.  Adding/removing an entry
# here is a deliberate act; the GUI generator must agree with the router.
ALLOWED_INTENT_KINDS = frozenset({
    "utterance",
    "decision_vector",
    "playfield_action",
})

# Endpoints that a commit-style widget may target. All reach the single
# write-point I4 (via router → kernel); none are arbitrary HTML endpoints.
ALLOWED_ACTIONS = frozenset({"world/tick", "interact", "game/step", "dispatch"})

# Widget type vocabulary (closed; LLM only selects+parametrises, never writes
# new widget code, per I5 spirit applied to presentation).
#
# Two groups:
#   (a) legacy interactive + display widgets (presets + LLM may emit them)
#   (b) kernel-information widgets (§13.6 read-only director-view surfaces):
#       belief_panel / commitment_list / causal_trace_panel / outcome_chapter.
#       These bind read-only to kernel:/state: projections of the tick's
#       model_trace (agent_mind / commitments / causal_narrative / outcome) so
#       the LLM-shaped GUI can surface the kernel's necessary information
#       without inventing a new write path. The front-end (web/world_gui.js)
#       renders the same payload into the static #world-info-panel so the
#       director view works even when no LLM GUI is mounted.
ALLOWED_WIDGET_TYPES = frozenset({
    # Executors
    "slider", "dial", "button", "button_group", "card_row",
    "toggle", "text_field", "commit_bar",
    # Displays
    "canvas_panel", "gauge", "lamp", "meter",
    "table", "ledger_grid", "log_feed", "timeline",
    "map_panel", "nameplate", "cue_row",
    # Kernel-information panels (read-only director-view, §13.6)
    "belief_panel", "commitment_list", "causal_trace_panel", "outcome_chapter",
    # Static label / fallback
    "text",
})

# Layout primitives — same closed-set treatment. "terminal" is the 4th
# bespoke layout the design document calls out as proof of generation.
ALLOWED_LAYOUT_TYPES = frozenset({
    "dashboard", "stage", "tabletop", "terminal", "map", "console",
})

# Closed icon-style tokens rendered by the code-native UI.
ALLOWED_ICON_STYLES = frozenset({
    "instrument", "gilded", "heraldic", "line_terminal", "ascii",
})

# Motion tokens — these are also recognised by GuiTheme.applyTheme.
ALLOWED_MOTIONS = frozenset({"free", "glitch"})


# ---------------------------------------------------------------------------
# Dataclasses — the gui_spec DSL in Python form (§4.1).
# ---------------------------------------------------------------------------

@dataclass
class WidgetSpec:
    """One widget on the GUI board.

    ``binds`` is the only way a widget touches the system; it must always
    validate via :func:`_validate_binds` before being compiled.
    """
    name: str
    type: str
    area: str
    binds: Dict[str, Any] = field(default_factory=dict)
    label: str = ""
    role: str = "panel"
    position: Dict[str, Any] = field(default_factory=dict)
    options: List[Dict[str, Any]] = field(default_factory=list)
    min: Optional[float] = None
    max: Optional[float] = None
    placeholder: str = ""
    title: str = ""


@dataclass
class GUISpec:
    """Compiled GUI configuration for one world (§4.1)."""
    gui_spec_id: str
    schema_version: int = 1
    world_id: str = ""
    layout_type: str = "dashboard"
    grid: Dict[str, Any] = field(default_factory=dict)
    chrome: str = "instrument_bezel"
    widgets: List[WidgetSpec] = field(default_factory=list)
    color_scheme: Dict[str, Any] = field(default_factory=dict)
    typography: Dict[str, Any] = field(default_factory=dict)
    icon_style: str = "instrument"
    motion: str = "free"
    semantic_slots: Dict[str, int] = field(default_factory=dict)
    provenance: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serializable mirror of the spec (§4.1 JSON shape)."""
        d = asdict(self)
        d["widgets"] = [asdict(w) for w in self.widgets]
        return d


# ---------------------------------------------------------------------------
# Validation (§7 — gui_spec acceptance gate)
# ---------------------------------------------------------------------------

def _validate_layout(spec: GUISpec) -> None:
    if spec.layout_type not in ALLOWED_LAYOUT_TYPES:
        raise ValueError(f"layout_type {spec.layout_type!r} not in closed set")
    grid = spec.grid or {}
    cols = grid.get("columns")
    if not isinstance(cols, str) or not cols.strip():
        raise ValueError("grid.columns must be a non-empty string")
    # rows is optional (CSS Grid synthesises rows from areas if absent)


def _validate_widget(widget: WidgetSpec, known_areas: set) -> None:
    if widget.type not in ALLOWED_WIDGET_TYPES:
        raise ValueError(
            f"widget {widget.name!r}: type {widget.type!r} not in closed set"
        )
    if widget.area and known_areas and widget.area not in known_areas:
        raise ValueError(
            f"widget {widget.name!r}: area {widget.area!r} is not declared "
            "in layout.grid.areas"
        )
    _validate_binds(widget.name, widget.binds)


def _validate_binds(widget_name: str, binds: Dict[str, Any]) -> None:
    """§4.4 / §7 — executable widgets must use the closed intent vocabulary.

    Display widgets must point at a known kernel or ``state:<path>``.
    """
    if not binds:
        # A widget with no binds is dead (§7 — 无死控件). Bail loudly so the
        # model can be told to retry.
        raise ValueError(f"widget {widget_name!r}: binds required")

    emit = binds.get("emit")
    read = binds.get("read")
    action = binds.get("action")

    # emit + read coexistence is allowed (widget reads state AND emits intent).

    if emit is not None:
        if emit not in ALLOWED_INTENT_KINDS:
            raise ValueError(
                f"widget {widget_name!r}: emit {emit!r} not in "
                f"closed intent set {sorted(ALLOWED_INTENT_KINDS)}"
            )
        # commit + action: optional, but if set both must validate.
        if binds.get("commit") and action is not None:
            if action not in ALLOWED_ACTIONS:
                raise ValueError(
                    f"widget {widget_name!r}: action {action!r} not in "
                    f"closed action set {sorted(ALLOWED_ACTIONS)}"
                )
        return

    if read is not None:
        if not isinstance(read, str):
            raise ValueError(
                f"widget {widget_name!r}: read must be a string path"
            )
        if not (read.startswith("kernel:") or read.startswith("state:")):
            raise ValueError(
                f"widget {widget_name!r}: read {read!r} must start with "
                "'kernel:' or 'state:'"
            )
        return

    # No emit and no read → invalid; at minimum one must be present.
    raise ValueError(
        f"widget {widget_name!r}: binds must set either 'emit' or 'read'"
    )


def _validate_motion(spec: GUISpec) -> None:
    if spec.motion not in ALLOWED_MOTIONS:
        raise ValueError(f"motion {spec.motion!r} not in closed set")
    if spec.icon_style not in ALLOWED_ICON_STYLES:
        raise ValueError(f"icon_style {spec.icon_style!r} not in closed set")


def validate_gui_spec(spec: GUISpec) -> None:
    """§7 — single gate. Raises ValueError on the first violation."""
    _validate_layout(spec)
    _validate_motion(spec)
    known_areas = set()
    if spec.grid and spec.grid.get("areas"):
        # Flatten the area string grid; each whitespace-separated token is one
        # area name (CSS Grid: each area line is a row, tokens within a row
        # are columns). An area referenced only on the right of a "." is the
        # same area as the left side.
        for row in spec.grid["areas"]:
            for token in row.split():
                cell = token.split(".", 1)[-1]
                known_areas.add(cell)
    for w in spec.widgets:
        _validate_widget(w, known_areas)
    if not spec.widgets:
        raise ValueError("gui_spec must define at least one widget")


# ---------------------------------------------------------------------------
# GUIGenerator
# ---------------------------------------------------------------------------

class GUIGenerator:
    """§3 — turns a world style (string) into a validated GUISpec via LLM.

    When present, the LLM's dict-shaped return is parsed, normalised,
    validated against closed vocabularies, and wrapped in a ``GUISpec``.
    Missing, failed, malformed, or invalid LLM output raises. Ordinary GUI
    generation has no preset or structural fallback.
    """

    def __init__(self, llm_fn: Optional[Callable[[str], Dict[str, Any]]] = None):
        self._llm_fn = llm_fn

    def generate(self, world_style: str,
                 llm_fn: Optional[Callable[[str], Any]] = None
                 ) -> GUISpec:
        """Return a GUI spec for ``world_style`` via LLM.

        The supplied ``llm_fn`` (explicit argument > constructor) is called
        with the world description. Its response is parsed, normalised, and
        validated against closed vocabularies. Any failure (no LLM provided,
        malformed output, validation error) is reported to the caller.
        """
        fn = llm_fn if llm_fn is not None else self._llm_fn
        if fn is None:
            raise RuntimeError(
                "GUIGenerator requires llm_fn; GUI generation has no fallback"
            )
        last_error: Optional[Exception] = None
        for attempt in range(3):
            prompt = self._llm_prompt(world_style)
            if last_error is not None:
                prompt += (
                    "\n\n你上一次返回的 JSON 未通过 GUISpec 校验："
                    f"{str(last_error)[:800]}\n"
                    "请重新生成一个完整对象并修正该问题；不要解释，也不要省略 "
                    "layout.grid、widgets 或 binds。"
                )
            try:
                # Provider/transport failures are not schema-repairable and
                # must surface immediately. Only an LLM response that reached
                # the local parser/validator is eligible for self-correction.
                raw = fn(prompt)
            except Exception as exc:
                raise RuntimeError(
                    f"LLM GUI generation failed: {exc}"
                ) from exc
            try:
                spec = self._build_spec_from_llm(raw, world_style)
                validate_gui_spec(spec)
                return spec
            except (ValueError, TypeError, KeyError) as exc:
                last_error = exc
                if attempt == 2:
                    break
        raise RuntimeError(
            f"LLM GUI generation failed after 3 validation attempts: "
            f"{last_error}"
        ) from last_error

    def _llm_prompt(self, world_style: str) -> str:
        """Prompt asking the LLM for a GUISpec JSON (closed vocabularies)."""
        return (
            _build_gui_system_prompt()
            + "\n\nWORLD DESCRIPTION:\n"
            + world_style
            + "\n\nGenerate 6-12 widgets and return the complete JSON object now."
        )

    def _build_spec_from_llm(self, raw: Any, world_style: str) -> GUISpec:
        """Parse → normalise → coerce → validate. Each step best-effort.

        Kept on the class so tests can subclass GUIGenerator to override
        individual steps (e.g. only the parser, only the normaliser).
        """
        parsed = _parse_llm_gui(raw)
        normalised = _normalize_gui_spec(parsed, world_style)
        return _coerce_spec(normalised, world_style)

    @staticmethod
    def compile_to_css(spec: GUISpec) -> str:
        return compile_to_css(spec)

    @staticmethod
    def compile_to_html_template(spec: GUISpec) -> str:
        return compile_to_html_template(spec)


# ---------------------------------------------------------------------------
# LLM path — parse + normalise (§3, §7)
# ---------------------------------------------------------------------------

def _build_gui_system_prompt() -> str:
    """Return the system prompt that teaches an LLM the GUISpec JSON shape.

    The LLM only selects + parametrases closed-vocabulary tokens; it never
    invents widget code, intent kinds, action endpoints, or read targets.
    The prompt lists every closed set so the LLM's output can be safely
    rounded into :func:`validate_gui_spec` after :func:`_normalize_gui_spec`
    has done the rewrite of unknown tokens.
    """
    widgets = ", ".join(sorted(ALLOWED_WIDGET_TYPES))
    layouts = ", ".join(sorted(ALLOWED_LAYOUT_TYPES))
    icons = ", ".join(sorted(ALLOWED_ICON_STYLES))
    motions = ", ".join(sorted(ALLOWED_MOTIONS))
    intents = ", ".join(sorted(ALLOWED_INTENT_KINDS))
    actions = ", ".join(sorted(ALLOWED_ACTIONS))
    return (
        "You are the GUI designer for WorldForge. Given a world description, "
        "you emit ONE JSON object describing the GUI for that world. The "
        "object MUST use only the closed vocabularies listed below. Any "
        "unknown token or invalid binding will reject the whole response.\n\n"
        "Output strictly ONE JSON object. No prose, no markdown fences, no "
        "comments, no trailing commas. Every key below is required unless "
        "explicitly marked optional:\n"
        "  - layout_type: one of {" + layouts + "}\n"
        "  - chrome: a short snake_case label (e.g. instrument_bezel, "
        "proscenium, parchment_frame, crt_scanline)\n"
        "  - grid: { columns: <CSS grid-template-columns string>,\n"
        "           rows:    <optional CSS grid-template-rows string>,\n"
        "           areas:   <list of whitespace-separated area rows,\n"
        "                    each row is one CSS Grid template-areas token> }\n"
        "  - icon_style: one of {" + icons + "}\n"
        "  - motion: one of {" + motions + "}\n"
        "  - typography: { display, mono, letter_spacing, case }\n"
        "      case ∈ {upper, mixed, lower}\n"
        "  - color_scheme: { bg_role, panel_role, ink_role, accent_role, "
        "ok_role, warn_role, danger_role, ... } — role → int palette index\n"
        "  - semantic_slots: same shape as color_scheme (alias for "
        "palette_roles)\n"
        "  - widgets: NON-EMPTY list of widget objects, each shaped as:\n"
        "      { id: <name>, type: <one of {" + widgets + "}>, area: "
        "<grid area name>, role, label, title, placeholder, position: {...}, "
        "options: [{label, verb}], min, max,\n"
        "        binds: <see SCHEMA below> }\n"
        "  - gui_spec_id: short snake_case identifier\n"
        "  - world_id: short snake_case identifier\n\n"
        "binds SCHEMA — every widget MUST set exactly one of:\n"
        "  - { emit: <one of {" + intents + "}>, verb: <optional verb>, "
        "commit: <bool>, action: <one of {" + actions + "}> }\n"
        "      (commit + action combine only on commit-style widgets)\n"
        "  - { read: <path starting with 'kernel:' or 'state:'> }\n"
        "emit and read MUST NOT both be present.\n\n"
        "Rules of thumb:\n"
        "  - Bind every widget to either a closed intent emit (executor) or a "
        "kernel:/state: read (display). Empty binds will be removed.\n"
        "  - Keep widget count between 3 and 12.\n"
        "  - Pick grid.areas so that every widget's `area` is one of the "
        "declared CSS Grid area tokens.\n"
        "  - Choose icon_style + motion only from the declared closed sets; "
        "do not assume a built-in genre preset.\n\n"
        "Kernel-information widgets (read-only director-view, §13.6) — use "
        "these to surface the kernel's necessary information (beliefs / "
        "commitments / causal narrative / outcome chapter) when the world "
        "calls for a director overlay:\n"
        "  - belief_panel         binds { read: 'state:beliefs' }\n"
        "  - commitment_list      binds { read: 'state:commitments' }\n"
        "  - causal_trace_panel   binds { read: 'state:causal_narrative' }\n"
        "  - outcome_chapter      binds { read: 'state:outcome_chapter' }\n"
        "These never emit; they only read their slot. The runtime fills each "
        "slot from build_info_panel_payload(model_trace, state).\n\n"
        "Begin your reply with '{' and end with '}'. No commentary before or "
        "after."
    )


# Known wrapper characters used when LLM replies have stray code fences or
# prose around the JSON payload. Cheap heuristic — never raise on these.
_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)
_JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)


def _parse_llm_gui(raw: Any) -> Dict[str, Any]:
    """Accept either a dict-shaped LLM reply or a JSON string.

    Steps:
      1. If ``raw`` is already a dict, return a shallow copy.
      2. If a string, strip optional markdown fences and try ``json.loads``.
      3. On any parse error, return ``{}``; the generation boundary rejects it
         because an accepted GUI must contain validated widgets.
    """
    if isinstance(raw, dict):
        # Best-effort shallow copy — guard against caller mutation.
        return dict(raw)
    if not isinstance(raw, str):
        return {}
    text = raw.strip()
    if not text:
        return {}
    # Strip a leading "```json" / "```" code fence, common with chat LLMs.
    fence = _JSON_FENCE_RE.search(text)
    if fence:
        text = fence.group(1).strip()
    # First try the whole text as JSON.
    try:
        value = json.loads(text)
        if isinstance(value, dict):
            return value
    except (ValueError, TypeError):
        pass
    # Fall back: grab the first balanced-looking JSON object in the text.
    match = _JSON_OBJECT_RE.search(text)
    if match:
        try:
            value = json.loads(match.group(0))
            if isinstance(value, dict):
                return value
        except (ValueError, TypeError):
            pass
    # Garbage / hallucination → empty dict signals "no usable spec".
    return {}


def _normalize_gui_spec(spec: Dict[str, Any], world_style: str) -> Dict[str, Any]:
    """Coalesce accepted response shapes without repairing invalid data.

    Policies:
      - Coalesce the two shapes LLM replies come in (``{layout:{type...},
        chrome, grid}`` vs flat ``{layout_type, grid, chrome}``) into a
        single ``layout`` dict so the downstream coercer can find the
        columns/areas/rows regardless of which shape the LLM emitted.
      - Preserve invalid layout, widget, and binding values. The central
        validator must reject model output instead of silently converting it
        into a different accepted artifact.
    """
    del world_style
    if not isinstance(spec, dict) or not spec:
        return {}
    layout = spec.get("layout")
    if not isinstance(layout, dict):
        layout = {}
    # Coalesce top-level fields the LLM sometimes emits under the spec root
    # instead of inside ``layout`` (it's a common JSON shape mismatch).
    for top_level_key in ("type", "chrome", "grid"):
        if top_level_key not in layout and top_level_key in spec:
            layout[top_level_key] = spec[top_level_key]
    # Also accept the bare ``layout_type`` shortcut at the root.
    if "type" not in layout and "layout_type" in spec:
        layout["type"] = spec["layout_type"]
    spec["layout"] = layout
    raw_widgets = spec.get("widgets")
    if not isinstance(raw_widgets, list):
        return spec
    spec["widgets"] = [
        dict(widget) if isinstance(widget, dict) else widget
        for widget in raw_widgets
    ]
    return spec


def _normalize_widget(widget: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Compatibility helper that preserves data for strict validation."""
    return dict(widget) if isinstance(widget, dict) else None


def _coerce_spec(raw: Any, world_style: str) -> GUISpec:
    """Coerce an LLM-shaped dict without discarding malformed entries."""
    if not isinstance(raw, dict):
        raise ValueError("llm_fn must return a dict-shaped gui_spec")
    layout = raw.get("layout")
    if not isinstance(layout, dict):
        raise ValueError("gui_spec.layout must be an object")
    layout_type = layout.get("type")
    grid = layout.get("grid")
    if not isinstance(grid, dict):
        raise ValueError("gui_spec.layout.grid must be an object")
    chrome = layout.get("chrome", "instrument_bezel")
    typography = raw.get("typography") or {}
    icon_style = raw.get("icon_style", "instrument")
    motion = raw.get("motion", "free")
    widgets_raw = raw.get("widgets")
    if not isinstance(widgets_raw, list):
        raise ValueError("gui_spec.widgets must be a list")
    widgets = []
    for w in widgets_raw:
        if not isinstance(w, dict):
            raise ValueError("every gui_spec widget must be an object")
        widgets.append(WidgetSpec(
            name=str(w.get("id") or w.get("name") or "w"),
            type=str(w.get("type") or ""),
            area=str(w.get("area") or ""),
            binds=dict(w.get("binds") or {}),
            label=str(w.get("label", "")),
            role=str(w.get("role", "panel")),
            position=dict(w.get("position") or {}),
            options=list(w.get("options") or []),
            min=w.get("min"),
            max=w.get("max"),
            placeholder=str(w.get("placeholder", "")),
            title=str(w.get("title", "")),
        ))
    semantic = raw.get("semantic_slots") or raw.get("palette_roles") or {}
    semantic_slots = {str(k): int(v) for k, v in semantic.items() if isinstance(v, int)}
    provenance = dict(raw.get("provenance") or {})
    provenance.setdefault("proposed_by", "llm")
    provenance.setdefault("source_prompt", world_style)
    return GUISpec(
        gui_spec_id=str(raw.get("gui_spec_id") or f"llm_{hash(world_style) & 0xffff:04x}"),
        world_id=str(raw.get("world_id") or ""),
        layout_type=str(layout_type),
        grid=grid,
        chrome=str(chrome),
        widgets=widgets,
        color_scheme=dict(raw.get("color_scheme") or {}),
        typography=typography,
        icon_style=str(icon_style),
        motion=str(motion),
        semantic_slots=semantic_slots,
        provenance=provenance,
    )


# ---------------------------------------------------------------------------
# Compilation targets (§6)
# ---------------------------------------------------------------------------

_CSS_GRID_AREAS_RE = re.compile(r"[\s]+")


def _css_quote(value: str) -> str:
    """Quote a value for use as a CSS string (single quotes; escape internals)."""
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


def compile_to_css(spec: GUISpec) -> str:
    """Emit a CSS string that lays out the GUI based on `spec.grid` + chrome.

    Colors are intentionally absent from this output: paint comes from
    GuiTheme.applyTheme (CSS variables on :root), keeping this layer
    presentation-structure-only.
    """
    out: List[str] = []
    out.append(f"/* GUI generated for {spec.gui_spec_id} "
               f"(layout={spec.layout_type}) */")
    out.append(f".gui-{spec.layout_type} {{")

    grid = spec.grid or {}
    cols = grid.get("columns", "minmax(0,1fr)")
    rows = grid.get("rows", "auto")
    areas = grid.get("areas") or []
    out.append("  display: grid;")
    out.append(f"  grid-template-columns: {cols};")
    if isinstance(rows, str) and rows.strip():
        out.append(f"  grid-template-rows: {rows};")
    if areas:
        # CSS Grid areas value = quoted concatenation of each row's tokens.
        quoted_rows = " ".join(
            _css_quote(_CSS_GRID_AREAS_RE.sub(" ", row).strip())
            for row in areas if row.strip()
        )
        out.append(f"  grid-template-areas: {quoted_rows};")

    # Typography hints (font-family falls back via var(--gui-font-display)).
    typo = spec.typography or {}
    display = typo.get("display")
    if display:
        out.append(f"  font-family: {display}, var(--gui-font-display);")
    letter_spacing = typo.get("letter_spacing")
    if letter_spacing:
        out.append(f"  letter-spacing: {letter_spacing};")
    case = typo.get("case")
    if case == "upper":
        out.append("  text-transform: uppercase;")
    out.append("}")

    # Chrome skin — purely presentational. References CSS variables only,
    # never inline color literals.
    out.append(f".gui-{spec.layout_type}.chrome-{spec.chrome} {{")
    if spec.chrome == "crt_scanline":
        out.append("  position: relative;")
        out.append("  background-image: linear-gradient("
                   "rgba(255,255,255,0.04) 50%, transparent 50%);"
                   "background-size: 100% 4px;")
        out.append("  box-shadow: inset 0 0 80px rgba(0,0,0,0.6);")
    elif spec.chrome == "parchment_frame":
        out.append("  background-image: radial-gradient("
                   "ellipse at top left, var(--panel2) 0%, transparent 70%);")
        out.append("  border: 2px solid var(--ink-faint);")
    elif spec.chrome == "proscenium":
        out.append("  box-shadow: inset 0 0 60px rgba(0,0,0,0.55);")
    elif spec.chrome == "instrument_bezel":
        out.append("  border: 1px solid var(--grid-bri);")
    out.append("}")

    # Motion class hook — actual transitions live in styles.css; we just
    # add the class so theming and behaviour can fork separately.
    out.append(f".gui-{spec.layout_type}.motion-{spec.motion} {{")
    if spec.motion == "glitch":
        out.append("  animation: glitch-shift 4s steps(1) infinite;")
    out.append("}")

    # Per-widget type rules — color via role, no inline color literals.
    for widget in spec.widgets:
        sel = f".gui-{spec.layout_type} .w-{widget.type}"
        out.append(f"{sel} {{ grid-area: {widget.area}; }}")
        if widget.role:
            # Role drives the paint through CSS variables, never literal hex.
            role_var = f"--{widget.role.replace('_', '-')}"
            out.append(f"{sel}.role-{widget.role} {{ "
                       f"color: var({role_var}); }}")

    return "\n".join(out) + "\n"


def compile_to_html_template(spec: GUISpec) -> str:
    """Emit an HTML skeleton driven by `spec.widgets`.

    Each widget becomes a ``<div class="w-<type>" data-widget="<name>" ...>``
    block.  The runtime (web/gui/dynamic_gui.js) is responsible for
    attaching behaviour on these data attributes.
    """
    lines: List[str] = []
    lines.append(f"<!-- GUI template generated for {spec.gui_spec_id} "
                 f"(layout={spec.layout_type}) -->")
    root_classes = (
        f"gui-{spec.layout_type} chrome-{spec.chrome} "
        f"motion-{spec.motion} icon-{spec.icon_style}"
    )
    lines.append(f'<section class="{root_classes}" '
                 f'data-gui-spec="{spec.gui_spec_id}">')
    for widget in spec.widgets:
        attrs = [
            f'class="w-{widget.type} role-{widget.role}"',
            f'data-widget="{_attr(widget.name)}"',
            f'data-type="{_attr(widget.type)}"',
            f'data-area="{_attr(widget.area)}"',
            f'data-role="{_attr(widget.role)}"',
            f'style="grid-area: {_attr(widget.area)};"',
        ]
        binds = widget.binds or {}
        if "emit" in binds:
            attrs.append(f'data-binds-emit="{_attr(binds["emit"])}"')
        if "read" in binds:
            attrs.append(f'data-binds-read="{_attr(binds["read"])}"')
        if binds.get("commit"):
            attrs.append('data-binds-commit="true"')
        if binds.get("verb"):
            attrs.append(f'data-binds-verb="{_attr(binds["verb"])}"')
        if "action" in binds:
            attrs.append(f'data-binds-action="{_attr(binds["action"])}"')
        if widget.label:
            attrs.append(f'data-label="{_attr(widget.label)}"')
        if widget.title:
            attrs.append(f'data-title="{_attr(widget.title)}"')
        if widget.placeholder:
            attrs.append(f'data-placeholder="{_attr(widget.placeholder)}"')
        if widget.type in {"slider", "dial", "gauge", "meter"}:
            if widget.min is not None:
                attrs.append(f'data-min="{_attr(widget.min)}"')
            if widget.max is not None:
                attrs.append(f'data-max="{_attr(widget.max)}"')

        body = _widget_inner_html(widget)
        lines.append(f'  <div {" ".join(attrs)}>{body}</div>')
    lines.append("</section>")
    return "\n".join(lines) + "\n"


def _attr(value: Any) -> str:
    """HTML-escape and quote an attribute value (defensive, even for trusted data)."""
    if value is None:
        return ""
    s = str(value)
    return (s.replace("&", "&amp;")
             .replace('"', "&quot;")
             .replace("<", "&lt;")
             .replace(">", "&gt;"))


def _widget_inner_html(widget: WidgetSpec) -> str:
    """Static skeleton inside each widget — runtime fills it with live data."""
    if widget.type == "text_field":
        return (f'<label class="w-label">{_attr(widget.label)}</label>'
                f'<input type="text" placeholder="{_attr(widget.placeholder)}" />')
    if widget.type == "commit_bar":
        return (f'<button class="w-btn" type="button">'
                f'{_attr(widget.label)}</button>')
    if widget.type == "slider":
        return (f'<label class="w-label">{_attr(widget.label)}</label>'
                f'<input type="range" min="{_attr(widget.min)}" '
                f'max="{_attr(widget.max)}" />')
    if widget.type == "dial":
        return (f'<label class="w-label">{_attr(widget.label)}</label>'
                f'<div class="w-dial-knob"></div>')
    if widget.type in {"button", "button_group", "card_row"}:
        opts = widget.options or [{"label": widget.label or widget.name}]
        items = "".join(
            f'<button class="w-btn" data-verb="{_attr(o.get("verb", ""))}" '
            f'type="button">{_attr(o.get("label", ""))}</button>'
            for o in opts
        )
        return f'<div class="w-buttons">{items}</div>'
    if widget.type == "toggle":
        return (f'<label class="w-label">{_attr(widget.label)}</label>'
                f'<span class="w-toggle"><span class="w-toggle-knob"></span></span>')
    if widget.type == "canvas_panel":
        return (f'<div class="w-panel-header">{_attr(widget.title)}</div>'
                f'<canvas class="w-canvas"></canvas>')
    if widget.type == "map_panel":
        return (f'<div class="w-panel-header">{_attr(widget.title)}</div>'
                f'<div class="w-map"></div>')
    if widget.type in {"table", "ledger_grid"}:
        return (f'<div class="w-panel-header">{_attr(widget.title)}</div>'
                f'<table class="w-table"><tbody></tbody></table>')
    if widget.type == "log_feed":
        return (f'<div class="w-panel-header">{_attr(widget.title)}</div>'
                f'<ul class="w-log"></ul>')
    if widget.type in {"gauge", "meter"}:
        return (f'<label class="w-label">{_attr(widget.label)}</label>'
                f'<div class="w-bar"><div class="w-bar-fill"></div></div>')
    if widget.type == "lamp":
        return (f'<span class="w-lamp-dot"></span>'
                f'<label class="w-label">{_attr(widget.label)}</label>')
    if widget.type == "timeline":
        return (f'<div class="w-panel-header">{_attr(widget.title)}</div>'
                f'<div class="w-timeline"></div>')
    if widget.type == "nameplate":
        return (f'<div class="w-name">{_attr(widget.label)}</div>')
    if widget.type == "cue_row":
        return (f'<div class="w-panel-header">{_attr(widget.label)}</div>'
                f'<ul class="w-cues"></ul>')
    if widget.type == "text":
        return (f'<div class="w-panel-header">{_attr(widget.title)}</div>'
                f'<div class="w-text">{_attr(widget.label)}</div>')
    # Kernel-information panels (§13.6 read-only director-view). The runtime
    # (web/world_gui.js) fills these from build_info_panel_payload(); the
    # skeleton just names the slot so a spec-mounted GUI is readable before
    # live data lands.
    if widget.type == "belief_panel":
        return (f'<div class="w-panel-header">{_attr(widget.title or "角色信念")}</div>'
                f'<ul class="w-belief-list" data-slot="beliefs"></ul>')
    if widget.type == "commitment_list":
        return (f'<div class="w-panel-header">{_attr(widget.title or "决策承诺")}</div>'
                f'<ul class="w-commitment-list" data-slot="commitments"></ul>')
    if widget.type == "causal_trace_panel":
        return (f'<div class="w-panel-header">{_attr(widget.title or "因果叙事")}</div>'
                f'<div class="w-causal" data-slot="causal_narrative"></div>')
    if widget.type == "outcome_chapter":
        return (f'<div class="w-panel-header">{_attr(widget.title or "结局章")}</div>'
                f'<div class="w-outcome" data-slot="outcome_chapter"></div>')
    return f'<div class="w-label">{_attr(widget.label)}</div>'


# ---------------------------------------------------------------------------
# Convenience: preserialise a spec to JSON (§4.1 mirror shape).
# ---------------------------------------------------------------------------

def spec_to_json(spec: GUISpec) -> str:
    """Return the gui_spec DSL mirror (§4.1). Indented, deterministic."""
    payload = spec.to_dict()
    return json.dumps(payload, sort_keys=False, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Kernel-information panel payload (§13.6 director view).
#
# ``build_info_panel_payload`` is the single source of truth for what the
# read-only director-view panel shows. It takes the two generic shapes the
# server already exposes — a tick's ``model_trace`` (from
# ``/api/world/tick`` / ``/api/world/fast_forward`` ``last_beat``) and the
# active world's snapshot (from ``/api/state``) — and projects them into a
# flat, front-end-renderable dict:
#
#   {
#     "kernel_state":   {beat, world_id, schema_version, character_count,
#                        worldbook_count, object_count, rule_count},
#     "meta":           {...},
#     "rules":          [{...}, ...],
#     "characters":     [{...}, ...],
#     "worldbook":      [{...}, ...],
#     "beliefs":        [{actor_id, topic, predicted, confidence,
#                         strategy, contradiction, accepted, model_error}],
#     "commitments":    [{commitment_id, actor_id, goal, status, progress,
#                         required_resources, allocated_resources,
#                         decision_type}],
#     "causal_narrative": {narrative, validation_ok, validation_errors,
#                          fallback_used, graph_nodes, graph_edges},
#     "event_log":      [str, ...],
#     "outcome_chapter": {kind, text, title, source},
#   }
#
# Every field is optional — missing sub-objects collapse to empty lists /
# None so the front-end (web/world_gui.js renderInfoPanel) can render partial
# state without crashing. This is also the contract the LLM-shaped GUI's
# belief_panel / commitment_list / causal_trace_panel / outcome_chapter widgets
# bind to via ``state:<slot>`` reads.
#
# LLM-GUI extension contract (gui_generation_design.md §4.4 / §7):
#   - widget white-list: ALLOWED_WIDGET_TYPES (closed; LLM selects +
#     parametrises, never invents widget code).
#   - binds rule: every widget sets exactly one of
#       {emit: <ALLOWED_INTENT_KINDS>, [commit], [action: ALLOWED_ACTIONS]} or
#       {read: "kernel:<path>" | "state:<path>"}.
#       The four kernel-information widgets are read-only — they bind
#       ``state:beliefs`` / ``state:commitments`` / ``state:causal_narrative``
#       / ``state:outcome_chapter`` so the runtime state bus can push the
#       matching slot from build_info_panel_payload().
#   - extension point: to surface a new kernel facet, (1) add a read-only
#       widget type to ALLOWED_WIDGET_TYPES, (2) give it a skeleton in
#       _widget_inner_html, (3) add the slot to build_info_panel_payload, and
#       (4) document the ``state:<slot>`` read target here. No write path is
#       ever added — the closed emit vocabulary is the only way a GUI widget
#       touches world state.
# ---------------------------------------------------------------------------

def _belief_rows(agent_mind: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten model_trace.agent_mind.agents into per-actor belief rows."""
    agents = (agent_mind or {}).get("agents") or {}
    rows: List[Dict[str, Any]] = []
    for actor_id, rec in agents.items():
        if not isinstance(rec, dict):
            continue
        belief = rec.get("belief")
        trace = rec.get("belief_trace") or {}
        # belief_trace is the BeliefUpdateTrace as_dict: prior/posterior/
        # strategy/contradiction/accepted/rejected_info/error_source.
        posterior = trace.get("posterior") or {}
        prior = trace.get("prior") or {}
        predicted = belief
        if predicted is None and isinstance(posterior, dict):
            predicted = posterior.get("predicted")
        confidence = posterior.get("confidence") if isinstance(posterior, dict) else None
        if confidence is None and isinstance(prior, dict):
            confidence = prior.get("confidence")
        rows.append({
            "actor_id": str(actor_id),
            "topic": str(trace.get("topic") or ""),
            "predicted": predicted,
            "confidence": confidence,
            "strategy": trace.get("strategy"),
            "contradiction": trace.get("contradiction"),
            "accepted": trace.get("accepted"),
            "rejected_info": trace.get("rejected_info"),
            "model_error": trace.get("error_source"),
        })
    return rows


def _commitment_rows(commitments: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flatten model_trace.commitments.resolutions into commitment rows.

    Each DecisionResolution carries the freshly-created/updated Commitment
    (goal/progress/status/required_resources). We surface the same fields the
    front-end director view shows.
    """
    out: List[Dict[str, Any]] = []
    for res in (commitments or {}).get("resolutions") or []:
        if not isinstance(res, dict):
            continue
        # DecisionResolution.to_dict nests the commitment under "commitment".
        c = res.get("commitment") or res
        out.append({
            "commitment_id": c.get("commitment_id"),
            "actor_id": c.get("actor_id"),
            "goal": c.get("goal"),
            "status": c.get("status"),
            "progress": c.get("progress"),
            "decision_type": c.get("decision_type"),
            "required_resources": dict(c.get("required_resources") or {}),
            "allocated_resources": dict(c.get("allocated_resources") or {}),
            "resolution_status": res.get("status"),
        })
    return out


def _causal_narrative(agent_mind: Dict[str, Any]) -> Dict[str, Any]:
    cn = (agent_mind or {}).get("causal_narrative") or {}
    if not isinstance(cn, dict):
        cn = {}
    graph = cn.get("causal_graph") or {}
    nodes, edges = [], []
    if isinstance(graph, dict):
        nodes = list(graph.get("nodes") or [])
        edges = list(graph.get("edges") or [])
    return {
        "narrative": cn.get("narrative"),
        "validation_ok": cn.get("validation_ok"),
        "validation_errors": list(cn.get("validation_errors") or []),
        "fallback_used": cn.get("fallback_used"),
        "graph_nodes": nodes,
        "graph_edges": edges,
    }


def _outcome_chapter(model_trace: Dict[str, Any],
                     world_updates: List[Any]) -> Dict[str, Any]:
    """Recover a generic outcome chapter and optional kernel verdict.

    Kernel adapters may prefix their source names, so an update is considered
    an outcome when its explicit type is ``outcome_chapter`` or its source
    ends with that generic suffix. No adapter or setting name is special-cased.
    """
    kind = None
    direct = None
    if isinstance(model_trace, dict):
        kind = model_trace.get("outcome_kind") or model_trace.get("kernel_verdict")
        direct = model_trace.get("outcome_chapter")

    text = None
    title = None
    source = None
    if isinstance(direct, dict):
        kind = direct.get("kind") or kind
        text = direct.get("text") or direct.get("content")
        title = direct.get("title")
        source = direct.get("source")
    elif isinstance(direct, str):
        text = direct

    for wu in world_updates or []:
        if not isinstance(wu, dict):
            continue
        src = str(wu.get("source") or "")
        update_type = str(wu.get("type") or "")
        if update_type == "outcome_chapter" or (
            src == "outcome_chapter" or src.endswith("_outcome_chapter")
        ):
            kind = wu.get("outcome_kind") or wu.get("kind") or kind
            text = wu.get("content") or wu.get("text") or text
            title = wu.get("title") or title
            source = src or source
            break
    return {
        "kind": kind,
        "text": text,
        "title": title,
        "source": source,
    }


def build_info_panel_payload(
    model_trace: Optional[Dict[str, Any]] = None,
    state: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Project a tick trace and generic world state into the panel payload.

    Both inputs are optional so callers can refresh whichever is available
    (poll ``/api/state`` independently, then fill beliefs/commitments after a
    tick). The projection only understands framework-level state, metadata,
    rules, characters, and worldbook records; optional kernels remain opaque.
    """
    mt: Dict[str, Any] = model_trace if isinstance(model_trace, dict) else {}
    world: Dict[str, Any] = state if isinstance(state, dict) else {}
    meta = world.get("_meta") or world.get("meta") or {}
    if not isinstance(meta, dict):
        meta = {}

    characters = world.get("characters")
    if not isinstance(characters, list):
        characters = []
    worldbook = world.get("worldbook")
    if not isinstance(worldbook, list):
        worldbook = []
    objects = world.get("objects")
    if not isinstance(objects, list):
        objects = []
    rules = world.get("rules")
    if not isinstance(rules, list):
        kernel_spec = world.get("world_kernel_spec") or {}
        rules = kernel_spec.get("rules") if isinstance(kernel_spec, dict) else []
    if not isinstance(rules, list):
        rules = []

    base_kernel_state = world.get("kernel_state") or mt.get("kernel_state") or {}
    if not isinstance(base_kernel_state, dict):
        base_kernel_state = {}
    kernel_state = {
        "beat": (
            mt.get("world_builder_beat")
            if mt.get("world_builder_beat") is not None
            else base_kernel_state.get("beat")
        ),
        "world_id": (
            world.get("world_id")
            or meta.get("world_id")
            or mt.get("world_id")
        ),
        "schema_version": (
            world.get("schema_version")
            if world.get("schema_version") is not None
            else meta.get("schema_version")
        ),
        "character_count": len(characters),
        "worldbook_count": len(worldbook),
        "object_count": len(objects),
        "rule_count": len(rules),
    }

    event_log: List[Any] = []
    kel = mt.get("kernel_event_log")
    if isinstance(kel, list):
        event_log = list(kel)
    persisted_events = world.get("event_log")
    if isinstance(persisted_events, list):
        event_log.extend(persisted_events)

    agent_mind = mt.get("agent_mind") if isinstance(mt.get("agent_mind"), dict) else {}
    causal = _causal_narrative(agent_mind)
    if not causal.get("narrative") and mt.get("agent_causal_trace"):
        act = mt["agent_causal_trace"]
        if isinstance(act, dict):
            if not causal.get("graph_nodes"):
                causal["graph_nodes"] = list(act.get("nodes") or [])
            if not causal.get("graph_edges"):
                causal["graph_edges"] = list(act.get("edges") or [])
            if not causal.get("narrative"):
                causal["narrative"] = act.get("narrative") or act.get("summary")

    world_updates = mt.get("world_updates") or []
    if not isinstance(world_updates, list):
        world_updates = []

    return {
        "kernel_state": kernel_state,
        "meta": dict(meta),
        "rules": list(rules),
        "characters": list(characters),
        "worldbook": list(worldbook),
        "narrative": world.get("narrative") or mt.get("narrative"),
        "beliefs": _belief_rows(agent_mind),
        "commitments": _commitment_rows(mt.get("commitments") or {}),
        "causal_narrative": causal,
        "event_log": event_log,
        "outcome_chapter": _outcome_chapter(mt, world_updates),
    }
