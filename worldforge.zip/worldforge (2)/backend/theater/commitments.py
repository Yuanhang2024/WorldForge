"""Decision-commitment lifecycle objects (architecture spec — decision
commitments as persistent causal mechanisms).

User principle (load-bearing): **small decisions produce events; major
decisions produce persistent causal mechanisms**.  A character does not
directly mutate the world; a character *makes a commitment* → the
commitment occupies resources, triggers organisational and third-party
reactions → execution is resisted / delayed → the result enters the kernel
→ the result shapes beliefs.

This module is the pure-stdlib, deterministic, no-LLM data + state-machine
layer for that lifecycle.  It defines four first-class objects plus the
per-agent agenda and the per-tick executor that advances active
commitments::

    Commitment                 — the persistent causal mechanism itself
    ScheduledEffect            — a deferred, condition-gated consequence
    WorldModifier              — a time-bounded rule / state modifier
    DecisionResolutionTrace    — audit record of why a decision resolved
                                 the way it did (effect-formula factors)
    DecisionEffects            — the 4-layer consequence bundle
    AgentAgenda                — a subject's persistent goals + pressures
    CommitmentExecutor         — per-tick progress / trigger / expire

Red lines (unchanged across the codebase)
-----------------------------------------
- Pure stdlib, deterministic, seed-driven (spec §8.2).  No LLM, no
  unseeded randomness.
- A commitment is a *commitment to act over time*; it does not mutate
  world state directly (§12 — the kernel / write point owns mutation).
  The executor emits structured effects + observable events; the
  dispatcher's single write point settles them.
- Read-only reuse of ``cognitive_model.Belief``, ``character_graph``;
  no kernel is modified here.

Lifecycle (§ decision lifecycle)
--------------------------------
    goal → opportunity/pressure → propose → authority feasibility check
    → win organisational support → allocate resources → form Commitment
    → phased execution → third-party reactions → direct + indirect
    consequences → agent revises belief

Commitment status machine::

    proposed → authorized → active → {blocked | completed | abandoned | failed}

``proposed`` → ``authorized`` (authority check passed) → ``active``
(resources allocated, execution begins).  ``active`` may drop to
``blocked`` (opposition / missing resource) and rise back to ``active``.
Terminal states: ``completed`` (progress ≥ 1.0), ``abandoned`` (actor
withdrew), ``failed`` (execution collapsed — sabotaged / starved).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple


__all__ = [
    "Commitment",
    "CommitmentStatus",
    "ScheduledEffect",
    "WorldModifier",
    "DecisionResolutionTrace",
    "DecisionEffects",
    "AgentAgenda",
    "CommitmentProposal",
    "CommitmentExecutor",
    "COMMITMENT_STATUS_ORDER",
    "ACTION_TEMPLATES",
    "is_terminal_status",
    "valid_transition",
    "transition_commitment",
    "build_launch_project_proposal",
    "build_establish_policy_proposal",
    "build_mobilize_faction_proposal",
    "authority_for_action",
    "customize_effects",
    "resource_requirements_for",
]


# ---------------------------------------------------------------------------
# Commitment status vocabulary + state machine
# ---------------------------------------------------------------------------


class CommitmentStatus:
    """Commitment lifecycle states (spec — proposed→…→failed).

    Kept as a plain string-constant class (not an Enum) so the status
    serialises trivially to JSON alongside the rest of the world state
    and stays hashable / comparable as a string.
    """

    PROPOSED = "proposed"
    AUTHORIZED = "authorized"
    ACTIVE = "active"
    BLOCKED = "blocked"
    COMPLETED = "completed"
    ABANDONED = "abandoned"
    FAILED = "failed"


#: Linear progression of the non-terminal states.  Terminal states have
#: no successor.  ``blocked`` is non-terminal: it can return to ``active``.
COMMITMENT_STATUS_ORDER: List[str] = [
    CommitmentStatus.PROPOSED,
    CommitmentStatus.AUTHORIZED,
    CommitmentStatus.ACTIVE,
    CommitmentStatus.BLOCKED,
]

_TERMINAL: set = {
    CommitmentStatus.COMPLETED,
    CommitmentStatus.ABANDONED,
    CommitmentStatus.FAILED,
}


def is_terminal_status(status: str) -> bool:
    """True for the three terminal commitment states."""
    return status in _TERMINAL


# Legal (from → set(of legal successors)) transitions.  Encodes the
# state machine: authority gates proposal; resource allocation gates
# activation; execution can stall (blocked) and resume; only the three
# terminal states are sinks.
_TRANSITIONS: Dict[str, set] = {
    CommitmentStatus.PROPOSED: {
        CommitmentStatus.AUTHORIZED,    # authority check passed
        CommitmentStatus.FAILED,        # rejected outright / infeasible
        CommitmentStatus.ABANDONED,     # proposer withdraws before auth
    },
    CommitmentStatus.AUTHORIZED: {
        CommitmentStatus.ACTIVE,        # resources allocated, execution begins
        CommitmentStatus.BLOCKED,       # resource shortfall before start
        CommitmentStatus.ABANDONED,
        CommitmentStatus.FAILED,
    },
    CommitmentStatus.ACTIVE: {
        CommitmentStatus.BLOCKED,       # opposition / missing input mid-run
        CommitmentStatus.COMPLETED,     # progress ≥ 1.0
        CommitmentStatus.ABANDONED,
        CommitmentStatus.FAILED,        # sabotaged / collapsed
    },
    CommitmentStatus.BLOCKED: {
        CommitmentStatus.ACTIVE,        # unblocked — resumes
        CommitmentStatus.ABANDONED,
        CommitmentStatus.FAILED,
    },
    CommitmentStatus.COMPLETED: set(),
    CommitmentStatus.ABANDONED: set(),
    CommitmentStatus.FAILED: set(),
}


def valid_transition(from_status: str, to_status: str) -> bool:
    """Whether ``from_status → to_status`` is a legal state-machine edge."""
    if from_status == to_status:
        return True  # idempotent re-affirmation is allowed
    return to_status in _TRANSITIONS.get(from_status, set())


def transition_commitment(commitment: "Commitment", to_status: str,
                          *, reason: str = "") -> str:
    """Move ``commitment`` to ``to_status`` if legal; else raise ValueError.

    Returns the new status.  Records the transition in the commitment's
    ``history`` (event-sourced audit, mirroring ``character_graph``
    Relationship history) so the lifecycle is replayable.
    """
    if not valid_transition(commitment.status, to_status):
        raise ValueError(
            f"illegal commitment transition "
            f"{commitment.status!r} → {to_status!r} "
            f"(commitment {commitment.commitment_id})"
        )
    old = commitment.status
    commitment.status = to_status
    commitment.history.append({
        "event": "transition",
        "from": old,
        "to": to_status,
        "reason": reason,
    })
    return to_status


# ---------------------------------------------------------------------------
# Commitment — the persistent causal mechanism
# ---------------------------------------------------------------------------


@dataclass
class Commitment:
    """A persistent, multi-tick commitment a subject made (spec § decisions).

    A commitment is **not** a state delta — it is a mechanism that
    occupies resources, triggers reactions, and unfolds over time.  Even
    a commitment that never reaches completion still changed the world:
    budget locked, personnel reassigned, factions guessing, old plans
    crowded out, reputation staked, future options constrained (path
    dependence).

    Fields
    ------
    commitment_id:
        Stable unique id (caller assigns — typically ``f"commit:{actor}:{n}"``).
    actor_id:
        The subject that made the commitment.
    decision_type:
        One of the generic major-action verbs — ``launch_project`` /
        ``establish_policy`` / ``mobilize_faction`` — or a world-specific
        verb.  Routed by :class:`DecisionResolver`.
    target_ids:
        Ids of the objects / factions / regions the commitment acts on.
    goal:
        Free-form goal string (LLM-authored at proposal time; the
        structural layer never reads it for physics).
    required_resources:
        ``{resource_key: amount}`` the commitment needs to complete.
    allocated_resources:
        ``{resource_key: amount}`` actually granted so far.  The gap
        between required and allocated is one source of ``partial`` /
        ``delayed`` resolution.
    authority_source:
        Who authorised it (``actor_id`` for self, an org id, or
        ``"self"``).  Drives the authority factor in the effect formula.
    start_tick:
        Tick the commitment was proposed (not necessarily activated).
    expected_duration:
        Ticks the commitment is expected to run once active.
    progress:
        ``[0.0, 1.0]`` — how far execution has advanced.
    priority:
        ``[0.0, 1.0]`` — higher-priority commitments win resource
        conflicts.
    reversibility:
        ``[0.0, 1.0]`` — 0 = irreversible (once started, cannot undo
        without loss), 1 = freely reversible.  Drives abandon cost.
    secrecy:
        ``[0.0, 1.0]`` — 0 = fully public, 1 = fully secret.  Gates the
        observable-event broadcast (secret commitments leak partially).
    status:
        Lifecycle state — see :class:`CommitmentStatus`.
    history:
        Event-sourced audit log of transitions + tick-level progress.
    spawned_tick:
        Tick the commitment became ``active`` (None until activated).
    last_tick:
        Last tick the executor advanced this commitment.
    """

    commitment_id: str
    actor_id: str
    decision_type: str
    target_ids: List[str] = field(default_factory=list)
    goal: str = ""
    required_resources: Dict[str, float] = field(default_factory=dict)
    allocated_resources: Dict[str, float] = field(default_factory=dict)
    authority_source: str = "self"
    start_tick: int = 0
    expected_duration: int = 1
    progress: float = 0.0
    priority: float = 0.5
    reversibility: float = 0.5
    secrecy: float = 0.0
    status: str = CommitmentStatus.PROPOSED
    history: List[Dict[str, Any]] = field(default_factory=list)
    spawned_tick: Optional[int] = None
    last_tick: Optional[int] = None

    def __post_init__(self) -> None:
        self.progress = max(0.0, min(1.0, float(self.progress)))
        self.priority = max(0.0, min(1.0, float(self.priority)))
        self.reversibility = max(0.0, min(1.0, float(self.reversibility)))
        self.secrecy = max(0.0, min(1.0, float(self.secrecy)))
        self.expected_duration = max(1, int(self.expected_duration))

    # -- convenience -------------------------------------------------------

    @property
    def is_terminal(self) -> bool:
        return is_terminal_status(self.status)

    @property
    def is_active(self) -> bool:
        return self.status == CommitmentStatus.ACTIVE

    @property
    def resource_gap(self) -> float:
        """Total shortfall = sum(required) − sum(allocated).  ≥ 0."""
        req = sum(float(v) for v in self.required_resources.values())
        got = sum(float(v) for v in self.allocated_resources.values())
        return max(0.0, req - got)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "commitment_id": self.commitment_id,
            "actor_id": self.actor_id,
            "decision_type": self.decision_type,
            "target_ids": list(self.target_ids),
            "goal": self.goal,
            "required_resources": dict(self.required_resources),
            "allocated_resources": dict(self.allocated_resources),
            "authority_source": self.authority_source,
            "start_tick": self.start_tick,
            "expected_duration": self.expected_duration,
            "progress": self.progress,
            "priority": self.priority,
            "reversibility": self.reversibility,
            "secrecy": self.secrecy,
            "status": self.status,
            "history": list(self.history),
            "spawned_tick": self.spawned_tick,
            "last_tick": self.last_tick,
        }


# ---------------------------------------------------------------------------
# ScheduledEffect — a deferred, condition-gated consequence
# ---------------------------------------------------------------------------


@dataclass
class ScheduledEffect:
    """A consequence of a commitment that fires at a future tick (spec).

    ``condition`` is an optional callable ``(world_state, current_tick)
    → bool``; when it returns False at the due tick the effect is
    skipped (not cancelled — it may re-check next tick until
    ``cancel_conditions`` fire).  ``effect`` is a dict the executor
    interprets (``{op, path, value}`` style or a free-form event payload).
    ``cancel_conditions`` is a list of callables; any returning True
    cancels the effect (it never fires).
    """

    source_id: str
    due_tick: int
    effect: Dict[str, Any] = field(default_factory=dict)
    condition: Optional[Callable[[Dict[str, Any], int], bool]] = None
    cancel_conditions: List[Callable[[Dict[str, Any], int], bool]] = field(default_factory=list)
    triggered: bool = False
    cancelled: bool = False

    def should_fire(self, world_state: Dict[str, Any], current_tick: int) -> bool:
        """Due, not yet fired/cancelled, condition (if any) holds, no cancel."""
        if self.triggered or self.cancelled:
            return False
        if current_tick < self.due_tick:
            return False
        for cancel_fn in self.cancel_conditions:
            try:
                if cancel_fn(world_state, current_tick):
                    self.cancelled = True
                    return False
            except Exception:
                continue
        if self.condition is not None:
            try:
                if not self.condition(world_state, current_tick):
                    return False
            except Exception:
                return False
        return True

    def should_cancel(self, world_state: Dict[str, Any], current_tick: int) -> bool:
        """Whether a cancel-condition has fired (checked even before due)."""
        if self.triggered or self.cancelled:
            return False
        for cancel_fn in self.cancel_conditions:
            try:
                if cancel_fn(world_state, current_tick):
                    self.cancelled = True
                    return True
            except Exception:
                continue
        return False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_id": self.source_id,
            "due_tick": self.due_tick,
            "effect": dict(self.effect),
            "triggered": self.triggered,
            "cancelled": self.cancelled,
        }


# ---------------------------------------------------------------------------
# WorldModifier — a time-bounded rule / state modifier
# ---------------------------------------------------------------------------


@dataclass
class WorldModifier:
    """A time-bounded modification to a world rule / state path (spec).

    ``rule_modifiers`` is a list of ``{path, op, value}`` changes the
    executor applies to the world state at ``start_tick`` and reverts at
    ``end_tick``.  ``op`` is ``"set"`` (record the prior value, restore
    on expiry) or ``"add"`` (apply a delta at start, subtract it at end).

    How it acts on ``WorldKernelHost``: the executor does **not** modify
    the kernel's compiled rules (red line).  Instead it applies the
    modifier's changes to the host's *state* dict — the same surface
    ``WorldKernelHost.step`` reads.  When a host is available the
    dispatcher routes each change through the host's write path so the
    rule engine still gates writes; when no host is present (pure
    dict-state worlds) the executor applies the change directly.  Either
    way the modifier is *data*, not a rule edit.
    """

    modifier_id: str
    source_decision_id: str
    scope: str = ""
    start_tick: int = 0
    end_tick: int = 0
    rule_modifiers: List[Dict[str, Any]] = field(default_factory=list)
    active: bool = False
    applied: bool = False        # has the start-tick change been applied
    _saved_prior: Dict[str, Any] = field(default_factory=dict, repr=False)

    @property
    def is_expired(self, current_tick: int = 0) -> bool:
        return self.end_tick > 0 and current_tick > self.end_tick

    def to_dict(self) -> Dict[str, Any]:
        return {
            "modifier_id": self.modifier_id,
            "source_decision_id": self.source_decision_id,
            "scope": self.scope,
            "start_tick": self.start_tick,
            "end_tick": self.end_tick,
            "rule_modifiers": list(self.rule_modifiers),
            "active": self.active,
            "applied": self.applied,
        }


# ---------------------------------------------------------------------------
# DecisionResolutionTrace — audit record of the effect-formula factors
# ---------------------------------------------------------------------------


@dataclass
class DecisionResolutionTrace:
    """Why a proposed decision resolved the way it did (spec § effect formula).

    The actual effect of a decision is::

        net = decision_strength
              × authority
              × resource
              × execution_capability
              × org_compliance
              × time
              × environment_fit
              × (1 − opposition)
              × (1 − info_error_penalty)   # cognitive error
              × (1 − failure_penalty)      # execution failure

    Every factor is ``[0, 1]`` (a ratio) except ``decision_strength``
    which may exceed 1 (a strong actor pushes harder).  The trace keeps
    the decomposition so the narrator / tests can read *why* a decision
    landed as ``partial`` rather than ``completed``.

    ``cognitive_error`` (the actor's judgement was wrong — they misread
    the situation) is distinguished from ``execution_failure`` (the
    decision was sound but execution collapsed).  Both depress the net
    effect but for different narrative reasons.
    """

    decision_strength: float = 1.0
    authority: float = 1.0
    resource: float = 1.0
    execution_capability: float = 1.0
    org_compliance: float = 1.0
    time: float = 1.0
    environment_fit: float = 1.0
    opposition: float = 0.0
    info_error_penalty: float = 0.0
    failure_penalty: float = 0.0
    cognitive_error: bool = False
    execution_failure: bool = False
    raw_effect: float = 0.0
    net_effect: float = 0.0
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "decision_strength": self.decision_strength,
            "authority": self.authority,
            "resource": self.resource,
            "execution_capability": self.execution_capability,
            "org_compliance": self.org_compliance,
            "time": self.time,
            "environment_fit": self.environment_fit,
            "opposition": self.opposition,
            "info_error_penalty": self.info_error_penalty,
            "failure_penalty": self.failure_penalty,
            "cognitive_error": self.cognitive_error,
            "execution_failure": self.execution_failure,
            "raw_effect": self.raw_effect,
            "net_effect": self.net_effect,
            "notes": self.notes,
        }


# ---------------------------------------------------------------------------
# DecisionEffects — the 4-layer consequence bundle
# ---------------------------------------------------------------------------


@dataclass
class DecisionEffects:
    """The structured consequences of a resolved decision (spec § 4 layers).

    Six buckets, ordered from immediate to long-horizon:

    1. ``immediate_deltas`` — scalar state changes applied this tick
       (``{path: delta}``).
    2. ``resource_transfers`` — resources moved between actors
       (``{from, to, resource, amount}``).
    3. ``relationship_changes`` — character_graph trust/conflict nudges
       (``{from, to, trust_delta, conflict_delta, reason}``).
    4. ``scheduled_effects`` — deferred :class:`ScheduledEffect` objects.
    5. ``world_modifiers`` — time-bounded :class:`WorldModifier` objects.
    6. ``spawned_commitments`` — ids of new commitments this decision
       spawned (path dependence — a decision that begets decisions).
    """

    immediate_deltas: Dict[str, float] = field(default_factory=dict)
    resource_transfers: List[Dict[str, Any]] = field(default_factory=list)
    relationship_changes: List[Dict[str, Any]] = field(default_factory=list)
    scheduled_effects: List[ScheduledEffect] = field(default_factory=list)
    world_modifiers: List[WorldModifier] = field(default_factory=list)
    spawned_commitments: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "immediate_deltas": dict(self.immediate_deltas),
            "resource_transfers": list(self.resource_transfers),
            "relationship_changes": list(self.relationship_changes),
            "scheduled_effects": [e.to_dict() for e in self.scheduled_effects],
            "world_modifiers": [m.to_dict() for m in self.world_modifiers],
            "spawned_commitments": list(self.spawned_commitments),
        }

    @property
    def is_empty(self) -> bool:
        return (
            not self.immediate_deltas
            and not self.resource_transfers
            and not self.relationship_changes
            and not self.scheduled_effects
            and not self.world_modifiers
            and not self.spawned_commitments
        )


# ---------------------------------------------------------------------------
# CommitmentProposal — what an agent emits at Phase 4 (major decision)
# ---------------------------------------------------------------------------


@dataclass
class CommitmentProposal:
    """A proposed major decision emitted by an agent (spec § Phase 4).

    Distinct from an ordinary :class:`ActionIntent` (a small per-tick
    action): a proposal is the *intent to form a commitment*.  The
    :class:`DecisionResolver` settles it — authority / resources / org
    support / opposition — and either creates a :class:`Commitment` or
    rejects it.
    """

    actor_id: str
    decision_type: str           # launch_project / establish_policy / mobilize_faction / ...
    target_ids: List[str] = field(default_factory=list)
    goal: str = ""
    required_resources: Dict[str, float] = field(default_factory=dict)
    expected_duration: int = 1
    priority: float = 0.5
    reversibility: float = 0.5
    secrecy: float = 0.0
    # Subjective (actor-side) inputs the resolver reads:
    decision_strength: float = 1.0
    execution_capability: float = 1.0
    # Context the dispatcher fills in before resolving:
    authority_source: str = "self"
    proposed_tick: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "actor_id": self.actor_id,
            "decision_type": self.decision_type,
            "target_ids": list(self.target_ids),
            "goal": self.goal,
            "required_resources": dict(self.required_resources),
            "expected_duration": self.expected_duration,
            "priority": self.priority,
            "reversibility": self.reversibility,
            "secrecy": self.secrecy,
            "decision_strength": self.decision_strength,
            "execution_capability": self.execution_capability,
            "authority_source": self.authority_source,
            "proposed_tick": self.proposed_tick,
        }


# ---------------------------------------------------------------------------
# AgentAgenda — a subject's persistent goals + pressures + initiative
# ---------------------------------------------------------------------------


@dataclass
class AgentAgenda:
    """A subject's persistent agenda (spec § initiative).

    Carries the *persistent* layer an ordinary ``choose_action`` cycle
    does not: long-lived goals, unresolved pressures, deadlines,
    opportunities, and active plans.  Each tick the dispatcher calls
    :meth:`initiative_score`; when it crosses ``initiative_threshold``
    the agent proactively emits a :class:`CommitmentProposal` — *without
    waiting for the player to trigger it*.

    ``initiative_score``::

        urgency_of_top_goal
        + opportunity_fit
        + failure_risk
        + personality_drive
        − cost
        − authority_barrier
        − uncertainty

    All terms ``[0, 1]`` except ``urgency`` which may exceed 1 (a
    looming deadline).  Deterministic: pure function of the agenda's
    fields.
    """

    goals: List[Dict[str, Any]] = field(default_factory=list)
    active_plans: List[str] = field(default_factory=list)
    unresolved_pressures: Dict[str, float] = field(default_factory=dict)
    deadlines: Dict[str, int] = field(default_factory=dict)
    opportunities: Dict[str, float] = field(default_factory=dict)
    initiative_threshold: float = 0.5
    # Personality knob folded into the drive term (0 = passive, 1 = bold).
    personality_drive: float = 0.5

    def add_goal(self, goal_id: str, urgency: float = 0.5,
                 cost: float = 0.3, authority_barrier: float = 0.2,
                 uncertainty: float = 0.3) -> None:
        """Register / update a goal on the agenda."""
        for g in self.goals:
            if g.get("goal_id") == goal_id:
                g["urgency"] = float(urgency)
                g["cost"] = float(cost)
                g["authority_barrier"] = float(authority_barrier)
                g["uncertainty"] = float(uncertainty)
                return
        self.goals.append({
            "goal_id": goal_id,
            "urgency": float(urgency),
            "cost": float(cost),
            "authority_barrier": float(authority_barrier),
            "uncertainty": float(uncertainty),
        })

    def top_goal(self) -> Optional[Dict[str, Any]]:
        """The highest-urgency goal (None when the agenda is empty)."""
        if not self.goals:
            return None
        return max(self.goals, key=lambda g: float(g.get("urgency", 0.0)))

    def initiative_score(self, *, current_tick: int = 0,
                         opportunity_fit: Optional[float] = None,
                         failure_risk: float = 0.0) -> float:
        """Compute the agent's initiative score for this tick.

        Parameters
        ----------
        current_tick:
            Used to scale urgency by looming deadlines (a deadline near
            the current tick boosts urgency).
        opportunity_fit:
            Caller-supplied fit of the current opportunity (0..1).  When
            None, falls back to the max unresolved opportunity on the
            agenda.
        failure_risk:
            Caller-supplied risk that *not* acting now loses the window
            (0..1).  Drives the agent to act before the moment passes.
        """
        top = self.top_goal()
        if top is None:
            return 0.0
        urgency = float(top.get("urgency", 0.5))
        cost = float(top.get("cost", 0.3))
        auth_barrier = float(top.get("authority_barrier", 0.2))
        uncertainty = float(top.get("uncertainty", 0.3))

        # Deadline pressure: a deadline close to now boosts urgency.
        for goal_id, due in self.deadlines.items():
            if goal_id == top.get("goal_id"):
                remain = max(0, due - current_tick)
                if remain <= 1:
                    urgency += 1.0
                elif remain <= 3:
                    urgency += 0.5
                break

        if opportunity_fit is None:
            opportunity_fit = (
                max(self.opportunities.values()) if self.opportunities else 0.0
            )
        opportunity_fit = max(0.0, min(1.0, float(opportunity_fit)))
        failure_risk = max(0.0, min(1.0, float(failure_risk)))
        drive = max(0.0, min(1.0, float(self.personality_drive)))

        score = (
            urgency
            + opportunity_fit
            + failure_risk
            + drive
            - cost
            - auth_barrier
            - uncertainty
        )
        return score

    def should_propose(self, *, current_tick: int = 0,
                       opportunity_fit: Optional[float] = None,
                       failure_risk: float = 0.0) -> bool:
        """Whether the agent proactively proposes a commitment this tick."""
        return self.initiative_score(
            current_tick=current_tick,
            opportunity_fit=opportunity_fit,
            failure_risk=failure_risk,
        ) >= self.initiative_threshold

    def to_dict(self) -> Dict[str, Any]:
        return {
            "goals": list(self.goals),
            "active_plans": list(self.active_plans),
            "unresolved_pressures": dict(self.unresolved_pressures),
            "deadlines": dict(self.deadlines),
            "opportunities": dict(self.opportunities),
            "initiative_threshold": self.initiative_threshold,
            "personality_drive": self.personality_drive,
        }


# ---------------------------------------------------------------------------
# 3 generic major-action templates (launch_project / establish_policy /
# mobilize_faction) — cover three-body / economy / political-fantasy /
# investigation / fantasy-build-war.
# ---------------------------------------------------------------------------


def _template_launch_project() -> Dict[str, Any]:
    """launch_project: build a durable project (observatory / trade house /
    fortress / investigation bureau).  Long duration, high resource need,
    spawns a world modifier (the project's output) on completion."""
    return {
        "decision_type": "launch_project",
        "default_duration": 8,
        "default_priority": 0.7,
        "default_reversibility": 0.2,
        "resource_keys": ["budget", "labor"],
        "modifier_scope": "project_output",
        "produces_modifier": True,
    }


def _template_establish_policy() -> Dict[str, Any]:
    """establish_policy: enact a rule / tax / reform / decree.  Short to
    enact, long-lived modifier, high reversibility resistance (policy is
    sticky)."""
    return {
        "decision_type": "establish_policy",
        "default_duration": 3,
        "default_priority": 0.6,
        "default_reversibility": 0.1,   # policy is sticky
        "resource_keys": ["authority"],
        "modifier_scope": "policy",
        "produces_modifier": True,
    }


def _template_mobilize_faction() -> Dict[str, Any]:
    """mobilize_faction: move a faction (rally / coup / war / expedition).
    Short, high-stakes, drains personnel, triggers strong opposition."""
    return {
        "decision_type": "mobilize_faction",
        "default_duration": 4,
        "default_priority": 0.8,
        "default_reversibility": 0.3,
        "resource_keys": ["personnel", "morale"],
        "modifier_scope": "mobilization",
        "produces_modifier": True,
    }


ACTION_TEMPLATES: Dict[str, Dict[str, Any]] = {
    "launch_project": _template_launch_project(),
    "establish_policy": _template_establish_policy(),
    "mobilize_faction": _template_mobilize_faction(),
}


def proposal_from_template(
    actor_id: str,
    decision_type: str,
    *,
    target_ids: Optional[List[str]] = None,
    goal: str = "",
    required_resources: Optional[Dict[str, float]] = None,
    expected_duration: Optional[int] = None,
    priority: Optional[float] = None,
    reversibility: Optional[float] = None,
    secrecy: float = 0.0,
    decision_strength: float = 1.0,
    execution_capability: float = 1.0,
    authority_source: str = "self",
    proposed_tick: int = 0,
) -> CommitmentProposal:
    """Build a :class:`CommitmentProposal` from a generic action template.

    Fills template defaults for any field the caller omits, so the three
    generic major actions are one-liners at the call site.
    """
    if decision_type not in ACTION_TEMPLATES:
        # Unknown verb: still build a proposal (world-specific actions),
        # just without template defaults.
        tpl: Dict[str, Any] = {}
    else:
        tpl = ACTION_TEMPLATES[decision_type]
    return CommitmentProposal(
        actor_id=actor_id,
        decision_type=decision_type,
        target_ids=list(target_ids or []),
        goal=goal,
        required_resources=dict(required_resources or {}),
        expected_duration=int(expected_duration if expected_duration is not None
                              else tpl.get("default_duration", 1)),
        priority=float(priority if priority is not None
                       else tpl.get("default_priority", 0.5)),
        reversibility=float(reversibility if reversibility is not None
                            else tpl.get("default_reversibility", 0.5)),
        secrecy=float(secrecy),
        decision_strength=float(decision_strength),
        execution_capability=float(execution_capability),
        authority_source=authority_source,
        proposed_tick=int(proposed_tick),
    )


# ---------------------------------------------------------------------------
# 3 generic major-action builders (launch_project / establish_policy /
# mobilize_faction).  Each builder is a one-liner at the call site that fills
# the template defaults + the action's canonical resource requirements +
# target shape.  The dispatcher's Phase 4 calls these when an AgentAgenda's
# initiative crosses threshold; Phase 5 hands the resulting proposal to the
# DecisionResolver.
# ---------------------------------------------------------------------------


def resource_requirements_for(decision_type: str, *, scale: float = 1.0,
                              ) -> Dict[str, float]:
    """Canonical resource requirements for a generic action at *scale*.

    ``scale`` lets a caller dial the project size (a bigger observatory
    costs more).  The keys mirror the template's ``resource_keys`` so the
    resolver's resource factor (allocated / required per-key min) reads
    them directly.
    """
    tpl = ACTION_TEMPLATES.get(decision_type, {})
    keys = tpl.get("resource_keys") or []
    base: Dict[str, float] = {
        "budget": 10.0,
        "labor": 8.0,
        "authority": 6.0,
        "personnel": 8.0,
        "morale": 5.0,
    }
    return {k: float(base.get(k, 5.0)) * float(scale) for k in keys}


def build_launch_project_proposal(
    actor_id: str, *, target_ids: Optional[List[str]] = None, goal: str = "",
    scale: float = 1.0, proposed_tick: int = 0,
    decision_strength: float = 1.0, execution_capability: float = 1.0,
    secrecy: float = 0.0, authority_source: str = "self",
    priority: Optional[float] = None, reversibility: Optional[float] = None,
    expected_duration: Optional[int] = None,
) -> CommitmentProposal:
    """launch_project: build a durable project (observatory / trade house /
    fortress / investigation bureau).  Long duration, high resource need,
    produces a world modifier (project output) on completion."""
    return proposal_from_template(
        actor_id, "launch_project",
        target_ids=target_ids, goal=goal,
        required_resources=resource_requirements_for("launch_project", scale=scale),
        expected_duration=expected_duration,
        priority=priority, reversibility=reversibility, secrecy=secrecy,
        decision_strength=decision_strength,
        execution_capability=execution_capability,
        authority_source=authority_source, proposed_tick=proposed_tick,
    )


def build_establish_policy_proposal(
    actor_id: str, *, target_ids: Optional[List[str]] = None, goal: str = "",
    scale: float = 1.0, proposed_tick: int = 0,
    decision_strength: float = 1.0, execution_capability: float = 1.0,
    secrecy: float = 0.0, authority_source: str = "self",
    priority: Optional[float] = None, reversibility: Optional[float] = None,
    expected_duration: Optional[int] = None,
) -> CommitmentProposal:
    """establish_policy: enact a rule / tax / reform / decree.  Short to
    enact, long-lived modifier, high stickiness (low reversibility)."""
    return proposal_from_template(
        actor_id, "establish_policy",
        target_ids=target_ids, goal=goal,
        required_resources=resource_requirements_for("establish_policy", scale=scale),
        expected_duration=expected_duration,
        priority=priority, reversibility=reversibility, secrecy=secrecy,
        decision_strength=decision_strength,
        execution_capability=execution_capability,
        authority_source=authority_source, proposed_tick=proposed_tick,
    )


def build_mobilize_faction_proposal(
    actor_id: str, *, target_ids: Optional[List[str]] = None, goal: str = "",
    scale: float = 1.0, proposed_tick: int = 0,
    decision_strength: float = 1.0, execution_capability: float = 1.0,
    secrecy: float = 0.0, authority_source: str = "self",
    priority: Optional[float] = None, reversibility: Optional[float] = None,
    expected_duration: Optional[int] = None,
    opposition_refs: Optional[List[str]] = None,
) -> CommitmentProposal:
    """mobilize_faction: rally / coup / war / expedition.  Short, high-stakes,
    drains personnel + morale, triggers strong opposition.  ``opposition_refs``
    is stashed on the proposal (as a private attr) so the dispatcher can route
    the faction's opponents into the resolver's Opposition input."""
    prop = proposal_from_template(
        actor_id, "mobilize_faction",
        target_ids=target_ids, goal=goal,
        required_resources=resource_requirements_for("mobilize_faction", scale=scale),
        expected_duration=expected_duration,
        priority=priority, reversibility=reversibility, secrecy=secrecy,
        decision_strength=decision_strength,
        execution_capability=execution_capability,
        authority_source=authority_source, proposed_tick=proposed_tick,
    )
    # stash opposing faction ids for the dispatcher's Opposition input
    prop._opposition_refs = list(opposition_refs or [])  # type: ignore[attr-defined]
    return prop


# ---------------------------------------------------------------------------
# Authority + per-action effect customisation
# ---------------------------------------------------------------------------


def authority_for_action(decision_type: str, actor_id: str,
                         *, mandate: float = 1.0,
                         authority_source: str = "self") -> "Any":
    """Build an :class:`~theater.decision_resolver.AuthorityCheck` for a
    generic action.  ``mandate`` ∈ [0,1] = how much authority backs the actor
    for this action (1 = full mandate, 0 = none → rejected).  By default a
    self-authored action is feasible with full mandate; an org action passes
    ``authority_source=<org_id>`` with the org's mandate factor."""
    from .decision_resolver import AuthorityCheck
    feasible = float(mandate) > 0.0
    return AuthorityCheck(
        feasible=feasible,
        factor=max(0.0, min(1.0, float(mandate))),
        authority_source=authority_source,
        reason=("" if feasible else "no authority for this action"),
    )


def customize_effects(decision_type: str, proposal: CommitmentProposal,
                      effects: "DecisionEffects", exec_ratio: float) -> "DecisionEffects":
    """Apply per-action 4-layer consequence customisation on top of the
    resolver's generic effects.

    - ``launch_project``: a completion-time scheduled effect that delivers the
      project's output (a scalar bump on the actor's ``project_output``).
    - ``establish_policy``: the template modifier is already long-lived; here
      we additionally add an immediate ``policy.enacted`` flag delta so the
      rule takes effect this tick (not only at the modifier's start_tick).
    - ``mobilize_faction``: relationship_changes between the actor and every
      ``target_id`` (faction rallied) + stashed ``_opposition_refs`` (faction
      opposed) — trust up with rallied, conflict up with opposed.
    """
    if decision_type == "launch_project":
        # completion-time output delivery (path dependence: the project's
        # output lands when it finishes, not when it starts).
        due = proposal.proposed_tick + max(1, proposal.expected_duration)
        effects.scheduled_effects.append(ScheduledEffect(
            source_id=f"{proposal.actor_id}:launch_project_output:"
                      f"{proposal.proposed_tick}",
            due_tick=due,
            effect={
                "op": "add",
                "path": f"actors.{proposal.actor_id}.project_output",
                "value": float(exec_ratio) * 10.0,
            },
        ))
    elif decision_type == "establish_policy":
        # the policy is enacted immediately (flag), the modifier carries its
        # long-lived effect.
        effects.immediate_deltas[
            f"policy.{proposal.actor_id}.enacted"
        ] = float(exec_ratio)
    elif decision_type == "mobilize_faction":
        opp_refs = list(getattr(proposal, "_opposition_refs", []) or [])
        for tid in proposal.target_ids:
            effects.relationship_changes.append({
                "from": proposal.actor_id,
                "to": tid,
                "trust_delta": 0.15 * float(exec_ratio),
                "conflict_delta": -0.05 * float(exec_ratio),
                "reason": f"mobilized alongside {proposal.actor_id}",
            })
        for opp_id in opp_refs:
            effects.relationship_changes.append({
                "from": proposal.actor_id,
                "to": opp_id,
                "trust_delta": -0.2 * float(exec_ratio),
                "conflict_delta": 0.25 * float(exec_ratio),
                "reason": f"mobilized against {opp_id}",
            })
    return effects


# ---------------------------------------------------------------------------
# CommitmentExecutor — per-tick progress / trigger / expire
# ---------------------------------------------------------------------------


@dataclass
class TickEffects:
    """Structured record of one executor tick's effects on the world."""

    tick: int = 0
    progressed_commitments: List[str] = field(default_factory=list)
    completed_commitments: List[str] = field(default_factory=list)
    failed_commitments: List[str] = field(default_factory=list)
    blocked_commitments: List[str] = field(default_factory=list)
    abandoned_commitments: List[str] = field(default_factory=list)
    triggered_effects: List[Dict[str, Any]] = field(default_factory=list)
    cancelled_effects: List[Dict[str, Any]] = field(default_factory=list)
    applied_modifiers: List[str] = field(default_factory=list)
    expired_modifiers: List[str] = field(default_factory=list)
    immediate_deltas: Dict[str, float] = field(default_factory=dict)
    resource_transfers: List[Dict[str, Any]] = field(default_factory=list)
    relationship_changes: List[Dict[str, Any]] = field(default_factory=list)
    spawned_commitments: List[str] = field(default_factory=list)
    observable_events: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tick": self.tick,
            "progressed_commitments": list(self.progressed_commitments),
            "completed_commitments": list(self.completed_commitments),
            "failed_commitments": list(self.failed_commitments),
            "blocked_commitments": list(self.blocked_commitments),
            "abandoned_commitments": list(self.abandoned_commitments),
            "triggered_effects": list(self.triggered_effects),
            "cancelled_effects": list(self.cancelled_effects),
            "applied_modifiers": list(self.applied_modifiers),
            "expired_modifiers": list(self.expired_modifiers),
            "immediate_deltas": dict(self.immediate_deltas),
            "resource_transfers": list(self.resource_transfers),
            "relationship_changes": list(self.relationship_changes),
            "spawned_commitments": list(self.spawned_commitments),
            "observable_events": list(self.observable_events),
        }


class CommitmentExecutor:
    """Advances active commitments one tick (spec § Phase 6/7/8).

    The executor is the *only* thing that moves an ``active`` commitment
    forward.  Each tick it:

    1. **Progresses** active commitments — ``progress += step`` where
       ``step = execution_ratio / expected_duration`` (so a fully-resourced
       commitment completes in ``expected_duration`` ticks; an
       under-resourced one runs proportionally slower and may stall).
    2. **Triggers** due :class:`ScheduledEffect` objects whose condition
       holds and cancel-conditions do not.
    3. **Applies** :class:`WorldModifier` objects at their start tick and
       **reverts** them at their end tick.
    4. **Emits observable events** — one per progressed commitment,
       gated by the commitment's ``secrecy`` (secret commitments leak
       partial / noisy events; the ObservationFilter does the actual
       per-subject projection downstream).
    5. **Resolves terminals** — ``completed`` / ``failed`` / ``abandoned``.

    The executor never mutates the world kernel; it returns a
    :class:`TickEffects` record the dispatcher's single write point
    settles (§12 red line).
    """

    def __init__(self) -> None:
        # Per-world registries the dispatcher installs.
        self.commitments: Dict[str, Commitment] = {}
        self.scheduled_effects: List[ScheduledEffect] = []
        self.world_modifiers: List[WorldModifier] = []

    # -- registration ------------------------------------------------------

    def register_commitment(self, commitment: Commitment) -> None:
        self.commitments[commitment.commitment_id] = commitment

    def register_scheduled_effect(self, effect: ScheduledEffect) -> None:
        self.scheduled_effects.append(effect)

    def register_world_modifier(self, modifier: WorldModifier) -> None:
        self.world_modifiers.append(modifier)

    # -- per-tick advance --------------------------------------------------

    def tick_commitments(
        self,
        world_state: Dict[str, Any],
        current_tick: int,
        *,
        seed: Optional[int] = None,
    ) -> TickEffects:
        """Advance every active commitment + due effect + modifier one tick."""
        record = TickEffects(tick=current_tick)

        # 1. advance active commitments
        for cid, c in list(self.commitments.items()):
            if c.is_terminal:
                continue
            if c.status == CommitmentStatus.ACTIVE:
                self._advance_active(c, current_tick, world_state, record)
            elif c.status == CommitmentStatus.BLOCKED:
                # a blocked commitment may auto-resume if its resource
                # gap has closed (resources were since allocated)
                if c.resource_gap <= 0.0:
                    transition_commitment(
                        c, CommitmentStatus.ACTIVE,
                        reason="unblocked: resource gap closed")
                    self._advance_active(c, current_tick, world_state, record)
                else:
                    record.blocked_commitments.append(cid)

        # 2. scheduled effects
        for eff in list(self.scheduled_effects):
            if eff.should_cancel(world_state, current_tick):
                record.cancelled_effects.append(eff.to_dict())
                continue
            if eff.should_fire(world_state, current_tick):
                eff.triggered = True
                self._apply_effect(eff, world_state, current_tick, record)
                record.triggered_effects.append(eff.to_dict())

        # 3. world modifiers (apply at start, revert at end)
        for mod in list(self.world_modifiers):
            if not mod.applied and current_tick >= mod.start_tick:
                self._apply_modifier(mod, world_state, current_tick, record)
            if mod.applied and mod.end_tick > 0 and current_tick > mod.end_tick:
                self._revert_modifier(mod, world_state, current_tick, record)

        return record

    # -- internals ---------------------------------------------------------

    def _advance_active(self, commitment: Commitment, current_tick: int,
                        world_state: Dict[str, Any],
                        record: TickEffects) -> None:
        """Advance one active commitment's progress toward completion."""
        commitment.last_tick = current_tick
        if commitment.spawned_tick is None:
            commitment.spawned_tick = current_tick

        # execution_ratio from the resolver is stashed on the commitment
        # as a private attr by the dispatcher when the commitment was
        # authorised.  Default 1.0 (fully resourced) when unset.
        exec_ratio = float(getattr(commitment, "_execution_ratio", 1.0))
        exec_ratio = max(0.0, min(1.0, exec_ratio))

        # resource shortfall slows execution: effective step is scaled by
        # the ratio of allocated to required (1.0 when fully allocated).
        req = sum(float(v) for v in commitment.required_resources.values()) or 1.0
        got = sum(float(v) for v in commitment.allocated_resources.values())
        res_ratio = max(0.0, min(1.0, got / req)) if req > 0 else 1.0

        step = (exec_ratio * res_ratio) / max(1, commitment.expected_duration)
        commitment.progress = max(0.0, min(1.0, commitment.progress + step))
        commitment.history.append({
            "event": "progress",
            "tick": current_tick,
            "step": step,
            "progress": commitment.progress,
            "exec_ratio": exec_ratio,
            "res_ratio": res_ratio,
        })
        record.progressed_commitments.append(commitment.commitment_id)

        # observable event (secrecy-gated broadcast flag)
        record.observable_events.append(self._observable_event(
            commitment, current_tick, kind="progress"))

        if commitment.progress >= 1.0:
            transition_commitment(
                commitment, CommitmentStatus.COMPLETED,
                reason="progress reached 1.0")
            record.completed_commitments.append(commitment.commitment_id)
            record.observable_events.append(self._observable_event(
                commitment, current_tick, kind="completed"))
        elif step <= 0.0:
            # no forward motion this tick → block
            transition_commitment(
                commitment, CommitmentStatus.BLOCKED,
                reason="zero execution step (no resources / no capability)")
            record.blocked_commitments.append(commitment.commitment_id)

    def _observable_event(self, commitment: Commitment, current_tick: int,
                          *, kind: str) -> Dict[str, Any]:
        """Build a broadcastable event for a commitment transition.

        ``visibility`` ∈ [0, 1] = 1 − secrecy.  The ObservationFilter
        downstream decides per-subject what each agent actually sees;
        here we only tag how public the event is.
        """
        return {
            "type": "commitment_event",
            "kind": kind,                        # progress / completed / ...
            "commitment_id": commitment.commitment_id,
            "actor_id": commitment.actor_id,
            "decision_type": commitment.decision_type,
            "tick": current_tick,
            "visibility": max(0.0, 1.0 - commitment.secrecy),
            "progress": commitment.progress,
            "status": commitment.status,
        }

    def _apply_effect(self, effect: ScheduledEffect,
                      world_state: Dict[str, Any], current_tick: int,
                      record: TickEffects) -> None:
        """Interpret a fired ScheduledEffect's ``effect`` dict.

        Supported shapes:
        - ``{"op": "set", "path": "a.b", "value": x}`` → immediate delta
        - ``{"op": "add", "path": "a.b", "value": dx}`` → add to state
        - ``{"op": "event", "name": "...", "payload": {...}}`` → observable
        - ``{"op": "spawn_commitment", "commitment": {...}}`` → register
          a new commitment (path dependence)
        """
        eff = effect.effect or {}
        op = str(eff.get("op", "event"))
        if op in ("set", "add"):
            path = str(eff.get("path", ""))
            val = eff.get("value", 0.0)
            if op == "add":
                try:
                    cur = _get_path(world_state, path)
                    val = (float(cur) if cur is not None else 0.0) + float(val)
                except (TypeError, ValueError):
                    val = float(val)
            _set_path(world_state, path, val)
            record.immediate_deltas[path] = float(val if op == "add"
                                                  else eff.get("value", 0.0))
        elif op == "event":
            record.observable_events.append({
                "type": "scheduled_event",
                "name": eff.get("name", ""),
                "source_id": effect.source_id,
                "payload": eff.get("payload", {}),
                "tick": current_tick,
            })
        elif op == "spawn_commitment":
            spec = eff.get("commitment") or {}
            if isinstance(spec, dict) and "commitment_id" in spec:
                child = Commitment(**{
                    k: v for k, v in spec.items()
                    if k in Commitment.__dataclass_fields__
                })
                self.register_commitment(child)
                record.spawned_commitments.append(child.commitment_id)
        elif op == "relationship":
            record.relationship_changes.append({
                "from": eff.get("from"),
                "to": eff.get("to"),
                "trust_delta": float(eff.get("trust_delta", 0.0)),
                "conflict_delta": float(eff.get("conflict_delta", 0.0)),
                "reason": eff.get("reason", ""),
            })
        elif op == "transfer":
            record.resource_transfers.append({
                "from": eff.get("from"),
                "to": eff.get("to"),
                "resource": eff.get("resource", ""),
                "amount": float(eff.get("amount", 0.0)),
            })

    def _apply_modifier(self, modifier: WorldModifier,
                        world_state: Dict[str, Any], current_tick: int,
                        record: TickEffects) -> None:
        """Apply a WorldModifier's start-tick changes to world_state."""
        for change in modifier.rule_modifiers:
            path = str(change.get("path", ""))
            op = str(change.get("op", "set"))
            val = change.get("value", 0.0)
            if op == "set":
                modifier._saved_prior[path] = _get_path(world_state, path)
                _set_path(world_state, path, val)
            elif op == "add":
                try:
                    cur = _get_path(world_state, path)
                    newv = (float(cur) if cur is not None else 0.0) + float(val)
                except (TypeError, ValueError):
                    newv = float(val)
                modifier._saved_prior[path] = _get_path(world_state, path)
                _set_path(world_state, path, newv)
        modifier.applied = True
        modifier.active = True
        modifier.history_event = {"event": "apply", "tick": current_tick}
        record.applied_modifiers.append(modifier.modifier_id)

    def _revert_modifier(self, modifier: WorldModifier,
                         world_state: Dict[str, Any], current_tick: int,
                         record: TickEffects) -> None:
        """Revert a WorldModifier's changes at its end tick."""
        for change in modifier.rule_modifiers:
            path = str(change.get("path", ""))
            op = str(change.get("op", "set"))
            prior = modifier._saved_prior.get(path)
            if op == "set":
                if prior is not None:
                    _set_path(world_state, path, prior)
                else:
                    _unset_path(world_state, path)
            elif op == "add":
                try:
                    cur = _get_path(world_state, path)
                    newv = (float(cur) if cur is not None else 0.0) - float(change.get("value", 0.0))
                    _set_path(world_state, path, newv)
                except (TypeError, ValueError):
                    pass
        modifier.active = False
        record.expired_modifiers.append(modifier.modifier_id)

    # -- inspection --------------------------------------------------------

    def active_commitments(self) -> List[Commitment]:
        return [c for c in self.commitments.values() if c.is_active]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "commitments": {cid: c.to_dict() for cid, c in self.commitments.items()},
            "scheduled_effects": [e.to_dict() for e in self.scheduled_effects],
            "world_modifiers": [m.to_dict() for m in self.world_modifiers],
        }


# ---------------------------------------------------------------------------
# Path helpers (dotted-path get/set on nested dicts) — stdlib only
# ---------------------------------------------------------------------------


def _get_path(state: Dict[str, Any], path: str) -> Any:
    if not path:
        return None
    cur: Any = state
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def _set_path(state: Dict[str, Any], path: str, value: Any) -> None:
    if not path:
        return
    parts = path.split(".")
    cur: Any = state
    for part in parts[:-1]:
        if not isinstance(cur.get(part), dict):
            cur[part] = {}
        cur = cur[part]
    cur[parts[-1]] = value


def _unset_path(state: Dict[str, Any], path: str) -> None:
    if not path:
        return
    parts = path.split(".")
    cur: Any = state
    for part in parts[:-1]:
        if not isinstance(cur, dict) or part not in cur:
            return
        cur = cur[part]
    if isinstance(cur, dict):
        cur.pop(parts[-1], None)
