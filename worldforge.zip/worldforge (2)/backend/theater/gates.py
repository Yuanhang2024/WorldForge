from typing import Iterable, List, Optional

from .models import CharacterPatch, SceneObjectEntry, ScienceApproval, WorldBookPatch


# verbs that attempt to destroy/break an object
_BREAK_VERBS = {"break", "smash", "destroy", "砸", "打烂", "击碎", "破坏", "劈碎", "砸烂", "砸碎", "捣毁"}
# verbs that attempt to take/pick up an object
_TAKE_VERBS = {"take", "grab", "pick", "拿", "拾", "捡", "取", "抄起", "拿起", "抓起"}
# verbs that attempt to move/push an object
_MOVE_VERBS = {"push", "move", "shove", "推", "移动", "挪", "搬"}


class ScienceDirectorGate:
    director_id = "science_director"

    def validate_write(self, world_patches: Iterable[WorldBookPatch], character_patches: Iterable[CharacterPatch]) -> ScienceApproval:
        reasons: List[str] = []
        approved = True
        for patch in world_patches:
            if not patch.title.strip() or not patch.content.strip():
                approved = False
                reasons.append("worldbook patch requires title and content")
        for patch in character_patches:
            if not patch.character_id.strip() or not patch.name.strip() or not patch.summary.strip():
                approved = False
                reasons.append("character patch requires id, name, and summary")
            if patch.possessed:
                allowed_actions = patch.possession_limit.get("allowed_actions") if isinstance(patch.possession_limit, dict) else None
                if not patch.possessed_by or not patch.ai_subconscious.strip() or not allowed_actions:
                    approved = False
                    reasons.append("possession patch requires suppression, possessor, and allowed actions")
        if approved:
            reasons.append("write constrained to verified worldbook and character schemas")
        return ScienceApproval(approved=approved, director_id=self.director_id, reasons=reasons)

    def validate_interaction(self, verb: str, target: Optional[SceneObjectEntry], actor_strength: int = 1) -> dict:
        """Arbitrate 'can this action affect this object, and what happens?'

        Runs the SchemaOK → PermOK → RuleOK triad (the Orchestrated-Reality
        pattern). Returns {approved, reasons, outcome} where outcome is a
        structured state delta (Story2Game's 4 effect kinds: set_state / remove
        / create / none). Cheap deterministic rules — no LLM on this path; the
        LLM only proposes the verb/target, the gate rules the physics.
        """
        reasons: List[str] = []
        v = (verb or "").strip().lower()

        # SchemaOK: the target must exist to be acted on
        if target is None:
            return {"approved": False, "reasons": ["no such object"], "outcome": {"type": "none"}}

        is_break = any(w in v for w in _BREAK_VERBS)
        is_take = any(w in v for w in _TAKE_VERBS)
        is_move = any(w in v for w in _MOVE_VERBS)

        # PermOK: the verb must be an affordance the object accepts (or a known verb)
        if not (is_break or is_take or is_move) and v not in [a.lower() for a in target.affordances]:
            reasons.append(f"'{verb}' is not an affordance of {target.name}")
            return {"approved": True, "reasons": reasons, "outcome": {"type": "none"}}

        # RuleOK: the world rules must actually permit the mutation
        if is_break:
            if not target.is_destructible:
                reasons.append(f"{target.name} is indestructible ({target.material})")
                return {"approved": False, "reasons": reasons, "outcome": {"type": "none"}}
            # stronger material / lower actor strength resist; durability gates it
            resist = _MATERIAL_RESIST.get(target.material, 1)
            if actor_strength * 2 < target.durability * resist:
                reasons.append(f"{target.name} withstands the blow (durability {target.durability}, {target.material})")
                return {"approved": True, "reasons": reasons,
                        "outcome": {"type": "set_state", "object_id": target.object_id, "state": "damaged"}}
            reasons.append(f"{target.name} is destroyed")
            return {"approved": True, "reasons": reasons,
                    "outcome": {"type": "set_state", "object_id": target.object_id, "state": "broken", "spawn_debris": True}}

        if is_take:
            if not target.is_takeable:
                reasons.append(f"{target.name} cannot be taken")
                return {"approved": False, "reasons": reasons, "outcome": {"type": "none"}}
            reasons.append(f"{target.name} is taken")
            return {"approved": True, "reasons": reasons,
                    "outcome": {"type": "set_state", "object_id": target.object_id, "state": "taken"}}

        if is_move:
            if not target.is_movable:
                reasons.append(f"{target.name} won't budge")
                return {"approved": False, "reasons": reasons, "outcome": {"type": "none"}}
            reasons.append(f"{target.name} is moved")
            return {"approved": True, "reasons": reasons, "outcome": {"type": "none"}}

        reasons.append(f"{verb} on {target.name} acknowledged")
        return {"approved": True, "reasons": reasons, "outcome": {"type": "none"}}


# material resistance multiplier for break resolution
_MATERIAL_RESIST = {"wood": 1, "glass": 1, "cloth": 1, "stone": 3, "metal": 4, "iron": 4}

