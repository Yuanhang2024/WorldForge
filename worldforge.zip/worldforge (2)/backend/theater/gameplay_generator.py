"""LLM-driven out-of-library gameplay generator (spec §9.2 库外玩法).

An LLM may author — **offline only** — a rules JSON describing new gameplay.
Parameterized library kernels are available only by an explicit ``kernel_id``;
the generator never infers one from world prose or genre keywords. Ordinary
generation requires an LLM; there is no offline fallback. The
:class:`GameplayGenerator` orchestrates this path:

  1. LLM emits a :class:`GameplaySpec` JSON (restricted DSL, deterministic).
  2. :class:`GameplayValidator.validate_all` runs the four hard gates.
  3. On failure → ``_repair``: feed the failure reasons back to the LLM and
     ask it to rewrite (up to 2 rounds).
  4. Still failing → raise ``RuntimeError`` (fail hard; never silently degrade).

No ``eval``, no ``exec``, no ``__import__`` — the LLM only emits declarative
JSON over the §8 AST whitelist subset (§12.1 安全红线).

Pure stdlib; no external deps; unit-testable with stub ``llm_fn``.
"""

from __future__ import annotations

import json
import re
from typing import Any, Callable, Dict, List, Optional, Tuple

from .gameplay_validator import GameplaySpec, GameplayValidator, ValidationReport


__all__ = ["GameplayGenerator", "GenerationResult"]


# ---------------------------------------------------------------------------
# LLM system prompt
# ---------------------------------------------------------------------------


_SYSTEM_PROMPT = """You are a gameplay rule compiler for a deterministic game engine.

Your output is a single JSON object — no prose, no markdown fences, no commentary.

ROLE (spec §9.2 库外玩法, LLM 立法 offline only):
  You define the SHAPE of a new game's rules (state, legal actions, terminal,
  payoff, apply).  You NEVER decide results.  A deterministic engine applies
  your rules; you do not narrate outcomes.  Your rules must be SAFE and
  TERMINATING.

OUTPUT (a single JSON object with these keys):
{
  "name": "snake_case_identifier",
  "description": "one-line human summary",
  "state_schema": {"dotted.path": <initial value>, ...},
  "legal_actions": [
     {"id": "action_id", "condition": <AST or null>, "description": "..."},
     ...
  ],
  "terminal": <AST → bool>,
  "payoff": <AST → number>  OR  {"p1": <AST>, "p2": <AST>},
  "apply": {
     "action_id": {"set": "dotted.path", "value": <AST>}
              OR  {"writes": [{"path": "...", "value": <AST>}, ...]},
     ...
  },
  "parameters": {"max_turns": 50, ...}
}

EXPRESSION AST — op WHITELIST ONLY:
  add, sub, mul, div, neg, min, max, clamp,
  lt, gt, eq, le, ge,
  and, or, not,
  if,
  sum, avg
  Leaves: {"const": <number|bool>}  or  {"ref": "dotted.path"}

HARD RULES:
  1. Output ONLY the JSON object.
  2. Every AST must use ONLY whitelisted ops.  No eval/exec/import/lambdas.
  3. legal_actions MUST be non-empty for every non-terminal state.
  4. The game MUST terminate within ~50 steps from the initial state —
     include a "turn" counter in state_schema that increments every action
     and a terminal predicate like {"op":"gt","args":[{"ref":"turn"},{"const":50}]}.
  5. No dominant pure strategy — the game must be winnable by both the
     first-action and the last-action strategy; avoid trivial "always wins"
     rules.
  6. No deadlock — every non-terminal state must have at least one action
     that makes progress toward terminal.
  7. Use incrementing "turn" counters and bounded resources so termination
     is structurally guaranteed, not just empirically observed.
"""


# ---------------------------------------------------------------------------
# GenerationResult
# ---------------------------------------------------------------------------


class GenerationResult:
    """Bundle returned by :meth:`GameplayGenerator.generate`.

    Attributes:
        spec:         the final GameplaySpec (LLM-authored if it passed
                      validation, or an explicitly selected parameterized
                      kernel spec).
        source:       ``"llm"`` for an accepted LLM spec or ``"kernel"`` for
                      an explicitly selected library kernel.
        validation:   the final :class:`ValidationReport` (LLM path) or None
                      (kernel path).
        repairs:      number of repair rounds run (0 if first-pass LLM ok).
        llm_messages:  diagnostics from the LLM client (optional).
    """

    def __init__(
        self,
        spec: GameplaySpec,
        source: str,
        validation: Optional[ValidationReport] = None,
        repairs: int = 0,
        llm_messages: Optional[List[str]] = None,
    ) -> None:
        self.spec = spec
        self.source = source
        self.validation = validation
        self.repairs = repairs
        self.llm_messages = list(llm_messages or [])

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": True,
            "spec": self.spec.to_dict(),
            "source": self.source,
            "validation": self.validation.to_dict() if self.validation else None,
            "repairs": self.repairs,
            "llm_messages": self.llm_messages,
        }


# ---------------------------------------------------------------------------
# GameplayGenerator
# ---------------------------------------------------------------------------


class GameplayGenerator:
    """Generate a validated GameplaySpec for an out-of-library gameplay.

    Parameters:
        max_repairs:  max number of repair rounds (default 2).
        seed:         validator seed for deterministic simulations.
        model_label:  human-readable LLM label (diagnostics only).
    """

    def __init__(
        self,
        *,
        max_repairs: int = 2,
        seed: int = 42,
        model_label: str = "gameplay-llm",
    ) -> None:
        self._max_repairs = max_repairs
        self._validator = GameplayValidator(seed=seed)
        self._model_label = model_label

    # -- main entry ---------------------------------------------------------

    def generate(
        self,
        description: str,
        world_style: Optional[str] = None,
        llm_fn: Optional[Callable[[str], str]] = None,
        kernel_id: Optional[str] = None,
    ) -> Tuple[GameplaySpec, GenerationResult]:
        """Generate a GameplaySpec.

        If *llm_fn* is provided, it is called as ``llm_fn(prompt) -> str``
        (single-arg; the system prompt is folded into *prompt*).  The raw
        output is parsed as JSON, validated, and (if invalid) repaired up to
        ``max_repairs`` rounds.  Still-invalid → raises ``RuntimeError``.

        If *llm_fn* is None and *kernel_id* names a registered parameterized
        kernel, that kernel is selected explicitly. Without either input,
        generation fails. ``description`` and ``world_style`` are never used
        to select a built-in kernel.

        Returns ``(spec, result)`` where ``result.source`` is ``"llm"`` or
        ``"kernel"``.
        """
        description = (description or "").strip()
        if llm_fn is None:
            if kernel_id:
                return self._from_kernel(kernel_id)
            raise RuntimeError(
                "GameplayGenerator requires llm_fn for ordinary generation; "
                "no fallback is available. Pass an explicit kernel_id only "
                "when intentionally selecting a library adapter."
            )

        user_prompt = self._build_user_prompt(description, world_style)
        repairs = 0
        feedback: List[str] = []
        last_spec: Optional[GameplaySpec] = None
        last_report: Optional[ValidationReport] = None

        for attempt in range(self._max_repairs + 1):
            raw = llm_fn(f"{_SYSTEM_PROMPT}\n\n{user_prompt}")
            spec = self._parse_llm_output(raw)
            if spec is None:
                feedback.append(f"round {attempt}: LLM output not parseable as GameplaySpec JSON")
                # Build a repair prompt and retry.
                user_prompt = self._build_repair_prompt(description, world_style, feedback)
                repairs += 1
                continue
            last_spec = spec
            report = self._validator.validate_all(spec)
            last_report = report
            if report.passed:
                result = GenerationResult(
                    spec=spec,
                    source="llm",
                    validation=report,
                    repairs=repairs,
                )
                return spec, result
            feedback.append(f"round {attempt}: validation failed — " + "; ".join(report.reasons))
            if attempt < self._max_repairs:
                user_prompt = self._build_repair_prompt(description, world_style, feedback)
                repairs += 1

        # LLM path exhausted → raise (fail hard, never silently degrade).
        msg = (
            f"LLM gameplay generation failed after {repairs} repair(s) "
            f"for description={description!r}"
        )
        if last_report:
            msg += f"; last validation reasons: {last_report.reasons}"
        raise RuntimeError(msg)

    # -- prompt building ----------------------------------------------------

    def _build_user_prompt(self, description: str, world_style: Optional[str]) -> str:
        style_line = f"\nWorld style: {world_style}\n" if world_style else ""
        return (
            f"Generate the gameplay rule JSON for this request:{style_line}\n"
            f"{description}\n\n"
            "Return ONLY the JSON object as specified in the system prompt. "
            "Ensure termination, legal actions, no deadlock, no dominant strategy."
        )

    def _build_repair_prompt(
        self, description: str, world_style: Optional[str], feedback: List[str]
    ) -> str:
        style_line = f"\nWorld style: {world_style}\n" if world_style else ""
        feedback_block = "\n".join(f"- {f}" for f in feedback)
        return (
            f"Your previous gameplay rule JSON failed validation.  Please rewrite it."
            f"{style_line}\n"
            f"Original request:\n{description}\n\n"
            f"Validation failures:\n{feedback_block}\n\n"
            "Rewrite the FULL GameplaySpec JSON fixing these issues.  "
            "Add a 'turn' counter and a terminal predicate that bounds the game "
            "to ≤50 turns if not already present.  Return ONLY the JSON object."
        )

    # -- LLM output parsing -------------------------------------------------

    def _parse_llm_output(self, raw: str) -> Optional[GameplaySpec]:
        """Parse raw LLM text into a GameplaySpec.  Tolerant of code fences."""
        text = (raw or "").strip()
        if not text:
            return None
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```\s*$", "", text)
        obj: Any = None
        try:
            obj = json.loads(text)
        except json.JSONDecodeError:
            start = text.find("{")
            end = text.rfind("}")
            if start == -1 or end == -1 or end <= start:
                return None
            try:
                obj = json.loads(text[start: end + 1])
            except json.JSONDecodeError:
                return None
        if not isinstance(obj, dict):
            return None
        if "name" not in obj or not isinstance(obj["name"], str):
            return None
        return GameplaySpec.from_dict(obj)

    # -- parameterized kernel path (no LLM) -----------------------------------

    def _from_kernel(
        self, kernel_id: str,
    ) -> Tuple[GameplaySpec, GenerationResult]:
        """Select a parameterized kernel by an explicit registry identifier."""
        spec = _kernel_spec_for(kernel_id)
        result = GenerationResult(
            spec=spec,
            source="kernel",
            validation=None,
            repairs=0,
        )
        return spec, result

# ---------------------------------------------------------------------------
# Parameterized kernel: mirror as a GameplaySpec.
# ---------------------------------------------------------------------------


def match_kernel_safe(description: str) -> str:
    """Explicit compatibility helper for callers opting into old heuristics.

    The generic generator does not call this function. It remains only for
    tools/tests that deliberately request heuristic library search.
    """
    try:
        from .game_kernels import match_kernel
        return match_kernel(description or "")
    except Exception:
        return ""


def _kernel_spec_for(kernel_name: str) -> GameplaySpec:
    """Return a trivial-but-validation-safe GameplaySpec mirroring *kernel_name*.

    The spec is NOT a faithful reimplementation of the kernel — it is a
    *minimal, validator-safe* spec that captures the kernel's surface shape
    (a turn-bounded game with a single legal action that increments the turn
    counter and terminates at max_turns).  Real execution falls through to
    the parameterized kernel itself; this spec only needs to pass the four
    gates.
    """
    from .game_kernels import KERNEL_REGISTRY

    name = str(kernel_name or "").strip()
    if name not in KERNEL_REGISTRY:
        raise ValueError(
            f"unknown kernel_id {name!r}; expected one of "
            f"{', '.join(sorted(KERNEL_REGISTRY))}"
        )
    max_turns = 20
    return GameplaySpec(
        name=f"kernel_{name}",
        description=f"Kernel spec mirroring parameterized kernel '{name}'.",
        state_schema={
            "turn": 0,
            "score": 0,
        },
        legal_actions=[
            {"id": "advance", "condition": None},
        ],
        # terminal when turn >= max_turns
        terminal={"op": "ge", "args": [{"ref": "turn"}, {"const": max_turns}]},
        payoff={"op": "ref", "path": "score"},
        parameters={"max_turns": max_turns, "source_kernel": name},
        apply={
            "advance": {
                "writes": [
                    {"path": "turn",
                     "value": {"op": "add",
                               "args": [{"ref": "turn"}, {"const": 1}]}},
                    {"path": "score",
                     "value": {"op": "add",
                               "args": [{"ref": "score"}, {"const": 1}]}},
                ]
            }
        },
    )
