"""Runtime self-consistency promotion: crystallise recurring LLM adjudications.

Spec ``docs/runtime_world_kernel_design.md`` §1.4 + §3: when the same state
path keeps triggering LLM semantic adjudication (the "fourth-class" writes
that pass deterministic checks but require semantic review), treat it as a
*recurring mechanism* rather than a one-off fact.  Promote it into a
deterministic kernel rule so the LLM stops adjudicating that path.

Two pieces:

  * :class:`AdjudicationTracker` — counts per-path adjudications; flags
    paths that crossed the recurrence threshold.
  * :class:`RulePromoter`        — scans the tracker, asks the LLM for a
    deterministic rule, validates it via :class:`RuleCompiler`,
    and appends it to a :class:`WorldKernelHost` via ``add_rule`` (which
    is itself append-only — overwrites are rejected by the host).

Self-consistency guarantees (per §3.2):

  a) **No overwrite**: ``add_rule`` rejects duplicate rule_ids.
  b) **No contradiction**: ``RuleCompiler.validate_spec`` runs on the union
     of existing rules + the new one; any failure rejects the promotion.
  c) **No orphan DAG targets**: rules with DAG prerequisites are skipped
     from promotion (the host's RuleEngine already enforces reachability
     on the optional ``dag`` passed to the engine — see ``rule_engine.py``).
  d) **Reset on success**: after a successful promotion the tracker
     clears the path so the same adjudication won't immediately retrigger.

Pure stdlib Python; unit-testable in isolation. No LLM is required at import
time, but every promotion attempt requires ``llm_fn`` and fails without
installing anything if model generation or validation fails.
"""

from __future__ import annotations

import copy
from collections import defaultdict
from typing import Any, Callable, Dict, List, Optional

from .rule_generator import RuleGenerator
from .world_kernel_host import (
    DSLError,
    RuleCompiler,
    WorldKernelHost,
    WorldRule,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Default recurrence threshold — match design doc §1.4 ("N 次窗口内反复").
DEFAULT_THRESHOLD: int = 3

#: Max promotions per :meth:`RulePromoter.check_and_promote` call — bounds
#: any one pass (one promotion already grows the rule set; spam-promotion
#: would erode the "make sure it really recurs" gate).
MAX_PROMOTIONS_PER_PASS: int = 1

#: Suffix appended to generated rule_ids to keep them unique across passes.
RULE_ID_SUFFIX: str = "_promoted"


# ---------------------------------------------------------------------------
# AdjudicationTracker
# ---------------------------------------------------------------------------


class AdjudicationTracker:
    """Count LLM adjudications per state path and flag recurrences.

    The tracker is **stateful** but trivially serialisable: a ``counts``
    dict keyed by dotted state path.  Two paths with the same prefix are
    counted independently (e.g. ``"temporal.paradox"`` and
    ``"narrative.continuity"`` are separate recurrences).

    Public surface:
        - :meth:`record`           — increment counter for *path*.
        - :meth:`count`            — current counter (default 0).
        - :meth:`is_recurring`     — ``count >= threshold``.
        - :meth:`recurrent_paths`  — every path that crossed the threshold.
        - :meth:`reset`            — clear a path (called after promotion).
    """

    def __init__(self, *, default_threshold: int = DEFAULT_THRESHOLD) -> None:
        self._counts: Dict[str, int] = defaultdict(int)
        self._threshold = int(default_threshold)

    # -- public API ---------------------------------------------------------

    def record(self, path: str) -> None:
        """Increment the counter for *path*.

        *path* is normalised to ``str``; empty / non-string values are
        ignored (defensive — RuleEngine itself filters empty paths).
        """
        if not isinstance(path, str) or not path:
            return
        self._counts[path] += 1

    def count(self, path: str) -> int:
        """Current counter for *path* (0 if never recorded)."""
        if not isinstance(path, str):
            return 0
        return int(self._counts.get(path, 0))

    def is_recurring(self, path: str, threshold: Optional[int] = None) -> bool:
        """``True`` iff *path* has been recorded >= *threshold* times.

        *threshold* defaults to the tracker's configured value
        (:data:`DEFAULT_THRESHOLD`).
        """
        if not isinstance(path, str):
            return False
        cutoff = self._threshold if threshold is None else int(threshold)
        return self.count(path) >= cutoff

    def recurrent_paths(self, threshold: Optional[int] = None) -> List[str]:
        """List of paths currently at/above the recurrence cutoff.

        Order is insertion order of the underlying ``defaultdict`` (Python
        3.7+ guarantee).  Tests rely on this for determinism.
        """
        cutoff = self._threshold if threshold is None else int(threshold)
        return [p for p, n in self._counts.items() if n >= cutoff]

    def reset(self, path: str) -> None:
        """Zero out the counter for *path*.  No-op if absent.

        Called by :meth:`RulePromoter.check_and_promote` after a successful
        promotion — the path is now governed by a deterministic rule, so
        future adjudications on it should not retrigger promotion.
        """
        if not isinstance(path, str):
            return
        self._counts.pop(path, None)

    def reset_all(self) -> None:
        """Wipe every counter (mostly for tests + diagnostics)."""
        self._counts.clear()

    def snapshot(self) -> Dict[str, int]:
        """Read-only copy of every counter (for diagnostics / tests)."""
        return dict(self._counts)


# ---------------------------------------------------------------------------
# RulePromoter
# ---------------------------------------------------------------------------


#: Signature of the optional LLM callback.  Matches ``RuleGenerator.generate``:
#: ``llm_fn(prompt) -> raw_text`` (single-arg; system prompt folded in by the
#: generator).
LLMFn = Callable[[str], str]


class RulePromoter:
    """Promote recurring LLM adjudications into deterministic kernel rules.

    Lifecycle::

        tracker = AdjudicationTracker()
        promoter = RulePromoter(host, tracker)
        # ... every time rule_engine.needs_llm_adjudication fires:
        tracker.record(change_path)
        # ... periodically (e.g. between scenes / waves):
        promoter.check_and_promote()    # may add 0..1 rule

    Construction parameters:
        host:        :class:`WorldKernelHost` whose ruleset grows over time.
        tracker:     :class:`AdjudicationTracker` providing recurrence counts.
        generator:   Optional :class:`RuleGenerator`; built lazily if absent.
        llm_fn:      Optional ``llm_fn(prompt) -> str`` callback.
        threshold:   Override the recurrence threshold (default 3).

    Self-consistency guards (each is a precondition for ``host.add_rule``):
        * **No overwrite**        — host rejects duplicate rule_ids.
        * **No contradiction**    — compiler validates the union spec.
        * **No isolated target**  — rules referencing DAG prereqs whose
          nodes aren't already in the host's DAG are skipped (the host's
          ``RuleEngine`` would reject them at runtime).
    """

    def __init__(
        self,
        host: WorldKernelHost,
        tracker: AdjudicationTracker,
        *,
        generator: Optional[RuleGenerator] = None,
        llm_fn: Optional[LLMFn] = None,
        threshold: int = DEFAULT_THRESHOLD,
    ) -> None:
        self._host = host
        self._tracker = tracker
        self._generator = generator if generator is not None else RuleGenerator()
        self._llm_fn = llm_fn
        # Per-instance threshold — propagate to tracker for consistency.
        self._threshold = int(threshold)
        self._tracker._threshold = self._threshold  # type: ignore[attr-defined]

    # -- public API ---------------------------------------------------------

    def check_and_promote(self) -> Optional[WorldRule]:
        """Scan the tracker and try to promote at most one rule.

        Returns the newly installed :class:`WorldRule` (now visible in
        ``host.kernel().rule_ids()``) or ``None`` when there is nothing
        to do / the rule fails any self-consistency check.

        Promotion is bounded to one rule per call
        (:data:`MAX_PROMOTIONS_PER_PASS`) so a single tick cannot
        spam the rule set; callers may loop until ``None`` is returned.
        """
        for path in self._tracker.recurrent_paths(self._threshold):
            rule = self.promote_for_path(path)
            if rule is not None:
                return rule
        return None

    def promote_for_path(self, path: str) -> Optional[WorldRule]:
        """Ask the model to mint and install one deterministic rule for *path*.

        Steps:
          1. Ask the LLM to build a deterministic :class:`WorldRule` covering
             *path*.
          2. Validate the new rule via :class:`RuleCompiler.validate_rule`.
          3. Validate the union (existing rules + new) via
             :meth:`RuleCompiler.validate_spec`.
          4. Install via :meth:`WorldKernelHost.add_rule` (append-only;
             duplicate rule_ids are rejected by the host).
          5. Reset the tracker's counter for *path*.

        Returns the installed rule. Empty paths still return ``None``.
        Missing model access, generation failure, validation failure, or
        installation failure raises and leaves both the host and tracker
        unchanged.
        """
        if not isinstance(path, str) or not path:
            return None
        if self._llm_fn is None:
            raise RuntimeError(
                "RulePromoter requires llm_fn; rule promotion has no preset "
                "or deterministic fallback"
            )

        rule = self._mint_rule(path)
        if rule is None:
            raise RuntimeError(
                f"LLM did not generate a rule targeting recurring path {path!r}"
            )

        # Per-rule shape validation.
        rule_issues = RuleCompiler().validate_rule(rule)
        if rule_issues:
            raise ValueError(
                "promoted rule failed validation: " + "; ".join(rule_issues)
            )

        # Full-spec validation against the existing host ruleset (union).
        spec_issues = self._validate_against_host(rule)
        if spec_issues:
            raise ValueError(
                "promoted ruleset failed validation: " + "; ".join(spec_issues)
            )

        # Install via the host (append-only).  add_rule returns a list of
        # issues; empty = accepted.
        install_issues = self._host.add_rule(rule)
        if install_issues:
            raise ValueError(
                "promoted rule was not installed: " + "; ".join(install_issues)
            )

        # All gates passed — clear the recurrence counter for this path so
        # future adjudications don't immediately retrigger promotion.
        self._tracker.reset(path)
        return rule

    # -- internals ----------------------------------------------------------

    def _mint_rule(self, path: str) -> Optional[WorldRule]:
        """Build a deterministic :class:`WorldRule` for *path*.

        :class:`RuleGenerator` proposes a full spec and this method selects the
        rule targeting *path*. Model and parsing errors propagate; there is no
        rule template or path-name heuristic.
        """
        if self._llm_fn is None:
            raise RuntimeError("RulePromoter requires llm_fn")
        spec = self._generator.generate(
            world_description=f"Recurring LLM adjudication on path {path!r}",
            llm_fn=self._llm_fn,
        )
        chosen = next(
            (rule for rule in spec.rules if _rule_targets_path(rule, path)),
            None,
        )
        if chosen is None:
            return None

        # Give the rule a unique id — append a suffix + a counter so two
        # promotions on the same path across different worlds don't clash.
        base_id = str(chosen.rule_id or "promoted_rule").strip() or "promoted_rule"
        unique_id = _unique_rule_id(self._host, base_id)
        return _rewrite_rule_id(chosen, unique_id)

    def _validate_against_host(self, rule: WorldRule) -> List[str]:
        """Validate *rule* against the host's existing ruleset.

        We rebuild a union :class:`WorldKernelSpec` mirroring what the host
        does internally in ``add_rule`` and call
        :meth:`RuleCompiler.validate_spec`.  Returning the issues list
        lets the caller decide whether to install; we never raise here
        (so :meth:`promote_for_path` stays best-effort).
        """
        try:
            kernel = self._host.kernel()
            union_rules = list(kernel.rules) + [rule]
            # The union doesn't need initial_state / params for validation —
            # validate_spec only inspects rules.
            from .world_kernel_host import WorldKernelSpec
            union_spec = WorldKernelSpec(
                world_type=kernel.world_type,
                rules=union_rules,
            )
            return RuleCompiler().validate_spec(union_spec)
        except DSLError:
            return [f"validation raised DSLError for promoted rule"]
        except Exception:
            return [f"validation raised for promoted rule"]


# ---------------------------------------------------------------------------
# Helpers (module-level — pure functions, easy to test)
# ---------------------------------------------------------------------------


def _rule_targets_path(rule: WorldRule, path: str) -> bool:
    """True if *rule* writes or asserts something about *path*.

    Used to pick a relevant rule out of an LLM-generated spec.  We match
    on effect write paths and on predicate / condition ``ref`` leaves.
    """
    if not isinstance(rule, WorldRule):
        return False
    # Effect write paths.
    effect = rule.effect or {}
    for p in _extract_write_paths(effect):
        if p == path or p.startswith(path + ".") or path.startswith(p + "."):
            return True
    # Predicate references (invariant rules).
    expr = _extract_predicate_expr(effect)
    if expr is not None and _ast_mentions_path(expr, path):
        return True
    # Condition AST.
    if rule.condition is not None and _ast_mentions_path(rule.condition, path):
        return True
    return False


def _ast_mentions_path(node: Any, path: str) -> bool:
    """True if *node* (a whitelisted AST) contains a ``ref`` to *path*."""
    if isinstance(node, dict):
        # ``{"ref": "x.y"}`` shorthand.
        r = node.get("ref")
        if isinstance(r, str) and (r == path or r.startswith(path + ".")
                                   or path.startswith(r + ".")):
            return True
        # ``{"op":"ref","path":"x.y"}`` / ``{"op":"lookup",...}``
        op = node.get("op")
        if op in ("ref", "lookup"):
            p = node.get("path")
            if not isinstance(p, str):
                args = node.get("args") or []
                if args and isinstance(args[0], str):
                    p = args[0]
            if isinstance(p, str) and (p == path or p.startswith(path + ".")
                                       or path.startswith(p + ".")):
                return True
        for v in node.values():
            if _ast_mentions_path(v, path):
                return True
    elif isinstance(node, list):
        for v in node:
            if _ast_mentions_path(v, path):
                return True
    elif isinstance(node, str):
        # Bare-string ref shorthand.
        if node == path or node.startswith(path + ".") or path.startswith(node + "."):
            return True
    return False


def _extract_write_paths(effect: Any) -> List[str]:
    """Pull ``writes`` paths from an effect dict (legacy + flat shape)."""
    out: List[str] = []
    if not isinstance(effect, dict):
        return out
    if effect.get("op") == "writes":
        for c in effect.get("changes", []) or []:
            if isinstance(c, dict) and isinstance(c.get("path"), str):
                out.append(c["path"])
    w = effect.get("writes")
    if isinstance(w, str) and effect.get("op") in (None, "set", "add", "delete"):
        out.append(w)
    return out


def _extract_predicate_expr(effect: Any) -> Optional[Any]:
    """Return the predicate AST if *effect* is a predicate (any shape)."""
    if not isinstance(effect, dict):
        return None
    if effect.get("op") == "predicate":
        return effect.get("expr")
    if "predicate" in effect and effect.get("op") in (None, "predicate"):
        return effect.get("predicate")
    return None


def _unique_rule_id(host: WorldKernelHost, base: str) -> str:
    """Return a rule_id that isn't already in *host*.

    Appends the suffix + a numeric counter until the id is unique.  The
    counter is per-call (in-memory) so multiple promotions across the
    same session get distinct ids without coordination.
    """
    existing = {r.rule_id for r in host.kernel().rules}
    # Also account for runtime-added extras (the host keeps them in a
    # separate list but exposes the combined view through ``rules``).
    for extra in getattr(host, "_compiled_extra", []) or []:
        existing.add(extra.rule_id)
    candidate = f"{base}{RULE_ID_SUFFIX}"
    n = 1
    while candidate in existing:
        n += 1
        candidate = f"{base}{RULE_ID_SUFFIX}_{n}"
    return candidate


def _rewrite_rule_id(rule: WorldRule, new_id: str) -> WorldRule:
    """Return a deep copy of *rule* with ``rule_id`` replaced."""
    new = copy.deepcopy(rule)
    new.rule_id = new_id
    return new


# ---------------------------------------------------------------------------
# Module exports
# ---------------------------------------------------------------------------


__all__ = [
    "AdjudicationTracker",
    "RulePromoter",
    "DEFAULT_THRESHOLD",
    "MAX_PROMOTIONS_PER_PASS",
]
