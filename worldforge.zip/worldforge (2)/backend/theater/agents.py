import json
import urllib.error
import urllib.request
from typing import Any, Dict

from .settings import Settings


class ModelClient:
    def complete_json(self, role: str, prompt: str, model: str) -> Dict[str, Any]:
        raise NotImplementedError

    def complete_character_card(self, description: str, model: str) -> Dict[str, Any]:
        raise NotImplementedError


class ModelClientError(RuntimeError):
    """The configured runtime LLM is unavailable or returned invalid data."""


class DeterministicModelClient(ModelClient):
    """Explicit deterministic test/demo stub.

    Production wiring never selects this client automatically.  Tests and
    explicitly offline adapters may instantiate it directly.
    """

    def complete_json(self, role: str, prompt: str, model: str) -> Dict[str, Any]:
        request = prompt.split(
            "\n\n已持久化的当前世界上下文",
            1,
        )[0]
        lowered = request.lower()
        if "夺舍" in request or "possess" in lowered:
            intent = "possession"
        elif any(word in request for word in ["动作", "抬手", "指向", "移动", "姿态"]):
            intent = "action"
        elif any(word in request for word in ["场景", "生成", "档案馆", "雷雨", "背景"]):
            intent = "world_update"
        else:
            intent = "complex_story"
        return {
            "intent": intent,
            "brief": (request or "处理当前玩家请求").strip()[:200],
            "dialogue": "",
            "actor_id": "",
            "world_title": "当前世界",
            "world_content": (request or "等待进一步输入").strip()[:400],
            "character_summary": "",
            "warnings": ["explicit deterministic test/demo stub active"],
            "provider_model": model,
        }

    def complete_character_card(self, description: str, model: str) -> Dict[str, Any]:
        return {
            "name": "主要角色",
            "summary": (description or "用户尚未提供角色描述").strip()[:200],
            "personality": "未指定；由后续互动与用户输入逐步补充。",
            "appearance": "未指定。",
            "sample_line": "我会先了解当前情况，再决定下一步。",
            "warnings": ["explicit deterministic test/demo stub active"],
            "provider_model": model,
        }


class OpenAICompatibleClient(ModelClient):
    """Strict runtime client for an OpenAI-compatible provider.

    Disabled configuration, transport failures and malformed model output are
    hard errors.  Runtime semantics must come from the configured LLM, never
    from an automatically substituted deterministic response.
    """

    def __init__(self, settings: Settings):
        self.settings = settings

    def complete_json(self, role: str, prompt: str, model: str) -> Dict[str, Any]:
        agent = self.settings.agent_config(role)
        if not self.settings.agent_live_api_enabled(role):
            raise ModelClientError(
                f"LLM runtime is not enabled for role {role!r}; configure a "
                "provider, model and any provider-required API key."
            )

        provider_model = self.settings.provider_model_name(agent.model or model)
        url = f"{self.settings.agent_normalized_base_url(role)}/chat/completions"
        body = {
            "model": provider_model,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are 制片人导演, the backend director agent of an interactive theater. "
                        "You always reply with ONE compact JSON object and nothing else: no prose, no "
                        "markdown fence, no reasoning. The JSON must use exactly these keys: intent, brief, "
                        "dialogue, actor_id, world_title, world_content, character_summary, warnings. "
                        "dialogue is the character's optional text response "
                        "(empty string if no one responds). intent is one of "
                        "world_update/action/possession/complex_story. warnings is an array."
                    ),
                },
                {"role": "user", "content": "role=producer\n玩家请求：让当前世界响应这次输入。"},
                {
                    "role": "assistant",
                    "content": (
                        '{"intent":"complex_story","brief":"处理当前输入",'
                        '"dialogue":"","actor_id":"",'
                        '"world_title":"当前世界","world_content":"世界将依据规则响应输入。",'
                        '"character_summary":"","warnings":[]}'
                    ),
                },
                {"role": "user", "content": f"role={role}\n{prompt}"},
            ],
            "temperature": 0.4,
            "max_tokens": 1536 if role == "world_builder" else 1024,
            "stop": ["<|im_start|>", "<|im_end|>", "<|endoftext|>", "<|eot_id|>", "<|end|>"],
        }
        # JSON-schema constrained decoding keeps producer output valid instead
        # of drifting into reasoning or malformed output. world_builder writes
        # free-form narrative, so leave it unconstrained.
        if role != "world_builder":
            body["response_format"] = {
                "type": "json_schema",
                "json_schema": {"name": "director", "strict": True, "schema": self._director_schema()},
            }
        request = urllib.request.Request(
            url,
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={
                **self.settings.agent_auth_headers(role),
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request) as response:
                payload = json.loads(response.read().decode("utf-8"))
            message = payload.get("choices", [{}])[0].get("message", {})
            content = message.get("content") or message.get("reasoning_content")
            if not isinstance(content, str) or not content.strip():
                raise ModelClientError("LLM returned empty director content")
            result = self._parse_content(content)
            self._validate_director_payload(result)
            result["provider_model"] = provider_model
            return result
        except ModelClientError:
            raise
        except (
            urllib.error.URLError,
            OSError,
            UnicodeDecodeError,
            json.JSONDecodeError,
            KeyError,
            IndexError,
            AttributeError,
            TypeError,
            ValueError,
        ) as exc:
            raise ModelClientError(
                f"LLM request failed for role {role!r} using model "
                f"{provider_model!r}: {exc.__class__.__name__}: {exc}"
            ) from exc

    def complete_character_card(self, description: str, model: str) -> Dict[str, Any]:
        """Generate a structured character card from a free-text description.

        Reuses the world_builder agent config (the configured narrative model): it is the strongest
        local model for coherent Chinese, and card writing is a creative,
        reasoning-heavy task like world building. Failures are surfaced.
        """
        role = "world_builder"
        agent = self.settings.agent_config(role)
        if not self.settings.agent_live_api_enabled(role):
            raise ModelClientError(
                "LLM runtime is not enabled for character generation; "
                "configure a provider, model and any provider-required API key."
            )

        provider_model = self.settings.provider_model_name(agent.model or model)
        url = f"{self.settings.agent_normalized_base_url(role)}/chat/completions"
        body = {
            "model": provider_model,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "你是互动剧场的角色设计师。玩家给你一段自然语言的人物描述，"
                        "你把它扩写成一张结构化角色卡。只回复一个紧凑的 JSON 对象，"
                        "不要散文、不要 markdown 代码块、不要解释。JSON 必须且仅使用这些键："
                        "name(角色名), summary(一句话身份定位), personality(性格，2-3句), "
                        "appearance(纯文本叙事中的外貌与形象描述，2-3句), "
                        "sample_line(一句符合人设的代表台词), warnings(数组)。全部用中文。"
                    ),
                },
                {"role": "user", "content": "描述：一个负责协调公共事务、做事谨慎的角色。"},
                {
                    "role": "assistant",
                    "content": (
                        '{"name":"协调者","summary":"负责协调公共事务的角色",'
                        '"personality":"谨慎、耐心，倾向先收集信息再行动。",'
                        '"appearance":"外观由具体世界设定决定。",'
                        '"sample_line":"我先确认现状，再安排下一步。","warnings":[]}'
                    ),
                },
                {"role": "user", "content": f"描述：{description}"},
            ],
            "temperature": 0.7,
            "max_tokens": 1024,
            "stop": ["<|im_start|>", "<|im_end|>", "<|endoftext|>", "<|eot_id|>", "<|end|>"],
        }
        request = urllib.request.Request(
            url,
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={
                **self.settings.agent_auth_headers(role),
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request) as response:
                payload = json.loads(response.read().decode("utf-8"))
            message = payload.get("choices", [{}])[0].get("message", {})
            content = message.get("content") or message.get("reasoning_content")
            if not isinstance(content, str) or not content.strip():
                raise ModelClientError("LLM returned empty character-card content")
            parsed = self._parse_content(content)
            self._validate_character_card(parsed)
            parsed["provider_model"] = provider_model
            return parsed
        except ModelClientError:
            raise
        except (
            urllib.error.URLError,
            OSError,
            UnicodeDecodeError,
            json.JSONDecodeError,
            KeyError,
            IndexError,
            AttributeError,
            TypeError,
            ValueError,
        ) as exc:
            raise ModelClientError(
                "LLM character-card request failed using model "
                f"{provider_model!r}: {exc.__class__.__name__}: {exc}"
            ) from exc

    def _parse_content(self, content: str) -> Dict[str, Any]:
        stripped = content.strip()
        if stripped.startswith("```"):
            stripped = stripped.strip("`")
            if stripped.startswith("json"):
                stripped = stripped[4:].strip()
        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            parsed = json.loads(self._first_json_object(stripped))
        if not isinstance(parsed, dict):
            raise json.JSONDecodeError("director output is not a JSON object", stripped, 0)
        return parsed

    @staticmethod
    def _first_json_object(text: str) -> str:
        """Extract the first brace-balanced object, ignoring braces inside strings.

        Local small models sometimes continue past the first JSON and hallucinate
        extra chat turns, so rfind('}') would over-capture. Scan for the first
        complete object instead.
        """
        start = text.find("{")
        if start == -1:
            raise json.JSONDecodeError("no JSON object found", text, 0)
        depth = 0
        in_string = False
        escaped = False
        for index in range(start, len(text)):
            char = text[index]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    return text[start:index + 1]
        raise json.JSONDecodeError("unterminated JSON object", text, start)

    @staticmethod
    def _director_schema() -> Dict[str, Any]:
        """JSON schema for the producer/director output — constrains the small
        model to valid director JSON (all keys, intent enum)."""
        return {
            "type": "object",
            "properties": {
                "intent": {"type": "string", "enum": ["world_update", "action", "possession", "complex_story"]},
                "brief": {"type": "string"},
                "dialogue": {"type": "string"},
                "actor_id": {"type": "string"},
                "world_title": {"type": "string"},
                "world_content": {"type": "string"},
                "character_summary": {"type": "string"},
                "interaction": {
                    "type": "object",
                    "description": "optional: an action on a scene object (砸桌子/拿起道具)",
                    "properties": {
                        "verb": {"type": "string"},
                        "object_id": {"type": "string"},
                        "actor_strength": {"type": "integer"},
                    },
                },
                "warnings": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["intent", "brief", "dialogue", "actor_id"],
        }

    @staticmethod
    def _validate_director_payload(payload: Dict[str, Any]) -> None:
        allowed_intents = {
            "world_update", "action", "possession", "complex_story",
        }
        required_strings = ("intent", "brief", "dialogue", "actor_id")
        missing = [
            key for key in required_strings
            if key not in payload or not isinstance(payload[key], str)
        ]
        if missing:
            raise ModelClientError(
                "LLM director output is missing string fields: "
                + ", ".join(missing)
            )
        if payload["intent"] not in allowed_intents:
            raise ModelClientError(
                f"LLM director output has invalid intent: {payload['intent']!r}"
            )
        if not payload["brief"].strip():
            raise ModelClientError(
                "LLM director output field 'brief' must not be empty"
            )
        warnings = payload.get("warnings", [])
        if not isinstance(warnings, list) or not all(
            isinstance(item, str) for item in warnings
        ):
            raise ModelClientError(
                "LLM director output field 'warnings' must be an array of strings"
            )

    @staticmethod
    def _validate_character_card(payload: Dict[str, Any]) -> None:
        required_strings = (
            "name", "summary", "personality", "appearance", "sample_line",
        )
        missing = [
            key for key in required_strings
            if not isinstance(payload.get(key), str) or not payload[key].strip()
        ]
        if missing:
            raise ModelClientError(
                "LLM character-card output is missing non-empty string fields: "
                + ", ".join(missing)
            )
        warnings = payload.get("warnings", [])
        if not isinstance(warnings, list) or not all(
            isinstance(item, str) for item in warnings
        ):
            raise ModelClientError(
                "LLM character-card field 'warnings' must be an array of strings"
            )


class ProviderDiagnostics:
    def __init__(self, settings: Settings, urlopen=None):
        self.settings = settings
        self._urlopen = urlopen

    def _fetch_url(self, req):
        opener = self._urlopen or urllib.request.urlopen
        return opener(req)

    def fetch_models(self) -> Dict[str, Any]:
        """Fetch the provider model list. Returns {ok, models, error, base_url}."""
        base = {
            "ok": False,
            "base_url": self.settings.normalized_base_url,
            "models": [],
            "error": None,
        }
        if not self.settings.live_api_ready:
            base["error"] = (
                "live API disabled or provider credentials are incomplete"
            )
            return base
        req = urllib.request.Request(
            f"{self.settings.normalized_base_url}/models",
            headers=self.settings.auth_headers,
        )
        try:
            with self._fetch_url(req) as response:
                payload = json.loads(response.read().decode("utf-8"))
            models = sorted(item.get("id") for item in payload.get("data", []) if item.get("id"))
            base.update({"ok": True, "models": models})
        except urllib.error.HTTPError as exc:
            base["error"] = f"HTTP {exc.code}: {exc.reason}"
        except Exception as exc:
            base["error"] = f"{exc.__class__.__name__}: {exc}"
        return base

    def report(self, probe_chat: bool = False) -> Dict[str, Any]:
        base = {
            "base_url": self.settings.normalized_base_url,
            "model_fast": self.settings.model_fast,
            "model_deep": self.settings.model_deep,
            "provider_model_fast": self.settings.provider_model_fast,
            "provider_model_deep": self.settings.provider_model_deep,
            "live_api_enabled": self.settings.live_api_ready,
            "api_key": self.settings.masked_api_key,
            "models": [],
            "status": "disabled",
            "error": None,
            "chat_probe": {},
        }
        if not self.settings.live_api_ready:
            return base
        model_fetch = self.fetch_models()
        models = model_fetch.get("models") or []
        base.update(
            {
                "models": models,
                "status": "ok" if model_fetch["ok"] else "error",
                "error": model_fetch.get("error"),
                "supports_fast": self.settings.provider_model_fast in models,
                "supports_deep": self.settings.provider_model_deep in models,
            }
        )
        if probe_chat:
            base["chat_probe"] = {
                "fast": self._probe_chat(self.settings.provider_model_fast),
                "deep": self._probe_chat(self.settings.provider_model_deep),
            }
        return base

    def _probe_chat(self, model: str) -> Dict[str, Any]:
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": "Return OK."}],
            "temperature": 0,
        }
        req = urllib.request.Request(
            f"{self.settings.normalized_base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                **self.settings.auth_headers,
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with self._fetch_url(req) as response:
                body = json.loads(response.read().decode("utf-8"))
            return {"model": model, "status": "ok", "choices": len(body.get("choices") or [])}
        except urllib.error.HTTPError as exc:
            return {"model": model, "status": "error", "error": f"HTTP {exc.code}: {exc.reason}"}
        except Exception as exc:
            return {"model": model, "status": "error", "error": f"{exc.__class__.__name__}: {exc}"}
