"""WorldForge HTTP service.

The generic routes expose state, dispatch, onboarding, rules, GUI, gameplay,
save/load, and world ticks without selecting a worldview. Optional reference
adapters live behind explicit routes/parameters. In particular,
``/api/three_body/bake`` and ``/api/three_body/state`` expose the deterministic
Three-Body adapter; generic server startup does not import that kernel.
"""

from __future__ import annotations

import json
import threading
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Optional
from urllib.parse import parse_qs, urlparse

import numpy as np

from .dispatcher import TheaterOrchestrator
from .runtime import WorldClock
from .agents import ProviderDiagnostics
from .settings import Settings
from .gui_generator import compile_to_css
from .gui_theme import GuiTheme

if TYPE_CHECKING:
    from .kernels.three_body import ThreeBodyKernel


STATIC_DIR = Path(__file__).resolve().parents[2] / "web"
_active_server: Optional[ThreadingHTTPServer] = None

_FROM_SCRATCH_PROMPTS = {
    "world": "请从零生成一个原创世界，并自行决定其状态结构与规则方向。",
    "characters": "请从零生成适合当前世界的原创角色卡，并完整填写所有字段。",
    "rules_gui": "请从零生成当前世界的规则、初始状态和可操作 GUI。",
    "gameplay": "请从零生成玩法、合法行动、终止条件和状态转换。",
    "cognitive_model": "请从零生成与当前世界一致的认知与误判模型。",
}


def _style_lock_from_spec(spec: "GUISpec") -> Dict[str, Any]:
    """Project a GUISpec into the style_lock shape GuiTheme.deriveTheme expects.

    The spec stores role→ramp-index and chrome/motion. GuiTheme applies the
    neutral base palette unless the spec explicitly supplies deterministic
    style tokens.
    """
    return {
        "world_id": spec.world_id,
        "style_lock_id": spec.gui_spec_id,
        "layout_type": spec.layout_type,
        "roles": dict(spec.semantic_slots or {}),
        "motion": spec.motion,
    }


def _json_bytes(payload: Dict[str, Any]) -> bytes:
    return json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")


def _dispatch_payload(result: Any) -> Dict[str, Any]:
    """Return the current text/world dispatch contract."""
    return dict(result.to_dict())


class TheaterRequestHandler(SimpleHTTPRequestHandler):
    orchestrator: TheaterOrchestrator
    settings: Settings

    def __init__(self, *args: Any, directory: Optional[str] = None, **kwargs: Any):
        super().__init__(*args, directory=directory or str(STATIC_DIR), **kwargs)

    def log_message(self, format: str, *args: Any) -> None:
        return

    def end_headers(self) -> None:
        # Static JS/CSS/HTML is under active development; never let the
        # browser serve a stale cached copy (it broke the dynamic_gui.js
        # rewrite during verification — browser kept serving the old file).
        path = urlparse(self.path).path.lower()
        if path.endswith((".html", ".js", ".css")):
            self.send_header("Cache-Control", "no-cache, must-revalidate")
        super().end_headers()

    def do_OPTIONS(self) -> None:
        # Permissive CORS preflight response — only the three_body bake
        # endpoint is currently consumed cross-origin by the fork.
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/health":
            self._send_json({"ok": True, "service": "ai-multi-agent-theater", "settings": self.settings.public_dict()})
            return
        if path == "/api/state":
            state_store = self.orchestrator.state_store
            snapshot = state_store.snapshot()
            try:
                raw_state = state_store._load_raw()
            except Exception:
                raw_state = {}
            meta = raw_state.get("_meta") or {}
            if not isinstance(meta, dict):
                meta = {}
            world_id = str(
                meta.get("world_id")
                or getattr(state_store, "world_id", "")
                or "main"
            )
            try:
                kernel_spec = self.orchestrator.get_world_kernel_spec(world_id)
                kernel_spec_data = (
                    kernel_spec.to_dict()
                    if kernel_spec is not None and hasattr(kernel_spec, "to_dict")
                    else kernel_spec
                )
            except Exception:
                kernel_spec_data = None
            rules = (
                kernel_spec_data.get("rules") or []
                if isinstance(kernel_spec_data, dict)
                else []
            )
            try:
                kernel_state = self.orchestrator.get_world_kernel_state(world_id)
            except Exception:
                kernel_state = {}
            try:
                task_queue = [task.to_dict() for task in self.orchestrator.task_manager.list_tasks()]
            except Exception:
                # tasks.json may be corrupted by concurrent enqueues (pre-existing
                # race in TaskManager); don't let it take down the whole state endpoint.
                task_queue = []
            self._send_json(
                {
                    "settings": self.settings.public_dict(),
                    "world_id": world_id,
                    "schema_version": meta.get("schema_version"),
                    "_meta": dict(meta),
                    "rules": list(rules),
                    "kernel_state": (
                        dict(kernel_state)
                        if isinstance(kernel_state, dict)
                        else {}
                    ),
                    "worldbook": [entry.to_dict() for entry in snapshot.worldbook],
                    "characters": [entry.to_dict() for entry in snapshot.characters],
                    "objects": [o.to_dict() for o in snapshot.objects],
                    "event_log": list(raw_state.get("event_log") or []),
                    "narrative": raw_state.get("narrative"),
                    "task_queue": task_queue,
                    "game_sessions": self.orchestrator.game_manager.snapshot(),
                }
            )
            return
        if path == "/api/provider/diagnostics":
            probe_chat = (parse_qs(parsed.query).get("probe") or [""])[0] == "chat"
            self._send_json(ProviderDiagnostics(self.settings).report(probe_chat=probe_chat))
            return
        if path == "/api/provider/models":
            self._send_json(ProviderDiagnostics(self.settings).fetch_models())
            return
        if path == "/api/three_body/bake":
            self._handle_three_body_bake()
            return
        if path == "/api/three_body/state":
            self._handle_three_body_state()
            return
        if path == "/api/world/gui":
            self._handle_world_gui(parsed)
            return
        if path == "/api/world/offline_summary":
            self._handle_offline_summary(parsed)
            return
        if path == "/":
            self.path = "/index.html"
        super().do_GET()

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/dispatch":
            self._handle_dispatch()
            return
        if path == "/v1/chat/completions":
            self._handle_openai_compatible_chat()
            return
        if path == "/api/st/bridge":
            self._handle_st_bridge()
            return
        if path == "/api/game/step":
            self._handle_game_step()
            return
        if path == "/api/possession/exit":
            self._handle_possession_exit()
            return
        if path == "/api/possession/enter":
            self._handle_possession_enter()
            return
        if path == "/api/tasks/mark":
            self._handle_task_mark()
            return
        if path == "/api/character/create":
            self._handle_character_create()
            return
        if path == "/api/object/add":
            self._handle_object_add()
            return
        if path == "/api/interact":
            self._handle_interact()
            return
        if path == "/api/memory/embed":
            self._handle_memory_embed()
            return
        if path == "/api/system/shutdown":
            self._handle_shutdown()
            return
        if path == "/api/world/tick":
            self._handle_world_tick()
            return
        if path == "/api/world/fast_forward":
            self._handle_world_fast_forward()
            return
        if path == "/api/world/reset":
            self._handle_world_reset()
            return
        if path == "/api/world/save":
            self._handle_world_save()
            return
        if path == "/api/world/load":
            self._handle_world_load()
            return
        if path == "/api/world/import_worldbook":
            self._handle_world_import_worldbook()
            return
        if path == "/api/world/import_card":
            self._handle_world_import_card()
            return
        if path == "/api/world/generate_rules":
            self._handle_world_generate_rules()
            return
        if path == "/api/gameplay/generate":
            self._handle_gameplay_generate()
            return
        if path == "/api/cognitive_model/generate":
            self._handle_cognitive_model_generate()
            return
        if path == "/api/onboarding":
            self._handle_onboarding()
            return
        if path == "/api/onboarding/world/propose":
            self._handle_onboarding_world_propose()
            return
        if path == "/api/onboarding/world/confirm":
            self._handle_onboarding_world_confirm()
            return
        if path == "/api/onboarding/characters/propose":
            self._handle_onboarding_characters_propose()
            return
        if path == "/api/onboarding/characters/confirm":
            self._handle_onboarding_characters_confirm()
            return
        if path == "/api/onboarding/rules_gui/propose":
            self._handle_onboarding_rules_gui_propose()
            return
        if path == "/api/onboarding/rules_gui/confirm":
            self._handle_onboarding_rules_gui_confirm()
            return
        if path == "/api/onboarding/gameplay/propose":
            self._handle_onboarding_gameplay_propose()
            return
        if path == "/api/onboarding/gameplay/confirm":
            self._handle_onboarding_gameplay_confirm()
            return
        if path == "/api/onboarding/finalize":
            self._handle_onboarding_finalize()
            return
        if path == "/api/world/list":
            self._handle_world_list()
            return
        if path == "/api/three_body/bake":
            self._handle_three_body_bake()
            return
        if path != "/api/dispatch":
            self.send_error(HTTPStatus.NOT_FOUND)
            return

    def do_DELETE(self) -> None:
        path = urlparse(self.path).path
        if path.startswith("/api/world/"):
            world_id = path[len("/api/world/"):]
            if not world_id or "/" in world_id:
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            self._handle_world_delete(world_id)
            return
        self.send_error(HTTPStatus.NOT_FOUND)
        return

    def _handle_world_save(self) -> None:
        """POST /api/world/save — export a world as zip.

        Body: ``{"world_id": "..."}``

        Writes zip to ``saves/<world_id>.zip`` under the server's data
        directory and returns the absolute path + meta info. The zip
        includes state.json, llm_log.json and meta.json.
        """
        from .save_manager import SaveManager  # local import — cycles
        try:
            payload = self._read_json()
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)
            return
        world_id = str(payload.get("world_id") or "").strip()
        if not world_id:
            self._send_json({"error": "world_id is required"},
                             status=HTTPStatus.BAD_REQUEST)
            return
        try:
            orch = self.orchestrator
            orch.set_world(world_id)
            store = orch.state_store
            state = store._load()
            llm_log = list(getattr(orch, "_three_body_llm_log", []) or [])
            saves_dir = store.root.parent / "saves"
            saves_dir.mkdir(parents=True, exist_ok=True)
            out = saves_dir / f"{world_id}.zip"
            mgr = SaveManager()
            result = mgr.save(
                world_id, out,
                world_state=state, llm_output_log=llm_log,
            )
            self._send_json({
                "ok": True,
                "zip_path": str(result.path),
                "world_id": result.world_id,
                "schema_version": result.schema_version,
            })
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                             status=HTTPStatus.INTERNAL_SERVER_ERROR)
            return

    def _handle_world_load(self) -> None:
        """POST /api/world/load (multipart zip) — import a world archive.

        Accepts multipart/form-data with a file field ``file`` whose
        contents are the zip. After import, the orchestrator's in-memory
        store is rebound so subsequent reads see the new world (§10.5).
        """
        from .save_manager import SaveManager
        try:
            content_type = (self.headers.get("Content-Type") or "").lower()
            if "multipart/form-data" not in content_type:
                self._send_json(
                    {"error": "expected multipart/form-data with a 'file' field"},
                    status=HTTPStatus.BAD_REQUEST,
                )
                return
            boundary = self._extract_boundary(content_type)
            if not boundary:
                self._send_json({"error": "missing multipart boundary"},
                                 status=HTTPStatus.BAD_REQUEST)
                return
            length = int(self.headers.get("Content-Length", "0"))
            raw_body = self.rfile.read(length)
            file_bytes = self._extract_multipart_file(raw_body, boundary)
            if not file_bytes:
                self._send_json({"error": "multipart 'file' field not found"},
                                 status=HTTPStatus.BAD_REQUEST)
                return
            tmp_zip = self.orchestrator._state_root.parent / "tmp_upload.zip"
            tmp_zip.parent.mkdir(parents=True, exist_ok=True)
            tmp_zip.write_bytes(file_bytes)
            mgr = SaveManager()
            result = mgr.load(tmp_zip, self.orchestrator._state_root)
            tmp_zip.unlink(missing_ok=True)
            self.orchestrator.set_world(result.world_id)
            payload = {
                "ok": True,
                "world_id": result.world_id,
                "schema_version": result.schema_version,
            }
            if result.sandbox_warning:
                payload["sandbox_warning"] = result.sandbox_warning
            if result.fallback_text_path:
                payload["fallback_text_path"] = str(result.fallback_text_path)
            self._send_json(payload)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                             status=HTTPStatus.INTERNAL_SERVER_ERROR)
            return

    def _handle_world_import_worldbook(self) -> None:
        """POST /api/world/import_worldbook — import a lorebook into a world.

        Body: ``{"world_id"?: "...", "lorebook": <json>, "merge"?: bool}``

        Pipeline: WorldbookImporter.compile_worldbook → write each entry via
        the orchestrator's add_world_entry (approved by science_director).
        ``merge=true`` appends verbatim; ``merge=false`` (default) skips
        entries whose title already exists in the target world's worldbook.
        The world is auto-created (lazy via _world_store) if missing.
        """
        from .worldbook_import import WorldbookImporter
        from .models import WorldBookPatch
        try:
            payload = self._read_json()
        except json.JSONDecodeError:
            self._send_json({"ok": False, "error": "invalid json"},
                             status=HTTPStatus.BAD_REQUEST)
            return
        world_id = str(payload.get("world_id") or "main")
        lorebook = payload.get("lorebook")
        if not lorebook:
            self._send_json(
                {"ok": False, "error": "lorebook field is required"},
                status=HTTPStatus.BAD_REQUEST,
            )
            return
        merge = bool(payload.get("merge", False))

        compiled = WorldbookImporter.compile_worldbook(lorebook, target_world_id=world_id)
        warnings: list = list(compiled.get("warnings", []))

        # Auto-create + switch to the target world (lazy _world_store creates
        # the state file on first access — matches cmd_tick's auto-create).
        self.orchestrator.set_world(world_id)
        store = self.orchestrator.state_store
        existing_titles = {
            e.title for e in store.snapshot().worldbook
        }

        imported = 0
        skipped = 0
        for entry in compiled["worldbook"]:
            if not merge and entry["title"] in existing_titles:
                skipped += 1
                continue
            patch = WorldBookPatch(
                title=entry["title"],
                content=entry["content"],
                source=entry["source"],
                provenance="lore",
            )
            self.orchestrator.add_world_entry(patch, "science_director",
                                              origin="worldbook_import")
            imported += 1
        self._send_json({
            "ok": True,
            "world_id": world_id,
            "imported": imported,
            "skipped": skipped,
            "warnings": warnings,
        })

    def _handle_world_import_card(self) -> None:
        """POST /api/world/import_card — import a character card into a world.

        Body: ``{"world_id"?: "...", "card": <character card json>,
                "character_id"?: "..."}``

        Pipeline (§11.1): WorldImporter.parse_card → scan_injection on every
        raw field → compile_character → validate (QA gate).  On validate
        failure returns 400 with ``reasons``.  On pass, upsert_character
        writes the entity into the target world's characters.json.  The
        world is auto-created if missing.
        """
        from .world_import import WorldImporter
        from .models import CharacterPatch
        try:
            payload = self._read_json()
        except json.JSONDecodeError:
            self._send_json({"ok": False, "error": "invalid json"},
                             status=HTTPStatus.BAD_REQUEST)
            return
        world_id = str(payload.get("world_id") or "main")
        card = payload.get("card")
        if not isinstance(card, dict):
            self._send_json(
                {"ok": False, "error": "card field (object) is required"},
                status=HTTPStatus.BAD_REQUEST,
            )
            return
        character_id_override = payload.get("character_id")

        # parse → scan → compile → validate (§11.1)
        parsed = WorldImporter.parse_card(dict(card))
        if character_id_override:
            parsed.character_id = str(character_id_override)

        injection_warnings: list = []
        for raw_text in parsed.raw_fields.values():
            injection_warnings.extend(WorldImporter.scan_injection(raw_text))

        gaps = WorldImporter.detect_gaps(parsed)

        entity = WorldImporter.compile_character(
            parsed,
            gaps_filled={
                "dag_position": "imported",
                "allowed_actions": ["move", "speak"],
                "disposition": {"loyalty": 0.5},
                "damping": {"fear": 0.5},
            },
            injected=injection_warnings,
        )
        errors = WorldImporter.validate(entity)
        if errors:
            self._send_json(
                {"ok": False, "error": "card failed QA gate",
                 "reasons": errors, "gaps": gaps,
                 "warnings": injection_warnings},
                status=HTTPStatus.BAD_REQUEST,
            )
            return

        # Map the typed entity → CharacterPatch for storage (§15.3 → §15.2).
        tone_samples = entity.prose.get("tone_samples") or []
        patch = CharacterPatch(
            character_id=entity.character_id,
            name=parsed.name or entity.character_id,
            summary=str(entity.prose.get("description", ""))[:280],
            source="imported_card",
            personality=str(entity.prose.get("personality", "")),
            sample_line=str(tone_samples[0]) if tone_samples else "",
        )
        self.orchestrator.set_world(world_id)
        self.orchestrator.upsert_character(patch, "science_director",
                                           origin="card_import")
        self._send_json({
            "ok": True,
            "world_id": world_id,
            "character_id": entity.character_id,
            "warnings": injection_warnings,
            "gaps": gaps,
        })

    def _handle_world_list(self) -> None:
        """GET /api/world/list — list all archived worlds."""
        from .save_manager import SaveManager
        try:
            mgr = SaveManager()
            saves = mgr.list_saves(self.orchestrator._state_root)
            self._send_json({"ok": True, "saves": saves})
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                             status=HTTPStatus.INTERNAL_SERVER_ERROR)
            return

    def _handle_world_delete(self, world_id: str) -> None:
        """DELETE /api/world/{world_id} — remove an archived world."""
        from .save_manager import SaveManager
        try:
            mgr = SaveManager()
            removed = mgr.delete(world_id, self.orchestrator._state_root)
            self._send_json({"ok": True, "world_id": world_id, "removed": removed})
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                             status=HTTPStatus.INTERNAL_SERVER_ERROR)
            return

    @staticmethod
    def _extract_boundary(content_type: str) -> Optional[str]:
        """Pull ``boundary=...`` from the Content-Type header."""
        for part in content_type.split(";"):
            part = part.strip()
            if part.startswith("boundary="):
                value = part[len("boundary="):].strip()
                if value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]
                return value
        return None

    @staticmethod
    def _extract_multipart_file(body: bytes, boundary: str) -> Optional[bytes]:
        """Return the file bytes from a multipart payload.

        Scans ``--boundary`` parts, picks the first whose
        ``Content-Disposition: form-data; name="file"`` header is found,
        and returns the chunk between its blank line and the next
        ``--boundary`` marker.
        """
        delim = ("--" + boundary).encode("utf-8")
        crlf = b"\r\n"
        parts = body.split(delim)
        for idx, part in enumerate(parts):
            # Last delim is the terminator --boundary-- which we want to skip.
            if idx == len(parts) - 1:
                continue
            if not part.endswith(crlf):
                part = part + crlf
            head_end = part.find(b"\r\n\r\n")
            if head_end < 0:
                continue
            header_block = part[:head_end].decode("utf-8", errors="ignore").lower()
            if 'name="file"' not in header_block:
                continue
            content = part[head_end + 4:]
            if content.endswith(crlf):
                content = content[:-2]
            return content
        return None

    def _handle_three_body_state(self) -> None:
        """Read-only snapshot for the fork dashboard (no LLM cost).

        Returns the kernel's current civilization scalars + recent narration
        log so the fork can hydrate on load and after each COMMIT (spec §8.4)
        without re-baking the timeline. The orchestrator owns the private
        state; server is the only place that exposes it to the fork.
        """
        orch = self.orchestrator
        civ_root = orch._three_body_civ_state()  # in-memory, see dispatcher.py
        civ = civ_root.get("civilization", {})
        llm_log = list(getattr(orch, "_three_body_llm_log", []) or [])
        recent = llm_log[-3:]
        cursor = float(getattr(orch, "_three_body_cursor", 0.0))
        max_tech = float(getattr(orch, "_THREE_BODY_MAX_TECH", 10.0))
        self._send_cors_json({
            "ok": True,
            "civilization": {
                "tech_level": float(civ.get("tech_level", 0.0)),
                "count": int(civ.get("count", 1)),
                "alive": bool(civ.get("alive", True)),
                "evacuated": bool(civ.get("evacuated", False)),
                "last_event": str(civ.get("last_event", "")),
            },
            "cursor_t": cursor,
            "max_tech": max_tech,
            "recent_narration": recent,
            "session_id": "three_body",
        })

    def _handle_offline_summary(self, parsed) -> None:
        """GET /api/world/offline_summary?world_id=<id>&max_entries=<n>

        Returns a second-person "你离开时发生了……" recap of the world's recent
        autonomous advances (spec §13.4). The recap is produced by the
        orchestrator's IdleLoop.offline_summary, which reads the recent
        worldbook and asks an LLM to summarize. Raw entries may accompany an
        error for diagnostics, but they are never presented as a generated
        summary.
        """
        qs = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        world_id = str(qs.get("world_id") or "main")
        max_entries = int(qs.get("max_entries") or "5")
        orch = self.orchestrator
        with orch.world_scope(world_id):
            loop = orch._idle_loops.get(world_id)
            if loop is None:
                # Lazily build a transient IdleLoop for this world so the
                # summary works even before WorldClock installs one.
                from .idle_loop import IdleLoop
                loop = IdleLoop(orch, world_id)
            snapshot = orch.state_store.snapshot()
            recent = [
                {
                    "title": entry.title,
                    "content": entry.content,
                    "source": entry.source,
                }
                for entry in (snapshot.worldbook or [])[-max_entries:]
            ]

            # Route through the configured model with the same persisted,
            # request-scoped world context used by normal dispatch.
            def llm_fn(prompt: str) -> str:
                contextual_prompt = (
                    f"{prompt}\n\n"
                    "已持久化的当前世界上下文：\n"
                    f"{orch._runtime_world_context()}"
                )
                result = orch.model_client.complete_json(
                    role="world_builder",
                    prompt=contextual_prompt,
                    model=orch.settings.provider_model_deep,
                )
                if not isinstance(result, dict):
                    raise RuntimeError("LLM summary returned invalid data")
                text = str(
                    result.get("brief") or result.get("world_content") or ""
                ).strip()
                if not text:
                    raise RuntimeError("LLM summary returned empty text")
                return text
            try:
                summary = loop.offline_summary(
                    llm_fn,
                    max_entries=max_entries,
                )
            except Exception as exc:
                self._send_cors_json(
                    {
                        "ok": False,
                        "error": str(exc),
                        "world_id": world_id,
                        "recent_entries": recent,
                    },
                    status=HTTPStatus.SERVICE_UNAVAILABLE,
                )
                return
        self._send_cors_json({
            "ok": True, "world_id": world_id,
            "summary": summary or "", "recent_entries": recent,
        })

    def _handle_world_fast_forward(self) -> None:
        """POST /api/world/fast_forward — skip N beats (spec §10.2 代价约束:
        跳过=纯收益, 开放). Bystander / director-view affordance.

        Body: ``{"beats": N, "mode": "generic"|"three_body", "world_id": "...",
                "decision": {...}}``

        - generic (non-three-body): loops ``world_tick`` N times; each beat is
          tagged ``advancement_origin=idle_advance`` and recorded in worldbook.
        - three_body: loops ``three_body_tick`` N times, advancing the kernel
          cursor (time acceleration, §13.4 — "三体项目可直接用时间加速").

        Returns ``{ok, beats_run, summaries: [..], last_beat}`` so the UI can
        show a "快进中…" recap. Errors per-beat are tolerated: we stop early
        and return what we have (a tick that produces None is not fatal).
        """
        try:
            payload = self._read_json() if self.headers.get("Content-Length") else {}
        except json.JSONDecodeError:
            payload = {}
        beats = int(payload.get("beats") or 5)
        beats = max(0, min(beats, 50))  # safety cap: never run away
        mode = str(payload.get("mode") or "generic").strip().lower()
        if mode not in {"generic", "three_body"}:
            self._send_cors_json(
                {"ok": False, "error": "mode must be 'generic' or 'three_body'"},
                status=HTTPStatus.BAD_REQUEST,
            )
            return
        world_id = str(
            payload.get("world_id")
            or ("three_body" if mode == "three_body" else self.orchestrator.world_id)
        )
        decision = payload.get("decision") if mode == "three_body" else None
        orch = self.orchestrator
        if mode == "three_body":
            # Pre-bake a small kernel so three_body_tick doesn't block on the
            # full 600-year bake during a fast-forward burst.
            orch._ensure_three_body_kernel()

        summaries = []
        last_beat = None
        run = 0
        for _ in range(beats):
            try:
                if mode == "three_body":
                    result = orch.three_body_tick(decision=decision, world_id=world_id)
                else:
                    result = orch.world_tick(session_id="fast_forward")
            except Exception as exc:
                summaries.append({"ok": False, "error": str(exc)})
                break
            if result is None:
                summaries.append({"ok": False, "error": "tick produced no result"})
                break
            run += 1
            last_beat = result.to_dict()
            wu = (last_beat or {}).get("world_updates") or []
            line = ""
            if wu:
                line = (wu[0].get("title") or "") + ": " + (wu[0].get("content") or "")
            summaries.append({"ok": True, "beat": line[:200]})
        completed = run == beats
        self._send_cors_json(
            {
                "ok": completed,
                "beats_run": run,
                "summaries": summaries,
                "last_beat": last_beat,
                **(
                    {"error": summaries[-1].get("error", "tick failed")}
                    if not completed and summaries else {}
                ),
            },
            status=(
                HTTPStatus.OK
                if completed else HTTPStatus.SERVICE_UNAVAILABLE
            ),
        )

    def _handle_world_tick(self) -> None:
        try:
            payload = self._read_json() if self.headers.get("Content-Length") else {}
        except json.JSONDecodeError:
            payload = {}
        session_id = str(payload.get("session_id") or "world_tick")
        mode = str(payload.get("mode") or "generic").strip().lower()
        if mode not in {"generic", "three_body"}:
            self._send_cors_json(
                {"ok": False, "error": "mode must be 'generic' or 'three_body'"},
                status=HTTPStatus.BAD_REQUEST,
            )
            return
        # Three-body DecisionVector COMMIT (spec §8.4). The kernel decides
        # *what happened*; we forward the decision verbatim and let the
        # orchestrator collapse it via _resolve_three_body_decision.
        decision = payload.get("decision") if mode == "three_body" else None
        world_id = str(
            payload.get("world_id")
            or ("three_body" if mode == "three_body" else self.orchestrator.world_id)
        )
        try:
            if mode == "generic":
                result = self.orchestrator.world_tick(
                    session_id=session_id,
                    world_id=world_id,
                )
            else:
                result = self.orchestrator.three_body_tick(
                    session_id=session_id,
                    decision=decision,
                    world_id=world_id,
                )
        except Exception as exc:
            self._send_cors_json(
                {"ok": False, "error": f"LLM tick failed: {exc}"},
                status=HTTPStatus.SERVICE_UNAVAILABLE,
            )
            return
        if result is None:
            self._send_cors_json({"ok": False, "error": "world_tick produced no result"}, status=HTTPStatus.INTERNAL_SERVER_ERROR)
            return
        self._send_cors_json({"ok": True, "beat": result.to_dict()})

    def _handle_world_reset(self) -> None:
        """Wipe only the worldbook so a fresh seed can start clean.

        Characters and objects are kept so other sessions are not affected.
        """
        try:
            store = self.orchestrator.state_store
            state_path = store.path
            backup_path = state_path.with_suffix(".json.bak")
            if state_path.exists():
                backup_path.write_text(state_path.read_text(encoding="utf-8"), encoding="utf-8")
            state = store._load()  # internal but stable: same module owns the file
            state["worldbook"] = []
            store._save(state)
            self._send_json({"ok": True, "backup": str(backup_path)})
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)}, status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_three_body_bake(self) -> None:
        """Bake the three-body kernel and return the dashboard payload.

        Accepts POST {seed, years, dt, frames} or GET ?seed=&years=&dt=&frames=
        so the fork HTML can fetch via a simple GET during development.
        """
        try:
            if self.command == "GET":
                qs = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
                params = {
                    "seed": int(qs.get("seed", 2026)),
                    "years": float(qs.get("years", 200.0)),
                    "dt": float(qs.get("dt", 0.02)),
                    "frames": int(qs.get("frames", 600)),
                }
            else:
                payload = self._read_json() if self.headers.get("Content-Length") else {}
                params = {
                    "seed": int(payload.get("seed", 2026)),
                    "years": float(payload.get("years", 200.0)),
                    "dt": float(payload.get("dt", 0.02)),
                    "frames": int(qs.get("frames", 600)),
                }
            params["seed"] = max(0, params["seed"])
            params["years"] = max(10.0, min(params["years"], 2000.0))
            params["dt"] = max(0.005, min(params["dt"], 0.2))
            params["frames"] = max(60, min(params["frames"], 2000))
            from . import server as _server_module
            result = _server_module.bake_three_body(**params)
            self._send_cors_json(result)
        except (ValueError, TypeError) as exc:
            self._send_cors_json({"ok": False, "error": f"bad parameter: {exc}"},
                                 status=HTTPStatus.BAD_REQUEST)
        except Exception as exc:
            self._send_cors_json({"ok": False, "error": str(exc)},
                                 status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_world_gui(self, parsed) -> None:
        """GET /api/world/gui?world_id=... — load a confirmed GUI artifact.

        GUI generation belongs to the LLM-backed onboarding/generation stage.
        This read endpoint never creates a world and never synthesises a GUI
        when the confirmed artifact is absent.
        """
        try:
            qs = parse_qs(parsed.query)
            requested_world_id = (qs.get("world_id") or [""])[0].strip()
            if not requested_world_id:
                self._send_json(
                    {
                        "ok": False,
                        "error": (
                            "world_id query param is required; generate and "
                            "confirm the GUI through onboarding first"
                        ),
                    },
                    status=HTTPStatus.BAD_REQUEST,
                )
                return

            state_root = getattr(self.orchestrator, "_state_root", None)
            from .onboarding import load_gui_spec

            world_id = requested_world_id
            gui_spec = (
                load_gui_spec(state_root, world_id)
                if state_root is not None else None
            )
            if gui_spec is None:
                self._send_json(
                    {
                        "ok": False,
                        "world_id": world_id,
                        "error": "confirmed GUI artifact not found",
                    },
                    status=HTTPStatus.NOT_FOUND,
                )
                return

            # Tag the spec with the world_id so downstream wiring stays bound.
            gui_spec.world_id = world_id
            css = compile_to_css(gui_spec)

            # 4. build a style_lock-shaped dict from the spec + a layout-
            #    neutral base ramp. deriveTheme() needs the actual hex ramp;
            #    the spec only carries role→ramp-index, so we pair it with the
            #    fixed structural palette. This keeps colors deterministic.
            style_lock = _style_lock_from_spec(gui_spec)
            gui_theme = GuiTheme.deriveTheme(style_lock)

            self._send_json({
                "ok": True,
                "world_id": world_id,
                "gui_spec": gui_spec.to_dict(),
                "gui_theme": gui_theme,
                "css": css,
                "gui_source": "persisted",
            })
        except Exception as exc:
            self._send_json(
                {"ok": False, "error": f"world_gui failed: {exc}"},
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )

    def _handle_world_generate_rules(self) -> None:
        """POST /api/world/generate_rules  body: {world_id, description}.

        Uses :class:`OpenAILLMClient` to drive
        :meth:`RuleGenerator.generate`, validates + compiles the resulting
        :class:`WorldKernelSpec` via :class:`RuleCompiler`, and returns
        ``{ok, rules, compiled, errors, source, ...}``.

        Missing model access, request failure, parse failure, validation
        failure, or compile failure returns an error. No ruleset fallback is
        installed.
        """
        try:
            payload = self._read_json()
            world_id = str(payload.get("world_id") or "").strip()
            description = (
                str(payload.get("description") or "").strip()
                or _FROM_SCRATCH_PROMPTS["rules_gui"]
            )
            if not world_id:
                self._send_json(
                    {"ok": False, "error": "world_id is required"},
                    status=HTTPStatus.BAD_REQUEST,
                )
                return

            from .onboarding_llm import generate_world_rules, build_llm
            from .world_kernel_host import RuleCompiler

            client, llm_message = build_llm()
            if client is None:
                self._send_json(
                    {"ok": False, "error": llm_message or "LLM unavailable"},
                    status=HTTPStatus.SERVICE_UNAVAILABLE,
                )
                return
            llm_fn = client.as_text_fn(temperature=0.2, max_tokens=4096)
            model_label = "openai-llm"

            spec, gen_meta = generate_world_rules(
                description, llm_fn=llm_fn, model_label=model_label,
            )

            compiler = RuleCompiler()
            issues = compiler.validate_spec(spec)
            compiled = True
            spec_hash = ""
            try:
                compiled_kernel = compiler.compile(spec)
                spec_hash = compiled_kernel.spec_hash
            except Exception as exc:
                compiled = False
                issues = issues + [f"compile failed: {exc}"]

            if issues or not compiled:
                self._send_json(
                    {
                        "ok": False,
                        "error": "LLM-generated rules failed validation",
                        "errors": issues,
                    },
                    status=HTTPStatus.BAD_REQUEST,
                )
                return
            self._send_json({
                "ok": True,
                "world_id": world_id,
                "source": gen_meta["source"],
                "model_label": model_label,
                "llm_message": llm_message,
                "world_type": spec.world_type,
                "rules": [
                    {
                        "rule_id": r.rule_id,
                        "kind": r.kind,
                        "trigger": r.trigger,
                        "priority": r.priority,
                        "description": r.description,
                    }
                    for r in spec.rules
                ],
                "initial_state": spec.initial_state,
                "params": spec.params,
                "compiled": compiled,
                "spec_hash": spec_hash,
                "errors": issues,
            })
        except Exception as exc:
            self._send_json(
                {"ok": False, "error": f"generate_rules failed: {exc}"},
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )

    def _handle_gameplay_generate(self) -> None:
        """POST /api/gameplay/generate — out-of-library gameplay (spec §9.2).

        Body: ``{description, world_style?, use_llm?, kernel_id?}``.

        Drives :class:`GameplayGenerator.generate`: the LLM (when
        ``use_llm`` and a Spark client is available) authors a
        :class:`GameplaySpec` offline; it MUST pass the four hard validator
        gates (legal actions / termination / no dominant strategy / no
        deadlock) before it is returned. On failure the generator repairs
        (up to 2 rounds). Without an LLM, ``kernel_id`` selects a library
        kernel explicitly; without either input generation fails. World prose
        never selects a built-in kernel.

        Returns ``{ok, spec, source, validation, repairs}``.
        """
        try:
            payload = self._read_json()
            description = (
                str(payload.get("description") or "").strip()
                or _FROM_SCRATCH_PROMPTS["gameplay"]
            )
            world_style = payload.get("world_style")
            if world_style is not None:
                world_style = str(world_style).strip() or None
            use_llm = bool(payload.get("use_llm", False))
            kernel_id = str(payload.get("kernel_id") or "").strip() or None
            if not use_llm and kernel_id is None:
                self._send_json(
                    {
                        "ok": False,
                        "error": (
                            "use_llm=true is required for ordinary gameplay "
                            "generation; alternatively pass an explicit kernel_id"
                        ),
                    },
                    status=HTTPStatus.BAD_REQUEST,
                )
                return

            from .gameplay_generator import GameplayGenerator

            llm_fn = None
            llm_message = ""
            if use_llm:
                try:
                    from .onboarding_llm import build_llm
                    client, llm_message = build_llm()
                    if client is None:
                        self._send_json(
                            {
                                "ok": False,
                                "error": llm_message or "LLM unavailable",
                            },
                            status=HTTPStatus.SERVICE_UNAVAILABLE,
                        )
                        return
                    llm_fn = client.as_text_fn(
                        temperature=0.2, max_tokens=4096,
                    )
                except Exception as exc:  # noqa: BLE001
                    self._send_json(
                        {"ok": False, "error": f"llm unavailable: {exc}"},
                        status=HTTPStatus.SERVICE_UNAVAILABLE,
                    )
                    return

            gen = GameplayGenerator()
            spec, result = gen.generate(
                description,
                world_style=world_style,
                llm_fn=llm_fn,
                kernel_id=kernel_id,
            )
            response = result.to_dict()
            response["llm_message"] = llm_message
            self._send_json(response)
        except Exception as exc:
            self._send_json(
                {"ok": False, "error": f"gameplay/generate failed: {exc}"},
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )

    def _handle_cognitive_model_generate(self) -> None:
        """POST /api/cognitive_model/generate — Q7 cognitive-model generation.

        Body: ``{world_description, agent_role?, use_llm?}``.

        Drives :func:`cognitive_model_generator.generate_cognitive_model`.
        The configured LLM authors a :class:`CognitiveModelSpec`, which MUST
        pass the five hard validator gates before it is returned. On failure
        the request fails; no reference cognitive model is installed.

        Returns ``{ok, spec, source, validation, repairs, llm_message}``.
        """
        try:
            payload = self._read_json()
            description = (
                str(payload.get("world_description") or "").strip()
                or _FROM_SCRATCH_PROMPTS["cognitive_model"]
            )
            agent_role = str(payload.get("agent_role") or "").strip()
            use_llm = bool(payload.get("use_llm", False))
            if not use_llm:
                self._send_json(
                    {
                        "ok": False,
                        "error": "use_llm=true is required for generation",
                    },
                    status=HTTPStatus.BAD_REQUEST,
                )
                return

            from .cognitive_model_generator import generate_cognitive_model

            llm_fn = None
            llm_message = ""
            try:
                from .onboarding_llm import build_llm
                client, llm_message = build_llm()
                if client is None:
                    self._send_json(
                        {
                            "ok": False,
                            "error": llm_message or "LLM unavailable",
                        },
                        status=HTTPStatus.SERVICE_UNAVAILABLE,
                    )
                    return
                llm_fn = client.as_text_fn(
                    temperature=0.2, max_tokens=4096,
                )
            except Exception as exc:  # noqa: BLE001
                self._send_json(
                    {"ok": False, "error": f"llm unavailable: {exc}"},
                    status=HTTPStatus.SERVICE_UNAVAILABLE,
                )
                return

            spec, meta = generate_cognitive_model(
                description, agent_role=agent_role, llm_fn=llm_fn,
            )
            response = meta
            response["ok"] = True
            response["spec"] = spec.to_dict()
            response["llm_message"] = llm_message
            self._send_json(response)
        except Exception as exc:
            self._send_json(
                {"ok": False,
                 "error": f"cognitive_model/generate failed: {exc}"},
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )

    # ------------------------------------------------------------------
    # Onboarding per-stage propose+confirm handlers (9 endpoints)
    # ------------------------------------------------------------------

    def _build_onboarding_flow(self) -> Any:
        """Build an OnboardingFlow wired to the server's orchestrator."""
        from .onboarding import OnboardingFlow
        from .onboarding_llm import build_llm

        llm_client, llm_message = build_llm()
        return OnboardingFlow(
            orchestrator=self.orchestrator,
            state_root=getattr(self.orchestrator, "_state_root", None),
            llm_client=llm_client,
        )

    def _handle_onboarding_world_propose(self) -> None:
        """POST /api/onboarding/world/propose  body: {description}

        LLM generates a world parameter draft for user editing.
        """
        try:
            payload = self._read_json()
            description = str(payload.get("description") or "").strip()
            flow = self._build_onboarding_flow()
            result = flow.propose_world(description)
            self._send_json(result)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                            status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_onboarding_world_confirm(self) -> None:
        """POST /api/onboarding/world/confirm  body: {description, edited_params}

        User-edited world params → create world on disk, return world_id.
        """
        try:
            payload = self._read_json()
            description = str(payload.get("description") or "").strip()
            edited_params = payload.get("edited_params") or {}
            flow = self._build_onboarding_flow()
            result = flow.confirm_world(description, edited_params)
            self._send_json(result)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                            status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_onboarding_characters_propose(self) -> None:
        """POST /api/onboarding/characters/propose  body: {world_id, description, mode?}

        LLM generates character card draft(s) for user editing.
        """
        try:
            payload = self._read_json()
            world_id = str(payload.get("world_id") or "").strip()
            description = (
                str(payload.get("description") or "").strip()
                or _FROM_SCRATCH_PROMPTS["characters"]
            )
            mode = str(payload.get("mode") or "auto")
            if not world_id:
                self._send_json({"ok": False, "error": "world_id is required"},
                                status=HTTPStatus.BAD_REQUEST)
                return
            flow = self._build_onboarding_flow()
            result = flow.propose_characters(world_id, description, mode)
            self._send_json(result)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                            status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_onboarding_characters_confirm(self) -> None:
        """POST /api/onboarding/characters/confirm  body: {world_id, edited_characters}

        User-edited character cards → create via orchestrator.
        """
        try:
            payload = self._read_json()
            world_id = str(payload.get("world_id") or "").strip()
            edited_characters = payload.get("edited_characters") or []
            if not world_id or not edited_characters:
                self._send_json({"ok": False, "error": "world_id and edited_characters are required"},
                                status=HTTPStatus.BAD_REQUEST)
                return
            flow = self._build_onboarding_flow()
            result = flow.confirm_characters(world_id, edited_characters)
            self._send_json(result)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                            status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_onboarding_rules_gui_propose(self) -> None:
        """POST /api/onboarding/rules_gui/propose  body: {world_id, description}

        LLM generates rules + GUI draft for user editing.
        """
        try:
            payload = self._read_json()
            world_id = str(payload.get("world_id") or "").strip()
            description = (
                str(payload.get("description") or "").strip()
                or _FROM_SCRATCH_PROMPTS["rules_gui"]
            )
            if not world_id:
                self._send_json({"ok": False, "error": "world_id is required"},
                                status=HTTPStatus.BAD_REQUEST)
                return
            flow = self._build_onboarding_flow()
            result = flow.propose_rules_gui(world_id, description)
            self._send_json(result)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                            status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_onboarding_rules_gui_confirm(self) -> None:
        """POST /api/onboarding/rules_gui/confirm  body: {world_id, edited_rules, edited_gui}

        User-edited rules + GUI → compile and register.
        """
        try:
            payload = self._read_json()
            world_id = str(payload.get("world_id") or "").strip()
            edited_rules = payload.get("edited_rules") or {}
            edited_gui = payload.get("edited_gui") or {}
            if not world_id:
                self._send_json({"ok": False, "error": "world_id is required"},
                                status=HTTPStatus.BAD_REQUEST)
                return
            flow = self._build_onboarding_flow()
            result = flow.confirm_rules_gui(world_id, edited_rules, edited_gui)
            self._send_json(result)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                            status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_onboarding_gameplay_propose(self) -> None:
        """POST /api/onboarding/gameplay/propose  body: {world_id, description}

        LLM generates gameplay draft for user editing.
        """
        try:
            payload = self._read_json()
            world_id = str(payload.get("world_id") or "").strip()
            description = (
                str(payload.get("description") or "").strip()
                or _FROM_SCRATCH_PROMPTS["gameplay"]
            )
            if not world_id:
                self._send_json({"ok": False, "error": "world_id is required"},
                                status=HTTPStatus.BAD_REQUEST)
                return
            flow = self._build_onboarding_flow()
            result = flow.propose_gameplay(world_id, description)
            self._send_json(result)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                            status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_onboarding_gameplay_confirm(self) -> None:
        """POST /api/onboarding/gameplay/confirm  body: {world_id, edited_gameplay}

        User-edited gameplay → persist.
        """
        try:
            payload = self._read_json()
            world_id = str(payload.get("world_id") or "").strip()
            edited_gameplay = payload.get("edited_gameplay") or {}
            if not world_id or not edited_gameplay:
                self._send_json({"ok": False, "error": "world_id and edited_gameplay are required"},
                                status=HTTPStatus.BAD_REQUEST)
                return
            flow = self._build_onboarding_flow()
            result = flow.confirm_gameplay(world_id, edited_gameplay)
            self._send_json(result)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                            status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_onboarding_finalize(self) -> None:
        """POST /api/onboarding/finalize  body: {world_id}

        Activate world (WorldClock) + return ready status.
        """
        try:
            payload = self._read_json()
            world_id = str(payload.get("world_id") or "").strip()
            if not world_id:
                self._send_json({"ok": False, "error": "world_id is required"},
                                status=HTTPStatus.BAD_REQUEST)
                return
            flow = self._build_onboarding_flow()
            result = flow.finalize(world_id)
            self._send_json(result)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)},
                            status=HTTPStatus.INTERNAL_SERVER_ERROR)

    def _handle_onboarding(self) -> None:
        """POST /api/onboarding — one-shot 5-stage onboarding.

        Body: ``{description, characters?, worldbook?, character_cards?,
                  use_llm?, mode?, gameplay?}``  →  :meth:`OnboardingFlow.run`.

        ``gameplay`` may override the stage-4 prompt with
        ``{description, use_llm?, mode?}``; if omitted, the world description
        is used and gameplay is still generated by the LLM.

        Returns the full structured result. A failed model/configuration/
        validation step blocks the flow and is returned explicitly.
        """
        try:
            from .onboarding import OnboardingFlow
            payload = self._read_json()
            description = str(payload.get("description") or "").strip()
            llm_client = None
            llm_message = ""
            if payload.get("use_llm", True):
                try:
                    from .onboarding_llm import build_llm
                    llm_client, llm_message = build_llm()
                except Exception as exc:
                    llm_message = f"LLM unavailable: {exc}"
            flow = OnboardingFlow(
                orchestrator=self.orchestrator,
                state_root=getattr(self.orchestrator, "_state_root", None),
                llm_client=llm_client,
            )
            gameplay = payload.get("gameplay")
            if gameplay is not None and not isinstance(gameplay, dict):
                gameplay = None
            result = flow.run(
                description,
                characters=payload.get("characters"),
                worldbook=payload.get("worldbook"),
                character_cards=payload.get("character_cards"),
                use_llm=bool(payload.get("use_llm", True)),
                mode=str(payload.get("mode") or "auto"),
                gameplay=gameplay,
            )
            self._send_json(result)
        except Exception as exc:
            self._send_json(
                {"ok": False, "error": f"onboarding failed: {exc}"},
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )

    def _handle_dispatch(self) -> None:
        try:
            payload = self._read_json()
            message = str(payload.get("message") or "").strip()
            if not message:
                self._send_json({"error": "message is required"}, status=HTTPStatus.BAD_REQUEST)
                return
            result = self.orchestrator.dispatch(message=message, session_id=payload.get("session_id"), world_id=payload.get("world_id"))
            self._send_json(_dispatch_payload(result))
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)
        except Exception as exc:
            self._send_json(
                {"ok": False, "error": f"LLM dispatch failed: {exc}"},
                status=HTTPStatus.SERVICE_UNAVAILABLE,
            )

    def _handle_st_bridge(self) -> None:
        try:
            payload = self._read_json()
            message = str(payload.get("message") or payload.get("prompt") or "").strip()
            session_id = payload.get("session_id") or payload.get("chat_id") or "st_bridge"
            if not message:
                self._send_json({"error": "message is required"}, status=HTTPStatus.BAD_REQUEST)
                return
            result = self.orchestrator.dispatch(message=message, session_id=session_id)
            self._send_json({"ok": True, "task_manifest": _dispatch_payload(result)})
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)
        except Exception as exc:
            self._send_json(
                {"ok": False, "error": f"LLM dispatch failed: {exc}"},
                status=HTTPStatus.SERVICE_UNAVAILABLE,
            )

    def _handle_openai_compatible_chat(self) -> None:
        try:
            payload = self._read_json()
            messages = payload.get("messages") or []
            content_parts = []
            for message in messages:
                if isinstance(message, dict):
                    content_parts.append(str(message.get("content") or ""))
            message_text = "\n".join(content_parts).strip() or "导演棚默认调度"
            result = self.orchestrator.dispatch(message=message_text, session_id="openai_compatible")
            self._send_json(
                {
                    "id": f"chatcmpl_{result.session_id}",
                    "object": "chat.completion",
                    "model": payload.get("model") or self.settings.model_deep,
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": json.dumps(_dispatch_payload(result), ensure_ascii=False),
                            },
                            "finish_reason": "stop",
                        }
                    ],
                }
            )
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)
        except Exception as exc:
            self._send_json(
                {
                    "error": {
                        "message": f"LLM dispatch failed: {exc}",
                        "type": "llm_unavailable",
                    }
                },
                status=HTTPStatus.SERVICE_UNAVAILABLE,
            )

    def _handle_game_step(self) -> None:
        try:
            payload = self._read_json()
            result = self.orchestrator.game_manager.step(
                session_id=str(payload.get("session_id") or "game"),
                command=str(payload.get("command") or "idle"),
            )
            self._send_json(result)
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)

    def _handle_possession_exit(self) -> None:
        try:
            payload = self._read_json()
            character = self.orchestrator.possession_manager.exit_possession(str(payload.get("character_id") or "aster"))
            self._send_json({"character": character.to_dict()})
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)
        except ValueError as exc:
            self._send_json({"error": str(exc)}, status=HTTPStatus.BAD_REQUEST)

    def _handle_possession_enter(self) -> None:
        # setuid-style possession (§10.6): player gets the character's own
        # permissions (allowed_actions), not sudo. The frontend disables
        # intervention buttons whose verb isn't in allowed_actions.
        try:
            payload = self._read_json()
            character_id = str(payload.get("character_id") or "")
            player_id = str(payload.get("player_id") or "player_01")
            reason = str(payload.get("reason") or "")
            if not character_id:
                self._send_json({"error": "character_id required"}, status=HTTPStatus.BAD_REQUEST)
                return
            character = self.orchestrator.possession_manager.enter_possession(
                character_id, player_id, reason=reason)
            allowed = list((character.possession_limit or {}).get("allowed_actions") or [])
            self._send_json({"character": character.to_dict(), "allowed_actions": allowed})
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)
        except ValueError as exc:
            self._send_json({"error": str(exc)}, status=HTTPStatus.BAD_REQUEST)

    def _handle_task_mark(self) -> None:
        try:
            payload = self._read_json()
            task = self.orchestrator.task_manager.mark(
                session_id=str(payload.get("session_id") or ""),
                task_id=str(payload.get("task_id") or ""),
                status=str(payload.get("status") or "queued"),
            )
            if not task:
                self._send_json({"error": "task not found"}, status=HTTPStatus.NOT_FOUND)
                return
            self._send_json({"task": task.to_dict()})
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)

    def _handle_character_create(self) -> None:
        try:
            payload = self._read_json()
            description = str(payload.get("description") or "").strip()
            fields = payload.get("fields") or {}
            character_id = payload.get("character_id")
            mode = str(payload.get("mode") or "").strip().lower()
            # Backward-compatible mode inference (no mode → auto if description,
            # manual if fields, else error). Keeps the legacy {description}
            # contract working unchanged.
            if not mode:
                if description:
                    mode = "auto"
                elif fields:
                    mode = "manual"
                else:
                    self._send_json({"error": "description or fields required"}, status=HTTPStatus.BAD_REQUEST)
                    return
            if mode in ("auto", "mixed") and not description:
                self._send_json({"error": f"description is required for {mode} mode"}, status=HTTPStatus.BAD_REQUEST)
                return
            if mode == "manual" and not (fields and str(fields.get("name") or "").strip()):
                self._send_json({"error": "fields.name is required for manual mode"}, status=HTTPStatus.BAD_REQUEST)
                return
            result = self.orchestrator.create_character(
                mode=mode,
                character_id=character_id,
                description=description,
                fields=fields,
            )
            status = HTTPStatus.OK if result.get("ok") else HTTPStatus.BAD_REQUEST
            self._send_json(result, status=status)
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)

    def _handle_object_add(self) -> None:
        try:
            payload = self._read_json()
            oid = str(payload.get("object_id") or "").strip()
            name = str(payload.get("name") or "").strip()
            if not oid or not name:
                self._send_json({"error": "object_id and name required"}, status=HTTPStatus.BAD_REQUEST)
                return
            props = {k: payload[k] for k in ("kind", "location", "state", "material", "durability",
                                             "is_destructible", "is_takeable", "is_movable", "affordances")
                     if k in payload}
            self._send_json(self.orchestrator.add_object(oid, name, **props))
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)

    def _handle_interact(self) -> None:
        try:
            payload = self._read_json()
            verb = str(payload.get("verb") or "").strip()
            oid = str(payload.get("object_id") or "").strip()
            if not verb or not oid:
                self._send_json({"error": "verb and object_id required"}, status=HTTPStatus.BAD_REQUEST)
                return
            result = self.orchestrator.interact(
                actor_id=str(payload.get("actor_id") or "aster"),
                verb=verb, object_id=oid,
                actor_strength=int(payload.get("actor_strength") or 1),
            )
            self._send_json(result)
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)

    def _handle_memory_embed(self) -> None:
        try:
            payload = self._read_json()
            result = self.orchestrator.embedding_memory.embed(str(payload.get("text") or ""))
            self._send_json(result)
        except json.JSONDecodeError:
            self._send_json({"error": "invalid json"}, status=HTTPStatus.BAD_REQUEST)

    def _handle_shutdown(self) -> None:
        self._send_json({"ok": True, "shutting_down": True})
        server = _active_server
        if server is not None:
            # Shutdown from a daemon thread so the current response finishes.
            threading.Thread(target=server.shutdown, daemon=True).start()

    def _read_json(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length).decode("utf-8")
        return json.loads(raw or "{}")

    def _send_json(self, payload: Dict[str, Any], status: HTTPStatus = HTTPStatus.OK) -> None:
        body = _json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        # CORS for ALL JSON responses — fork pages (e.g. three_body.html on
        # :8765) need to POST /api/dispatch etc cross-origin during dev.
        # Permissive star is fine here because the endpoints are read/write
        # JSON RPC, not browser cookies.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def _send_cors_json(self, payload: Dict[str, Any],
                        status: HTTPStatus = HTTPStatus.OK) -> None:
        """Variant of _send_json that also emits permissive CORS headers,
        so the fork's three_body.html (served from a different origin
        during dev) can fetch /api/three_body/bake directly."""
        body = _json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

# Optional Three-Body bake adapter. The full trajectory is downsampled before
# transport; none of these helpers are called by generic world routes.


_BAKE_LOCK = threading.Lock()
_BAKE_CACHE: Dict[int, Dict[str, Any]] = {}
_BAKE_CACHE_MAX = 8


def _downsample(arr: np.ndarray, frames: int) -> np.ndarray:
    """Stride-sample `arr` to at most `frames` rows (uniform stride)."""
    n = arr.shape[0]
    if n <= frames:
        return arr
    stride = max(1, n // frames)
    return arr[::stride]


def _payload_for_kernel(kernel: "ThreeBodyKernel",
                        seed: int,
                        years: float,
                        dt: float,
                        frames: int) -> Dict[str, Any]:
    """Serialize a baked kernel into a JSON-safe dashboard payload."""
    # Project stars and planet onto the rotation plane (z dropped).
    # Use barycentric coordinates so the orbit motion is visible
    # rather than the lab-frame drift.
    star_xy = kernel.star_states[:, :, :2] - kernel.bary_positions[:, None, :2]
    planet_xy = kernel.planet_states[:, :2] - kernel.bary_positions[:, :2]
    light_total = kernel.light_series.sum(axis=1)

    # Approximate temperature proxy: log of total flux, scaled so the
    # typical mean sits around 0 with a roughly [-3, +3] dynamic range.
    eps = 1e-6
    temperature = np.log(light_total + eps)
    t_mean = float(temperature.mean())
    t_std = float(temperature.std()) + 1e-9
    temperature = (temperature - t_mean) / t_std

    star_ds = _downsample(star_xy, frames)
    planet_ds = _downsample(planet_xy, frames)
    t_ds = _downsample(kernel.t, frames)
    light_ds = _downsample(light_total, frames)
    temp_ds = _downsample(temperature, frames)

    # Civilization curve: tech 0 .. 8 step 0.5, evaluated at t=0 (the
    # default user vantage).
    tech_max = 8.0
    tech_step = 0.5
    civ_curve = []
    tech = 0.0
    while tech <= tech_max + 1e-9:
        ev = kernel.civilization_step(tech_level=tech, t=0.0)
        civ_curve.append({
            "tech": float(ev.tech_level),
            "delta_0": float(ev.delta_0),
            "T_predict": float(ev.T_predict),
            "next_chaos": float(ev.next_chaos) if ev.next_chaos is not None else None,
            "kind": str(ev.kind),
            "note": str(ev.note),
        })
        tech += tech_step

    # Evacuation proof: at max tech, is the best horizon shorter than
    # the mean gap between chaotic eras?
    chaotic = kernel.chaotic_era_intervals()
    proved = bool(kernel.evacuation_check(max_tech=tech_max))
    mean_chaos_gap = None
    T_pred_best = None
    if len(chaotic) >= 2:
        gaps = [chaotic[i].start - chaotic[i - 1].end for i in range(1, len(chaotic))]
        mean_chaos_gap = float(np.mean(gaps))
    if kernel.lambda_ > 0:
        delta_base = 0.5
        alpha = 1.5
        Delta = 0.1
        delta_0_best = float(delta_base * np.exp(-alpha * tech_max))
        T_pred_best = float(np.log(Delta / delta_0_best) / kernel.lambda_)

    return {
        "ok": True,
        "params": {"seed": int(seed), "years": float(years), "dt": float(dt), "frames": int(frames)},
        "kernel": {
            "lambda_max": float(kernel.lambda_),
            "energy_drift": float(kernel.energy_drift),
            "samples": int(len(kernel.t)),
            "baked_samples": int(len(t_ds)),
        },
        "t": t_ds.tolist(),
        "stars": star_ds.tolist(),       # [F][3][2]
        "planet": planet_ds.tolist(),     # [F][2]
        "illumination": light_ds.tolist(),
        "temperature": temp_ds.tolist(),
        "eras": [
            {"start": float(e.start), "end": float(e.end), "kind": str(e.kind)}
            for e in kernel.eras
        ],
        "civilization_curve": civ_curve,
        "evacuation": {
            "proved": proved,
            "max_tech": float(tech_max),
            "T_pred_best": T_pred_best,
            "mean_chaos_gap": mean_chaos_gap,
            "covers_gap": (
                None if T_pred_best is None or mean_chaos_gap is None
                else bool(T_pred_best < mean_chaos_gap)
            ),
        },
    }


def bake_three_body(seed: int = 2026,
                    years: float = 200.0,
                    dt: float = 0.02,
                    frames: int = 600) -> Dict[str, Any]:
    """Bake (with disk-cache) and return the dashboard payload."""
    cache_key = (int(seed), float(years), float(dt))
    with _BAKE_LOCK:
        cached = _BAKE_CACHE.get(cache_key)
        if cached is not None:
            # Re-serialize with the requested frame count, but reuse the kernel.
            return _payload_for_kernel(cached["kernel"], seed, years, dt, frames)

    # Optional reference adapter: generic server startup does not import it.
    from .kernels.three_body import ThreeBodyKernel

    kernel = ThreeBodyKernel(seed=seed, dt=dt,
                             lyapunov_renorms=12, lyapunov_renorm_steps=120)
    kernel.bake(years=years)

    with _BAKE_LOCK:
        if len(_BAKE_CACHE) >= _BAKE_CACHE_MAX:
            _BAKE_CACHE.pop(next(iter(_BAKE_CACHE)))
        _BAKE_CACHE[cache_key] = {"kernel": kernel}

    return _payload_for_kernel(kernel, seed, years, dt, frames)


def create_server(host: Optional[str] = None, port: Optional[int] = None, settings: Optional[Settings] = None) -> ThreadingHTTPServer:
    global _active_server
    if settings is None:
        # Load persisted config into env before reading settings (user
        # configures once via launcher; env vars still take precedence).
        from .config_store import apply_config_to_env
        apply_config_to_env()
    active_settings = settings or Settings.from_env()
    handler_class = type(
        "BoundTheaterRequestHandler",
        (TheaterRequestHandler,),
        {
            "settings": active_settings,
            "orchestrator": TheaterOrchestrator.from_settings(active_settings),
        },
    )
    server = ThreadingHTTPServer((host or active_settings.host, active_settings.port if port is None else port), handler_class)
    server.orchestrator = handler_class.orchestrator
    _active_server = server
    return server


def main() -> None:
    from .config_store import apply_config_to_env
    apply_config_to_env()
    settings = Settings.from_env()
    server = create_server(settings=settings)
    print(f"AI Multi-Agent Theater running at http://{settings.host}:{settings.port}")
    print(f"OpenAI-compatible endpoint: {settings.normalized_base_url} ({settings.model_fast}, {settings.model_deep})")
    world_clock = WorldClock(server.orchestrator, settings.world_tick_interval)
    if world_clock.start():
        print(f"World clock active: autonomous beat every {settings.world_tick_interval}s when idle")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        world_clock.stop()
        server.server_close()
        global _active_server
        _active_server = None


if __name__ == "__main__":
    main()
