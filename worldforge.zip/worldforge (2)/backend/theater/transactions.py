"""State transactions (snapshot / commit / rollback) — spec §8.1, §8.4, §15.6, §13.2.

通用组件：被时间加速、反事实、投机缓冲三处共用。
所有状态变更经此唯一写入点；校验 origin / adjudication_ref / prerequisites_checked。
纯 Python，无外部依赖，可单测。
"""

from __future__ import annotations

import copy
import uuid
from dataclasses import dataclass, field
from typing import Any, List, Literal, Optional

# §15.6 契约 — origin 取值
Origin = Literal["kernel", "rule_engine", "llm_adjudication", "user_action"]
ChangeOp = Literal["set", "delete"]


@dataclass
class StateChange:
    """§15.6 状态变更入参契约。"""

    txn_id: str
    origin: Origin
    speculative: bool
    changes: List[dict]  # each: {"path": str, "op": "set"|"delete", "value": Any}
    prerequisites_checked: List[str]
    adjudication_ref: Optional[str] = None

    @staticmethod
    def new(
        origin: Origin,
        changes: List[dict],
        *,
        speculative: bool = False,
        prerequisites_checked: Optional[List[str]] = None,
        adjudication_ref: Optional[str] = None,
        txn_id: Optional[str] = None,
    ) -> "StateChange":
        return StateChange(
            txn_id=txn_id or str(uuid.uuid4()),
            origin=origin,
            speculative=speculative,
            changes=list(changes),
            prerequisites_checked=list(prerequisites_checked or []),
            adjudication_ref=adjudication_ref,
        )


class StateTransactionError(ValueError):
    """校验失败的统一入口。"""


def _set_path(root: Any, path: str, value: Any) -> None:
    """支持点号路径写入；中间缺失自动建 dict。"""
    if not path:
        raise StateTransactionError("change.path 不能为空")
    parts = path.split(".")
    cursor = root
    for key in parts[:-1]:
        nxt = cursor.get(key) if isinstance(cursor, dict) else None
        if not isinstance(nxt, dict):
            nxt = {}
            cursor[key] = nxt
        cursor = nxt
    cursor[parts[-1]] = value


def _delete_path(root: Any, path: str) -> None:
    if not path:
        raise StateTransactionError("change.path 不能为空")
    parts = path.split(".")
    cursor = root
    for key in parts[:-1]:
        if not isinstance(cursor, dict) or key not in cursor:
            return  # 已不存在，幂等
        cursor = cursor[key]
    if isinstance(cursor, dict):
        cursor.pop(parts[-1], None)


def _apply_change(state: dict, change: dict) -> None:
    op = change.get("op", "set")
    path = change.get("path")
    if op == "set":
        _set_path(state, path, change.get("value"))
    elif op == "delete":
        _delete_path(state, path)
    else:
        raise StateTransactionError(f"未知 op: {op!r}")


@dataclass
class StateTransaction:
    """基于一个状态快照；begin 后 apply 走影子；commit 转正 / rollback 丢弃。

    校验规则（§15.6 / §13.2）：
      - origin=llm_adjudication 必须携带 adjudication_ref
      - prerequisites_checked 必须非空（I3 拒绝裸变更）
      - path 必须非空
    """

    base_state: dict
    _shadow: Optional[dict] = field(default=None, init=False)
    _active: bool = field(default=False, init=False)
    _applied: List[StateChange] = field(default_factory=list, init=False)

    # -- lifecycle ----------------------------------------------------------

    def begin(self) -> "StateTransaction":
        """开启一个影子事务；同一实例重复 begin 视为丢弃旧影子、重开。"""
        self._shadow = copy.deepcopy(self.base_state)
        self._active = True
        self._applied = []
        return self

    def apply(self, change: StateChange) -> None:
        if not self._active or self._shadow is None:
            raise StateTransactionError("事务未 begin 或已结束（commit/rollback）")
        # §15.6 校验
        if not change.prerequisites_checked:
            raise StateTransactionError(
                f"prerequisites_checked 必须非空 (txn_id={change.txn_id}, "
                f"origin={change.origin})"
            )
        if change.origin == "llm_adjudication" and not change.adjudication_ref:
            raise StateTransactionError(
                f"origin=llm_adjudication 必须携带 adjudication_ref "
                f"(txn_id={change.txn_id})"
            )
        if not change.changes:
            raise StateTransactionError(f"changes 不能为空 (txn_id={change.txn_id})")
        for c in change.changes:
            if not isinstance(c, dict) or not c.get("path"):
                raise StateTransactionError(
                    f"changes 项必须是含 path 的 dict (txn_id={change.txn_id})"
                )
        # §15.6: speculative=true 必须写到影子；false 直接到 base
        target = self._shadow if change.speculative else self.base_state
        for c in change.changes:
            _apply_change(target, c)
        # 非投机变更走 base 时，影子也保持一致以便 commit 是幂等 no-op
        if not change.speculative:
            self._shadow = copy.deepcopy(self.base_state)
        self._applied.append(change)

    def commit(self) -> dict:
        """转正：把影子写入 base_state（保留 dict 标识）并返回它。

        选择"原地写入"而非"替换引用"，是为了让已持有 base_state 引用的
        上层（嵌套事务、缓存、监视器）看到的是同一对象被原地修改，
        避免引用分裂导致隐性不一致。§15.6 的"唯一写入点"语义也由此成立。
        """
        if not self._active:
            raise StateTransactionError("事务未 begin 或已结束")
        if self._shadow is not None:
            self.base_state.clear()
            self.base_state.update(self._shadow)
        self._shadow = None
        self._active = False
        self._applied = []
        return self.base_state

    def rollback(self) -> dict:
        """丢弃影子，base_state 不变；返回当前 base_state。"""
        if not self._active:
            raise StateTransactionError("事务未 begin 或已结束")
        self._shadow = None
        self._active = False
        self._applied = []
        return self.base_state

    # -- misc ---------------------------------------------------------------

    def snapshot(self) -> dict:
        """深拷贝当前 base_state；用于加速前的存档点。"""
        return copy.deepcopy(self.base_state)

    @property
    def active(self) -> bool:
        return self._active

    @property
    def pending_changes(self) -> List[StateChange]:
        """当前事务已 apply 但未 commit 的变更（用于审计 / 复现记录）。"""
        return list(self._applied)