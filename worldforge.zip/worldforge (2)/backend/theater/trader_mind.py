"""TraderMind — an economy-world ``CognitiveModel`` (architecture spec P2).

The P2 minimal closed loop (spec §8 / §9.3② / §10 / §12):

    trader observes price → updates belief → buys/sells → market moves
    → causal trace explains it.

The user's precision principle (load-bearing for this module):

    - **errors are generated in AgentMind**, facts are adjudicated in
      WorldKernel, causes are kept in CausalTrace.
    - The script does **not** pick the correct answer; it defines *how the
      character observes / mis-perceives / weighs / chooses*.  The trader
      decides on **subjective beliefs** (subjective disaster probability,
      not the real one) and may therefore *stably* be wrong.
    - Six structured error sources (§10): information error / perception
      error / reasoning error / cognitive bias (stubborn → down-weight
      disconfirming evidence) / wrong goal / execution error.  These are
      modelled structurally, not as random blunders.
    - Decisions use **subjective-belief scoring** sampled by softmax; no
      hard if/else.
    - Determinism ≠ infallibility: the same seed → the same (possibly
      wrong) outcome every run.
    - Belief update is pure-numerical, kernel-side; **no LLM**.

Generalisation proof: ``TraderMind`` implements the same
:class:`theater.cognitive_model.CognitiveModel` protocol as
:class:`theater.cognitive_model.ThreeBodyCognitiveModel` — one protocol,
two worlds (three-body + economy).  That is the whole point of P2.

Reuse of P1: ``TraderMind`` composes a :class:`theater.sim_agent.SimAgent`
(character card + MindProfile + AgentMindState + WorldBinding) rather than
re-deriving those structures.  It overrides the three skeleton methods
(``observe`` / ``update_belief`` / ``choose_action``) with the real
bounded-confidence + softmax policy.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .cognitive_model import Belief, CognitiveModel
from .observation_filter import (
    MarketObservation,
    MarketObservationFilter,
    Observation,
    ObservationFilter,
)
from .sim_agent import (
    AgentMindState,
    CharacterDefinition,
    MindProfile,
    SimAgent,
    WorldBinding,
    derive_mind_profile,
)


__all__ = [
    "TraderProfile",
    "BeliefUpdateTrace",
    "ActionIntent",
    "CausalTrace",
    "TraderMind",
]


@dataclass
class TraderProfile:
    """Economy-specific personality knobs layered on top of MindProfile.

    The §10 cognitive-bias table, made explicit (each in ``[0, 1]``):

    - ``greed``          — chases gains (raises subjective upside).
    - ``stubbornness``   — down-weights disconfirming evidence (×0.3 at 1.0).
    - ``official_trust`` — up-weights official "market stable" proclamations.
    - ``rumour_trust``   — up-weights friend / rumour tips.
    - ``loss_aversion``  — multiplies the subjective cost of a wrong buy.

    Stable traits derived from the card's personality text by
    :func:`derive_trader_profile`; they shape belief formation, never
    dictate the action directly.
    """

    base: MindProfile = field(default_factory=MindProfile)
    greed: float = 0.5
    stubbornness: float = 0.0
    official_trust: float = 0.5
    rumour_trust: float = 0.5
    loss_aversion: float = 0.5

    def evidence_weight_for(self, source: str, confirms_prior: bool) -> float:
        """Effective evidence weight for an observation (§10 cognitive bias).

        - stubborn traders down-weight disconfirming evidence by
          ``(1 - stubbornness*0.7)`` (at stubbornness=1 → ×0.3).
        - official_trust / rumour_trust multiply official / rumour sources.
        - aggregate (invisible) → weight 0 (information error source).
        """
        base = self.base.evidence_weight
        if source == "aggregate":
            return 0.0
        if source == "official":
            w = base * (0.5 + self.official_trust)
        elif source == "rumour":
            w = base * (0.5 + self.rumour_trust)
        else:
            w = base
        if not confirms_prior:
            w *= (1.0 - self.stubbornness * 0.7)
        return max(0.0, w)


_TRADER_KEYWORDS: List[tuple] = [
    (("贪婪", "贪心", "greedy", "avaricious", "covetous"),
     {"greed": +0.4, "official_trust": +0.2}),
    (("固执", "顽固", "倔强", "stubborn", "inflexible", "fixed"),
     {"stubbornness": +0.5, "official_trust": +0.1}),
    (("谨慎", "小心", "cautious", "careful", "prudent"),
     {"loss_aversion": +0.4, "greed": -0.2}),
    (("赌徒", "冒险", "鲁莽", "gambler", "reckless", "risk-seeking"),
     {"greed": +0.3, "loss_aversion": -0.3}),
    (("开放", "好奇", "open", "curious", "inquisitive"),
     {"stubbornness": -0.3, "rumour_trust": +0.2}),
    (("轻信", "耳根软", "gullible", "credulous"),
     {"rumour_trust": +0.4}),
    (("理性", "冷静", "rational", "analytical"),
     {"stubbornness": -0.2, "greed": -0.1}),
]


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def derive_trader_profile(personality: str, appearance: str = "") -> TraderProfile:
    """Derive a :class:`TraderProfile` from card text, deterministically.

    Builds on :func:`theater.sim_agent.derive_mind_profile` (P1 epistemic
    knobs) and layers economy-specific bias knobs.  No LLM, no randomness.
    """
    base = derive_mind_profile(personality, appearance)
    text = f"{personality} {appearance}".lower()
    greed = 0.5
    stubbornness = 0.0
    official_trust = 0.5
    rumour_trust = 0.5
    loss_aversion = 0.5
    for keywords, deltas in _TRADER_KEYWORDS:
        if any(kw.lower() in text for kw in keywords):
            greed += deltas.get("greed", 0.0)
            stubbornness += deltas.get("stubbornness", 0.0)
            official_trust += deltas.get("official_trust", 0.0)
            rumour_trust += deltas.get("rumour_trust", 0.0)
            loss_aversion += deltas.get("loss_aversion", 0.0)
    return TraderProfile(
        base=base,
        greed=_clamp01(greed),
        stubbornness=_clamp01(stubbornness),
        official_trust=_clamp01(official_trust),
        rumour_trust=_clamp01(rumour_trust),
        loss_aversion=_clamp01(loss_aversion),
    )


@dataclass
class BeliefUpdateTrace:
    """A single belief-update step, fully replayable (six-source structure).

    Every field is a plain scalar so the trace serialises and replays
    deterministically; ``error_source`` attributes one of the six
    structured error sources (§10) to this step.
    """

    topic: str
    prior: Optional[float]
    prior_confidence: float
    observation: Optional[float]
    source: str
    imperfection: str
    evidence_signal: float
    evidence_weight: float
    personality_modifier: str
    rejected: bool
    posterior: Optional[float]
    posterior_confidence: float
    error_source: str = ""


@dataclass
class ActionIntent:
    """The trader's chosen action, emitted to the rule engine (§12).

    The AgentMind **never writes world state directly** — it emits an
    intent; the kernel's rule engine settles it against ground truth.
    """

    actor_id: str
    verb: str
    quantity: float
    rationale: str
    decision_temperature: float
    subjective_scores: Dict[str, float] = field(default_factory=dict)


@dataclass
class CausalTrace:
    """Structured causal chain for one tick (belief → decision → market).

    Not literary prose; a structured DAG the narrator layer dramatises
    later.  Edges are typed: ``perception`` / ``bias`` / ``evidence`` /
    ``decision`` / ``settlement`` / ``irony``.
    """

    agent_id: str
    t: int
    belief_before: Optional[float]
    belief_after: Optional[float]
    belief_update: Optional[BeliefUpdateTrace]
    action: ActionIntent
    market_before: Dict[str, float] = field(default_factory=dict)
    market_after: Dict[str, float] = field(default_factory=dict)
    edges: List[Dict[str, str]] = field(default_factory=list)
    error_sources: List[str] = field(default_factory=list)


class TraderMind:
    """An economy-world ``CognitiveModel`` + bounded-rational trader policy.

    Composes a :class:`SimAgent` (P1) for character / mind / binding /
    state plumbing, and an :class:`ObservationFilter` for perception.
    Implements :meth:`predict` (the CognitiveModel protocol) plus
    :meth:`update_belief` and :meth:`choose_action` — the real bounded
    confidence + softmax policy that P1 only stubbed.

    Belief topic ``"price_trend"``: a committed prediction of the direction
    the price will move next tick (``predicted > 0`` → up, ``< 0`` → down,
    ``== 0`` → stable).  ``predicted`` is a Sabre commitment (concrete, not
    a distribution); ``confidence`` is a scalar self-assessment.

    Determinism: every input is deterministic, so the same seed → the same
    (possibly wrong) belief / action every run.
    """

    BASE_DECISION_TEMP = 0.5

    def __init__(
        self,
        character: CharacterDefinition,
        *,
        profile: Optional[TraderProfile] = None,
        world_binding: Optional[WorldBinding] = None,
        observation_filter: Optional[ObservationFilter] = None,
        seed: int = 0,
    ) -> None:
        self.profile = profile if profile is not None else derive_trader_profile(
            character.personality, character.appearance)
        sim = SimAgent(
            character=character,
            mind=self.profile.base,
            world_binding=world_binding,
        )
        self._sim = sim
        self._obs_filter = observation_filter or MarketObservationFilter()
        self._seed = int(seed)
        self._rng = random.Random(self._seed)
        self._topic = "price_trend"
        self._price_memory: List[float] = []

    @property
    def character_id(self) -> str:
        return self._sim.character.character_id

    @property
    def name(self) -> str:
        return self._sim.character.name

    @property
    def mind_state(self) -> AgentMindState:
        return self._sim.mind_state

    @property
    def world_binding(self) -> WorldBinding:
        return self._sim.world_binding

    # -- CognitiveModel protocol ------------------------------------------

    def predict(
        self,
        ground_truth_state: Dict[str, Any],
        agent_capability: Dict[str, Any],
        t: float,
    ) -> Belief:
        """Build the trader's committed price-trend belief at time ``t``.

        Same protocol shape as ``ThreeBodyCognitiveModel.predict`` — that
        is the generalisation proof.  The trader observes via the filter,
        then commits to a direction.  Low information (no price history,
        invisible aggregates) → the trader commits to a greed-tilted trend
        — a deterministic, stable misprediction (``model_error=True`` when
        the committed direction disagrees with the ground-truth next move).
        """
        seed = int(agent_capability.get("seed", self._seed))
        binding = {
            "agent_id": self.character_id,
            "t": int(t),
            "own_inventory": agent_capability.get("own_inventory", 0.0),
            "own_cash": agent_capability.get("own_cash", 0.0),
            "own_history": agent_capability.get("own_history", []),
            "public_tape": agent_capability.get("public_tape"),
        }
        obs = self._obs_filter.observe(ground_truth_state, binding, seed)
        observed_price = obs.public_price()
        if observed_price is not None:
            self._price_memory.append(float(observed_price))
        belief = self._infer_trend(obs, ground_truth_state, t)
        self._sim.mind_state.beliefs[self._topic] = belief
        return belief

    # -- Belief update (pure-numerical, no LLM) ---------------------------

    def update_belief(
        self,
        observation: Observation,
        evidence_weight: Optional[float] = None,
        belief_update_rate: Optional[float] = None,
    ) -> BeliefUpdateTrace:
        """Numerically revise the price-trend belief given an observation.

        Every observable evidence source is reduced to a signed signal in
        ``[-1, +1]`` and a personality-shaped weight, then aggregated in
        parallel (the user-example structure: official / rumour / public
        tape / inventory each carry their own weight)::

            w_i = TraderProfile.evidence_weight_for(source_i, confirms_prior)
            posterior = prior + belief_update_rate × Σ_i (w_i × signal_i)
            confidence creeps toward the evidence direction, gated by Σw.

        Rejection: when every source weight is ~0 (invisible aggregate, or
        stubborn trader rejecting disconfirming evidence), the update is a
        no-op and ``rejected=True``.
        """
        rate = (belief_update_rate if belief_update_rate is not None
                else self.profile.base.belief_update_rate)
        prior_belief = self._sim.mind_state.beliefs.get(self._topic)
        prior = prior_belief.predicted if prior_belief else 0.0
        prior_conf = prior_belief.confidence if prior_belief else 0.5

        sources = self._all_evidence(observation, prior)
        if sources:
            lead = max(sources, key=lambda s: abs(s["weight"] * s["signal"]))
        else:
            lead = {"signal": 0.0, "source": "none",
                    "imperfection": "invisible", "value": None,
                    "error_source": "information_error", "weight": 0.0}
        signal = lead["signal"]
        source = lead["source"]
        imperf = lead["imperfection"]
        obs_val = lead["value"]
        error_source = lead["error_source"]

        agg = sum(s["weight"] * s["signal"] for s in sources)
        total_w = sum(s["weight"] for s in sources)

        confirms_prior = (signal == 0) or (prior == 0) or (
            (signal > 0) == (prior > 0))
        w = lead["weight"] if evidence_weight is None else float(evidence_weight)
        modifier = self._personality_modifier_label(source, confirms_prior, w)

        rejected = (total_w <= 1e-9) or (source in ("aggregate", "none"))
        if rejected:
            posterior = prior
            posterior_conf = prior_conf
        else:
            posterior = prior + rate * agg
            posterior = max(-1.0, min(1.0, posterior))
            delta_conf = min(1.0, total_w) * rate * abs(agg) * 0.2
            posterior_conf = min(1.0, prior_conf + delta_conf)

        new_belief = Belief(
            predicted=posterior,
            confidence=posterior_conf,
            model_error=bool(prior_belief and prior_belief.model_error),
            committed_values=(dict(prior_belief.committed_values)
                              if prior_belief else {}),
        )
        new_belief.committed_values["last_signal"] = signal
        new_belief.committed_values["last_source"] = source
        self._sim.mind_state.beliefs[self._topic] = new_belief

        if not error_source:
            if imperf == "invisible":
                error_source = "information_error"
            elif imperf in ("delayed", "noisy", "delayed+noisy"):
                error_source = "perception_error"
            elif (self.profile.stubbornness > 0.5 and not confirms_prior
                  and rejected):
                error_source = "cognitive_bias"

        return BeliefUpdateTrace(
            topic=self._topic,
            prior=prior,
            prior_confidence=prior_conf,
            observation=obs_val,
            source=source,
            imperfection=imperf,
            evidence_signal=signal,
            evidence_weight=w,
            personality_modifier=modifier,
            rejected=rejected,
            posterior=posterior,
            posterior_confidence=posterior_conf,
            error_source=error_source,
        )

    # -- Decision: subjective scoring + softmax (no hard if/else) ---------

    def choose_action(
        self,
        belief: Optional[Any] = None,
        risk_profile: Optional[Dict[str, float]] = None,
        *,
        own_inventory: float = 0.0,
        own_cash: float = 0.0,
        current_price: float = 1.0,
        decision_temperature: Optional[float] = None,
        seed: Optional[int] = None,
    ) -> ActionIntent:
        """Pick buy / sell / hold by **subjective-belief scoring** + softmax.

        No hard if/else "if belief>0 buy".  Each verb gets a subjective
        expected value computed from the trader's *subjective* belief and
        personality; the verb is sampled by ``softmax(scores / T)``::

            buy_score  = greed·P_up·gain_w·gain − loss_av·P_down·loss_w·loss − cash_cost
            sell_score = loss_av·P_down·loss_w·loss − greed·P_up·gain_w·gain + liquidity
            hold_score = small inertia + P_stable term

        where ``P_up = sigmoid(belief.predicted)`` (the trader's subjective
        probability, **not** the real one).  Pressure (low cash / negative
        inventory) raises the temperature → more impulsive sampling.

        ``belief`` accepts a :class:`Belief` or a bare scalar posterior.
        """
        if belief is None:
            b = self._sim.mind_state.beliefs.get(self._topic)
            pred = b.predicted if b and b.predicted is not None else 0.0
            conf = b.confidence if b else 0.5
        elif isinstance(belief, Belief):
            pred = belief.predicted if belief.predicted is not None else 0.0
            conf = belief.confidence
        else:
            pred = float(belief) if belief is not None else 0.0
            conf = 0.6
        rp = risk_profile or self.profile.base.risk_profile
        loss_w = rp.get("loss_weight", 1.0) * (0.5 + self.profile.loss_aversion)
        gain_w = rp.get("gain_weight", 1.0) * (0.5 + self.profile.greed)

        p_up = _sigmoid(pred)
        p_down = _sigmoid(-pred)
        p_stable = max(0.0, 1.0 - p_up - p_down)

        # expected move scaled by committed magnitude × confidence so a
        # confident belief dominates the softmax rather than being drowned
        # by the hold inertia.
        move = max(0.0, abs(pred)) * conf
        expected_gain = current_price * move
        expected_loss = current_price * move

        cash_cost = 0.0 if own_cash > 0 else 0.5
        buy_score = (
            self.profile.greed * p_up * gain_w * expected_gain
            - self.profile.loss_aversion * p_down * loss_w * expected_loss
            - cash_cost)
        sell_score = (
            self.profile.loss_aversion * p_down * loss_w * expected_loss
            - self.profile.greed * p_up * gain_w * expected_gain
            + (0.2 if own_inventory > 0 else 0.0))
        hold_score = 0.05 + 0.3 * p_stable

        scores = {"buy": buy_score, "sell": sell_score, "hold": hold_score}

        pressure = 0.0
        if own_cash < current_price:
            pressure += 0.5
        if own_inventory < 0:
            pressure += 0.5
        temp = (decision_temperature if decision_temperature is not None
                else self.BASE_DECISION_TEMP)
        temp *= (1.0 + pressure)

        rng = random.Random(seed) if seed is not None else self._rng
        verb = _softmax_sample(scores, temp, rng)

        if verb == "buy":
            capacity = (max(0.0, own_cash / current_price)
                        if current_price > 0 else 0.0)
            qty = capacity * conf * (0.5 + self.profile.greed)
        elif verb == "sell":
            qty = max(0.0, own_inventory) * conf * (0.5 + self.profile.loss_aversion)
        else:
            qty = 0.0
        qty = max(0.0, qty)

        return ActionIntent(
            actor_id=self.character_id,
            verb=verb,
            quantity=qty,
            rationale=(
                f"belief={pred:+.3f} conf={conf:.2f} "
                f"p_up={p_up:.2f} p_down={p_down:.2f} "
                f"greed={self.profile.greed:.2f} "
                f"loss_av={self.profile.loss_aversion:.2f} "
                f"pressure={pressure:.2f} T={temp:.2f}"),
            decision_temperature=temp,
            subjective_scores={k: round(v, 4) for k, v in scores.items()},
        )

    # -- Causal trace -----------------------------------------------------

    def explain_trace(
        self,
        t: int,
        belief_before: Optional[float],
        belief_update: Optional[BeliefUpdateTrace],
        action: ActionIntent,
        market_before: Dict[str, float],
        market_after: Dict[str, float],
    ) -> CausalTrace:
        """Assemble a :class:`CausalTrace` for tick ``t``.

        Edges: world→observation (perception), observation→belief
        (bias/evidence), belief→action (decision), action→market
        (settlement), and an irony edge when the subjective belief
        disagrees with the ground-truth price move.
        """
        edges: List[Dict[str, str]] = []
        error_sources: List[str] = []
        if belief_update is not None:
            edges.append({"from": "world", "to": "observation",
                          "type": "perception"})
            edges.append({
                "from": "observation", "to": "belief",
                "type": "bias" if (belief_update.rejected
                                   or "bias" in belief_update.personality_modifier)
                else "evidence",
            })
            if belief_update.error_source:
                error_sources.append(belief_update.error_source)
        edges.append({"from": "belief", "to": "action", "type": "decision"})
        edges.append({"from": "action", "to": "market", "type": "settlement"})

        belief_after = (belief_update.posterior if belief_update
                        else belief_before)
        p_before = market_before.get("price", 0.0)
        p_after = market_after.get("price", 0.0)
        truth_dir = _sign(p_after - p_before)
        subj_dir = _sign(belief_after) if belief_after is not None else 0
        if truth_dir != 0 and subj_dir != 0 and truth_dir != subj_dir:
            edges.append({"from": "subjective_belief", "to": "ground_truth",
                          "type": "irony"})
            if "cognitive_bias" not in error_sources:
                error_sources.append("cognitive_bias")

        return CausalTrace(
            agent_id=self.character_id,
            t=t,
            belief_before=belief_before,
            belief_after=belief_after,
            belief_update=belief_update,
            action=action,
            market_before=dict(market_before),
            market_after=dict(market_after),
            edges=edges,
            error_sources=error_sources,
        )

    # -- internals --------------------------------------------------------

    def _infer_trend(
        self, obs: MarketObservation, ground_truth: Dict[str, Any], t: float,
    ) -> Belief:
        """Commit a price-trend belief from the observation.

        Price-memory delta is the primary signal; an official "stable"
        claim is read as bullish by a greedy+stubborn trader (cognitive
        bias).  Low information (one price, no claim) → greed-tilted
        commitment (greedy → up ``+0.3``; cautious → stable ``0.0``).
        """
        if len(self._price_memory) >= 2:
            prev = self._price_memory[-2]
            curr = self._price_memory[-1]
            delta = curr - prev
            signal = _sign(delta) * min(1.0, abs(delta) / max(1.0, abs(prev)))
            conf = 0.6
        elif len(self._price_memory) == 1:
            signal = 0.3 if self.profile.greed > 0.6 else 0.0
            conf = 0.4
        else:
            signal = 0.3 if self.profile.greed > 0.6 else 0.0
            conf = 0.3

        claim = obs.official_claim()
        if claim and "stable" in claim.lower():
            if self.profile.stubbornness > 0.4 and self.profile.greed > 0.5:
                signal = max(signal, 0.5)
                conf = min(1.0, conf + 0.15)

        true_next = ground_truth.get("_next_price")
        committed_pred = signal
        model_error = False
        if isinstance(true_next, (int, float)):
            ref = (self._price_memory[-1] if self._price_memory else 0.0)
            true_dir = _sign(float(true_next) - ref)
            subj_dir = _sign(committed_pred)
            if true_dir != 0 and subj_dir != 0 and true_dir != subj_dir:
                model_error = True
        return Belief(
            predicted=committed_pred,
            confidence=conf,
            model_error=model_error,
            committed_values={"t": float(t)},
        )

    def _all_evidence(
        self, observation: Observation, prior: float
    ) -> List[Dict[str, Any]]:
        """Reduce every observable source to a signed evidence record.

        Each record: ``{signal, source, imperfection, value, error_source,
        weight}``.  Sources: price (public_tape), official_claim, own
        inventory glut, invisible aggregates.  The belief update aggregates
        them in parallel (user-example structure).
        """
        out: List[Dict[str, Any]] = []

        price_field = observation.field("price")
        if price_field is not None and price_field.value is not None:
            val = price_field.value
            if self._price_memory:
                last = self._price_memory[-1]
                sig = _sign(val - last) * min(
                    1.0, abs(val - last) / max(1.0, abs(last)))
            else:
                sig = 0.0
            err = ""
            if price_field.imperfection in ("noisy", "delayed+noisy"):
                err = "perception_error"
            confirms = (sig == 0) or (prior == 0) or (sig > 0) == (prior > 0)
            out.append({
                "signal": sig,
                "source": price_field.source,
                "imperfection": price_field.imperfection,
                "value": val,
                "error_source": err,
                "weight": self.profile.evidence_weight_for(
                    price_field.source, confirms),
            })

        claim_field = observation.field("official_claim")
        if claim_field is not None:
            bullish = (self.profile.stubbornness > 0.4
                       and self.profile.greed > 0.5)
            sig = 0.5 if bullish else 0.0
            err = "cognitive_bias" if bullish else ""
            confirms = (sig == 0) or (prior == 0) or (sig > 0) == (prior > 0)
            out.append({
                "signal": sig,
                "source": "official",
                "imperfection": "interpretation_bias",
                "value": None,
                "error_source": err,
                "weight": self.profile.evidence_weight_for("official", confirms),
            })

        own_inv_field = observation.field("own_inventory")
        if own_inv_field is not None and own_inv_field.value is not None:
            inv = float(own_inv_field.value)
            glut = max(0.0, inv - 20.0) / 20.0
            sig = -min(1.0, glut)
            confirms = (sig == 0) or (prior == 0) or (sig > 0) == (prior > 0)
            w = (self.profile.base.evidence_weight
                 * (0.2 + self.profile.loss_aversion))
            if not confirms:
                w *= (1.0 - self.profile.stubbornness * 0.7)
            out.append({
                "signal": sig,
                "source": "own_ledger",
                "imperfection": "exact",
                "value": inv,
                "error_source": "",
                "weight": max(0.0, w),
            })

        agg_field = observation.field("supply")
        if agg_field is not None and agg_field.imperfection == "invisible":
            out.append({
                "signal": 0.0,
                "source": "aggregate",
                "imperfection": "invisible",
                "value": None,
                "error_source": "information_error",
                "weight": 0.0,
            })

        return out

    def _personality_modifier_label(
        self, source: str, confirms_prior: bool, w: float
    ) -> str:
        parts: List[str] = []
        if source == "official":
            parts.append(f"official_trust×{0.5 + self.profile.official_trust:.2f}")
        elif source == "rumour":
            parts.append(f"rumour_trust×{0.5 + self.profile.rumour_trust:.2f}")
        if not confirms_prior and self.profile.stubbornness > 0:
            parts.append(
                f"stubborn×{1 - self.profile.stubbornness * 0.7:.2f} (disconfirming)")
        if not parts:
            return "neutral"
        return ", ".join(parts) + f" → w={w:.3f}"


def _sigmoid(x: float) -> float:
    try:
        return 1.0 / (1.0 + math.exp(-max(-60.0, min(60.0, float(x)))))
    except (OverflowError, ValueError):
        return 0.0 if x < 0 else 1.0


def _sign(x: float) -> float:
    if x > 1e-9:
        return 1.0
    if x < -1e-9:
        return -1.0
    return 0.0


def _softmax_sample(
    scores: Dict[str, float], temperature: float, rng: random.Random
) -> str:
    """Sample a verb from ``softmax(scores / T)``.

    ``T → 0`` → argmax (greedy); large ``T`` → uniform (impulsive).
    Deterministic given ``rng``.
    """
    if temperature <= 1e-6:
        best = max(scores.items(), key=lambda kv: kv[1])
        return best[0]
    items = list(scores.items())
    mx = max(v for _, v in items) if items else 0.0
    weights = [math.exp((v - mx) / temperature) for _, v in items]
    total = sum(weights)
    if total <= 0:
        return items[0][0] if items else "hold"
    r = rng.random() * total
    acc = 0.0
    for (verb, _), w in zip(items, weights):
        acc += w
        if r <= acc:
            return verb
    return items[-1][0]
