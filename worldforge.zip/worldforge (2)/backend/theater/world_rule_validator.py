"""Dynamic validator for LLM-authored world rules (张力1 / spec §8.2 I2).

Counterpart to :mod:`theater.gameplay_validator` (which动态验收玩法规则四
项硬门).  Before this module, :class:`RuleCompiler.validate_spec` only did
*static* syntax checks on a :class:`WorldKernelSpec` — yet world rules have
larger blast radius than gameplay rules.  This module adds the missing
*dynamic* acceptance gate: after compile, run N dry-run beats over seeded
initial states and check the invariants survive, the state does not diverge
to NaN/inf, and numeric fields do not explode past a tolerance.

The validator is pure-stdlib, deterministic given a seed, and never calls an
LLM. On failure it returns a :class:`WorldRuleValidationReport` whose
``reasons`` can be fed back to the LLM for an explicit repair attempt. A
failed report must not install substitute rules.

Public surface:
    - :class:`WorldRuleValidator`
    - :class:`WorldRuleValidationReport`
"""
from __future__ import annotations

import copy
import math
import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .world_kernel_host import (
    DSLError,
    RuleCompiler,
    WorldKernelHost,
    WorldKernelSpec,
)


__all__ = ["WorldRuleValidator", "WorldRuleValidationReport"]


# Numeric magnitude above which we consider a state value to have "exploded".
# Conservative: a well-designed world rule should not push any single scalar
# past 1e12 within DEFAULT_BEATS ticks.  Tunable per-call.
_DEFAULT_EXPLOSION_LIMIT = 1e12
_DEFAULT_BEATS = 16
_DEFAULT_SEEDS = 3


@dataclass
class WorldRuleValidationReport:
    """Aggregate report for :meth:`WorldRuleValidator.validate`."""

    passed: bool
    checks: Dict[str, "CheckResult"] = field(default_factory=dict)
    reasons: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": {
                k: {"passed": v.passed, "reason": v.reason, "details": v.details}
                for k, v in self.checks.items()
            },
            "reasons": list(self.reasons),
        }


@dataclass
class CheckResult:
    passed: bool
    reason: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


class WorldRuleValidator:
    """Dynamic acceptance gate for a compiled :class:`WorldKernelSpec`.

    Four hard checks (mirroring the spirit of §9.2's gameplay gates but
    adapted to world rules — world rules don't have legal-actions/terminal
    structure; they have invariants + state evolution):

      1. **compiles**        — the spec statically validates + compiles
                               (cheap precondition; surfaces LLM syntax bugs).
      2. **invariants hold** — after N dry-run beats, every ``invariant``
                               rule's predicate is still truthy.
      3. **no divergence**   — no state numeric goes NaN/inf.
      4. **bounded growth**  — no state numeric explodes past
                               ``explosion_limit`` within N beats (catches
                               e.g. ``population *= 2`` every tick).

    All checks are deterministic given the seed; no LLM, no network.
    """

    def __init__(self, seed: int = 42) -> None:
        self._seed = seed

    # ------------------------------------------------------------------
    # public
    # ------------------------------------------------------------------

    def validate(
        self,
        spec: WorldKernelSpec,
        *,
        beats: int = _DEFAULT_BEATS,
        seeds: int = _DEFAULT_SEEDS,
        explosion_limit: float = _DEFAULT_EXPLOSION_LIMIT,
        require_all_seeds: bool = False,
    ) -> WorldRuleValidationReport:
        """Run all four dynamic checks; return the aggregate report.

        Parameters
        ----------
        beats, seeds, explosion_limit:
            Dry-run shape. Seed 0 is the spec's declared initial_state
            verbatim; seeds 1..N are numeric perturbations.
        require_all_seeds:
            When False (default), only seed 0 (the LLM's declared starting
            point) must pass — perturbed seeds surface as non-blocking
            ``warnings``. When True, every seed must pass. The default keeps
            the gate strict on the declared contract without rejecting
            well-formed presets whose invariants are fragile under extreme
            perturbation (e.g. price going negative when supply >> demand).
        """
        report = WorldRuleValidationReport(passed=True)
        warnings: List[str] = []

        # CHECK 1: compiles (static gate as precondition).
        compiler = RuleCompiler()
        issues = compiler.validate_spec(spec)
        if issues:
            r = CheckResult(False, "static validation failed",
                            {"issues": list(issues)})
            report.checks["compiles"] = r
            report.passed = False
            report.reasons.append(f"compiles: {r.reason} ({'; '.join(issues)})")
            return report
        try:
            compiler.compile(spec)
        except Exception as exc:  # pragma: no cover — validate_spec guards it
            r = CheckResult(False, f"compile raised: {exc}", {})
            report.checks["compiles"] = r
            report.passed = False
            report.reasons.append(f"compiles: {r.reason}")
            return report
        report.checks["compiles"] = CheckResult(True, "spec compiles")

        # Run the dynamic checks over a few seeded initial states. Seed 0 is
        # the spec's *unperturbed* initial_state (the LLM's declared starting
        # point); the rest are perturbed variants. Invariant failures are
        # only counted when the invariant held at t=0 *and* broke during play
        # — a perturbation that breaks an invariant at t=0 is a seed artifact,
        # not a rule defect.
        invariant_failures: List[str] = []
        divergence_failures: List[str] = []
        explosion_failures: List[str] = []
        for i in range(max(1, seeds)):
            seed_i = self._seed + i
            init = self._initial_state(spec, seed_i, perturb=(i != 0))
            try:
                host = WorldKernelHost(spec, copy.deepcopy(init), seed=seed_i)
            except Exception as exc:
                report.passed = False
                report.reasons.append(f"seed[{i}] host build failed: {exc}")
                continue
            inv_before = set(host.check_invariants())
            ok_inv, ok_div, ok_exp, inv_after = self._run_beats(
                host, beats, explosion_limit, seed_index=i)
            new_breaks = inv_after - inv_before
            is_seed0 = (i == 0)
            blocking = is_seed0 or require_all_seeds
            tag = "seed" if is_seed0 else "perturbed seed"
            if new_breaks:
                msg = (f"{tag}[{i}]: invariants {sorted(new_breaks)} broke "
                       f"during {beats} beats (held at t=0)")
                if blocking:
                    invariant_failures.append(msg)
                else:
                    warnings.append(msg)
            if not ok_div:
                msg = f"{tag}[{i}]: state diverged to NaN/inf within {beats} beats"
                if blocking:
                    divergence_failures.append(msg)
                else:
                    warnings.append(msg)
            if not ok_exp:
                msg = (f"{tag}[{i}]: a numeric state value exceeded "
                       f"{explosion_limit} within {beats} beats (unbounded growth)")
                if blocking:
                    explosion_failures.append(msg)
                else:
                    warnings.append(msg)

        report.checks["invariants_hold"] = CheckResult(
            not invariant_failures,
            "all invariants hold after dry-run" if not invariant_failures
            else "; ".join(invariant_failures),
            {"failures": invariant_failures},
        )
        report.checks["no_divergence"] = CheckResult(
            not divergence_failures,
            "no NaN/inf" if not divergence_failures
            else "; ".join(divergence_failures),
            {"failures": divergence_failures},
        )
        report.checks["bounded_growth"] = CheckResult(
            not explosion_failures,
            "growth bounded" if not explosion_failures
            else "; ".join(explosion_failures),
            {"failures": explosion_failures},
        )
        for name, failures in (
            ("invariants_hold", invariant_failures),
            ("no_divergence", divergence_failures),
            ("bounded_growth", explosion_failures),
        ):
            if failures:
                report.passed = False
                report.reasons.append(
                    f"{name}: {report.checks[name].reason}")
        if warnings:
            # Non-blocking: perturbed-seed fragility is surfaced for the LLM
            # repair loop / human review but does not reject the spec.
            report.checks["perturbed_warnings"] = CheckResult(
                True, f"{len(warnings)} non-blocking perturbed-seed warning(s)",
                {"warnings": warnings})
        return report

    # ------------------------------------------------------------------
    # internals
    # ------------------------------------------------------------------

    def _initial_state(self, spec: WorldKernelSpec, seed: int,
                       *, perturb: bool = True) -> Dict[str, Any]:
        """Build an initial state. When *perturb* is False (seed 0), return
        the spec's declared initial_state verbatim — the LLM's starting point
        must be runnable as-is. When True, apply small numeric perturbations
        so the dry-run exercises the rules under slight variation."""
        base = copy.deepcopy(dict(getattr(spec, "initial_state", {}) or {}))
        if perturb:
            rng = random.Random(seed)
            self._perturb(base, rng)
        return base

    def _perturb(self, state: Any, rng: random.Random) -> None:
        """In-place numeric perturbation of a nested state dict."""
        if isinstance(state, dict):
            for k, v in list(state.items()):
                if isinstance(v, bool):
                    continue
                if isinstance(v, int):
                    state[k] = max(0, v + rng.choice([-2, -1, 1, 2]))
                elif isinstance(v, float):
                    state[k] = max(0.0, v + rng.uniform(-1.0, 1.0))
                elif isinstance(v, dict):
                    self._perturb(v, rng)
        # lists / scalars left alone

    def _run_beats(
        self, host: WorldKernelHost, beats: int,
        explosion_limit: float, *, seed_index: int,
    ) -> Tuple[bool, bool, bool, set]:
        """Run ``beats`` turn.tick events.

        Returns ``(invariants_ok, no_div, bounded, failing_invariants_after)``.
        ``failing_invariants_after`` is the set of invariant rule_ids that are
        violated after the run (caller diffs against t=0 to decide whether
        the *rules* broke them or the seed did).
        """
        no_divergence = True
        bounded = True
        stopped_early = False
        for step in range(max(1, beats)):
            try:
                host.step({"trigger": "turn.tick", "payload": {}})
            except DSLError:
                continue
            except Exception:
                no_divergence = False
                stopped_early = True
                break
            state = host.state()
            if not _state_finite(state):
                no_divergence = False
                stopped_early = True
                break
            if _state_exploded(state, explosion_limit):
                bounded = False
                stopped_early = True
                break
        failing_after = set(host.check_invariants())
        # invariants_ok = no NEW break happened during beats AND none still
        # failing if they were green at t=0 (caller computes "new"). We return
        # the raw set and let the caller diff. For the boolean, True means
        # "no break observed this run" — caller refines.
        invariants_ok = not failing_after
        return invariants_ok, no_divergence, bounded, failing_after


def _state_finite(state: Any) -> bool:
    """True iff every numeric leaf is finite (not NaN, not inf)."""
    if isinstance(state, bool):
        return True
    if isinstance(state, (int, float)):
        return math.isfinite(float(state))
    if isinstance(state, dict):
        return all(_state_finite(v) for v in state.values())
    if isinstance(state, list):
        return all(_state_finite(v) for v in state)
    return True


def _state_exploded(state: Any, limit: float) -> bool:
    """True iff any numeric leaf magnitude exceeds *limit*."""
    if isinstance(state, bool):
        return False
    if isinstance(state, (int, float)):
        return abs(float(state)) > limit
    if isinstance(state, dict):
        return any(_state_exploded(v, limit) for v in state.values())
    if isinstance(state, list):
        return any(_state_exploded(v, limit) for v in state)
    return False
