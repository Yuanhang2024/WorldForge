"""Out-of-library gameplay validator (spec §9.2 — 库外玩法).

When a user's gameplay request does not match any parameterized kernel in
:mod:`backend.theater.game_kernels`, an LLM may *offline* author a rules JSON
describing a new game.  Before that JSON is ever allowed into runtime, it MUST
pass the four hard gates mandated by spec §9.2:

  1. **legal action generator** — every non-terminal state has ≥1 legal action.
  2. **termination**            — from any sampled initial state, play always
                                   terminates within ``max_steps`` (no infinite
                                   loops).
  3. **no dominant pure strategy** — no single pure strategy wins 100% of
                                   sampled games (strong strategies are ok;
                                   *guaranteed* wins are not).
  4. **no deadlock**             — every non-terminal state can advance (no
                                   state where the only legal actions all lead
                                   back to a previously-visited state with no
                                   progress — here approximated by "non-terminal
                                   ⇒ ≥1 action that changes state").

The validator NEVER evaluates arbitrary Python.  GameplaySpec rules are
expressed in a restricted, deterministic pseudo-DSL (subset of the §8 AST
whitelist: ``add/sub/mul/div/lt/gt/eq/and/or/not/if/sum/avg/min/max/clamp``).
No ``eval``, no ``exec``, no ``__import__`` (§12.1 安全红线).

Pure stdlib; no external deps; unit-testable in isolation.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple


__all__ = [
    "GameplaySpec",
    "GameplayValidator",
    "CheckResult",
    "ValidationReport",
    "ExprEvalError",
]


# ---------------------------------------------------------------------------
# Restricted expression whitelist (subset of §8 AST whitelist)
# ---------------------------------------------------------------------------
#
# We deliberately EXCLUDE ``random_in_range`` here — gameplay rules must be
# deterministic given state + action (any randomness lives in the action
# generator / bot, not the rule payoff).  This keeps the validator's
# termination argument tractable.

_ALLOWED_OPS = {
    "add", "sub", "mul", "div", "neg", "min", "max", "clamp",
    "lt", "gt", "eq", "le", "ge",
    "and", "or", "not",
    "if",
    "sum", "avg",
}

# Max AST depth — bounds recursion so evaluation always terminates.
_MAX_DEPTH = 64


class ExprEvalError(ValueError):
    """Raised when a gameplay expression AST cannot be evaluated safely."""


def _eval_expr(node: Any, state: Dict[str, Any], depth: int = 0) -> Any:
    """Evaluate a restricted-expression AST against *state*.

    Nodes:
      - scalars (int/float/bool/None) → returned as-is
      - ``{"const": v}``               → v
      - ``{"ref": "path"}``            → state lookup (dotted path walks dicts)
      - ``{"op": "add", "args": [...]}`` → whitelisted operator
    """
    if depth > _MAX_DEPTH:
        raise ExprEvalError(f"expression depth exceeds {_MAX_DEPTH}")
    if isinstance(node, bool) or isinstance(node, (int, float)) or node is None:
        return node
    if isinstance(node, str):
        # bare string = ref by dotted path
        return _lookup(node, state)
    if not isinstance(node, dict):
        raise ExprEvalError(f"unsupported AST node type: {type(node).__name__}")
    if "const" in node and "op" not in node:
        return node["const"]
    if "ref" in node and "op" not in node:
        return _lookup(node["ref"], state)
    op = node.get("op")
    if op is None:
        raise ExprEvalError("AST node missing 'op'")
    # Leaf ops that read state — accepted even though not in _ALLOWED_OPS
    # (they're data access, not computation).
    if op == "const":
        return node.get("value")
    if op == "ref":
        return _lookup(node.get("path", ""), state)
    if op == "lookup":
        p = node.get("path")
        if not isinstance(p, str):
            args = node.get("args", [])
            p = args[0] if args else ""
        return _lookup(p, state)
    if op not in _ALLOWED_OPS:
        raise ExprEvalError(f"op {op!r} not in gameplay whitelist")
    args = node.get("args", [])
    if not isinstance(args, list):
        raise ExprEvalError(f"op {op!r} args must be a list")

    def _a(i: int) -> Any:
        return _eval_expr(args[i], state, depth + 1)

    if op == "add":
        return _num(_a(0)) + _num(_a(1))
    if op == "sub":
        return _num(_a(0)) - _num(_a(1))
    if op == "mul":
        return _num(_a(0)) * _num(_a(1))
    if op == "div":
        d = _num(_a(1))
        if d == 0:
            return 0
        return _num(_a(0)) / d
    if op == "neg":
        return -_num(_a(0))
    if op == "min":
        return min(_a(0), _a(1))
    if op == "max":
        return max(_a(0), _a(1))
    if op == "clamp":
        # {"op":"clamp","args":[value, lo, hi]}
        v = _a(0)
        lo = _a(1)
        hi = _a(2)
        return max(lo, min(hi, v))
    if op == "lt":
        return _a(0) < _a(1)
    if op == "gt":
        return _a(0) > _a(1)
    if op == "eq":
        return _a(0) == _a(1)
    if op == "le":
        return _a(0) <= _a(1)
    if op == "ge":
        return _a(0) >= _a(1)
    if op == "and":
        return bool(_a(0)) and bool(_a(1))
    if op == "or":
        return bool(_a(0)) or bool(_a(1))
    if op == "not":
        return not bool(_a(0))
    if op == "if":
        # if(cond, then, else)
        return _a(1) if bool(_a(0)) else _a(2)
    if op == "sum":
        lst = _a(0)
        if not isinstance(lst, list):
            raise ExprEvalError("sum expects a list")
        return sum(_num(x) for x in lst)
    if op == "avg":
        lst = _a(0)
        if not isinstance(lst, list):
            raise ExprEvalError("avg expects a list")
        if not lst:
            return 0
        return sum(_num(x) for x in lst) / len(lst)
    # Unreachable — op checked against whitelist above.
    raise ExprEvalError(f"unhandled op {op!r}")


def _num(x: Any) -> float:
    if isinstance(x, bool):
        return 1.0 if x else 0.0
    if isinstance(x, (int, float)):
        return float(x)
    if x is None:
        return 0.0
    raise ExprEvalError(f"expected number, got {type(x).__name__}")


def _lookup(path: str, state: Dict[str, Any]) -> Any:
    """Walk a dotted path through nested dicts; missing → 0."""
    if not path:
        return 0
    cur: Any = state
    for part in path.split("."):
        if isinstance(cur, dict):
            if part in cur:
                cur = cur[part]
            else:
                return 0
        elif isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return 0
        else:
            return 0
    return cur


# ---------------------------------------------------------------------------
# GameplaySpec
# ---------------------------------------------------------------------------


@dataclass
class GameplaySpec:
    """Structured, JSON-serializable description of a gameplay ruleset.

    This is the payload an LLM emits (offline) and the validator consumes.
    It is intentionally a *declarative* description — no executable Python.

    Attributes:
        name:           snake_case identifier.
        description:    free-text human-readable summary.
        state_schema:   dict describing the initial state shape; used as the
                        base initial state for validator simulations.  Keys
                        are dotted paths; values are defaults.  The validator
                        also synthesises variants (e.g. perturbed numeric
                        fields) to sample multiple initial states.
        legal_actions:  a restricted-expression AST that, given a state,
                        evaluates to a **list of action descriptor dicts**.
                        Each action descriptor has at minimum an ``id`` string;
                        the validator uses ``apply`` to advance the state.
                        Alternatively, a literal list of action descriptors
                        with embedded ``condition`` ASTs (evaluated against
                        the state) — this is the form LLMs find natural.
        terminal:       restricted-expression AST → bool.  True iff game over.
        payoff:         restricted-expression AST → number, OR a dict of
                        player_id → AST.  Higher = better for that player.
        parameters:     extra config (num_players, max_turns, etc.).
        apply:          a dict mapping action_id → restricted-expression AST
                        that *modifies* state.  The AST form is
                        ``{"set": "path", "value": <AST>}`` (one write) or
                        ``{"writes": [{...}, ...]}`` (multi-write).  Each
                        write's ``value`` is an AST evaluated against the
                        *current* state.  This keeps apply deterministic and
                        side-effect-free (no eval).
    """

    name: str
    description: str = ""
    state_schema: Dict[str, Any] = field(default_factory=dict)
    legal_actions: Any = None          # AST or list-of-descriptors
    terminal: Any = None               # AST → bool
    payoff: Any = None                 # AST → number, or {player: AST}
    parameters: Dict[str, Any] = field(default_factory=dict)
    apply: Dict[str, Any] = field(default_factory=dict)

    # -- serialization ------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "state_schema": dict(self.state_schema),
            "legal_actions": self.legal_actions,
            "terminal": self.terminal,
            "payoff": self.payoff,
            "parameters": dict(self.parameters),
            "apply": dict(self.apply),
        }

    @classmethod
    def from_dict(cls, obj: Dict[str, Any]) -> "GameplaySpec":
        return cls(
            name=str(obj.get("name", "")),
            description=str(obj.get("description", "")),
            state_schema=dict(obj.get("state_schema", {}) or {}),
            legal_actions=obj.get("legal_actions"),
            terminal=obj.get("terminal"),
            payoff=obj.get("payoff"),
            parameters=dict(obj.get("parameters", {}) or {}),
            apply=dict(obj.get("apply", {}) or {}),
        )

    def to_json_safe(self) -> Dict[str, Any]:
        """Return a JSON-safe dict (caller does json.dumps)."""
        return self.to_dict()


# ---------------------------------------------------------------------------
# Check results
# ---------------------------------------------------------------------------


@dataclass
class CheckResult:
    """Outcome of a single validation check."""
    passed: bool
    reason: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ValidationReport:
    """Aggregate report for :meth:`GameplayValidator.validate_all`."""
    passed: bool
    checks: Dict[str, CheckResult] = field(default_factory=dict)
    reasons: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": {
                k: {"passed": v.passed, "reason": v.reason,
                    "details": v.details}
                for k, v in self.checks.items()
            },
            "reasons": list(self.reasons),
        }


# ---------------------------------------------------------------------------
# GameplayValidator
# ---------------------------------------------------------------------------


class GameplayValidator:
    """Four hard gates (spec §9.2) for an LLM-authored GameplaySpec.

    All checks are pure-Python simulations over the spec's restricted DSL.
    No LLM, no network, no eval — fully deterministic given a seed.
    """

    def __init__(self, seed: int = 42) -> None:
        self._seed = seed

    # -- expression evaluation (restricted DSL) -----------------------------

    @staticmethod
    def eval_expr(node: Any, state: Dict[str, Any]) -> Any:
        """Evaluate a restricted-expression AST (public for tests)."""
        return _eval_expr(node, state)

    # -- state helpers ------------------------------------------------------

    def _initial_state(self, spec: GameplaySpec) -> Dict[str, Any]:
        """Build the base initial state from spec.state_schema (nested)."""
        flat = spec.state_schema or {}
        state: Dict[str, Any] = {}
        for k, v in flat.items():
            _set_path(state, k, v)
        return state

    def _sample_initial_states(
        self, spec: GameplaySpec, n: int = 4
    ) -> List[Dict[str, Any]]:
        """Generate *n* initial states: base + a few numeric perturbations."""
        rng = random.Random(self._seed)
        base = self._initial_state(spec)
        states: List[Dict[str, Any]] = [base]
        for _ in range(max(0, n - 1)):
            variant = _deep_copy_state(base)
            numeric_paths = _collect_numeric_paths(base)
            if numeric_paths:
                # perturb 1-2 numeric fields
                for _ in range(rng.randint(1, 2)):
                    p = rng.choice(numeric_paths)
                    cur = _lookup(p, variant)
                    if isinstance(cur, bool):
                        new = cur
                    elif isinstance(cur, int):
                        delta = rng.choice([-2, -1, 1, 2])
                        new = max(0, cur + delta)
                    elif isinstance(cur, float):
                        new = max(0.0, cur + rng.uniform(-1.0, 1.0))
                    else:
                        continue
                    _set_path(variant, p, new)
            states.append(variant)
        return states

    # -- legal actions ------------------------------------------------------

    def legal_actions(self, spec: GameplaySpec, state: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Compute the list of legal action descriptors for *state*.

        Supports two forms for ``spec.legal_actions``:

        1. **List of descriptors** (LLM-natural).  Each descriptor is a dict
           with an ``id`` and an optional ``condition`` AST.  Descriptors
           whose condition evaluates truthy (or which have no condition) are
           legal.
        2. **AST** evaluating to a list of descriptors.
        """
        la = spec.legal_actions
        if la is None:
            return []
        if isinstance(la, list):
            out: List[Dict[str, Any]] = []
            for entry in la:
                if not isinstance(entry, dict):
                    continue
                cond = entry.get("condition")
                if cond is None:
                    out.append(entry)
                    continue
                try:
                    ok = bool(_eval_expr(cond, state))
                except ExprEvalError:
                    ok = False
                if ok:
                    out.append(entry)
            return out
        # AST form → evaluate to a list
        try:
            result = _eval_expr(la, state)
        except ExprEvalError:
            return []
        if not isinstance(result, list):
            return []
        return [e for e in result if isinstance(e, dict)]

    # -- apply an action ----------------------------------------------------

    def _apply(self, spec: GameplaySpec, state: Dict[str, Any],
               action: Dict[str, Any]) -> Dict[str, Any]:
        """Return a *new* state after applying *action*.

        Looks up ``spec.apply[action_id]``.  The apply-rule is either:
          - ``{"set": "path", "value": <AST>}``  (single write)
          - ``{"writes": [{"path","value"}, ...]}`` (multi-write)
          - ``None`` / missing → state unchanged (a "pass" action)
        """
        new_state = _deep_copy_state(state)
        action_id = str(action.get("id", ""))
        rule = spec.apply.get(action_id)
        if rule is None:
            return new_state
        if not isinstance(rule, dict):
            return new_state
        writes: List[Dict[str, Any]] = []
        if "writes" in rule and isinstance(rule["writes"], list):
            for w in rule["writes"]:
                if isinstance(w, dict):
                    writes.append(w)
        elif "set" in rule or "path" in rule:
            writes.append(rule)
        for w in writes:
            path = w.get("set") or w.get("path")
            if not isinstance(path, str):
                continue
            value_node = w.get("value")
            try:
                value = _eval_expr(value_node, new_state)
            except ExprEvalError:
                value = 0
            _set_path(new_state, path, value)
        return new_state

    def _is_terminal(self, spec: GameplaySpec, state: Dict[str, Any]) -> bool:
        if spec.terminal is None:
            return False
        try:
            return bool(_eval_expr(spec.terminal, state))
        except ExprEvalError:
            return False

    # -- payoff -------------------------------------------------------------

    def _payoff(self, spec: GameplaySpec, state: Dict[str, Any]) -> Dict[str, float]:
        """Return {player_id: payoff_number}.  If payoff is a single AST,
        the result is keyed under ``"p1"`` (single-player convention)."""
        if spec.payoff is None:
            return {}
        if isinstance(spec.payoff, dict) and "op" not in spec.payoff and "const" not in spec.payoff and "ref" not in spec.payoff:
            # dict of player → AST
            out: Dict[str, float] = {}
            for player, ast in spec.payoff.items():
                try:
                    out[player] = float(_eval_expr(ast, state))
                except (ExprEvalError, ValueError, TypeError):
                    out[player] = 0.0
            return out
        try:
            v = float(_eval_expr(spec.payoff, state))
        except (ExprEvalError, ValueError, TypeError):
            v = 0.0
        return {"p1": v}

    # =====================================================================
    # CHECK 1: legal action generator
    # =====================================================================

    def check_legal_action_generator(self, spec: GameplaySpec) -> CheckResult:
        """Every non-terminal state sampled must have ≥1 legal action."""
        states = self._sample_initial_states(spec, n=4)
        for state in states:
            # If already terminal at init, legal_actions may be empty — ok.
            if self._is_terminal(spec, state):
                continue
            actions = self.legal_actions(spec, state)
            if not actions:
                return CheckResult(
                    passed=False,
                    reason="non-terminal initial state has no legal actions",
                    details={"state": _state_snapshot(state)},
                )
            # Also check 1-2 reachable successors to catch early dead-ends.
            for a in actions[:2]:
                succ = self._apply(spec, state, a)
                if self._is_terminal(spec, succ):
                    continue
                if not self.legal_actions(spec, succ):
                    return CheckResult(
                        passed=False,
                        reason="reachable non-terminal state has no legal actions",
                        details={"state": _state_snapshot(succ),
                                 "from_action": a.get("id")},
                    )
        return CheckResult(passed=True, reason="all sampled non-terminal states have legal actions")

    # =====================================================================
    # CHECK 2: termination
    # =====================================================================

    def check_termination(self, spec: GameplaySpec, max_steps: int = 1000) -> CheckResult:
        """From each sampled initial state, greedy + random play must
        terminate within *max_steps* (no infinite loop)."""
        states = self._sample_initial_states(spec, n=4)
        for i, state in enumerate(states):
            rng = random.Random(self._seed + i)
            steps = 0
            cur = state
            visited_hashes = set()
            while not self._is_terminal(spec, cur):
                if steps >= max_steps:
                    return CheckResult(
                        passed=False,
                        reason=f"did not terminate within {max_steps} steps",
                        details={"start_state_index": i,
                                 "steps": steps,
                                 "last_state": _state_snapshot(cur)},
                    )
                actions = self.legal_actions(spec, cur)
                if not actions:
                    # Dead-end non-terminal → not terminating.  Fail.
                    return CheckResult(
                        passed=False,
                        reason="reached non-terminal state with no legal actions (non-terminating)",
                        details={"state": _state_snapshot(cur),
                                 "start_state_index": i,
                                 "steps": steps},
                    )
                # Detect cycles: hash state + step count window.
                h = _state_hash(cur)
                if h in visited_hashes:
                    # seen this exact state before within the run → cycle
                    return CheckResult(
                        passed=False,
                        reason="detected a recurring state (cycle) before termination",
                        details={"state": _state_snapshot(cur),
                                 "start_state_index": i,
                                 "steps": steps},
                    )
                visited_hashes.add(h)
                # Pick an action: alternate greedy-first + random to cover branches.
                if rng.random() < 0.5:
                    a = actions[0]
                else:
                    a = rng.choice(actions)
                cur = self._apply(spec, cur, a)
                steps += 1
        return CheckResult(passed=True, reason="all sampled games terminated within max_steps")

    # =====================================================================
    # CHECK 3: no dominant pure strategy
    # =====================================================================

    def check_no_dominant_strategy(self, spec: GameplaySpec, samples: int = 200) -> CheckResult:
        """No single pure strategy wins 100% of sampled decided games.

        We define a small population of pure strategies (first, last, random)
        and cross-play them pairwise on the SAME seed (deterministic replay ⇒
        fair comparison).  A strategy that wins **every** decided game it
        participates in is a 必胜纯策略 and fails the check.  Ties and
        non-terminating games are skipped (don't count for or against).
        """
        strategies: List[Tuple[str, Callable[[List[Dict[str, Any]], random.Random], Dict[str, Any]]]] = [
            ("first", lambda acts, rng: acts[0]),
            ("last", lambda acts, rng: acts[-1]),
            ("random", lambda acts, rng: rng.choice(acts)),
        ]
        wins: Dict[str, int] = {name: 0 for name, _ in strategies}
        played: Dict[str, int] = {name: 0 for name, _ in strategies}
        decided: int = 0
        for i in range(samples):
            s_a = strategies[i % len(strategies)]
            s_b = strategies[(i + 1) % len(strategies)]
            seed = self._seed + i * 7
            try:
                pay_a = self._playout(spec, s_a[1], seed)
                pay_b = self._playout(spec, s_b[1], seed)
            except _PlayoutNonTerminating:
                continue
            if pay_a is None or pay_b is None:
                continue
            if pay_a == pay_b:
                continue  # tie — not a decided game; doesn't count either way
            decided += 1
            # Only decided games count toward a strategy's played record.
            played[s_a[0]] += 1
            played[s_b[0]] += 1
            if pay_a > pay_b:
                wins[s_a[0]] += 1
            else:
                wins[s_b[0]] += 1
        if decided == 0:
            # No decided games — dominance undetermined; pass conservatively
            # (the termination check separately enforces non-triviality).
            return CheckResult(passed=True,
                               reason="no decided games; dominance undetermined (pass)",
                               details={"samples": samples})
        for name in wins:
            # A dominant pure strategy wins 100% of the decided games it played.
            if played[name] > 0 and wins[name] == played[name]:
                return CheckResult(
                    passed=False,
                    reason=f"pure strategy {name!r} won {wins[name]}/{played[name]} decided games (dominant)",
                    details={"wins": wins, "played": played, "decided": decided,
                             "samples": samples},
                )
        return CheckResult(passed=True,
                           reason="no pure strategy won 100% of its decided games",
                           details={"wins": wins, "played": played, "decided": decided})

    def _playout(self, spec: GameplaySpec,
                 strat_fn: Callable[[List[Dict[str, Any]], random.Random], Dict[str, Any]],
                 seed: int, max_steps: int = 200) -> Optional[float]:
        """Run one game with *strat_fn*, return the single-player payoff
        (``p1``) or None if undeterminable.  Raises _PlayoutNonTerminating
        if the game does not end within max_steps."""
        rng = random.Random(seed)
        state = self._initial_state(spec)
        steps = 0
        while not self._is_terminal(spec, state):
            if steps >= max_steps:
                raise _PlayoutNonTerminating()
            actions = self.legal_actions(spec, state)
            if not actions:
                break
            a = strat_fn(actions, rng)
            state = self._apply(spec, state, a)
            steps += 1
        pay = self._payoff(spec, state)
        return pay.get("p1")

    # =====================================================================
    # CHECK 4: no deadlock
    # =====================================================================

    def check_no_deadlock(self, spec: GameplaySpec) -> CheckResult:
        """No reachable non-terminal state is a dead-end (zero legal actions),
        AND at least one terminal state is reachable (so the game can always
        make progress toward ending).  Bounded BFS from sampled starts."""
        states = self._sample_initial_states(spec, n=3)
        for i, start in enumerate(states):
            if self._is_terminal(spec, start):
                continue
            seen_hashes = {_state_hash(start)}
            # frontier of non-terminal states still to expand
            frontier: List[Dict[str, Any]] = [start]
            reached_terminal = False
            expanded = 0
            while frontier and expanded < 200:
                cur = frontier.pop(0)
                expanded += 1
                if self._is_terminal(spec, cur):
                    reached_terminal = True
                    continue
                actions = self.legal_actions(spec, cur)
                if not actions:
                    return CheckResult(
                        passed=False,
                        reason="non-terminal state has no legal actions (deadlock)",
                        details={"state": _state_snapshot(cur),
                                 "start_state_index": i},
                    )
                for a in actions:
                    succ = self._apply(spec, cur, a)
                    h = _state_hash(succ)
                    if h not in seen_hashes:
                        seen_hashes.add(h)
                        if self._is_terminal(spec, succ):
                            reached_terminal = True
                        else:
                            frontier.append(succ)
            if not reached_terminal:
                return CheckResult(
                    passed=False,
                    reason="no terminal state reachable from start within BFS bound (non-terminating region / deadlock)",
                    details={"start_state_index": i,
                             "state": _state_snapshot(start),
                             "expanded": expanded},
                )
        return CheckResult(passed=True, reason="no deadlocks found in sampled states")

    # =====================================================================
    # AGGREGATE
    # =====================================================================

    def validate_all(self, spec: GameplaySpec) -> ValidationReport:
        """Run all four gates.  passed=True only if all pass."""
        legal = self.check_legal_action_generator(spec)
        termination = self.check_termination(spec)
        no_dominant = self.check_no_dominant_strategy(spec)
        no_deadlock = self.check_no_deadlock(spec)
        checks = {
            "legal": legal,
            "termination": termination,
            "no_dominant": no_dominant,
            "no_deadlock": no_deadlock,
        }
        reasons: List[str] = []
        for name, r in checks.items():
            if not r.passed:
                reasons.append(f"{name}: {r.reason}")
        return ValidationReport(
            passed=all(r.passed for r in checks.values()),
            checks=checks,
            reasons=reasons,
        )


# ---------------------------------------------------------------------------
# Internal helpers (state path manipulation)
# ---------------------------------------------------------------------------


class _PlayoutNonTerminating(Exception):
    """Internal sentinel for non-terminating playouts in dominance check."""


def _set_path(state: Dict[str, Any], path: str, value: Any) -> None:
    """Set a dotted path in a nested dict, creating intermediate dicts."""
    parts = path.split(".")
    cur = state
    for part in parts[:-1]:
        if part not in cur or not isinstance(cur[part], dict):
            cur[part] = {}
        cur = cur[part]
    cur[parts[-1]] = value


def _deep_copy_state(state: Dict[str, Any]) -> Dict[str, Any]:
    import copy
    return copy.deepcopy(state)


def _collect_numeric_paths(state: Any, prefix: str = "") -> List[str]:
    out: List[str] = []
    if isinstance(state, dict):
        for k, v in state.items():
            p = f"{prefix}.{k}" if prefix else k
            if isinstance(v, dict):
                out.extend(_collect_numeric_paths(v, p))
            elif isinstance(v, list):
                out.extend(_collect_numeric_paths(v, p))
            elif isinstance(v, (int, float)) and not isinstance(v, bool):
                out.append(p)
            elif isinstance(v, bool):
                out.append(p)
    elif isinstance(state, list):
        for i, v in enumerate(state):
            p = f"{prefix}.{i}" if prefix else str(i)
            if isinstance(v, (dict, list)):
                out.extend(_collect_numeric_paths(v, p))
            elif isinstance(v, (int, float)) and not isinstance(v, bool):
                out.append(p)
    return out


def _state_snapshot(state: Dict[str, Any]) -> Dict[str, Any]:
    """Prune a state to a JSON-safe snapshot for diagnostics."""
    try:
        import copy
        return copy.deepcopy(state)
    except Exception:
        return {}


def _state_hash(state: Any) -> int:
    """Stable hash of a state for cycle detection."""
    import hashlib
    import json
    try:
        s = json.dumps(state, sort_keys=True, default=str)
    except (TypeError, ValueError):
        s = repr(state)
    return int(hashlib.md5(s.encode("utf-8")).hexdigest(), 16)
