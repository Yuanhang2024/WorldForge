"""Two-stage causal narrative (architecture spec §14).

Pipeline::

    Committed Tick → CausalTraceBuilder → LLM Narrative Planner
                  → Causal Validator → Narrative Realizer
                  → Final Consistency Check (NLI guard)

This module is the structural, "compiler-architecture" counterpart to
:mod:`theater.three_body_narrator`.  Where the narrator translates kernel
numbers into prose *in one step*, this module splits the LLM's job in two
(user principle, spec §6):

  - **Stage 1 — NarrativePlanner**: an LLM turns a structured
    :class:`CausalGraph` into a candidate causal explanation
    ``{cause, mechanism, effect, subjective_reason, belief_refs,
    fact_refs, confidence}``.  The LLM only sees the actor's *subjective*
    world (its beliefs / goals / personality), never the kernel's full
    ground truth.
  - **Stage 2 — NarrativeRealizer**: a (possibly different) LLM turns the
    *validator-approved* causal graph + planner explanation into literary
    prose.

Between the two LLM stages sits the :class:`CausalValidator` — a symbolic
checker (no LLM) that rejects explanations a character could not actually
produce: beliefs the character does not hold, actions outside its
permissions, facts outside its observations, or effects that contradict
the kernel outcome. Rejected plans are retried once with feedback; a second
failure aborts generation.

After stage 2 the realized prose is run through the already-committed
:class:`theater.nli_guard.NliGuard` (Q6 first-tier guard) so the text must
bi-entail the approved causal graph's ground-truth claims. A failure rejects
the prose.

Why two stages (research note Q2)
---------------------------------
Yamin et al. show LLMs systematically "correct" counter-intuitive
causation back to common sense.  A one-shot narrator quietly flips
"the civilisation dehydrated correctly but was destroyed anyway" into a
plausible-but-wrong survival story.  The two-stage split with a symbolic
validator in the middle is the upstream structural defence: the LLM never
gets to *decide* the outcome, only to *explain* an outcome the kernel
already fixed, and the validator checks the explanation against the
actor's actual mental state before any prose is written.

§8.2 red line holds throughout: neither LLM stage computes physics or
adjudicates the outcome; the kernel owns the outcome, the validator owns
consistency, the LLMs only narrate.

Pure stdlib + optional ``llm_fn``; no numpy / torch dependency.
``llm_fn`` signature: ``llm_fn(prompt: str) -> str`` (same contract as
:mod:`theater.three_body_narrator`).
"""

from __future__ import annotations

import json
import random
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .nli_guard import NliGuard


__all__ = [
    "EDGE_TYPES",
    "CausalNode",
    "CausalEdge",
    "CausalGraph",
    "CommittedTick",
    "CausalTraceBuilder",
    "CausalPlan",
    "NarrativePlanner",
    "ValidationResult",
    "CausalValidator",
    "NarrativeRealizer",
    "CausalNarrativeEngine",
]


# ---------------------------------------------------------------------------
# Edge vocabulary (spec §15 — six causal edge types)
# ---------------------------------------------------------------------------

#: The six causal edge types a :class:`CausalGraph` may carry.  Kept as a
#: tuple so membership / iteration order is stable.  These are the only
#: legal ``edge_type`` values on a :class:`CausalEdge`.
EDGE_TYPES: Tuple[str, ...] = (
    "physical_cause",     # decision/action → physical outcome (kernel-owned)
    "informational",      # observation/fact → belief (evidence channel)
    "epistemic",          # belief → belief, or belief → decision (belief drove choice)
    "motivational",       # goal/desire → decision
    "social_influence",   # peer belief → actor belief (bounded confidence)
    "institutional",      # permission/rule → decision (authority gate)
)


# ---------------------------------------------------------------------------
# CausalGraph data structures
# ---------------------------------------------------------------------------


@dataclass
class CausalNode:
    """One node in the causal graph.

    ``kind`` is one of ``actor`` / ``belief`` / ``decision`` / ``outcome``
    / ``fact``.  ``ref`` is a stable handle the validator can cross-check
    against an :class:`~theater.sim_agent.AgentMindState` (a belief topic,
    a decision verb, an outcome kind, or a canonical-fact id).
    """

    id: str
    kind: str
    actor_id: str = ""
    ref: str = ""
    summary: str = ""


@dataclass
class CausalEdge:
    """A directed cause → effect edge typed by one of :data:`EDGE_TYPES`."""

    from_id: str
    to_id: str
    edge_type: str
    weight: float = 1.0
    note: str = ""


@dataclass
class CausalGraph:
    """Structured causal skeleton of one committed tick.

    Nodes and edges are stored in *forward topological order*: every edge
    goes from an earlier node to a later node, so iterating ``nodes``
    walks the chain cause-first.  This is the ordering Yamin et al.
    found maximises LLM causal accuracy (forward + short chain).
    """

    tick: int = 0
    nodes: List[CausalNode] = field(default_factory=list)
    edges: List[CausalEdge] = field(default_factory=list)

    # -- accessors ---------------------------------------------------------

    def node(self, node_id: str) -> Optional[CausalNode]:
        for n in self.nodes:
            if n.id == node_id:
                return n
        return None

    def topo_order(self) -> List[str]:
        """Node ids in forward topological order (cause before effect).

        Computed by Kahn's algorithm over ``edges``.  When the graph has
        a cycle (it should not — the builder never creates one) the
        remaining nodes are appended in insertion order so the method
        never raises.
        """
        indeg: Dict[str, int] = {n.id: 0 for n in self.nodes}
        adj: Dict[str, List[str]] = {n.id: [] for n in self.nodes}
        for e in self.edges:
            if e.from_id not in indeg or e.to_id not in indeg:
                continue
            adj[e.from_id].append(e.to_id)
            indeg[e.to_id] += 1
        # Stable: iterate nodes in insertion order so ties break
        # cause-first (the builder inserts causes before effects).
        queue = [n.id for n in self.nodes if indeg[n.id] == 0]
        out: List[str] = []
        while queue:
            nid = queue.pop(0)
            out.append(nid)
            for nxt in adj[nid]:
                indeg[nxt] -= 1
                if indeg[nxt] == 0:
                    queue.append(nxt)
        # Append any cycle-locked nodes in insertion order (defensive).
        for n in self.nodes:
            if n.id not in out:
                out.append(n.id)
        return out

    def ordered_nodes(self) -> List[CausalNode]:
        """Nodes reordered by :meth:`topo_order` (forward causal order)."""
        idx = {n.id: n for n in self.nodes}
        return [idx[nid] for nid in self.topo_order() if nid in idx]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "tick": self.tick,
            "nodes": [
                {"id": n.id, "kind": n.kind, "actor_id": n.actor_id,
                 "ref": n.ref, "summary": n.summary}
                for n in self.nodes
            ],
            "edges": [
                {"from": e.from_id, "to": e.to_id, "type": e.edge_type,
                 "weight": e.weight, "note": e.note}
                for e in self.edges
            ],
        }


# ---------------------------------------------------------------------------
# CommittedTick — the builder's input
# ---------------------------------------------------------------------------


@dataclass
class CommittedTick:
    """Everything a committed tick offers the causal-trace builder.

    All fields are kernel-/rule-engine-owned ground truth or
    :class:`~theater.belief_update.BeliefUpdateTrace` records — never LLM
    free text.  ``actors`` maps actor ids to objects that carry an
    ``AgentMindState`` (``mind_state``) and a ``WorldBinding``
    (``world_binding``) — typically :class:`~theater.sim_agent.SimAgent`
    instances, but any duck-typed object works.
    """

    tick: int = 0
    actor_id: str = ""
    belief_traces: List[Any] = field(default_factory=list)
    #: Optional parallel list of actor ids owning each trace (same length
    #: as ``belief_traces``).  ``BeliefUpdateTrace`` itself has no owner
    #: field, so the caller supplies attribution here; a missing entry
    #: defaults to ``actor_id``.  This is what lets the builder wire
    #: ``social_influence`` edges between peers sharing a topic.
    trace_owners: Optional[List[str]] = None
    decision: Dict[str, Any] = field(default_factory=dict)
    outcome: Dict[str, Any] = field(default_factory=dict)
    canonical_facts: List[Dict[str, Any]] = field(default_factory=list)
    actors: Dict[str, Any] = field(default_factory=dict)
    observations: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# CausalTraceBuilder
# ---------------------------------------------------------------------------


class CausalTraceBuilder:
    """Turn a :class:`CommittedTick` into a forward-ordered :class:`CausalGraph`.

    Pure stdlib, deterministic.  Node / edge construction rules:

      - One ``actor`` node per actor referenced (decision actor + every
        belief-trace owner).
      - One ``belief`` node per :class:`BeliefUpdateTrace` (keyed by
        ``trace.topic``); an ``informational`` edge links each canonical
        fact / observation that fed the trace to the belief, and an
        ``epistemic`` edge links the belief to the decision it drove.
      - One ``decision`` node (from ``tick.decision``); a
        ``physical_cause`` edge links it to the outcome, and an
        ``institutional`` edge links the actor's permission set to it
        (the authority gate).
      - One ``outcome`` node (from ``tick.outcome``, kernel-owned).
      - ``social_influence`` edges link peer beliefs (same topic, other
        actors) to an actor's belief when peer traces share the topic —
        the bounded-confidence channel.
      - ``motivational`` edges link an actor's stated goals (from
        ``mind_state.goals``) to its decision.

    The builder never creates a cycle: causes are inserted before
    effects, so :meth:`CausalGraph.topo_order` returns the insertion
    order for a well-formed tick.
    """

    def build(self, tick: CommittedTick) -> CausalGraph:
        graph = CausalGraph(tick=tick.tick)
        node_ids: set = set()

        def add(node: CausalNode) -> None:
            if node.id in node_ids:
                return
            node_ids.add(node.id)
            graph.nodes.append(node)

        def edge(from_id: str, to_id: str, edge_type: str,
                 weight: float = 1.0, note: str = "") -> None:
            if edge_type not in EDGE_TYPES:
                raise ValueError(f"unknown edge type {edge_type!r}")
            graph.edges.append(CausalEdge(from_id, to_id, edge_type,
                                          weight, note))

        # -- fact nodes (kernel-owned, provenance=canonical_event) ----------
        fact_ids_by_actor: Dict[str, List[str]] = {}
        for fact in tick.canonical_facts:
            fid = str(fact.get("id") or f"fact_{len(graph.nodes)}")
            add(CausalNode(fid, "fact",
                           summary=str(fact.get("summary") or fact.get("content") or "")))
            # route the fact to every actor whose observations include it
            for actor_id, obs in tick.observations.items():
                for o in obs:
                    if (isinstance(o, dict) and o.get("fact_id") == fid) \
                            or o == fid:
                        fact_ids_by_actor.setdefault(actor_id, []).append(fid)

        # -- belief nodes (one per belief-trace topic) ----------------------
        belief_topics_by_actor: Dict[str, List[str]] = {}
        owners = self._resolve_owners(tick)
        for idx, tr in enumerate(tick.belief_traces):
            actor_id = owners[idx]
            topic = str(getattr(tr, "topic", "") or "default")
            belief_node_id = f"belief:{actor_id}:{topic}"
            add(CausalNode(belief_node_id, "belief", actor_id=actor_id,
                           ref=topic,
                           summary=self._belief_summary(tr)))
            belief_topics_by_actor.setdefault(actor_id, []).append(topic)
            # informational: fact → belief (each fact the actor observed
            # that fed this trace is an evidence channel).
            for fid in fact_ids_by_actor.get(actor_id, []):
                edge(fid, belief_node_id, "informational",
                     weight=0.8, note="observed evidence")

        # -- peer / social_influence edges (same topic across actors) ------
        for topic, owners in self._topic_owners(tick).items():
            if len(owners) < 2:
                continue
            for j, tgt in enumerate(owners):
                for src in owners:
                    if src == tgt:
                        continue
                    edge(f"belief:{src}:{topic}", f"belief:{tgt}:{topic}",
                         "social_influence", weight=0.4,
                         note="bounded-confidence peer")

        # -- actor + decision + outcome nodes -------------------------------
        decision = tick.decision or {}
        actor_id = str(decision.get("actor_id") or tick.actor_id or "")
        if actor_id:
            add(CausalNode(f"actor:{actor_id}", "actor", actor_id=actor_id,
                           ref=actor_id, summary=actor_id))

        decision_id = "decision"
        verb = str(decision.get("verb") or "")
        add(CausalNode(decision_id, "decision", actor_id=actor_id,
                       ref=verb,
                       summary=str(decision.get("rationale") or verb)))

        outcome = tick.outcome or {}
        outcome_kind = str(outcome.get("kind") or "unspecified")
        outcome_id = "outcome"
        add(CausalNode(outcome_id, "outcome", ref=outcome_kind,
                       summary=str(outcome.get("cause") or outcome_kind)))

        # institutional: permission → decision (authority gate).
        binding = self._binding(tick, actor_id)
        allowed = (binding.get("permissions") or {}).get("allowed_actions") or []
        if allowed:
            edge(f"permissions:{actor_id}", decision_id, "institutional",
                 weight=1.0, note=f"allowed={','.join(map(str, allowed))}")
            add(CausalNode(f"permissions:{actor_id}", "fact",
                           actor_id=actor_id, ref="permissions",
                           summary="world-binding permissions"))

        # epistemic: belief → decision (the actor's beliefs drove the choice).
        for topic in belief_topics_by_actor.get(actor_id, []):
            edge(f"belief:{actor_id}:{topic}", decision_id, "epistemic",
                 weight=0.9, note="belief drove decision")

        # motivational: goal → decision.
        for g in self._goals(tick, actor_id):
            gid = f"goal:{actor_id}:{g}"
            add(CausalNode(gid, "fact", actor_id=actor_id, ref=g,
                           summary=f"goal: {g}"))
            edge(gid, decision_id, "motivational", weight=0.7,
                 note="active goal")

        # physical_cause: decision → outcome (kernel-owned causation).
        edge(decision_id, outcome_id, "physical_cause", weight=1.0,
             note="kernel adjudicated")

        return graph

    # -- helpers -----------------------------------------------------------

    @staticmethod
    def _belief_summary(trace: Any) -> str:
        post = getattr(trace, "posterior", None)
        predicted = getattr(post, "predicted", None) if post is not None else None
        topic = getattr(trace, "topic", "") or "belief"
        strat = getattr(trace, "strategy", "") or ""
        accepted = getattr(trace, "accepted", None)
        parts = [f"topic={topic}"]
        if predicted is not None:
            parts.append(f"predicted={predicted}")
        if strat:
            parts.append(f"strategy={strat}")
        if accepted is False:
            parts.append("rejected")
        return " ".join(parts)

    @staticmethod
    def _binding(tick: CommittedTick, actor_id: str) -> Dict[str, Any]:
        actor = tick.actors.get(actor_id)
        if actor is None:
            return {}
        binding = getattr(actor, "world_binding", None)
        if binding is None:
            return {}
        # WorldBinding is a dataclass; expose as dict for .get().
        return {
            "permissions": getattr(binding, "permissions", {}) or {},
            "knowledge_scope": getattr(binding, "knowledge_scope", "*"),
        }

    @staticmethod
    def _goals(tick: CommittedTick, actor_id: str) -> List[str]:
        actor = tick.actors.get(actor_id)
        if actor is None:
            return []
        ms = getattr(actor, "mind_state", None)
        if ms is None:
            return []
        goals = getattr(ms, "goals", None) or []
        return [str(g) for g in goals]

    @staticmethod
    def _topic_owners(tick: CommittedTick) -> Dict[str, List[str]]:
        """Map belief-topic → list of actor ids that hold a trace on it.

        Used to wire ``social_influence`` edges between peers sharing a
        topic.  Owners come from :meth:`_resolve_owners`; a trace without
        an explicit owner is attributed to the tick's primary actor.
        """
        owners = CausalTraceBuilder._resolve_owners(tick)
        out: Dict[str, List[str]] = {}
        for idx, tr in enumerate(tick.belief_traces):
            topic = str(getattr(tr, "topic", "") or "default")
            out.setdefault(topic, []).append(owners[idx])
        return out

    @staticmethod
    def _resolve_owners(tick: CommittedTick) -> List[str]:
        """Resolve an owner actor id for each trace (parallel to
        ``belief_traces``).  Honours an explicit ``actor_id`` attribute
        on the trace, then ``tick.trace_owners``, then ``tick.actor_id``.
        """
        explicit = tick.trace_owners or []
        out: List[str] = []
        for idx, tr in enumerate(tick.belief_traces):
            owner = getattr(tr, "actor_id", None)
            if not owner and idx < len(explicit):
                owner = explicit[idx]
            out.append(str(owner or tick.actor_id))
        return out


# ---------------------------------------------------------------------------
# CausalPlan — the planner's output (stage 1)
# ---------------------------------------------------------------------------


@dataclass
class CausalPlan:
    """A candidate causal explanation produced by stage 1.

    Fields mirror the user-spec JSON ``{cause, mechanism, effect,
    subjective_reason, belief_refs, confidence}`` plus ``fact_refs`` —
    the explicit list of canonical-fact ids the explanation relies on,
    which the validator checks against the actor's observations
    (epistemic opacity).  ``actor_id`` is the character whose
    perspective the plan explains (defaults to the decision's actor).
    """

    cause: str = ""
    mechanism: str = ""           # one of EDGE_TYPES
    effect: str = ""              # must match outcome.kind
    subjective_reason: str = ""
    belief_refs: List[str] = field(default_factory=list)   # belief topics
    fact_refs: List[str] = field(default_factory=list)     # canonical fact ids
    confidence: float = 0.5
    actor_id: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return {
            "cause": self.cause,
            "mechanism": self.mechanism,
            "effect": self.effect,
            "subjective_reason": self.subjective_reason,
            "belief_refs": list(self.belief_refs),
            "fact_refs": list(self.fact_refs),
            "confidence": self.confidence,
            "actor_id": self.actor_id,
        }


# ---------------------------------------------------------------------------
# NarrativePlanner (LLM stage 1)
# ---------------------------------------------------------------------------


class NarrativePlanner:
    """Stage 1 LLM: CausalGraph + subjective mind → :class:`CausalPlan`.

    The LLM is shown the structured causal graph plus the actor's
    *subjective* mind state (beliefs / goals / personality) — never the
    kernel's full ground truth (user principle: the LLM does not see
    objective truth, only the character's world).  It returns a JSON
    object describing the dominant cause → mechanism → effect chain.

    ``llm_fn`` is required.  When the LLM fails (raises, returns
    unparseable text) the planner raises ``RuntimeError`` — there is no
    deterministic replacement.
    """

    def __init__(self, llm_fn: Optional[Callable[[str], str]] = None,
                 seed: Optional[int] = None) -> None:
        self._llm_fn = llm_fn
        self._rng = random.Random(seed)

    def plan(self, graph: CausalGraph, tick: CommittedTick) -> CausalPlan:
        actor_id = str((tick.decision or {}).get("actor_id") or tick.actor_id)
        subjective = self._subjective_view(tick, actor_id)
        if self._llm_fn is None:
            raise RuntimeError(
                "NarrativePlanner: llm_fn is required, got None")
        plan = self._plan_via_llm(graph, subjective, actor_id, tick)
        if plan is None:
            raise RuntimeError(
                "NarrativePlanner: LLM failed to produce a valid plan")
        return plan

    # -- LLM path ----------------------------------------------------------

    def _plan_via_llm(self, graph: CausalGraph, subjective: Dict[str, Any],
                      actor_id: str, tick: CommittedTick) -> Optional[CausalPlan]:
        prompt = self._build_prompt(graph, subjective, tick)
        try:
            raw = self._llm_fn(prompt)  # type: ignore[misc]
        except Exception:
            return None
        if not isinstance(raw, str):
            return None
        parsed = self._parse_plan_json(raw)
        if parsed is None:
            return None
        parsed.actor_id = actor_id
        return parsed

    def _build_prompt(self, graph: CausalGraph, subjective: Dict[str, Any],
                      tick: CommittedTick) -> str:
        outcome_kind = str((tick.outcome or {}).get("kind") or "unspecified")
        sys_prompt = (
            "你是因果叙事的「规划器」（架构 §14 阶段1）。任务：阅读结构化因果图"
            "与角色的**主观**心理状态（信念/目标/人格），输出一个 JSON 因果解释：\n"
            "  cause             —— 主因（引用图中的节点 summary）\n"
            "  mechanism         —— 因果机制（六选一: physical_cause / informational"
            " / epistemic / motivational / social_influence / institutional）\n"
            "  effect            —— 结局（必须等于给定 outcome.kind，不得改写）\n"
            "  subjective_reason —— 角色主观理由（基于其信念，不得引用角色不知道的客观真值）\n"
            "  belief_refs       —— 角色持有的信念 topic 列表（必须来自输入的 beliefs）\n"
            "  fact_refs         —— 角色观察到的 canonical fact id 列表（必须来自输入的 observations）\n"
            "  confidence        —— 0..1\n"
            "红线（§8.2）：不得改写 outcome.kind；不得引用未在输入中给出的信念或事实；"
            "不得裁定物理。只输出一个 JSON 对象。"
        )
        lines = [sys_prompt, ""]
        lines.append(f"outcome.kind={outcome_kind}")
        lines.append("causal_graph=" + json.dumps(graph.as_dict(),
                                                  ensure_ascii=False))
        lines.append("subjective_mind=" + json.dumps(subjective,
                                                     ensure_ascii=False))
        lines.append("")
        lines.append("只输出 JSON。")
        return "\n".join(lines)

    @staticmethod
    def _parse_plan_json(raw: str) -> Optional[CausalPlan]:
        s = raw.strip().strip("`").strip()
        if s.lower().startswith("json"):
            s = s[4:].strip()
        try:
            obj = json.loads(s)
        except json.JSONDecodeError:
            start = s.find("{")
            end = s.rfind("}")
            if start == -1 or end <= start:
                return None
            try:
                obj = json.loads(s[start:end + 1])
            except json.JSONDecodeError:
                return None
        if not isinstance(obj, dict):
            return None
        return CausalPlan(
            cause=str(obj.get("cause", "")),
            mechanism=str(obj.get("mechanism", "")),
            effect=str(obj.get("effect", "")),
            subjective_reason=str(obj.get("subjective_reason", "")),
            belief_refs=[str(x) for x in (obj.get("belief_refs") or [])],
            fact_refs=[str(x) for x in (obj.get("fact_refs") or [])],
            confidence=float(obj.get("confidence", 0.5) or 0.5),
        )

    # -- subjective view (actor's world, not ground truth) ----------------

    @staticmethod
    def _subjective_view(tick: CommittedTick, actor_id: str) -> Dict[str, Any]:
        actor = tick.actors.get(actor_id)
        beliefs_out: List[Dict[str, Any]] = []
        goals: List[str] = []
        personality = ""
        if actor is not None:
            ms = getattr(actor, "mind_state", None)
            if ms is not None:
                for topic, bel in (getattr(ms, "beliefs", {}) or {}).items():
                    beliefs_out.append({
                        "topic": topic,
                        "predicted": getattr(bel, "predicted", None),
                        "confidence": getattr(bel, "confidence", 0.0),
                    })
                goals = list(getattr(ms, "goals", []) or [])
            char = getattr(actor, "character", None)
            if char is not None:
                personality = str(getattr(char, "personality", "") or "")
        observed = tick.observations.get(actor_id, []) or []
        observed_facts: List[str] = []
        for o in observed:
            if isinstance(o, dict) and o.get("fact_id"):
                observed_facts.append(str(o["fact_id"]))
            elif isinstance(o, str):
                observed_facts.append(o)
        return {
            "actor_id": actor_id,
            "beliefs": beliefs_out,
            "goals": goals,
            "personality": personality,
            "observed_facts": observed_facts,
        }


# ---------------------------------------------------------------------------
# CausalValidator (symbolic, no LLM)
# ---------------------------------------------------------------------------


@dataclass
class ValidationResult:
    ok: bool
    errors: List[str] = field(default_factory=list)


class CausalValidator:
    """Symbolic checker for a :class:`CausalPlan` (the compiler's type-check).

    Four checks, all deterministic, all against kernel-/agent-owned state
    (never against LLM free text):

    1. **belief ownership** — every ``belief_refs`` topic must exist in
       the cited actor's :class:`AgentMindState.beliefs`.
    2. **permission** — the decision's verb must be in the actor's
       ``WorldBinding.permissions.allowed_actions``.
    3. **epistemic opacity** — every ``fact_refs`` id must be in the
       actor's observations (the character cannot cite a fact it never
       saw).
    4. **kernel consistency** — ``plan.effect`` must equal the kernel
       ``outcome.kind`` (the LLM may not flip the outcome).

    On failure the validator returns the error list; the engine retries the
    planner once with feedback, then raises.
    """

    def validate(self, plan: CausalPlan, tick: CommittedTick) -> ValidationResult:
        errors: List[str] = []
        actor_id = plan.actor_id or tick.actor_id
        actor = tick.actors.get(actor_id)

        # 1. belief ownership
        held_topics: set = set()
        if actor is not None:
            ms = getattr(actor, "mind_state", None)
            if ms is not None:
                held_topics = set((getattr(ms, "beliefs", {}) or {}).keys())
        for topic in plan.belief_refs:
            if topic not in held_topics:
                errors.append(
                    f"belief_ref {topic!r} not held by actor {actor_id!r}")

        # 2. permission
        verb = str((tick.decision or {}).get("verb") or "")
        allowed: List[str] = []
        if actor is not None:
            binding = getattr(actor, "world_binding", None)
            if binding is not None:
                allowed = list((getattr(binding, "permissions", {}) or {})
                               .get("allowed_actions") or [])
        if verb and allowed and verb not in allowed:
            errors.append(
                f"verb {verb!r} not in allowed_actions {allowed} for "
                f"actor {actor_id!r}")

        # 3. epistemic opacity
        observed_ids: set = set()
        for o in (tick.observations.get(actor_id, []) or []):
            if isinstance(o, dict) and o.get("fact_id"):
                observed_ids.add(str(o["fact_id"]))
            elif isinstance(o, str):
                observed_ids.add(o)
        for fid in plan.fact_refs:
            if fid not in observed_ids:
                errors.append(
                    f"fact_ref {fid!r} not in actor {actor_id!r} observations")

        # 4. kernel consistency — effect must match outcome.kind.
        outcome_kind = str((tick.outcome or {}).get("kind") or "unspecified")
        if plan.effect and plan.effect != outcome_kind:
            errors.append(
                f"plan.effect {plan.effect!r} != outcome.kind "
                f"{outcome_kind!r} (§8.2 red line: LLM cannot flip outcome)")

        return ValidationResult(ok=not errors, errors=errors)


# ---------------------------------------------------------------------------
# NarrativeRealizer (LLM stage 2)
# ---------------------------------------------------------------------------


class NarrativeRealizer:
    """Stage 2 LLM: approved CausalGraph + plan → literary prose.

    The LLM is shown the *approved* causal graph and the planner's
    explanation and asked for 80-200 chars of prose.  The §8.2 red line
    is restated: do not flip the outcome, do not invent physics.

    ``llm_fn`` is required.  When the LLM fails (raises, returns empty
    text) the realizer raises ``RuntimeError`` — there is no
    deterministic replacement.
    """

    def __init__(self, llm_fn: Optional[Callable[[str], str]] = None,
                 seed: Optional[int] = None) -> None:
        self._llm_fn = llm_fn
        self._rng = random.Random(seed)

    def realize(self, graph: CausalGraph, plan: CausalPlan,
                outcome: Dict[str, Any]) -> str:
        if self._llm_fn is None:
            raise RuntimeError(
                "NarrativeRealizer: llm_fn is required, got None")
        prompt = self._build_prompt(graph, plan, outcome)
        try:
            raw = self._llm_fn(prompt)  # type: ignore[misc]
        except Exception:
            raise RuntimeError(
                "NarrativeRealizer: LLM call failed") from None
        if not isinstance(raw, str) or not raw.strip():
            raise RuntimeError(
                "NarrativeRealizer: LLM returned empty/invalid text")
        return raw.strip()

    def _build_prompt(self, graph: CausalGraph, plan: CausalPlan,
                      outcome: Dict[str, Any]) -> str:
        sys_prompt = (
            "你是因果叙事的「实现器」（架构 §14 阶段2）。输入是**已校验通过**的"
            "因果图与因果解释，请把它写成 80-200 字的文学旁白（可含对白）。\n"
            "红线（§8.2）：结局由内核裁定，你不得改写 outcome.kind；不得臆造未在"
            "因果图中出现的物理数值或事实；只能润色与编织已给定的因果链。"
        )
        lines = [sys_prompt, ""]
        lines.append(f"outcome.kind={outcome.get('kind') or 'unspecified'}")
        lines.append("causal_plan=" + json.dumps(plan.as_dict(),
                                                 ensure_ascii=False))
        lines.append("causal_graph=" + json.dumps(graph.as_dict(),
                                                  ensure_ascii=False))
        lines.append("")
        lines.append("只输出旁白文本，不要 JSON、不要字段名。")
        return "\n".join(lines)

    @staticmethod
    def _kind_label(kind: str) -> str:
        # Generic runtime does not assign semantics to adapter-owned outcome
        # identifiers. It only makes the committed identifier readable.
        return str(kind or "unspecified").replace("_", " ")


# ---------------------------------------------------------------------------
# CausalNarrativeEngine — the full §14 pipeline
# ---------------------------------------------------------------------------


@dataclass
class NarrationResult:
    """Bundle returned by :meth:`CausalNarrativeEngine.narrate_tick`."""

    causal_graph: CausalGraph
    plan: CausalPlan
    validation: ValidationResult
    narrative: str
    nli: Dict[str, Any]
    warnings: List[str] = field(default_factory=list)
    # Stable orchestration contract: callers may surface whether optional
    # prose was replaced by the deterministic safety path.
    fallback_used: bool = False


class CausalNarrativeEngine:
    """Wire the four stages of spec §14 into one call.

    Parameters
    ----------
    planner_llm, realizer_llm:
        ``llm_fn(prompt: str) -> str`` callables for the two LLM stages.
        Missing callables or model failures abort generation. They may be the
        same callable or different models.
    nli_guard:
        Optional injected :class:`NliGuard`.  ``None`` → the engine
        probes the environment lazily. Probe failure does not install any
        world-specific lexical policy.
    outcome_keywords:
        Optional adapter-owned ``kind -> {need, forbid}`` lexicon. Generic
        runtime leaves it unset; a specialised adapter may pass one explicitly.
    max_retries:
        How many times to re-run the planner with validator feedback
        before failing generation (default 1).
    seed:
        Reserved reproducibility seed for LLM-stage helpers.
    """

    def __init__(
        self,
        planner_llm: Optional[Callable[[str], str]] = None,
        realizer_llm: Optional[Callable[[str], str]] = None,
        nli_guard: Optional[NliGuard] = None,
        outcome_keywords: Optional[
            Dict[str, Dict[str, Tuple[str, ...]]]
        ] = None,
        max_retries: int = 1,
        seed: Optional[int] = None,
    ) -> None:
        self._builder = CausalTraceBuilder()
        self._planner = NarrativePlanner(llm_fn=planner_llm, seed=seed)
        self._validator = CausalValidator()
        self._realizer = NarrativeRealizer(llm_fn=realizer_llm, seed=seed)
        self._nli_guard = nli_guard
        self._outcome_keywords = dict(outcome_keywords or {})
        self._max_retries = max(0, int(max_retries))
        self._seed = seed

    # -- public API --------------------------------------------------------

    def narrate_tick(self, tick: CommittedTick) -> NarrationResult:
        warnings: List[str] = []
        graph = self._builder.build(tick)
        # Stage 1 + validator (with retry).
        plan, validation = self._plan_with_validation(graph, tick, warnings)

        # Stage 2: realize.
        narrative = self._realizer.realize(graph, plan, tick.outcome or {})

        # Final consistency check (NLI guard).
        nli = self._final_consistency_check(graph, plan, tick, narrative,
                                            warnings)
        if not nli.get("consistent", False):
            raise RuntimeError(
                "CausalNarrativeEngine: generated narrative failed "
                "consistency validation"
            )

        return NarrationResult(
            causal_graph=graph,
            plan=plan,
            validation=validation,
            narrative=narrative,
            nli=nli,
            warnings=warnings,
            fallback_used=False,
        )

    # -- stage 1 + validation ---------------------------------------------

    def _plan_with_validation(
        self, graph: CausalGraph, tick: CommittedTick, warnings: List[str],
    ) -> Tuple[CausalPlan, ValidationResult]:
        plan = self._planner.plan(graph, tick)
        validation = self._validator.validate(plan, tick)
        attempts = 0
        while not validation.ok and attempts < self._max_retries:
            attempts += 1
            feedback = ("; ".join(validation.errors)
                        if validation.errors else "invalid plan")
            warnings.append(f"planner rejected: {feedback}; retrying")
            plan = self._planner.plan(graph, tick)
            validation = self._validator.validate(plan, tick)
        if not validation.ok:
            # planner and validator are both deterministic after the
            # LLM has spoken; if retries still fail the error is in
            # the prompt or the validator logic, not a transient flake.
            raise RuntimeError(
                f"CausalNarrativeEngine: plan invalid after "
                f"{self._max_retries} retries: {validation.errors}")
        return plan, validation

    # -- final NLI consistency check --------------------------------------

    def _final_consistency_check(
        self, graph: CausalGraph, plan: CausalPlan, tick: CommittedTick,
        narrative: str, warnings: List[str],
    ) -> Dict[str, Any]:
        source = self._build_source(graph, plan, tick)
        guard = self._get_nli_guard()
        if guard is None or not guard.available():
            kind = str((tick.outcome or {}).get("kind") or "unspecified")
            ok = _keyword_consistent(
                narrative, kind, self._outcome_keywords,
            )
            if not ok:
                warnings.append(
                    "NLI unavailable; adapter lexical check rejected narrative; "
                    "generation rejected")
            return {"available": False, "consistent": ok, "source": source}
        res = guard.check_entailment(source, narrative or "")
        if not res.get("consistent", False):
            warnings.append(
                "NLI guard rejected narrative; generation rejected")
        return res

    def _build_source(self, graph: CausalGraph, plan: CausalPlan,
                      tick: CommittedTick) -> str:
        """Plain template of the ground-truth claims the narrative must entail."""
        outcome = tick.outcome or {}
        kind = str(outcome.get("kind") or "unspecified")
        label = NarrativeRealizer._kind_label(kind)  # noqa: SLF001
        parts = [label]
        cause = outcome.get("cause")
        if cause:
            parts.append(f"原因={cause}")
        if plan.cause:
            parts.append(f"主因={plan.cause}")
        if plan.effect:
            parts.append(f"结局类型={plan.effect}")
        for fact in tick.canonical_facts:
            summary = fact.get("summary") or fact.get("content")
            if summary:
                parts.append(f"事实={summary}")
        return "，".join(str(p) for p in parts)

    def _get_nli_guard(self) -> Optional[NliGuard]:
        if self._nli_guard is not None:
            return self._nli_guard
        import os
        guard: Optional[NliGuard] = None
        if os.environ.get("THEATER_NLI_MODEL"):
            guard = NliGuard()
        elif os.environ.get("THEATER_NLI_JUDGE") == "1":
            try:
                from .onboarding_llm import build_llm
                client, _msg = build_llm()
                if client is not None:
                    def _judge(prompt: str) -> str:
                        return client.complete(prompt, temperature=0.0,
                                               max_tokens=8)

                    guard = NliGuard(llm_fn=_judge)
            except Exception:
                guard = None
        self._nli_guard = guard
        return guard


# ---------------------------------------------------------------------------
# Optional adapter lexical guard (NLI unavailable).
# ---------------------------------------------------------------------------


def _keyword_consistent(
    narrated: str,
    kind: str,
    lexicon: Optional[Dict[str, Dict[str, Tuple[str, ...]]]] = None,
) -> bool:
    """Apply only a caller-supplied outcome lexicon.

    An absent/unknown lexicon is intentionally lenient: generic narration
    cannot invent vocabulary for an arbitrary world.
    """
    kw = (lexicon or {}).get(kind)
    if kw is None:
        return True
    need = kw.get("need", ())
    forbid = kw.get("forbid", ())
    has_need = any(k in narrated for k in need)
    has_forbid = any(k in narrated for k in forbid)
    return not (has_forbid and not has_need)
