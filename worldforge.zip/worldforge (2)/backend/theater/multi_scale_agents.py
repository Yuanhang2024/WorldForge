"""P3 — generic multi-scale agency framework (architecture spec §3 / §8.2).

This module generalises the three-layer subject system first built for the
three-body world (``three_body_agents.py``) into a **world-agnostic**
framework::

    IndividualAgent       — observe → believe → propose
        ↓ proposals
    OrganizationAgent     — aggregate member proposals through a
                            character_graph trust gate + org_decide
        ↓ org decision
    CollectiveAgent       — map the org decision to an *action vector*
                            and feed it to the world kernel
        ↓ action vector
    world kernel          — deterministic outcome (red line: the kernel
                            decides, the LLM only narrates)
        ↓ outcome
    reflux                — individuals revise beliefs given the verdict
                            (rational learn; dogmatic reinforce)

The three-body ``ScientistAgent`` / ``DecisionBody`` / ``CivilizationAgent``
become the *first instance* of this framework — they subclass these generic
layers and supply three-body-specific plugs (observation filter, plan
vocabulary, decision-vector map, kernel outcome call).  The economy
(merchant → guild → market) and political-fantasy (noble → faction →
kingdom) instances in this module supply the *second* and *third* instances
— the generality proof (the "三体特化" critique answered by construction).

Why generic — the load-bearing distinction
------------------------------------------
The §3 correction is *not* three-body-specific.  It says any civilisation /
market / polity is a *multi-scale subject system*: individuals form beliefs
from filtered observations; organisations aggregate those beliefs through
trust-gated channels; the collective maps the org decision to an action
vector the kernel consumes.  The "leader distrusts the scientist →
information does not propagate → social disaster" example (§5) is one
instance; "faction distrusts the loyal general → defensive plan does not
land → kingdom falls" is the same instance in a different world.  One
framework, three worlds — that is the whole point.

Red lines (unchanged from ``three_body_agents.py``)
---------------------------------------------------
- The world kernel decides outcomes; this module only translates an org
  decision into the kernel's action-vector shape.  No kernel is modified.
- Reuses (read-only): ``cognitive_model``, ``sim_agent``, ``belief_update``,
  ``character_graph``, ``observation_filter``.
- Pure stdlib, deterministic, seed-driven (spec §8.2).  No LLM, no unseeded
  randomness.

Pluggability
------------
A concrete world supplies four callables / dicts (see
:class:`MultiScaleSimConfig`):

- ``true_state_fn(kernel, t)`` — read the kernel's ground truth.
- ``plan_to_action_vector`` — ``{plan: action_vector_dict}``.  ``None`` is
  reserved for "no decision" → the kernel's neutral branch.
- ``outcome_fn(kernel, action_vector, t, **ctx)`` — call the kernel and
  return ``(outcome, outcome_kind, civ_destroyed_flag)``.
- ``reflux_evidence_fn(outcome, outcome_kind, destroyed)`` — map the
  verdict to a reflux evidence value fed back into individual beliefs.
- ``default_plan`` — the status-quo plan a member falls back to when no
  trusted proposal reaches them (``persist`` / ``hold`` / ``status_quo``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .belief_update import BeliefUpdateTrace, revise_belief
from .character_graph import CharacterGraph, Organization, org_decide
from .cognitive_model import Belief
from .sim_agent import SimAgent


__all__ = [
    "DEFAULT_TRUST_THRESHOLD",
    "IndividualAgent",
    "OrganizationAgent",
    "CollectiveAgent",
    "MultiScaleCausalTrace",
    "MultiScaleSimConfig",
    "MultiScaleSim",
    "proposal_from_thresholds",
]


#: Default trust gate: a member accepts an individual's proposal iff the
#: member's trust in that individual exceeds this threshold.  Below it the
#: proposal does not land — the §5 "leader distrusts scientist" block,
#: generalised to any org.
DEFAULT_TRUST_THRESHOLD: float = 0.0


# ---------------------------------------------------------------------------
# Layer 1 — IndividualAgent (generic)
# ---------------------------------------------------------------------------


class IndividualAgent:
    """An individual subject: observe → believe → propose.

    Wraps a :class:`SimAgent` (character + mind profile + mind state) and
    adds the generic epistemic loop.  World-specific behaviour is supplied
    through three plugs:

    - ``observation_filter`` — projects kernel ground truth into the
      subject's (possibly-wrong) observation.  Duck-typed: any object with
      an ``observe(true_state, binding) -> dict`` method.
    - ``belief_topic`` — the belief key the subject revises each tick
      (e.g. ``"disaster_prob"`` / ``"price_trend"`` / ``"invasion_risk"``).
    - ``propose_fn`` — maps the current belief to a plan string.  Defaults
      to :func:`proposal_from_thresholds` with the supplied thresholds.

    The subject always reads its observation through the filter — never raw
    kernel truth (§8 red line).  Personality shapes the belief revision
    (固执 → dogmatic / 教条强化; 理性 → rational).  Determinism: every step
    is a pure function of ``(ground truth, capability, mind, seed)``.
    """

    def __init__(
        self,
        sim_agent: SimAgent,
        *,
        capability: Optional[Dict[str, float]] = None,
        agent_id: Optional[str] = None,
        belief_topic: str = "default",
        observation_filter: Any = None,
        propose_fn: Optional[Callable[["IndividualAgent"], str]] = None,
        observation_binding_fn: Optional[Callable[["IndividualAgent", Any], Dict[str, Any]]] = None,
        seed: Optional[int] = None,
    ) -> None:
        self.sim = sim_agent
        self.capability: Dict[str, float] = dict(capability or {})
        self.id: str = agent_id or sim_agent.character.character_id or sim_agent.character.name
        self.belief_topic: str = belief_topic
        self.observation_filter = observation_filter
        self.propose_fn: Callable[["IndividualAgent"], str] = (
            propose_fn or _default_propose_noop
        )
        self.observation_binding_fn = observation_binding_fn
        self.seed = seed

    # -- perception ---------------------------------------------------------

    def observe(
        self,
        filter_: Any,
        true_state: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Project ground truth through the capability-gated filter."""
        if filter_ is None:
            filter_ = self.observation_filter
        binding: Dict[str, Any] = {
            "agent_id": self.id,
        }
        if self.observation_binding_fn is not None:
            binding.update(self.observation_binding_fn(self, true_state) or {})
        else:
            # Default: flatten capability into the binding so a filter that
            # reads tech_level / delta_0 / T_predict etc. sees them.
            binding.update(self.capability)
        return filter_.observe(true_state, binding)

    # -- cognition ----------------------------------------------------------

    def update_belief(
        self,
        observation: Dict[str, Any],
        topic: Optional[str] = None,
        evidence_field: str = "evidence",
        model_error_field: str = "model_error",
    ) -> Tuple[Belief, BeliefUpdateTrace]:
        """Revise the belief given an observation.

        ``evidence_field`` is the observation key carrying the numerical
        evidence (defaults to ``"evidence"``; three-body uses
        ``"disaster_prob"``).  ``model_error_field`` forwards the
        observation's perception-error flag as ``observation_validated``
        so a misperceived reading is tagged ``perception_error``.
        """
        key = topic or self.belief_topic
        prior = self.sim.mind_state.beliefs.get(key)
        if prior is None:
            prior = Belief(predicted=0.5, confidence=0.5, model_error=False,
                           committed_values={})

        obs_value = observation.get(evidence_field)
        if obs_value is None:
            # fall back to the belief-topic-named field (three-body style)
            obs_value = observation.get(self.belief_topic)
        try:
            obs_value = float(obs_value)
        except (TypeError, ValueError):
            obs_value = 0.5
        observation_validated = not bool(observation.get(model_error_field, False))

        posterior, trace = revise_belief(
            prior=prior,
            observation=obs_value,
            profile=self.sim.mind,
            topic=key,
            personality_text=self.sim.character.personality,
            seed=self.seed,
            observation_validated=observation_validated,
        )
        self.sim.mind_state.beliefs[key] = posterior
        return posterior, trace

    # -- action -------------------------------------------------------------

    def propose(self) -> str:
        """Map the current belief to a plan via ``propose_fn``."""
        return self.propose_fn(self)

    @property
    def belief_value(self) -> float:
        """Current committed belief on this agent's topic (0.5 if unset)."""
        belief = self.sim.mind_state.beliefs.get(self.belief_topic)
        if belief and belief.predicted is not None:
            return float(belief.predicted)
        return 0.5


def _default_propose_noop(agent: "IndividualAgent") -> str:
    """Fallback proposer when a world does not configure one."""
    return "noop"


def proposal_from_thresholds(
    high_threshold: float,
    mid_threshold: float,
    high_plan: str,
    mid_plan: str,
    low_plan: str,
) -> Callable[[IndividualAgent], str]:
    """Build a threshold-based ``propose_fn``.

    Reads the agent's committed belief on its topic and returns:

    - ``high_plan``  when ``belief >= high_threshold``
    - ``mid_plan``   when ``belief >= mid_threshold``
    - ``low_plan``   otherwise

    This is the generalisation of the three-body ``dehydrate / evacuate /
    persist`` mapping — the same threshold structure, different vocabulary.
    """

    def _fn(agent: IndividualAgent) -> str:
        prob = agent.belief_value
        if prob >= high_threshold:
            return high_plan
        if prob >= mid_threshold:
            return mid_plan
        return low_plan

    return _fn


# ---------------------------------------------------------------------------
# Layer 2 — OrganizationAgent (generic)
# ---------------------------------------------------------------------------


class OrganizationAgent:
    """The organisational layer: aggregate proposals into one decision.

    Members are the org's decision-makers (individuals + non-individual
    authorities such as a leader / guild-master / king).  A member accepts
    an individual's proposal iff the member's trust in that individual
    (``graph.get_trust(member, individual)``) exceeds ``trust_threshold``
    — the §5 "leader distrusts individual → information does not propagate"
    gate, made structural on the character graph and generalised to any
    org.  An individual always accepts their own proposal.

    Voting:

    - Each individual member votes their own proposal.
    - Each non-individual member votes the highest-trust proposal they
      received, defaulting to ``default_plan`` (status quo) when they
      received none (the distrust case).
    - :func:`character_graph.org_decide` aggregates under the org's rule
      (``dictator`` / ``consensus`` / ``vote``).
    """

    def __init__(
        self,
        org: Organization,
        graph: CharacterGraph,
        *,
        trust_threshold: float = DEFAULT_TRUST_THRESHOLD,
        default_plan: str = "status_quo",
    ) -> None:
        self.org = org
        self.graph = graph
        self.trust_threshold = float(trust_threshold)
        self.default_plan = default_plan

    def _received_proposals(
        self,
        proposals: Dict[str, str],
    ) -> Dict[str, List[Tuple[str, str, float]]]:
        """For each member, the (individual_id, plan, trust) proposals they accept."""
        received: Dict[str, List[Tuple[str, str, float]]] = {
            m: [] for m in self.org.members
        }
        for ind_id, plan in proposals.items():
            for member_id in self.org.members:
                if member_id == ind_id:
                    # an individual always accepts their own proposal
                    trust = 1.0
                else:
                    trust = self.graph.get_trust(member_id, ind_id)
                if trust > self.trust_threshold:
                    received[member_id].append((ind_id, plan, trust))
        return received

    def decide(
        self,
        proposals: Dict[str, str],
        seed: Optional[int] = None,
    ) -> Tuple[Optional[str], Dict[str, str], Dict[str, List[str]]]:
        """Aggregate ``proposals`` into one org decision.

        Returns ``(decision, member_votes, received_map)`` where
        ``received_map`` is ``{member_id: [individual_id, ...]}`` recording
        whose proposals each member accepted (the audit trail for the
        "information did not propagate" failure mode).
        """
        received = self._received_proposals(proposals)

        member_votes: Dict[str, str] = {}
        for member_id in self.org.members:
            if member_id in proposals:
                # individual votes their own proposal
                member_votes[member_id] = proposals[member_id]
                continue
            accepted = received.get(member_id, [])
            if not accepted:
                # no trusted proposal reached this member → status quo
                member_votes[member_id] = self.default_plan
            else:
                # vote the highest-trust proposal received
                accepted.sort(key=lambda t: t[2], reverse=True)
                member_votes[member_id] = accepted[0][1]

        decision = org_decide(self.org, member_votes)
        received_audit: Dict[str, List[str]] = {
            m: [s for (s, _p, _t) in received.get(m, [])] for m in self.org.members
        }
        return decision, member_votes, received_audit


# ---------------------------------------------------------------------------
# Layer 3 — CollectiveAgent (generic)
# ---------------------------------------------------------------------------


class CollectiveAgent:
    """Maps the org decision to an action vector and feeds the kernel.

    The collective level does **not** decide physics — it only translates
    the organisational decision into the action-vector shape the kernel
    reads.  ``outcome_fn`` stays the single source of ground truth (red
    line: kernel decides, LLM only narrates).  When the org failed to
    decide (``decision is None``) the vector is ``None`` and the kernel
    degrades to its neutral branch.
    """

    def __init__(
        self,
        kernel: Any,
        plan_to_action_vector: Dict[str, Dict[str, float]],
        outcome_fn: Callable[..., Any],
    ) -> None:
        self.kernel = kernel
        self.plan_to_action_vector = dict(plan_to_action_vector)
        self.outcome_fn = outcome_fn

    def action_vector_for(self, org_decision: Optional[str]) -> Optional[Dict[str, float]]:
        """Translate an org decision to the kernel's action vector."""
        if org_decision is None:
            return None
        return self.plan_to_action_vector.get(org_decision)

    def decide_outcome(
        self,
        org_decision: Optional[str],
        t: float,
        **ctx: Any,
    ) -> Tuple[Any, Optional[Dict[str, float]]]:
        """Return ``(outcome, action_vector)`` from the kernel.

        ``outcome_fn(kernel, action_vector, t, **ctx)`` is the world's
        kernel call; it returns the kernel's outcome object (or dict).
        :meth:`outcome_verdict` derives the ``(kind, destroyed)`` flag the
        generic tick's reflux rule reads, so a world can subclass either
        hook independently.
        """
        action_vector = self.action_vector_for(org_decision)
        outcome = self.outcome_fn(self.kernel, action_vector, t, **ctx)
        return outcome, action_vector

    def outcome_verdict(self, outcome: Any) -> Tuple[str, bool]:
        """Derive ``(outcome_kind, destroyed)`` from a kernel outcome.

        Default heuristic: a kind starting with ``destroyed`` or equal to
        ``planet_ejected`` (the three-body vocabulary) marks the
        civilisation destroyed.  Worlds with a different outcome vocabulary
        override this.
        """
        kind = getattr(outcome, "kind", "") or (
            outcome.get("kind", "") if isinstance(outcome, dict) else ""
        )
        destroyed = kind.startswith("destroyed") or kind == "planet_ejected"
        return str(kind), destroyed


# ---------------------------------------------------------------------------
# MultiScaleCausalTrace — generic audit record
# ---------------------------------------------------------------------------


@dataclass
class MultiScaleCausalTrace:
    """Structured record of one generic multi-scale tick.

    Captures the full causal chain — individual observation → belief →
    proposal → org decision → collective action → kernel outcome →
    post-outcome belief reflux — so the narrator (and tests) can read the
    *why* of an ending without re-running the simulation.  Structured and
    non-literary by design (§8.2 red line).

    The field names mirror ``three_body_agents.CausalTrace`` so the
    three-body narrator / dispatcher code can read a generic trace without
    branching on type — the three-body ``CausalTrace`` is a thin subclass
    that adds no fields, only typed convenience.
    """

    t: float = 0.0
    civ_tech_level: float = 0.0
    # Layer 1 — individuals
    scientist_observations: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    belief_updates: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    proposals: Dict[str, str] = field(default_factory=dict)
    # Layer 2 — organisation
    member_votes: Dict[str, str] = field(default_factory=dict)
    info_propagation: Dict[str, List[str]] = field(default_factory=dict)
    org_decision: Optional[str] = None
    # Layer 3 — collective
    decision_vector: Optional[Dict[str, float]] = None
    # World result — kernel verdict
    outcome_kind: str = ""
    outcome: Optional[Dict[str, Any]] = None
    civ_destroyed: bool = False
    # Reflux — post-outcome belief revision
    post_outcome_belief_updates: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "t": self.t,
            "civ_tech_level": self.civ_tech_level,
            "scientist_observations": self.scientist_observations,
            "belief_updates": self.belief_updates,
            "proposals": self.proposals,
            "member_votes": self.member_votes,
            "info_propagation": self.info_propagation,
            "org_decision": self.org_decision,
            "decision_vector": self.decision_vector,
            "outcome_kind": self.outcome_kind,
            "outcome": self.outcome,
            "civ_destroyed": self.civ_destroyed,
            "post_outcome_belief_updates": self.post_outcome_belief_updates,
        }


# ---------------------------------------------------------------------------
# MultiScaleSimConfig — world plugs
# ---------------------------------------------------------------------------


@dataclass
class MultiScaleSimConfig:
    """World-specific plugs for :class:`MultiScaleSim`.

    Fields
    ------
    true_state_fn:
        ``(kernel, t) -> dict`` — read the kernel's ground truth the
        individuals observe.
    observation_filter:
        shared filter, or ``None`` if each :class:`IndividualAgent` carries
        its own.
    reflux_evidence_fn:
        ``(outcome, outcome_kind, destroyed) -> (evidence_value, model_error)``
        — map the verdict to the reflux evidence fed back into individual
        beliefs.  Default: destroyed → (1.0, False); else (0.0, False).
    outcome_context_fn:
        ``(t, kernel) -> dict`` — extra context passed to ``outcome_fn``
        (e.g. ``civ_count``, ``tech_level``).  Default: ``{}``.
    """

    true_state_fn: Callable[[Any, float], Dict[str, Any]]
    observation_filter: Any = None
    reflux_evidence_fn: Optional[Callable[[Any, str, bool], Tuple[float, bool]]] = None
    outcome_context_fn: Optional[Callable[[float, Any], Dict[str, Any]]] = None


def _default_reflux_evidence(
    outcome: Any, outcome_kind: str, destroyed: bool,
) -> Tuple[float, bool]:
    return (1.0 if destroyed else 0.0, False)


# ---------------------------------------------------------------------------
# MultiScaleSim — compose the three layers into one deterministic tick
# ---------------------------------------------------------------------------


class MultiScaleSim:
    """Compose the three generic layers into one deterministic tick.

    ``tick(t, **extra)`` runs the full §3 chain::

        individuals observe (filter-gated)
          → belief_update (personality-shaped)
          → proposals
          → OrganizationAgent aggregates (trust-gated + org_decide)
          → CollectiveAgent → action_vector
          → kernel outcome (kernel verdict)
          → outcome reflux: individuals revise beliefs given the verdict

    The kernel is the only source of ground truth; this class never
    adjudicates physics.  Same inputs → same :class:`MultiScaleCausalTrace`
    (§8.2).
    """

    def __init__(
        self,
        kernel: Any,
        individuals: Dict[str, IndividualAgent],
        organization: OrganizationAgent,
        collective: CollectiveAgent,
        config: MultiScaleSimConfig,
        *,
        seed: Optional[int] = None,
        observation_filter: Any = None,
        evidence_field: str = "evidence",
        model_error_field: str = "model_error",
        trace_factory: Optional[Callable[[], MultiScaleCausalTrace]] = None,
    ) -> None:
        self.kernel = kernel
        self.individuals = individuals
        self.organization = organization
        self.collective = collective
        self.config = config
        self.seed = seed
        self.observation_filter = observation_filter or config.observation_filter
        self.evidence_field = evidence_field
        self.model_error_field = model_error_field
        self.trace_factory = trace_factory or MultiScaleCausalTrace

    def tick(
        self,
        t: float,
        *,
        civ_tech_level: float = 0.0,
        **outcome_extra: Any,
    ) -> MultiScaleCausalTrace:
        """Run one multi-scale tick and return the structured causal trace."""
        trace = self.trace_factory()
        trace.t = float(t)
        trace.civ_tech_level = float(civ_tech_level)

        # Ground truth the individuals observe (kernel-owned, read-only).
        true_state = self.config.true_state_fn(self.kernel, float(t))

        # --- Layer 1: individuals observe → believe → propose ---------------
        for iid, ind in self.individuals.items():
            obs = ind.observe(self.observation_filter, true_state)
            trace.scientist_observations[iid] = obs
            posterior, btrace = ind.update_belief(
                obs, evidence_field=self.evidence_field,
                model_error_field=self.model_error_field,
            )
            trace.belief_updates[iid] = {
                "prior": _belief_summary(btrace.prior),
                "posterior": _belief_summary(posterior),
                "strategy": btrace.strategy,
                "accepted": btrace.accepted,
                "error_source": btrace.error_source,
                "contradiction": btrace.contradiction,
            }
            trace.proposals[iid] = ind.propose()

        # --- Layer 2: organisation aggregates proposals ---------------------
        org_decision, member_votes, received_audit = self.organization.decide(
            trace.proposals, seed=self.seed,
        )
        trace.org_decision = org_decision
        trace.member_votes = member_votes
        trace.info_propagation = received_audit

        # --- Layer 3: collective → action_vector → kernel outcome -----------
        ctx: Dict[str, Any] = {}
        if self.config.outcome_context_fn is not None:
            ctx.update(self.config.outcome_context_fn(float(t), self.kernel) or {})
        ctx.update(outcome_extra)
        outcome, action_vector = self.collective.decide_outcome(
            org_decision, float(t), **ctx,
        )
        outcome_kind, destroyed = self.collective.outcome_verdict(outcome)
        trace.decision_vector = action_vector
        trace.outcome_kind = outcome_kind
        trace.outcome = _outcome_as_dict(outcome)
        trace.civ_destroyed = bool(destroyed)

        # --- Reflux: individuals revise beliefs given the kernel verdict -----
        reflux_fn = self.config.reflux_evidence_fn or _default_reflux_evidence
        evidence_value, reflux_model_error = reflux_fn(
            outcome, outcome_kind, bool(destroyed),
        )
        for iid, ind in self.individuals.items():
            obs = {
                self.evidence_field: evidence_value,
                self.model_error_field: reflux_model_error,
            }
            posterior, btrace = ind.update_belief(
                obs, evidence_field=self.evidence_field,
                model_error_field=self.model_error_field,
            )
            trace.post_outcome_belief_updates[iid] = {
                "prior": _belief_summary(btrace.prior),
                "posterior": _belief_summary(posterior),
                "strategy": btrace.strategy,
                "accepted": btrace.accepted,
                "error_source": btrace.error_source,
                "contradiction": btrace.contradiction,
                "evidence": evidence_value,
            }

        return trace


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def _belief_summary(belief: Belief) -> Dict[str, Any]:
    return {
        "predicted": belief.predicted,
        "confidence": float(belief.confidence),
        "model_error": bool(belief.model_error),
    }


def _outcome_as_dict(outcome: Any) -> Optional[Dict[str, Any]]:
    if outcome is None:
        return None
    as_dict = getattr(outcome, "as_dict", None)
    if callable(as_dict):
        return as_dict()
    if isinstance(outcome, dict):
        return outcome
    return {
        "kind": getattr(outcome, "kind", ""),
        "cause": getattr(outcome, "cause", ""),
        "t": getattr(outcome, "t", None),
        "tech_level": getattr(outcome, "tech_level", None),
        "decision_quality": getattr(outcome, "decision_quality", None),
    }
