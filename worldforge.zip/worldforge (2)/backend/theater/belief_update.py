"""Belief update layer — the shared epistemic evolution used by every
``SimAgent`` (architecture §8.2 / §10, research notes Q5).

This is the *subjective* belief-revision machinery that sits **under**
``sim_agent.SimAgent.update_belief`` and **over** the kernel-owned ground
truth.  It is pure-stdlib, deterministic and seed-driven — no LLM, no
unseeded randomness (spec §8.2 red line: the LLM only narrates; physics
and observation are kernel-owned).

Three views on the same state
-----------------------------
The central insight from arxiv 2307.05069 is that *dogmatic reinforcement*
and *learning* are not two mechanisms — they are two **revision
strategies** applied to the same belief state.  We expose three of them
on one :class:`theater.cognitive_model.Belief`:

- ``rational``      — standard Bayesian-ish move toward the evidence,
                      weighted by ``evidence_weight × update_rate``.
- ``dogmatic``      — 教条: new evidence is damped (×0.1); when the
                      evidence *contradicts* the prior beyond a tolerance
                      the prior is *pushed away* from the evidence
                      (``-= contradiction × 0.5``) — the backfire /
                      belief-polarisation effect.
- ``conspiratorial``— 阴谋论: contradicting evidence *strengthens* the
                      prior (confidence rises, predicted moves further
                      from the observation).

Personality (``MindProfile``) does not pick decisions — it only shapes
three epistemic knobs already on the profile (``evidence_weight``,
``belief_update_rate``) and derives two more: the revision ``strategy``
and the ``confidence_radius`` used by the bounded-confidence model.  This
mirrors the Q3 rejection of the game-y "stubborn→hoard+20" shortcut.

Bounded-confidence model (Deffuant / Hegselmann-Krause)
-------------------------------------------------------
``bounded_confidence_update`` only lets an agent be influenced by peers
whose committed prediction is within ``confidence_radius`` of its own.
Stubborn agents (small radius) talk past each other; pragmatic agents
(large radius) converge.  One knob, two behaviours.

Replayability
-------------
Every update produces a :class:`BeliefUpdateTrace` recording the prior,
observation, personality modifiers, whether the evidence was accepted or
rejected, and — when the update embodies a mistake — which of the six
error sources it traces to (information / perception / reasoning /
cognitive-bias / goal / execution).  Traces are deterministic: same
inputs → same trace.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field, replace
from typing import Any, Dict, List, Optional, Tuple

from .cognitive_model import Belief


__all__ = [
    "ERROR_SOURCES",
    "BeliefUpdateTrace",
    "derive_strategy",
    "derive_confidence_radius",
    "update_with_evidence",
    "update_with_evidence_traced",
    "bounded_confidence_update",
    "bounded_confidence_update_traced",
    "revise_belief",
    "classify_error_source",
]


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: The six error sources a belief update can trace to (spec error model).
#: Kept as a tuple so membership / iteration order is stable.
ERROR_SOURCES: Tuple[str, ...] = (
    "information_error",  # wrong evidence entered the agent's channel
    "perception_error",  # agent mis-perceived a correct signal
    "reasoning_error",   # correct evidence, faulty inference over it
    "cognitive_bias",    # personality-driven distortion (dogmatic/conspiratorial)
    "goal_error",        # evidence mis-weighted because it serves the wrong goal
    "execution_error",   # right belief, wrong action (not an update error per se)
)

#: Strategies recognised by :func:`update_with_evidence`.
STRATEGIES: Tuple[str, ...] = ("rational", "dogmatic", "conspiratorial")

#: Default tolerance below which evidence is considered *consistent* with
#: the prior rather than *contradicting* it.  Tuned so that a genuine
#: contradiction (e.g. prior 0.5 vs observation 0.9) trips it while a
#: rounding-level discrepancy does not.
DEFAULT_CONTRADICTION_THRESHOLD: float = 1e-6

#: Damping applied to new evidence under the dogmatic strategy.
DOGMATIC_EVIDENCE_DAMPING: float = 0.1

#: Penalty applied to the prior when a contradiction is detected (dogmatic).
DOGMATIC_CONTRADICTION_PENALTY: float = 0.5

#: How far the conspiratorial prior moves *away* from contradicting evidence.
CONSPIRATORIAL_REINFORCE_PULL: float = 0.2

#: Confidence growth per rational update (gentle creep toward 1.0).
RATIONAL_CONFIDENCE_CREEP: float = 0.05


# ---------------------------------------------------------------------------
# BeliefUpdateTrace — replayable record of one revision
# ---------------------------------------------------------------------------


@dataclass
class BeliefUpdateTrace:
    """A replayable record of a single belief revision.

    Captures everything needed to re-derive the posterior deterministically:
    the prior belief, the observation, the personality-derived modifiers,
    the strategy, the computed contradiction, whether the evidence was
    accepted or rejected (and why), the resulting posterior, and — when the
    update embodies one of the six mistake classes — which error source it
    traces to.

    A trace with ``accepted=False`` and a non-null ``error_source`` is the
    signature of a *mistaken* update (the agent distorted or rejected
    evidence it should have integrated).
    """

    topic: str
    prior: Belief
    observation: Any
    evidence_weight: float
    update_rate: float
    strategy: str
    personality_modifiers: Dict[str, float]
    contradiction: float
    accepted: bool
    rejected_info: Optional[str]
    posterior: Belief
    error_source: Optional[str] = None
    seed: Optional[int] = None

    def replay(self) -> Belief:
        """Re-derive the posterior from the recorded inputs.

        Because :func:`update_with_evidence` is a pure function of its
        inputs, replaying a trace with the same recorded values yields the
        same posterior — this is the determinism guarantee (spec §8.2).
        """
        posterior, _ = update_with_evidence_traced(
            prior=self.prior,
            observation=self.observation,
            evidence_weight=self.evidence_weight,
            update_rate=self.update_rate,
            strategy=self.strategy,
            contradiction_threshold=self.personality_modifiers.get(
                "contradiction_threshold", DEFAULT_CONTRADICTION_THRESHOLD
            ),
            seed=self.seed,
            topic=self.topic,
        )
        return posterior


# ---------------------------------------------------------------------------
# Personality → strategy / confidence-radius derivation
# ---------------------------------------------------------------------------


#: Personality keywords signalling a conspiratorial / paranoid mindset.
_CONSPIRATORIAL_KEYWORDS: Tuple[str, ...] = (
    "阴谋", "多疑", "偏执", "被害妄想", "paranoid", "conspiracy",
    "paranoid-schizoid", "delusional",
)


def _has_conspiratorial_tendency(personality_text: str) -> bool:
    """Deterministic substring check for conspiratorial markers."""
    if not personality_text:
        return False
    low = personality_text.lower()
    return any(kw.lower() in low for kw in _CONSPIRATORIAL_KEYWORDS)


def derive_strategy(profile: Any, personality_text: str = "") -> str:
    """Derive the revision strategy from a :class:`MindProfile`.

    Priority (deterministic):

    1. conspiratorial markers in the personality text → ``"conspiratorial"``
    2. stubborn (low ``evidence_weight``) → ``"dogmatic"``
    3. open / rational (high ``evidence_weight``) → ``"rational"``
    4. neutral default → ``"rational"``

    The profile is read structurally (``evidence_weight`` /
    ``belief_update_rate``) so this works for any object that carries those
    attributes, not just the real :class:`MindProfile`.
    """
    if _has_conspiratorial_tendency(personality_text):
        return "conspiratorial"
    ew = float(getattr(profile, "evidence_weight", 1.0))
    # 固执 → low evidence weight → dogmatic
    if ew < 0.6:
        return "dogmatic"
    # open / rational → high evidence weight → rational (also the default)
    return "rational"


def derive_confidence_radius(profile: Any) -> float:
    """Derive the bounded-confidence radius from a :class:`MindProfile`.

    Stubborn agents (slow update / low evidence weight) get a *small*
    radius — they only accept influence from near-identical peers.
    Pragmatic / open agents (fast update / high evidence weight) get a
    *large* radius.  Result is clamped to ``(0, 1]``.
    """
    ew = float(getattr(profile, "evidence_weight", 1.0))
    bur = float(getattr(profile, "belief_update_rate", 0.5))
    # Map the two epistemic knobs into a radius in (0, 1].  Both contribute:
    # higher evidence_weight and higher update_rate → wider radius.
    radius = 0.1 + 0.4 * bur + 0.2 * max(0.0, ew - 1.0)
    return max(0.05, min(1.0, radius))


# ---------------------------------------------------------------------------
# Core revision primitives
# ---------------------------------------------------------------------------


def _coerce_observation(observation: Any) -> Optional[float]:
    """Coerce an observation to a float, or ``None`` if non-numeric.

    Non-numeric observations (events, symbols) cannot move a scalar
    ``Belief.predicted``; they are treated as qualitative evidence and
    only nudge confidence.
    """
    if isinstance(observation, bool):
        # bool is a subclass of int — treat as qualitative to avoid the
        # 0/1 scalar hijacking predicted values.
        return None
    if isinstance(observation, (int, float)):
        return float(observation)
    try:
        return float(observation)
    except (TypeError, ValueError):
        return None


def _signed_contradiction(
    evidence: float, threshold: float
) -> float:
    """Signed contradiction magnitude: ``evidence`` if it exceeds the
    tolerance, else ``0``.

    ``evidence`` here is the *signed* discrepancy ``observation - prior``
    so the sign is preserved when a strategy pushes the prior away from
    the contradicting direction.
    """
    if abs(evidence) > threshold:
        return evidence
    return 0.0


def _clamp_confidence(value: float) -> float:
    return max(0.0, min(1.0, value))


def _rational_update(
    prior: Belief, evidence: float, ew: float, ur: float
) -> Belief:
    """Standard Bayesian-ish move toward the evidence.

    ``predicted += evidence × evidence_weight × update_rate`` (task spec).
    Confidence creeps gently toward 1.0 — the agent grows marginally more
    confident each time it integrates evidence, mirroring the P1 skeleton.
    """
    new_predicted = (prior.predicted or 0.0) + evidence * ew * ur
    new_confidence = _clamp_confidence(prior.confidence + ur * RATIONAL_CONFIDENCE_CREEP)
    return replace(
        prior,
        predicted=new_predicted,
        confidence=new_confidence,
        committed_values=dict(prior.committed_values),
    )


def _dogmatic_update(
    prior: Belief,
    evidence: float,
    contradiction: float,
    ew: float,
    ur: float,
) -> Belief:
    """教条: damped evidence + contradiction backfire.

    ``predicted += evidence × ew × ur × 0.1`` — new evidence barely moves
    the prior.  When the evidence *contradicts* the prior (exceeds the
    tolerance), the prior is *pushed away* from the evidence:
    ``predicted -= contradiction × 0.5``.  This is the belief-polarisation
    / dogmatic reinforcement effect (arxiv 2307.05069): repeated
    contradicting evidence drives the prior further from the observation
    rather than toward it.
    """
    new_predicted = (
        (prior.predicted or 0.0)
        + evidence * ew * ur * DOGMATIC_EVIDENCE_DAMPING
        - contradiction * DOGMATIC_CONTRADICTION_PENALTY
    )
    # Confidence barely moves under dogma — the agent is sure of itself.
    new_confidence = _clamp_confidence(prior.confidence + ur * 0.01)
    return replace(
        prior,
        predicted=new_predicted,
        confidence=new_confidence,
        committed_values=dict(prior.committed_values),
    )


def _conspiratorial_update(
    prior: Belief,
    evidence: float,
    contradiction: float,
    ew: float,
    ur: float,
) -> Belief:
    """阴谋论: contradicting evidence *strengthens* the prior.

    When evidence contradicts the prior, the agent (a) moves its
    prediction *further away* from the observation and (b) *raises* its
    confidence — the backfire effect in its strongest form.  Consistent
    evidence (within tolerance) is integrated weakly, like a cautious
    rational update.
    """
    if contradiction != 0.0:
        new_predicted = (prior.predicted or 0.0) - contradiction * CONSPIRATORIAL_REINFORCE_PULL
        # contradiction strengthens belief: confidence rises with the size
        # of the (perceived) assault on it.
        new_confidence = _clamp_confidence(
            prior.confidence + abs(contradiction) * 0.3 * ew
        )
    else:
        # consistent evidence: cautious move toward it
        new_predicted = (prior.predicted or 0.0) + evidence * ew * ur * 0.5
        new_confidence = _clamp_confidence(prior.confidence + ur * 0.02)
    return replace(
        prior,
        predicted=new_predicted,
        confidence=new_confidence,
        committed_values=dict(prior.committed_values),
    )


def update_with_evidence_traced(
    prior: Belief,
    observation: Any,
    evidence_weight: float,
    update_rate: float,
    strategy: str = "rational",
    contradiction_threshold: float = DEFAULT_CONTRADICTION_THRESHOLD,
    seed: Optional[int] = None,
    topic: str = "",
    observation_validated: bool = True,
) -> Tuple[Belief, BeliefUpdateTrace]:
    """Revise ``prior`` with ``observation`` and return the posterior
    plus a full :class:`BeliefUpdateTrace`.

    Parameters
    ----------
    prior:
        The current committed belief.
    observation:
        The new evidence (numeric predictions move ``predicted``;
        non-numeric observations only nudge confidence).
    evidence_weight:
        Personality-derived weight on the evidence (固执 ×0.3, 开放 ×1.5).
    update_rate:
        Personality-derived speed of revision (固执 slow, 理性 fast).
    strategy:
        One of ``"rational"`` / ``"dogmatic"`` / ``"conspiratorial"``.
    contradiction_threshold:
        Tolerance below which evidence counts as consistent.
    seed:
        Optional seed; the current strategies are fully deterministic and
        do not consume it, but it is recorded on the trace for replay and
        for any future stochastic tie-breaking.
    topic:
        Belief key, for trace readability.
    observation_validated:
        If ``False`` the observation itself is suspect → the trace's
        ``error_source`` is tagged ``"perception_error"`` (or
        ``"information_error"`` for a clearly wrong channel).
    """
    if strategy not in STRATEGIES:
        raise ValueError(
            f"unknown strategy {strategy!r}; expected one of {STRATEGIES}"
        )

    ew = float(evidence_weight)
    ur = float(update_rate)

    obs_float = _coerce_observation(observation)

    # Non-numeric observation: qualitative evidence — predicted unchanged,
    # confidence nudged.  No contradiction is computed.
    if obs_float is None:
        new_confidence = _clamp_confidence(prior.confidence + ur * 0.02)
        posterior = replace(
            prior,
            confidence=new_confidence,
            committed_values=dict(prior.committed_values),
        )
        error_source = None if observation_validated else "perception_error"
        trace = BeliefUpdateTrace(
            topic=topic,
            prior=prior,
            observation=observation,
            evidence_weight=ew,
            update_rate=ur,
            strategy=strategy,
            personality_modifiers={
                "evidence_weight": ew,
                "update_rate": ur,
                "contradiction_threshold": contradiction_threshold,
            },
            contradiction=0.0,
            accepted=True,
            rejected_info=None,
            posterior=posterior,
            error_source=error_source,
            seed=seed,
        )
        return posterior, trace

    base = prior.predicted if prior.predicted is not None else 0.0
    evidence = obs_float - base
    contradiction = _signed_contradiction(evidence, contradiction_threshold)

    if strategy == "rational":
        posterior = _rational_update(prior, evidence, ew, ur)
    elif strategy == "dogmatic":
        posterior = _dogmatic_update(prior, evidence, contradiction, ew, ur)
    else:  # conspiratorial
        posterior = _conspiratorial_update(prior, evidence, contradiction, ew, ur)

    # An update is "accepted" when the evidence actually moved the prior
    # toward the observation (or, for conspiratorial consistent evidence,
    # was integrated at all).  A backfire (dogmatic/conspiratorial under
    # contradiction) counts as *rejected* — the agent refused to learn.
    moved_toward = (posterior.predicted - base) * evidence > 0 if evidence != 0 else True
    backfired = strategy in ("dogmatic", "conspiratorial") and contradiction != 0.0
    accepted = moved_toward and not backfired

    if backfired:
        rejected_info = f"{strategy} backfire: contradiction reinforced prior"
    elif not moved_toward:
        rejected_info = "update moved away from evidence"
    else:
        rejected_info = None

    error_source = classify_error_source(
        strategy=strategy,
        accepted=accepted,
        contradiction=contradiction,
        observation_validated=observation_validated,
    )

    trace = BeliefUpdateTrace(
        topic=topic,
        prior=prior,
        observation=observation,
        evidence_weight=ew,
        update_rate=ur,
        strategy=strategy,
        personality_modifiers={
            "evidence_weight": ew,
            "update_rate": ur,
            "contradiction_threshold": contradiction_threshold,
        },
        contradiction=contradiction,
        accepted=accepted,
        rejected_info=rejected_info,
        posterior=posterior,
        error_source=error_source,
        seed=seed,
    )
    return posterior, trace


def update_with_evidence(
    prior: Belief,
    observation: Any,
    evidence_weight: float,
    update_rate: float,
    strategy: str = "rational",
    contradiction_threshold: float = DEFAULT_CONTRADICTION_THRESHOLD,
    seed: Optional[int] = None,
) -> Belief:
    """Revise ``prior`` with ``observation`` — returns only the posterior.

    Thin convenience wrapper around :func:`update_with_evidence_traced`
    for callers that do not need the trace.
    """
    posterior, _ = update_with_evidence_traced(
        prior=prior,
        observation=observation,
        evidence_weight=evidence_weight,
        update_rate=update_rate,
        strategy=strategy,
        contradiction_threshold=contradiction_threshold,
        seed=seed,
        topic="",
    )
    return posterior


# ---------------------------------------------------------------------------
# Bounded-confidence (Deffuant / Hegselmann-Krause) update
# ---------------------------------------------------------------------------


def bounded_confidence_update_traced(
    agent_belief: Belief,
    other_beliefs: List[Belief],
    confidence_radius: float,
    weight: float,
    seed: Optional[int] = None,
    topic: str = "",
) -> Tuple[Belief, BeliefUpdateTrace]:
    """Deffuant-style bounded-confidence revision.

    Only peers whose committed ``predicted`` is within
    ``confidence_radius`` of the agent's own ``predicted`` influence the
    agent.  The agent moves a fraction ``weight`` of the mean signed
    difference toward those peers.  Peers outside the radius are
    *ignored* — recorded on the trace as rejected influence.

    Peers with ``predicted is None`` are skipped (no scalar to compare).

    Returns the posterior belief and a trace whose ``rejected_info``
    captures how many peers were out of radius (the cognitive-bias
    signature of an echo chamber).
    """
    base = agent_belief.predicted if agent_belief.predicted is not None else 0.0
    within: List[float] = []
    rejected = 0
    for other in other_beliefs:
        if other.predicted is None:
            continue
        diff = other.predicted - base
        if abs(diff) < confidence_radius:
            within.append(diff)
        else:
            rejected += 1

    if within:
        mean_diff = sum(within) / len(within)
        new_predicted = base + weight * mean_diff
        # Integrating peers nudges confidence up slightly.
        new_confidence = _clamp_confidence(
            agent_belief.confidence + 0.02 * len(within) / max(1, len(other_beliefs))
        )
        accepted = True
        rejected_info = (
            f"integrated {len(within)} peer(s); {rejected} out of radius"
            if rejected else f"integrated {len(within)} peer(s)"
        )
    else:
        new_predicted = base
        new_confidence = agent_belief.confidence
        accepted = False
        rejected_info = (
            f"echo chamber: 0/{len(other_beliefs)} peers within radius"
            if other_beliefs else "no peers to consult"
        )

    posterior = replace(
        agent_belief,
        predicted=new_predicted,
        confidence=new_confidence,
        committed_values=dict(agent_belief.committed_values),
    )

    error_source = (
        "cognitive_bias" if (not accepted and other_beliefs) else None
    )

    trace = BeliefUpdateTrace(
        topic=topic,
        prior=agent_belief,
        observation=[b.predicted for b in other_beliefs],
        evidence_weight=weight,
        update_rate=0.0,  # bounded confidence does not use update_rate
        strategy="bounded_confidence",
        personality_modifiers={"confidence_radius": confidence_radius},
        contradiction=0.0,
        accepted=accepted,
        rejected_info=rejected_info,
        posterior=posterior,
        error_source=error_source,
        seed=seed,
    )
    return posterior, trace


def bounded_confidence_update(
    agent_belief: Belief,
    other_beliefs: List[Belief],
    confidence_radius: float,
    weight: float,
    seed: Optional[int] = None,
) -> Belief:
    """Bounded-confidence revision — returns only the posterior."""
    posterior, _ = bounded_confidence_update_traced(
        agent_belief=agent_belief,
        other_beliefs=other_beliefs,
        confidence_radius=confidence_radius,
        weight=weight,
        seed=seed,
    )
    return posterior


# ---------------------------------------------------------------------------
# Error-source classification
# ---------------------------------------------------------------------------


def classify_error_source(
    strategy: str,
    accepted: bool,
    contradiction: float,
    observation_validated: bool = True,
) -> Optional[str]:
    """Tag a revision with one of the six error sources, or ``None`` when
    the update is epistemically clean.

    Mapping (deterministic):

    - observation not validated → ``"perception_error"`` (the agent
      mis-perceived a signal) — caller may upgrade this to
      ``"information_error"`` if the channel itself was wrong.
    - dogmatic / conspiratorial backfire (contradiction → prior moved
      away from evidence) → ``"cognitive_bias"``.
    - bounded-confidence echo chamber (no peers within radius) →
      ``"cognitive_bias"`` (set by the bounded-confidence caller).
    - otherwise ``None``.
    """
    if not observation_validated:
        return "perception_error"
    if strategy in ("dogmatic", "conspiratorial") and contradiction != 0.0:
        return "cognitive_bias"
    if strategy == "bounded_confidence" and not accepted:
        return "cognitive_bias"
    return None


# ---------------------------------------------------------------------------
# High-level convenience: revise_belief from a MindProfile
# ---------------------------------------------------------------------------


def revise_belief(
    prior: Belief,
    observation: Any,
    profile: Any,
    topic: str = "",
    personality_text: str = "",
    contradiction_threshold: float = DEFAULT_CONTRADICTION_THRESHOLD,
    seed: Optional[int] = None,
    observation_validated: bool = True,
) -> Tuple[Belief, BeliefUpdateTrace]:
    """Wire :func:`derive_strategy` + :func:`update_with_evidence_traced`.

    This is the entry point a future ``SimAgent.update_belief`` will call:
    given a ``MindProfile`` and an observation, pick the strategy and
    modifiers, run the revision, and return the posterior with a full
    trace.  Pure and deterministic.
    """
    strategy = derive_strategy(profile, personality_text)
    ew = float(getattr(profile, "evidence_weight", 1.0))
    ur = float(getattr(profile, "belief_update_rate", 0.5))
    posterior, trace = update_with_evidence_traced(
        prior=prior,
        observation=observation,
        evidence_weight=ew,
        update_rate=ur,
        strategy=strategy,
        contradiction_threshold=contradiction_threshold,
        seed=seed,
        topic=topic,
        observation_validated=observation_validated,
    )
    # Augment the trace's personality_modifiers with the derived radius
    # so a caller can see the full personality → epistemics mapping.
    trace.personality_modifiers["confidence_radius"] = derive_confidence_radius(profile)
    trace.personality_modifiers["strategy"] = strategy
    return posterior, trace
