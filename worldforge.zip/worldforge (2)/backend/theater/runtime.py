import hashlib
import json
import threading
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from .gates import ScienceDirectorGate
from .models import CharacterEntry, CharacterPatch, Task
from .storage import JsonStateStore


class TaskManager:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "tasks.json"
        self._lock = threading.RLock()
        if not self.path.exists():
            self._save({"sessions": {}})
        else:
            self._migrate_legacy_rows()

    def _migrate_legacy_rows(self) -> None:
        """Normalize queued jobs written by pre-v6 runtimes.

        The task queue itself is generic.  This one-time pass removes retired
        callback/prompt fields and converts the former scene intent to the
        neutral world-update intent before any row is exposed through the API.
        """
        try:
            state = self._load()
        except (OSError, json.JSONDecodeError, TypeError):
            return
        changed = False
        sessions = dict(state.get("sessions") or {})
        removed_types = {
            "image_generation",
            "audio_generation",
            "portrait_generation",
            "animation_generation",
        }
        for session_id, raw_rows in list(sessions.items()):
            cleaned = []
            for raw_row in list(raw_rows or []):
                if not isinstance(raw_row, dict):
                    changed = True
                    continue
                row = dict(raw_row)
                if str(row.get("type") or "") in removed_types:
                    changed = True
                    continue
                if row.pop("callback", None) is not None:
                    changed = True
                payload = dict(row.get("payload") or {})
                if payload.get("intent") == "scene_generation":
                    payload["intent"] = "world_update"
                    changed = True
                for key in ("scene_prompt", "audio_prompt"):
                    if payload.pop(key, None) is not None:
                        changed = True
                row["payload"] = payload
                cleaned.append(row)
            sessions[session_id] = cleaned
        if changed:
            state["sessions"] = sessions
            self._save(state)

    def _load(self) -> Dict[str, object]:
        with self._lock:
            return json.loads(self.path.read_text(encoding="utf-8"))

    def _save(self, state: Dict[str, object]) -> None:
        with self._lock:
            temp = self.path.with_suffix(".json.tmp")
            temp.write_text(
                json.dumps(state, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            temp.replace(self.path)

    def enqueue(self, session_id: str, tasks: Iterable[Task]) -> List[Task]:
        with self._lock:
            state = self._load()
            sessions = dict(state.get("sessions") or {})
            existing = list(sessions.get(session_id) or [])
            for task in tasks:
                queued = task.to_dict()
                queued["status"] = "queued"
                existing = [
                    item for item in existing
                    if item.get("task_id") != task.task_id
                ]
                existing.append(queued)
            sessions[session_id] = sorted(
                enumerate(existing),
                key=lambda item: (
                    int(item[1].get("priority") or 999),
                    item[0],
                ),
            )
            sessions[session_id] = [item for _, item in sessions[session_id]]
            state["sessions"] = sessions
            self._save(state)
        return self.list_tasks(session_id)

    def mark(self, session_id: str, task_id: str, status: str) -> Optional[Task]:
        with self._lock:
            state = self._load()
            sessions = dict(state.get("sessions") or {})
            rows = list(sessions.get(session_id) or [])
            found: Optional[Task] = None
            for row in rows:
                if row.get("task_id") == task_id:
                    row["status"] = status
                    found = self._task_from_dict(row)
            sessions[session_id] = rows
            state["sessions"] = sessions
            self._save(state)
        return found

    def list_tasks(self, session_id: Optional[str] = None) -> List[Task]:
        with self._lock:
            state = self._load()
            sessions = dict(state.get("sessions") or {})
            rows: List[Dict[str, object]] = []
            if session_id:
                rows.extend(sessions.get(session_id) or [])
            else:
                for session_rows in sessions.values():
                    rows.extend(session_rows)
            ordered = sorted(
                enumerate(rows),
                key=lambda item: (
                    int(item[1].get("priority") or 999),
                    item[0],
                ),
            )
            return [self._task_from_dict(row) for _, row in ordered]

    def _task_from_dict(self, row: Dict[str, object]) -> Task:
        return Task(
            task_id=str(row["task_id"]),
            type=str(row["type"]),
            priority=int(row["priority"]),
            payload=dict(row.get("payload") or {}),
            status=str(row.get("status") or "queued"),
        )


class PossessionManager:
    def __init__(self, state_store: JsonStateStore, science_gate: ScienceDirectorGate):
        self.state_store = state_store
        self.science_gate = science_gate

    def enter_possession(self, character_id: str, player_id: str, reason: str = "") -> CharacterEntry:
        current = self._current_character(character_id)
        patch = CharacterPatch(
            character_id=current.character_id,
            name=current.name,
            summary=f"{current.summary} Possession channel active for {player_id}.",
            source="possession_manager",
            possessed=True,
            possessed_by=player_id,
            ai_subconscious=f"AI output suppressed while {player_id} controls this actor. Reason: {reason}".strip(),
            pending_ai_actions=current.pending_ai_actions,
            possession_limit=current.possession_limit,
        )
        return self._write_patch(patch)

    def queue_ai_action(self, character_id: str, action: Dict[str, object]) -> CharacterEntry:
        current = self._current_character(character_id)
        pending = list(current.pending_ai_actions)
        pending.append(dict(action))
        patch = CharacterPatch(
            character_id=current.character_id,
            name=current.name,
            summary=current.summary,
            source="possession_manager",
            possessed=current.possessed,
            possessed_by=current.possessed_by,
            ai_subconscious=current.ai_subconscious,
            pending_ai_actions=pending,
            possession_limit=current.possession_limit,
        )
        return self._write_patch(patch)

    def exit_possession(self, character_id: str) -> CharacterEntry:
        current = self._current_character(character_id)
        patch = CharacterPatch(
            character_id=current.character_id,
            name=current.name,
            summary=current.summary.replace(" Possession channel active for player_01.", ""),
            source="possession_manager",
            possessed=False,
            possessed_by=None,
            ai_subconscious="",
            pending_ai_actions=[],
            possession_limit=current.possession_limit,
        )
        return self._write_patch(patch)

    def execute_action(
        self, character_id: str, verb: str, payload: Optional[dict] = None,
        *, executor=None,
    ) -> dict:
        """Execute a player-driven action while possessing a character (张力5).

        Before this, PossessionManager had enter/exit/queue + an
        ``allowed_actions`` *declaration* but no executor — the player could
        say "去北边" during possession and nothing routed it. This method
        closes the loop: the player's verb is checked against the possessed
        character's ``allowed_actions`` (setuid, §10.6 — the player gets only
        that character's permissions), and on approval the ``executor``
        callback applies it through the orchestrator's single write point
        (I4). Disallowed verbs are rejected before any state touches.

        Parameters
        ----------
        character_id: the possessed actor.
        verb:         the action verb (must be in allowed_actions).
        payload:      optional action params (e.g. direction, target object).
        executor:    ``callable(verb, payload) -> dict`` provided by the
                      orchestrator; it owns the actual state mutation (object
                      interaction via the gate, worldbook fact, etc.). When
                      ``None`` the verb is only validated, not applied.

        Returns ``{ok, character_id, verb, allowed, reason, result}``.
        """
        current = self._current_character(character_id)
        allowed = list((current.possession_limit or {}).get("allowed_actions") or [])
        result: Dict[str, object] = {
            "ok": False, "character_id": character_id, "verb": verb,
            "allowed": list(allowed), "reason": "", "result": None,
        }
        if not current.possessed:
            result["reason"] = "character is not possessed"
            return result
        verb_s = str(verb or "").strip().lower()
        if not verb_s:
            result["reason"] = "verb required"
            return result
        if verb_s not in [a.lower() for a in allowed]:
            result["reason"] = f"verb {verb_s!r} not in allowed_actions {allowed}"
            return result
        if executor is None:
            # Validation-only path (no state mutation). Lets callers probe
            # whether a verb would be accepted without committing it.
            result["ok"] = True
            result["reason"] = "validated (no executor)"
            return result
        try:
            outcome = executor(verb_s, payload or {})
        except Exception as exc:
            result["reason"] = f"executor raised: {exc}"
            return result
        result["ok"] = bool(outcome.get("ok", True)) if isinstance(outcome, dict) else True
        result["result"] = outcome
        return result

    def _current_character(self, character_id: str) -> CharacterEntry:
        snapshot = self.state_store.snapshot()
        for character in snapshot.characters:
            if character.character_id == character_id:
                return character
        return CharacterEntry(
            character_id=character_id,
            name=character_id.title(),
            summary="Runtime-created actor awaiting full character card.",
            source="possession_manager",
        )

    def _write_patch(self, patch: CharacterPatch) -> CharacterEntry:
        approval = self.science_gate.validate_write([], [patch])
        if not approval.approved:
            raise ValueError("; ".join(approval.reasons))
        self.state_store.upsert_character(patch, approved_by=approval.director_id)
        return self._current_character(patch.character_id)


class GameSessionManager:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "game_sessions.json"
        if not self.path.exists():
            self._save({"sessions": {}})

    def _load(self) -> Dict[str, object]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _save(self, state: Dict[str, object]) -> None:
        self.path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    def step(self, session_id: str, command: str) -> Dict[str, object]:
        state = self._load()
        sessions = dict(state.get("sessions") or {})
        session = dict(sessions.get(session_id) or {"tick": 0, "history": []})
        tick = int(session.get("tick") or 0) + 1
        history = list(session.get("history") or [])
        event = {"tick": tick, "command": command}
        history.append(event)
        session.update({"session_id": session_id, "tick": tick, "last_command": command, "history": history[-20:]})
        sessions[session_id] = session
        state["sessions"] = sessions
        self._save(state)
        return session

    def snapshot(self) -> Dict[str, object]:
        return self._load()


class EmbeddingMemory:
    def __init__(self, dimensions: int = 32):
        self.dimensions = dimensions

    def embed(self, text: str) -> Dict[str, object]:
        values: List[float] = []
        seed = text.encode("utf-8")
        counter = 0
        while len(values) < self.dimensions:
            digest = hashlib.sha256(seed + str(counter).encode("ascii")).digest()
            for byte in digest:
                values.append(round((byte / 127.5) - 1.0, 6))
                if len(values) == self.dimensions:
                    break
            counter += 1
        return {
            "provider": "local_hash_embedding",
            "dimensions": self.dimensions,
            "embedding": values,
        }


class WorldClock:
    """Background thread that autonomously advances the world when idle.

    Wraps an :class:`~theater.idle_loop.IdleLoop` and fires its ``tick()`` every
    ``interval`` seconds from a daemon thread. The idle *timer* is the
    orchestrator's own ``_last_activity`` (reset on every player dispatch);
    :class:`IdleLoop` only adds the saturation cap. Player dispatches should
    also call ``idle_loop.on_user_activity()`` to reset the cap (see
    :meth:`TheaterOrchestrator.dispatch`).

    Spec §13.4: the world keeps living during silence, but a saturation cap
    prevents an offline world from running the story to its end.
    """

    def __init__(self, orchestrator, interval: int,
                 idle_threshold: Optional[float] = None,
                 max_advances: int = 5):
        from .idle_loop import IdleLoop  # local import — idle_loop is stdlib-only
        self.orchestrator = orchestrator
        self.interval = max(0, int(interval))
        # idle_threshold defaults to the tick interval when not specified: the
        # world advances one beat per interval once the player has been quiet
        # for at least that long.
        threshold = idle_threshold if idle_threshold is not None else float(self.interval)
        self.idle_loop = IdleLoop(
            orchestrator, orchestrator.world_id,
            idle_threshold=threshold, max_advances=max_advances,
        )
        # Register the loop on the orchestrator so dispatch() can reset its
        # saturation cap on player activity (single shared idle timer).
        if hasattr(orchestrator, "attach_idle_loop"):
            orchestrator.attach_idle_loop(self.idle_loop)
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> bool:
        if self.interval <= 0 or self._thread is not None:
            return False
        self._thread = threading.Thread(target=self._run, name="world-clock", daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        while not self._stop.wait(min(self.interval, 5)):
            try:
                self.idle_loop.tick()
            except Exception:
                continue
