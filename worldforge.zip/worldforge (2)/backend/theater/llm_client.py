"""Standard OpenAI-compatible LLM client for onboarding authoring.

Replaces the former Spark SSH-tunnel client. Speaks the standard OpenAI
Chat Completions protocol — ``POST {base_url}/chat/completions`` with a
``messages`` array of ``{role, content}`` objects — over urllib. No SSH,
no paramiko, no Spark-specific topology.

Exposes two ``llm_fn`` shapes the generators expect, both SINGLE-ARG
(``prompt -> ...``) so the contract is uniform across the codebase:

* :meth:`OpenAILLMClient.as_text_fn` -> ``Callable[[str], str]``
  (prompt -> raw text). Used by RuleGenerator / GameplayGenerator /
  CognitiveModelGenerator / ThreeBodyNarrator.

* :meth:`OpenAILLMClient.as_dict_fn` -> ``Callable[[str], dict]``
  (prompt -> parsed JSON dict). Used by GUIGenerator / WorldCreator.

When a generator needs a system prompt it folds it into the prompt before
calling ``llm_fn``; the client sends the combined text as the user
message. ``complete`` also accepts an optional ``system`` for callers
that want a separate system message (e.g. character cards).

Credentials come ONLY from :class:`theater.settings.Settings` (env vars /
``.env``) — never hardcoded. ``build_llm`` in :mod:`theater.onboarding_llm`
constructs a client from settings or returns ``None`` with a message when
unconfigured, so integration boundaries can stop the current generation step
with an explicit error.

Robustness: network failures and parse errors raise immediately. Creation
callers surface the failure and never substitute a preset or offline skeleton.
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from typing import Any, Callable, Dict

_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)
_JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)


class LLMError(RuntimeError):
    """Raised on any unrecoverable LLM failure (connect/parse)."""


class OpenAILLMClient:
    """Client for any OpenAI-compatible ``/v1/chat/completions`` endpoint.

    Cheap to construct; each :meth:`complete` call is a standalone HTTP
    POST. Network failures are not retried here because callers own fallback
    policy.
    """

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str = "",
    ) -> None:
        if not base_url:
            raise LLMError(
                "base_url is required (set AI_THEATER_BASE_URL)."
            )
        if not model:
            raise LLMError(
                "model is required (set AI_THEATER_MODEL_FAST)."
            )
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._model = model

    # -- public API ---------------------------------------------------------

    def complete(
        self,
        prompt: str,
        *,
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 2048,
        json_mode: bool = False,
    ) -> str:
        """Return the LLM's raw text response for *prompt*.

        ``system`` is sent as a separate system message when non-empty.
        ``json_mode=True`` adds ``response_format: {type: json_object}`` to
        the request body for providers that implement that OpenAI option.
        Generic OpenAI-compatible providers differ here, so dict-path callers
        rely on explicit prompts plus strict local parsing by default.
        Transient provider/network failures are retried up to three times.
        Persistent failures raise :class:`LLMError`; the current semantic
        step blocks and no substitute content is generated.
        """
        messages: list = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        request_body: dict = {
            "model": self._model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        if json_mode:
            request_body["response_format"] = {"type": "json_object"}
        body = json.dumps(request_body).encode("utf-8")
        url = self._base_url
        if not url.endswith("/chat/completions"):
            url = url + "/chat/completions"
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        req = urllib.request.Request(
            url,
            data=body,
            headers=headers,
            method="POST",
        )
        attempts = 3
        for attempt in range(attempts):
            try:
                with urllib.request.urlopen(req) as resp:
                    payload = json.loads(resp.read().decode("utf-8"))
                return _extract_content(payload)
            except urllib.error.HTTPError as exc:
                try:
                    detail = exc.read().decode(
                        "utf-8", errors="replace",
                    ).strip()
                except Exception:
                    detail = ""
                transient = (
                    exc.code in {408, 429, 500, 502, 503, 504}
                    or "connection closed" in detail.lower()
                    or "temporarily unavailable" in detail.lower()
                    or "peer_keepalive_timeout" in detail.lower()
                    or "connection entered error state" in detail.lower()
                )
                if transient and attempt + 1 < attempts:
                    continue
                suffix = (
                    f"; provider response: {detail[:2000]}"
                    if detail else ""
                )
                raise LLMError(
                    f"HTTP call to {url} failed after {attempt + 1} "
                    f"attempt(s): HTTP {exc.code} {exc.reason}{suffix}"
                ) from exc
            except (urllib.error.URLError, OSError) as exc:
                if attempt + 1 < attempts:
                    continue
                raise LLMError(
                    f"HTTP call to {url} failed after {attempts} attempts: "
                    f"{exc.__class__.__name__}: {exc}"
                ) from exc
            except (
                json.JSONDecodeError,
                KeyError,
                IndexError,
                TypeError,
            ) as exc:
                raise LLMError(
                    f"unexpected response shape from {url}: "
                    f"{exc.__class__.__name__}: {exc}"
                ) from exc
        raise LLMError(f"HTTP call to {url} failed without a response")

    def as_text_fn(
        self, *, temperature: float = 0.7, max_tokens: int = 2048,
        json_mode: bool = False,
    ) -> Callable[[str], str]:
        """Return a ``prompt -> str`` callable (single-arg).

        ``json_mode=True`` forces JSON output (for callers that parse the
        text as JSON themselves, like RuleGenerator).
        """
        def _fn(prompt: str) -> str:
            return self.complete(
                prompt,
                temperature=temperature,
                max_tokens=max_tokens,
                json_mode=json_mode,
            )
        return _fn

    def as_dict_fn(
        self, *, temperature: float = 0.7, max_tokens: int = 2048
    ) -> Callable[[str], Dict[str, Any]]:
        """Return a ``prompt -> dict`` callable (single-arg).

        The LLM's text response is parsed as JSON; on failure we try to
        extract a ```json``` fence or the outermost ``{...}`` block. If all
        parsing fails we **raise** — the caller decides whether to fall back.
        """
        def _fn(prompt: str) -> Dict[str, Any]:
            raw = self.complete(
                prompt,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return _parse_json_obj(raw)
        return _fn


# ---------------------------------------------------------------------------
# Response / JSON parsing helpers
# ---------------------------------------------------------------------------


def _extract_content(payload: Any) -> str:
    """Pull the assistant message content out of an OpenAI-style response.

    Some reasoning models (e.g. bonsai 1bit) put their output in
    ``reasoning_content`` while ``content`` is empty — fall back to
    ``reasoning_content`` when ``content`` is missing or blank.
    """
    try:
        msg = payload["choices"][0]["message"]
    except (KeyError, IndexError, TypeError) as exc:
        raise LLMError(
            f"unexpected response shape: {str(payload)[:200]}"
        ) from exc
    content = msg.get("content") or ""
    if not content.strip():
        # Reasoning models may populate reasoning_content instead.
        content = msg.get("reasoning_content") or ""
    return content


def _parse_json_obj(raw: str) -> Dict[str, Any]:
    """Parse *raw* LLM text into a dict.

    Tries, in order: direct ``json.loads``; ```json``` fence extraction;
    outermost ``{...}`` block. Raises :class:`LLMError` if nothing parses
    to a dict — never silently returns garbage.
    """
    text = (raw or "").strip()
    if not text:
        raise LLMError("LLM returned empty content")
    # 1. direct parse
    try:
        value = json.loads(text)
        if isinstance(value, dict):
            return value
    except (ValueError, TypeError):
        pass
    # 2. ```json ... ``` fence
    fence = _JSON_FENCE_RE.search(text)
    if fence:
        candidate = fence.group(1).strip()
        try:
            value = json.loads(candidate)
            if isinstance(value, dict):
                return value
        except (ValueError, TypeError):
            pass
    # 3. first complete JSON object (handles trailing text / multiple objects)
    try:
        decoder = json.JSONDecoder()
        # Find the first '{' and decode from there
        start = text.find("{")
        if start >= 0:
            value, end = decoder.raw_decode(text[start:])
            if isinstance(value, dict):
                return value
    except (ValueError, TypeError):
        pass
    raise LLMError(
        f"LLM output is not valid JSON (dict expected). head={text[:200]!r}"
    )


__all__ = ["OpenAILLMClient", "LLMError", "_parse_json_obj"]
