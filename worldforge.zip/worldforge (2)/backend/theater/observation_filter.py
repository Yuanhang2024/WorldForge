"""Observation filter layer (architecture spec §8 — four imperfection types).

The red line (§8.2): the kernel owns physics and **observations**; the LLM
only narrates.  ``ObservationFilter`` factors the *subjective observation*
out of the kernel: a subject never sees the raw ground truth, it sees a
filtered, possibly-wrong observation.  The gap between ground truth and the
observation is the first of the six structured error sources (§10 —
information error / perception error / reasoning error / cognitive bias /
wrong goal / execution error).

Four observation imperfection types (§8):

    - **invisible**      — the subject cannot perceive the quantity at all
                           (e.g. another trader's private inventory, the
                           true aggregate supply/demand).  The filter
                           returns ``None`` for that field.
    - **delayed**        — the subject sees a stale value from N ticks ago.
                           Realised by returning the back of a per-agent
                           observation history deque.
    - **noisy**          — the subject sees the true value perturbed by a
                           deterministic, seed-driven offset (a seeded RNG
                           so the *same* seed → the *same* noise every run).
    - **interpretation bias** — a public signal (e.g. an official "market is
                           stable" proclamation) is presented with a bias
                           flag attached, so a stubborn agent can later
                           up-weight it and a rational agent can discount
                           it.  The filter tags it; the belief-update layer
                           reads the tag.

This module owns the **observation** step only.  It does not form beliefs,
make decisions, or touch world state — those are AgentMind / kernel
territory.  Everything here is deterministic and seed-driven; no LLM, no
ambient randomness.

Generalisation: ``ObservationFilter`` is a world-agnostic Protocol (the same
shape a three-body observer or a card-game observer would implement).
``MarketObservationFilter`` is the economy adapter used by
:class:`theater.trader_mind.TraderMind`.
"""

from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Protocol, runtime_checkable


__all__ = [
    "Observation",
    "MarketObservation",
    "ObservationFilter",
    "MarketObservationFilter",
    "ObservationField",
]


@dataclass
class ObservationField:
    """A single perceived quantity, tagged with how it was observed.

    imperfection ∈ {"exact","invisible","delayed","noisy",
                     "interpretation_bias"}; source tags provenance
    ("own_ledger"/"public_tape"/"official"/"rumour"/"aggregate") so the
    belief-update layer can weight each kind (§10 cognitive bias).
    """

    name: str
    value: Optional[float]
    imperfection: str = "exact"
    source: str = ""
    delay: int = 0
    noise: float = 0.0
    bias_tag: str = ""


@dataclass
class Observation:
    """What one subject perceives of the world at tick ``t``."""

    agent_id: str
    t: int
    fields: Dict[str, ObservationField] = field(default_factory=dict)

    def get(self, name: str) -> Optional[float]:
        f = self.fields.get(name)
        return None if f is None else f.value

    def field(self, name: str) -> Optional[ObservationField]:
        return self.fields.get(name)


@dataclass
class MarketObservation(Observation):
    """An economy-flavoured :class:`Observation`."""

    own_inventory: float = 0.0
    own_cash: float = 0.0

    def public_price(self) -> Optional[float]:
        return self.get("price")

    def official_claim(self) -> Optional[str]:
        f = self.field("official_claim")
        if f is None or f.value is None:
            return None
        return str(f.bias_tag) or None


@runtime_checkable
class ObservationFilter(Protocol):
    """World-agnostic observation filter (spec §8).

    Implementations are pure functions of ``(true_state, binding, seed)``
    — the same inputs yield the same observation (deterministic
    misperception, not a random fluke).
    """

    def observe(
        self,
        true_state: Dict[str, Any],
        agent_binding: Dict[str, Any],
        seed: int,
    ) -> Observation:
        ...


# Fields a trader is never allowed to see (aggregate truth).
_INVISIBLE_AGGREGATE: tuple = ("supply", "demand", "production_rate",
                               "consumption_rate", "population")


class MarketObservationFilter:
    """Filters the economy ground truth into a trader's observation.

    Configuration:
      - public_tape_len: how many recent public trades the trader sees.
      - delay_ticks: staleness of the public price (0 = fresh).
      - noise_amp: amplitude of the deterministic price noise.
      - claim_bias_tag: tag attached to an official ``official_claim``.

    The delay channel keeps a small per-agent deque of recent true prices
    (in-filter state, not world state); the kernel still owns the real price.
    """

    def __init__(
        self,
        *,
        public_tape_len: int = 5,
        delay_ticks: int = 0,
        noise_amp: float = 0.0,
        claim_bias_tag: str = "official_stable",
    ) -> None:
        self.public_tape_len = int(public_tape_len)
        self.delay_ticks = int(delay_ticks)
        self.noise_amp = float(noise_amp)
        self.claim_bias_tag = str(claim_bias_tag)
        self._price_history: Dict[str, Deque[Optional[float]]] = {}

    def observe(
        self,
        true_state: Dict[str, Any],
        agent_binding: Dict[str, Any],
        seed: int = 0,
    ) -> MarketObservation:
        """Build a trader's observation from ground-truth economy state.

        ``agent_binding`` carries agent_id / t / own_inventory / own_cash /
        own_history / public_tape.  Aggregates are returned as ``invisible``
        fields (value=None) so the trace records the information-error source.
        """
        agent_id = str(agent_binding.get("agent_id", "agent"))
        t = int(agent_binding.get("t", 0))
        rng = random.Random(_hash_seed(seed, agent_id, t))
        obs = MarketObservation(agent_id=agent_id, t=t)

        # 1. own state — exact
        own_inv = float(agent_binding.get("own_inventory", 0.0) or 0.0)
        own_cash = float(agent_binding.get("own_cash", 0.0) or 0.0)
        obs.own_inventory = own_inv
        obs.own_cash = own_cash
        obs.fields["own_inventory"] = ObservationField(
            name="own_inventory", value=own_inv, imperfection="exact",
            source="own_ledger")
        obs.fields["own_cash"] = ObservationField(
            name="own_cash", value=own_cash, imperfection="exact",
            source="own_ledger")

        # 2. public price — delayed + noisy
        true_price = true_state.get("price")
        true_price_f = (float(true_price)
                        if isinstance(true_price, (int, float)) else None)
        delayed_price = self._delayed_price(agent_id, true_price_f)
        noisy_price, noise = self._noisy_price(delayed_price, rng)
        imperf = "exact"
        if self.delay_ticks > 0 and self.noise_amp > 0:
            imperf = "delayed+noisy"
        elif self.delay_ticks > 0:
            imperf = "delayed"
        elif self.noise_amp > 0:
            imperf = "noisy"
        obs.fields["price"] = ObservationField(
            name="price", value=noisy_price, imperfection=imperf,
            source="public_tape", delay=self.delay_ticks, noise=noise)

        # 3. public tape — exact recent trades
        tape = agent_binding.get("public_tape")
        if tape is None:
            own_hist = agent_binding.get("own_history") or []
            tape = list(own_hist[-self.public_tape_len:])
        else:
            tape = list(tape)[-self.public_tape_len:]
        obs.fields["public_tape"] = ObservationField(
            name="public_tape", value=_tape_summary(tape),
            imperfection="exact", source="public_tape")

        # 4. official proclamation — interpretation_bias tag
        claim = true_state.get("official_claim")
        if claim:
            obs.fields["official_claim"] = ObservationField(
                name="official_claim", value=None,
                imperfection="interpretation_bias",
                source="official", bias_tag=str(claim) or self.claim_bias_tag)

        # 5. aggregates — invisible (information error source)
        for agg in _INVISIBLE_AGGREGATE:
            obs.fields[agg] = ObservationField(
                name=agg, value=None, imperfection="invisible",
                source="aggregate")
        return obs

    def _delayed_price(
        self, agent_id: str, true_price: Optional[float]
    ) -> Optional[float]:
        buf = self._price_history.setdefault(agent_id, deque(maxlen=64))
        buf.append(true_price)
        if self.delay_ticks <= 0:
            return true_price
        idx = max(0, len(buf) - 1 - self.delay_ticks)
        return list(buf)[idx]

    def _noisy_price(
        self, price: Optional[float], rng: random.Random
    ) -> tuple:
        if price is None or self.noise_amp <= 0:
            return price, 0.0
        noise = (rng.random() - 0.5) * 2.0 * self.noise_amp
        return price + noise, noise


def _hash_seed(seed: int, agent_id: str, t: int) -> int:
    h = (int(seed) * 1_000_003) & 0x7FFFFFFF
    h ^= abs(hash(agent_id)) & 0x7FFFFFFF
    h ^= (int(t) * 265_443_5761) & 0x7FFFFFFF
    return h & 0x7FFFFFFF


def _tape_summary(tape: List[Dict[str, Any]]) -> Optional[float]:
    if not tape:
        return None
    prices: List[float] = []
    for tr in tape:
        if not isinstance(tr, dict):
            continue
        p = tr.get("price")
        if isinstance(p, (int, float)):
            prices.append(float(p))
    if not prices:
        return None
    return sum(prices) / len(prices)
