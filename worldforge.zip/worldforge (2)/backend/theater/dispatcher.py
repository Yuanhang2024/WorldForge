import json
import threading
import time
import warnings
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple
from uuid import uuid4

from .agents import ModelClient, OpenAICompatibleClient
from .gates import ScienceDirectorGate
from .models import (
    CharacterEntry,
    CharacterPatch,
    DispatchResult,
    SceneObjectPatch,
    StateSnapshot,
    Task,
    WorldBookEntry,
    WorldBookPatch,
)
from .rule_engine import RuleEngine, RuleResult
from .runtime import EmbeddingMemory, GameSessionManager, PossessionManager, TaskManager
from .settings import Settings
from .storage import JsonStateStore
from .transactions import StateChange, StateTransaction

if TYPE_CHECKING:
    from .kernels.three_body import ThreeBodyKernel


@dataclass
class AgentMindBinding:
    """Per-agent wiring for the AgentMind tick cycle (spec §4.2 / §8).

    Bundles a :class:`~theater.sim_agent.SimAgent` with the world-specific
    pieces the dispatcher cannot infer on its own:

    - ``observation_filter``: projects the kernel's true_state into the
      agent's filtered observation (§8 — the subject never reads raw truth).
    - ``belief_topic``: the topic the agent revises each tick; evidence is
      pulled from the filtered observation's ``belief_topic`` field (a
      number) when present, else ``None`` (qualitative beat).
    - ``action_candidates``: the candidate actions the agent chooses among
      via subjective-utility softmax (§9.3). Each candidate is the dict
      shape ``SimAgent.choose_action`` expects
      (``{verb, target, benefit, cost, risk, belief_topic}``).
    - ``pressure``: optional perceived pressure raising the softmax
      temperature toward impulsive choice.
    """

    agent: Any
    observation_filter: Any = None
    belief_topic: str = "default"
    action_candidates: List[Dict[str, Any]] = field(default_factory=list)
    pressure: float = 0.0


class TheaterOrchestrator:
    def __init__(
        self,
        state_store: JsonStateStore,
        model_client: ModelClient,
        settings: Optional[Settings] = None,
    ):
        # World isolation (ARCHITECTURE_SPEC §I4/§10.4): each world has its own
        # state store, namespaced by world_id. The passed-in store is registered
        # under its own world_id; additional worlds are loaded on demand via
        # _world_store(world_id). `self.state_store` is a property returning the
        # store for the current world (set via set_world).
        self._world_stores: Dict[str, JsonStateStore] = {state_store.world_id: state_store}
        self._world_registry_lock = threading.RLock()
        self._world_context = threading.local()
        self._current_world_id: str = state_store.world_id
        self._state_root: Path = state_store.root
        self.model_client = model_client
        self.settings = settings or Settings()
        self.science_gate = ScienceDirectorGate()
        runtime_root = self.settings.data_dir / "runtime"
        self.task_manager = TaskManager(runtime_root)
        self._possession_managers: Dict[str, PossessionManager] = {
            state_store.world_id: PossessionManager(
                state_store,
                self.science_gate,
            ),
        }
        self.game_manager = GameSessionManager(runtime_root)
        self.embedding_memory = EmbeddingMemory()
        self._last_activity = time.monotonic()
        self._world_beats: Dict[str, int] = {}
        # Single write point (spec §I4 / §2.3): RuleEngine for deterministic
        # validation (<1ms), StateTransaction for snapshot/commit semantics.
        # Every state write goes through _write_point — gradual hardening, so
        # on RuleEngine denial we warn + fall back to the legacy direct write
        # instead of hard-blocking (backward compatible).
        self.rule_engine = RuleEngine()
        self._pending_llm_adjudications: List[Tuple[StateChange, str]] = []
        # Deterministic three-body kernel — baked lazily on the first
        # three_body_tick and then held immutable (spec §8.2 user-immutable
        # boundary). The kernel is the ground truth for survival/eras; the LLM
        # only narrates its structured event log.
        self._three_body_kernel: Optional["ThreeBodyKernel"] = None
        self._three_body_cursor: float = 0.0  # simulation-time cursor into the baked timeline
        self._three_body_civ: Optional[dict] = None  # kernel-owned civilization scalars
        self._three_body_llm_log: List[dict] = []  # discardable LLM narration audit log
        # Compiled LLM-authored world rules (spec §1.2 立法/司法 separation).
        # Each non-three-body world may have a WorldKernelHost whose DSL rules
        # were compiled at onboarding stage 3 and must actually run at tick
        # time — otherwise the LLM's "legislation" is never "promulgated"
        # (P0 fix: onboarding compiled kernels used to be orphaned). Keyed by
        # world_id so world isolation (§I4/§10.4) is preserved.
        self._world_kernel_hosts: Dict[str, Any] = {}
        # Compiled gameplay spec (onboarding stage 4: 玩法, spec §9.2 库外玩法).
        # A GameplaySpec authored by the LLM (or selected through an explicit
        # parameterized-kernel ID) at onboarding stage 4. Persisted to
        # ``gameplay_<world_id>.json`` so a new orchestrator instance can
        # reload it on ``set_world``; the in-memory dict is a runtime cache.
        self._gameplay_specs: Dict[str, Any] = {}
        # IdleLoop registry (spec §13.4): per-world autonomous-advance loops.
        # The WorldClock (background thread) installs one when
        # settings.world_tick_interval > 0; dispatch() calls on_user_activity()
        # on the current world's loop to reset its saturation cap. Kept as a
        # dict keyed by world_id so world isolation (§I4/§10.4) is preserved.
        self._idle_loops: Dict[str, Any] = {}
        # Origin tag for the current dispatch (spec §13.4). When world_tick
        # drives dispatch, it sets this to "idle_advance" so the resulting
        # worldbook entries are tagged as autonomous-advance beats.
        self._advancement_origins: Dict[str, Optional[str]] = {}
        # AgentMind tick integration (spec §4.2 / §8 / §14). Registries are
        # per-world (§I4 isolation): ``_agent_mind_bindings[world_id]`` maps
        # character_id → AgentMindBinding (a SimAgent + its ObservationFilter
        # + belief topic + action candidates); ``_multi_scale_sims[world_id]``
        # holds the three-body MultiScaleThreeBodySim. Both are optional —
        # when empty (or when the settings flag is off) ticks degrade to the
        # existing pure kernel+LLM-narration behaviour (backward compatible).
        self._agent_mind_bindings: Dict[str, Dict[str, "AgentMindBinding"]] = {}
        self._multi_scale_sims: Dict[str, Any] = {}
        # Optional injected CausalNarrativeEngine (§14). Semantic narration
        # runs only when a caller explicitly wires model-backed planner and
        # realizer stages.
        self._causal_narrative_engine: Any = None
        # Decision-commitment lifecycle (spec — major decisions as persistent
        # causal mechanisms). Per-world registry holding the
        # CommitmentExecutor, DecisionResolver, AgentAgendas, the mutable
        # commitment-layer world_state (scalar deltas + modifier-applied
        # paths), and the last tick's observable-event broadcast. Only used
        # when settings.enable_commitments is on (default off → backward
        # compatible). Keyed by world_id (§I4 isolation).
        self._commitment_state: Dict[str, Dict[str, Any]] = {}

    @property
    def _commitments_enabled(self) -> bool:
        """Whether world_tick runs Phase 4-8 (decision commitments)."""
        return bool(getattr(self.settings, "enable_commitments", False))

    # ---- AgentMind tick integration (§4.2 / §8 / §14) -------------------
    def register_agent_mind_binding(
        self, world_id: str, character_id: str, binding: "AgentMindBinding",
    ) -> None:
        """Register a SimAgent as a tick-time subject in *world_id*.

        The agent runs its observe→update_belief→choose_action cycle inside
        :meth:`world_tick` when AgentMind is enabled (settings flag). The
        binding carries the world-specific :class:`ObservationFilter`, the
        belief topic the agent revises, and the action candidates it chooses
        among — the dispatcher itself never invents these (they are part of
        the world's design, not the runtime's).
        """
        self._agent_mind_bindings.setdefault(world_id, {})[character_id] = binding

    def register_multi_scale_sim(self, world_id: str, sim: Any) -> None:
        """Register the three-body :class:`MultiScaleThreeBodySim` for *world_id*.

        When the three-body AgentMind flag is on, :meth:`three_body_tick`
        runs ``sim.tick`` so scientists→org→civilisation deliberate and
        produce the ``decision_vector`` the kernel consumes (§8.2 red line:
        the kernel still adjudicates the outcome; the sim only translates the
        org decision into a vector).
        """
        self._multi_scale_sims[world_id] = sim

    def attach_causal_narrative_engine(self, engine: Any) -> None:
        """Inject a model-backed :class:`CausalNarrativeEngine` (§14)."""
        self._causal_narrative_engine = engine

    @property
    def _agent_mind_enabled(self) -> bool:
        """Whether non-three-body ticks run the AgentMind cycle (§4.2)."""
        return bool(getattr(self.settings, "enable_agent_mind", False))

    # ---- compiled world-rule kernel registry (P0: 立法→颁布) ----
    def register_world_kernel(self, world_id: str, spec: Any) -> None:
        """Install a compiled :class:`WorldKernelSpec` for *world_id*.

        Called by onboarding stage 3 after :meth:`RuleCompiler.compile` so the
        LLM-authored rules actually execute on subsequent ticks. The host is
        built lazily on first :meth:`_step_world_kernel` call so a spec that
        fails at runtime does not crash registration.

        Persistence (P0): the spec is serialized to
        ``kernel_<world_id>.json`` via the world's :class:`JsonStateStore` so a
        new orchestrator instance (new process) can reload it on
        :meth:`set_world`. The in-memory ``_world_kernel_hosts`` dict is now a
        runtime cache; **the on-disk file is the source of truth.**

        Coexistence note (待决策 — see final report): the three-body world is
        driven by :meth:`three_body_tick` (deterministic physics, §8.2 red
        line) and does NOT run DSL rules here. Non-three-body worlds run their
        DSL kernel inside :meth:`world_tick`. Combining both in one world via
        multi_kernel is a future decision, not assumed.
        """
        from .world_kernel_host import RuleCompiler
        # Validate eagerly (cheap, static) so a bad spec is flagged at
        # registration, but defer host construction to first use.
        issues = RuleCompiler().validate_spec(spec)
        if issues:
            raise ValueError("; ".join(issues))
        self._world_kernel_hosts[world_id] = spec
        # Persist to disk so a new orchestrator instance can reload it.
        self._world_store(world_id).save_world_kernel_spec(spec.to_dict())

    def _load_world_kernel_spec(self, world_id: str) -> Any:
        """Load the persisted spec for *world_id* from disk into the cache.

        Returns the spec if loaded, else ``None``. Idempotent: if the cache
        already holds a spec for this world, it is left in place (avoids
        clobbering a freshly registered in-memory spec with a stale disk copy
        during the same process).
        """
        if world_id in self._world_kernel_hosts:
            return self._world_kernel_hosts[world_id]
        from .world_kernel_host import WorldKernelSpec
        raw = self._world_store(world_id).load_world_kernel_spec()
        if not raw:
            return None
        try:
            spec = WorldKernelSpec.from_dict(raw)
        except Exception:
            return None
        self._world_kernel_hosts[world_id] = spec
        return spec

    def _step_world_kernel(self, world_id: str) -> List[Dict[str, Any]]:
        """Run one ``turn.tick`` through this world's compiled DSL kernel.

        Returns the list of emitted changes (each ``{path, op, value}``). If
        no kernel is registered for *world_id*, returns an empty list — the
        generic tick still proceeds via the dispatch pipeline.
        """
        spec = self._load_world_kernel_spec(world_id)
        if spec is None:
            return []
        from .world_kernel_host import WorldKernelHost
        # Lazily build + memoise the host (with the spec's initial_state).
        host_attr = f"_world_kernel_host_built:{world_id}"
        host = getattr(self, host_attr, None)
        if host is None:
            host = WorldKernelHost(spec, dict(getattr(spec, "initial_state", {}) or {}))
            setattr(self, host_attr, host)
        return host.step({"trigger": "turn.tick", "payload": {}})

    def get_world_kernel_state(self, world_id: str) -> Dict[str, Any]:
        """Read-only snapshot of the compiled kernel's state for *world_id*.

        Returns an empty dict when no kernel is registered. Used by tests and
        the tick log to confirm LLM rules actually fired (P0 acceptance).
        """
        host_attr = f"_world_kernel_host_built:{world_id}"
        host = getattr(self, host_attr, None)
        if host is None:
            return {}
        return host.state()

    def get_world_kernel_spec(self, world_id: str) -> Any:
        """Return the registered :class:`WorldKernelSpec` for *world_id*, or None.

        Loads from disk on first access (P0 persistence) so a fresh orchestrator
        instance can answer. Used by the CLI to route ``--tick`` between
        ``world_tick`` (DSL kernel) and ``three_body_tick`` (physics).
        """
        return self._load_world_kernel_spec(world_id)

    # ---- compiled gameplay spec registry (onboarding stage 4: 玩法) ----
    def register_gameplay_spec(self, world_id: str, spec: Any) -> None:
        """Install a :class:`GameplaySpec` for *world_id*.

        Called by onboarding stage 4 after :meth:`GameplayGenerator.generate`
        produces a validated spec. The spec is persisted to
        ``gameplay_<world_id>.json`` so a new orchestrator instance (new
        process) can reload it on :meth:`set_world`; the in-memory dict is
        a runtime cache. Registration is best-effort: failures never crash
        onboarding (the caller wraps this in a try/except and records a
        warning). Accepts either a :class:`GameplaySpec` or a raw dict.
        """
        from .gameplay_validator import GameplaySpec
        if isinstance(spec, GameplaySpec):
            spec_dict = spec.to_dict()
        elif isinstance(spec, dict):
            spec_dict = spec
        else:
            raise TypeError(f"gameplay spec must be GameplaySpec or dict, got {type(spec)}")
        self._gameplay_specs[world_id] = spec_dict
        self._world_store(world_id).save_gameplay_spec(spec_dict)

    def _load_gameplay_spec(self, world_id: str) -> Optional[Any]:
        """Load the persisted gameplay spec for *world_id* into the cache.

        Returns the spec dict if loaded, else ``None``. Idempotent: if the
        cache already holds a spec for this world, it is left in place.
        """
        if world_id in self._gameplay_specs:
            return self._gameplay_specs[world_id]
        raw = self._world_store(world_id).load_gameplay_spec()
        if not raw:
            return None
        self._gameplay_specs[world_id] = raw
        return raw

    def get_gameplay_spec(self, world_id: str) -> Optional[Any]:
        """Return the persisted gameplay spec dict for *world_id*, or None.

        Loads from disk on first access so a fresh orchestrator instance can
        answer. Returns a plain dict (the serialized :class:`GameplaySpec`);
        callers wanting the typed object can ``GameplaySpec.from_dict(...)`` it.
        """
        return self._load_gameplay_spec(world_id)

    # ---- AgentMind tick cycle (§4.2 observe→believe→choose, §12 write point) --
    def _tick_sim_agents(self, world_id: str, true_state: Dict[str, Any],
                         *, seed: Optional[int] = None) -> Dict[str, Any]:
        """Run one AgentMind tick for every registered SimAgent in *world_id*.

        Phase B (§11): each agent observes the kernel's ``true_state`` through
        its :class:`ObservationFilter`, revises its belief, and picks an
        :class:`ActionIntent` via subjective-utility softmax. Phase C: the
        intent is routed through the single write point (§12 — the agent never
        mutates the world directly). Returns a structured record of the
        cycle's traces + applied intents for the causal narrative + model trace.

        Red line (§8.2 / §12): the agent emits an *intent*; the rule engine /
        write point settles it. No agent writes world state directly.
        """
        bindings = self._agent_mind_bindings.get(world_id, {})
        if not bindings:
            return {"agents": {}, "belief_traces": [], "intents": [],
                    "canonical_facts": []}
        agents_record: Dict[str, Dict[str, Any]] = {}
        belief_traces: List[Any] = []
        trace_owners: List[str] = []
        intents: List[Dict[str, Any]] = []
        beat = self._world_beat
        for cid, binding in bindings.items():
            agent = binding.agent
            # Phase B1: observe (filtered, never raw truth — §8).
            try:
                agent.observe(binding.observation_filter, true_state, seed=seed)
            except Exception:
                pass
            # Phase B2: update_belief. Evidence = the observation's value on
            # the binding's belief_topic (a number) when present.
            evidence = None
            memory = list(getattr(agent.mind_state, "memory", []))
            last_obs = memory[-1] if memory else None
            if isinstance(last_obs, dict):
                obs_env = last_obs.get("observation")
                if isinstance(obs_env, dict):
                    val = obs_env.get(binding.belief_topic)
                    if isinstance(val, (int, float)):
                        evidence = float(val)
            try:
                trace = agent.update_belief(
                    topic=binding.belief_topic, evidence=evidence, seed=seed,
                )
                belief_traces.append(trace)
                trace_owners.append(cid)
            except Exception:
                trace = None
            # Phase B3: choose_action (softmax over permitted candidates).
            context = {"candidates": list(binding.action_candidates),
                       "pressure": float(binding.pressure), "seed": seed}
            try:
                intent = agent.choose_action(context, seed=seed)
            except Exception:
                intent = {"actor_id": cid, "verb": "wait", "target": None,
                          "subjective_reason": "choose_action failed",
                          "belief_refs": [], "subjective_scores": {},
                          "confidence": 0.0}
            intents.append(intent)
            agents_record[cid] = {
                "belief_trace": trace,
                "intent": intent,
                "belief": (
                    getattr(agent.mind_state.beliefs.get(binding.belief_topic),
                            "predicted", None)
                    if binding.belief_topic in agent.mind_state.beliefs else None
                ),
            }
        # Phase C: route intents through the single write point (§12). The
        # agent proposes; the rule engine + worldbook write settle. We record
        # one canonical fact per beat summarising the agents' committed
        # actions so the causal narrative + downstream beats can read them.
        applied = self._apply_agent_intents(world_id, intents, beat)
        return {
            "agents": agents_record,
            "belief_traces": belief_traces,
            "trace_owners": trace_owners,
            "intents": intents,
            "canonical_facts": applied,
        }

    def _apply_agent_intents(self, world_id: str, intents: List[Dict[str, Any]],
                             beat: int) -> List[Dict[str, Any]]:
        """Route ActionIntents through the single write point (§12).

        The agent never mutates the world directly: each intent is recorded as
        a canonical worldbook fact (origin=agent_mind) via :meth:`add_world_entry`
        (which runs the RuleEngine gate + state_store commit). Returns the list
        of canonical-fact dicts (``{id, summary}``) the causal narrative reads.

        Verbs that map onto existing first-class interactions (``interact``
        with an ``object_id``) are routed through the gate-arbitrated
        :meth:`interact` path; everything else becomes a worldbook fact.
        """
        store = self._world_store(world_id)
        facts: List[Dict[str, Any]] = []
        lines: List[str] = []
        for intent in intents:
            actor = str(intent.get("actor_id") or "agent")
            verb = str(intent.get("verb") or "wait")
            target = intent.get("target")
            reason = str(intent.get("subjective_reason") or "")
            object_id = ""
            if isinstance(target, dict):
                object_id = str(target.get("object_id") or "")
            elif isinstance(target, str):
                object_id = target
            # Gate-arbitrated interaction when the intent names a scene object.
            if verb == "interact" and object_id and store.get_object(object_id) is not None:
                self.interact(actor_id=actor, verb=verb, object_id=object_id,
                              actor_strength=1)
                fid = f"fact:agent:{actor}:{verb}:{object_id}:beat{beat}"
                summary = f"{actor} {verb} {object_id}"
            else:
                fid = f"fact:agent:{actor}:{verb}:beat{beat}"
                summary = f"{actor} {verb}" + (
                    f" → {object_id}" if object_id else "")
            if reason:
                summary += f"（{reason[:60]}）"
            lines.append(summary)
            facts.append({"id": fid, "summary": summary, "actor_id": actor})
        if lines:
            content = "；".join(lines)
            self.add_world_entry(
                WorldBookPatch(
                    title=f"角色行动·第{beat}拍",
                    content=content,
                    source="agent_mind_tick",
                    provenance="canonical_event",
                ),
                approved_by=self.science_gate.director_id,
                origin="agent_mind",
            )
        return facts

    def _run_causal_narrative(self, world_id: str, agent_record: Dict[str, Any],
                              outcome: Optional[Dict[str, Any]] = None,
                              decision: Optional[Dict[str, Any]] = None,
                              ) -> Optional[Dict[str, Any]]:
        """Run the two-stage causal narrative (§14) over a tick's traces.

        Builds a :class:`CommittedTick` from the AgentMind belief traces +
        applied intents + (optional) kernel outcome, runs the
        :class:`CausalNarrativeEngine`, and returns a JSON-serialisable
        summary (causal_graph + plan + narrative + validation). ``None`` when
        there are no belief traces to narrate.
        """
        from .causal_narrative import CommittedTick
        belief_traces = agent_record.get("belief_traces") or []
        if not belief_traces:
            return None
        owners = agent_record.get("trace_owners") or []
        actors = {}
        bindings = self._agent_mind_bindings.get(world_id, {})
        for cid, binding in bindings.items():
            actors[cid] = binding.agent
        # Pick the first intent's actor as the decision actor (the causal
        # narrative's builder wires belief→decision→outcome around it).
        intents = agent_record.get("intents") or []
        decision_actor = ""
        if intents:
            decision_actor = str(intents[0].get("actor_id") or "")
        decision_dict = dict(decision or {})
        if intents and "actor_id" not in decision_dict:
            decision_dict = {
                "actor_id": decision_actor,
                "verb": str(intents[0].get("verb") or ""),
                "rationale": str(intents[0].get("subjective_reason") or ""),
            }
        tick = CommittedTick(
            tick=self._world_beat,
            actor_id=decision_actor,
            belief_traces=belief_traces,
            trace_owners=owners or None,
            decision=decision_dict,
            outcome=outcome or {},
            canonical_facts=agent_record.get("canonical_facts") or [],
            actors=actors,
            observations={},
        )
        engine = self._causal_narrative_engine
        if engine is None:
            raise RuntimeError(
                "causal narration requires an explicitly attached "
                "model-backed CausalNarrativeEngine"
            )
        result = engine.narrate_tick(tick)
        return {
            "causal_graph": result.causal_graph.as_dict(),
            "plan": result.plan.as_dict(),
            "validation_ok": result.validation.ok,
            "validation_errors": list(result.validation.errors),
            "narrative": result.narrative,
            "fallback_used": False,
            "warnings": list(result.warnings),
        }

    # ---- decision-commitment lifecycle (Phase 4-8, § decisions) ----------
    def register_agent_agenda(self, world_id: str, character_id: str,
                              agenda: Any) -> None:
        """Register an :class:`~theater.commitments.AgentAgenda` for *character_id*.

        The agenda carries the subject's persistent goals + deadlines +
        opportunities. Each tick, when its ``initiative_score`` crosses
        ``initiative_threshold``, the agent proactively emits a
        :class:`~theater.commitments.CommitmentProposal` (Phase 4) — *without*
        waiting for the player to trigger it.
        """
        layer = self._commitment_layer(world_id)
        layer["agendas"][character_id] = agenda

    def register_commitment_proposal(self, world_id: str, proposal: Any) -> None:
        """Queue an externally-authored CommitmentProposal for the next tick.

        Used by tests / scripted scenarios (e.g. the three-body scientist
        proposing an emergency observatory) to inject a proposal without going
        through the AgentAgenda initiative path. Cleared at the end of Phase 5.
        """
        layer = self._commitment_layer(world_id)
        layer["pending_proposals"].append(proposal)

    def get_commitment_executor(self, world_id: str) -> Any:
        """Expose the per-world CommitmentExecutor (read-only for tests/CLI)."""
        return self._commitment_layer(world_id)["executor"]

    def get_commitment_state(self, world_id: str) -> Dict[str, Any]:
        """Read-only snapshot of the commitment layer for *world_id*."""
        layer = self._commitment_layer(world_id)
        return {
            "commitments": layer["executor"].to_dict(),
            "world_state": dict(layer["world_state"]),
            "agendas": {cid: a.to_dict() for cid, a in layer["agendas"].items()},
            "last_broadcast": list(layer["last_broadcast"]),
        }

    def _commitment_layer(self, world_id: str) -> Dict[str, Any]:
        """Get (lazy-create) the per-world commitment registry."""
        from .commitments import CommitmentExecutor
        from .decision_resolver import DecisionResolver
        if world_id not in self._commitment_state:
            self._commitment_state[world_id] = {
                "executor": CommitmentExecutor(),
                "resolver": DecisionResolver(seed=88123),
                "agendas": {},
                "pending_proposals": [],
                # mutable scalar/path state the executor applies modifiers +
                # scheduled-effect deltas to (the kernel's own scalars are not
                # touched — this is the commitment layer's own state surface).
                "world_state": {},
                "last_broadcast": [],
            }
        return self._commitment_state[world_id]

    def _tick_commitments(self, world_id: str, agent_record: Dict[str, Any],
                          true_state: Dict[str, Any], beat: int, *,
                          seed: Optional[int] = None) -> Dict[str, Any]:
        """Run Phase 4-8 of the decision-commitment lifecycle for one tick.

        Phase 4 — agents whose agenda initiative crosses threshold emit a
        CommitmentProposal (plus any externally queued proposals).
        Phase 5 — DecisionResolver settles each proposal (authority / resources
        / org / opposition) → creates/updates Commitment + DecisionEffects.
        Phase 6 — apply the 4-layer effects through the single write point +
        the executor's registries; commit immediate deltas to world_state.
        Phase 7 — broadcast observable events (secrecy-gated); per-subject
        projection recorded for the model trace.
        Phase 8 — CommitmentExecutor.tick_commitments advances active
        commitments (progress / trigger scheduled effects / apply+revert
        modifiers) and returns a TickEffects the caller settles.

        Returns a JSON-serialisable summary for model_trace. Pure stdlib,
        deterministic, no LLM.
        """
        from .commitments import (
            ACTION_TEMPLATES, CommitmentStatus, proposal_from_template,
            resource_requirements_for,
        )
        from .decision_resolver import (
            AuthorityCheck, Environment, Opposition, OrgSupport,
        )
        layer = self._commitment_layer(world_id)
        executor = layer["executor"]
        resolver = layer["resolver"]
        cstate = layer["world_state"]
        agendas = layer["agendas"]
        # seed cstate with the post-kernel true_state so the resolver reads
        # real resource levels (budget/personnel/etc.) without mutating truth.
        for k, v in (true_state or {}).items():
            if isinstance(v, (int, float, str, bool)):
                cstate.setdefault(k, v)

        proposals: List[Any] = []
        # Phase 4: initiative-driven proposals from registered agendas.
        for cid, agenda in agendas.items():
            try:
                fit = self._opportunity_fit(cid, agent_record)
                risk = self._failure_risk(cid, agent_record)
                if agenda.should_propose(current_tick=beat,
                                         opportunity_fit=fit,
                                         failure_risk=risk):
                    proposals.append(self._agenda_proposal(
                        agenda, cid, beat, fit, risk))
            except Exception:
                continue
        # Externally queued proposals (tests / scripted scenarios).
        proposals.extend(layer["pending_proposals"])
        layer["pending_proposals"] = []

        # Phase 5: resolve each proposal.
        resolutions: List[Any] = []
        for prop in proposals:
            resources = self._resources_for(prop, cstate)
            authority = self._authority_for(prop)
            org = self._org_support_for(prop)
            opp = self._opposition_for(prop)
            env = self._environment_for(prop, beat)
            try:
                res = resolver.resolve_and_commit(
                    prop, executor, authority=authority, resources=resources,
                    org_support=org, opposition=opp, environment=env)
            except Exception:
                continue
            resolutions.append(res)

        # Phase 6: settle the 4-layer effects.
        applied_deltas: Dict[str, float] = {}
        for res in resolutions:
            effects = res.effects
            for path, val in effects.immediate_deltas.items():
                _cset(cstate, path, float(val))
                applied_deltas[path] = float(val)
            for eff in effects.scheduled_effects:
                executor.register_scheduled_effect(eff)
            for mod in effects.world_modifiers:
                executor.register_world_modifier(mod)
            # relationship_changes + resource_transfers are recorded for the
            # narrator / character_graph downstream; we do not mutate the
            # character_graph here (read-only reuse — the graph is owned by
            # the world's design, not the runtime). They surface in the trace.
            # transition the freshly-created commitment authorized→active so
            # the executor can advance it next tick (Phase 8 this tick).
            if res.commitment_id is not None:
                c = executor.commitments.get(res.commitment_id)
                if c is not None and c.status == CommitmentStatus.AUTHORIZED:
                    from .commitments import transition_commitment
                    transition_commitment(
                        c, CommitmentStatus.ACTIVE,
                        reason="resources allocated, execution begins")

        # Phase 8: advance active commitments one tick. (Phase 7 broadcast
        # collected below from resolution events + executor events.)
        tick_effects = executor.tick_commitments(cstate, beat, seed=seed)
        for path, val in tick_effects.immediate_deltas.items():
            applied_deltas[path] = float(val)

        # Phase 7: broadcast observable events (secrecy-gated). The
        # ObservationFilter downstream decides per-subject what each agent
        # sees; here we record the raw broadcast + a per-agent projection
        # summary (who saw what, by visibility).
        broadcast: List[Dict[str, Any]] = []
        for res in resolutions:
            broadcast.extend(res.events)
        broadcast.extend(tick_effects.observable_events)
        layer["last_broadcast"] = list(broadcast)
        projections = self._project_broadcast(broadcast, agendas)

        # record a canonical worldbook fact summarising this tick's decisions
        # so downstream beats + the narrator have continuity (origin=commitment).
        if resolutions:
            self._record_commitment_beat(world_id, beat, resolutions, tick_effects)

        return {
            "proposals": [p.to_dict() for p in proposals],
            "resolutions": [r.to_dict() for r in resolutions],
            "tick_effects": tick_effects.to_dict(),
            "applied_deltas": applied_deltas,
            "broadcast": broadcast,
            "projections": projections,
        }

    # -- Phase 4-8 helpers ------------------------------------------------

    def _agenda_proposal(self, agenda: Any, actor_id: str, beat: int,
                         fit: float, risk: float) -> Any:
        """Build a CommitmentProposal from an agenda whose initiative crossed.

        Routes the agenda's top goal to a generic action verb by its
        ``decision_type`` hint (default ``launch_project``). The proposal's
        decision_strength scales with initiative surplus; execution_capability
        with the agenda's drive.
        """
        from .commitments import proposal_from_template, ACTION_TEMPLATES
        top = agenda.top_goal() or {}
        decision_type = str(top.get("decision_type") or "launch_project")
        if decision_type not in ACTION_TEMPLATES:
            decision_type = "launch_project"
        strength = 1.0 + max(0.0, agenda.initiative_score(
            current_tick=beat, opportunity_fit=fit, failure_risk=risk)
            - agenda.initiative_threshold)
        return proposal_from_template(
            actor_id, decision_type,
            target_ids=list(top.get("target_ids") or []),
            goal=str(top.get("goal_id") or "agenda-driven proposal"),
            proposed_tick=beat,
            decision_strength=min(2.0, strength),
            execution_capability=float(getattr(agenda, "personality_drive", 0.5)),
        )

    def _opportunity_fit(self, cid: str, agent_record: Dict[str, Any]) -> float:
        """Heuristic opportunity-fit for the agent this tick (0..1).

        Reads the agent's last intent confidence as a proxy: a confident agent
        sees a better-fitting opportunity. Falls back to 0.5.
        """
        rec = (agent_record.get("agents") or {}).get(cid) or {}
        intent = rec.get("intent") or {}
        try:
            return max(0.0, min(1.0, float(intent.get("confidence") or 0.5)))
        except (TypeError, ValueError):
            return 0.5

    def _failure_risk(self, cid: str, agent_record: Dict[str, Any]) -> float:
        """Heuristic failure-risk (0..1): high when the agent's top belief is
        marked model_error (the agent itself thinks its model is wrong)."""
        return 0.0  # deterministic default; callers can override via agenda

    def _resources_for(self, proposal: Any, cstate: Dict[str, Any]) -> Dict[str, float]:
        """Read available resources for the proposal from the commitment-layer
        world_state. Falls back to fully-resourced when state is silent (so a
        fresh world still resolves)."""
        req = proposal.required_resources or {}
        out: Dict[str, float] = {}
        for key, need in req.items():
            # look up actors.<actor>.<key> or a flat <key> in cstate
            val = _cget(cstate, f"actors.{proposal.actor_id}.{key}")
            if val is None:
                val = _cget(cstate, key)
            if val is None:
                # default: fully resourced (so the resolver's resource factor
                # is 1.0 unless the world explicitly tracks scarcity)
                val = float(need)
            try:
                out[key] = float(val)
            except (TypeError, ValueError):
                out[key] = float(need)
        return out

    def _authority_for(self, proposal: Any) -> Any:
        """AuthorityCheck for a proposal. Self-authored → feasible w/ full
        mandate unless the proposal carries an explicit authority mandate."""
        from .decision_resolver import AuthorityCheck
        mandate = float(getattr(proposal, "_mandate", 1.0))
        return AuthorityCheck(
            feasible=mandate > 0.0,
            factor=max(0.0, min(1.0, mandate)),
            authority_source=proposal.authority_source,
            reason="" if mandate > 0.0 else "no authority",
        )

    def _org_support_for(self, proposal: Any) -> Any:
        """OrgSupport: default full compliance (the actor's org obeys). The
        dispatcher does not run a full org_decide here — that lives in the
        multi-scale sim for three-body; for the generic commitment layer we
        treat the actor as self-authorised unless a hook overrides."""
        from .decision_resolver import OrgSupport
        return OrgSupport(compliance=1.0, supporters=[proposal.actor_id])

    def _opposition_for(self, proposal: Any) -> Any:
        """Opposition: read stashed _opposition_refs (mobilize_faction) →
        strength scaled by the number of opposed factions."""
        from .decision_resolver import Opposition
        refs = list(getattr(proposal, "_opposition_refs", []) or [])
        if not refs:
            return Opposition()
        # one opposed faction = 0.3 strength, capped at 0.9
        strength = min(0.9, 0.3 * len(refs))
        return Opposition(strength=strength, refs=refs, sabotage=False)

    def _environment_for(self, proposal: Any, beat: int) -> Any:
        """Environment: default hospitable (fit=1, no cognitive error, no
        failure pressure). Tests / scripted scenarios override via proposal
        stashed env attrs (``_info_error``, ``_failure_pressure``)."""
        from .decision_resolver import Environment
        return Environment(
            fit=1.0,
            info_error=float(getattr(proposal, "_info_error", 0.0)),
            failure_pressure=float(getattr(proposal, "_failure_pressure", 0.0)),
            time_available=1.0,
        )

    def _project_broadcast(self, broadcast: List[Dict[str, Any]],
                           agendas: Dict[str, Any]) -> Dict[str, Any]:
        """Per-subject projection of the broadcast events (Phase 7).

        Each event carries ``visibility`` ∈ [0,1] (1 − secrecy). A subject
        sees an event when ``visibility`` exceeds a per-subject threshold
        (default 0.3 — secret commitments leak partially to attentive agents).
        Returns ``{subject_id: [event summaries]}`` for the model trace.
        """
        out: Dict[str, Any] = {}
        for cid in agendas:
            seen = []
            for ev in broadcast:
                vis = float(ev.get("visibility", 1.0))
                if vis >= 0.3:
                    seen.append({
                        "type": ev.get("type"),
                        "kind": ev.get("kind", ev.get("status", "")),
                        "actor_id": ev.get("actor_id"),
                        "commitment_id": ev.get("commitment_id"),
                        "visibility": vis,
                    })
            out[cid] = seen
        return out

    def _record_commitment_beat(self, world_id: str, beat: int,
                                resolutions: List[Any], tick_effects: Any) -> None:
        """Record a canonical worldbook fact summarising this tick's decisions
        + commitment progress (origin=commitment) so the world has continuity."""
        lines: List[str] = []
        for res in resolutions:
            lines.append(
                f"{res.proposal.actor_id} {res.proposal.decision_type}→{res.status}"
                f"(exec={res.execution_ratio:.2f})")
        for cid in tick_effects.completed_commitments:
            lines.append(f"{cid} completed")
        for cid in tick_effects.failed_commitments:
            lines.append(f"{cid} failed")
        if not lines:
            return
        self.add_world_entry(
            WorldBookPatch(
                title=f"决策承诺·第{beat}拍",
                content="；".join(lines),
                source="commitment_tick",
                provenance="canonical_event",
            ),
            approved_by=self.science_gate.director_id,
            origin="commitment",
        )

    def _commitment_brief(self, summary: Dict[str, Any]) -> str:
        """One-line human-readable brief of this tick's commitment resolutions
        for the narration prompt (kept short so it doesn't dominate)."""
        parts: List[str] = []
        for r in summary.get("resolutions") or []:
            parts.append(
                f"{r['proposal']['actor_id']} {r['proposal']['decision_type']}"
                f"→{r['status']}")
        te = summary.get("tick_effects") or {}
        for cid in te.get("completed_commitments") or []:
            parts.append(f"{cid}完成")
        return "；".join(parts)[:200]

    # ---- world isolation (§I4/§10.4) ----
    @property
    def state_store(self) -> JsonStateStore:
        """The state store for the *current* world. Worlds are fully isolated:
        separate state files, separate worldbooks, separate characters. Switching
        worlds via set_world() re-points this property — no cross-world leakage."""
        return self._world_store(self.world_id)

    @property
    def world_id(self) -> str:
        return str(
            getattr(self._world_context, "world_id", None)
            or self._current_world_id
        )

    @property
    def possession_manager(self) -> PossessionManager:
        world_id = self.world_id
        with self._world_registry_lock:
            manager = self._possession_managers.get(world_id)
            if manager is None:
                manager = PossessionManager(
                    self._world_store(world_id),
                    self.science_gate,
                )
                self._possession_managers[world_id] = manager
            return manager

    @property
    def _world_beat(self) -> int:
        return int(self._world_beats.get(self.world_id, 0))

    @_world_beat.setter
    def _world_beat(self, value: int) -> None:
        self._world_beats[self.world_id] = int(value)

    @property
    def _advancement_origin(self) -> Optional[str]:
        return self._advancement_origins.get(self.world_id)

    @_advancement_origin.setter
    def _advancement_origin(self, value: Optional[str]) -> None:
        self._advancement_origins[self.world_id] = value

    @property
    def _idle_loop(self):
        """The IdleLoop bound to the *current* world, or None (spec §13.4)."""
        return self._idle_loops.get(self.world_id)

    def attach_idle_loop(self, idle_loop) -> None:
        """Register an :class:`~theater.idle_loop.IdleLoop` for its
        ``world_id``. The WorldClock calls this once at startup so dispatch()
        can reset the loop's saturation cap on player activity. Safe to call
        per-world; re-binding replaces the previous loop for that world."""
        self._idle_loops[getattr(idle_loop, "world_id", self.world_id)] = idle_loop

    def _world_store(self, world_id: str) -> JsonStateStore:
        """Get (lazy-create) the isolated state store for a world_id."""
        with self._world_registry_lock:
            if world_id not in self._world_stores:
                self._world_stores[world_id] = JsonStateStore(
                    self._state_root,
                    world_id=world_id,
                )
            return self._world_stores[world_id]

    @contextmanager
    def world_scope(self, world_id: str):
        """Bind one request/thread to a world without changing global selection."""
        marker = object()
        previous = getattr(self._world_context, "world_id", marker)
        self._world_store(world_id)
        self._world_context.world_id = world_id
        self._load_world_kernel_spec(world_id)
        self._load_gameplay_spec(world_id)
        try:
            yield self
        finally:
            if previous is marker:
                del self._world_context.world_id
            else:
                self._world_context.world_id = previous

    def set_world(self, world_id: str) -> None:
        """Switch the current world context. All subsequent state reads/writes go
        to this world's isolated store. The possession_manager is re-bound so
        possession state is also world-scoped. The persisted compiled kernel
        spec (if any) is loaded from disk into the runtime cache so a fresh
        orchestrator instance sees registered DSL rules."""
        store = self._world_store(world_id)
        self._current_world_id = world_id
        with self._world_registry_lock:
            self._possession_managers.setdefault(
                world_id,
                PossessionManager(store, self.science_gate),
            )
        # P0: reload the persisted kernel spec from disk so a new orchestrator
        # instance (new process) recovers registered DSL rules.
        self._load_world_kernel_spec(world_id)
        # Onboarding stage 4: likewise reload the persisted gameplay spec so a
        # fresh orchestrator instance recovers the world's gameplay rules.
        self._load_gameplay_spec(world_id)

    def list_worlds(self) -> List[str]:
        """All world_ids that have state (exist on disk)."""
        import glob
        ids = set(self._world_stores.keys())
        for p in glob.glob(str(self._state_root / "state_*.json")):
            name = Path(p).stem.replace("state_", "", 1)
            ids.add(name)
        ids.add("main")  # default always exists
        return sorted(ids)

    @classmethod
    def from_settings(cls, settings: Settings) -> "TheaterOrchestrator":
        return cls(
            state_store=JsonStateStore(settings.data_dir / "state"),
            model_client=OpenAICompatibleClient(settings),
            settings=settings,
        )

    # ---- single write point (spec §I4 / §2.3) ---------------------------
    # Every state-mutating call routes through _write_point → RuleEngine
    # validation (deterministic, <1ms). The three public wrappers
    # (add_world_entry / upsert_character / upsert_object) preserve the
    # state_store signatures so call sites stay unchanged; on RuleEngine
    # denial they warn + degrade to a direct write (progressive hardening,
    # not a hard block).

    def _write_point(self, state_change: StateChange) -> RuleResult:
        """Single write point: RuleEngine.validate (deterministic, <1ms).

        Branches (spec §I4):
          - approved, no LLM needed  → return approved
          - approved, needs_llm=True → queue async question, return approved
          - denied                   → return reasons (caller decides degrade)

        The kernel writes its own scalars directly via StateTransaction
        (begin/apply/commit on the civ dict — that path is preserved as the
        single kernel transactional write point). Dispatcher writes for
        worldbook/characters/objects go through JsonStateStore's own atomic
        temp-file+rename commit, so the validation gate here is sufficient —
        we don't run a parallel audit transaction that would double-count the
        kernel's apply surface.
        """
        state = self.state_store._load()  # raw dict for RuleEngine
        result = self.rule_engine.validate(state_change, state)
        if not result.approved:
            return result
        # if the heuristic flags this for LLM semantic adjudication, queue it
        if self.rule_engine.needs_llm_adjudication(state_change, state):
            question = self.rule_engine.build_llm_question(state_change, state)
            self._pending_llm_adjudications.append((state_change, question))
            return RuleResult.ok(needs_llm=True, llm_question=question)
        return RuleResult.ok()

    # --- write-point wrappers (preserve state_store signatures) ----------

    def add_world_entry(
        self, patch: "WorldBookPatch", approved_by: Optional[str], *,
        origin: str = "rule_engine", adjudication_ref: Optional[str] = None,
    ) -> bool:
        """Worldbook append, routed through _write_point for validation+audit.

        On RuleEngine denial: warn + fall through to state_store.add_world_entry
        (degraded path; progressive hardening).
        """
        change = StateChange.new(
            origin=origin,
            changes=[
                {"path": "worldbook.append.title", "op": "set", "value": patch.title},
                {"path": "worldbook.append.content", "op": "set", "value": patch.content},
                {"path": "worldbook.append.source", "op": "set", "value": patch.source},
            ],
            prerequisites_checked=[f"science_gate:{approved_by or 'unknown'}"],
            adjudication_ref=adjudication_ref,
        )
        result = self._write_point(change)
        if not result.approved:
            warnings.warn(
                f"[write_point] add_world_entry denied: {result.reasons}; "
                f"degraded path: writing directly (progressive hardening)"
            )
        return self.state_store.add_world_entry(patch, approved_by)

    def upsert_character(
        self, patch: "CharacterPatch", approved_by: Optional[str], *,
        origin: str = "rule_engine", adjudication_ref: Optional[str] = None,
    ) -> bool:
        """Character upsert, routed through _write_point for validation+audit."""
        change = StateChange.new(
            origin=origin,
            changes=[
                {"path": f"characters.{patch.character_id}.name", "op": "set", "value": patch.name},
                {"path": f"characters.{patch.character_id}.source", "op": "set", "value": patch.source},
            ],
            prerequisites_checked=[f"science_gate:{approved_by or 'unknown'}"],
            adjudication_ref=adjudication_ref,
        )
        result = self._write_point(change)
        if not result.approved:
            warnings.warn(
                f"[write_point] upsert_character({patch.character_id!r}) denied: "
                f"{result.reasons}; degraded path: writing directly (progressive hardening)"
            )
        return self.state_store.upsert_character(patch, approved_by)

    def upsert_object(
        self, patch: "SceneObjectPatch", approved_by: Optional[str], *,
        origin: str = "rule_engine", adjudication_ref: Optional[str] = None,
    ) -> bool:
        """Scene-object upsert, routed through _write_point for validation+audit."""
        change = StateChange.new(
            origin=origin,
            changes=[
                {"path": f"objects.{patch.object_id}.name", "op": "set", "value": patch.name},
                {"path": f"objects.{patch.object_id}.kind", "op": "set", "value": patch.kind},
                {"path": f"objects.{patch.object_id}.state", "op": "set", "value": patch.state},
            ],
            prerequisites_checked=[f"science_gate:{approved_by or 'unknown'}"],
            adjudication_ref=adjudication_ref,
        )
        result = self._write_point(change)
        if not result.approved:
            warnings.warn(
                f"[write_point] upsert_object({patch.object_id!r}) denied: "
                f"{result.reasons}; degraded path: writing directly (progressive hardening)"
            )
        return self.state_store.upsert_object(patch, approved_by)

    def dispatch(self, message: str, session_id: Optional[str] = None, role: str = "producer", world_id: Optional[str] = None, *, advancement_origin: Optional[str] = None) -> DispatchResult:
        if world_id is not None:
            with self.world_scope(str(world_id)):
                return self.dispatch(
                    message=message,
                    session_id=session_id,
                    role=role,
                    advancement_origin=advancement_origin,
                )
        self._last_activity = time.monotonic()
        # Player activity resets the idle loop's saturation cap (spec §13.4).
        # The silence timer is _last_activity above; the cap is owned by the
        # IdleLoop bound to this orchestrator (if any — WorldClock installs one
        # when world_tick_interval > 0).
        if self._idle_loop is not None:
            self._idle_loop.on_user_activity()
        # advancement_origin: when set (e.g. "idle_advance" from world_tick),
        # worldbook/character writes from this dispatch are tagged with that
        # origin instead of the default "rule_engine" — so idle-advance beats
        # are distinguishable in the worldbook (spec §13.4 算正典, origin-tagged).
        self._advancement_origin = advancement_origin
        sid = session_id or f"story_{uuid4().hex[:10]}"
        contextual_prompt = (
            f"{message}\n\n"
            "已持久化的当前世界上下文（本次生成必须接续这些状态；"
            "不得覆盖、遗忘或改写既有事实）：\n"
            f"{self._runtime_world_context()}"
        )
        try:
            director = self.model_client.complete_json(
                role=role,
                prompt=contextual_prompt,
                model=self.settings.provider_model_deep,
            )
        except Exception as exc:
            raise RuntimeError(f"LLM director generation failed: {exc}") from exc
        if not isinstance(director, dict):
            raise RuntimeError("LLM director generation returned invalid data")
        director_warnings = self._normalize_warnings(director.get("warnings"))
        raw_intent = str(director.get("intent") or "").strip()
        if raw_intent not in {
            "world_update", "action", "possession", "complex_story",
        }:
            raise RuntimeError(
                f"LLM director returned unsupported intent {raw_intent!r}"
            )
        if not str(director.get("brief") or "").strip():
            raise RuntimeError("LLM director returned an empty brief")
        intent = raw_intent
        tasks = self._build_tasks(sid, message, director, intent)

        world_entries, character_entries = self._apply_verified_writes(message, director)
        if "退出夺舍" in message:
            character_entries = [self.possession_manager.exit_possession("aster")]
        elif intent == "possession":
            character_entries = [self.possession_manager.enter_possession("aster", "player_01", message)]
        # if the director proposed a scene-object interaction (砸桌子/拿道具),
        # resolve it through the gate and let it mutate + propagate state.
        interaction_result = self._maybe_interact(director, str(director.get("actor_id") or "aster"))
        self.task_manager.enqueue(sid, tasks)
        return DispatchResult(
            session_id=sid,
            intent=intent,
            director_brief=str(director.get("brief") or "导演棚完成调度。"),
            dialogue=str(director.get("dialogue") or ""),
            tasks=tasks,
            world_updates=world_entries,
            character_updates=character_entries,
            model_trace={
                "model_fast": self.settings.model_fast,
                "model_deep": self.settings.model_deep,
                "provider_model_fast": self.settings.provider_model_fast,
                "provider_model_deep": self.settings.provider_model_deep,
                "live_api_enabled": self.settings.enable_live_api and bool(self.settings.api_key),
                "director_provider_model": director.get("provider_model"),
                "raw_intent": raw_intent,
                "interaction": interaction_result,
                "advancement_origin": self._advancement_origin,
            },
            warnings=director_warnings,
        )

    def _runtime_world_context(self) -> str:
        """Return bounded, persisted context for every runtime LLM call."""
        snapshot = self.state_store.snapshot()
        try:
            with self.state_store._lock:
                raw = self.state_store._load_raw()
        except Exception:
            raw = {}
        meta = raw.get("_meta") if isinstance(raw.get("_meta"), dict) else {}
        payload = {
            "world_id": self.world_id,
            "world_params": dict(meta.get("world_params") or {}),
            "characters": [
                entry.to_dict() for entry in snapshot.characters[:12]
            ],
            "objects": [
                entry.to_dict() for entry in snapshot.objects[:20]
            ],
            "recent_worldbook": [
                entry.to_dict() for entry in snapshot.worldbook[-12:]
            ],
            "kernel_state": self.get_world_kernel_state(
                self.world_id,
            ),
        }
        return json.dumps(payload, ensure_ascii=False)[:24000]

    def _maybe_interact(self, director: dict, actor_id: str) -> Optional[dict]:
        """If the director proposed a scene-object interaction, resolve it.

        Lets the LLM autonomously drive 砸桌子/拿道具 within the living world:
        the director emits {verb, object_id}; the gate rules the physics; state
        mutates + propagates. No-op (None) if no interaction or no such object.
        """
        inter = director.get("interaction")
        if not isinstance(inter, dict):
            return None
        verb = str(inter.get("verb") or "").strip()
        object_id = str(inter.get("object_id") or "").strip()
        if not verb or not object_id:
            return None
        if self.state_store.get_object(object_id) is None:
            return None
        strength = int(inter.get("actor_strength") or 1)
        return self.interact(actor_id=actor_id, verb=verb, object_id=object_id, actor_strength=strength)

    def seconds_since_activity(self) -> float:
        return time.monotonic() - self._last_activity

    @staticmethod
    def _character_patch_from_entry(entry, **overrides) -> CharacterPatch:
        """Rebuild a CharacterPatch from a stored entry, applying field overrides."""
        fields = dict(
            character_id=entry.character_id, name=entry.name, summary=entry.summary, source=entry.source,
            personality=entry.personality, appearance=entry.appearance,
            sample_line=entry.sample_line,
            possessed=entry.possessed, possessed_by=entry.possessed_by, ai_subconscious=entry.ai_subconscious,
            pending_ai_actions=list(entry.pending_ai_actions or []), possession_limit=dict(entry.possession_limit or {}),
        )
        fields.update(overrides)
        return CharacterPatch(**fields)

    def add_object(self, object_id: str, name: str, **props) -> dict:
        """Register an interactive scene object (a first-class citizen with
        state/properties/affordances) through the science gate."""
        patch = SceneObjectPatch(object_id=object_id, name=name, **props)
        approval = self.science_gate.validate_write([], [])  # schema ok for objects is trivial
        self.upsert_object(patch, approved_by=approval.director_id)
        stored = self.state_store.get_object(object_id)
        return {"ok": True, "object": stored.to_dict() if stored else patch.to_dict()}

    def interact(self, actor_id: str, verb: str, object_id: str, actor_strength: int = 1) -> dict:
        """Resolve a character↔object interaction (砸烂桌子 chain).

        intent → load target → gate arbitrates (can it? what happens?) →
        mutate state → propagate to worldbook so all agents henceforth know.
        The gate is the physics; the LLM only proposed the verb/target.
        """
        target = self.state_store.get_object(object_id)
        verdict = self.science_gate.validate_interaction(verb, target, actor_strength)
        outcome = verdict.get("outcome") or {"type": "none"}
        applied = None
        if verdict.get("approved") and outcome.get("type") == "set_state" and target is not None:
            new_state = str(outcome.get("state") or target.state)
            patch = SceneObjectPatch(
                object_id=target.object_id, name=target.name, kind=target.kind,
                location=target.location, state=new_state, source="interaction",
                material=target.material, durability=max(0, target.durability - actor_strength),
                is_destructible=target.is_destructible, is_takeable=target.is_takeable,
                is_movable=target.is_movable, affordances=target.affordances,
            )
            self.upsert_object(patch, approved_by=self.science_gate.director_id)
            applied = new_state
            # propagate: record in the worldbook so every agent knows henceforth
            reason = "；".join(verdict.get("reasons") or []) or f"{target.name} 状态变为 {new_state}"
            self.add_world_entry(
                WorldBookPatch(title=f"{target.name}·{new_state}",
                               content=f"{actor_id} {verb} {target.name}：{reason}", source="interaction",
                               provenance="canonical_event"),
                approved_by=self.science_gate.director_id,
            )
        return {
            "ok": bool(verdict.get("approved")),
            "actor": actor_id, "verb": verb, "object_id": object_id,
            "reasons": verdict.get("reasons") or [],
            "outcome": outcome,
            "applied_state": applied,
        }

    _STATE_DESC = {
        "broken": "被彻底砸烂、四分五裂、碎片散落",
        "damaged": "有明显裂痕和损伤、局部破损",
        "burning": "燃烧着、火焰包裹、冒烟",
        "taken": "空荡荡的原位、物体已被拿走",
    }

    def possess_action(
        self, character_id: str, verb: str, payload: Optional[dict] = None,
    ) -> dict:
        """Execute a player action while possessing *character_id* (张力5).

        Closes the possession execution loop: the player's verb is checked
        against the possessed character's ``allowed_actions`` (setuid, §10.6)
        by :meth:`PossessionManager.execute_action`, and on approval the
        action is applied through the single write point (I4):

          - ``interact`` verbs carrying an ``object_id`` route through the
            existing gate-arbitrated interaction path (砸桌子 etc.).
          - otherwise the action is recorded as a possession worldbook fact
            (origin=rule_engine) so the world has continuity.

        Returns the manager's ``{ok, verb, allowed, reason, result}`` dict.
        """
        def _executor(v: str, p: dict) -> dict:
            object_id = str(p.get("object_id") or "").strip()
            if object_id and self.state_store.get_object(object_id) is not None:
                return self.interact(
                    actor_id=character_id, verb=v, object_id=object_id,
                    actor_strength=int(p.get("actor_strength") or 1),
                )
            # Non-object action: record as a worldbook fact through the write
            # point so downstream beats know what the possessed character did.
            detail = str(p.get("detail") or "")
            content = f"{character_id} 执行 {v}" + (f"：{detail}" if detail else "")
            self.add_world_entry(
                WorldBookPatch(
                    title=f"夺舍·{v}", content=content,
                    source="possession_action", provenance="agent_observation"),
                approved_by=self.science_gate.director_id,
                origin="rule_engine",
            )
            return {"ok": True, "verb": v, "recorded": True}

        return self.possession_manager.execute_action(
            character_id, verb, payload, executor=_executor,
        )

    def create_character_from_description(self, description: str, character_id: Optional[str] = None) -> dict:
        """Description → structured text character card → save.

        Generates a card via the character designer and persists it through
        the science gate. WorldForge is a pure world engine, so the card is
        text-only (personality / appearance / sample_line).
        """
        description = (description or "").strip()
        if not description:
            return {"ok": False, "error": "description is required"}
        try:
            card = self.model_client.complete_character_card(
                description=description,
                model=self.settings.provider_model_deep,
            )
        except Exception as exc:
            return {
                "ok": False,
                "error": f"LLM character generation failed: {exc}",
            }
        if not isinstance(card, dict):
            return {"ok": False, "error": "LLM character generation returned invalid data"}
        warnings = self._normalize_warnings(card.get("warnings"))
        missing = [
            key for key in self._CARD_FIELD_KEYS
            if not str(card.get(key) or "").strip()
        ]
        if missing:
            return {
                "ok": False,
                "error": (
                    "LLM character generation returned incomplete data: "
                    + ", ".join(missing)
                ),
                "warnings": warnings,
            }
        cid = (character_id or self._slugify_character_id(str(card.get("name") or "")) or f"char_{uuid4().hex[:6]}")
        patch = CharacterPatch(
            character_id=cid,
            name=str(card.get("name") or "无名角色"),
            summary=str(card.get("summary") or description[:200]),
            source="character_designer",
            personality=str(card.get("personality") or ""),
            appearance=str(card.get("appearance") or ""),
            sample_line=str(card.get("sample_line") or ""),
        )
        approval = self.science_gate.validate_write([], [patch])
        if not approval.approved:
            return {"ok": False, "error": "science gate rejected card", "reasons": approval.reasons, "card": card}
        self.upsert_character(patch, approved_by=approval.director_id, origin="rule_engine")
        snapshot = self.state_store.snapshot()
        stored = next((e for e in snapshot.characters if e.character_id == cid), None)
        return {
            "ok": True,
            "character": stored.to_dict() if stored else patch.to_dict(),
            "provider_model": card.get("provider_model"),
            "warnings": warnings,
        }

    def create_character(self, *, mode: str,
                         character_id: Optional[str] = None,
                         description: Optional[str] = None,
                         fields: Optional[Dict[str, Any]] = None,
                         as_sim_agent: bool = False) -> dict:
        """Unified character-creation entry point (onboarding stage 2).

        mode="manual": ``fields`` fills the CharacterPatch directly (name
            required, rest optional). No LLM; just science-gate validation
            and upsert. Returns
            {ok, character_id, warnings}.
        mode="auto": equivalent to :meth:`create_character_from_description`
            (description → LLM card). Thin wrapper.
        mode="mixed": user-supplied ``fields`` are kept; fields the user left
            blank (e.g. personality/appearance) are filled by the LLM from
            description+known fields. Returns {ok, character_id, warnings,
            llm_filled_fields}.
        """
        mode = (mode or "").strip().lower()
        if mode == "manual":
            result = self._create_character_manual(character_id=character_id, fields=fields or {})
        elif mode == "auto":
            result = self.create_character_from_description(description=description or "", character_id=character_id)
        elif mode == "mixed":
            result = self._create_character_mixed(character_id=character_id, description=description or "", fields=fields or {})
        else:
            return {"ok": False, "error": f"unknown mode: {mode!r}"}
        if as_sim_agent and result.get("ok"):
            result["sim_agent"] = self._to_sim_agent(result.get("character_id") or "", fields or {})
        return result

    def _to_sim_agent(self, character_id: str, fields: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Wrap a created character into a SimAgent snapshot (P1 §4.2).

        Builds CharacterDefinition from the card fields + derived MindProfile
        + WorldBinding bound to the current world. Returns a JSON-serializable
        dict (character_id / mind / world_binding) so callers can inspect the
        bounded-rational subject without importing SimAgent.
        """
        from .sim_agent import (
            SimAgent, CharacterDefinition, derive_mind_profile, WorldBinding,
        )
        f = fields or {}
        cid = character_id or str(f.get("character_id") or "")
        char = CharacterDefinition(
            character_id=cid,
            name=str(f.get("name") or ""),
            personality=str(f.get("personality") or ""),
            appearance=str(f.get("appearance") or ""),
            sample_line=str(f.get("sample_line") or ""),
            background=str(f.get("summary") or f.get("background") or ""),
            social_role=str(f.get("social_role") or ""),
        )
        mind = derive_mind_profile(char.personality, char.appearance)
        binding = WorldBinding(world_id=getattr(self, "world_id", "") or "")
        sim = SimAgent(character=char, mind=mind, world_binding=binding)
        return {
            "character_id": cid,
            "mind": {
                "evidence_weight": mind.evidence_weight,
                "risk_profile": dict(mind.risk_profile),
                "belief_update_rate": mind.belief_update_rate,
            },
            "world_binding": {
                "world_id": binding.world_id,
                "permissions": dict(binding.permissions),
            },
        }

    # character-card fields the manual/mixed paths know how to copy
    _CARD_FIELD_KEYS = ("name", "summary", "personality", "appearance", "sample_line")

    def _create_character_manual(self, *, character_id: Optional[str], fields: Dict[str, Any]) -> dict:
        """Manual mode: fields → CharacterPatch → science_gate → upsert.

        No LLM; this path persists the supplied text fields directly.
        """
        name = str(fields.get("name") or "").strip()
        if not name:
            return {"ok": False, "error": "name is required in manual mode"}
        summary = str(fields.get("summary") or "").strip() or f"{name}（手动创建）"
        cid = character_id or self._slugify_character_id(name)
        patch = CharacterPatch(
            character_id=cid,
            name=name,
            summary=summary,
            source=str(fields.get("source") or "manual"),
            personality=str(fields.get("personality") or ""),
            appearance=str(fields.get("appearance") or ""),
            sample_line=str(fields.get("sample_line") or ""),
        )
        approval = self.science_gate.validate_write([], [patch])
        if not approval.approved:
            return {"ok": False, "error": "science gate rejected card", "reasons": approval.reasons}
        self.upsert_character(patch, approved_by=approval.director_id, origin="user_action")
        snapshot = self.state_store.snapshot()
        stored = next((e for e in snapshot.characters if e.character_id == cid), None)
        return {
            "ok": True,
            "character_id": cid,
            "character": stored.to_dict() if stored else patch.to_dict(),
            "warnings": [],
        }

    def _create_character_mixed(self, *, character_id: Optional[str], description: str, fields: Dict[str, Any]) -> dict:
        """Mixed mode: user fields kept, blanks filled by the LLM card.

        ``llm_filled_fields`` reports which card fields the LLM supplied
        (i.e. the user did not provide).
        """
        description = (description or "").strip()
        # user_filled_keys = card fields the user explicitly supplied
        user_filled_keys = [
            k for k in self._CARD_FIELD_KEYS
            if str(fields.get(k) or "").strip()
        ]
        missing_keys = [
            key for key in self._CARD_FIELD_KEYS
            if key not in user_filled_keys
        ]
        card: Dict[str, Any] = {}
        warnings: List[str] = []
        if missing_keys:
            if not description:
                return {
                    "ok": False,
                    "error": (
                        "description is required when mixed mode must ask the "
                        "LLM to fill missing fields"
                    ),
                }
            prompt_description = description
            known_fields = {
                key: str(fields.get(key) or "").strip()
                for key in user_filled_keys
            }
            if known_fields:
                prompt_description += (
                    "\n已确认字段（不得改写）: "
                    + json.dumps(known_fields, ensure_ascii=False)
                    + "\n只补全: "
                    + ", ".join(missing_keys)
                )
            try:
                generated = self.model_client.complete_character_card(
                    description=prompt_description,
                    model=self.settings.provider_model_deep,
                )
            except Exception as exc:
                return {
                    "ok": False,
                    "error": f"LLM character completion failed: {exc}",
                }
            if not isinstance(generated, dict):
                return {
                    "ok": False,
                    "error": "LLM character completion returned invalid data",
                }
            card = generated
            warnings = self._normalize_warnings(card.get("warnings"))
            incomplete = [
                key for key in missing_keys
                if not str(card.get(key) or "").strip()
            ]
            if incomplete:
                return {
                    "ok": False,
                    "error": (
                        "LLM character completion left fields empty: "
                        + ", ".join(incomplete)
                    ),
                    "warnings": warnings,
                }

        def _pick(key: str, card_key: Optional[str] = None) -> str:
            card_key = card_key or key
            user_val = str(fields.get(key) or "").strip()
            return user_val or str(card.get(card_key) or "")
        name = _pick("name")
        summary = _pick("summary")
        personality = _pick("personality")
        appearance = _pick("appearance")
        sample_line = _pick("sample_line")
        cid = character_id or self._slugify_character_id(name)
        patch = CharacterPatch(
            character_id=cid,
            name=name,
            summary=summary,
            source=(
                "character_designer+manual" if missing_keys else "manual"
            ),
            personality=personality,
            appearance=appearance,
            sample_line=sample_line,
        )
        approval = self.science_gate.validate_write([], [patch])
        if not approval.approved:
            return {"ok": False, "error": "science gate rejected card", "reasons": approval.reasons, "card": card}
        self.upsert_character(
            patch,
            approved_by=approval.director_id,
            origin="rule_engine" if missing_keys else "user_action",
        )
        llm_filled_fields = list(missing_keys)
        snapshot = self.state_store.snapshot()
        stored = next((e for e in snapshot.characters if e.character_id == cid), None)
        return {
            "ok": True,
            "character_id": cid,
            "character": stored.to_dict() if stored else patch.to_dict(),
            "llm_filled_fields": llm_filled_fields,
            "warnings": warnings,
        }

    @staticmethod
    def _slugify_character_id(name: str) -> str:
        """Build an ascii-safe character_id; fall back to a hash for CJK names."""
        slug = "".join(ch.lower() if ch.isalnum() and ch.isascii() else "_" for ch in name).strip("_")
        slug = "_".join(part for part in slug.split("_") if part)
        return slug or f"char_{uuid4().hex[:6]}"

    def world_tick(
        self,
        session_id: str = "world_clock",
        world_id: Optional[str] = None,
    ) -> Optional[DispatchResult]:
        """Autonomously advance the world one beat, continuing from history.

        Reads the recent worldbook so the beat stays coherent, then drives the
        normal LLM dispatch pipeline with a self-progression prompt. Semantic
        generation failure raises instead of producing replacement prose.
        """
        if world_id is not None:
            with self.world_scope(str(world_id)):
                return self.world_tick(session_id=session_id)
        self._world_beat += 1
        # P0: actually run the LLM-authored DSL rules (立法→颁布). The compiled
        # kernel's emitted changes are the world's autonomous advance; we render
        # them as a worldbook entry so the beat has continuity WITHOUT inventing
        # facts. An unregistered kernel simply emits no deterministic changes
        # (three-body worlds use three_body_tick).
        kernel_changes = self._step_world_kernel(self.world_id)
        kernel_event_lines: List[str] = []
        for c in kernel_changes:
            path = c.get("path", "")
            if path.startswith("_events."):
                # rule_skipped / emit markers — surface as readable lines.
                val = c.get("value")
                if isinstance(val, dict):
                    kernel_event_lines.append(
                        f"rule {val.get('rule_id', '?')}: {val.get('reason', val.get('event', ''))}"
                    )
                continue
            kernel_event_lines.append(
                f"{path} {c.get('op', 'set')} {c.get('value')}"
            )
        # Deterministic execution of an already-generated ruleset remains
        # canonical even if the later LLM narration fails. Persist only these
        # structured kernel facts here; no prose is synthesized.
        if kernel_event_lines:
            kernel_entry = WorldBookEntry(
                title=f"内核事件·第{self._world_beat}拍",
                content="；".join(kernel_event_lines),
                source="world_kernel_tick",
                approved_by="science_director",
                provenance="canonical_event",
            )
            self.add_world_entry(
                WorldBookPatch(
                    title=kernel_entry.title,
                    content=kernel_entry.content,
                    source=kernel_entry.source,
                    provenance=kernel_entry.provenance,
                ),
                approved_by=kernel_entry.approved_by,
                origin="kernel",
            )
        # Phase B/C (§11 AgentMind): when enabled, registered SimAgents run
        # observe→update_belief→choose_action against the post-kernel
        # true_state, and their ActionIntents are routed through the single
        # write point (§12). The kernel's own changes are already in
        # ``kernel_changes``; the agents act *on* that state, never over it.
        agent_record: Dict[str, Any] = {}
        causal_summary = ""
        if self._agent_mind_enabled:
            true_state = {
                "world_id": self.world_id,
                "beat": self._world_beat,
                "kernel_changes": kernel_changes,
                "kernel_state": self.get_world_kernel_state(self.world_id),
            }
            agent_record = self._tick_sim_agents(
                self.world_id, true_state, seed=self._world_beat)
            # Phase D (§14): two-stage causal narrative over the agents'
            # belief traces + applied intents. A model-backed engine must have
            # been attached; missing/failed semantic generation aborts the
            # tick instead of fabricating replacement prose.
            causal = self._run_causal_narrative(self.world_id, agent_record)
            if causal is not None:
                agent_record["causal_narrative"] = causal
                causal_summary = str(causal.get("narrative") or "")
        # Phase 4-8 (decision-commitment lifecycle). Runs on top of the
        # AgentMind cycle when enable_commitments is on: agents emit
        # CommitmentProposals (initiative-driven), the DecisionResolver settles
        # them, the CommitmentExecutor advances active commitments, and
        # observable events are broadcast. Default off → backward compatible.
        commitment_summary: Dict[str, Any] = {}
        if self._commitments_enabled:
            cstate_true = {
                "world_id": self.world_id,
                "beat": self._world_beat,
                "kernel_changes": kernel_changes,
                "kernel_state": self.get_world_kernel_state(self.world_id),
            }
            try:
                commitment_summary = self._tick_commitments(
                    self.world_id, agent_record, cstate_true,
                    self._world_beat, seed=self._world_beat)
            except Exception:
                commitment_summary = {}
        snapshot = self.state_store.snapshot()
        recent = self._recent_worldbook_for_narration(snapshot, limit=3)
        history = "；".join(f"{e.title}: {e.content}" for e in recent) or "尚无既有世界状态。"
        prompt = (
            "世界自主推进（无玩家干预）。"
            f"当前世界书最近进展：{history} "
            "请让世界合理地向前发展一个节拍：延续既有设定，推进一个小事件或角色内心变化，"
            "保持前后连贯，不要重复已有内容。"
        )
        if causal_summary:
            prompt += f" 角色因果链（供参考，勿照抄）：{causal_summary[:200]}"
        if commitment_summary.get("resolutions"):
            prompt += f" 本拍重大决策（供参考，勿照抄）：{self._commitment_brief(commitment_summary)}"
        player_activity = self._last_activity
        try:
            result = self.dispatch(prompt, session_id=session_id, role="world_builder",
                                   advancement_origin="idle_advance")
        except Exception as exc:
            self._last_activity = player_activity
            self._advancement_origin = None
            raise RuntimeError(
                "world tick semantic narration failed"
            ) from exc
        # A tick is not player activity; keep the idle timer measuring player silence.
        self._last_activity = player_activity
        self._advancement_origin = None
        if kernel_event_lines:
            if result is not None:
                result.model_trace["kernel_event_log"] = kernel_event_lines
        if result is not None and agent_record.get("agents"):
            result.model_trace["agent_mind"] = {
                "agents": {
                    cid: {"intent": rec.get("intent"),
                          "belief": rec.get("belief")}
                    for cid, rec in agent_record.get("agents", {}).items()
                },
                "causal_narrative": agent_record.get("causal_narrative"),
            }
        if result is not None and commitment_summary:
            result.model_trace["commitments"] = commitment_summary
        return result

    # -- three-body: kernel-driven, LLM-narrated (spec §8.2 / §8.4) --------
    # Baked timeline horizon (simulation years) + civilization ceiling.
    # Kept modest so the first-tick bake is a few seconds; the demo script
    # can bake a longer line by pre-setting self._three_body_kernel.
    _THREE_BODY_BAKE_YEARS: float = 600.0
    _THREE_BODY_MAX_TECH: float = 10.0
    _THREE_BODY_DELTA: float = 0.1

    def _ensure_three_body_kernel(self) -> "ThreeBodyKernel":
        """Bake the deterministic timeline once, then hold it immutable.

        Spec §8.2 user-immutable boundary: orbits / light series / λ /
        chaotic-era times are baked exactly once and never re-derived. Tests
        (and the demo script) may pre-set ``self._three_body_kernel`` with a
        smaller pre-baked kernel to skip the bake cost.
        """
        if self._three_body_kernel is None:
            # Optional reference adapter: generic dispatch/world_tick must not
            # import or instantiate it unless its explicit tick is invoked.
            from .kernels.three_body import ThreeBodyKernel

            kernel = ThreeBodyKernel(seed=88123, dt=0.02,
                                     lyapunov_renorms=8, lyapunov_renorm_steps=80)
            kernel.bake(years=self._THREE_BODY_BAKE_YEARS)
            self._three_body_kernel = kernel
        return self._three_body_kernel

    def _three_body_civ_state(self) -> dict:
        """In-memory civilization state (the kernel's structured ground truth).

        Not part of JsonStateStore (which owns worldbook/characters/objects);
        this holds the survival-loop scalars the kernel writes through the
        single transactional write point.
        """
        if not hasattr(self, "_three_body_civ") or self._three_body_civ is None:
            self._three_body_civ = {
                "civilization": {"tech_level": 0.0, "count": 1, "alive": True,
                                 "evacuated": False, "last_event": ""},
            }
        return self._three_body_civ

    @staticmethod
    def _resolve_three_body_decision(decision: object, stored_tech: float) -> float:
        """Collapse the decision vector to the tech_level used this beat.

        decision may be a number (tech_level), a dict {"tech_level": x} /
        {"resources": {...}} (resource allocation → tech proxy = sum), or None
        (carry the stored tech_level forward). The kernel — not the LLM —
        consumes this scalar to compute δ₀.
        """
        if decision is None:
            return float(stored_tech)
        if isinstance(decision, (int, float)):
            return float(decision)
        if isinstance(decision, dict):
            if "tech_level" in decision:
                try:
                    return float(decision["tech_level"])
                except (TypeError, ValueError):
                    return float(stored_tech)
            resources = decision.get("resources")
            if isinstance(resources, dict):
                total = 0.0
                for v in resources.values():
                    try:
                        total += float(v)
                    except (TypeError, ValueError):
                        continue
                return total
            # MultiScaleThreeBodySim decision_vector shape
            # {tech, shelter, hoard, gamble} (three_body_agents): the kernel's
            # _decision_quality reads prepare = tech+shelter vs squander =
            # hoard+gamble; the tech proxy fed to civilization_step is the
            # total allocation (sum of all four), mirroring the resources path.
            if "tech" in decision and "hoard" in decision:
                total = 0.0
                for v in decision.values():
                    try:
                        total += float(v)
                    except (TypeError, ValueError):
                        continue
                return total
        return float(stored_tech)

    def three_body_tick(self, session_id: str = "three_body",
                        decision: object = None, world_id: str = "three_body") -> Optional[DispatchResult]:
        """One kernel-driven beat of the Trisolaris civilization arc (spec §8.2).

        Division of labour (I2 red line, spec §8.2):
          - The deterministic ``ThreeBodyKernel`` decides *what happened*:
            survival/destruction, civilization count, next chaotic era, and —
            when the maximum-tech horizon is mathematically shorter than the
            mean chaotic-era gap — the *proven* evacuation.
          - Those numbers are committed through the single transactional write
            point (``StateChange`` with ``origin="kernel"``); the LLM cannot
            touch them.
          - The LLM's *only* job is to turn the kernel's structured event log
            into prose (title/narrative/dialogue). Its output is stored in
            ``llm_output_log`` (discardable) and rendered as the beat's scene —
            it is never a source of state truth.

        ``decision`` is the beat's decision vector (tech_level or resource
        allocation, see ``_resolve_three_body_decision``); ``None`` carries the
        stored tech forward.
        """
        # Enforce world isolation: three-body state goes to its own store, never
        # the default "main" world where Carmen/José live.
        self.set_world(world_id)
        self._world_beat += 1
        kernel = self._ensure_three_body_kernel()
        civ_root = self._three_body_civ_state()
        civ = civ_root["civilization"]

        # ---- deterministic step: the kernel is the ground truth -----------
        tech_level = self._resolve_three_body_decision(decision, civ.get("tech_level", 0.0))
        cursor = self._three_body_cursor
        ev = kernel.civilization_step(tech_level, t=cursor, Delta=self._THREE_BODY_DELTA)

        # Multi-scale AgentMind (§3 / §8.2): when enabled, scientists→org→
        # civilisation deliberate and produce the ``decision_vector``. The
        # sim calls ``kernel.civilization_outcome`` itself (§8.2 red line:
        # the kernel still adjudicates); we reuse that outcome so the tick
        # does NOT re-derive it via ``_three_body_outcome``. The
        # ``decision_vector``'s tech proxy overrides the tech_level fed to
        # ``civilization_step`` above so the event_log reflects what the
        # civilisation actually committed to.
        agent_trace: Any = None
        outcome: Optional[Dict[str, Any]] = None
        if self._agent_mind_enabled and world_id in self._multi_scale_sims:
            sim = self._multi_scale_sims[world_id]
            try:
                agent_trace = sim.tick(
                    t=cursor, civ_tech_level=float(civ.get("tech_level", 0.0)),
                    civ_count=int(civ.get("count", 1)),
                )
            except Exception:
                agent_trace = None
            if agent_trace is not None:
                dv = getattr(agent_trace, "decision_vector", None)
                if isinstance(dv, dict):
                    tech_proxy = self._resolve_three_body_decision(
                        dv, civ.get("tech_level", 0.0))
                    tech_level = tech_proxy
                    ev = kernel.civilization_step(
                        tech_level, t=cursor, Delta=self._THREE_BODY_DELTA)
                outcome = getattr(agent_trace, "outcome", None) or None

        event_log: List[str] = [
            f"beat={self._world_beat}",
            f"t={cursor:.1f}",
            f"tech_level={tech_level:.2f}",
            f"delta_0={ev.delta_0:.3g}",
            f"horizon={ev.T_predict:.1f}yr",
        ]
        if ev.next_chaos is not None:
            interval = ev.next_chaos - ev.t
            event_log.append(f"next_chaotic_era@t={ev.next_chaos:.1f}")
            event_log.append(f"horizon={ev.T_predict:.1f}yr vs interval={interval:.1f}yr")
        else:
            event_log.append("no_further_chaotic_era_in_timeline")

        # Apply the kernel verdict to the structured civilization scalars.
        # When the multi-scale sim ran, the authoritative outcome kind comes
        # from ``agent_trace.outcome`` (the kernel's civilization_outcome);
        # otherwise fall back to the ``civilization_step`` event kind.
        if outcome is not None and isinstance(outcome, dict):
            outcome_kind = str(outcome.get("kind") or ev.kind)
        else:
            outcome_kind = ev.kind
        if outcome_kind.startswith("destroyed") or outcome_kind == "planet_ejected":
            event_log.append("civ_destroyed")
            event_log.append("tech_reset")
            new_tech = 0.0
            new_count = int(civ.get("count", 1)) + 1
            alive = True  # a new civilization rises from the ashes
        else:  # "survived" / "evacuated"
            event_log.append("civ_survived")
            event_log.append("tech_retained")
            new_tech = tech_level + 1.0  # stable-era accumulation
            new_count = int(civ.get("count", 1))
            alive = True

        # Evacuation proof — max-tech horizon < mean chaotic-era gap (§8.2).
        # This is *proven*, not narrated: the kernel returns a bool.
        evacuation_proven = kernel.evacuation_check(
            max_tech=self._THREE_BODY_MAX_TECH, Delta=self._THREE_BODY_DELTA)
        evacuated = bool(civ.get("evacuated")) or evacuation_proven
        if evacuation_proven:
            event_log.append("evacuation_proven")

        # advance the timeline cursor past the chaotic era we just faced
        if ev.next_chaos is not None:
            self._three_body_cursor = ev.next_chaos + 1e-6

        # ---- single write point: commit kernel truth (origin=kernel) ------
        txn = StateTransaction(civ_root).begin()
        txn.apply(StateChange.new(
            origin="kernel",
            changes=[
                {"path": "civilization.tech_level", "op": "set", "value": new_tech},
                {"path": "civilization.count", "op": "set", "value": new_count},
                {"path": "civilization.alive", "op": "set", "value": alive},
                {"path": "civilization.evacuated", "op": "set", "value": evacuated},
                {"path": "civilization.last_event", "op": "set", "value": outcome_kind},
            ],
            prerequisites_checked=["dag:gravity_law", "kernel:baked"],
            speculative=False,
        ))
        txn.commit()
        # commit() rebuilds base_state in place (clear+update from a deepcopy),
        # so re-fetch the nested civ dict — the pre-commit reference is stale.
        civ = civ_root["civilization"]

        # ---- LLM narration: prose only, never state truth -----------------
        history = self._three_body_history()
        narration = self._narrate_three_body(event_log, history)
        warnings: List[str] = list(narration.get("warnings") or [])
        title = str(narration.get("title") or f"三体：第{self._world_beat}拍").strip() \
            or f"三体：第{self._world_beat}拍"
        narrative = str(narration.get("narrative") or "").strip()
        dialogue = str(narration.get("dialogue") or "").strip()
        if not narrative:
            raise RuntimeError("LLM three-body narration returned empty prose")

        # llm_output_log is discardable — kept for audit, not a truth source.
        self._three_body_llm_log.append({
            "beat": self._world_beat,
            "event_log": list(event_log),
            "narrative": narrative,
            "dialogue": dialogue,
        })

        world_updates: List[WorldBookEntry] = []
        # narration of this beat → worldbook (it is story text, not truth)
        beat_entry = WorldBookEntry(title=title, content=narrative,
                                    source="three_body_kernel_narration",
                                    approved_by="science_director",
                                    provenance="narrative_rendering")
        if self.add_world_entry(
                WorldBookPatch(title=beat_entry.title, content=beat_entry.content,
                               source=beat_entry.source,
                               provenance=beat_entry.provenance),
                approved_by=beat_entry.approved_by,
                origin="kernel"):
            world_updates.append(beat_entry)

        # proven evacuation → a worldbook fact (被证明的，不是编的)
        if evacuation_proven and not civ.get("_evac_recorded"):
            evac_entry = WorldBookEntry(
                title="文明决定逃离三体星系",
                content=("文明证明长期不可幸存：即便在最高科技水平下，可证明的预测视界"
                         "仍短于乱纪元平均间隔（Lyapunov 墙），故决定逃离三体星系。"),
                source="three_body_kernel_evacuation",
                approved_by="science_director",
                provenance="canonical_event")
            if self.add_world_entry(
                    WorldBookPatch(title=evac_entry.title, content=evac_entry.content,
                                   source=evac_entry.source,
                                   provenance=evac_entry.provenance),
                    approved_by=evac_entry.approved_by,
                    origin="kernel"):
                world_updates.append(evac_entry)
                civ["_evac_recorded"] = True

        # Compute the structured terminal outcome for diagnostics. The beat's
        # accepted LLM prose above is the only narrative artifact; the runtime
        # no longer fabricates a second deterministic "outcome chapter".
        if outcome is None:
            outcome = self._three_body_outcome(
                ev, kernel, tech_level, cursor, civ, evacuation_proven, decision,
            )

        # a tick is not player activity; keep the idle timer measuring silence
        player_activity = self._last_activity
        self._last_activity = player_activity
        if not world_updates:
            return None
        return DispatchResult(
            session_id=session_id,
            intent="complex_story",
            director_brief=narrative[:400],
            dialogue=dialogue,
            tasks=[],
            world_updates=world_updates,
            character_updates=[],
            model_trace={
                "model_fast": self.settings.model_fast,
                "model_deep": self.settings.model_deep,
                "provider_model_fast": self.settings.provider_model_fast,
                "provider_model_deep": self.settings.provider_model_deep,
                "live_api_enabled": self.settings.enable_live_api,
                "world_builder_beat": self._world_beat,
                "kernel_event_log": event_log,
                "kernel_verdict": outcome_kind,
                "civilization": dict(civ),
                "evacuation_proven": evacuation_proven,
                "agent_causal_trace": (
                    agent_trace.as_dict() if agent_trace is not None else None),
            },
            warnings=warnings,
        )

    def _three_body_history(self) -> str:
        """Recent worldbook lines, for narration continuity (read-only).

        §17 P0 事实隔离: prefer canonical_event (kernel truth) so the LLM
        narrates from facts, not from previous LLM prose — shadow-world
        defense. Falls back to any entry when no canonical ones exist."""
        try:
            snapshot = self.state_store.snapshot()
        except Exception:
            return "尚无既有世界状态。"
        recent = self._recent_worldbook_for_narration(snapshot, limit=3)
        return "；".join(f"{e.title}: {e.content}" for e in recent) or "尚无既有世界状态。"

    def _recent_worldbook_for_narration(self, snapshot: StateSnapshot, *, limit: int = 3) -> List[WorldBookEntry]:
        """§17 P0 事实隔离: pick the most recent worldbook entries, preferring
        ``canonical_event`` (kernel truth) over ``narrative_rendering`` (LLM
        prose). The next narration beat is built on facts, not on prior prose,
        so Kernel State and LLM Prose cannot drift apart (shadow-world fix).

        Selection order: the most recent ``limit`` canonical_event entries; if
        fewer than ``limit`` exist, top up with the most recent non-canonical
        entries so continuity still has something to read on a fresh world.
        The final list is in chronological (append) order, mirroring the old
        ``worldbook[-limit:]`` semantics."""
        wb = snapshot.worldbook
        if not wb:
            return []
        canonical = [e for e in wb if e.provenance == "canonical_event"]
        if len(canonical) >= limit:
            return canonical[-limit:]
        non_canonical = [e for e in wb if e.provenance != "canonical_event"]
        tail = non_canonical[-(limit - len(canonical)):] if non_canonical else []
        chosen = {id(e) for e in canonical}
        merged = list(canonical)
        for e in tail:
            if id(e) not in chosen:
                merged.append(e)
                chosen.add(id(e))
        order = {id(e): i for i, e in enumerate(wb)}
        merged.sort(key=lambda e: order.get(id(e), 0))
        return merged[-limit:]

    def _three_body_outcome(self, ev, kernel, tech_level, cursor,
                            civ, evacuation_proven, decision) -> dict:
        """Build the diversified kernel ``Outcome`` dict for this beat.

        Prefers the kernel's own ``civilization_outcome`` (rich, diversified
        per §8.2).  Falls back to synthesising from the ``CivilizationEvent``
        for stub/legacy kernels that only implement ``civilization_step`` —
        in that case the outcome kind collapses to ``survived`` /
        ``destroyed_chaos`` so no new physics is invented.
        """
        civ_count = int(civ.get("count", 1))
        outcome_fn = getattr(kernel, "civilization_outcome", None)
        if callable(outcome_fn):
            try:
                return outcome_fn(
                    tech_level=tech_level, t=cursor,
                    decision_vector=decision,
                    Delta=self._THREE_BODY_DELTA,
                    civ_count=civ_count,
                    evacuated=bool(evacuation_proven),
                ).as_dict()
            except Exception:
                pass  # fall through to synthesis — never crash the tick
        # Synthesis from the CivilizationEvent (stub-kernel path).
        if getattr(ev, "kind", None) == "destroyed":
            return {
                "kind": "destroyed_chaos", "cause": "chaotic_era_unforeseen",
                "detail": "stub kernel: horizon did not cover next chaos",
                "t": float(cursor), "tech_level": float(tech_level),
                "delta_0": float(getattr(ev, "delta_0", 0.0)),
                "T_predict": float(getattr(ev, "T_predict", 0.0)),
                "next_chaos": getattr(ev, "next_chaos", None),
                "planet_energy": None, "decision_quality": "neutral",
                "civ_count": civ_count, "note": getattr(ev, "note", ""),
            }
        return {
            "kind": "survived", "cause": "horizon_covers_chaos",
            "detail": "stub kernel: survived",
            "t": float(cursor), "tech_level": float(tech_level),
            "delta_0": float(getattr(ev, "delta_0", 0.0)),
            "T_predict": float(getattr(ev, "T_predict", 0.0)),
            "next_chaos": getattr(ev, "next_chaos", None),
            "planet_energy": None, "decision_quality": "neutral",
            "civ_count": civ_count, "note": getattr(ev, "note", ""),
        }

    def _narrate_three_body(self, event_log: List[str], history: str) -> Dict[str, Any]:
        """Turn the kernel's structured event log into prose (title/narrative/
        dialogue). This is the LLM's ONLY job in the three-body loop — it is
        told the facts and must not invent or overrule them (spec §8.2 I2).

        Returns a dict with title/narrative/dialogue/warnings. Missing model
        access, transport/parse failure, or verdict inconsistency raises.
        Tests may monkeypatch this method to inject accepted model output.
        """
        import urllib.error
        import urllib.request

        agent = self.settings.agent_config("world_builder")
        provider_model = self.settings.provider_model_name(
            agent.model or self.settings.provider_model_deep
        )
        if not self.settings.agent_live_api_enabled("world_builder"):
            raise RuntimeError(
                "three-body narration requires a configured live LLM"
            )
        url = f"{self.settings.agent_normalized_base_url('world_builder')}/chat/completions"
        system_prompt = (
            "你是三体世界的小说家。给你的是确定性物理内核算出的**事件事实**"
            "（存亡、文明计数、乱纪元时刻、预测视界、是否证明需要逃离）。"
            "你的唯一任务：把这些事实**改编成文学性的场景叙事**（约200-300字中文），"
            "像写科幻小说一样——有具体人物、感官细节、情感张力、戏剧性。"
            "**不得改动、质疑或新增任何事实**（不得自行判定文明是否幸存、是否逃离——那是内核算好的）。\n"
            "写作要求：\n"
            "1. **禁止照抄数字**。不要写'科技等级X''delta_0=Y''视界Z年'这类工程参数——"
            "把它们转译成叙事（如'他们的观测精度又精进了十倍，但那道混沌之墙依旧矗立'）。\n"
            "2. **禁止模板化**。不要写'地球文明在科技等级X时迎来第N次接触'这种句式。每拍要有独特场景。\n"
            "3. **场景化**：写一个具体瞬间——某个科学家在观测台、某个公民在脱水、某次乱纪元降临时的街道。\n"
            "4. **连贯**：延续世界书已有的人物（如陆远/苏青/林）与设定，推进他们的命运。\n"
            "5. **台词要有血肉**，不是信息播报。\n"
            "只输出严格 JSON: {\"title\":\"...\",\"narrative\":\"...\",\"dialogue\":\"...\"}。"
            "title ≤ 20 字且有诗意,dialogue 是一句代表性台词。不要 markdown 围栏,不要解释。"
        )
        user_prompt = (
            f"世界书最近进展(不要重复这些内容,要推进):\n{history}\n\n"
            f"本拍内核事实(你的叙事必须与这些事实一致,但不要照抄数字,要转译成小说):\n- " + "\n- ".join(event_log) + "\n"
            "请写一个**与之前完全不同**的瞬间——不同人物、不同地点、不同情绪。"
            "如果上一拍在观测台,这拍就去地下城/脱水仓/废墟/会议厅。推进故事,不要循环。"
        )
        body = {
            "model": provider_model,
            "messages": [
                {"role": "system", "content": system_prompt},
                # few-shot: show the LLM what good three-body narration looks like
                {"role": "user", "content": "世界书最近进展:混沌前奏：引力涟漪的低语。\n本拍内核事实:\n- chaotic_era_arrived\n- civ_destroyed\n- tech_reset\n请写这一拍的具体场景。"},
                {"role": "assistant", "content": '{"title":"恒星的审判","narrative":"陆远跪在观测台的碎玻璃间，三颗太阳在地平线上跳着不可预测的舞步。他刚算出的轨道方程在纸上是完美的——但窗外，引力潮汐正将城市撕成螺旋。脱水仓的警报响了三代人，这一代没能逃过。苏青从废墟里刨出半块晶体板，上面还残留着上一文明留下的最后一组数据。她把它塞进怀里，向地下城的方向走去——新的纪元要开始了，又是从零开始。","dialogue":"又结束了……但至少，这次我们留下了点什么。"}'},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.95,
            "max_tokens": 4096,
        }
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                headers={
                    **self.settings.agent_auth_headers("world_builder"),
                    "Content-Type": "application/json",
                },
                method="POST",
            )
            with urllib.request.urlopen(req) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
            message = payload.get("choices", [{}])[0].get("message", {})
            content = (message.get("content") or message.get("reasoning_content") or "").strip()
        except (urllib.error.URLError, urllib.error.HTTPError,
                json.JSONDecodeError, KeyError, IndexError) as exc:
            raise RuntimeError(
                f"three-body LLM narration failed: {exc}"
            ) from exc

        # Parsing + §8.2 verdict-consistency guard live on ThreeBodyNarrator.
        # Rejected output raises and is never presented as successful prose.
        return self._three_body_narrator().narrate_beat(
            event_log, history, llm_content=content,
        )

    def _three_body_narrator(self):
        """Lazily build the singleton ThreeBodyNarrator used by the runtime.

        ``llm_fn`` is None because the dispatcher makes the LLM HTTP call
        itself and passes the raw content to ``narrate_beat``. The narrator
        is used for parsing and its §8.2 consistency guard.
        """
        from .three_body_narrator import ThreeBodyNarrator
        if getattr(self, "_three_body_narrator_instance", None) is None:
            self._three_body_narrator_instance = ThreeBodyNarrator(
                llm_fn=None, seed=88123)
        return self._three_body_narrator_instance

    def _normalize_warnings(self, warnings: object) -> List[str]:
        if warnings is None:
            return []
        if isinstance(warnings, str):
            return [warnings]
        if isinstance(warnings, list):
            return [str(item) for item in warnings]
        return [str(warnings)]

    def _build_tasks(self, session_id: str, message: str, director: dict, intent: str) -> List[Task]:
        base_payload = {"message": message, "intent": intent}
        tasks: List[Task] = []
        if intent in {"complex_story", "possession", "world_update"}:
            tasks.append(
                Task(
                    task_id=f"task_{uuid4().hex[:8]}",
                    type="game_logic",
                    priority=2,
                    payload={**base_payload, "rule": "update world beat after science validation"},
                )
            )
        return tasks

    def _apply_verified_writes(self, message: str, director: dict) -> tuple[List[WorldBookEntry], List[CharacterEntry]]:
        # Origin tag for this beat's writes (spec §13.4). "idle_advance" marks
        # autonomous beats; None falls back to "rule_engine".
        beat_origin = self._advancement_origin or "rule_engine"
        world_patch = WorldBookPatch(
            title=str(director.get("world_title") or "World Update"),
            content=str(director.get("world_content") or f"World updated from user request: {message}"),
            source="director_group",
            provenance="narrative_rendering",
        )
        # Possession guard (调研① bug fix): a possessed character must not be
        # manipulated by autonomous LLM advancement (world_tick → dispatch).
        # Before this, _apply_verified_writes always wrote a CharacterPatch
        # for "aster" with possessed=False, clobbering an active possession.
        # Now: if the stored actor is currently possessed, skip the character
        # write entirely (the player owns that actor; the AI's beat is recorded
        # only in the worldbook, not on the character) and queue the AI's
        # proposed action as a pending_ai_action for the player to review.
        existing = next(
            (c for c in self.state_store.snapshot().characters if c.character_id == "aster"),
            None,
        )
        possession_active = bool(existing and existing.possessed)
        if possession_active:
            # Queue the AI's intent as a subconscious pending action instead of
            # writing to the possessed actor. The worldbook entry still lands
            # so continuity is preserved; the actor stays player-controlled.
            action_patch = {
                "actor_id": "aster",
                "intent": str(director.get("intent") or "complex_story"),
                "message": message,
                "summary": str(director.get("character_summary") or ""),
            }
            try:
                self.possession_manager.queue_ai_action("aster", action_patch)
            except Exception:
                pass
            approval = self.science_gate.validate_write([world_patch], [])
            if not approval.approved:
                return [], []
            self.add_world_entry(world_patch, approved_by=approval.director_id, origin=beat_origin)
            snapshot = self.state_store.snapshot()
            return snapshot.worldbook[-1:], [existing] if existing else []
        character_patch = CharacterPatch(
            character_id="aster",
            name="Aster",
            summary=str(director.get("character_summary") or "Primary actor currently anchored to the live scene."),
            source="director_group",
            possessed="夺舍" in message,
            possessed_by="player_01" if "夺舍" in message else None,
            ai_subconscious="Player control is active; AI output is suppressed." if "夺舍" in message else "",
        )
        approval = self.science_gate.validate_write([world_patch], [character_patch])
        if not approval.approved:
            return [], []
        self.add_world_entry(world_patch, approved_by=approval.director_id, origin=beat_origin)
        self.upsert_character(character_patch, approved_by=approval.director_id, origin=beat_origin)
        snapshot = self.state_store.snapshot()
        return snapshot.worldbook[-1:], [entry for entry in snapshot.characters if entry.character_id == "aster"]


# ---------------------------------------------------------------------------
# Commitment-layer dotted-path helpers (module-level, stdlib only).
# Used by _tick_commitments to read/write the commitment layer's own state
# dict (not the kernel's). Kept separate from commitments._get_path etc. so
# this module has no dependency on a private API of another module.
# ---------------------------------------------------------------------------


def _cget(state: Dict[str, Any], path: str) -> Any:
    if not path:
        return None
    cur: Any = state
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def _cset(state: Dict[str, Any], path: str, value: Any) -> None:
    if not path:
        return
    parts = path.split(".")
    cur: Any = state
    for part in parts[:-1]:
        if not isinstance(cur.get(part), dict):
            cur[part] = {}
        cur = cur[part]
    cur[parts[-1]] = value
