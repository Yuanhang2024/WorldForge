"""DecisionResolver — settle a proposed major decision (spec § effect formula).

The resolver is the structural layer that decides **whether a proposed
commitment lands, and how hard**.  It is the seat of the distinction
the user drew between *cognitive error* (the actor's judgement was
wrong) and *execution failure* (the decision was sound but execution
collapsed).  Both depress the outcome, but for different narrative
reasons — and the resolver tags which is which.

Effect formula (load-bearing)::

    net = decision_strength
          × authority
          × resource
          × execution_capability
          × org_compliance
          × time
          × environment_fit
          × (1 − opposition)
          × (1 − info_error_penalty)     # cognitive error
          × (1 − failure_penalty)        # execution failure

Every factor is ``[0, 1]`` (a ratio) except ``decision_strength`` which
may exceed 1.  The resolver returns a :class:`DecisionResolution`
carrying the status (rejected / authorized / partial / delayed /
sabotaged / completed), ``execution_ratio``, consumed resources, the
4-layer :class:`DecisionEffects`, observable events, opposition refs,
and a full :class:`DecisionResolutionTrace`.

Red lines
---------
- Pure stdlib, deterministic, seed-driven.  No LLM, no unseeded
  randomness (§8.2).  The LLM proposes + narrates; this layer decides
  authority / resources / progress / observability / world variables /
  success (spec — LLM boundary).
- Never mutates the world kernel; returns a structured resolution the
  dispatcher's single write point settles.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .commitments import (
    ACTION_TEMPLATES,
    Commitment,
    CommitmentProposal,
    CommitmentStatus,
    DecisionEffects,
    DecisionResolutionTrace,
    ScheduledEffect,
    WorldModifier,
    is_terminal_status,
    proposal_from_template,
    transition_commitment,
)


__all__ = [
    "DecisionResolution",
    "DecisionResolver",
    "AuthorityCheck",
    "OrgSupport",
    "Opposition",
    "Environment",
]


# ---------------------------------------------------------------------------
# Input bundles — the dispatcher fills these in before resolving
# ---------------------------------------------------------------------------


@dataclass
class AuthorityCheck:
    """Result of the authority-feasibility gate (spec § lifecycle step 4).

    ``feasible`` = the actor is allowed to make this decision at all.
    ``factor`` ∈ [0, 1] = how much authority backs it (1 = full mandate,
    0 = none).  A non-feasible proposal is rejected outright.
    """

    feasible: bool = True
    factor: float = 1.0
    authority_source: str = "self"
    reason: str = ""


@dataclass
class OrgSupport:
    """Organisational support for a proposal (spec § lifecycle step 5).

    Aggregated through the character_graph trust gate + org_decide by
    the dispatcher; the resolver only reads the result.
    """

    compliance: float = 1.0    # [0,1] — how much the org obeys
    supporters: List[str] = field(default_factory=list)
    dissenters: List[str] = field(default_factory=list)
    decision: Optional[str] = None  # the org's resolved choice (if any)


@dataclass
class Opposition:
    """Active opposition to a proposal (spec § lifecycle step 8).

    ``strength`` ∈ [0, 1] = how hard opponents push back; ``refs`` lists
    the opposing actor/org ids (for the resolution's ``opposition_refs``).
    """

    strength: float = 0.0
    refs: List[str] = field(default_factory=list)
    sabotage: bool = False     # active sabotage (not just dissent)


@dataclass
class Environment:
    """Environment / context the decision lands in (spec § lifecycle).

    ``fit`` ∈ [0, 1] = how hospitable the environment is to this
    decision.  ``info_error`` ∈ [0, 1] = the actor's *cognitive* error
    (they misread the situation — wrong belief drove the proposal).
    ``failure_pressure`` ∈ [0, 1] = exogenous execution headwind
    (breakdowns, corruption, delay) independent of the actor's judgement.
    """

    fit: float = 1.0
    info_error: float = 0.0
    failure_pressure: float = 0.0
    time_available: float = 1.0   # [0,1+] — slack vs the deadline


# ---------------------------------------------------------------------------
# DecisionResolution — the resolver's return value
# ---------------------------------------------------------------------------


#: Resolution status vocabulary.  ``rejected`` = never authorised;
#: ``authorized`` = cleared to act (no execution yet); ``partial`` =
#: authorised but under-resourced (will run slower / weaker);
#: ``delayed`` = authorised but blocked this tick by cognitive error /
#: missing info; ``sabotaged`` = opposition sank execution;
#: ``completed`` = the decision's immediate effect landed in full.
RESOLUTION_STATUSES = (
    "rejected",
    "authorized",
    "partial",
    "delayed",
    "sabotaged",
    "completed",
)


@dataclass
class DecisionResolution:
    """The structured result of resolving a :class:`CommitmentProposal`.

    Carries everything the dispatcher needs to (a) create / not create a
    :class:`Commitment`, (b) commit the 4-layer effects through the
    single write point, (c) broadcast observable events, (d) record the
    full audit trace for the narrator.
    """

    proposal: CommitmentProposal
    status: str                       # one of RESOLUTION_STATUSES
    execution_ratio: float            # [0,1] — drives commitment progress speed
    consumed_resources: Dict[str, float] = field(default_factory=dict)
    effects: DecisionEffects = field(default_factory=DecisionEffects)
    events: List[Dict[str, Any]] = field(default_factory=list)
    opposition_refs: List[str] = field(default_factory=list)
    trace: DecisionResolutionTrace = field(default_factory=DecisionResolutionTrace)
    commitment_id: Optional[str] = None   # set when a Commitment is created

    @property
    def creates_commitment(self) -> bool:
        """Whether the resolution authorises a persistent Commitment."""
        return self.status in ("authorized", "partial", "delayed")

    @property
    def cognitive_error(self) -> bool:
        return bool(self.trace.cognitive_error)

    @property
    def execution_failure(self) -> bool:
        return bool(self.trace.execution_failure)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "proposal": self.proposal.to_dict(),
            "status": self.status,
            "execution_ratio": self.execution_ratio,
            "consumed_resources": dict(self.consumed_resources),
            "effects": self.effects.to_dict(),
            "events": list(self.events),
            "opposition_refs": list(self.opposition_refs),
            "trace": self.trace.to_dict(),
            "commitment_id": self.commitment_id,
        }


# ---------------------------------------------------------------------------
# DecisionResolver — the effect formula + status routing
# ---------------------------------------------------------------------------


class DecisionResolver:
    """Resolve a :class:`CommitmentProposal` into a :class:`DecisionResolution`.

    The resolver encodes the user's effect formula as a multiplicative
    chain of ratios, then routes the resulting ``net_effect`` to a
    status.  It distinguishes *cognitive error* (the actor's belief was
    wrong → ``info_error_penalty`` → ``delayed`` / ``rejected``) from
    *execution failure* (the decision was sound but execution collapsed
    → ``failure_penalty`` + opposition → ``sabotaged`` / ``partial``).

    Thresholds (constructor knobs, all deterministic):

    - ``reject_threshold``: net_effect below this → ``rejected`` (or
      ``delayed`` when the decision was sound but info-error blocked it).
    - ``partial_threshold``: net_effect below this but above reject →
      ``partial`` (under-resourced, runs slower).
    - ``sabotage_threshold``: opposition strength above this with active
      sabotage → ``sabotaged``.
    - ``complete_threshold``: net_effect above this and the action is
      instantaneous (``expected_duration == 1``) → ``completed``.
    """

    def __init__(
        self,
        *,
        reject_threshold: float = 0.15,
        partial_threshold: float = 0.5,
        sabotage_threshold: float = 0.6,
        complete_threshold: float = 0.85,
        seed: Optional[int] = None,
    ) -> None:
        self.reject_threshold = float(reject_threshold)
        self.partial_threshold = float(partial_threshold)
        self.sabotage_threshold = float(sabotage_threshold)
        self.complete_threshold = float(complete_threshold)
        self.seed = seed

    # -- public ----------------------------------------------------------

    def resolve(
        self,
        proposal: CommitmentProposal,
        *,
        authority: Optional[AuthorityCheck] = None,
        resources: Optional[Dict[str, float]] = None,
        org_support: Optional[OrgSupport] = None,
        opposition: Optional[Opposition] = None,
        environment: Optional[Environment] = None,
    ) -> DecisionResolution:
        """Resolve a proposal → DecisionResolution (effect formula + routing)."""
        authority = authority or AuthorityCheck()
        org_support = org_support or OrgSupport()
        opposition = opposition or Opposition()
        env = environment or Environment()
        resources = dict(resources or {})

        trace = DecisionResolutionTrace()

        # --- factor 1: decision strength (may exceed 1) ------------------
        trace.decision_strength = max(0.0, float(proposal.decision_strength))

        # --- factor 2: authority -----------------------------------------
        if not authority.feasible:
            # authority gate fails → rejected outright, no commitment
            trace.authority = 0.0
            trace.net_effect = 0.0
            return self._build(
                proposal, "rejected", 0.0, trace, consumed={},
                effects=DecisionEffects(), events=[{
                    "type": "decision_rejected",
                    "actor_id": proposal.actor_id,
                    "reason": authority.reason or "authority gate failed",
                }],
                opposition_refs=list(opposition.refs),
            )
        trace.authority = _clamp01(authority.factor)

        # --- factor 3: resources -----------------------------------------
        # resource factor = allocated / required (per-key min), 1.0 when
        # nothing is required.
        req = proposal.required_resources or {}
        if req:
            ratios = []
            for key, need in req.items():
                need = float(need)
                got = float(resources.get(key, 0.0))
                ratios.append((got / need) if need > 0 else 1.0)
            trace.resource = _clamp01(min(ratios))
        else:
            trace.resource = 1.0
        consumed = {
            k: min(float(v), float(resources.get(k, 0.0)))
            for k, v in req.items()
        }

        # --- factor 4: execution capability ------------------------------
        trace.execution_capability = _clamp01(proposal.execution_capability)

        # --- factor 5: org compliance ------------------------------------
        trace.org_compliance = _clamp01(org_support.compliance)

        # --- factor 6: time ----------------------------------------------
        trace.time = _clamp01(env.time_available)

        # --- factor 7: environment fit -----------------------------------
        trace.environment_fit = _clamp01(env.fit)

        # --- factor 8: opposition ----------------------------------------
        trace.opposition = _clamp01(opposition.strength)

        # --- cognitive error vs execution failure ------------------------
        # info_error_penalty: the actor's belief was wrong.  This is a
        # *cognitive* depression — the decision was based on a misread.
        trace.info_error_penalty = _clamp01(env.info_error)
        trace.cognitive_error = trace.info_error_penalty >= 0.5
        # failure_penalty: exogenous execution headwind (breakdown /
        # corruption / delay) independent of the actor's judgement.
        trace.failure_penalty = _clamp01(env.failure_pressure)
        trace.execution_failure = (
            trace.failure_penalty >= 0.5 or opposition.sabotage
        )

        # --- net effect (the formula) ------------------------------------
        raw = (
            trace.decision_strength
            * trace.authority
            * trace.resource
            * trace.execution_capability
            * trace.org_compliance
            * trace.time
            * trace.environment_fit
        )
        trace.raw_effect = raw
        net = raw * (1.0 - trace.opposition) \
            * (1.0 - trace.info_error_penalty) \
            * (1.0 - trace.failure_penalty)
        trace.net_effect = max(0.0, min(2.0, net))

        # --- route to status ---------------------------------------------
        status, exec_ratio = self._route(
            trace, proposal, opposition, env)

        # --- build effects (4-layer consequences) ------------------------
        effects = self._build_effects(
            proposal, status, exec_ratio, trace, env, opposition)
        events = self._build_events(
            proposal, status, exec_ratio, trace, opposition)

        return self._build(
            proposal, status, exec_ratio, trace,
            consumed=consumed, effects=effects, events=events,
            opposition_refs=list(opposition.refs),
        )

    # -- status routing --------------------------------------------------

    def _route(
        self, trace: DecisionResolutionTrace, proposal: CommitmentProposal,
        opposition: Opposition, env: Environment,
    ) -> Tuple[str, float]:
        """Map the net effect + flags to a (status, execution_ratio)."""
        net = trace.net_effect

        # cognitive error strong enough to block → delayed (decision sound
        # but the actor cannot act on bad info this tick)
        if trace.cognitive_error and net < self.partial_threshold:
            # if the decision itself is too weak even without the error,
            # it is rejected; otherwise it is delayed.
            if trace.raw_effect * (1.0 - trace.opposition) < self.reject_threshold:
                return "rejected", 0.0
            return "delayed", _clamp01(net)

        # active sabotage sinks execution
        if opposition.sabotage and opposition.strength >= self.sabotage_threshold:
            return "sabotaged", _clamp01(net * 0.25)

        # too weak overall → rejected
        if net < self.reject_threshold:
            return "rejected", 0.0

        # instantaneous action that landed fully → completed
        if net >= self.complete_threshold and proposal.expected_duration <= 1:
            return "completed", 1.0

        # under-resourced → partial (authorised but runs slower / weaker)
        if net < self.partial_threshold:
            return "partial", _clamp01(net)

        # otherwise: authorised, execution_ratio = net clamped to [0,1]
        return "authorized", _clamp01(net)

    # -- effects (4-layer) -----------------------------------------------

    def _build_effects(
        self, proposal: CommitmentProposal, status: str, exec_ratio: float,
        trace: DecisionResolutionTrace, env: Environment,
        opposition: Opposition,
    ) -> DecisionEffects:
        """Construct the 4-layer :class:`DecisionEffects` for the resolution.

        Only non-rejected resolutions produce effects.  The shape:
        - immediate_deltas: a scalar reputation/standing bump on the
          actor proportional to exec_ratio (path dependence — even a
          partial decision stakes reputation).
        - resource_transfers: resources consumed from the source.
        - relationship_changes: opposition → conflict nudges;
          supporters → trust nudges.
        - scheduled_effects + world_modifiers: built from the action
          template (launch_project / establish_policy / mobilize_faction
          all produce a time-bounded modifier).
        - spawned_commitments: empty by default (subclasses / callers
          may extend).
        """
        effects = DecisionEffects()
        if status == "rejected":
            return effects

        # 1. immediate deltas — reputation staked (path dependence)
        effects.immediate_deltas[
            f"actors.{proposal.actor_id}.reputation"
        ] = float(exec_ratio) * 0.1

        # 2. resource transfers — consumed resources flow from the actor
        for key, amt in proposal.required_resources.items():
            consumed = min(float(amt), float(exec_ratio) * float(amt))
            if consumed > 0:
                effects.resource_transfers.append({
                    "from": proposal.actor_id,
                    "to": f"commitment:{proposal.decision_type}",
                    "resource": key,
                    "amount": consumed,
                })

        # 3. relationship changes — opposition hardens conflict
        for opp_id in opposition.refs:
            effects.relationship_changes.append({
                "from": proposal.actor_id,
                "to": opp_id,
                "trust_delta": -0.1 * (1.0 + float(opposition.strength)),
                "conflict_delta": 0.1 * float(opposition.strength),
                "reason": f"opposed {proposal.decision_type}",
            })

        # 4/5. scheduled effects + world modifier (template-driven)
        if status in ("authorized", "partial", "completed"):
            modifier = self._build_modifier(proposal, status, exec_ratio)
            if modifier is not None:
                effects.world_modifiers.append(modifier)
            sched = self._build_scheduled_effect(proposal, status, exec_ratio)
            if sched is not None:
                effects.scheduled_effects.append(sched)

        # 4b. per-action customisation (launch_project output, establish_policy
        # enact flag, mobilize_faction relationship ripple).
        from .commitments import customize_effects
        effects = customize_effects(proposal.decision_type, proposal,
                                    effects, exec_ratio)
        return effects

    def _build_modifier(self, proposal: CommitmentProposal, status: str,
                        exec_ratio: float) -> Optional[WorldModifier]:
        """Build the WorldModifier the decision's template says it produces."""
        tpl = ACTION_TEMPLATES.get(proposal.decision_type, {})
        if not tpl.get("produces_modifier"):
            return None
        scope = tpl.get("modifier_scope", proposal.decision_type)
        start = proposal.proposed_tick + max(1, proposal.expected_duration)
        # duration scales with exec_ratio (partial → shorter-lived modifier)
        duration = max(1, int(round(proposal.expected_duration
                                    * max(0.25, exec_ratio))))
        end = start + duration
        return WorldModifier(
            modifier_id=f"mod:{proposal.actor_id}:{proposal.decision_type}:"
                        f"{proposal.proposed_tick}",
            source_decision_id=f"{proposal.actor_id}:{proposal.decision_type}:"
                               f"{proposal.proposed_tick}",
            scope=scope,
            start_tick=start,
            end_tick=end,
            rule_modifiers=[{
                "path": f"world.{scope}.{proposal.actor_id}",
                "op": "set",
                "value": float(exec_ratio),
            }],
        )

    def _build_scheduled_effect(self, proposal: CommitmentProposal,
                                status: str,
                                exec_ratio: float) -> Optional[ScheduledEffect]:
        """A deferred 'decision outcome' event fired at the project's end."""
        due = proposal.proposed_tick + max(1, proposal.expected_duration)
        return ScheduledEffect(
            source_id=f"{proposal.actor_id}:{proposal.decision_type}:"
                      f"{proposal.proposed_tick}",
            due_tick=due,
            effect={
                "op": "event",
                "name": f"{proposal.decision_type}_outcome",
                "payload": {
                    "actor_id": proposal.actor_id,
                    "decision_type": proposal.decision_type,
                    "status": status,
                    "execution_ratio": float(exec_ratio),
                    "goal": proposal.goal,
                },
            },
        )

    def _build_events(self, proposal: CommitmentProposal, status: str,
                      exec_ratio: float, trace: DecisionResolutionTrace,
                      opposition: Opposition) -> List[Dict[str, Any]]:
        """Observable events broadcast at Phase 7 (secrecy-gated)."""
        visibility = max(0.0, 1.0 - proposal.secrecy)
        return [{
            "type": "decision_resolved",
            "actor_id": proposal.actor_id,
            "decision_type": proposal.decision_type,
            "status": status,
            "execution_ratio": exec_ratio,
            "cognitive_error": trace.cognitive_error,
            "execution_failure": trace.execution_failure,
            "visibility": visibility,
            "tick": proposal.proposed_tick,
        }]

    # -- create the Commitment + bundle the resolution -------------------

    def _build(
        self, proposal: CommitmentProposal, status: str, exec_ratio: float,
        trace: DecisionResolutionTrace, *, consumed: Dict[str, float],
        effects: DecisionEffects, events: List[Dict[str, Any]],
        opposition_refs: List[str],
    ) -> DecisionResolution:
        return DecisionResolution(
            proposal=proposal,
            status=status,
            execution_ratio=exec_ratio,
            consumed_resources=consumed,
            effects=effects,
            events=events,
            opposition_refs=opposition_refs,
            trace=trace,
        )

    # -- convenience: resolve + create Commitment in one step -----------

    def resolve_and_commit(
        self,
        proposal: CommitmentProposal,
        executor: Any,
        *,
        commitment_id: Optional[str] = None,
        authority: Optional[AuthorityCheck] = None,
        resources: Optional[Dict[str, float]] = None,
        org_support: Optional[OrgSupport] = None,
        opposition: Optional[Opposition] = None,
        environment: Optional[Environment] = None,
    ) -> DecisionResolution:
        """Resolve a proposal and, when authorised, register a Commitment.

        The Commitment starts in ``authorized``; the dispatcher's Phase 5
        transitions it to ``active`` once resources are allocated.  The
        ``execution_ratio`` is stashed on the commitment as
        ``_execution_ratio`` so the executor's per-tick progress uses it.
        """
        res = self.resolve(
            proposal, authority=authority, resources=resources,
            org_support=org_support, opposition=opposition,
            environment=environment,
        )
        if res.creates_commitment:
            cid = commitment_id or (
                f"commit:{proposal.actor_id}:{proposal.decision_type}:"
                f"{proposal.proposed_tick}")
            commitment = Commitment(
                commitment_id=cid,
                actor_id=proposal.actor_id,
                decision_type=proposal.decision_type,
                target_ids=list(proposal.target_ids),
                goal=proposal.goal,
                required_resources=dict(proposal.required_resources),
                allocated_resources=dict(res.consumed_resources),
                authority_source=proposal.authority_source,
                start_tick=proposal.proposed_tick,
                expected_duration=proposal.expected_duration,
                progress=0.0,
                priority=proposal.priority,
                reversibility=proposal.reversibility,
                secrecy=proposal.secrecy,
                status=CommitmentStatus.AUTHORIZED,
            )
            # stash the resolver's execution_ratio for the executor
            commitment._execution_ratio = res.execution_ratio  # type: ignore[attr-defined]
            commitment.history.append({
                "event": "created",
                "status": "authorized",
                "execution_ratio": res.execution_ratio,
                "resolution_status": res.status,
            })
            executor.register_commitment(commitment)
            res.commitment_id = cid
        return res


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _clamp01(x: float) -> float:
    try:
        x = float(x)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, x))
