"""LLM-driven cognitive-model generator (Q7 — the project's unique academic gap).

Academic positioning
====================
This module is the project's **only** contribution with no prior art:

  * Story2Game (Trivedi et al.) generates **action preconditions** from story
    text — what an agent is *allowed* to do.
  * PDDL / planning-line generators produce a **physical / dynamics model** of
    the world — what happens when an action fires.
  * BDI agent frameworks (Sabre, JAck) give you the *vocabulary* of
    belief/desire/intention but the belief model itself is hand-authored per
    domain.

**Nobody generates the epistemic structure of misprediction** — "what can the
subjects of *this* world misjudge, and what is the *shape* of that
misjudgement".  That is exactly what a world's cognitive model is (see
:mod:`backend.theater.cognitive_model`): a subject commits to a prediction
built from its (imperfect) capability, and ``model_error`` flags the
dramatic-irony gap to ground truth.

So this module asks the LLM to author, for an arbitrary world + agent role,
a :class:`CognitiveModelSpec` — a declarative description of *who* misjudges
*what* and *how*.  The spec compiles into a :class:`CognitiveModel` protocol
instance (deterministic, seed-driven, no LLM at runtime — §8.2 red line).

Pipeline (mirrors :mod:`backend.theater.gameplay_generator`):

  1. LLM emits a :class:`CognitiveModelSpec` JSON (restricted DSL).
  2. :class:`CognitiveModelValidator.validate_all` runs five hard gates.
  3. On failure → ``_repair``: feed failure reasons back to the LLM and ask
     it to rewrite (up to 2 rounds).
  4. Still failing → raise RuntimeError (LLM required — no preset fallback).

No ``eval``, no ``exec``, no ``__import__`` — the LLM only emits declarative
JSON over a tiny expression whitelist (§12.1 安全红线).  Pure stdlib; unit-
testable with stub ``llm_fn``.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .cognitive_model import Belief, CognitiveModel


__all__ = [
    "CognitiveModelSpec",
    "CognitiveModelValidator",
    "CMCheckResult",
    "CMValidationReport",
    "CognitiveModelGenerator",
    "CMGenerationResult",
    "PRESET_SPECS",
    "match_preset",
]


# ---------------------------------------------------------------------------
# Restricted expression whitelist (tiny, deterministic subset)
# ---------------------------------------------------------------------------
#
# Deliberately tiny and DETERMINISTIC — no random/采样 op.  A cognitive model
# is a pure function of (ground_truth_state, agent_capability, t); the same
# inputs MUST yield the same Belief (§8.2 red line: model_error is a
# *deterministic* misprediction, not a random fluke).

_ALLOWED_OPS = {
    "add", "sub", "mul", "div", "neg", "min", "max", "clamp", "abs",
    "lt", "gt", "eq", "le", "ge",
    "and", "or", "not",
    "if",
    "sum", "avg",
    "sigmoid",  # deterministic 1/(1+exp(-x)); the only non-piecewise curve
}

_MAX_DEPTH = 64


class _CMExprError(ValueError):
    """Raised when a cognitive-model expression AST cannot be evaluated safely."""


def _cm_lookup(path: str, state: Dict[str, Any]) -> Any:
    """Walk a dotted path through nested dicts/lists; missing → None.

    Unlike the gameplay validator (which returns 0 for missing paths), the
    cognitive-model layer returns ``None`` for unobservable variables — this
    is the subject's "I have no reading" state, distinct from a numeric 0.
    Arithmetic ops coerce ``None``→0 via :func:`_num`.
    """
    if not path:
        return None
    cur: Any = state
    for part in path.split("."):
        if isinstance(cur, dict):
            if part in cur:
                cur = cur[part]
            else:
                return None
        elif isinstance(cur, list):
            try:
                cur = cur[int(part)]
            except (ValueError, IndexError):
                return None
        else:
            return None
    return cur


def _num(x: Any) -> float:
    if isinstance(x, bool):
        return 1.0 if x else 0.0
    if isinstance(x, (int, float)):
        return float(x)
    if x is None:
        return 0.0
    raise _CMExprError(f"expected number, got {type(x).__name__}")


def _truthy(x: Any) -> bool:
    if x is None:
        return False
    if isinstance(x, bool):
        return x
    if isinstance(x, (int, float)):
        return x != 0
    return bool(x)


def _cm_eval(node: Any, state: Dict[str, Any], depth: int = 0) -> Any:
    """Evaluate a restricted-expression AST against *state*.

    Nodes:
      - scalars (int/float/bool/None) → returned as-is
      - ``{"const": v}``                → v
      - ``{"ref": "dotted.path"}``      → state lookup (None if missing)
      - ``{"op": "add", "args": [...]}``→ whitelisted operator
    """
    if depth > _MAX_DEPTH:
        raise _CMExprError(f"expression depth exceeds {_MAX_DEPTH}")
    if node is None or isinstance(node, (bool, int, float)):
        return node
    if not isinstance(node, dict):
        raise _CMExprError(f"unsupported AST node type: {type(node).__name__}")
    if "const" in node and "op" not in node:
        return node["const"]
    if "ref" in node and "op" not in node:
        return _cm_lookup(node["ref"], state)
    op = node.get("op")
    if op is None:
        raise _CMExprError("AST node missing 'op'")
    if op == "const":
        return node.get("value")
    if op == "ref":
        return _cm_lookup(node.get("path", ""), state)
    if op not in _ALLOWED_OPS:
        raise _CMExprError(f"op {op!r} not in cognitive-model whitelist")
    args = node.get("args", [])
    if not isinstance(args, list):
        raise _CMExprError(f"op {op!r} args must be a list")

    def _a(i: int) -> Any:
        return _cm_eval(args[i], state, depth + 1)

    if op == "add":
        return _num(_a(0)) + _num(_a(1))
    if op == "sub":
        return _num(_a(0)) - _num(_a(1))
    if op == "mul":
        return _num(_a(0)) * _num(_a(1))
    if op == "div":
        d = _num(_a(1))
        if d == 0:
            return 0.0
        return _num(_a(0)) / d
    if op == "neg":
        return -_num(_a(0))
    if op == "abs":
        return abs(_num(_a(0)))
    if op == "min":
        return min(_num(_a(0)), _num(_a(1)))
    if op == "max":
        return max(_num(_a(0)), _num(_a(1)))
    if op == "clamp":
        # clamp(value, lo, hi) = max(lo, min(hi, value))
        v = _num(_a(0))
        lo = _num(_a(1))
        hi = _num(_a(2))
        return max(lo, min(hi, v))
    if op == "lt":
        return _num(_a(0)) < _num(_a(1))
    if op == "gt":
        return _num(_a(0)) > _num(_a(1))
    if op == "eq":
        return _a(0) == _a(1)
    if op == "le":
        return _num(_a(0)) <= _num(_a(1))
    if op == "ge":
        return _num(_a(0)) >= _num(_a(1))
    if op == "and":
        return _truthy(_a(0)) and _truthy(_a(1))
    if op == "or":
        return _truthy(_a(0)) or _truthy(_a(1))
    if op == "not":
        return not _truthy(_a(0))
    if op == "if":
        # if(cond, then, else) — lazy: only the taken branch is evaluated.
        return _a(1) if _truthy(_a(0)) else _a(2)
    if op == "sum":
        lst = _a(0)
        if not isinstance(lst, list):
            raise _CMExprError("sum expects a list")
        return sum(_num(x) for x in lst)
    if op == "avg":
        lst = _a(0)
        if not isinstance(lst, list):
            raise _CMExprError("avg expects a list")
        if not lst:
            return 0.0
        return sum(_num(x) for x in lst) / len(lst)
    if op == "sigmoid":
        # 1 / (1 + exp(-x)); deterministic.  Clamped against overflow.
        try:
            x = _num(_a(0))
            if x >= 0:
                z = math.exp(-x)
                return 1.0 / (1.0 + z)
            z = math.exp(x)
            return z / (1.0 + z)
        except OverflowError:
            return 0.0 if _num(_a(0)) < 0 else 1.0
    # Unreachable — op checked against whitelist above.
    raise _CMExprError(f"unhandled op {op!r}")  # pragma: no cover


def _collect_ops(node: Any, acc: Optional[set] = None) -> set:
    """Walk an AST and collect every ``op`` string used (static scan)."""
    if acc is None:
        acc = set()
    if isinstance(node, dict):
        op = node.get("op")
        if isinstance(op, str):
            acc.add(op)
        for v in node.values():
            _collect_ops(v, acc)
    elif isinstance(node, list):
        for v in node:
            _collect_ops(v, acc)
    return acc


# ---------------------------------------------------------------------------
# CognitiveModelSpec — the LLM-authored product
# ---------------------------------------------------------------------------


@dataclass
class CognitiveModelSpec:
    """A declarative cognitive-model specification authored by the LLM.

    This is the *epistemic* description of a world's subjects: who they are,
    what they can observe, what they cannot, how their capability maps to
    observation accuracy, and — crucially (Q7) — **what they can misjudge
    and the structure of that misjudgement**.  It compiles into a
    :class:`CognitiveModel` protocol instance via :meth:`to_cognitive_model`.

    Attributes:
        world_schema:
            ``{"world_type", "description", "truth_variables": [...],
            "truth_structure": {var: type_hint}}``.  ``truth_variables`` is
            the *full* set of ground-truth state variables the kernel knows
            — the universe of things a subject could in principle observe.
        agent_role:
            The subject's role (scientist / merchant / noble / detective …).
        observable_variables:
            Variables the subject can directly observe (subset of
            ``truth_variables``).
        hidden_variables:
            Variables the subject cannot directly observe — the source of
            information-driven misjudgement (subset of ``truth_variables``).
        capability_to_accuracy:
            Mapping ``capability_name → human description`` of how that
            capability sharpens (or fails to sharpen) observation accuracy.
            The actual mechanics live in ``prediction_template``'s ASTs; this
            field documents the intended monotonic relationship for the
            narrator / LLM.
        failure_modes:
            **The Q7 core.**  List of ``{name, description,
            misjudged_variable, structure}`` describing what subjects in this
            world misjudge and the *shape* of the misjudgement
            (capability-gated / information-incomplete / source-biased /
            confirmation-biased).  ``misjudged_variable`` must be a known
            truth variable.
        prediction_template:
            ``{"predicted_expr", "confidence_expr", "model_error_expr",
            "committed_keys"}`` — four restricted-expression ASTs that
            compile into the :class:`CognitiveModel.predict` contract.
            ``predicted_expr`` / ``confidence_expr`` evaluate against the
            subject's view (ground_truth + capability + t);
            ``model_error_expr`` evaluates against the omniscient view
            (ground_truth + capability + t + the just-computed ``predicted``)
            — the narrator's dramatic-irony comparison, NOT the subject's.
    """

    world_schema: Dict[str, Any] = field(default_factory=dict)
    agent_role: str = ""
    observable_variables: List[str] = field(default_factory=list)
    hidden_variables: List[str] = field(default_factory=list)
    capability_to_accuracy: Dict[str, str] = field(default_factory=dict)
    failure_modes: List[Dict[str, Any]] = field(default_factory=list)
    prediction_template: Dict[str, Any] = field(default_factory=dict)

    # -- helpers ------------------------------------------------------------

    def truth_variables(self) -> List[str]:
        """The full set of ground-truth variables declared by the world."""
        tv = self.world_schema.get("truth_variables")
        if isinstance(tv, list):
            return [str(v) for v in tv]
        return []

    def world_type(self) -> str:
        return str(self.world_schema.get("world_type", "") or "")

    # -- serialization ------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {
            "world_schema": dict(self.world_schema),
            "agent_role": self.agent_role,
            "observable_variables": list(self.observable_variables),
            "hidden_variables": list(self.hidden_variables),
            "capability_to_accuracy": dict(self.capability_to_accuracy),
            "failure_modes": list(self.failure_modes),
            "prediction_template": dict(self.prediction_template),
        }

    @classmethod
    def from_dict(cls, obj: Dict[str, Any]) -> "CognitiveModelSpec":
        ws = obj.get("world_schema") or {}
        if not isinstance(ws, dict):
            ws = {}
        pt = obj.get("prediction_template") or {}
        if not isinstance(pt, dict):
            pt = {}
        return cls(
            world_schema=ws,
            agent_role=str(obj.get("agent_role", "") or ""),
            observable_variables=[str(v) for v in (obj.get("observable_variables") or [])],
            hidden_variables=[str(v) for v in (obj.get("hidden_variables") or [])],
            capability_to_accuracy={
                str(k): str(v) for k, v in (obj.get("capability_to_accuracy") or {}).items()
            },
            failure_modes=[
                e if isinstance(e, dict) else {}
                for e in (obj.get("failure_modes") or [])
            ],
            prediction_template=pt,
        )

    # -- compilation --------------------------------------------------------

    def to_cognitive_model(self) -> "_SpecCognitiveModel":
        """Compile this spec into a :class:`CognitiveModel` protocol instance.

        The compiled model is deterministic and seed-driven (§8.2 red line):
        ``predict`` is a pure function of ``(ground_truth_state,
        agent_capability, t)``.  No LLM, no randomness at runtime.
        """
        return _SpecCognitiveModel(self)


# ---------------------------------------------------------------------------
# Compiled cognitive model — implements the CognitiveModel protocol
# ---------------------------------------------------------------------------


class _SpecCognitiveModel:
    """Runtime cognitive model compiled from a :class:`CognitiveModelSpec`.

    Implements the :class:`CognitiveModel` protocol: ``predict`` builds a
    :class:`Belief` from the spec's three expression ASTs.  All expressions
    evaluate against a single eval-state dict:

      ``{**ground_truth_state, "capability": agent_capability, "t": t,
         "predicted": <computed>}``

    ``predicted_expr`` / ``confidence_expr`` model the subject's view;
    ``model_error_expr`` is the narrator's omniscient comparison (it may
    reference hidden variables + the just-computed ``predicted``).
    """

    def __init__(self, spec: CognitiveModelSpec) -> None:
        self._spec = spec

    def predict(
        self,
        ground_truth_state: Dict[str, Any],
        agent_capability: Dict[str, Any],
        t: float,
    ) -> Belief:
        tpl = self._spec.prediction_template or {}
        eval_state: Dict[str, Any] = dict(ground_truth_state or {})
        eval_state["capability"] = dict(agent_capability or {})
        try:
            eval_state["t"] = float(t)
        except (TypeError, ValueError):
            eval_state["t"] = 0.0

        # 1) predicted — the subject's committed prediction.
        predicted_raw: Any = None
        pred_node = tpl.get("predicted_expr")
        if pred_node is not None:
            try:
                predicted_raw = _cm_eval(pred_node, eval_state)
            except _CMExprError:
                predicted_raw = None
        # Coerce to Belief.predicted (Optional[float]).
        if predicted_raw is None:
            predicted: Optional[float] = None
        else:
            try:
                predicted = float(predicted_raw)
            except (TypeError, ValueError):
                predicted = None
        eval_state["predicted"] = predicted

        # 2) confidence — scalar self-assessment in [0, 1].
        confidence = 0.5
        conf_node = tpl.get("confidence_expr")
        if conf_node is not None:
            try:
                confidence = float(_cm_eval(conf_node, eval_state))
            except (_CMExprError, ValueError, TypeError):
                confidence = 0.5
        if confidence != confidence:  # NaN guard
            confidence = 0.5
        confidence = max(0.0, min(1.0, confidence))

        # 3) model_error — omniscient comparison to ground truth.
        model_error = False
        err_node = tpl.get("model_error_expr")
        if err_node is not None:
            try:
                model_error = bool(_cm_eval(err_node, eval_state))
            except _CMExprError:
                model_error = False

        # 4) committed_values — Sabre commitment: copy declared capability
        #    keys verbatim (concrete values, not a distribution).
        committed: Dict[str, float] = {}
        for k in (tpl.get("committed_keys") or []):
            if isinstance(k, str) and k in (agent_capability or {}):
                try:
                    committed[k] = float(agent_capability[k])
                except (TypeError, ValueError):
                    committed[k] = 0.0

        return Belief(
            predicted=predicted,
            confidence=confidence,
            model_error=model_error,
            committed_values=committed,
        )


# ---------------------------------------------------------------------------
# Validator — five hard gates
# ---------------------------------------------------------------------------


@dataclass
class CMCheckResult:
    """Outcome of a single cognitive-model validation check."""
    passed: bool
    reason: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CMValidationReport:
    """Aggregate report for :meth:`CognitiveModelValidator.validate_all`."""
    passed: bool
    checks: Dict[str, CMCheckResult] = field(default_factory=dict)
    reasons: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": {
                k: {"passed": v.passed, "reason": v.reason,
                    "details": v.details}
                for k, v in self.checks.items()
            },
            "reasons": list(self.reasons),
        }


class CognitiveModelValidator:
    """Five hard gates for an LLM-authored :class:`CognitiveModelSpec`.

    All checks are pure-Python over the spec's restricted DSL.  No LLM, no
    network, no eval — fully deterministic.
    """

    def __init__(self, seed: int = 42) -> None:
        self._seed = seed

    # -- sample inputs ------------------------------------------------------

    def _sample_ground_truth(self, spec: CognitiveModelSpec) -> Dict[str, Any]:
        """Build a sample ground-truth state from the declared truth vars.

        Each declared truth variable is seeded with 1.0 (a benign numeric).
        Used by the determinism and compile checks; values are arbitrary —
        only the *pure-function* property matters.
        """
        gt: Dict[str, Any] = {}
        for v in spec.truth_variables():
            gt[v] = 1.0
        return gt

    def _sample_capability(self, spec: CognitiveModelSpec) -> Dict[str, float]:
        caps: Dict[str, float] = {}
        for k in spec.capability_to_accuracy.keys():
            caps[k] = 1.0
        # Ensure committed_keys resolve even if the LLM forgot to declare them.
        for k in (spec.prediction_template.get("committed_keys") or []):
            if isinstance(k, str) and k not in caps:
                caps[k] = 1.0
        return caps

    # =====================================================================
    # CHECK 1: compiles — structure + AST well-formedness
    # =====================================================================

    def check_compiles(self, spec: CognitiveModelSpec) -> CMCheckResult:
        """Spec structure is legal and every AST uses only whitelisted ops."""
        # Required structural fields.
        if not isinstance(spec.world_schema, dict) or not spec.truth_variables():
            return CMCheckResult(
                False, "world_schema.truth_variables must be a non-empty list"
            )
        if not spec.agent_role:
            return CMCheckResult(False, "agent_role must be non-empty")
        tpl = spec.prediction_template
        if not isinstance(tpl, dict):
            return CMCheckResult(False, "prediction_template must be a dict")
        for key in ("predicted_expr", "confidence_expr", "model_error_expr"):
            node = tpl.get(key)
            if node is None:
                return CMCheckResult(False, f"prediction_template.{key} missing")
            if not isinstance(node, dict):
                return CMCheckResult(False, f"prediction_template.{key} must be an AST dict")
            ops = _collect_ops(node)
            bad = ops - _ALLOWED_OPS
            if bad:
                return CMCheckResult(
                    False,
                    f"prediction_template.{key} uses non-whitelisted ops: {sorted(bad)}",
                )
        # Dry-run: each AST evaluates without raising on a sample state.
        cm = spec.to_cognitive_model()
        try:
            gt = self._sample_ground_truth(spec)
            cap = self._sample_capability(spec)
            cm.predict(gt, cap, 1.0)
        except _CMExprError as exc:
            return CMCheckResult(False, f"expression evaluation failed: {exc}")
        except Exception as exc:  # noqa: BLE001 — defensive
            return CMCheckResult(False, f"compile dry-run crashed: {exc}")
        return CMCheckResult(True, "spec structure legal; ASTs well-formed")

    # =====================================================================
    # CHECK 2: prediction deterministic — same inputs → same Belief
    # =====================================================================

    def check_prediction_deterministic(
        self, spec: CognitiveModelSpec
    ) -> CMCheckResult:
        """``predict`` is a pure function: same inputs → same Belief, and no
        whitelisted op is non-deterministic (the whitelist has no random op
        by construction; this check confirms it empirically)."""
        # Static: whitelist contains no random/采样 op.
        for node_name in ("predicted_expr", "confidence_expr", "model_error_expr"):
            ops = _collect_ops(spec.prediction_template.get(node_name))
            if ops & {"random", "random_in_range", "sample", "rand"}:
                return CMCheckResult(
                    False,
                    f"{node_name} uses a non-deterministic op: {sorted(ops & {'random','random_in_range','sample','rand'})}",
                )
        # Empirical: three trials, each run twice, must yield equal beliefs.
        cm = spec.to_cognitive_model()
        gt_base = self._sample_ground_truth(spec)
        cap_base = self._sample_capability(spec)
        trials = [
            (gt_base, cap_base, 0.0),
            ({k: 2.5 for k in gt_base}, {k: 0.5 for k in cap_base}, 3.0),
            ({k: 0.0 for k in gt_base}, {k: 5.0 for k in cap_base}, 10.0),
        ]
        for i, (gt, cap, t) in enumerate(trials):
            try:
                b1 = cm.predict(gt, cap, t)
                b2 = cm.predict(gt, cap, t)
            except Exception as exc:  # noqa: BLE001
                return CMCheckResult(False, f"trial {i} crashed: {exc}")
            if (b1.predicted != b2.predicted
                    or abs(b1.confidence - b2.confidence) > 1e-12
                    or b1.model_error != b2.model_error):
                return CMCheckResult(
                    False,
                    f"trial {i}: identical inputs yielded different beliefs (non-deterministic)",
                )
        return CMCheckResult(True, "predict is deterministic (pure function)")

    # =====================================================================
    # CHECK 3: observable ⊆ truth全集
    # =====================================================================

    def check_observable_subset(self, spec: CognitiveModelSpec) -> CMCheckResult:
        """observable_variables (and hidden_variables) must be subsets of the
        world's declared truth_variables — the subject cannot observe things
        that do not exist in the world."""
        truth = set(spec.truth_variables())
        if not truth:
            return CMCheckResult(False, "world_schema declares no truth_variables")
        obs = set(spec.observable_variables)
        hid = set(spec.hidden_variables)
        extra_obs = obs - truth
        extra_hid = hid - truth
        if extra_obs:
            return CMCheckResult(
                False,
                f"observable_variables not in truth_variables: {sorted(extra_obs)}",
            )
        if extra_hid:
            return CMCheckResult(
                False,
                f"hidden_variables not in truth_variables: {sorted(extra_hid)}",
            )
        # A variable declared both observable AND hidden is contradictory.
        both = obs & hid
        if both:
            return CMCheckResult(
                False,
                f"variables declared both observable and hidden: {sorted(both)}",
            )
        return CMCheckResult(True, "observable/hidden subsets of truth_variables")

    # =====================================================================
    # CHECK 4: failure_modes plausible — reference real variables
    # =====================================================================

    def check_failure_modes_plausible(
        self, spec: CognitiveModelSpec
    ) -> CMCheckResult:
        """Every failure_mode's ``misjudged_variable`` must exist in the
        world's truth_variables, and each failure_mode has the required keys
        (name / description / misjudged_variable / structure).  This is the
        Q7 plausibility gate: the misjudgement must target something real."""
        if not spec.failure_modes:
            return CMCheckResult(False, "failure_modes is empty (Q7 core missing)")
        truth = set(spec.truth_variables())
        required = {"name", "description", "misjudged_variable", "structure"}
        for i, fm in enumerate(spec.failure_modes):
            if not isinstance(fm, dict):
                return CMCheckResult(False, f"failure_modes[{i}] not a dict")
            missing = required - set(fm.keys())
            if missing:
                return CMCheckResult(
                    False, f"failure_modes[{i}] missing keys: {sorted(missing)}"
                )
            mv = fm.get("misjudged_variable")
            if not isinstance(mv, str) or mv not in truth:
                return CMCheckResult(
                    False,
                    f"failure_modes[{i}].misjudged_variable {mv!r} not in truth_variables",
                )
            if not str(fm.get("structure", "")).strip():
                return CMCheckResult(
                    False, f"failure_modes[{i}].structure is empty (misjudgement shape missing)"
                )
        return CMCheckResult(True, "all failure_modes reference real variables")

    # =====================================================================
    # CHECK 5: compiles to protocol
    # =====================================================================

    def check_compiles_to_protocol(
        self, spec: CognitiveModelSpec
    ) -> CMCheckResult:
        """``to_cognitive_model()`` produces an instance satisfying the
        :class:`CognitiveModel` protocol, and ``predict`` returns a proper
        :class:`Belief` with bounded confidence."""
        try:
            cm = spec.to_cognitive_model()
        except Exception as exc:  # noqa: BLE001
            return CMCheckResult(False, f"to_cognitive_model() crashed: {exc}")
        if not isinstance(cm, CognitiveModel):
            return CMCheckResult(False, "compiled model does not satisfy CognitiveModel protocol")
        try:
            gt = self._sample_ground_truth(spec)
            cap = self._sample_capability(spec)
            belief = cm.predict(gt, cap, 1.0)
        except Exception as exc:  # noqa: BLE001
            return CMCheckResult(False, f"predict() crashed: {exc}")
        if not isinstance(belief, Belief):
            return CMCheckResult(False, "predict() did not return a Belief")
        if not (0.0 <= belief.confidence <= 1.0):
            return CMCheckResult(
                False, f"confidence out of [0,1]: {belief.confidence}"
            )
        if not isinstance(belief.model_error, bool):
            return CMCheckResult(False, "model_error is not a bool")
        return CMCheckResult(True, "compiles to a protocol-conformant CognitiveModel")

    # =====================================================================
    # AGGREGATE
    # =====================================================================

    def validate_all(self, spec: CognitiveModelSpec) -> CMValidationReport:
        """Run all five gates.  passed=True only if all pass."""
        checks = {
            "compiles": self.check_compiles(spec),
            "deterministic": self.check_prediction_deterministic(spec),
            "observable_subset": self.check_observable_subset(spec),
            "failure_modes_plausible": self.check_failure_modes_plausible(spec),
            "compiles_to_protocol": self.check_compiles_to_protocol(spec),
        }
        reasons: List[str] = []
        for name, r in checks.items():
            if not r.passed:
                reasons.append(f"{name}: {r.reason}")
        return CMValidationReport(
            passed=all(r.passed for r in checks.values()),
            checks=checks,
            reasons=reasons,
        )


# ---------------------------------------------------------------------------
# Explicit reference cognitive-model adapters
# ---------------------------------------------------------------------------


def _three_body_preset() -> CognitiveModelSpec:
    """三体: 低科技文明预测视界短于乱纪元间隔 → 误判'无乱纪元来临'。

    The canonical example (spec §8.2).  Capability-gated misjudgement: the
    subject's tech_level sets δ₀ → T_predict; when the horizon falls short
    of the next chaotic era the subject commits to "no chaos coming" even
    though the kernel knows chaos is coming — dramatic irony.
    """
    return CognitiveModelSpec(
        world_schema={
            "world_type": "three_body",
            "description": "三体世界: 恒纪元/乱纪元交替, 文明预测下一个乱纪元来临时刻",
            "truth_variables": ["next_chaos", "current_era"],
            "truth_structure": {"next_chaos": "float|null", "current_era": "stable|chaotic"},
        },
        agent_role="civilization_scientist",
        observable_variables=["current_era"],
        hidden_variables=["next_chaos"],
        capability_to_accuracy={
            "tech_level": "higher → tighter δ₀ → longer prediction horizon T_predict",
            "delta_0": "observation precision (smaller = sharper)",
            "T_predict": "prediction horizon, computed from tech_level via T=(1/λ)·ln(Δ/δ₀)",
        },
        failure_modes=[
            {
                "name": "horizon_short_misprediction",
                "description": "低科技文明的预测视界 T_predict 短于到下一个乱纪元的间隔, 主体承诺'无乱纪元来临', 与真值不符",
                "misjudged_variable": "next_chaos",
                "structure": "capability_gated: T_predict < (next_chaos - t) → predicted=null (model_error=true)",
            },
        ],
        prediction_template={
            # if no chaos → null; elif horizon reaches → next_chaos; else null (misprediction)
            "predicted_expr": {
                "op": "if", "args": [
                    {"op": "eq", "args": [{"ref": "next_chaos"}, {"const": None}]},
                    {"const": None},
                    {"op": "if", "args": [
                        {"op": "ge", "args": [
                            {"ref": "capability.T_predict"},
                            {"op": "sub", "args": [{"ref": "next_chaos"}, {"ref": "t"}]},
                        ]},
                        {"ref": "next_chaos"},
                        {"const": None},
                    ]},
                ],
            },
            # confidence: soft-saturating in tech_level, bounded away from 0/1.
            "confidence_expr": {
                "op": "clamp", "args": [
                    {"op": "div", "args": [
                        {"ref": "capability.tech_level"},
                        {"op": "add", "args": [
                            {"ref": "capability.tech_level"}, {"const": 3.0},
                        ]},
                    ]},
                    {"const": 0.05}, {"const": 0.95},
                ],
            },
            # model_error: there IS a chaos AND the subject failed to predict it.
            "model_error_expr": {
                "op": "and", "args": [
                    {"op": "not", "args": [
                        {"op": "eq", "args": [{"ref": "next_chaos"}, {"const": None}]},
                    ]},
                    {"op": "not", "args": [
                        {"op": "eq", "args": [{"ref": "predicted"}, {"ref": "next_chaos"}]},
                    ]},
                ],
            },
            "committed_keys": ["tech_level", "delta_0", "T_predict"],
        },
    )


def _economy_preset() -> CognitiveModelSpec:
    """经济: 商人只观测本地成交价, 信息不全误判全局公平价/趋势。

    Information-incomplete misjudgement: the merchant observes only the local
    last transaction price and extrapolates to the global fair price.  Low
    information_reach → more weight on the local outlier → larger error when
    the local price is unrepresentative.
    """
    return CognitiveModelSpec(
        world_schema={
            "world_type": "economy",
            "description": "市场世界: 全局公平价隐藏, 商人仅观测本地成交价并预测趋势",
            "truth_variables": ["fair_price", "trend_direction", "local_last_price"],
            "truth_structure": {
                "fair_price": "float", "trend_direction": "up|down|flat",
                "local_last_price": "float",
            },
        },
        agent_role="merchant",
        observable_variables=["local_last_price"],
        hidden_variables=["fair_price", "trend_direction"],
        capability_to_accuracy={
            "information_reach": "higher → more markets sampled → local outlier weighted less",
            "analysis_skill": "higher → better prior calibration",
        },
        failure_modes=[
            {
                "name": "local_outlier_extrapolation",
                "description": "低信息触达的商人把本地成交价当作全局公平价, 当本地是离群点时误判趋势",
                "misjudged_variable": "fair_price",
                "structure": "information_incomplete: predicted = blend(local_last_price, prior); "
                             "low information_reach → weight on local → error when local is outlier",
            },
        ],
        prediction_template={
            # predicted fair_price = 0.6*local + 0.4*prior(100).  References
            # only observable (local_last_price) + constants — the subject
            # cannot see the true fair_price.
            "predicted_expr": {
                "op": "add", "args": [
                    {"op": "mul", "args": [{"const": 0.6}, {"ref": "local_last_price"}]},
                    {"op": "mul", "args": [{"const": 0.4}, {"const": 100.0}]},
                ],
            },
            "confidence_expr": {
                "op": "clamp", "args": [
                    {"op": "div", "args": [
                        {"ref": "capability.information_reach"},
                        {"op": "add", "args": [
                            {"ref": "capability.information_reach"}, {"const": 2.0},
                        ]},
                    ]},
                    {"const": 0.05}, {"const": 0.95},
                ],
            },
            # model_error (omniscient): |predicted - fair_price| > 8.
            "model_error_expr": {
                "op": "gt", "args": [
                    {"op": "abs", "args": [
                        {"op": "sub", "args": [{"ref": "predicted"}, {"ref": "fair_price"}]},
                    ]},
                    {"const": 8.0},
                ],
            },
            "committed_keys": ["information_reach", "analysis_skill"],
        },
    )


def _politics_preset() -> CognitiveModelSpec:
    """政治: 贵族只听信信任源, 误判真实权力格局。

    Source-biased misjudgement: the noble observes the *stated* positions of
    two factions but trusts source A over B (trust_network_bias).  When A is
    bluffing, the noble's predicted power_balance diverges from truth.
    """
    return CognitiveModelSpec(
        world_schema={
            "world_type": "politics",
            "description": "朝堂世界: 真实权力格局隐藏, 贵族仅观测各派公开表态并预测权力归属",
            "truth_variables": ["power_balance", "stated_position_A", "stated_position_B"],
            "truth_structure": {
                "power_balance": "float in [0,1]",
                "stated_position_A": "float", "stated_position_B": "float",
            },
        },
        agent_role="noble",
        observable_variables=["stated_position_A", "stated_position_B"],
        hidden_variables=["power_balance"],
        capability_to_accuracy={
            "trust_network_bias": "higher → more weight on source A's stated position",
            "intelligence_skill": "higher → better at detecting bluffs",
        },
        failure_modes=[
            {
                "name": "trusted_source_bluff",
                "description": "高信任偏置的贵族把 A 派公开表态当作真实权力格局, 当 A 在虚张声势时误判局势",
                "misjudged_variable": "power_balance",
                "structure": "source_biased: predicted = weighted_avg(stated_A, stated_B) by trust; "
                             "high trust_network_bias → over-trust A → error when A bluffs",
            },
        ],
        prediction_template={
            # predicted power_balance = weighted avg of stated positions by
            # trust_network_bias (w in [0,1] toward A).
            "predicted_expr": {
                "op": "add", "args": [
                    {"op": "mul", "args": [
                        {"op": "clamp", "args": [
                            {"ref": "capability.trust_network_bias"},
                            {"const": 0.0}, {"const": 1.0},
                        ]},
                        {"ref": "stated_position_A"},
                    ]},
                    {"op": "mul", "args": [
                        {"op": "sub", "args": [
                            {"const": 1.0},
                            {"op": "clamp", "args": [
                                {"ref": "capability.trust_network_bias"},
                                {"const": 0.0}, {"const": 1.0},
                            ]},
                        ]},
                        {"ref": "stated_position_B"},
                    ]},
                ],
            },
            "confidence_expr": {
                "op": "clamp", "args": [
                    {"op": "div", "args": [
                        {"ref": "capability.intelligence_skill"},
                        {"op": "add", "args": [
                            {"ref": "capability.intelligence_skill"}, {"const": 2.0},
                        ]},
                    ]},
                    {"const": 0.05}, {"const": 0.95},
                ],
            },
            # model_error (omniscient): |predicted - power_balance| > 0.15.
            "model_error_expr": {
                "op": "gt", "args": [
                    {"op": "abs", "args": [
                        {"op": "sub", "args": [{"ref": "predicted"}, {"ref": "power_balance"}]},
                    ]},
                    {"const": 0.15},
                ],
            },
            "committed_keys": ["trust_network_bias", "intelligence_skill"],
        },
    )


PRESET_SPECS: Dict[str, CognitiveModelSpec] = {
    "three_body": _three_body_preset(),
    "economy": _economy_preset(),
    "politics": _politics_preset(),
}


def match_preset(
    preset_id: str, agent_role: str = "",
) -> CognitiveModelSpec:
    """Return a fresh reference adapter selected by its exact identifier.

    The legacy function name is retained for API compatibility, but prose and
    ``agent_role`` are never inspected. Generic generation does not call this
    helper; callers must explicitly pass one of ``PRESET_SPECS``' keys.
    """
    del agent_role
    key = str(preset_id or "").strip()
    if key not in PRESET_SPECS:
        raise ValueError(
            f"unknown preset_id {key!r}; expected one of "
            f"{', '.join(sorted(PRESET_SPECS))}"
        )
    return CognitiveModelSpec.from_dict(PRESET_SPECS[key].to_dict())


# ---------------------------------------------------------------------------
# LLM system prompt + few-shot
# ---------------------------------------------------------------------------


_SYSTEM_PROMPT = """You are a cognitive-model compiler for a deterministic world-simulation engine.

Your job is the project's UNIQUE academic contribution (Q7): given a world and
an agent role, author the EPISTEMIC STRUCTURE OF MISJUDGEMENT — what can the
subjects of this world misjudge, and what is the *shape* of that misjudgement.

This is NOT action-precondition generation (Story2Game) and NOT a physics
model (PDDL).  You generate the *cognitive* layer: a subject commits to a
prediction built from its (imperfect) capability; when that prediction
disagrees with the kernel's ground truth, that is dramatic irony (model_error).

Your output is a single JSON object — no prose, no markdown fences.

OUTPUT SCHEMA:
{
  "world_schema": {
    "world_type": "snake_case_id",
    "description": "one-line world summary",
    "truth_variables": ["v1", "v2", ...],
    "truth_structure": {"v1": "type_hint", ...}
  },
  "agent_role": "scientist|merchant|noble|detective|...",
  "observable_variables": ["..."],   // subset of truth_variables
  "hidden_variables":   ["..."],     // subset of truth_variables; source of error
  "capability_to_accuracy": {"cap_name": "how it sharpens observation"},
  "failure_modes": [
    {
      "name": "snake_case_id",
      "description": "what the subject misjudges",
      "misjudged_variable": "a truth_variable name",
      "structure": "capability_gated | information_incomplete | source_biased | confirmation_biased: ..."
    }
  ],
  "prediction_template": {
    "predicted_expr":    <AST>,
    "confidence_expr":   <AST in [0,1]>,
    "model_error_expr":  <AST → bool, omniscient comparison to ground truth>,
    "committed_keys":    ["cap_name", ...]
  }
}

EXPRESSION AST — op WHITELIST ONLY (deterministic, NO random):
  add, sub, mul, div, neg, abs, min, max, clamp,
  lt, gt, eq, le, ge,
  and, or, not,
  if,
  sum, avg,
  sigmoid
Leaves:
  {"const": <number|bool|null>}
  {"ref": "dotted.path"}     // walks nested dicts; missing → null

EVAL STATE available to ASTs (a single merged dict):
  - every truth_variable by name (e.g. {"ref": "next_chaos"})
  - {"ref": "capability.<cap_name>"}   // agent capability
  - {"ref": "t"}                        // current time
  - {"ref": "predicted"}               // ONLY in model_error_expr: the
                                        //   just-computed prediction, for
                                        //   omniscient comparison

SEMANTICS (critical):
  - predicted_expr / confidence_expr model the SUBJECT's view.  They may use
    observables + capability + t.  They may reference a hidden truth variable
    ONLY when the subject's prediction model *computes* it (e.g. a scientist
    predicts the next chaos time from physics within their horizon).
  - model_error_expr is the NARRATOR's omniscient comparison: it compares
    {"ref": "predicted"} against ground-truth hidden variables and returns
    True when the subject misjudged.  It MUST be deterministic.
  - confidence_expr must stay in [0, 1] (use clamp).
  - null handling: {"const": null} is valid; eq(ref, {"const": null}) tests
    "variable is unknown/None".

HARD RULES:
  1. Output ONLY the JSON object.
  2. Every AST uses ONLY whitelisted ops.  No eval/exec/import/lambdas.
  3. observable_variables ∪ hidden_variables ⊆ truth_variables; a variable
     must not be both observable and hidden.
  4. failure_modes MUST be non-empty; each misjudged_variable must be a
     declared truth_variable.  The "structure" field is the Q7 core — name
     the misjudgement shape (capability_gated / information_incomplete /
     source_biased / confirmation_biased).
  5. The prediction must be DETERMINISTIC: identical inputs → identical
     output.  No random ops, no time-of-day reads, no external state.
  6. confidence_expr must evaluate to [0, 1] for any capability values.
"""


# ---------------------------------------------------------------------------
# CMGenerationResult
# ---------------------------------------------------------------------------


class CMGenerationResult:
    """Bundle returned by :meth:`CognitiveModelGenerator.generate`.

    Attributes:
        spec:         the final CognitiveModelSpec (LLM-authored, possibly after
                      repair rounds).
        source:       ``"llm"`` (the only source — no fallback path).
        validation:   the final :class:`CMValidationReport` or None.
        repairs:      number of repair rounds run (0 if first-pass ok).
        llm_messages: diagnostics from the LLM client.
    """

    def __init__(
        self,
        spec: CognitiveModelSpec,
        source: str,
        validation: Optional[CMValidationReport] = None,
        repairs: int = 0,
        llm_messages: Optional[List[str]] = None,
    ) -> None:
        self.spec = spec
        self.source = source
        self.validation = validation
        self.repairs = repairs
        self.llm_messages = list(llm_messages or [])

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": True,
            "spec": self.spec.to_dict(),
            "source": self.source,
            "validation": self.validation.to_dict() if self.validation else None,
            "repairs": self.repairs,
            "llm_messages": self.llm_messages,
        }


# ---------------------------------------------------------------------------
# CognitiveModelGenerator
# ---------------------------------------------------------------------------


class CognitiveModelGenerator:
    """Generate a validated :class:`CognitiveModelSpec` for an arbitrary world.

    Parameters:
        max_repairs:  max number of repair rounds (default 2).
        model_label:  human-readable LLM label (diagnostics only).
    """

    def __init__(
        self,
        *,
        max_repairs: int = 2,
        model_label: str = "cognitive-model-llm",
    ) -> None:
        self._max_repairs = max_repairs
        self._validator = CognitiveModelValidator()
        self._model_label = model_label

    # -- main entry ---------------------------------------------------------

    def generate(
        self,
        world_description: str,
        agent_role: str = "",
        llm_fn: Optional[Callable[[str], str]] = None,
    ) -> Tuple[CognitiveModelSpec, CMGenerationResult]:
        """Generate a :class:`CognitiveModelSpec`.

        If *llm_fn* is provided, it is called as ``llm_fn(prompt) -> str``
        (single-arg; the system prompt is folded into *prompt*).  The raw
        output is parsed as JSON, validated, and (if invalid) repaired up to
        ``max_repairs`` rounds.  Still-invalid → raises RuntimeError.

        If *llm_fn* is None → raises RuntimeError (LLM is required).

        Returns ``(spec, result)`` where ``result.source`` is ``"llm"``.
        """
        world_description = (world_description or "").strip()
        agent_role = (agent_role or "").strip()
        if llm_fn is None:
            raise RuntimeError(
                "CognitiveModelGenerator requires llm_fn (LLM) to generate a cognitive model. "
                "No LLM configured — cannot proceed."
            )

        user_prompt = self._build_user_prompt(world_description, agent_role)
        repairs = 0
        feedback: List[str] = []
        last_spec: Optional[CognitiveModelSpec] = None
        last_report: Optional[CMValidationReport] = None

        for attempt in range(self._max_repairs + 1):
            raw = llm_fn(f"{_SYSTEM_PROMPT}\n\n{user_prompt}")
            spec = self._parse_llm_output(raw)
            if spec is None:
                feedback.append(
                    f"round {attempt}: LLM output not parseable as CognitiveModelSpec JSON"
                )
                user_prompt = self._build_repair_prompt(
                    world_description, agent_role, feedback
                )
                repairs += 1
                continue
            last_spec = spec
            report = self._validator.validate_all(spec)
            last_report = report
            if report.passed:
                return spec, CMGenerationResult(
                    spec=spec, source="llm",
                    validation=report, repairs=repairs,
                )
            feedback.append(
                f"round {attempt}: validation failed — " + "; ".join(report.reasons)
            )
            if attempt < self._max_repairs:
                user_prompt = self._build_repair_prompt(
                    world_description, agent_role, feedback
                )
                repairs += 1

        # LLM path exhausted — all repair rounds consumed.
        reasons = [f"round {i}: {f}" for i, f in enumerate(feedback)]
        raise RuntimeError(
            f"CognitiveModelGenerator: LLM failed to produce a valid spec after "
            f"{repairs} repair round(s).\n" + "\n".join(reasons)
        )

    # -- prompt building ----------------------------------------------------

    def _build_user_prompt(self, world_description: str, agent_role: str) -> str:
        role_line = f"\nAgent role: {agent_role}\n" if agent_role else ""
        return (
            f"Author the cognitive-model JSON for this world:{role_line}\n"
            f"{world_description}\n\n"
            f"Focus on Q7: what can this world's subjects misjudge, and what "
            f"is the structure of that misjudgement?  Return ONLY the JSON "
            f"object. Derive every semantic field from this request; do not "
            f"copy or select a built-in world, genre, or reference adapter."
        )

    def _build_repair_prompt(
        self, world_description: str, agent_role: str, feedback: List[str]
    ) -> str:
        role_line = f"\nAgent role: {agent_role}\n" if agent_role else ""
        feedback_block = "\n".join(f"- {f}" for f in feedback)
        return (
            f"Your previous cognitive-model JSON failed validation.  Rewrite it."
            f"{role_line}\n"
            f"Original request:\n{world_description}\n\n"
            f"Validation failures:\n{feedback_block}\n\n"
            f"Fix the schema, the observable/hidden subsets, the failure_modes' "
            f"misjudged_variable, and the AST op whitelist.  Ensure "
            f"prediction is deterministic and confidence ∈ [0,1].  Return ONLY "
            f"the JSON object."
        )

    # -- LLM output parsing -------------------------------------------------

    def _parse_llm_output(self, raw: str) -> Optional[CognitiveModelSpec]:
        """Parse raw LLM text into a CognitiveModelSpec.  Tolerant of fences."""
        text = (raw or "").strip()
        if not text:
            return None
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```\s*$", "", text)
        obj: Any = None
        try:
            obj = json.loads(text)
        except json.JSONDecodeError:
            start = text.find("{")
            end = text.rfind("}")
            if start == -1 or end == -1 or end <= start:
                return None
            try:
                obj = json.loads(text[start: end + 1])
            except json.JSONDecodeError:
                return None
        if not isinstance(obj, dict):
            return None
        if not obj.get("world_schema") or not obj.get("prediction_template"):
            return None
        return CognitiveModelSpec.from_dict(obj)

# ---------------------------------------------------------------------------
# Convenience entry point (mirrors onboarding_llm.generate_world_rules)
# ---------------------------------------------------------------------------


def generate_cognitive_model(
    world_description: str,
    agent_role: str = "",
    llm_fn: Optional[Callable[[str], str]] = None,
    *,
    model_label: str = "openai-llm",
) -> Tuple[CognitiveModelSpec, Dict[str, Any]]:
    """Generate a :class:`CognitiveModelSpec` for *world_description*.

    ``llm_fn`` is required.  The generator validates + repairs up to 2 rounds.
    Raises RuntimeError if the LLM cannot produce a valid spec.

    Returns ``(spec, meta)`` where ``meta`` records ``source`` (always
    ``"llm"``), ``model_label``, ``repairs``, and the validation report.
    """
    generator = CognitiveModelGenerator(model_label=model_label)
    spec, result = generator.generate(
        world_description, agent_role=agent_role, llm_fn=llm_fn,
    )
    meta: Dict[str, Any] = {
        "source": "llm",
        "model_label": model_label,
        "repairs": result.repairs,
        "world_type": spec.world_type(),
        "agent_role": spec.agent_role,
        "failure_modes": len(spec.failure_modes),
        "validation": result.validation.to_dict() if result.validation else None,
        "llm_messages": result.llm_messages,
    }
    return spec, meta
