"""LLM-required onboarding orchestrator for the user-facing creation flow.

This is the last step of the user-flow spec:

    世界创造 → 角色创造 → 本地编程LLM编写规则+GUI → 开始叙事

Stages 1–4 already exist as standalone modules; this file sequences them,
requires valid model output at every requested generation step, and reports a
structured result.  It never substitutes a preset or an offline skeleton when
the model is unavailable or returns invalid data.

Stage 1 — World creation (world_creation.WorldCreator)
Stage 2 — Character creation (dispatcher.TheaterOrchestrator.create_character)
          / card import (world_import.WorldImporter)
Stage 3 — Rules + GUI (onboarding_llm.generate_world_rules / generate_world_gui)
          compiled via world_kernel_host.RuleCompiler
Stage 4 — Gameplay (gameplay_generator.GameplayGenerator); the LLM authors a
          GameplaySpec, which must pass the four hard gates before persistence.
Stage 5 — Narrative handoff (world_id + baked preview + ready flag)

Each stage also exposes propose+confirm methods so a caller can step through
one stage at a time with user editing in between:

    propose_world(description)     → draft WorldProposal dict
    confirm_world(description, edited_params) → world_id
    propose_characters(world_id, description, mode) → [character cards]
    confirm_characters(world_id, edited_characters) → result
    propose_rules_gui(world_id, description) → {rules, gui} draft
    confirm_rules_gui(world_id, edited_rules, edited_gui) → result
    propose_gameplay(world_id, description) → gameplay draft
    confirm_gameplay(world_id, edited_gameplay) → result
    finalize(world_id) → narrative handoff / ready

Public surface:
    OnboardingFlow(orchestrator=None, state_root=None, llm_client=None)
        .run(description, *, characters=None, worldbook=None,
             character_cards=None, use_llm=True, mode="auto",
             gameplay=None) -> dict
"""

from __future__ import annotations

import json
import re
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from .gui_generator import GUIGenerator, GUISpec, validate_gui_spec
from .onboarding_llm import (
    build_llm,
    generate_world_gui,
    generate_world_rules,
)
from .world_creation import WorldCreator, WorldProposal
from .world_kernel_host import RuleCompiler


__all__ = ["OnboardingFlow", "load_gui_spec", "persist_gui_spec"]


def _slugify(name: str) -> str:
    """Filesystem-safe world_id from a human description (mirrors worldforge.py)."""
    slug = re.sub(r"[\\/:*?\"<>|\s]+", "_", (name or "").strip())
    return slug or "world"


def _gui_spec_file(state_root: Path, world_id: str) -> Path:
    """Return the namespaced GUI artifact path for a world."""
    safe_world_id = _slugify(world_id)
    return Path(state_root) / "gui_specs" / f"{safe_world_id}.json"


def persist_gui_spec(state_root: Path, world_id: str, spec: GUISpec) -> Path:
    """Validate and atomically persist the GUI selected during onboarding."""
    validate_gui_spec(spec)
    spec.world_id = world_id
    path = _gui_spec_file(state_root, world_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(".json.tmp")
    temp_path.write_text(
        json.dumps(spec.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temp_path.replace(path)
    return path


def load_gui_spec(state_root: Path, world_id: str) -> Optional[GUISpec]:
    """Load a previously confirmed GUI, returning ``None`` if unavailable."""
    path = _gui_spec_file(state_root, world_id)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        from .gui_generator import _coerce_spec, _normalize_gui_spec
        spec = _coerce_spec(
            _normalize_gui_spec(dict(raw), "persisted"),
            "persisted",
        )
        spec.world_id = world_id
        validate_gui_spec(spec)
        return spec
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


class OnboardingFlow:
    """Sequence the LLM-authored onboarding stages.

    Parameters
    ----------
    orchestrator : TheaterOrchestrator | None
        Used for character creation + worldbook/card import + world switching.
        If ``None``, a deterministic offline orchestrator is built on first
        use (same shape as ``worldforge._build_orchestrator``).
    state_root : Path | None
        Where :meth:`WorldCreator.create` writes the world state file. Defaults
        to ``orchestrator._state_root`` (or ``data/runtime`` for a fresh
        offline orchestrator).
    llm_client : object | None
        Anything exposing ``as_text_fn()`` / ``as_dict_fn()`` (an
        :class:`OpenAILLMClient`). If ``None``, one is built via
        :func:`build_llm`. If no LLM is configured, creation stops with an
        explicit ``llm_required`` error.
    """

    def __init__(
        self,
        orchestrator: Optional[Any] = None,
        state_root: Optional[Path] = None,
        llm_client: Optional[Any] = None,
    ) -> None:
        self._orchestrator = orchestrator
        self._llm_client = llm_client
        if state_root is not None:
            self.state_root = Path(state_root)
        elif orchestrator is not None and getattr(orchestrator, "_state_root", None) is not None:
            self.state_root = Path(orchestrator._state_root)
        else:
            self.state_root = Path("data") / "runtime"
        self.state_root.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # lazy orchestrator (configured OpenAI-compatible LLM runtime)
    # ------------------------------------------------------------------
    @property
    def orchestrator(self) -> Any:
        if self._orchestrator is None:
            self._orchestrator = self._build_orchestrator()
        return self._orchestrator

    def _build_orchestrator(self) -> Any:
        from dataclasses import replace

        from .agents import OpenAICompatibleClient
        from .dispatcher import TheaterOrchestrator
        from .settings import Settings
        from .storage import JsonStateStore

        settings = replace(Settings.from_env(), data_dir=self.state_root)
        orch = TheaterOrchestrator(
            state_store=JsonStateStore(self.state_root, world_id="main"),
            model_client=OpenAICompatibleClient(settings),
            settings=settings,
        )
        return orch

    def _world_authoring_context(
        self,
        world_id: str,
        user_description: str,
    ) -> str:
        """Return bounded persisted context for later LLM authoring stages."""
        store = self.orchestrator._world_store(world_id)
        with store._lock:
            raw = store._load_raw()
        meta = raw.get("_meta") if isinstance(raw.get("_meta"), dict) else {}
        payload = {
            "world_id": world_id,
            "world_params": dict(meta.get("world_params") or {}),
            "confirmed_characters": list(raw.get("characters") or [])[:12],
            "confirmed_worldbook": list(raw.get("worldbook") or [])[-12:],
        }
        description = " ".join((user_description or "").split())
        return (
            (f"用户构想：{description}\n" if description else "")
            + "已确认的当前世界上下文（后续内容必须与其一致）：\n"
            + json.dumps(payload, ensure_ascii=False)[:14000]
        )

    @contextmanager
    def _temporary_world(self, world_id: str):
        """Bind writes to one world without activating it for other clients."""
        with self.orchestrator.world_scope(world_id):
            yield

    # ------------------------------------------------------------------
    # main entry (backward-compatible one-shot)
    # ------------------------------------------------------------------
    def run(
        self,
        description: str,
        *,
        characters: Optional[List[Any]] = None,
        worldbook: Optional[Any] = None,
        character_cards: Optional[List[Any]] = None,
        use_llm: bool = True,
        mode: str = "auto",
        gameplay: Optional[Dict[str, Any]] = None,
        cognitive_model: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Run all 5 LLM-backed stages.

        North-star default (一句话 → Progressing World): when ``characters``
        is ``None`` (caller did not pass a list), the LLM generates one or more
        editable character cards from the world description.  ``use_llm=False``
        is rejected: world creation has no offline or preset fallback.

        ``gameplay`` may override the stage-4 prompt with
        ``{description, use_llm?, mode?}``. When omitted, the world
        description is used and a gameplay spec is still generated by the
        LLM.

        ``cognitive_model`` is an optional dict ``{agent_role?, use_llm?}``
        for an optional cognitive-model generation stage (Q7).  When ``None``
        the stage is skipped.  The world description is reused as the world
        description; ``agent_role`` defaults to the flow's mode.

        Returns ``{ok, world_id, stages:{world, characters, rules, gui,
        gameplay, cognitive_model?, narrative}, warnings}``.
        """
        warnings: List[str] = []
        stages: Dict[str, Any] = {}

        if not use_llm:
            return {
                "ok": False,
                "world_id": "",
                "stages": stages,
                "warnings": [],
                "error_code": "llm_required",
                "error": "Onboarding requires LLM; use_llm=False is unsupported.",
            }
        llm_client, llm_message = self._resolve_llm_client()
        if llm_client is None:
            return {
                "ok": False,
                "world_id": "",
                "stages": stages,
                "warnings": [],
                "error_code": "llm_required",
                "error": llm_message or "Onboarding requires a configured LLM.",
            }
        self._llm_client = llm_client

        # ---- Stage 1: world creation / worldbook import ------------------
        world_info, world_warnings = self._stage_world(description, worldbook)
        stages["world"] = world_info
        warnings.extend(world_warnings)
        world_id = world_info.get("world_id", "")
        if not world_info.get("ok"):
            return {
                "ok": False,
                "world_id": "",
                "stages": stages,
                "warnings": warnings,
                "error_code": "world_generation_failed",
                "error": world_info.get("error") or "world generation failed",
            }

        # ---- Stage 2: characters -----------------------------------------
        if characters is None and not character_cards:
            character_proposal = self.propose_characters(
                world_id, description, mode,
            )
            if not character_proposal.get("ok"):
                stages["characters"] = character_proposal
                return {
                    "ok": False,
                    "world_id": world_id,
                    "stages": stages,
                    "warnings": warnings,
                    "error_code": "character_generation_failed",
                    "error": character_proposal.get("error")
                    or "character generation failed",
                }
            character_confirmation = self.confirm_characters(
                world_id, character_proposal["draft"],
            )
            if not character_confirmation.get("ok"):
                stages["characters"] = character_confirmation
                return {
                    "ok": False,
                    "world_id": world_id,
                    "stages": stages,
                    "warnings": warnings,
                    "error_code": "character_confirmation_failed",
                    "error": character_confirmation.get("error")
                    or "character confirmation failed",
                }
            char_info = character_confirmation.get("characters", [])
            char_warnings = list(character_confirmation.get("warnings") or [])
        else:
            char_info, char_warnings = self._stage_characters(
                world_id, characters, character_cards, mode,
            )
        stages["characters"] = char_info
        warnings.extend(char_warnings)

        # ---- Stage 3: rules + GUI ----------------------------------------
        rules_info, gui_info, stage3_warnings = self._stage_rules_gui(
            description, world_id, use_llm,
        )
        stages["rules"] = rules_info
        stages["gui"] = gui_info
        warnings.extend(stage3_warnings)
        if not rules_info.get("ok") or not gui_info.get("ok"):
            return {
                "ok": False,
                "world_id": world_id,
                "stages": stages,
                "warnings": warnings,
                "error_code": "rules_gui_generation_failed",
                "error": (
                    rules_info.get("error")
                    or gui_info.get("error")
                    or "rules/GUI generation failed"
                ),
            }

        # ---- Stage 4: gameplay (optional) ---------------------------------
        gameplay_info, gameplay_warnings = self._stage_gameplay(
            world_id, description, gameplay, use_llm,
        )
        stages["gameplay"] = gameplay_info
        warnings.extend(gameplay_warnings)
        if not gameplay_info.get("ok"):
            return {
                "ok": False,
                "world_id": world_id,
                "stages": stages,
                "warnings": warnings,
                "error_code": "gameplay_generation_failed",
                "error": gameplay_info.get("error")
                or "gameplay generation failed",
            }

        # ---- Stage 4b: cognitive model (optional, Q7) ---------------------
        cm_info, cm_warnings = self._stage_cognitive_model(
            world_id, description, cognitive_model, use_llm,
        )
        stages["cognitive_model"] = cm_info
        warnings.extend(cm_warnings)
        if cognitive_model and not cm_info.get("ok"):
            return {
                "ok": False,
                "world_id": world_id,
                "stages": stages,
                "warnings": warnings,
                "error_code": "cognitive_model_generation_failed",
                "error": cm_info.get("error")
                or "cognitive model generation failed",
            }

        # ---- Stage 5: narrative handoff (张力7: 姿态切换) ------------------
        # The onboarding flow is the boundary between the two project phases
        # (生成 → 模拟). Stage 5 marks the explicit stance switch: creation is
        # over, the user is now a guest in a world whose rules are enacted, not
        # edited. Each compiled rule set carries a §10.1 constraint-type label
        # so the simulation knows which rules may evolve (content) vs. which
        # are constitutive (§I7, fork-only).
        rules_info = stages.get("rules") or {}
        world_type = rules_info.get("world_type") or ""
        from .world_kernel_host import classify_constraint_type
        constraint_type = classify_constraint_type(
            world_type, rules_info.get("constraint_type"),
        )
        stages["narrative"] = {
            "ready": bool(world_id),
            "world_id": world_id,
            "preview": world_info.get("preview"),
            # 姿态切换: creation is done, the user is now a guest (§10.4 fork).
            "stance": "guest",
            "stance_message": (
                "世界已成，你现在是客人。规则已颁布，将以世界法则运行；"
                "想改规则请 fork 新宇宙，而非 mutate 当前世界。"
            ),
            # §10.1 constraint type of the compiled rules — drives which rules
            # may evolve at runtime (constitutive = never; content = evolves).
            "constraint_type": constraint_type,
        }

        return {
            "ok": bool(world_id),
            "world_id": world_id,
            "stages": stages,
            "warnings": warnings,
            "degraded": False,
        }

    # ==================================================================
    # Per-stage propose + confirm  (user-editable each step)
    # ==================================================================

    # ------------------------------------------------------------------
    # Stage 1 — world propose + confirm
    # ------------------------------------------------------------------
    def propose_world(self, description: str) -> Dict[str, Any]:
        """LLM-generated world parameter draft (editable by user).

        The LLM creates world_type / seed / lambda / initial_state from
        scratch.  Its response is never allowed to select a built-in kernel,
        adapter, or preset.  A configured LLM and valid structured output are
        mandatory; this stage never substitutes a fallback world.
        """
        try:
            clean_description = " ".join((description or "").split())
            llm_client, llm_message = self._resolve_llm_client()
            if llm_client is None:
                return {
                    "ok": False,
                    "error_code": "llm_required",
                    "error": llm_message or "世界创建必须配置可用 LLM。",
                }

            fn = llm_client.as_dict_fn(temperature=0.3, max_tokens=2048)
            prompt = (
                "你是世界设计架构师。根据世界观描述，从零生成世界参数 JSON。\n"
                "输出 JSON: {\"world_type\": \"string\", \"seed\": int, "
                "\"lambda\": float, \"initial_state\": {}}\n"
                "world_type 是本次生成的稳定机器标识；不要套用预置世界类型。\n"
                "seed 是随机种子（整数）。lambda 是 0-1 的动态敏感度。\n"
                "initial_state 是根据本次世界生成的非空初始状态对象。\n"
                "不得选择或引用任何内置世界、预设、kernel、adapter；"
                "所有内容必须仅从本次描述现场生成。\n"
                f"世界观描述: {clean_description or '请自由构思一个全新的世界'}\n"
                "只输出 JSON。"
            )
            result = fn(prompt)
            if not isinstance(result, dict):
                raise ValueError("模型必须返回世界参数 JSON 对象")
            world_params: Dict[str, Any] = dict(result)

            # A model-produced routing hint must never make the generic create
            # path activate a built-in setting or adapter.  Explicit adapters
            # have their own entry points outside onboarding.
            for routing_key in (
                "enabled_kernels",
                "kernel",
                "kernel_id",
                "preset",
                "preset_id",
                "adapter",
                "adapter_id",
            ):
                world_params.pop(routing_key, None)

            missing = [
                key for key in ("world_type", "seed", "lambda", "initial_state")
                if key not in world_params
            ]
            if missing:
                raise ValueError(
                    "模型世界草案缺少必填字段: " + ", ".join(missing)
                )
            if not str(world_params["world_type"]).strip():
                raise ValueError("模型世界草案的 world_type 不能为空")
            if not isinstance(world_params["seed"], int):
                raise ValueError("模型世界草案的 seed 必须是整数")
            if not isinstance(world_params["lambda"], (int, float)):
                raise ValueError("模型世界草案的 lambda 必须是数字")
            if (
                not isinstance(world_params["initial_state"], dict)
                or not world_params["initial_state"]
            ):
                raise ValueError("模型世界草案的 initial_state 必须是非空对象")

            world_id = _slugify(
                clean_description or str(world_params["world_type"]),
            )
            preview_text = self._llm_preview(clean_description, world_params)
            return {
                "ok": True,
                "source": "llm",
                "degraded": False,
                "warnings": [],
                "draft": {
                    "world_id": world_id,
                    "world_type": world_params["world_type"],
                    "seed": world_params["seed"],
                    "lambda": world_params["lambda"],
                    "initial_state": world_params["initial_state"],
                    "world_params": world_params,
                    "npcs": [],
                    "opening_scene": "",
                    "gui_hint": "",
                },
                "preview": {
                    "summary_text": preview_text,
                },
            }
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def _llm_preview(self, description: str, world_params: Dict[str, Any]) -> str:
        """Return a cheap, deterministic preview without another LLM round-trip.

        World parameters, characters, rules, and GUI already have dedicated
        generation calls. A cosmetic summary must not double a stage's latency
        or infer a preferred worldview.
        """
        clean = " ".join((description or "").split())
        if clean:
            return f"世界：{clean[:80]}"
        world_type = str(world_params.get("world_type") or "").strip()
        return f"世界类型：{world_type}" if world_type else "世界草案已生成"

    def confirm_world(self, description: str, edited_params: Dict[str, Any]) -> Dict[str, Any]:
        """User-edited world params → create world on disk, return world_id.

        ``edited_params`` should contain the WorldProposal fields
        (world_id, world_params, npcs, opening_scene, gui_hint).
        """
        try:
            if not isinstance(edited_params, dict):
                raise ValueError("edited_params must be a world draft object")
            world_params = edited_params.get("world_params")
            if not isinstance(world_params, dict):
                raise ValueError(
                    "world_params is required; first generate a draft with the LLM"
                )
            for routing_key in (
                "enabled_kernels",
                "kernel",
                "kernel_id",
                "preset",
                "preset_id",
                "adapter",
                "adapter_id",
            ):
                if routing_key in world_params:
                    raise ValueError(
                        f"generic onboarding cannot select {routing_key}"
                    )
            missing = [
                key for key in ("world_type", "seed", "lambda", "initial_state")
                if key not in world_params
            ]
            if missing:
                raise ValueError(
                    "world draft is missing required LLM fields: "
                    + ", ".join(missing)
                )
            if not str(world_params["world_type"]).strip():
                raise ValueError("world_type must not be empty")
            if (
                isinstance(world_params["seed"], bool)
                or not isinstance(world_params["seed"], int)
            ):
                raise ValueError("seed must be an integer")
            if (
                isinstance(world_params["lambda"], bool)
                or not isinstance(world_params["lambda"], (int, float))
            ):
                raise ValueError("lambda must be a number")
            if not 0 <= float(world_params["lambda"]) <= 1:
                raise ValueError("lambda must be between 0 and 1")
            if (
                not isinstance(world_params["initial_state"], dict)
                or not world_params["initial_state"]
            ):
                raise ValueError("initial_state must be a non-empty object")
            proposal = WorldProposal(
                world_id=str(
                    edited_params.get("world_id")
                    or _slugify(str(world_params["world_type"]) or description)
                ),
                world_params=dict(world_params),
                npcs=list(edited_params.get("npcs") or []),
                opening_scene=str(edited_params.get("opening_scene") or ""),
                gui_hint=str(edited_params.get("gui_hint") or ""),
            )
            world_id = WorldCreator.create(proposal, self.state_root)
            preview_text = self._llm_preview(description, proposal.world_params)
            return {
                "ok": True,
                "world_id": world_id,
                "preview": {
                    "summary_text": preview_text,
                },
            }
        except Exception as exc:
            return {
                "ok": False,
                "error_code": "llm_generation_failed",
                "error": str(exc),
            }

    # ------------------------------------------------------------------
    # Stage 2 — characters propose + confirm
    # ------------------------------------------------------------------
    def propose_characters(
        self, world_id: str, description: str, mode: str = "auto",
    ) -> Dict[str, Any]:
        """LLM-generated character card draft(s) for user editing.

        Uses the LLM client's text_fn to suggest a single protagonist
        card; returns draft fields the user can edit before confirm.
        """
        try:
            authoring_context = self._world_authoring_context(
                world_id,
                description,
            )
            llm_client, llm_message = self._resolve_llm_client()
            if llm_client is None:
                return {
                    "ok": False,
                    "error_code": "llm_required",
                    "error": llm_message or "角色创建必须配置可用 LLM。",
                }
            text_fn = llm_client.as_text_fn(
                temperature=0.3, max_tokens=2048,
            )
            prompt = (
                f"你是一位角色设计师。根据以下世界描述，生成一个主角的角色卡。\n\n"
                f"世界描述：{authoring_context}\n\n"
                f"请用JSON格式返回一个角色卡数组（至少一个角色），每张卡包含：\n"
                f"- name: 角色姓名\n"
                f"- personality: 性格描述\n"
                f"- appearance: 纯文本叙事中的外貌描述\n"
                f"- sample_line: 一句标志性台词\n\n"
                "不得引用或套用任何内置角色、作品、世界或预设；"
                "只根据本次描述从零生成。\n\n"
                f"JSON:"
            )
            raw = text_fn(prompt)
            import re as _re
            match = _re.search(r"\[.*\]", raw, _re.DOTALL)
            if match:
                draft = json.loads(match.group(0))
            else:
                match = _re.search(r"\{.*\}", raw, _re.DOTALL)
                if match:
                    obj = json.loads(match.group(0))
                    draft = [obj] if isinstance(obj, dict) else obj
                else:
                    draft = []
            if not isinstance(draft, list):
                draft = [draft]
            normalised = []
            for item in draft:
                if not isinstance(item, dict):
                    continue
                card = {
                    "name": str(item.get("name") or "").strip(),
                    "personality": str(item.get("personality") or "").strip(),
                    "appearance": str(item.get("appearance") or "").strip(),
                    "sample_line": str(item.get("sample_line") or "").strip(),
                }
                if not all(card.values()):
                    raise ValueError(
                        "模型角色卡必须完整填写姓名、性格、外貌与示例台词"
                    )
                normalised.append(card)
            if not normalised:
                raise ValueError("模型未返回可用的角色卡数组")
            return {"ok": True, "source": "llm", "degraded": False, "warnings": [], "draft": normalised}
        except Exception as exc:
            return {
                "ok": False,
                "error_code": "llm_generation_failed",
                "error": str(exc),
            }

    def confirm_characters(
        self, world_id: str, edited_characters: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """User-edited character cards → create via orchestrator."""
        warnings: List[str] = []
        results: List[Dict[str, Any]] = []
        if not isinstance(edited_characters, list) or not edited_characters:
            return {
                "ok": False,
                "error": "at least one LLM-generated character card is required",
            }
        for idx, card in enumerate(edited_characters):
            if not isinstance(card, dict):
                return {
                    "ok": False,
                    "error": f"character[{idx}] must be an object",
                }
            missing = [
                key
                for key in ("name", "personality", "appearance", "sample_line")
                if not str(card.get(key) or "").strip()
            ]
            if missing:
                return {
                    "ok": False,
                    "error": (
                        f"character[{idx}] is missing required fields: "
                        + ", ".join(missing)
                    ),
                }
        try:
            with self._temporary_world(world_id):
                for idx, card in enumerate(edited_characters):
                    name = str(card["name"]).strip()
                    fields = {
                        "name": name,
                        # The editable card schema has no separate summary field.
                        # Reuse the LLM-authored personality text as its concise
                        # persisted summary instead of triggering a second call.
                        "summary": str(card["personality"]).strip(),
                        "personality": str(card["personality"]).strip(),
                        "appearance": str(card["appearance"]).strip(),
                        "sample_line": str(card["sample_line"]).strip(),
                    }
                    info = self._create_one_character(
                        {
                            "mode": "mixed",
                            "description": name,
                            "fields": fields,
                        },
                        "auto",
                        idx,
                    )
                    results.append(info)
                    if not info.get("ok"):
                        warnings.append(
                            f"character[{idx}] failed: {info.get('error')}"
                        )
        except Exception as exc:
            return {"ok": False, "error": f"world-scoped character write failed: {exc}"}

        return {
            "ok": bool(results) and not warnings,
            "characters": results,
            "warnings": warnings,
            **({"error": "; ".join(warnings)} if warnings else {}),
        }

    # ------------------------------------------------------------------
    # Stage 3 — rules + GUI propose + confirm
    # ------------------------------------------------------------------
    def _generate_dynamically_valid_rules(
        self,
        description: str,
        text_fn: Callable[[str], str],
    ) -> tuple[Any, Dict[str, Any], Dict[str, Any]]:
        """Have the LLM repair rule drafts until the dynamic gate passes."""
        feedback = ""
        last_error = ""
        for _attempt in range(3):
            def _validated_text_fn(prompt: str) -> str:
                if not feedback:
                    return text_fn(prompt)
                return text_fn(
                    prompt
                    + "\n\nThe previous complete rule draft passed static "
                    "validation but failed the 24-beat dynamic validation:\n"
                    + feedback[:14000]
                    + "\nReturn a COMPLETE corrected JSON rule spec. Preserve "
                    "the world's intended semantics, but make every invariant "
                    "hold for all generated writes (use safe conditions or "
                    "clamp arithmetic where necessary). Do not explain."
                )

            spec, gen_meta = generate_world_rules(
                description,
                llm_fn=_validated_text_fn,
            )
            if gen_meta.get("source") != "llm":
                raise RuntimeError("world rules were not authored by the LLM")

            from .world_rule_validator import WorldRuleValidator
            dyn = WorldRuleValidator().validate(
                spec,
                beats=24,
                explosion_limit=1e8,
            )
            if dyn.passed:
                return spec, gen_meta, dyn.to_dict()

            last_error = "; ".join(str(reason) for reason in dyn.reasons)
            feedback = (
                last_error
                + "\n\nRejected rule JSON:\n"
                + json.dumps(spec.to_dict(), ensure_ascii=False)[:12000]
            )

        raise RuntimeError(
            "LLM-generated rules failed dynamic validation after 3 "
            f"model-authored attempts: {last_error}"
        )

    def propose_rules_gui(self, world_id: str, description: str) -> Dict[str, Any]:
        """LLM-generated rules + GUI draft for user editing.

        Returns ``{ok, draft_rules, draft_gui}`` where each draft is a
        JSON-serialisable dict the user can edit.
        """
        try:
            llm_client, llm_message = self._resolve_llm_client()
            if llm_client is None:
                return {
                    "ok": False,
                    "error_code": "llm_required",
                    "error": llm_message or "规则与 GUI 创建必须配置可用 LLM。",
                    "draft_rules": None,
                    "draft_gui": None,
                }
            text_fn = llm_client.as_text_fn(
                temperature=0.2, max_tokens=4096,
            )
            dict_fn = llm_client.as_dict_fn(
                temperature=0.4, max_tokens=4096,
            )
            authoring_context = self._world_authoring_context(
                world_id,
                description,
            )

            spec, gen_meta, dynamic_report = self._generate_dynamically_valid_rules(
                authoring_context,
                text_fn,
            )
            draft_rules = spec.to_dict()

            gui_spec, gui_meta = generate_world_gui(
                authoring_context,
                llm_fn=dict_fn,
            )
            draft_gui = gui_spec.to_dict()
            if (
                gen_meta.get("source") != "llm"
                or gui_meta.get("source") != "llm"
            ):
                raise RuntimeError(
                    "规则与 GUI 必须由 LLM 生成，禁止 fallback"
                )

            return {
                "ok": True,
                "draft_rules": draft_rules,
                "draft_gui": draft_gui,
                "meta_rules": gen_meta,
                "meta_gui": gui_meta,
                "dynamic_validation": dynamic_report,
                "warnings": [],
                "degraded": False,
            }
        except Exception as exc:
            return {
                "ok": False,
                "error_code": "proposal_generation_failed",
                "error": str(exc),
                "draft_rules": None,
                "draft_gui": None,
            }

    def confirm_rules_gui(
        self, world_id: str, edited_rules: Dict[str, Any], edited_gui: Dict[str, Any],
    ) -> Dict[str, Any]:
        """User-edited rules + GUI → compile and register."""
        from .world_kernel_host import WorldKernelSpec
        from .gui_generator import _coerce_spec, _normalize_gui_spec
        warnings: List[str] = []

        rules_info: Dict[str, Any] = {"ok": False, "rules": 0}
        try:
            spec = WorldKernelSpec.from_dict(edited_rules)
            compiler = RuleCompiler()
            issues = compiler.validate_spec(spec)
            if issues:
                raise ValueError(
                    "rules failed static validation: " + "; ".join(issues)
                )
            compiled_kernel = compiler.compile(spec)
            spec_hash = compiled_kernel.spec_hash

            from .world_rule_validator import WorldRuleValidator
            dyn = WorldRuleValidator().validate(
                spec, beats=24, explosion_limit=1e8,
            )
            if not dyn.passed:
                raise RuntimeError(
                    f"rules failed dynamic validation ({dyn.reasons})"
                )

            if not world_id:
                raise ValueError("world_id is required")
            self.orchestrator.register_world_kernel(world_id, spec)

            rules_info = {
                "ok": True,
                "source": "user_edited",
                "world_type": spec.world_type,
                "constraint_type": spec.constraint_type,
                "rules": len(spec.rules),
                "compiled": True,
                "registered": True,
                "spec_hash": spec_hash,
                "issues": [],
                "dynamic_validation": dyn.to_dict(),
            }
        except Exception as exc:
            warnings.append(f"rules confirm failed: {exc}")
            rules_info = {"ok": False, "rules": 0, "error": str(exc)}

        gui_info: Dict[str, Any] = {"ok": False, "widgets": 0}
        try:
            gui_spec_obj = _coerce_spec(
                _normalize_gui_spec(dict(edited_gui), "user_edited"),
                "user_edited",
            )
            persist_gui_spec(self.state_root, world_id, gui_spec_obj)
            gui_info = {
                "ok": True,
                "source": "user_edited",
                "gui_spec_id": gui_spec_obj.gui_spec_id,
                "layout_type": gui_spec_obj.layout_type,
                "widgets": len(gui_spec_obj.widgets),
            }
        except Exception as exc:
            warnings.append(f"GUI confirm failed: {exc}")
            gui_info = {"ok": False, "widgets": 0, "error": str(exc)}

        return {
            "ok": rules_info["ok"] and gui_info["ok"],
            "rules": rules_info,
            "gui": gui_info,
            "warnings": warnings,
            **(
                {"error": rules_info.get("error") or gui_info.get("error")}
                if not (rules_info["ok"] and gui_info["ok"])
                else {}
            ),
        }

    # ------------------------------------------------------------------
    # Stage 4 — gameplay propose + confirm
    # ------------------------------------------------------------------
    def propose_gameplay(
        self, world_id: str, description: str,
    ) -> Dict[str, Any]:
        """Generate a from-scratch gameplay draft for user editing.

        The generic onboarding endpoint never performs keyword matching or
        selects a registered gameplay kernel.  A valid LLM-authored spec is
        mandatory; there is no no-model or invalid-output fallback.
        """
        try:
            from .gameplay_generator import GameplayGenerator

            llm_client, llm_message = self._resolve_llm_client()
            if llm_client is None:
                return {
                    "ok": False,
                    "error_code": "llm_required",
                    "error": llm_message or "玩法创建必须配置可用 LLM。",
                }
            text_fn = llm_client.as_text_fn(
                temperature=0.2, max_tokens=4096,
            )
            authoring_context = self._world_authoring_context(
                world_id,
                description,
            )

            gen = GameplayGenerator()
            spec, result = gen.generate(
                authoring_context,
                world_style=authoring_context,
                llm_fn=text_fn,
            )
            if result.source != "llm":
                raise RuntimeError("玩法必须由 LLM 从零生成，禁止 fallback")
            return {
                "ok": True,
                "draft": spec.to_dict() if hasattr(spec, "to_dict") else spec,
                "source": result.source,
                "degraded": False,
                "warnings": [],
                "validation": result.validation.to_dict() if result.validation else None,
                "repairs": result.repairs,
            }
        except Exception as exc:
            return {
                "ok": False,
                "error_code": "llm_generation_failed",
                "error": str(exc),
            }

    def confirm_gameplay(
        self, world_id: str, edited_gameplay: Dict[str, Any],
    ) -> Dict[str, Any]:
        """User-edited gameplay → persist."""
        try:
            from .gameplay_validator import GameplaySpec, GameplayValidator
            if not isinstance(edited_gameplay, dict):
                raise ValueError("edited_gameplay must be an object")
            spec = GameplaySpec.from_dict(edited_gameplay)
            report = GameplayValidator().validate_all(spec)
            if not report.passed:
                raise ValueError(
                    "gameplay failed validation: " + "; ".join(report.reasons)
                )
            self.orchestrator.register_gameplay_spec(world_id, spec)
            return {
                "ok": True,
                "world_id": world_id,
                "spec_name": edited_gameplay.get("name", ""),
                "validation": report.to_dict(),
            }
        except Exception as exc:
            return {
                "ok": False,
                "error_code": "llm_generation_failed",
                "error": str(exc),
            }

    # ------------------------------------------------------------------
    # Stage 5 — finalize (narrative handoff)
    # ------------------------------------------------------------------
    def finalize(self, world_id: str) -> Dict[str, Any]:
        """Activate the world: register WorldClock, return ready status.

        Called after all 4 previous stages are confirmed. Returns a
        narrative-handoff payload identical to stage 5 of ``run()``.
        """
        from .world_kernel_host import classify_constraint_type
        if not str(world_id or "").strip():
            return {
                "ok": False,
                "ready": False,
                "error": "world_id is required",
            }
        try:
            self.orchestrator.set_world(world_id)
        except Exception as exc:
            return {
                "ok": False,
                "world_id": world_id,
                "ready": False,
                "error": f"world activation failed: {exc}",
            }

        preview = {"summary_text": self._llm_preview("", {})}
        world_type = ""
        declared_constraint_type = None
        try:
            spec = self.orchestrator.get_world_kernel_spec(world_id)
            if spec is None:
                raise RuntimeError(
                    "rules are not confirmed; complete the LLM rules step first"
                )
            world_type = getattr(spec, "world_type", "")
            declared_constraint_type = getattr(spec, "constraint_type", None)
        except Exception as exc:
            return {
                "ok": False,
                "world_id": world_id,
                "ready": False,
                "error": str(exc),
            }

        gui_spec = load_gui_spec(self.state_root, world_id)
        if gui_spec is None:
            return {
                "ok": False,
                "world_id": world_id,
                "ready": False,
                "error": "GUI is not confirmed; complete the LLM GUI step first",
            }
        gameplay_spec = self.orchestrator.get_gameplay_spec(world_id)
        if gameplay_spec is None:
            return {
                "ok": False,
                "world_id": world_id,
                "ready": False,
                "error": (
                    "gameplay is not confirmed; complete the LLM gameplay "
                    "step first"
                ),
            }

        constraint_type = classify_constraint_type(
            world_type, declared_constraint_type,
        )

        return {
            "ok": True,
            "world_id": world_id,
            "ready": True,
            "preview": preview,
            "stance": "guest",
            "stance_message": (
                "世界已成，你现在是客人。规则已颁布，将以世界法则运行；"
                "想改规则请 fork 新宇宙，而非 mutate 当前世界。"
            ),
            "constraint_type": constraint_type,
        }

    # ------------------------------------------------------------------
    # Stage 1 — world (original internal methods)
    # ------------------------------------------------------------------
    def _stage_world(
        self, description: str, worldbook: Optional[Any],
    ) -> tuple[Dict[str, Any], List[str]]:
        warnings: List[str] = []
        try:
            proposed = self.propose_world(description)
            if not proposed.get("ok"):
                raise RuntimeError(
                    proposed.get("error") or "LLM world proposal failed"
                )
            draft = dict(proposed["draft"])
            confirmed = self.confirm_world(description, draft)
            if not confirmed.get("ok"):
                raise RuntimeError(
                    confirmed.get("error") or "world confirmation failed"
                )
            world_id = str(confirmed["world_id"])
            world_params = dict(draft["world_params"])
            preview_text = str(
                (proposed.get("preview") or {}).get("summary_text") or ""
            )
        except Exception as exc:
            return (
                {"ok": False, "world_id": "", "error": str(exc)},
                [f"stage1 world creation failed: {exc}"],
            )

        # Worldbook import (optional). Compiles the lorebook and appends each
        # entry through the orchestrator's single write point.
        imported = 0
        if worldbook:
            try:
                with self._temporary_world(world_id):
                    compiled = self._compile_worldbook(worldbook, world_id)
                    for w in compiled.get("warnings", []):
                        warnings.append(f"worldbook: {w}")
                    existing_titles = {
                        e.title
                        for e in self.orchestrator.state_store.snapshot().worldbook
                    }
                    from .models import WorldBookPatch
                    for entry in compiled["worldbook"]:
                        if entry["title"] in existing_titles:
                            continue
                        patch = WorldBookPatch(
                            title=entry["title"],
                            content=entry["content"],
                            source=entry["source"],
                            provenance="lore",
                        )
                        self.orchestrator.add_world_entry(
                            patch,
                            "science_director",
                            origin="worldbook_import",
                        )
                        imported += 1
            except Exception as exc:
                warnings.append(f"stage1 worldbook import failed: {exc}")

        return (
            {
                "ok": True,
                "source": "llm",
                "world_id": world_id,
                "world_params": world_params,
                "imported_entries": imported,
                "preview": {
                    "summary_text": preview_text,
                },
            },
            warnings,
        )

    @staticmethod
    def _compile_worldbook(worldbook: Any, world_id: str) -> Dict[str, Any]:
        from .worldbook_import import WorldbookImporter
        return WorldbookImporter.compile_worldbook(
            worldbook, target_world_id=world_id,
        )

    # ------------------------------------------------------------------
    # Stage 2 — characters
    # ------------------------------------------------------------------
    def _stage_characters(
        self,
        world_id: str,
        characters: Optional[List[Any]],
        character_cards: Optional[List[Any]],
        default_mode: str,
    ) -> tuple[List[Dict[str, Any]], List[str]]:
        results: List[Dict[str, Any]] = []
        warnings: List[str] = []
        if not world_id:
            warnings.append("stage2 skipped: no world_id from stage 1")
            return results, warnings

        items = list(characters or [])
        if not items and not character_cards:
            warnings.append("stage2 skipped: no characters requested")
            return results, warnings

        try:
            with self._temporary_world(world_id):
                for idx, item in enumerate(items):
                    info = self._create_one_character(item, default_mode, idx)
                    results.append(info)
                    if not info.get("ok"):
                        warnings.append(
                            f"stage2 character[{idx}] failed: {info.get('error')}"
                        )

                for idx, card in enumerate(character_cards or []):
                    info = self._import_one_card(card, idx)
                    results.append(info)
                    if not info.get("ok"):
                        warnings.append(
                            f"stage2 card[{idx}] failed: {info.get('error')}"
                        )
        except Exception as exc:
            warnings.append(f"stage2 world-scoped write failed: {exc}")

        return results, warnings

    def _create_one_character(
        self, item: Any, default_mode: str, idx: int,
    ) -> Dict[str, Any]:
        # Accept either a plain description string (CLI --character "…") or a
        # structured dict {mode, description, fields, character_id}.
        if isinstance(item, str):
            spec = {"mode": default_mode, "description": item, "fields": {}}
        elif isinstance(item, dict):
            spec = item
        else:
            return {"ok": False, "error": f"character[{idx}] not str/dict"}
        try:
            result = self.orchestrator.create_character(
                mode=str(spec.get("mode") or default_mode),
                description=spec.get("description"),
                fields=spec.get("fields") or {},
                character_id=spec.get("character_id"),
            )
            if not result.get("ok"):
                return {
                    "ok": False,
                    "error": result.get("error") or "create_character returned ok=False",
                    "reasons": result.get("reasons"),
                }
            return {
                "ok": True,
                "character_id": result.get("character_id"),
                "name": (result.get("character") or {}).get("name"),
                "mode": str(spec.get("mode") or default_mode),
                "warnings": result.get("warnings") or [],
            }
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def _import_one_card(self, card: Any, idx: int) -> Dict[str, Any]:
        from .models import CharacterPatch
        from .world_import import WorldImporter
        try:
            parsed = WorldImporter.parse_card(dict(card))
            injection_warnings: List[str] = []
            for raw_text in parsed.raw_fields.values():
                injection_warnings.extend(WorldImporter.scan_injection(raw_text))
            entity = WorldImporter.compile_character(
                parsed,
                gaps_filled={
                    "dag_position": "imported",
                    "allowed_actions": ["move", "speak"],
                    "disposition": {"loyalty": 0.5},
                    "damping": {"fear": 0.5},
                },
                injected=injection_warnings,
            )
            errors = WorldImporter.validate(entity)
            if errors:
                return {"ok": False, "error": "card failed QA gate", "reasons": errors}
            tone_samples = entity.prose.get("tone_samples") or []
            patch = CharacterPatch(
                character_id=entity.character_id,
                name=parsed.name or entity.character_id,
                summary=str(entity.prose.get("description", ""))[:280],
                source="imported_card",
                personality=str(entity.prose.get("personality", "")),
                sample_line=str(tone_samples[0]) if tone_samples else "",
            )
            self.orchestrator.upsert_character(
                patch, "science_director", origin="card_import",
            )
            return {
                "ok": True,
                "character_id": entity.character_id,
                "name": parsed.name,
                "source": "imported_card",
            }
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    # ------------------------------------------------------------------
    # Stage 3 — rules + GUI
    # ------------------------------------------------------------------
    def _stage_rules_gui(
        self, description: str, world_id: str, use_llm: bool,
    ) -> tuple[Dict[str, Any], Dict[str, Any], List[str]]:
        warnings: List[str] = []
        if not use_llm:
            error = "stage3 requires LLM; use_llm=False is unsupported"
            return (
                {"ok": False, "source": "unavailable", "rules": 0, "error": error},
                {"ok": False, "source": "unavailable", "widgets": 0, "error": error},
                [error],
            )

        llm_client, llm_message = self._resolve_llm_client()
        if llm_client is None:
            error = llm_message or "stage3 requires a configured LLM"
            return (
                {"ok": False, "source": "unavailable", "rules": 0, "error": error},
                {"ok": False, "source": "unavailable", "widgets": 0, "error": error},
                [error],
            )
        try:
            text_fn = llm_client.as_text_fn(
                temperature=0.2, max_tokens=4096,
            )
            dict_fn = llm_client.as_dict_fn(
                temperature=0.4, max_tokens=4096,
            )
            authoring_context = self._world_authoring_context(
                world_id,
                description,
            )
        except Exception as exc:
            error = f"stage3 LLM function setup failed: {exc}"
            return (
                {"ok": False, "source": "unavailable", "rules": 0, "error": error},
                {"ok": False, "source": "unavailable", "widgets": 0, "error": error},
                [error],
            )

        # ---- rules ----
        rules_info: Dict[str, Any] = {
            "ok": False, "source": "unavailable", "rules": 0,
        }
        try:
            spec, gen_meta, dynamic_report = self._generate_dynamically_valid_rules(
                authoring_context,
                text_fn,
            )
            compiler = RuleCompiler()
            issues = compiler.validate_spec(spec)
            if issues:
                raise RuntimeError(
                    "LLM-generated rules failed static validation: "
                    + "; ".join(issues)
                )
            compiled_kernel = compiler.compile(spec)

            self.orchestrator.register_world_kernel(world_id, spec)
            rules_info = {
                "ok": True,
                "source": "llm",
                "world_type": spec.world_type,
                "constraint_type": spec.constraint_type,
                "rules": len(spec.rules),
                "compiled": True,
                "registered": True,
                "spec_hash": compiled_kernel.spec_hash,
                "issues": [],
                "dynamic_validation": dynamic_report,
            }
        except Exception as exc:
            warnings.append(f"stage3 LLM rule generation failed: {exc}")
            rules_info = {
                "ok": False,
                "source": "unavailable",
                "world_type": "",
                "rules": 0,
                "compiled": False,
                "registered": False,
                "spec_hash": "",
                "issues": [],
                "dynamic_validation": None,
                "error_code": "rule_generation_failed",
                "error": str(exc),
            }

        # ---- GUI ----
        gui_info: Dict[str, Any] = {
            "ok": False, "source": "unavailable", "widgets": 0,
        }
        if not rules_info.get("ok"):
            gui_info["error"] = "GUI generation blocked until LLM rules pass validation"
            return rules_info, gui_info, warnings
        try:
            gui_spec, gui_meta = generate_world_gui(
                authoring_context,
                llm_fn=dict_fn,
            )
            if gui_meta.get("source") != "llm":
                raise RuntimeError("GUI was not authored by the LLM")
            persist_gui_spec(self.state_root, world_id, gui_spec)
            gui_info = {
                "ok": True,
                "source": gui_meta["source"],
                "gui_spec_id": gui_meta["gui_spec_id"],
                "layout_type": gui_meta["layout_type"],
                "widgets": gui_meta["widgets"],
            }
        except Exception as exc:
            warnings.append(f"stage3 GUI generation failed: {exc}")
            gui_info = {
                "ok": False,
                "source": "unavailable",
                "widgets": 0,
                "error": str(exc),
            }

        return rules_info, gui_info, warnings

    def _resolve_llm_client(self) -> tuple[Any, str]:
        if self._llm_client is not None:
            return self._llm_client, ""
        return build_llm()

    # ------------------------------------------------------------------
    # Stage 4 — gameplay (optional)
    # ------------------------------------------------------------------
    def _stage_gameplay(
        self,
        world_id: str,
        world_description: str,
        gameplay: Optional[Dict[str, Any]],
        use_llm: bool,
    ) -> tuple[Dict[str, Any], List[str]]:
        """Generate + persist a GameplaySpec for the world (spec §9.2).

        ``gameplay`` shape: ``{description, use_llm?, mode?}``. If omitted or
        left blank, the world description is used as the prompt.

        Returns ``({ok, source, kernel, validation, repairs, persisted,
        warnings}, stage_warnings)``. Any model/configuration/validation error
        blocks the stage; there is no generated fallback.
        """
        warnings: List[str] = []

        options = dict(gameplay or {})
        gp_description = str(
            options.get("description") or world_description
        ).strip()
        gp_use_llm = bool(options.get("use_llm", use_llm))
        if not gp_use_llm:
            error = "stage4 requires LLM; use_llm=False is unsupported"
            return (
                {
                    "ok": False,
                    "source": "unavailable",
                    "error_code": "llm_required",
                    "error": error,
                },
                [error],
            )
        llm_client, llm_message = self._resolve_llm_client()
        if llm_client is None:
            error = llm_message or "stage4 requires a configured LLM"
            return (
                {
                    "ok": False,
                    "source": "unavailable",
                    "error_code": "llm_required",
                    "error": error,
                },
                [error],
            )

        gameplay_info: Dict[str, Any] = {"ok": False, "source": "unavailable"}
        try:
            from .gameplay_generator import GameplayGenerator

            llm_fn = llm_client.as_text_fn(
                temperature=0.2, max_tokens=4096,
            )
            authoring_context = self._world_authoring_context(
                world_id,
                gp_description,
            )
            gen = GameplayGenerator()
            spec, result = gen.generate(
                authoring_context,
                world_style=authoring_context,
                llm_fn=llm_fn,
            )
            if result.source != "llm":
                raise RuntimeError("gameplay was not authored by the LLM")
            self.orchestrator.register_gameplay_spec(world_id, spec)
            gameplay_info = {
                "ok": True,
                "skipped": False,
                "source": result.source,
                "kernel": None,
                "spec_name": spec.name,
                "validation": result.validation.to_dict() if result.validation else None,
                "repairs": result.repairs,
                "persisted": True,
                "llm_message": "",
                "degraded": False,
            }
        except Exception as exc:  # noqa: BLE001
            warnings.append(f"stage4 gameplay generation failed: {exc}")
            gameplay_info = {
                "ok": False,
                "source": "unavailable",
                "error_code": "llm_generation_failed",
                "error": str(exc),
            }

        return gameplay_info, warnings

    # ------------------------------------------------------------------
    # Stage 4b — cognitive model (optional, Q7)
    # ------------------------------------------------------------------
    def _stage_cognitive_model(
        self,
        world_id: str,
        world_description: str,
        cognitive_model: Optional[Dict[str, Any]],
        use_llm: bool,
    ) -> tuple[Dict[str, Any], List[str]]:
        """Generate a CognitiveModelSpec for the world (Q7 — LLM-authored
        epistemic-misjudgement structure).

        ``cognitive_model`` shape: ``{agent_role?, use_llm?}``.  ``None`` →
        stage skipped.  The world description is reused; ``agent_role``
        defaults to the flow's ``mode``. A requested stage requires valid
        LLM output and never substitutes a built-in cognitive model.
        """
        warnings: List[str] = []
        if not cognitive_model:
            return ({"ok": True, "skipped": True}, warnings)

        cm_use_llm = bool(cognitive_model.get("use_llm", use_llm))
        agent_role = str(cognitive_model.get("agent_role") or "auto")

        if not cm_use_llm:
            error = "cognitive-model generation requires LLM"
            return (
                {
                    "ok": False,
                    "source": "unavailable",
                    "error_code": "llm_required",
                    "error": error,
                },
                [error],
            )
        llm_client, llm_message = self._resolve_llm_client()
        if llm_client is None:
            error = llm_message or "cognitive-model generation requires LLM"
            return (
                {
                    "ok": False,
                    "source": "unavailable",
                    "error_code": "llm_required",
                    "error": error,
                },
                [error],
            )

        cm_info: Dict[str, Any] = {"ok": False, "source": "unavailable"}
        try:
            from .cognitive_model_generator import generate_cognitive_model

            llm_fn = llm_client.as_text_fn(
                temperature=0.2, max_tokens=4096,
            )
            authoring_context = self._world_authoring_context(
                world_id,
                world_description,
            )
            spec, meta = generate_cognitive_model(
                authoring_context,
                agent_role=agent_role,
                llm_fn=llm_fn,
            )
            if meta.get("source") != "llm":
                raise RuntimeError(
                    "cognitive model was not authored by the LLM"
                )
            cm_info = {
                "ok": True,
                "skipped": False,
                "source": meta["source"],
                "world_type": meta["world_type"],
                "agent_role": meta["agent_role"],
                "failure_modes": meta["failure_modes"],
                "repairs": meta["repairs"],
                "validation": meta["validation"],
                "llm_message": "",
            }
        except Exception as exc:  # noqa: BLE001
            warnings.append(f"stage4b cognitive-model generation failed: {exc}")
            cm_info = {
                "ok": False,
                "source": "unavailable",
                "error_code": "llm_generation_failed",
                "error": str(exc),
            }

        return cm_info, warnings
