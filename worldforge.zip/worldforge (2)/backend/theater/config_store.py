"""Configuration store — persists LLM provider config across sessions.

The user configures base_url / api_key / model_fast / model_deep / per-role
models once (via launcher or env). This module saves that config to
``~/.worldforge_config.json`` and loads it on server startup so the user
doesn't have to reconfigure every time.

Architecture rule: **no hardcoded model names anywhere in the codebase**.
All model assignments happen at startup from this config (or env vars).
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

CONFIG_PATH = Path.home() / ".worldforge_config.json"

# Keys we persist (all optional — empty means "not set, use env or error").
CONFIG_KEYS = (
    "base_url",         # AI_THEATER_BASE_URL
    "api_key",          # AI_THEATER_API_KEY
    "model_fast",       # AI_THEATER_MODEL_FAST (global, all roles)
    "model_deep",       # AI_THEATER_MODEL_DEEP
    # Per-role overrides (optional; empty = use model_fast)
    "producer_model",
    "science_director_model",
    "world_builder_model",
)


def load_config() -> Dict[str, str]:
    """Load saved config from ``~/.worldforge_config.json``.

    Returns a dict with CONFIG_KEYS (values may be empty strings).
    Never raises — corrupt/missing file returns all-empty dict.
    """
    try:
        if CONFIG_PATH.exists():
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            return {k: str(data.get(k, "")) for k in CONFIG_KEYS}
    except Exception:
        pass
    return {k: "" for k in CONFIG_KEYS}


def save_config(config: Dict[str, str]) -> None:
    """Save config to ``~/.worldforge_config.json``.

    Only non-empty values are written. Never raises on write failure.
    """
    try:
        filtered = {k: v for k, v in config.items() if v and k in CONFIG_KEYS}
        CONFIG_PATH.write_text(json.dumps(filtered, indent=2), encoding="utf-8")
    except Exception:
        pass


def apply_config_to_env(config: Optional[Dict[str, str]] = None) -> None:
    """Apply saved config to ``os.environ`` (env vars take precedence).

    Called at server startup: loads the config file, then for each key
    that is empty in the environment but set in the config, sets the
    corresponding env var. This lets the user configure once and have
    it persist across restarts.
    """
    cfg = config or load_config()
    env_map = {
        "base_url": "AI_THEATER_BASE_URL",
        "api_key": "AI_THEATER_API_KEY",
        "model_fast": "AI_THEATER_MODEL_FAST",
        "model_deep": "AI_THEATER_MODEL_DEEP",
        "producer_model": "AI_THEATER_AGENT_PRODUCER_MODEL",
        "science_director_model": "AI_THEATER_AGENT_SCIENCE_DIRECTOR_MODEL",
        "world_builder_model": "AI_THEATER_AGENT_WORLD_BUILDER_MODEL",
    }
    for cfg_key, env_key in env_map.items():
        val = cfg.get(cfg_key, "")
        if val and not os.environ.get(env_key):
            os.environ[env_key] = val


def config_from_env() -> Dict[str, str]:
    """Snapshot current env vars into a config dict (for saving)."""
    env_map = {
        "AI_THEATER_BASE_URL": "base_url",
        "AI_THEATER_API_KEY": "api_key",
        "AI_THEATER_MODEL_FAST": "model_fast",
        "AI_THEATER_MODEL_DEEP": "model_deep",
        "AI_THEATER_AGENT_PRODUCER_MODEL": "producer_model",
        "AI_THEATER_AGENT_SCIENCE_DIRECTOR_MODEL": "science_director_model",
        "AI_THEATER_AGENT_WORLD_BUILDER_MODEL": "world_builder_model",
    }
    return {cfg_key: os.environ.get(env_key, "") for env_key, cfg_key in env_map.items()}


def update_and_save(**kwargs: str) -> Dict[str, str]:
    """Update config with changed values and save.

    Called when the user changes a setting at runtime (e.g. via launcher
    or a future /api/config endpoint). Merges with existing config,
    saves, and applies to env.
    """
    cfg = load_config()
    cfg.update({k: v for k, v in kwargs.items() if k in CONFIG_KEYS})
    save_config(cfg)
    apply_config_to_env(cfg)
    return cfg
