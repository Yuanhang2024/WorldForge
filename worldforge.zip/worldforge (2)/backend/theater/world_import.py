"""World import pipeline — character card compilation, injection scanning, QA gate.

§11.1: Import = compile, not load.  Card JSON  →  parse (deterministic)
→ LLM extract (offline, one-shot)  →  gap detect  →  ask only missing
→ QA gate  →  typed CharacterEntity.

§12.1:  Card text is untrusted input.  Never spliced into system prompt.
Only enters a restricted user turn.  State changes never parsed from
LLM free text.  Untrusted role cards default to can_write_state=false.

§15.3:  Output CharacterEntity matches the typed schema in the spec.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Public dataclasses
# ---------------------------------------------------------------------------

@dataclass
class ParsedCard:
    """Deterministically extracted fields from a character card JSON."""
    character_id: str = ""
    name: str = ""
    description: str = ""
    personality: str = ""
    scenario: str = ""
    first_mes: str = ""
    mes_example: str = ""
    creator_notes: str = ""
    system_prompt: str = ""
    post_history_instructions: str = ""
    alternate_greetings: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    creator: str = ""
    character_version: str = ""
    extended: Dict[str, Any] = field(default_factory=dict)
    # Raw text fields aggregated for injection scan
    raw_fields: Dict[str, str] = field(default_factory=dict)


@dataclass
class CharacterEntity:
    """Typed character entity — the compiled output of import (§15.3).

    ``prose`` holds card text that feeds the LLM *user turn* (never system).
    ``mechanics`` holds structured gameplay data for the deterministic engine.
    ``permissions`` gates runtime authority.
    """
    character_id: str
    source_card_ref: str

    # §12.1: card text lives here, NOT in system prompt
    prose: Dict[str, Any] = field(default_factory=dict)
    mechanics: Dict[str, Any] = field(default_factory=dict)
    permissions: Dict[str, bool] = field(default_factory=lambda: {"can_write_state": False})

    injection_warnings: List[str] = field(default_factory=list)
    qa_errors: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Injection patterns — data, not code
# ---------------------------------------------------------------------------

_INJECTION_PATTERNS: List[str] = [
    # Chinese direct
    r"忽略[之前以上所有].*?设定",
    r"无视[之前以上所有].*?规则",
    r"忘记[之前以上所有].*?指令",
    r"忘记[之前以上所有].*?规则",
    r"不要[受被].*?限制",
    r"你[是扮演将]?[一个].*?[自由自主]",
    r"请[忘记忽略无视].*?[身份规则设定]",
    # English direct
    r"ignore\s+(all\s+)?previous\s+(instructions|directives|commands|rules)",
    r"forget\s+(all\s+)?previous",
    r"disregard\s+prior",
    r"you\s+are\s+(no\s+longer|now)\s+a?\s*(free|unrestricted|unbounded)",
    r"you\s+are\s+no\s+w+(longer\s+)?bound\s+by",
    r"override\s+(all\s+)?(system\s+)?instructions",
    # System-prompt impersonation
    r"system\s*:",
    r"<\|im_start\|>system",
    r"\[system\]",
    r"你[是现在]的?[系统提示系统设定]",
    # Delimiter / jailbreak
    r"-+\s*BEGIN\s+(NEW\s+)?(INPUT|CONTEXT|SESSION)",
    r"-+\s*END\s+(OF\s+)?(INPUT|CONTEXT|SESSION)",
    r"===+\s*SYSTEM",
]

_INJECTION_RE = re.compile(
    "|".join(_INJECTION_PATTERNS),
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Required mechanics keys
# ---------------------------------------------------------------------------

_REQUIRED_MECHANICS: List[str] = [
    "disposition",
    "damping",
    "dag_position",
    "allowed_actions",
]

# ---------------------------------------------------------------------------
# WorldImporter
# ---------------------------------------------------------------------------

class WorldImporter:
    """Deterministic character-card compiler.  Pure Python, no dispatcher/agent
    dependencies, fully unit-testable."""

    @staticmethod
    def parse_card(card_json: dict) -> ParsedCard:
        """Deterministic parse of a character-card-style JSON.

        Handles both the flat SillyTavern v2 spec and nested v1 aliases.
        No LLM call — this is the first step in §11.1's pipeline.
        """
        def _pick(*keys: str) -> Any:
            for k in keys:
                v = card_json.get(k)
                if v is not None:
                    return v
            return ""

        parsed = ParsedCard(
            character_id=_pick("character_id", "char_id", "id"),
            name=_pick("name", "char_name"),
            description=_pick("description", "char_description", "description_text"),
            personality=_pick("personality", "char_personality"),
            scenario=_pick("scenario", "world_scenario"),
            first_mes=_pick("first_mes", "first_message", "greeting"),
            mes_example=_pick("mes_example", "example_dialogue"),
            creator_notes=_pick("creator_notes", "notes"),
            system_prompt=_pick("system_prompt"),
            post_history_instructions=_pick("post_history_instructions", "history_instructions"),
            alternate_greetings=card_json.get("alternate_greetings", []),
            tags=card_json.get("tags", []),
            creator=card_json.get("creator", ""),
            character_version=card_json.get("character_version", ""),
            extended=card_json.get("extensions", {}),
        )

        # Collect all text fields for injection scan
        raw: Dict[str, str] = {}
        for field_name in (
            "description", "personality", "scenario", "first_mes",
            "mes_example", "creator_notes", "system_prompt",
            "post_history_instructions",
        ):
            val = getattr(parsed, field_name)
            if val:
                raw[field_name] = val
        for i, g in enumerate(parsed.alternate_greetings):
            if g:
                raw[f"alternate_greeting_{i}"] = g
        parsed.raw_fields = raw

        return parsed

    @staticmethod
    def detect_gaps(parsed: ParsedCard) -> List[str]:
        """Detect missing fields required by the typed schema.

        Returns human-readable descriptions of what's missing.
        """
        gaps: List[str] = []

        if parsed.character_id and parsed.character_id != parsed.name:
            pass  # both present is fine
        if not parsed.character_id:
            gaps.append("character_id is missing")
        if not parsed.name:
            gaps.append("name is missing")
        if not parsed.description:
            gaps.append("description is missing — needed for LLM characterisation")
        if not parsed.personality:
            gaps.append("personality is missing — needed for disposition draft")

        return gaps

    @staticmethod
    def scan_injection(text: str) -> List[str]:
        """Scan text for prompt-injection patterns (§12.1).

        Returns a list of matched pattern descriptions (empty = clean).
        """
        if not text:
            return []
        matches: List[str] = []
        for pattern in _INJECTION_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE | re.DOTALL):
                matches.append(f"suspicious pattern: {pattern!r}")
        return matches

    @staticmethod
    def compile_character(
        parsed: ParsedCard,
        gaps_filled: Optional[Dict[str, Any]] = None,
        injected: Optional[List[str]] = None,
    ) -> CharacterEntity:
        """Compile a ParsedCard into a typed CharacterEntity (§15.3).

        §12.1 invariant: card text goes into ``prose``, *never* into
        a system prompt slot on the entity.  The entity itself does not
        carry a ``system_prompt`` field.

        Parameters
        ----------
        parsed: ParsedCard from parse_card().
        gaps_filled: dict with keys for any gaps detected by detect_gaps()
                     that were filled interactively.
        injected: list of injection warnings from scan_injection().
        """
        gaps_filled = gaps_filled or {}
        injected = injected or []

        # §15.3 prose section — card text goes here, NOT system prompt
        prose: Dict[str, Any] = {
            "description": parsed.description or gaps_filled.get("description", ""),
            "personality": parsed.personality or gaps_filled.get("personality", ""),
            "scenario": parsed.scenario,
        }
        tone_samples: List[str] = []
        if parsed.first_mes:
            tone_samples.append(parsed.first_mes)
        if parsed.mes_example:
            tone_samples.append(parsed.mes_example)
        if parsed.alternate_greetings:
            tone_samples.extend(parsed.alternate_greetings)
        if tone_samples:
            prose["tone_samples"] = tone_samples

        # §15.3 mechanics section
        mechanics: Dict[str, Any] = {
            "disposition": gaps_filled.get("disposition", {}),
            "damping": gaps_filled.get("damping", {}),
            "dag_position": gaps_filled.get("dag_position", ""),
            "allowed_actions": gaps_filled.get(
                "allowed_actions",
                ["move", "speak"],
            ),
        }

        # §12.1: untrusted import = no state-write permission until QA
        permissions: Dict[str, bool] = {"can_write_state": False}

        entity = CharacterEntity(
            character_id=parsed.character_id or gaps_filled.get("character_id", ""),
            source_card_ref=parsed.extended.get("source_path", ""),
            prose=prose,
            mechanics=mechanics,
            permissions=permissions,
            injection_warnings=injected,
        )
        return entity

    @staticmethod
    def validate(character: CharacterEntity) -> List[str]:
        """QA gate (§11.1).  Returns list of validation errors (empty = pass).

        Checks:
        - identity fields present
        - no injection warnings unresolved
        - required mechanics keys present
        - can_write_state still false (imports start locked)
        """
        errors: List[str] = []

        if not character.character_id:
            errors.append("character_id is required")
        if not character.prose.get("description"):
            errors.append("prose.description is required")
        if not character.prose.get("personality"):
            errors.append("prose.personality is required")

        for key in _REQUIRED_MECHANICS:
            val = character.mechanics.get(key)
            if key == "allowed_actions":
                if not val or not isinstance(val, list) or len(val) == 0:
                    errors.append(f"mechanics.{key} must be a non-empty list")
            elif not val:
                errors.append(f"mechanics.{key} is required")

        if character.injection_warnings:
            errors.append(
                f"injection warnings not cleared: {character.injection_warnings}"
            )

        # §12.1: untrusted import default — must remain locked until QA passes
        if character.permissions.get("can_write_state") is True:
            errors.append("untrusted import must have can_write_state=false")

        return errors
