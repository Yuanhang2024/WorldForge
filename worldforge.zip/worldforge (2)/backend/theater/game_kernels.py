"""Parameterized game kernel library.

Architecture spec §9.2 — a deterministic, no-LLM, pure-Python collection of
10-15 game-mechanic kernels that cover ~90% of minigame scenarios in the AI
theater world simulator.

Red lines enforced here:
- Every kernel is a deterministic state machine (<1ms per step, zero LLM).
- All randomness comes from a seeded random.Random, reproducible on replay.
- is_terminal MUST eventually return True for any sequence of legal actions.
- "Cheating" is an engine rule (config flag), not an LLM decision.
"""

from __future__ import annotations

import random
import re
from abc import ABC, abstractmethod
from collections import Counter
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
SUITS: List[str] = ["S", "H", "D", "C"]          # Spades, Hearts, Diamonds, Clubs
RANKS: List[int] = list(range(2, 15))            # 2-14  (11=J, 12=Q, 13=K, 14=A)
RANK_NAMES: Dict[int, str] = {11: "J", 12: "Q", 13: "K", 14: "A"}

SUIT_ORDER: Dict[str, int] = {s: i for i, s in enumerate(SUITS)}  # for deterministic sorting


def _card_str(suit: str, rank: int) -> str:
    """Human-readable card identifier, e.g. 'S14' or 'H10'."""
    return f"{suit}{RANK_NAMES.get(rank, str(rank))}"


def _card_rank(card: str) -> int:
    """Extract rank from card string 'S14' -> 14."""
    rest = card[1:]
    rev = {"J": 11, "Q": 12, "K": 13, "A": 14}
    if rest in rev:
        return rev[rest]
    return int(rest)


def _card_suit(card: str) -> str:
    """Extract suit from card string 'S14' -> 'S'."""
    return card[0]


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------
class GameKernel(ABC):
    """Abstract base for all game kernels.

    Each kernel is a deterministic state machine.  Callers interact with it
    exclusively through the six public methods below — no LLM involvement at
    any point during execution.
    """

    def __init__(self, config: dict) -> None:
        self.config = config
        self._rng = random.Random(config.get("seed", 42))

    # -- subclasses must override ----------------------------------------

    @abstractmethod
    def init_state(self) -> dict:
        """Return the initial game state dict.

        Every call with the same config yields the same initial state
        (deterministic from config["seed"]).
        """

    @abstractmethod
    def legal_actions(self, state: dict) -> List[str]:
        """Return the list of legal action strings for the current state."""

    @abstractmethod
    def apply(self, state: dict, action: str) -> dict:
        """Return a *new* state dict after executing *action*.

        Must complete in <1ms wall time.  Does NOT mutate the input state.
        """

    @abstractmethod
    def is_terminal(self, state: dict) -> bool:
        """True iff the game has ended."""

    @abstractmethod
    def winner(self, state: dict) -> Optional[str]:
        """Return the winner player id, or None if tie / game not over."""

    @abstractmethod
    def bot_action(self, state: dict, persona: str) -> str:
        """Return a legal action chosen by a heuristic bot.

        *persona* influences strategy — e.g. "greedy", "conservative",
        "reckless".  The decision must complete in microseconds (<1ms).
        """


# ===================================================================
# DeckKernel — trick-taking (吃墩类)
# ===================================================================
class DeckKernel(GameKernel):
    """Trick-taking card game.

    Config:
        num_players (int): 2-6  (default 4)
        num_cards   (int): cards dealt per hand (default 13; 0=full deck)

    Rules:
        - A standard 52-card deck is shuffled and dealt evenly.
        - Players, in clockwise order, lead a card; others must follow suit
          if able.  The highest card of the *led* suit wins the trick.
        - The trick winner leads the next trick.
        - After all cards are played the player with the most tricks wins.
        - If `cheater` is set in config, that player sees opponents' cards
          (engine rule — not an LLM capability).
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._num_players = max(2, min(6, config.get("num_players", 4)))
        self._cheater: Optional[str] = config.get("cheater")  # player id who cheats

    def _deck_size(self) -> int:
        n = self.config.get("num_cards", 0)
        if n and 0 < n * self._num_players <= 52:
            return n * self._num_players
        # round down to nearest multiple of num_players
        return (52 // self._num_players) * self._num_players

    def _player_ids(self) -> List[str]:
        return [f"p{i}" for i in range(self._num_players)]

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()

        deck = [_card_str(s, r) for s in SUITS for r in RANKS]
        self._rng.shuffle(deck)
        total = self._deck_size()
        deck = deck[:total]
        per_player = total // self._num_players

        hands: Dict[str, List[str]] = {}
        for i, p in enumerate(players):
            h = deck[i * per_player:(i + 1) * per_player]
            h.sort(key=lambda c: (SUIT_ORDER[_card_suit(c)], _card_rank(c)))
            hands[p] = h

        return {
            "hands": hands,
            "current_trick": [],          # [(player_id, card), ...]
            "tricks_won": {p: 0 for p in players},
            "scores": {p: 0 for p in players},
            "current_player": players[0],
            "led_suit": None,
            "trick_number": 0,
            "phase": "playing",           # "playing" | "finished"
        }

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] != "playing":
            return []
        player = state["current_player"]
        hand = state["hands"][player]
        if not hand:
            return []
        led = state["led_suit"]
        if led is None:
            # leading — any card
            return [f"play_{c}" for c in hand]
        # must follow suit if possible
        follows = [c for c in hand if _card_suit(c) == led]
        if follows:
            return [f"play_{c}" for c in follows]
        return [f"play_{c}" for c in hand]

    def apply(self, state: dict, action: str) -> dict:
        assert action.startswith("play_")
        card = action[5:]
        s = dict(state)
        player = s["current_player"]

        # Remove card from hand
        new_hands = dict(s["hands"])
        new_hands[player] = [c for c in new_hands[player] if c != card]
        s["hands"] = new_hands

        # Add to trick
        trick = list(s["current_trick"])
        trick.append((player, card))
        s["current_trick"] = trick

        if s["led_suit"] is None:
            s["led_suit"] = _card_suit(card)

        players = self._player_ids()

        # Check if trick is complete
        if len(trick) >= self._num_players:
            # Determine winner: highest card of led suit
            led = s["led_suit"]
            candidates = [(p, c) for p, c in trick if _card_suit(c) == led]
            if not candidates:
                candidates = trick  # fallback (shouldn't happen)
            winner_id = max(candidates, key=lambda x: _card_rank(x[1]))[0]

            new_tricks = dict(s["tricks_won"])
            new_tricks[winner_id] = new_tricks.get(winner_id, 0) + 1
            s["tricks_won"] = new_tricks

            s["current_trick"] = []
            s["led_suit"] = None
            s["current_player"] = winner_id
            s["trick_number"] = s["trick_number"] + 1

            # Check terminal
            total_cards = self._deck_size()
            cards_played = s["trick_number"] * self._num_players
            if cards_played >= total_cards:
                s["phase"] = "finished"
                # compute final scores
                for p in players:
                    s["scores"][p] = s["tricks_won"].get(p, 0)
        else:
            # next player
            idx = players.index(player)
            nxt = (idx + 1) % self._num_players
            s["current_player"] = players[nxt]

        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        best = max(state["scores"].values())
        winners = [p for p, v in state["scores"].items() if v == best]
        if len(winners) != 1:
            return None  # tie
        return winners[0]

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        player = state["current_player"]
        hand = state["hands"][player]
        led = state["led_suit"]

        # Parse cards from legal actions
        cards = [a[5:] for a in legal]  # strip "play_" prefix

        if persona in ("greedy", "aggressive"):
            # Lead or play highest card of the led suit (or overall if leading)
            if led is None:
                # leading: play highest card
                c = max(cards, key=_card_rank)
            else:
                # Follow: play highest that follows suit
                follows = [c for c in cards if _card_suit(c) == led]
                c = max(follows, key=_card_rank) if follows else max(cards, key=_card_rank)
        elif persona == "conservative":
            # Lead lowest; when following, play as low as possible while
            # still following suit.
            if led is None:
                c = min(cards, key=_card_rank)
            else:
                follows = [c for c in cards if _card_suit(c) == led]
                if follows:
                    # Play the lowest card that still follows suit
                    # (no need to waste a high card if we're winning anyway)
                    c = min(follows, key=_card_rank)
                else:
                    c = min(cards, key=_card_rank)
        elif persona == "cheater" and self._cheater == player:
            # Cheater: see all opponents' hands (engine rule), play
            # the lowest card that will still win the trick, or the
            # cheapest losing card when we can't win.
            if led is not None:
                # Check who has played what so far
                current_trick = state["current_trick"]
                led_cards = [(p, c) for p, c in current_trick if _card_suit(c) == led]
                if led_cards:
                    best_so_far = max(led_cards, key=lambda x: _card_rank(x[1]))
                    best_rank = _card_rank(best_so_far[1])
                    # Can we beat it?
                    beats = [c for c in cards if _card_suit(c) == led and _card_rank(c) > best_rank]
                    if beats:
                        c = min(beats, key=_card_rank)  # cheapest winning card
                    else:
                        c = min(cards, key=_card_rank)  # can't win, dump lowest
                else:
                    c = min(cards, key=_card_rank)
            else:
                c = max(cards, key=_card_rank)  # lead strong
        else:
            # "reckless" or anything else — random
            c = cards[self._rng.randint(0, len(cards) - 1)]

        return f"play_{c}"


# ===================================================================
# DicePoolKernel — dice pool (骰池类)
# ===================================================================
class DicePoolKernel(GameKernel):
    """Dice rolling / Yahtzee-style game.

    Config:
        num_players (int): 2-6  (default 2)
        num_dice    (int): 3-6  (default 5)
        sides       (int): 4/6/8/10/12/20  (default 6)
        rounds      (int): 1-5  (default 1)
        max_rolls   (int): 1-5  rolls per turn (default 3)

    Each turn a player rolls unheld dice (up to *max_rolls* times), holds
    desired dice, then scores the sum.  After all players have taken a turn
    for *rounds* rounds, the player with the highest cumulative score wins.
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._num_players = max(2, min(6, config.get("num_players", 2)))
        self._num_dice = max(3, min(6, config.get("num_dice", 5)))
        self._sides = config.get("sides", 6)
        self._rounds = max(1, min(5, config.get("rounds", 1)))
        self._max_rolls = max(1, min(5, config.get("max_rolls", 3)))

    def _player_ids(self) -> List[str]:
        return [f"p{i}" for i in range(self._num_players)]

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()
        return {
            "players": players,
            "current_player_idx": 0,
            "dice": [0] * self._num_dice,       # values of current roll
            "held": [False] * self._num_dice,    # which dice are locked
            "roll_count": 0,                      # rolls taken this turn
            "scores": {p: 0 for p in players},
            "round": 0,
            "phase": "playing",                   # "playing" | "finished"
        }

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] != "playing":
            return []
        actions: List[str] = []
        if state["roll_count"] < self._max_rolls:
            # Can roll any unheld dice
            if any(not h for h in state["held"]):
                actions.append("roll")
        for i in range(self._num_dice):
            if state["dice"][i] == 0:
                # Dice not rolled yet this turn — must roll first
                pass
            elif state["held"][i]:
                actions.append(f"unhold_{i}")
            else:
                actions.append(f"hold_{i}")
        # Can end turn if at least one roll taken
        if state["roll_count"] > 0:
            actions.append("end_turn")
        return actions

    def apply(self, state: dict, action: str) -> dict:
        s = dict(state)
        players = s["players"]
        idx = s["current_player_idx"]
        player = players[idx]

        if action == "roll":
            new_dice = list(s["dice"])
            new_held = list(s["held"])
            for i in range(self._num_dice):
                if not new_held[i]:
                    new_dice[i] = self._rng.randint(1, self._sides)
            s["dice"] = new_dice
            s["held"] = new_held
            s["roll_count"] = s["roll_count"] + 1

        elif action.startswith("hold_"):
            i = int(action[5:])
            new_held = list(s["held"])
            new_held[i] = True
            s["held"] = new_held

        elif action.startswith("unhold_"):
            i = int(action[7:])
            new_held = list(s["held"])
            new_held[i] = False
            s["held"] = new_held

        elif action == "end_turn":
            # Score the current dice
            new_scores = dict(s["scores"])
            new_scores[player] = new_scores.get(player, 0) + sum(s["dice"])
            s["scores"] = new_scores
            # Reset for next player
            s["dice"] = [0] * self._num_dice
            s["held"] = [False] * self._num_dice
            s["roll_count"] = 0
            nxt = idx + 1
            if nxt >= self._num_players:
                nxt = 0
                s["round"] = s["round"] + 1
                if s["round"] >= self._rounds:
                    s["phase"] = "finished"
            s["current_player_idx"] = nxt

        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        best = max(state["scores"].values())
        winners = [p for p, v in state["scores"].items() if v == best]
        if len(winners) != 1:
            return None
        return winners[0]

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        if "roll" in legal and persona in ("aggressive", "greedy"):
            # Aggressive: reroll aggressively; only hold ≥ 2/3 of max
            threshold = int(self._sides * 0.66) + 1
            for i in range(self._num_dice):
                if not state["held"][i] and state["dice"][i] >= threshold:
                    if f"hold_{i}" in legal and state["dice"][i] > 0:
                        # Hold good dice
                        pass  # fall through to roll the rest

            # Count how many unheld dice are "keepers"
            keepers = sum(1 for i in range(self._num_dice)
                          if not state["held"][i] and state["dice"][i] >= threshold)

            if keepers == sum(1 for h in state["held"] if not h):
                # No unheld dice to reroll — end turn
                if "end_turn" in legal:
                    return "end_turn"
            # Hold the good ones first, then roll
            for i in range(self._num_dice):
                if not state["held"][i] and state["dice"][i] >= threshold and state["dice"][i] > 0:
                    if f"hold_{i}" in legal:
                        return f"hold_{i}"
            if "roll" in legal:
                return "roll"
            if "end_turn" in legal:
                return "end_turn"

        if persona == "conservative":
            threshold = int(self._sides * 0.4) + 1
            for i in range(self._num_dice):
                if not state["held"][i] and state["dice"][i] >= threshold and state["dice"][i] > 0:
                    if f"hold_{i}" in legal:
                        return f"hold_{i}"

            # If we've rolled all dice above threshold, end turn
            all_held_or_good = all(
                state["held"][i] or state["dice"][i] >= threshold
                for i in range(self._num_dice) if state["dice"][i] > 0
            )
            if all_held_or_good and "end_turn" in legal:
                return "end_turn"

            if "roll" in legal and any(not state["held"][i] and state["dice"][i] < threshold for i in range(self._num_dice)):
                return "roll"
            if "end_turn" in legal:
                return "end_turn"

        # reckless or fallback
        return legal[self._rng.randint(0, len(legal) - 1)]


# ===================================================================
# BettingKernel — betting / bluffing (押注诈唬类)
# ===================================================================
class BettingKernel(GameKernel):
    """Simplified poker-style betting with a single round and showdown.

    Config:
        num_players    (int): 2-6  (default 2)
        starting_chips (int): per-player chip stack (default 100)
        min_bet        (int): minimum bet amount (default 10)
        max_raise      (int): maximum raise amount (default 50)

    Each player is dealt a hidden hand strength (0.0-1.0).  Players act in
    order, choosing to check, bet, call, raise, or fold.  After all active
    players have matched the current bet, showdown compares hand strengths.

    Cheating (config["cheater"]): the cheating player always knows all
    opponents' hand strengths (engine rule).
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._num_players = max(2, min(6, config.get("num_players", 2)))
        self._starting_chips = max(10, config.get("starting_chips", 100))
        self._min_bet = max(1, config.get("min_bet", 10))
        self._max_raise = max(self._min_bet, config.get("max_raise", 50))
        self._cheater: Optional[str] = config.get("cheater")

    def _player_ids(self) -> List[str]:
        return [f"p{i}" for i in range(self._num_players)]

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()
        hands: Dict[str, float] = {p: round(self._rng.random(), 3) for p in players}
        return {
            "player_order": list(players),
            "chips": {p: self._starting_chips for p in players},
            "player_bets": {p: 0 for p in players},
            "pot": 0,
            "current_bet": 0,
            "hand_strength": hands,
            "folded": {p: False for p in players},
            "turn_queue": list(players),   # players who still need to act
            "current_player": players[0],
            "phase": "betting",             # "betting" | "showdown" | "finished"
        }

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] != "betting":
            return []
        player = state["current_player"]
        if state["folded"][player]:
            return []
        acts: List[str] = []
        cb = state["current_bet"]
        pb = state["player_bets"][player]
        chips = state["chips"][player]
        deficit = cb - pb

        if deficit == 0:
            acts.append("check")
        if deficit > 0 and chips >= deficit:
            acts.append("call")
        if deficit > 0 and chips < deficit:
            # Can't call — all-in
            pass

        # Can bet if no outstanding bet
        if cb == 0 and chips >= self._min_bet:
            acts.append(f"bet_{self._min_bet}")

        # Can raise if there is an outstanding bet
        if cb > 0 and chips > deficit:
            # raise by min_bet more
            raise_amount = min(cb + self._min_bet, chips)
            if raise_amount > cb:
                acts.append(f"raise_{raise_amount}")

        acts.append("fold")
        return acts

    def apply(self, state: dict, action: str) -> dict:
        s = dict(state)
        player = s["current_player"]
        chips = s["chips"][player]
        pb = s["player_bets"][player]
        cb = s["current_bet"]
        players = s["player_order"]

        # Process action
        if action == "fold":
            new_folded = dict(s["folded"])
            new_folded[player] = True
            s["folded"] = new_folded
        elif action == "check":
            pass  # no chips change
        elif action == "call":
            deficit = cb - pb
            call_amt = min(deficit, chips)
            new_chips = dict(s["chips"])
            new_chips[player] = chips - call_amt
            s["chips"] = new_chips
            new_bets = dict(s["player_bets"])
            new_bets[player] = pb + call_amt
            s["player_bets"] = new_bets
            s["pot"] = s["pot"] + call_amt
        elif action.startswith("bet_"):
            amt = int(action[4:])
            amt = min(amt, chips)
            new_chips = dict(s["chips"])
            new_chips[player] = chips - amt
            s["chips"] = new_chips
            new_bets = dict(s["player_bets"])
            new_bets[player] = pb + amt
            s["player_bets"] = new_bets
            s["pot"] = s["pot"] + amt
            s["current_bet"] = pb + amt
            # Reset turn queue after a bet — all non-folded except better need to act
            new_q = [p for p in players if not s["folded"].get(p, False) and p != player]
            s["turn_queue"] = new_q
        elif action.startswith("raise_"):
            total = int(action[6:])
            add = total - pb  # total chips player will have put in
            add = min(add, chips)
            new_chips = dict(s["chips"])
            new_chips[player] = chips - add
            s["chips"] = new_chips
            new_bets = dict(s["player_bets"])
            new_bets[player] = pb + add
            s["player_bets"] = new_bets
            s["pot"] = s["pot"] + add
            s["current_bet"] = pb + add
            # Reset queue after a raise
            new_q = [p for p in players if not s["folded"].get(p, False) and p != player]
            s["turn_queue"] = new_q

        # Remove current player from queue if not already reset by bet/raise
        if "turn_queue" not in s.get("_skip_queue_removal", {}):
            q = list(s["turn_queue"])
            if player in q:
                q.remove(player)
            s["turn_queue"] = q

        # Check for end of betting round
        active = [p for p in players if not s["folded"][p]]
        if len(active) <= 1:
            # Only one active — they win without showdown
            s["phase"] = "finished"
        elif not s["turn_queue"]:
            # Queue empty — all active have acted and bets are matched
            s["phase"] = "showdown"
        else:
            # Advance to next player in queue
            s["current_player"] = s["turn_queue"][0]

        # If we entered showdown, resolve it
        if s["phase"] == "showdown":
            return self._resolve_showdown(s)

        return s

    def _resolve_showdown(self, state: dict) -> dict:
        s = dict(state)
        active = [p for p in s["player_order"] if not s["folded"][p]]
        if not active:
            s["phase"] = "finished"
            return s
        # Highest hand strength wins the pot
        best_p = max(active, key=lambda p: s["hand_strength"][p])
        # Check for tie
        best_hs = s["hand_strength"][best_p]
        winners = [p for p in active if s["hand_strength"][p] == best_hs]
        if len(winners) == 1:
            new_chips = dict(s["chips"])
            new_chips[best_p] = new_chips[best_p] + s["pot"]
            s["chips"] = new_chips
        else:
            # Split pot among tied winners
            split = s["pot"] // len(winners)
            remainder = s["pot"] % len(winners)
            new_chips = dict(s["chips"])
            for p in winners:
                new_chips[p] = new_chips[p] + split
            new_chips[winners[0]] = new_chips[winners[0]] + remainder
            s["chips"] = new_chips
        s["pot"] = 0
        s["phase"] = "finished"
        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        # Winner is the player with all the chips (or most, after showdown)
        best = max(state["chips"].values())
        winners = [p for p, v in state["chips"].items() if v == best]
        if len(winners) != 1:
            return None
        return winners[0]

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        player = state["current_player"]
        hs = state["hand_strength"][player]
        chips = state["chips"][player]
        cb = state["current_bet"]
        pb = state["player_bets"][player]
        deficit = cb - pb

        cheater_visible: Dict[str, float] = {}
        if persona == "cheater" and self._cheater == player:
            cheater_visible = {p: state["hand_strength"][p]
                               for p in state["player_order"] if p != player}

        if persona in ("greedy", "aggressive"):
            # Bet/raise when hand is strong or medium (bluff potential)
            if hs > 0.7:
                # Strong hand — bet or raise aggressively
                for a in legal:
                    if a.startswith("raise_"):
                        return a
                for a in legal:
                    if a.startswith("bet_"):
                        return a
                if "call" in legal:
                    return "call"
            elif hs > 0.4:
                # Medium — bluff-raise or call
                for a in legal:
                    if a.startswith("raise_") and self._rng.random() < 0.3:
                        return a
                if "call" in legal and self._rng.random() < 0.6:
                    return "call"
                if "check" in legal:
                    return "check"
            else:
                # Weak — call or check, sometimes bluff
                if deficit == 0 and "check" in legal:
                    if self._rng.random() < 0.15:
                        # Bluff sometimes
                        for a in legal:
                            if a.startswith("bet_"):
                                return a
                    return "check"
                if "call" in legal and self._rng.random() < 0.2:
                    return "call"
                return "fold"

        elif persona == "conservative":
            # Only bet/raise with very strong hands; fold weak ones
            if hs > 0.85:
                for a in legal:
                    if a.startswith("raise_"):
                        return a
                for a in legal:
                    if a.startswith("bet_"):
                        return a
                if "call" in legal:
                    return "call"
            elif hs > 0.6:
                if "call" in legal:
                    return "call"
                if "check" in legal:
                    return "check"
                return "fold"
            else:
                if deficit == 0 and "check" in legal:
                    return "check"
                return "fold"

        elif persona == "cheater" and self._cheater == player:
            # Cheater knows everyone's hand strength — exploit ruthlessly
            my_rank = sum(1 for v in cheater_visible.values() if v < hs)
            total_opponents = len(cheater_visible)
            if my_rank == total_opponents:
                # Best hand — bet/raise
                for a in legal:
                    if a.startswith("raise_"):
                        return a
                for a in legal:
                    if a.startswith("bet_"):
                        return a
                if "call" in legal:
                    return "call"
            elif my_rank >= total_opponents * 0.5:
                # Above average — call/check
                if "check" in legal:
                    return "check"
                if "call" in legal:
                    return "call"
                return "fold"
            else:
                # Below average — fold unless cheap to check
                if deficit == 0 and "check" in legal:
                    return "check"
                return "fold"

        # reckless or fallback — random
        return legal[self._rng.randint(0, len(legal) - 1)]


# ===================================================================
# TrickTakingKernel — trump-suit trick taking over multiple rounds
# ===================================================================
class TrickTakingKernel(GameKernel):
    """Trump-suit trick-taking game played over multiple rounds.

    Config:
        num_players    (int): 2-6  (default 4)
        cards_per_hand (int): 1-13 (default 7)
        num_rounds     (int): 1-5  (default 2)
        trump          (str|None): fixed trump suit 'S'/'H'/'D'/'C', or
                       None to draw trump from the deck each round.

    Rules:
        - A 52-card deck is shuffled each round; cards_per_hand dealt to each
          player.  If trump is None, the next card sets the trump suit.
        - Players must follow the led suit if able; otherwise any card
          (including trump) may be played.
        - A trick is won by the highest trump played, or — if no trump was
          played — by the highest card of the led suit.  Winner leads next.
        - After each hand, tricks_won accrue to a cumulative score.  After
          num_rounds hands, the player with the most cumulative tricks wins.
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._num_players = max(2, min(6, config.get("num_players", 4)))
        self._cards_per_hand = max(1, min(13, config.get("cards_per_hand", 7)))
        self._num_rounds = max(1, min(5, config.get("num_rounds", 2)))
        self._trump: Optional[str] = config.get("trump")

    def _player_ids(self) -> List[str]:
        return [f"p{i}" for i in range(self._num_players)]

    def _deal_round(self, state: dict) -> dict:
        """Shuffle and deal a fresh hand for the current round."""
        players = self._player_ids()
        deck = [_card_str(s, r) for s in SUITS for r in RANKS]
        self._rng.shuffle(deck)
        max_per = (52 - (0 if self._trump else 1)) // self._num_players
        per = min(self._cards_per_hand, max_per)
        hands: Dict[str, List[str]] = {}
        for i, p in enumerate(players):
            h = deck[i * per:(i + 1) * per]
            h.sort(key=lambda c: (SUIT_ORDER[_card_suit(c)], _card_rank(c)))
            hands[p] = h
        trump = self._trump if self._trump else _card_suit(deck[per * self._num_players])
        state["hands"] = hands
        state["trump"] = trump
        state["current_trick"] = []
        state["led_suit"] = None
        state["tricks_this_round"] = 0
        state["tricks_won"] = {p: 0 for p in players}
        return state

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()
        state: dict = {
            "players": players,
            "hands": {},
            "current_trick": [],
            "tricks_won": {p: 0 for p in players},
            "cumulative": {p: 0 for p in players},
            "current_player": players[0],
            "led_suit": None,
            "trump": None,
            "round": 0,
            "tricks_this_round": 0,
            "phase": "playing",          # "playing" | "finished"
        }
        self._deal_round(state)
        return state

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] != "playing":
            return []
        player = state["current_player"]
        hand = state["hands"][player]
        if not hand:
            return []
        led = state["led_suit"]
        if led is None:
            return [f"play_{c}" for c in hand]
        follows = [c for c in hand if _card_suit(c) == led]
        if follows:
            return [f"play_{c}" for c in follows]
        return [f"play_{c}" for c in hand]

    def apply(self, state: dict, action: str) -> dict:
        assert action.startswith("play_")
        card = action[5:]
        s = dict(state)
        s["hands"] = {p: list(h) for p, h in s["hands"].items()}
        s["tricks_won"] = dict(s["tricks_won"])
        s["cumulative"] = dict(s["cumulative"])
        s["current_trick"] = list(s["current_trick"])
        player = s["current_player"]
        s["hands"][player] = [c for c in s["hands"][player] if c != card]
        trick = s["current_trick"]
        trick.append((player, card))
        if s["led_suit"] is None:
            s["led_suit"] = _card_suit(card)
        players = s["players"]
        if len(trick) >= self._num_players:
            led = s["led_suit"]
            trump = s["trump"]
            trumped = [(p, c) for p, c in trick if trump and _card_suit(c) == trump]
            if trumped:
                winner_id = max(trumped, key=lambda x: _card_rank(x[1]))[0]
            else:
                cands = [(p, c) for p, c in trick if _card_suit(c) == led] or trick
                winner_id = max(cands, key=lambda x: _card_rank(x[1]))[0]
            s["tricks_won"][winner_id] = s["tricks_won"].get(winner_id, 0) + 1
            s["tricks_this_round"] = s["tricks_this_round"] + 1
            s["current_trick"] = []
            s["led_suit"] = None
            s["current_player"] = winner_id
            if s["tricks_this_round"] >= self._cards_per_hand:
                for p in players:
                    s["cumulative"][p] += s["tricks_won"].get(p, 0)
                s["round"] = s["round"] + 1
                if s["round"] >= self._num_rounds:
                    s["phase"] = "finished"
                else:
                    self._deal_round(s)
                    s["current_player"] = players[0]
        else:
            idx = players.index(player)
            s["current_player"] = players[(idx + 1) % self._num_players]
        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        best = max(state["cumulative"].values())
        winners = [p for p, v in state["cumulative"].items() if v == best]
        if len(winners) != 1:
            return None
        return winners[0]

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        player = state["current_player"]
        hand = [a[5:] for a in legal]
        led = state["led_suit"]
        trump = state["trump"]
        trick = state["current_trick"]

        if persona in ("greedy", "aggressive"):
            if led is None:
                non_trump = [c for c in hand if _card_suit(c) != trump]
                c = max(non_trump, key=_card_rank) if non_trump else min(hand, key=_card_rank)
            else:
                trump_played = [c for _, c in trick if trump and _card_suit(c) == trump]
                follows = [c for c in hand if _card_suit(c) == led]
                if follows:
                    if trump_played:
                        c = min(follows, key=_card_rank)
                    else:
                        best_led = max((c for _, c in trick if _card_suit(c) == led), key=_card_rank)
                        winners = [x for x in follows if _card_rank(x) > _card_rank(best_led)]
                        c = min(winners, key=_card_rank) if winners else min(follows, key=_card_rank)
                else:
                    trumps = [x for x in hand if _card_suit(x) == trump]
                    if trumps and not trump_played:
                        c = min(trumps, key=_card_rank)
                    elif trumps and trump_played:
                        best_t = max(trump_played, key=_card_rank)
                        beat = [x for x in trumps if _card_rank(x) > _card_rank(best_t)]
                        c = min(beat, key=_card_rank) if beat else min(hand, key=_card_rank)
                    else:
                        c = min(hand, key=_card_rank)
        elif persona == "conservative":
            if led is None:
                non_trump = [c for c in hand if _card_suit(c) != trump]
                c = min(non_trump, key=_card_rank) if non_trump else min(hand, key=_card_rank)
            else:
                follows = [c for c in hand if _card_suit(c) == led]
                if follows:
                    c = min(follows, key=_card_rank)
                else:
                    non_trump = [c for c in hand if _card_suit(c) != trump]
                    c = min(non_trump, key=_card_rank) if non_trump else min(hand, key=_card_rank)
        else:
            c = hand[self._rng.randint(0, len(hand) - 1)]
        return f"play_{c}"

    def check_invariants(self, state: dict) -> bool:
        players = state["players"]
        for p in players:
            assert p in state["hands"]
            assert p in state["tricks_won"]
            assert p in state["cumulative"]
        assert len(state["current_trick"]) < self._num_players
        assert 0 <= state["round"] <= self._num_rounds
        if state["phase"] == "finished":
            assert all(len(h) == 0 for h in state["hands"].values())
            assert sum(state["cumulative"].values()) == self._num_rounds * self._cards_per_hand
        else:
            cards_in_hands = sum(len(h) for h in state["hands"].values())
            played = state["tricks_this_round"] * self._num_players + len(state["current_trick"])
            assert cards_in_hands + played == self._cards_per_hand * self._num_players
        return True


# ===================================================================
# SetCollectionKernel — collect sets of matching tiles (凑集类)
# ===================================================================
class SetCollectionKernel(GameKernel):
    """Rummy-style set-collection game.

    Config:
        num_players (int): 2-6 (default 3)
        ranks       (int): 3-12 distinct ranks (default 6)
        copies      (int): 3-6 copies per rank (default 4)
        pool_size   (int): 2-5 face-up pool tiles (default 3)

    Rules:
        - A deck of ranks*copies tiles is shuffled.  pool_size tiles form the
          face-up pool; the rest is the draw deck.
        - On your turn, take one tile from the pool into your hand.  Whenever
          your hand holds 3+ tiles of the same rank, 3 of them are banked
          automatically as a completed set worth 3 points.  The emptied pool
          slot is refilled from the deck if possible.
        - Game ends when deck and pool are both empty.  Most banked tiles wins.
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._num_players = max(2, min(6, config.get("num_players", 3)))
        self._ranks = max(3, min(12, config.get("ranks", 6)))
        self._copies = max(3, min(6, config.get("copies", 4)))
        self._pool_size = max(2, min(5, config.get("pool_size", 3)))

    def _player_ids(self) -> List[str]:
        return [f"p{i}" for i in range(self._num_players)]

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()
        tiles = [f"r{r}" for r in range(1, self._ranks + 1) for _ in range(self._copies)]
        self._rng.shuffle(tiles)
        pool = tiles[:self._pool_size]
        deck = tiles[self._pool_size:]
        return {
            "players": players,
            "deck": deck,
            "pool": pool,
            "hands": {p: [] for p in players},
            "banked": {p: [] for p in players},   # list of 3-tile sets
            "scores": {p: 0 for p in players},
            "current_player_idx": 0,
            "phase": "playing",                   # "playing" | "finished"
        }

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] != "playing":
            return []
        return [f"take_{i}" for i in range(len(state["pool"]))]

    def apply(self, state: dict, action: str) -> dict:
        assert action.startswith("take_")
        idx = int(action[5:])
        s = dict(state)
        s["deck"] = list(s["deck"])
        s["pool"] = list(s["pool"])
        s["hands"] = {p: list(h) for p, h in s["hands"].items()}
        s["banked"] = {p: list(b) for p, b in s["banked"].items()}
        s["scores"] = dict(s["scores"])
        player = s["players"][s["current_player_idx"]]
        tile = s["pool"].pop(idx)
        s["hands"][player].append(tile)
        # auto-bank: while any rank has 3+ in hand, bank 3
        hand = s["hands"][player]
        counts = Counter(hand)
        for rank, cnt in list(counts.items()):
            while cnt >= 3:
                removed = 0
                new_hand: List[str] = []
                for t in hand:
                    if t == rank and removed < 3:
                        removed += 1
                    else:
                        new_hand.append(t)
                hand = new_hand
                s["banked"][player].append([rank, rank, rank])
                s["scores"][player] += 3
                cnt -= 3
            s["hands"][player] = hand
        # refill pool slot
        if s["deck"]:
            s["pool"].append(s["deck"].pop(0))
        # advance turn
        nxt = s["current_player_idx"] + 1
        if nxt >= self._num_players:
            nxt = 0
        s["current_player_idx"] = nxt
        if not s["pool"] and not s["deck"]:
            s["phase"] = "finished"
        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        best = max(state["scores"].values())
        winners = [p for p, v in state["scores"].items() if v == best]
        if len(winners) != 1:
            return None
        return winners[0]

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        player = state["players"][state["current_player_idx"]]
        hand_counts = Counter(state["hands"][player])

        def tile_rank(t: str) -> int:
            return int(t[1:])

        if persona in ("greedy", "aggressive"):
            best_i, best_score = 0, -1
            for i, t in enumerate(state["pool"]):
                sc = hand_counts.get(t, 0)
                if sc > best_score or (sc == best_score and tile_rank(t) < tile_rank(state["pool"][best_i])):
                    best_score, best_i = sc, i
            return f"take_{best_i}"
        if persona == "conservative":
            best_i, best_score = 0, -1
            for i, t in enumerate(state["pool"]):
                sc = hand_counts.get(t, 0)
                if sc > best_score:
                    best_score, best_i = sc, i
            return f"take_{best_i}"
        return legal[self._rng.randint(0, len(legal) - 1)]

    def check_invariants(self, state: dict) -> bool:
        total = len(state["deck"]) + len(state["pool"])
        for p in state["players"]:
            total += len(state["hands"][p])
            for s_set in state["banked"][p]:
                assert len(s_set) == 3
                total += len(s_set)
        assert total == self._ranks * self._copies
        for p in state["players"]:
            c = Counter(state["hands"][p])
            for v in c.values():
                assert v < 3, f"{p} hand has {v} of a rank"
            assert state["scores"][p] == 3 * len(state["banked"][p])
        return True


# ===================================================================
# MemoryKernel — concentration / matching (记忆类)
# ===================================================================
class MemoryKernel(GameKernel):
    """Memory / concentration matching game.

    Config:
        num_pairs   (int): 3-15 (default 6)
        num_players (int): 2-6 (default 2)

    Rules:
        - 2*num_pairs cards (values 1..num_pairs, each twice) are shuffled
          face-down.  On your turn flip two cards.  Matching values score a
          pair and the cards stay face up; otherwise they flip back.  Play
          passes to the next player either way.  Game ends when all pairs are
          found; most pairs wins.
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._num_pairs = max(3, min(15, config.get("num_pairs", 6)))
        self._num_players = max(2, min(6, config.get("num_players", 2)))

    def _player_ids(self) -> List[str]:
        return [f"p{i}" for i in range(self._num_players)]

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()
        values = list(range(1, self._num_pairs + 1)) * 2
        self._rng.shuffle(values)
        return {
            "players": players,
            "positions": values,            # card value at each position
            "revealed": {},                 # pos -> value, ever flipped
            "matched": {},                 # pos -> owner
            "first_pick": None,
            "current_player_idx": 0,
            "scores": {p: 0 for p in players},
            "phase": "select1",             # "select1" | "select2" | "finished"
        }

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] not in ("select1", "select2"):
            return []
        acts: List[str] = []
        for i in range(len(state["positions"])):
            if i in state["matched"]:
                continue
            if state["phase"] == "select2" and i == state["first_pick"]:
                continue
            acts.append(f"flip_{i}")
        return acts

    def apply(self, state: dict, action: str) -> dict:
        assert action.startswith("flip_")
        i = int(action[5:])
        s = dict(state)
        s["revealed"] = dict(s["revealed"])
        s["matched"] = dict(s["matched"])
        s["scores"] = dict(s["scores"])
        player = s["players"][s["current_player_idx"]]
        s["revealed"][i] = s["positions"][i]
        if s["phase"] == "select1":
            s["first_pick"] = i
            s["phase"] = "select2"
        else:
            j = s["first_pick"]
            if s["positions"][i] == s["positions"][j]:
                s["matched"][i] = player
                s["matched"][j] = player
                s["scores"][player] += 1
            s["first_pick"] = None
            nxt = s["current_player_idx"] + 1
            if nxt >= self._num_players:
                nxt = 0
            s["current_player_idx"] = nxt
            s["phase"] = "select1"
            if len(s["matched"]) >= len(s["positions"]):
                s["phase"] = "finished"
        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        best = max(state["scores"].values())
        winners = [p for p, v in state["scores"].items() if v == best]
        if len(winners) != 1:
            return None
        return winners[0]

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        revealed = state["revealed"]
        matched = state["matched"]
        n = len(state["positions"])

        def known_pair() -> Optional[int]:
            by_val: Dict[int, List[int]] = {}
            for pos, v in revealed.items():
                if pos in matched:
                    continue
                by_val.setdefault(v, []).append(pos)
            for v, ps in by_val.items():
                if len(ps) >= 2:
                    return ps[0]
            return None

        if persona in ("greedy", "aggressive", "conservative"):
            if state["phase"] == "select1":
                pair = known_pair()
                if pair is not None:
                    return f"flip_{pair}"
                unknown = [i for i in range(n) if i not in revealed and i not in matched]
                if unknown:
                    return f"flip_{unknown[0]}"
                known = [i for i in range(n) if i in revealed and i not in matched]
                return f"flip_{known[0]}"
            # select2: find mate of first_pick
            first = state["first_pick"]
            target = state["positions"][first]
            for pos, v in revealed.items():
                if pos == first or pos in matched:
                    continue
                if v == target:
                    return f"flip_{pos}"
            unknown = [i for i in range(n) if i not in revealed and i not in matched and i != first]
            if unknown:
                return f"flip_{unknown[0]}"
            known = [i for i in range(n) if i in revealed and i not in matched and i != first]
            return f"flip_{known[0]}" if known else legal[self._rng.randint(0, len(legal) - 1)]
        return legal[self._rng.randint(0, len(legal) - 1)]

    def check_invariants(self, state: dict) -> bool:
        n = 2 * self._num_pairs
        assert len(state["positions"]) == n
        c = Counter(state["positions"])
        for v in range(1, self._num_pairs + 1):
            assert c[v] == 2
        assert len(state["matched"]) % 2 == 0
        assert sum(state["scores"].values()) == len(state["matched"]) // 2
        if state["phase"] == "select1":
            assert state["first_pick"] is None
        elif state["phase"] == "select2":
            assert state["first_pick"] is not None
        return True


# ===================================================================
# AbstractStrategyKernel — perfect-info placement game (抽象策略类)
# ===================================================================
class AbstractStrategyKernel(GameKernel):
    """Generalized m,n,k placement game (tic-tac-toe / gomoku-lite).

    Config:
        width       (int): 3-9 (default 3)
        height      (int): 3-9 (default 3)
        win_length  (int): 3-5 (default 3), clamped to board dimension
        num_players (int): 2-4 (default 2)

    Rules:
        - Players alternate placing their mark on an empty cell of a
          width×height grid.  First to align win_length marks horizontally,
          vertically, or diagonally wins.  A full board with no winner is a
          draw.
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._width = max(3, min(9, config.get("width", 3)))
        self._height = max(3, min(9, config.get("height", 3)))
        max_win = max(self._width, self._height)
        self._win_length = max(3, min(5, min(max_win, config.get("win_length", 3))))
        self._num_players = max(2, min(4, config.get("num_players", 2)))

    def _player_ids(self) -> List[str]:
        return [f"p{i}" for i in range(self._num_players)]

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()
        return {
            "players": players,
            "board": [None] * (self._width * self._height),
            "current_player_idx": 0,
            "winner_id": None,
            "phase": "playing",            # "playing" | "finished"
        }

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] != "playing":
            return []
        return [f"place_{i}" for i, v in enumerate(state["board"]) if v is None]

    def _check_win(self, board: List[Optional[str]], pos: int) -> Optional[str]:
        w, h, k = self._width, self._height, self._win_length
        x = pos % w
        y = pos // w
        player = board[pos]
        if player is None:
            return None
        for dx, dy in [(1, 0), (0, 1), (1, 1), (1, -1)]:
            count = 1
            nx, ny = x + dx, y + dy
            while 0 <= nx < w and 0 <= ny < h and board[ny * w + nx] == player:
                count += 1
                nx += dx
                ny += dy
            nx, ny = x - dx, y - dy
            while 0 <= nx < w and 0 <= ny < h and board[ny * w + nx] == player:
                count += 1
                nx -= dx
                ny -= dy
            if count >= k:
                return player
        return None

    def apply(self, state: dict, action: str) -> dict:
        assert action.startswith("place_")
        i = int(action[6:])
        s = dict(state)
        s["board"] = list(s["board"])
        assert s["board"][i] is None
        player = s["players"][s["current_player_idx"]]
        s["board"][i] = player
        win = self._check_win(s["board"], i)
        if win is not None:
            s["winner_id"] = win
            s["phase"] = "finished"
        elif all(v is not None for v in s["board"]):
            s["phase"] = "finished"
        else:
            nxt = s["current_player_idx"] + 1
            if nxt >= self._num_players:
                nxt = 0
            s["current_player_idx"] = nxt
        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        return state["winner_id"]

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        board = state["board"]
        player = state["players"][state["current_player_idx"]]
        opponents = [p for p in state["players"] if p != player]

        def winning_move(for_player: str) -> Optional[int]:
            for i, v in enumerate(board):
                if v is not None:
                    continue
                b2 = list(board)
                b2[i] = for_player
                if self._check_win(b2, i) == for_player:
                    return i
            return None

        if persona in ("greedy", "aggressive", "conservative"):
            win = winning_move(player)
            if win is not None:
                return f"place_{win}"
            for opp in opponents:
                blk = winning_move(opp)
                if blk is not None:
                    return f"place_{blk}"
            w, h = self._width, self._height
            center = (h // 2) * w + (w // 2)
            if board[center] is None:
                return f"place_{center}"
            corners = [0, w - 1, (h - 1) * w, h * w - 1]
            for c in corners:
                if c < len(board) and board[c] is None:
                    return f"place_{c}"
            return legal[0]
        return legal[self._rng.randint(0, len(legal) - 1)]

    def check_invariants(self, state: dict) -> bool:
        assert len(state["board"]) == self._width * self._height
        for v in state["board"]:
            assert v is None or v in state["players"]
        if state["phase"] == "finished" and state["winner_id"] is not None:
            assert state["winner_id"] in state["players"]
        if state["phase"] == "playing":
            vals = [sum(1 for v in state["board"] if v == p) for p in state["players"]]
            assert max(vals) - min(vals) <= 1
            cur = state["players"][state["current_player_idx"]]
            assert sum(1 for v in state["board"] if v == cur) == min(vals)
        return True


# ===================================================================
# GuessingKernel — number guessing / logic deduction (猜谜类)
# ===================================================================
class GuessingKernel(GameKernel):
    """Number-guessing / logic-deduction game.

    Config:
        num_players (int): 2-6 (default 2)
        range_min   (int): default 1
        range_max   (int): default 100
        max_guesses (int): per-player guess budget (default 7)

    Rules:
        - A secret integer in [range_min, range_max] is drawn from the seed.
        - Players take turns guessing; the engine replies "higher"/"lower"/
          "correct".  A correct guess wins immediately.  If all players exhaust
          max_guesses each without a correct guess, the game ends with no
          winner.
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._num_players = max(2, min(6, config.get("num_players", 2)))
        self._range_min = config.get("range_min", 1)
        self._range_max = config.get("range_max", 100)
        if self._range_max <= self._range_min:
            self._range_max = self._range_min + 1
        self._max_guesses = max(1, min(20, config.get("max_guesses", 7)))

    def _player_ids(self) -> List[str]:
        return [f"p{i}" for i in range(self._num_players)]

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()
        secret = self._rng.randint(self._range_min, self._range_max)
        return {
            "players": players,
            "secret": secret,
            "guesses": {p: [] for p in players},
            "guesses_used": 0,
            "max_total": self._max_guesses * self._num_players,
            "low": self._range_min - 1,    # secret > low
            "high": self._range_max + 1,   # secret < high
            "current_player_idx": 0,
            "feedback": None,
            "winner_id": None,
            "phase": "playing",            # "playing" | "finished"
        }

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] != "playing":
            return []
        return [f"guess_{n}" for n in range(self._range_min, self._range_max + 1)]

    def apply(self, state: dict, action: str) -> dict:
        assert action.startswith("guess_")
        n = int(action[6:])
        s = dict(state)
        s["guesses"] = {p: list(g) for p, g in s["guesses"].items()}
        player = s["players"][s["current_player_idx"]]
        s["guesses"][player].append(n)
        s["guesses_used"] = s["guesses_used"] + 1
        if n == s["secret"]:
            s["feedback"] = "correct"
            s["phase"] = "finished"
            s["winner_id"] = player
            return s
        if n < s["secret"]:
            s["feedback"] = "higher"
            if n > s["low"]:
                s["low"] = n
        else:
            s["feedback"] = "lower"
            if n < s["high"]:
                s["high"] = n
        nxt = s["current_player_idx"] + 1
        if nxt >= self._num_players:
            nxt = 0
        s["current_player_idx"] = nxt
        if s["guesses_used"] >= s["max_total"]:
            s["phase"] = "finished"
            s["winner_id"] = None
        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        return state["winner_id"]

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        lo = state["low"] + 1
        hi = state["high"] - 1
        if lo > hi:
            lo, hi = self._range_min, self._range_max
        if persona in ("greedy", "aggressive", "conservative"):
            mid = (lo + hi) // 2
            mid = max(self._range_min, min(self._range_max, mid))
            return f"guess_{mid}"
        return f"guess_{self._rng.randint(lo, hi)}"

    def check_invariants(self, state: dict) -> bool:
        assert self._range_min <= state["secret"] <= self._range_max
        assert state["low"] < state["secret"] < state["high"]
        assert state["guesses_used"] <= state["max_total"]
        total = sum(len(g) for g in state["guesses"].values())
        assert total == state["guesses_used"]
        for g in state["guesses"].values():
            for n in g:
                assert self._range_min <= n <= self._range_max
        return True


# ===================================================================
# AuctionKernel — sealed-bid auction over multiple items (竞价类)
# ===================================================================
class AuctionKernel(GameKernel):
    """Sealed-bid auction over multiple items with a shared budget.

    Config:
        num_players (int): 2-6 (default 3)
        budget      (int): starting budget per player (default 100)
        num_items   (int): 2-10 (default 5)
        value_min   (int): default 10
        value_max   (int): default 50

    Rules:
        - num_items items are generated with public values in [value_min,
          value_max].  Each player starts with `budget` chips.
        - For each item, players bid in turn (one bid each, visible).  The
          highest bidder wins the item and pays their bid; ties broken in
          favor of the earlier bidder.  A bid of 0 is allowed (pass).
        - After all items are auctioned, profit = sum(won item values) - spent.
          Highest profit wins.
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._num_players = max(2, min(6, config.get("num_players", 3)))
        self._budget = max(10, config.get("budget", 100))
        self._num_items = max(2, min(10, config.get("num_items", 5)))
        self._value_min = max(1, config.get("value_min", 10))
        self._value_max = max(self._value_min + 1, config.get("value_max", 50))

    def _player_ids(self) -> List[str]:
        return [f"p{i}" for i in range(self._num_players)]

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()
        values = [self._rng.randint(self._value_min, self._value_max)
                  for _ in range(self._num_items)]
        return {
            "players": players,
            "item_values": values,
            "item_idx": 0,
            "budgets": {p: self._budget for p in players},
            "spent": {p: 0 for p in players},
            "won_value": {p: 0 for p in players},
            "current_bids": {},
            "bid_order": list(players),
            "current_bidder_idx": 0,
            "phase": "bidding",            # "bidding" | "finished"
        }

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] != "bidding":
            return []
        player = state["bid_order"][state["current_bidder_idx"]]
        budget = state["budgets"][player]
        return [f"bid_{n}" for n in range(0, budget + 1)]

    def apply(self, state: dict, action: str) -> dict:
        assert action.startswith("bid_")
        amt = int(action[4:])
        s = dict(state)
        s["budgets"] = dict(s["budgets"])
        s["spent"] = dict(s["spent"])
        s["won_value"] = dict(s["won_value"])
        s["current_bids"] = dict(s["current_bids"])
        player = s["bid_order"][s["current_bidder_idx"]]
        assert 0 <= amt <= s["budgets"][player]
        s["current_bids"][player] = amt
        nxt = s["current_bidder_idx"] + 1
        if nxt >= self._num_players:
            bids = s["current_bids"]
            best_player: Optional[str] = None
            best_bid = -1
            for p in s["bid_order"]:
                if bids[p] > best_bid:
                    best_bid = bids[p]
                    best_player = p
            if best_player is not None and best_bid > 0:
                s["budgets"][best_player] -= best_bid
                s["spent"][best_player] += best_bid
                s["won_value"][best_player] += s["item_values"][s["item_idx"]]
            s["item_idx"] += 1
            s["current_bids"] = {}
            s["current_bidder_idx"] = 0
            if s["item_idx"] >= self._num_items:
                s["phase"] = "finished"
        else:
            s["current_bidder_idx"] = nxt
        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        profits = {p: state["won_value"][p] - state["spent"][p] for p in state["players"]}
        best = max(profits.values())
        winners = [p for p, v in profits.items() if v == best]
        if len(winners) != 1:
            return None
        return winners[0]

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        player = state["bid_order"][state["current_bidder_idx"]]
        budget = state["budgets"][player]
        item_val = state["item_values"][state["item_idx"]]
        if persona in ("greedy", "aggressive"):
            bid = int(item_val * 0.9)
        elif persona == "conservative":
            bid = int(item_val * 0.5)
        elif persona == "cheater":
            bid = int(item_val * 0.95)
        else:
            bid = self._rng.randint(0, budget)
        bid = max(0, min(bid, budget))
        return f"bid_{bid}"

    def check_invariants(self, state: dict) -> bool:
        total_budget = sum(state["budgets"].values())
        total_spent = sum(state["spent"].values())
        assert total_budget + total_spent == self._num_players * self._budget
        for p in state["players"]:
            assert state["budgets"][p] >= 0
            assert state["spent"][p] >= 0
        assert 0 <= state["item_idx"] <= self._num_items
        assert sum(state["won_value"].values()) <= sum(state["item_values"])
        return True


# ===================================================================
# StrengthContestKernel — RPS-style HP contest (力量对抗类)
# ===================================================================
class StrengthContestKernel(GameKernel):
    """RPS-style strength contest with HP.

    Config:
        num_players (int): fixed at 2
        max_hp      (int): default 20
        rounds      (int): 1-10 (default 5)

    Rules:
        - Two combatants each pick a stance: aggressive / balanced / defensive.
          Stances are revealed in order (p0 then p1) then resolved.  Aggressive
          beats balanced, balanced beats defensive, defensive beats aggressive
          (rock-paper-scissors).  The winner deals 3 damage; on a tie both
          take 1 damage.
        - After `rounds` rounds, or when a combatant's HP reaches 0, the
          combatant with higher HP wins.
    """

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self._num_players = 2
        self._max_hp = max(5, config.get("max_hp", 20))
        self._rounds = max(1, min(10, config.get("rounds", 5)))

    def _player_ids(self) -> List[str]:
        return ["p0", "p1"]

    @staticmethod
    def _beats(a: str, b: str) -> int:
        if a == b:
            return 0
        wins = {("aggressive", "balanced"), ("balanced", "defensive"), ("defensive", "aggressive")}
        return 1 if (a, b) in wins else -1

    def init_state(self) -> dict:
        self._rng = random.Random(self.config.get("seed", 42))
        players = self._player_ids()
        return {
            "players": players,
            "hp": {"p0": self._max_hp, "p1": self._max_hp},
            "round": 0,
            "stances": {},              # player -> stance for current round
            "current_player_idx": 0,
            "phase": "select_p0",       # "select_p0" | "select_p1" | "finished"
            "last_result": None,
        }

    def legal_actions(self, state: dict) -> List[str]:
        if state["phase"] not in ("select_p0", "select_p1"):
            return []
        return ["stance_aggressive", "stance_balanced", "stance_defensive"]

    def apply(self, state: dict, action: str) -> dict:
        assert action.startswith("stance_")
        stance = action[7:]
        assert stance in ("aggressive", "balanced", "defensive")
        s = dict(state)
        s["hp"] = dict(s["hp"])
        s["stances"] = dict(s["stances"])
        player = s["players"][s["current_player_idx"]]
        s["stances"][player] = stance
        if s["phase"] == "select_p0":
            s["phase"] = "select_p1"
            s["current_player_idx"] = 1
        else:
            s0 = s["stances"]["p0"]
            s1 = s["stances"]["p1"]
            r = self._beats(s0, s1)
            if r > 0:
                s["hp"]["p1"] = max(0, s["hp"]["p1"] - 3)
                s["last_result"] = ("p0_wins", s0, s1)
            elif r < 0:
                s["hp"]["p0"] = max(0, s["hp"]["p0"] - 3)
                s["last_result"] = ("p1_wins", s0, s1)
            else:
                s["hp"]["p0"] = max(0, s["hp"]["p0"] - 1)
                s["hp"]["p1"] = max(0, s["hp"]["p1"] - 1)
                s["last_result"] = ("tie", s0, s1)
            s["stances"] = {}
            s["round"] = s["round"] + 1
            s["current_player_idx"] = 0
            if s["hp"]["p0"] <= 0 or s["hp"]["p1"] <= 0 or s["round"] >= self._rounds:
                s["phase"] = "finished"
            else:
                s["phase"] = "select_p0"
        return s

    def is_terminal(self, state: dict) -> bool:
        return state["phase"] == "finished"

    def winner(self, state: dict) -> Optional[str]:
        if not self.is_terminal(state):
            return None
        if state["hp"]["p0"] > state["hp"]["p1"]:
            return "p0"
        if state["hp"]["p1"] > state["hp"]["p0"]:
            return "p1"
        return None

    def bot_action(self, state: dict, persona: str) -> str:
        legal = self.legal_actions(state)
        if not legal:
            return ""
        if persona in ("greedy", "aggressive"):
            r = self._rng.random()
            if r < 0.6:
                return "stance_aggressive"
            if r < 0.9:
                return "stance_balanced"
            return "stance_defensive"
        if persona == "conservative":
            r = self._rng.random()
            if r < 0.6:
                return "stance_defensive"
            if r < 0.9:
                return "stance_balanced"
            return "stance_aggressive"
        return legal[self._rng.randint(0, len(legal) - 1)]

    def check_invariants(self, state: dict) -> bool:
        for p in ("p0", "p1"):
            assert 0 <= state["hp"][p] <= self._max_hp
        assert 0 <= state["round"] <= self._rounds
        if state["phase"] == "select_p0":
            assert state["stances"] == {}
            assert state["current_player_idx"] == 0
        elif state["phase"] == "select_p1":
            assert "p0" in state["stances"]
            assert state["current_player_idx"] == 1
        return True


# ===================================================================
# Registration
# ===================================================================
KERNEL_REGISTRY: Dict[str, type] = {
    "deck": DeckKernel,
    "dice_pool": DicePoolKernel,
    "betting": BettingKernel,
    "trick": TrickTakingKernel,
    "set_collection": SetCollectionKernel,
    "memory": MemoryKernel,
    "abstract_strategy": AbstractStrategyKernel,
    "guessing": GuessingKernel,
    "auction": AuctionKernel,
    "strength": StrengthContestKernel,
}


def match_kernel(description: str) -> str:
    """Match a natural-language description to the nearest kernel name.

    This is a simplified keyword matcher (spec §9.2①).  A full production
    deployment would use embedding kNN instead.
    """
    desc = description.lower()

    # Score each kernel
    patterns: Dict[str, List[str]] = {
        "deck": ["吃墩", "trick", "card", "牌", "扑克", "桥牌", "打牌", "纸牌"],
        "dice_pool": ["骰", "dice", "掷骰", "roll", "yahtzee", "骰子"],
        "betting": ["押注", "bet", "bluff", "诈唬", "poker", "下注", "加注", "德扑", "梭哈"],
        "trick": ["将牌", "王牌", "trump", "吃牌", "墩"],
        "set_collection": ["凑集", "凑套", "凑顺", "rummy", "收集", "成套", "set collection"],
        "memory": ["记忆", "memory", "concentration", "翻牌配对", "配对"],
        "abstract_strategy": ["井字", "tic tac toe", "三连", "抽象策略", "围棋", "五子", "gomoku"],
        "guessing": ["猜数字", "猜谜", "guess", "推理", "猜词", "higher lower"],
        "auction": ["竞价", "拍卖", "auction", "暗标", "明标", "投标"],
        "strength": ["力量对抗", "力量", "对抗", "stance", "格斗", "比武", "rps"],
    }

    best_name = "deck"
    best_score = 0
    for name, keywords in patterns.items():
        score = sum(1 for kw in keywords if kw in desc)
        # Boost: if description contains any Chinese keyword, strongly prefer it
        chinese_kw = [kw for kw in keywords if '一' <= kw <= '鿿']
        score += sum(3 for kw in chinese_kw if kw in desc)
        if score > best_score:
            best_score = score
            best_name = name

    return best_name
