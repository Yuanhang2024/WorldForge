from dataclasses import dataclass
import os
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urlparse


AGENT_ROLES: List[str] = [
    "producer",
    "science_director",
    "world_builder",
]


# ---------------------------------------------------------------------------
# Standard OpenAI defaults. The runtime + onboarding LLM calls go to any
# OpenAI-compatible /v1/chat/completions endpoint. Every value below is
# overridable through the AI_THEATER_* env vars (or a .env file): a user
# points at their provider by setting AI_THEATER_BASE_URL +
# AI_THEATER_MODEL_FAST/DEEP and, when the provider requires it, an API key.
#
# LOCAL_LLM_* constants are retained for backward reference / local-server
# setups (e.g. a user-run LM Studio / Ollama on 127.0.0.1) but are NO
# LONGER the default — the default is the public OpenAI endpoint, and a
# missing API key disables the official OpenAI API. OpenAI-compatible local
# and custom endpoints may intentionally use no authentication.
# ---------------------------------------------------------------------------

# Legacy local-server endpoint constant (kept for reference; not the default).
LOCAL_LLM_BASE_URL = "http://127.0.0.1:18899/v1"
LOCAL_LLM_MODEL = "qwen3-coder-30b-nvfp4-blackwell"
LOCAL_LLM_API_KEY = "local"  # placeholder: LM Studio ignores the bearer token

# Default OpenAI-compatible endpoint + model. No key by default → live API
# disabled until the user configures AI_THEATER_API_KEY.
DEFAULT_OPENAI_BASE_URL = "https://api.openai.com/v1"
DEFAULT_OPENAI_MODEL = "gpt-4o-mini"
DEFAULT_API_KEY = ""


# ---------------------------------------------------------------------------
# Per-role default models (multi-model routing).
#
# Different agent roles have different jobs, so they default to different
# models — a literary model for narrative and a code/rule-strong model for
# rule generation. All roles still default
# to the SAME local LM Studio endpoint (LOCAL_LLM_BASE_URL): load multiple
# models in one LM Studio instance and each role POSTs its own ``model``
# name. To run each model on its own server/port instead, override
# ``AI_THEATER_AGENT_{ROLE}_BASE_URL`` (see docs/MODEL_ROUTING.md).
#
# Override any single role's model via ``AI_THEATER_AGENT_{ROLE}_MODEL``.
# ---------------------------------------------------------------------------

# These are routing defaults, not an allow-list. A model selected in the
# launcher (AI_THEATER_MODEL_FAST) or a per-role model override always wins
# and is sent to the provider unchanged, apart from the narrow legacy aliases
# declared below.
LOCAL_NARRATIVE_MODEL = "gemma-4-12b"

ROLE_DEFAULT_MODELS: Dict[str, str] = {
    "producer": LOCAL_LLM_MODEL,
    "science_director": LOCAL_LLM_MODEL,
    "world_builder": LOCAL_NARRATIVE_MODEL,
}


# ---------------------------------------------------------------------------
# Model capability declarations — used by docs/tooling to reason about which
# model fits a role. Context length and capability flags are best-effort
# defaults for the model family; override if your deployment differs.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ModelCapability:
    name: str
    context_length: int
    supports_json_schema: bool
    strength: str  # short human-readable tag


MODEL_CAPABILITIES: Dict[str, ModelCapability] = {
    LOCAL_LLM_MODEL: ModelCapability(
        name=LOCAL_LLM_MODEL,
        context_length=131072,
        supports_json_schema=True,
        strength="code/rules/JSON — strong at strict structured output",
    ),
    LOCAL_NARRATIVE_MODEL: ModelCapability(
        name=LOCAL_NARRATIVE_MODEL,
        context_length=131072,
        supports_json_schema=True,
        strength="literary Chinese narration, creative writing",
    ),
}


# Compatibility for the historical logical names exposed by WorldForge's
# settings/API contract. This is intentionally an exact, finite mapping:
# launcher-selected provider IDs such as "bonsai-27b@q1_0" remain untouched.
LEGACY_PROVIDER_MODEL_ALIASES: Dict[str, str] = {
    "gpt5.4": "gpt-5.4",
    "gpt5.5": "gpt-5.5",
    "gpt5.4-mini": "gpt-5.4-mini",
}


def role_default_model(role: str) -> str:
    """Return the default model for an agent role.

    Priority: per-role env ``AI_THEATER_AGENT_<ROLE>_MODEL`` > the global
    ``AI_THEATER_MODEL_FAST`` (if the user set one in the launcher) > the
    built-in ``ROLE_DEFAULT_MODELS`` table.
    """
    env_role = os.environ.get(f"AI_THEATER_AGENT_{role.upper()}_MODEL")
    if env_role:
        return env_role
    global_fast = os.environ.get("AI_THEATER_MODEL_FAST")
    if global_fast:
        return global_fast
    return ROLE_DEFAULT_MODELS.get(role, LOCAL_LLM_MODEL)


def model_capability(model: str) -> Optional[ModelCapability]:
    """Return the capability declaration for a model name, if known."""
    return MODEL_CAPABILITIES.get(model)


def _load_dotenv(path: Path) -> Dict[str, str]:
    values: Dict[str, str] = {}
    if not path.exists():
        return values
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _as_bool(value: Optional[str], default: bool) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _normalize_base_url(url: str) -> str:
    url = url.strip().rstrip("/")
    if not url.startswith(("http://", "https://")):
        url = f"https://{url}"
    return url


def _provider_requires_api_key(base_url: str) -> bool:
    """Whether *base_url* is an official OpenAI endpoint.

    LM Studio, Ollama and custom OpenAI-compatible servers commonly run
    without authentication.  Only official OpenAI hosts have a framework
    level key requirement; custom providers remain free to enforce their own
    authentication and will return an explicit HTTP error if it is missing.
    """
    try:
        host = (urlparse(_normalize_base_url(base_url)).hostname or "").lower()
    except ValueError:
        return False
    return host == "openai.com" or host.endswith(".openai.com")


def _masked_key(api_key: str) -> str:
    if not api_key:
        return "not-configured"
    if len(api_key) <= 8:
        return "configured"
    return f"{api_key[:3]}...{api_key[-4:]}"


AUTH_HEADER_TYPES = ["bearer", "api-key", "x-api-key"]


def _auth_headers(auth_type: str, api_key: str) -> Dict[str, str]:
    if not api_key:
        return {}
    lowered = auth_type.strip().lower()
    if lowered == "api-key":
        return {"api-key": api_key}
    if lowered == "x-api-key":
        return {"x-api-key": api_key}
    return {"Authorization": f"Bearer {api_key}"}


@dataclass(frozen=True)
class AgentConfig:
    api_key: str = ""
    base_url: str = ""
    model: str = ""
    enable_live_api: Optional[bool] = None
    auth_header_type: str = ""


@dataclass(frozen=True)
class Settings:
    api_key: str = DEFAULT_API_KEY
    base_url: str = DEFAULT_OPENAI_BASE_URL
    model_fast: str = DEFAULT_OPENAI_MODEL
    model_deep: str = DEFAULT_OPENAI_MODEL
    enable_live_api: bool = False
    auth_header_type: str = "bearer"
    data_dir: Path = Path("data/runtime")
    host: str = "127.0.0.1"
    port: int = 8787
    # North-star default (一句话 → Progressing World): a fresh world auto-
    # advances one beat every world_tick_interval seconds when the player is
    # idle. 300s (5 min) is the out-of-the-box cadence; override via
    # AI_THEATER_WORLD_TICK_INTERVAL. 0 disables autonomous advance.
    world_tick_interval: int = 300
    # AgentMind tick integration (spec §4.2 / §8 / §14). When enabled, the
    # tick runs the registered SimAgents' observe→update_belief→choose_action
    # cycle and feeds the resulting traces to the two-stage causal narrative.
    # North-star default ON so a one-shot world's characters act on their own.
    # Turned off per-world via the registry on TheaterOrchestrator; these
    # flags gate the dispatch hooks. Override via AI_THEATER_ENABLE_AGENT_MIND.
    enable_agent_mind: bool = True
    # Decision-commitment lifecycle (spec — major decisions become persistent
    # causal mechanisms, not instantaneous state deltas). When enabled,
    # world_tick runs Phase 4-8 on top of the AgentMind cycle: agents emit
    # CommitmentProposals (initiative-driven), the DecisionResolver settles
    # them, the CommitmentExecutor advances active commitments each tick,
    # and observable events are broadcast. North-star default ON so major
    # decisions persist; override via AI_THEATER_ENABLE_COMMITMENTS.
    enable_commitments: bool = True
    agents: Dict[str, AgentConfig] = None  # type: ignore[assignment]

    def __post_init__(self):
        # Frozen dataclass with mutable default requires object.__setattr__
        if self.agents is None:
            object.__setattr__(self, "agents", {})

    @classmethod
    def from_env(cls, cwd: Optional[Path] = None) -> "Settings":
        root = cwd or Path.cwd()
        dotenv = _load_dotenv(root / ".env")

        def get(name: str, default: str = "") -> str:
            return os.environ.get(name) or dotenv.get(name) or default

        base_url = get("AI_THEATER_BASE_URL", DEFAULT_OPENAI_BASE_URL)
        api_key = get("AI_THEATER_API_KEY", DEFAULT_API_KEY)
        enable_default = bool(
            base_url and (api_key or not _provider_requires_api_key(base_url))
        )

        agents: Dict[str, AgentConfig] = {}
        global_auth_type = get("AI_THEATER_AUTH_HEADER_TYPE", "bearer").lower()
        global_fast_model = get("AI_THEATER_MODEL_FAST", DEFAULT_OPENAI_MODEL)
        # Only an explicitly configured global model replaces the differentiated
        # role defaults. This lets the Tk launcher route every role to any model
        # selected from the provider while preserving no-config role defaults.
        configured_global_fast = (
            os.environ.get("AI_THEATER_MODEL_FAST")
            or dotenv.get("AI_THEATER_MODEL_FAST")
        )
        for role in AGENT_ROLES:
            role_api_key = get(f"AI_THEATER_AGENT_{role.upper()}_API_KEY")
            role_base_url = get(f"AI_THEATER_AGENT_{role.upper()}_BASE_URL")
            role_model = (
                get(f"AI_THEATER_AGENT_{role.upper()}_MODEL")
                or configured_global_fast
                or ROLE_DEFAULT_MODELS[role]
            )
            role_enable = get(f"AI_THEATER_AGENT_{role.upper()}_ENABLE_LIVE_API")
            role_auth_type = get(f"AI_THEATER_AGENT_{role.upper()}_AUTH_HEADER_TYPE", "").lower()
            agents[role] = AgentConfig(
                api_key=role_api_key,
                base_url=role_base_url,
                model=role_model,
                enable_live_api=_as_bool(role_enable or None, None),
                auth_header_type=role_auth_type or global_auth_type,
            )

        return cls(
            api_key=api_key,
            base_url=base_url,
            model_fast=global_fast_model,
            model_deep=get("AI_THEATER_MODEL_DEEP", "") or global_fast_model,
            enable_live_api=_as_bool(get("AI_THEATER_ENABLE_LIVE_API") or None, enable_default),
            auth_header_type=global_auth_type,
            data_dir=Path(get("AI_THEATER_DATA_DIR", "data/runtime")),
            host=get("AI_THEATER_HOST", "127.0.0.1"),
            port=int(get("AI_THEATER_PORT", "8787")),
            world_tick_interval=int(get("AI_THEATER_WORLD_TICK_INTERVAL", "300") or "0"),
            enable_agent_mind=_as_bool(get("AI_THEATER_ENABLE_AGENT_MIND") or None, True),
            enable_commitments=_as_bool(get("AI_THEATER_ENABLE_COMMITMENTS") or None, True),
            agents=agents,
        )

    @property
    def normalized_base_url(self) -> str:
        return _normalize_base_url(self.base_url)

    @property
    def masked_api_key(self) -> str:
        return _masked_key(self.api_key)

    @staticmethod
    def provider_model_name(model: str) -> str:
        return LEGACY_PROVIDER_MODEL_ALIASES.get(model, model)

    @property
    def provider_model_fast(self) -> str:
        return self.provider_model_name(self.model_fast)

    @property
    def provider_model_deep(self) -> str:
        # model_deep falls back to model_fast — user configures one model,
        # it covers all roles + deep paths. No hardcoded default.
        return self.provider_model_name(self.model_deep or self.model_fast)

    def agent_config(self, role: str) -> AgentConfig:
        """Return per-agent config merged with global defaults."""
        agent = self.agents.get(role) or AgentConfig()
        return AgentConfig(
            api_key=agent.api_key or self.api_key,
            base_url=agent.base_url or self.base_url,
            model=agent.model,
            enable_live_api=agent.enable_live_api if agent.enable_live_api is not None else self.enable_live_api,
            auth_header_type=agent.auth_header_type or self.auth_header_type,
        )

    def agent_auth_headers(self, role: str) -> Dict[str, str]:
        agent = self.agent_config(role)
        return _auth_headers(agent.auth_header_type, agent.api_key)

    @property
    def auth_headers(self) -> Dict[str, str]:
        """Authentication headers for the global provider, omitting blanks."""
        return _auth_headers(self.auth_header_type, self.api_key)

    @property
    def live_api_ready(self) -> bool:
        """Whether the configured global provider may be called."""
        return bool(
            self.enable_live_api
            and self.base_url
            and (
                self.api_key
                or not _provider_requires_api_key(self.normalized_base_url)
            )
        )

    def agent_live_api_enabled(self, role: str) -> bool:
        """Whether a role may make an outbound provider request.

        Callers must use this merged role/global gate before doing network I/O.
        A model name or base URL alone never enables live access.
        """
        agent = self.agent_config(role)
        return bool(
            agent.enable_live_api
            and agent.base_url
            and (
                agent.api_key
                or not _provider_requires_api_key(
                    self.agent_normalized_base_url(role)
                )
            )
        )

    def agent_model(self, role: str, fallback_model: str) -> str:
        """Return the model to use for an agent, falling back to the passed model."""
        agent = self.agent_config(role)
        return agent.model or fallback_model

    def agent_model_name(self, role: str, fallback_model: str) -> str:
        return self.provider_model_name(self.agent_model(role, fallback_model))

    def agent_normalized_base_url(self, role: str) -> str:
        return _normalize_base_url(self.agent_config(role).base_url)

    def agent_masked_api_key(self, role: str) -> str:
        return _masked_key(self.agent_config(role).api_key)

    def public_dict(self) -> Dict[str, object]:
        return {
            "base_url": self.normalized_base_url,
            "model_fast": self.model_fast,
            "model_deep": self.model_deep,
            "provider_model_fast": self.provider_model_fast,
            "provider_model_deep": self.provider_model_deep,
            "live_api_enabled": self.live_api_ready,
            "api_key": self.masked_api_key,
            "auth_header_type": self.auth_header_type,
            "data_dir": str(self.data_dir),
            "agent_roles": AGENT_ROLES,
            "agents": {
                role: {
                    "base_url": self.agent_normalized_base_url(role),
                    "model": self.agent_config(role).model,
                    "auth_header_type": self.agent_config(role).auth_header_type,
                    "masked_api_key": self.agent_masked_api_key(role),
                    "live_api_enabled": self.agent_live_api_enabled(role),
                }
                for role in AGENT_ROLES
            },
        }
