"""Onboarding LLM orchestration — standard OpenAI client → generators.

Thin orchestration layer that turns an :class:`OpenAILLMClient` into the
single-arg ``llm_fn`` shapes the generators accept.  When no LLM is
configured, generation fails explicitly; semantic artifacts are never
substituted with a preset or structural fallback.

Public functions:

* :func:`generate_world_rules` — RuleGenerator.generate(description, llm_fn)
  → validated :class:`WorldKernelSpec`. ``llm_fn=None`` is an error.

* :func:`generate_world_gui` — GUIGenerator.generate(world_style, llm_fn)
  → validated :class:`GUISpec`. ``llm_fn=None`` or generation failure is an
  error.

* :func:`build_llm` — convenience constructor that returns an
  :class:`OpenAILLMClient` from :class:`Settings` (env vars / ``.env``),
or ``None`` with a clear message when unconfigured.

These helpers preserve the generators' strict contracts. A complete generated
world requires accepted LLM artifacts at every semantic generation stage.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional, Tuple
from urllib.parse import urlparse

from .gui_generator import GUISpec, GUIGenerator
from .llm_client import LLMError, OpenAILLMClient
from .rule_generator import RuleGenerator
from .settings import Settings
from .world_kernel_host import RuleCompiler, WorldKernelSpec


__all__ = [
    "build_llm",
    "generate_world_rules",
    "generate_world_gui",
]


def build_llm(
    settings: Optional[Settings] = None,
) -> Tuple[Optional[OpenAILLMClient], str]:
    """Construct an :class:`OpenAILLMClient` from settings.

    Reads base_url / api_key / model from :class:`Settings` (env vars
    ``AI_THEATER_BASE_URL`` / ``AI_THEATER_API_KEY`` / ``AI_THEATER_MODEL_FAST``
    or a ``.env`` file). Returns ``(client, message)``. On success
    ``client`` is non-None and ``message`` is empty. On failure ``client``
    is None and ``message`` explains what's missing — callers can surface
    it to the user without crashing.
    """
    s = settings or Settings.from_env()
    if not s.base_url:
        return None, "LLM unconfigured: set AI_THEATER_BASE_URL."
    host = (urlparse(s.normalized_base_url).hostname or "").lower()
    if host in {"api.openai.com", "openai.com"} and not s.api_key:
        return None, (
            "LLM unconfigured: OpenAI requires AI_THEATER_API_KEY. "
            "Local OpenAI-compatible providers may use an empty key."
        )
    model = s.model_fast
    try:
        return OpenAILLMClient(
            base_url=s.normalized_base_url,
            api_key=s.api_key,
            model=model,
        ), ""
    except LLMError as exc:
        return None, str(exc)


def generate_world_rules(
    description: str,
    llm_fn: Optional[Callable[[str], str]] = None,
    *,
    model_label: str = "openai-llm",
) -> Tuple[WorldKernelSpec, Dict[str, Any]]:
    """Generate a :class:`WorldKernelSpec` for *description*.

    With ``llm_fn`` non-None the LLM drafts and validates the rule DSL.
    Invalid LLM output remains an error; silently substituting unrelated
    rules would misrepresent the user's world. With ``llm_fn=None`` this
    function raises; it does not create a structural substitute.

    Returns ``(spec, meta)`` where ``meta`` records ``source="llm"``,
    ``model_label``,
    and any validation ``issues`` seen by :meth:`RuleCompiler.validate_spec`
    after generation.
    """
    generator = RuleGenerator(model_label=model_label)
    if llm_fn is None:
        raise RuntimeError(
            "generate_world_rules requires llm_fn; rule generation has no "
            "fallback"
        )
    spec = generator.generate(description, llm_fn=llm_fn)
    source = "llm"
    issues = RuleCompiler().validate_spec(spec)
    if issues:
        raise RuntimeError(
            "generated world rules failed validation: " + "; ".join(issues)
        )
    return spec, {
        "source": source,
        "model_label": model_label,
        "issues": issues,
        "rules": len(spec.rules),
        "world_type": spec.world_type,
        "degraded": False,
        "fallback_reason": None,
    }


def generate_world_gui(
    world_style: str,
    worldbook: Optional[Any] = None,
    characters: Optional[Any] = None,
    llm_fn: Optional[Callable[[str], Dict[str, Any]]] = None,
) -> Tuple[GUISpec, Dict[str, Any]]:
    """Generate a :class:`GUISpec` for *world_style*.

    ``worldbook`` / ``characters`` are accepted for forward-compatibility
    (a richer prompt could include them) but are not required by the current
    GUIGenerator contract which takes a single ``world_style`` string.

    Returns ``(spec, meta)`` with ``source="llm"``. Missing/failed/invalid
    LLM output raises.
    """
    generator = GUIGenerator()
    spec = generator.generate(world_style, llm_fn=llm_fn)
    return spec, {
        "source": "llm",
        "gui_spec_id": spec.gui_spec_id,
        "layout_type": spec.layout_type,
        "widgets": len(spec.widgets),
        "degraded": False,
        "fallback_reason": None,
    }
