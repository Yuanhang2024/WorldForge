"""Deterministic, world-agnostic theme derivation for generated GUIs.

The backend uses one neutral default palette. A style lock may override
presentation values explicitly, but layout, world, and kernel names never
select a hidden genre preset.
"""
from __future__ import annotations

from typing import Any, Dict, List

DEFAULT_ROLES: Dict[str, int] = {
    "bg": 0,
    "panel": 1,
    "ink": 14,
    "accent": 9,
    "ok": 6,
    "warn": 11,
    "danger": 4,
}

DEFAULT_PALETTE_RAMP: List[str] = [
    "#0f141d", "#18202c", "#232d3b", "#303b4b",
    "#a85d5d", "#465469", "#5e8b70", "#657086",
    "#b28a55", "#6586ad", "#8993a5", "#b27a55",
    "#8073a8", "#70a083", "#d9dee7", "#f3f5f8",
]


def _clamp_roles(roles: Dict[str, int], ramp_len: int) -> Dict[str, int]:
    """Mirror of theme.js clampRoles — keep indices in [0, ramp_len-1]."""
    out: Dict[str, int] = {}
    max_i = ramp_len - 1
    for k, v in roles.items():
        out[k] = max(0, min(max_i, int(v)))
    return out


def deriveTheme(style_lock: Dict[str, Any]) -> Dict[str, Any]:
    """Build a serialisable theme solely from explicit style-lock values."""
    lock = style_lock or {}
    layout = lock.get("layout_type") or "console"
    supplied_ramp = lock.get("palette_ramp")
    if (
        isinstance(supplied_ramp, list)
        and len(supplied_ramp) >= 2
        and all(isinstance(color, str) and color for color in supplied_ramp)
    ):
        ramp = list(supplied_ramp)
    else:
        ramp = list(DEFAULT_PALETTE_RAMP)

    role_values = dict(DEFAULT_ROLES)
    role_values.update(dict(lock.get("roles") or {}))
    roles = _clamp_roles(role_values, len(ramp))

    light_dir = lock.get("light_dir_deg")
    if not isinstance(light_dir, (int, float)):
        light_dir = 45

    density = "vector"
    motion = lock.get("motion") or "free"
    typography = lock.get("typography") or {
        "display": "Noto Sans", "mono": "IBM Plex Mono",
    }

    return {
        "world_id": lock.get("world_id") or "generic",
        "derived_from_style_lock": lock.get("style_lock_id") or "generic_lock",
        "palette_ramp": ramp,
        "roles": roles,
        "layout": layout,
        "typography": typography,
        "light_dir_deg": light_dir,
        "density": density,
        "motion": motion,
    }


# Exposed as a namespace so callers can write `GuiTheme.deriveTheme(...)`.
class GuiTheme:
    deriveTheme = staticmethod(deriveTheme)
    DEFAULT_ROLES = DEFAULT_ROLES
    DEFAULT_PALETTE_RAMP = DEFAULT_PALETTE_RAMP
