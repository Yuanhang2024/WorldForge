"""P3 — three-body multi-scale agency (architecture spec §8.2 / §3).

This module is now the **first instance** of the generic multi-scale
framework in :mod:`theater.multi_scale_agents`.  The three layers subclass
the generic ones and supply three-body-specific plugs:

- :class:`ScientistAgent` → :class:`IndividualAgent` with the
  :class:`ThreeBodyObservationFilter` and the
  ``dehydrate / evacuate / persist`` threshold proposer.
- :class:`DecisionBody` → :class:`OrganizationAgent` with
  ``default_plan = PLAN_PERSIST`` (status quo under imminent chaos).
- :class:`CivilizationAgent` → :class:`CollectiveAgent` with the
  ``PLAN_TO_DECISION_VECTOR`` map and the kernel's
  ``civilization_outcome`` call.
- :class:`MultiScaleThreeBodySim` → :class:`MultiScaleSim` wired with the
  three-body ground-truth reader + reflux rule (destroyed → disaster was
  real, evidence = 1.0).

Behaviour is unchanged — every existing test passes verbatim.  The §3
correction (a three-body civilisation is a *multi-scale subject system*,
not a single ``CivilizationMind``) is now expressed once, generically, in
``multi_scale_agents.py``; this file only fills in the three-body
vocabulary.  See that module for the full chain diagram.

The §3 correction: a three-body civilisation is **not** a single
``CivilizationMind`` that directly picks a decision vector.  It is a
*multi-scale* subject system with three layers::

    个人角色 (ScientistAgent)        — observes physical anomaly, forms a
                                       "disaster probability" belief via
                                       belief_update, proposes a plan
                                       (dehydrate / evacuate / persist).
        ↓ proposals
    组织/制度 (DecisionBody)          — aggregates member proposals through
                                       character_graph trust edges +
                                       org_decide (dictator / consensus /
                                       vote).  Leader distrust of a
                                       scientist blocks the proposal.
        ↓ org decision
    文明级 (CivilizationAgent)        — maps the org decision to a
                                       ``decision_vector`` and feeds it to
                                       ``ThreeBodyKernel.civilization_outcome``.
        ↓ decision_vector
    世界结果 (ThreeBodyKernel)        — deterministic §8.2 outcome (red line:
                                       kernel decides, LLM only narrates).

Every layer is pure-stdlib, deterministic and seed-driven (spec §8.2 red
line).  No LLM, no unseeded randomness.

Architecture note — two tech scales
-----------------------------------
The §8.2 *model-error limit* is **breakable** (a better theory sharpens
δ₀).  A scientist's personal observation precision can therefore exceed
the civilisation's general tech base.  This module keeps the two scales
explicit:

- ``ScientistAgent.capability`` — the scientist's personal observation
  precision (``tech_level`` / ``delta_0`` / ``T_predict``).  Drives the
  :class:`ThreeBodyObservationFilter` → disaster-probability reading.
- the civilisation-level ``tech_level`` passed to
  :meth:`ThreeBodyKernel.civilization_outcome` — the general
  infrastructure that decides survival horizon / 脱水备灾 capacity.

This separation is what makes the canonical §5 example computable: a
brilliant scientist (high personal capability) sees the chaos coming,
proposes ``dehydrate``; but a low-tech civilisation still has a short
survival horizon, AND a leader who distrusts the scientist blocks the
proposal → the org picks ``persist`` (hoard) → ``destroyed_decision``.
With a single tech scale that example is impossible (seeing the chaos ⟺
horizon covers ⟺ survived), so the two scales are load-bearing, not a
configurability indulgence.

Red lines
---------
- ``three_body.py``'s ``civilization_outcome`` / ``civilization_step`` are
  **not modified** (§8.2).  This module sits *above* the kernel: it
  produces ``decision_vector`` and feeds it in.
- Reuses (read-only): ``cognitive_model``, ``sim_agent``,
  ``belief_update``, ``character_graph``, ``observation_filter``,
  ``multi_scale_agents``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .belief_update import BeliefUpdateTrace
from .character_graph import CharacterGraph, Organization
from .cognitive_model import Belief, ThreeBodyCognitiveModel
from .multi_scale_agents import (
    CollectiveAgent,
    IndividualAgent,
    MultiScaleCausalTrace,
    MultiScaleSim,
    MultiScaleSimConfig,
    OrganizationAgent,
    proposal_from_thresholds,
)
from .sim_agent import CharacterDefinition, SimAgent, derive_mind_profile


__all__ = [
    "PLAN_DEHYDRATE",
    "PLAN_EVACUATE",
    "PLAN_PERSIST",
    "PLAN_TO_DECISION_VECTOR",
    "ThreeBodyObservationFilter",
    "ScientistAgent",
    "DecisionBody",
    "CivilizationAgent",
    "CausalTrace",
    "MultiScaleThreeBodySim",
]


# ---------------------------------------------------------------------------
# Plan vocabulary → civilization decision_vector
# ---------------------------------------------------------------------------

PLAN_DEHYDRATE: str = "dehydrate"   # prepare: invest in tech + shelter
PLAN_EVACUATE: str = "evacuate"     # escape attempt: gamble on flight
PLAN_PERSIST: str = "persist"       # status quo: hoard, do nothing new

#: Mapping from an org-level plan to the kernel's ``decision_vector``
#: ``{tech, shelter, hoard, gamble}``.  The kernel's ``_decision_quality``
#: reads ``prepare = tech + shelter`` vs ``squander = hoard + gamble``:
#: ``persist`` (hoard) under imminent chaos is *mismatched* →
#: ``destroyed_decision``; ``dehydrate`` is *aligned*; ``evacuate`` raises
#: ``gamble`` (a squander component) — the civilisation is rolling the dice
#: on flight rather than preparing to ride out the chaos.
PLAN_TO_DECISION_VECTOR: Dict[str, Dict[str, float]] = {
    PLAN_DEHYDRATE: {"tech": 1.0, "shelter": 1.0, "hoard": 0.0, "gamble": 0.0},
    PLAN_EVACUATE: {"tech": 0.5, "shelter": 0.0, "hoard": 0.0, "gamble": 1.0},
    PLAN_PERSIST: {"tech": 0.0, "shelter": 0.0, "hoard": 1.0, "gamble": 0.0},
}

#: Disaster-probability belief thresholds for proposal selection.
_PROPOSE_EVACUATE_THRESHOLD: float = 0.9
_PROPOSE_DEHYDRATE_THRESHOLD: float = 0.66

#: Default trust gate: a member accepts a scientist's proposal iff the
#: member's trust in that scientist exceeds this threshold.  Below it the
#: proposal does not land — the §5 "leader distrusts scientist" block.
DEFAULT_TRUST_THRESHOLD: float = 0.0

#: The disaster-probability reading a low-capability (model-error) subject
#: commits to — "no chaos coming" even though the kernel knows otherwise.
_MISPERCEIVED_DISASTER_PROB: float = 0.1

#: Disaster-probability floor when the subject *does* see chaos coming.
_PERCEIVED_DISASTER_PROB_FLOOR: float = 0.5

#: Scale (simulation time units) over which an approaching chaotic era
#: raises the perceived disaster probability toward 1.0.
_DISASTER_PROXIMITY_SCALE: float = 30.0

#: The belief topic every three-body scientist revises.
_DISASTER_TOPIC: str = "disaster_prob"


# ---------------------------------------------------------------------------
# Observation filter — kernel ground truth → scientist observation
# ---------------------------------------------------------------------------


class ThreeBodyObservationFilter:
    """§8 observation filter for the three-body world.

    Projects the kernel's ground truth (``next_chaos``) into a scientist's
    observation of the *disaster probability*, gated by the scientist's
    personal capability.  This reuses :class:`ThreeBodyCognitiveModel`
    (the δ₀→horizon misprediction) so the model-error limit is the single
    source of truth for "did the subject see it coming?".

    Behaviour (deterministic, pure function of inputs):

    - ``next_chaos is None`` → no chaotic era ahead → ``disaster_prob = 0``,
      ``model_error = False``.
    - horizon reaches the next chaos (``T_predict >= gap``) → the subject
      sees it coming → ``disaster_prob`` rises with proximity
      (``[0.5, 1.0)``), ``model_error = False``.
    - horizon falls short → the subject commits to "no chaos coming" →
      ``disaster_prob = 0.1`` with ``model_error = True`` (dramatic irony:
      the kernel knows chaos is coming, the subject does not).

    The observation is a plain dict consumed by :class:`ScientistAgent`'s
    belief-update step.
    """

    def __init__(self, kernel: Any) -> None:
        # ``ThreeBodyCognitiveModel`` stores the kernel but its ``predict``
        # does not read it; we keep the reference for clarity and future
        # kernel-backed prediction refinements.
        self._kernel = kernel
        self._cognitive = ThreeBodyCognitiveModel(kernel)

    def observe(
        self,
        true_state: Dict[str, Any],
        agent_binding: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Project kernel ground truth into a scientist's observation."""
        t = float(true_state.get("t", 0.0))
        next_chaos = true_state.get("next_chaos")
        tech_level = float(agent_binding.get("tech_level", 0.0))
        delta_0 = float(agent_binding.get("delta_0", 0.5))
        T_predict = float(agent_binding.get("T_predict", 0.0))

        belief = self._cognitive.predict(
            {"next_chaos": next_chaos},
            {"tech_level": tech_level, "delta_0": delta_0,
             "T_predict": T_predict},
            t,
        )

        if next_chaos is None:
            disaster_prob = 0.0
            model_error = False
        elif belief.predicted is not None:
            # Horizon reaches the next chaos — subject sees it coming.
            gap = max(0.0, float(next_chaos) - t)
            prob = _PERCEIVED_DISASTER_PROB_FLOOR + (
                1.0 - _PERCEIVED_DISASTER_PROB_FLOOR
            ) * (1.0 / (1.0 + gap / _DISASTER_PROXIMITY_SCALE))
            disaster_prob = float(prob)
            model_error = False
        else:
            # Horizon falls short — subject commits to "no chaos coming".
            disaster_prob = _MISPERCEIVED_DISASTER_PROB
            model_error = bool(belief.model_error)

        return {
            "disaster_prob": disaster_prob,
            "model_error": model_error,
            "next_chaos": next_chaos,
            "t": t,
            "T_predict": T_predict,
            "delta_0": delta_0,
            "tech_level": tech_level,
        }


# ---------------------------------------------------------------------------
# Layer 1 — ScientistAgent (IndividualAgent, three-body instance)
# ---------------------------------------------------------------------------


class ScientistAgent(IndividualAgent):
    """An individual scientist: observe → believe → propose.

    Subclasses :class:`multi_scale_agents.IndividualAgent` and fills in the
    three-body plugs:

    - ``belief_topic = "disaster_prob"``.
    - ``propose_fn`` = :func:`proposal_from_thresholds` over the
      dehydrate / evacuate / persist thresholds.
    - the observation binding carries the scientist's personal capability
      (``tech_level`` / ``delta_0`` / ``T_predict``) so the
      :class:`ThreeBodyObservationFilter` can gate the reading.

    Personality picks the belief-revision strategy: a 固执 (stubborn)
    scientist is *dogmatic* — contradicting evidence backfires (教条强化);
    a 理性 (rational) scientist integrates evidence quickly.

    Determinism: every step is a pure function of ``(kernel ground truth,
    capability, mind profile, seed)`` — the same inputs reproduce the same
    misprediction and the same proposal every time (spec §8.2).
    """

    def __init__(
        self,
        sim_agent: SimAgent,
        capability: Optional[Dict[str, float]] = None,
        scientist_id: Optional[str] = None,
        seed: Optional[int] = None,
    ) -> None:
        super().__init__(
            sim_agent,
            capability=capability,
            agent_id=scientist_id,
            belief_topic=_DISASTER_TOPIC,
            propose_fn=proposal_from_thresholds(
                high_threshold=_PROPOSE_EVACUATE_THRESHOLD,
                mid_threshold=_PROPOSE_DEHYDRATE_THRESHOLD,
                high_plan=PLAN_EVACUATE,
                mid_plan=PLAN_DEHYDRATE,
                low_plan=PLAN_PERSIST,
            ),
            seed=seed,
        )

    # -- perception ---------------------------------------------------------

    def observe(
        self,
        filter_: ThreeBodyObservationFilter,
        true_state: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Project ground truth through the capability-gated filter."""
        binding = {
            "scientist_id": self.id,
            "tech_level": self.capability.get("tech_level", 0.0),
            "delta_0": self.capability.get("delta_0", 0.5),
            "T_predict": self.capability.get("T_predict", 0.0),
        }
        return filter_.observe(true_state, binding)

    # -- cognition ----------------------------------------------------------

    def update_belief(
        self,
        observation: Dict[str, Any],
        topic: str = "disaster_prob",
        evidence_field: str = "disaster_prob",
        model_error_field: str = "model_error",
    ) -> Tuple[Belief, BeliefUpdateTrace]:
        """Revise the disaster-probability belief given an observation.

        The observation's ``model_error`` flag is forwarded as
        ``observation_validated=False`` so a misperceived reading is tagged
        ``perception_error`` on the trace (the §8 four-kind filter's
        "interpretation bias" made structural).
        """
        return super().update_belief(
            observation,
            topic=topic,
            evidence_field=evidence_field,
            model_error_field=model_error_field,
        )

    # -- action (propose comes from IndividualAgent + propose_fn) -----------

    def propose(self, topic: str = "disaster_prob") -> str:  # type: ignore[override]
        """Map the current disaster-probability belief to a plan."""
        return super().propose()

    @property
    def disaster_prob(self) -> float:
        """Current committed disaster-probability belief (0.5 if unset)."""
        return self.belief_value


# ---------------------------------------------------------------------------
# Layer 2 — DecisionBody (OrganizationAgent, three-body instance)
# ---------------------------------------------------------------------------


class DecisionBody(OrganizationAgent):
    """The organisational layer: aggregate scientist proposals into one decision.

    Subclasses :class:`multi_scale_agents.OrganizationAgent` with
    ``default_plan = PLAN_PERSIST`` (status quo under imminent chaos).

    Members are the org's decision-makers (scientists + leader).  A member
    accepts a scientist's proposal iff the member's trust in that
    scientist (``graph.get_trust(member, scientist)``) exceeds
    ``trust_threshold`` — this is the §5 "leader distrusts scientist →
    information does not propagate" gate, made structural on the
    character graph.  A scientist always accepts their own proposal.

    Voting:

    - Each scientist member votes their own proposal.
    - Each non-scientist member votes the highest-trust proposal they
      received, defaulting to ``persist`` (status quo) when they received
      none (the distrust case).
    - :func:`character_graph.org_decide` then aggregates under the org's
      rule (``dictator`` / ``consensus`` / ``vote``).
    """

    def __init__(
        self,
        org: Organization,
        graph: CharacterGraph,
        trust_threshold: float = DEFAULT_TRUST_THRESHOLD,
    ) -> None:
        super().__init__(
            org, graph,
            trust_threshold=trust_threshold,
            default_plan=PLAN_PERSIST,
        )


# ---------------------------------------------------------------------------
# Layer 3 — CivilizationAgent (CollectiveAgent, three-body instance)
# ---------------------------------------------------------------------------


class CivilizationAgent(CollectiveAgent):
    """Maps the org decision to a decision_vector and feeds the kernel.

    Subclasses :class:`multi_scale_agents.CollectiveAgent` with the
    ``PLAN_TO_DECISION_VECTOR`` map and the kernel's
    ``civilization_outcome`` call.

    The civilisation level does **not** decide physics — it only translates
    the organisational decision into the ``{tech, shelter, hoard, gamble}``
    vector the §8.2 kernel reads.  ``civilization_outcome`` stays the
    single source of ground truth (red line: kernel decides, LLM only
    narrates).  When the org failed to decide (``decision is None``) the
    vector is ``None`` and the kernel degrades to its neutral branch.
    """

    def __init__(self, kernel: Any) -> None:
        super().__init__(
            kernel=kernel,
            plan_to_action_vector=PLAN_TO_DECISION_VECTOR,
            outcome_fn=_three_body_outcome_fn,
        )

    def decide_outcome(
        self,
        org_decision: Optional[str],
        t: float = 0.0,
        **ctx: Any,
    ) -> Tuple[Any, Optional[Dict[str, float]]]:
        """Return ``(outcome, decision_vector)`` from the kernel.

        Signature-compatible with the generic
        :meth:`CollectiveAgent.decide_outcome` ``(org_decision, t, **ctx)``
        where ``ctx`` carries ``tech_level`` / ``civ_count`` /
        ``evacuated``.  Existing callers that pass ``tech_level`` / ``t``
        as keywords (``decide_outcome(plan, tech_level=1.0, t=0.0)``) keep
        working — ``t`` lands positionally-or-by-keyword and
        ``tech_level`` rides in ``ctx``.
        """
        return super().decide_outcome(org_decision, float(t), **ctx)


def _three_body_outcome_fn(
    kernel: Any, action_vector: Optional[Dict[str, float]], t: float,
    **ctx: Any,
) -> Any:
    """``outcome_fn`` adapter for :class:`CollectiveAgent`.

    Calls ``kernel.civilization_outcome`` with the three-body context
    (``tech_level`` / ``civ_count`` / ``evacuated``) and returns the
    kernel's outcome object.  The ``(kind, destroyed)`` verdict is derived
    by the inherited :meth:`CollectiveAgent.outcome_verdict`.
    """
    return kernel.civilization_outcome(
        tech_level=float(ctx.get("tech_level", 0.0)),
        t=t,
        decision_vector=action_vector,
        civ_count=ctx.get("civ_count"),
        evacuated=bool(ctx.get("evacuated", False)),
    )


# ---------------------------------------------------------------------------
# CausalTrace — the multi-scale audit record (structured, non-literary)
# ---------------------------------------------------------------------------


@dataclass
class CausalTrace(MultiScaleCausalTrace):
    """Structured record of one multi-scale three-body tick (three-body typed view).

    A thin subclass of :class:`multi_scale_agents.MultiScaleCausalTrace`
    that adds no fields — kept as a distinct type so existing narrator /
    dispatcher / test code that references ``three_body_agents.CausalTrace``
    keeps its identity, while reading the generic field set.
    """


# ---------------------------------------------------------------------------
# Composed simulator — one multi-scale tick
# ---------------------------------------------------------------------------


class MultiScaleThreeBodySim(MultiScaleSim):
    """Compose the three layers into one deterministic multi-scale tick.

    Subclasses :class:`multi_scale_agents.MultiScaleSim` and fills in the
    three-body ground-truth reader (``next_chaotic_era_after``) and the
    reflux rule (destroyed → disaster was real, evidence = 1.0;
    survived/evacuated → averted, evidence = 0.0).

    ``tick(t, civ_tech_level)`` runs the full §3 chain::

        scientists observe (capability-gated)
          → belief_update (personality-shaped)
          → proposals
          → DecisionBody aggregates (trust-gated + org_decide)
          → CivilizationAgent → decision_vector
          → ThreeBodyKernel.civilization_outcome (kernel verdict)
          → outcome reflux: scientists revise beliefs given the verdict
            (rational learn; dogmatic reinforce — 教条强化 even when destroyed)

    The kernel is the only source of ground truth; this class never
    adjudicates physics.  Same inputs → same ``CausalTrace`` (§8.2).
    """

    def __init__(
        self,
        kernel: Any,
        scientists: Dict[str, ScientistAgent],
        decision_body: DecisionBody,
        civilization_agent: CivilizationAgent,
        observation_filter: Optional[ThreeBodyObservationFilter] = None,
        seed: Optional[int] = None,
    ) -> None:
        config = MultiScaleSimConfig(
            true_state_fn=_three_body_true_state,
            observation_filter=observation_filter or ThreeBodyObservationFilter(kernel),
            reflux_evidence_fn=_three_body_reflux_evidence,
            outcome_context_fn=_three_body_outcome_context,
        )
        super().__init__(
            kernel=kernel,
            individuals=scientists,
            organization=decision_body,
            collective=civilization_agent,
            config=config,
            seed=seed,
            observation_filter=config.observation_filter,
            evidence_field="disaster_prob",
            model_error_field="model_error",
            trace_factory=CausalTrace,
        )
        # keep the historical attribute names for the dispatcher / tests
        self.scientists = scientists
        self.decision_body = decision_body
        self.civilization_agent = civilization_agent

    def tick(
        self,
        t: float,
        civ_tech_level: float,
        civ_count: Optional[int] = None,
    ) -> CausalTrace:
        """Run one multi-scale tick and return the structured causal trace."""
        return super().tick(
            t, civ_tech_level=civ_tech_level,
            tech_level=civ_tech_level, civ_count=civ_count,
        )


def _three_body_true_state(kernel: Any, t: float) -> Dict[str, Any]:
    """Read the kernel's ground truth the scientists observe."""
    next_chaos = kernel.next_chaotic_era_after(t)
    return {
        "t": float(t),
        "next_chaos": next_chaos,
        "lambda_": getattr(kernel, "lambda_", 0.0),
    }


def _three_body_reflux_evidence(
    outcome: Any, outcome_kind: str, destroyed: bool,
) -> Tuple[float, bool]:
    """Destroyed → disaster was real (evidence = 1.0); else averted (0.0)."""
    return (1.0 if destroyed else 0.0, False)


def _three_body_outcome_context(t: float, kernel: Any) -> Dict[str, Any]:
    """No extra context beyond what ``tick`` passes through (tech_level etc.)."""
    return {}


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def _belief_summary(belief: Belief) -> Dict[str, Any]:
    return {
        "predicted": belief.predicted,
        "confidence": float(belief.confidence),
        "model_error": bool(belief.model_error),
    }


def _outcome_as_dict(outcome: Any) -> Optional[Dict[str, Any]]:
    if outcome is None:
        return None
    as_dict = getattr(outcome, "as_dict", None)
    if callable(as_dict):
        return as_dict()
    return {
        "kind": getattr(outcome, "kind", ""),
        "cause": getattr(outcome, "cause", ""),
        "t": getattr(outcome, "t", None),
        "tech_level": getattr(outcome, "tech_level", None),
        "decision_quality": getattr(outcome, "decision_quality", None),
    }
