import json
import sys
from typing import Any, Dict
import urllib.error
import urllib.request

from .agents import ProviderDiagnostics
from .settings import Settings


def build_capability_report(
    diagnostics: Dict[str, Any],
    embedding_result: Dict[str, Any] = None,
) -> Dict[str, Any]:
    chat_probe = diagnostics.get("chat_probe") or {}
    return {
        "base_url": diagnostics.get("base_url"),
        "diagnostics": {
            "status": diagnostics.get("status") or "unknown",
            "live_api_enabled": bool(diagnostics.get("live_api_enabled")),
        },
        "models": {
            "requested_fast": diagnostics.get("model_fast"),
            "requested_deep": diagnostics.get("model_deep"),
            "provider_fast": diagnostics.get("provider_model_fast"),
            "provider_deep": diagnostics.get("provider_model_deep"),
            "listed_count": len(diagnostics.get("models") or []),
            "supports_fast": diagnostics.get("supports_fast"),
            "supports_deep": diagnostics.get("supports_deep"),
        },
        "chat": {
            "fast": (chat_probe.get("fast") or {}).get("status"),
            "deep": (chat_probe.get("deep") or {}).get("status"),
            "fast_error": (chat_probe.get("fast") or {}).get("error"),
            "deep_error": (chat_probe.get("deep") or {}).get("error"),
        },
        "embeddings": embedding_result or {"status": "skipped", "error": "not probed"},
    }


def probe_embeddings(settings: Settings) -> Dict[str, Any]:
    return _post_probe(
        settings,
        "/embeddings",
        {"model": "text-embedding-3-small", "input": "Storm Archive memory"},
        expect_json=True,
    )


def _post_probe(settings: Settings, path: str, payload: Dict[str, Any], expect_json: bool) -> Dict[str, Any]:
    if not settings.api_key:
        return {"status": "skipped", "error": "AI_THEATER_API_KEY is not set"}
    req = urllib.request.Request(
        f"{settings.normalized_base_url}{path}",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Authorization": f"Bearer {settings.api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as response:
            body = response.read()
        return {"status": "ok", "bytes": len(body), "json": expect_json}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:500]
        return {"status": "error", "error": f"HTTP {exc.code}: {detail}"}
    except Exception as exc:
        return {"status": "error", "error": f"{exc.__class__.__name__}: {exc}"}


def main() -> int:
    settings = Settings.from_env()
    diagnostics = ProviderDiagnostics(settings).report(probe_chat=True)
    report = build_capability_report(
        diagnostics,
        probe_embeddings(settings),
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report["chat"]["fast"] == "ok" and report["chat"]["deep"] == "ok":
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
