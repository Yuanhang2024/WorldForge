"""AI multi-agent interactive theater prototype."""

__all__ = ["__version__"]

__version__ = "0.1.0"

