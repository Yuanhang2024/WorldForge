"""Runtime World Kernel Host — declarative rule DSL + compiler (spec §2, §5).

LLM proposes world rules as **declarative JSON DSL**. The compiler converts
them into **deterministic** Python kernels that the host executes at runtime.
LLM never touches results (立法 / 司法 separation; spec §1.2, I2).

Public surface:
    - :class:`WorldRule`        — one declarative rule
    - :class:`WorldKernelSpec`  — whole-world spec
    - :class:`RuleCompiler`     — compile + validate
    - :class:`CompiledKernel`   — the deterministic executable product
    - :class:`WorldKernelHost`  — owns compiled kernel + state, runs ``step``
    - :class:`ExprEvaluator`    — whitelisted expression AST evaluator

DSL AST op whitelist (all pure, deterministic, no recursion):
    add, sub, mul, div, abs, neg, min, max, clamp,
    lt, gt, eq, ne, le, ge,
    and, or, not,
    if,                  // ternary conditional: if(cond, then, else)
    sum, avg, count,     // list aggregations
    lookup, random_in_range

Leaves: ``{"const": <scalar>}`` or ``{"ref": "state.path"}``.

Pure stdlib Python; no external deps; unit-testable in isolation.
"""

from __future__ import annotations

import copy
import hashlib
import json
import random
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union


# ---------------------------------------------------------------------------
# Whitelist of expression operators (compile-time enforced)
# ---------------------------------------------------------------------------
ARITH_OPS: Set[str] = {"add", "sub", "mul", "div", "abs", "neg", "min", "max", "clamp"}
COMPARE_OPS: Set[str] = {"lt", "gt", "eq", "ne", "le", "ge"}
LOGIC_OPS: Set[str] = {"and", "or", "not"}
IF_OPS: Set[str] = {"if"}                   # ternary: if(cond, then, else)
AGG_OPS: Set[str] = {"sum", "avg", "count"} # list aggregations
LEAF_OPS: Set[str] = {"const", "ref"}
WHITELIST_OPS: Set[str] = (
    ARITH_OPS | COMPARE_OPS | LOGIC_OPS | IF_OPS | AGG_OPS
    | {"lookup", "random_in_range"}
)

# deny_writes blacklist — spec §2.3 (never writable via compiled kernel)
DENY_WRITES_DEFAULT: Tuple[str, ...] = (
    "permissions.",
    "sealed_solutions.",
    "_meta.world_params.",
)

# AST evaluation depth cap — bounds recursion so it always terminates.
_MAX_AST_DEPTH = 64

# Max events processed in one ``step`` — bounds emit-chains so a cyclic
# ``A emits B, B emits A`` ruleset always terminates deterministically.
_MAX_EVENT_CHAIN = 256

# Rule-kind whitelist
RULE_KINDS: Set[str] = {"invariant", "dynamic", "minigame"}


# ---------------------------------------------------------------------------
# Constraint-type classification (§10.1: three kinds of constraint).
#
# A world rule's constraint type governs whether it may evolve at runtime:
#   constitutive  — λ / physics / sealed solutions (§I7: never mutable at
#                   runtime; fork only). e.g. three-body orbits, gravity.
#   consistency  — conservation / DAG / sealed clues (sandbox-mutable; a
#                   sandbox flag marks the save and it can't rejoin canon).
#   content      — economy / social / gameplay balance (evolves freely).
#
# A constraint class changes mutation policy, so it is declaration data, not
# something the framework may guess from a world/genre label.
CONSTRAINT_TYPES: Set[str] = {"constitutive", "consistency", "content"}


def classify_constraint_type(
    world_type: str,
    declared_constraint_type: Optional[str] = None,
) -> str:
    """Resolve an explicitly declared §10.1 constraint type.

    ``world_type`` is retained only for call compatibility and is deliberately
    ignored.  Missing declarations use the least-specialised ``"content"``
    default; invalid declarations are rejected instead of guessed.
    """
    del world_type
    value = str(declared_constraint_type or "content").strip().lower()
    if value not in CONSTRAINT_TYPES:
        raise ValueError(
            f"constraint_type must be one of {sorted(CONSTRAINT_TYPES)}, "
            f"got {value!r}"
        )
    return value


# ---------------------------------------------------------------------------
# DSL data structures
# ---------------------------------------------------------------------------


@dataclass
class WorldRule:
    """A single declarative rule.

    Attributes:
        rule_id:     Stable identifier (monotonic; cannot overwrite existing).
        kind:        ``invariant`` / ``dynamic`` / ``minigame``.
        trigger:     What fires the rule. One of:
                       - ``str`` event path (e.g. ``"trade.executed"`` or an
                         emitted event name) — fires when ``step`` sees that
                         event type.
                       - ``dict`` condition AST (whitelisted) — evaluated every
                         ``turn.tick``; fires when it evaluates truthy and emits
                         a ``condition_triggered`` event.
                       - ``None`` for invariants (always-on).
        condition:   AST (whitelisted) — gate; ``None`` means "always true".
        effect:      AST — produces a *list of changes* when the gate fires
                     (see :meth:`CompiledKernel._eval_effect` for shape).
        description: Free-text human-readable explanation.
        deny_writes: Additional path prefixes this rule may never write.
        priority:    Higher fires first when multiple rules match (int).
        enabled:     Kill-switch; ``False`` skips the rule entirely.
    """

    rule_id: str
    kind: str
    trigger: Optional[Union[str, Dict[str, Any]]] = None
    condition: Optional[Dict[str, Any]] = None
    effect: Optional[Dict[str, Any]] = None
    description: str = ""
    deny_writes: Tuple[str, ...] = ()
    priority: int = 0
    enabled: bool = True

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a JSON-safe dict (round-trips via :meth:`from_dict`)."""
        return {
            "rule_id": self.rule_id,
            "kind": self.kind,
            "trigger": self.trigger,
            "condition": self.condition,
            "effect": self.effect,
            "description": self.description,
            "deny_writes": list(self.deny_writes),
            "priority": self.priority,
            "enabled": self.enabled,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorldRule":
        return cls(
            rule_id=str(data["rule_id"]),
            kind=str(data["kind"]),
            trigger=data.get("trigger"),
            condition=data.get("condition"),
            effect=data.get("effect"),
            description=str(data.get("description") or ""),
            deny_writes=tuple(data.get("deny_writes") or ()),
            priority=int(data.get("priority") or 0),
            enabled=bool(data.get("enabled", True)),
        )


@dataclass
class WorldKernelSpec:
    """A whole world's ruleset (what LLM proposes as one JSON document)."""

    world_type: str
    constraint_type: str = "content"
    rules: List[WorldRule] = field(default_factory=list)
    params: Dict[str, Any] = field(default_factory=dict)
    enabled_kernels: List[str] = field(default_factory=list)
    deny_writes: Tuple[str, ...] = DENY_WRITES_DEFAULT
    initial_state: Dict[str, Any] = field(default_factory=dict)

    def rule_ids(self) -> Set[str]:
        return {r.rule_id for r in self.rules}

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a JSON-safe dict (round-trips via :meth:`from_dict`).

        Used by the dispatcher to persist the compiled spec to disk so a new
        orchestrator instance (new process) can reload it on ``set_world``.
        """
        return {
            "world_type": self.world_type,
            "constraint_type": classify_constraint_type(
                self.world_type, self.constraint_type,
            ),
            "rules": [r.to_dict() for r in self.rules],
            "params": copy.deepcopy(self.params),
            "enabled_kernels": list(self.enabled_kernels),
            "deny_writes": list(self.deny_writes),
            "initial_state": copy.deepcopy(self.initial_state),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WorldKernelSpec":
        rules = [
            WorldRule.from_dict(r) if isinstance(r, dict) else r
            for r in (data.get("rules") or [])
        ]
        return cls(
            world_type=str(data.get("world_type") or ""),
            constraint_type=classify_constraint_type(
                str(data.get("world_type") or ""),
                str(data.get("constraint_type") or "content"),
            ),
            rules=rules,
            params=dict(data.get("params") or {}),
            enabled_kernels=list(data.get("enabled_kernels") or []),
            deny_writes=tuple(data.get("deny_writes") or DENY_WRITES_DEFAULT),
            initial_state=dict(data.get("initial_state") or {}),
        )


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class DSLError(ValueError):
    """Base for compile/validate errors."""


class UnknownOpError(DSLError):
    """Expression AST uses an operator not on the whitelist."""


class ForbiddenWriteError(DSLError):
    """Effect tries to write to a deny_writes path."""


class DuplicateRuleError(DSLError):
    """Trying to add a rule with an existing rule_id."""


class ValidationError(DSLError):
    """Generic validate failure carrying human-readable messages."""


def _coerce_num(x: Any) -> Any:
    """Coerce ``None`` to ``0`` for arithmetic ops (first-write semantics).

    Non-numeric non-None values are returned as-is so the operation will
    raise a clear TypeError.
    """
    if x is None:
        return 0
    return x


# ---------------------------------------------------------------------------
# Expression evaluator (whitelist AST)
# ---------------------------------------------------------------------------


class ExprEvaluator:
    """Evaluate a whitelisted expression AST against a state dict.

    The AST is a dict tree::

        {"op": "add", "args": [<expr>, <expr>]}
        {"op": "const", "value": 42}
        {"op": "ref", "path": "economy.gold"}

    ``lookup`` is a convenience alias for ``ref`` — both read from state.

    No ``eval``, no ``exec``, no lambdas, no user-defined functions. Operators
    are pure functions of their arguments; ``random_in_range`` consumes a
    seeded :class:`random.Random` passed in ``rng`` so determinism is preserved.
    """

    def __init__(self, rng: Optional[random.Random] = None) -> None:
        self._rng = rng

    # -- public API ---------------------------------------------------------

    def eval(self, node: Any, state: Dict[str, Any]) -> Any:
        """Evaluate *node* against *state*.

        ``node`` may be:
          - a ``dict`` with ``op`` (an AST node)
          - a scalar (int / float / bool / str / None) returned as-is
        """
        return self._eval(node, state, depth=0)

    # -- internal -----------------------------------------------------------

    def _eval(self, node: Any, state: Dict[str, Any], depth: int) -> Any:
        if depth > _MAX_AST_DEPTH:
            raise DSLError(f"expression depth exceeds {_MAX_AST_DEPTH}")
        # Scalar passthrough
        if isinstance(node, (int, float, bool)) or node is None:
            return node
        if isinstance(node, str):
            # Bare string = ref by name (DSL shorthand)
            return self._lookup(node, state)
        if not isinstance(node, dict):
            raise DSLError(f"unsupported AST node type: {type(node).__name__}")
        # Shorthand leaves: ``{"const": v}`` and ``{"ref": "path"}``
        if "const" in node and "op" not in node:
            return node["const"]
        if "ref" in node and "op" not in node:
            return self._lookup(node["ref"], state)
        op = node.get("op")
        if op is None:
            raise DSLError("AST node missing 'op'")
        if op not in WHITELIST_OPS:
            raise UnknownOpError(f"op {op!r} not in whitelist")

        # Leaves
        if op == "const":
            return node.get("value")
        if op == "ref":
            return self._lookup(node.get("path", ""), state)
        if op == "lookup":
            # Accept both ``{"op":"lookup","path":"x"}`` and
            # ``{"op":"lookup","args":["x"]}`` (LLM emits either).
            p = node.get("path")
            if not isinstance(p, str):
                args = node.get("args", [])
                p = args[0] if args else ""
            return self._lookup(p, state)
        if op == "random_in_range":
            lo = self._eval(node["args"][0], state, depth + 1)
            hi = self._eval(node["args"][1], state, depth + 1)
            if self._rng is None:
                raise DSLError("random_in_range requires a seeded rng")
            return self._rng.randint(int(lo), int(hi))

        args = node.get("args", [])
        if op in {"not", "neg", "abs"}:
            if len(args) != 1:
                raise DSLError(f"op {op!r} expects 1 arg, got {len(args)}")
            a = self._eval(args[0], state, depth + 1)
            if op == "not":
                return not bool(a)
            if op == "neg":
                return -a
            if op == "abs":
                return abs(a)
        # Ternary conditional
        if op == "if":
            if len(args) != 3:
                raise DSLError(f"op 'if' expects 3 args (cond, then, else), got {len(args)}")
            cond = self._eval(args[0], state, depth + 1)
            if bool(cond):
                return self._eval(args[1], state, depth + 1)
            return self._eval(args[2], state, depth + 1)
        # Aggregations over a single list arg
        if op in AGG_OPS:
            if len(args) != 1:
                raise DSLError(
                    f"op {op!r} expects 1 arg (the list), got {len(args)}"
                )
            items = self._eval(args[0], state, depth + 1)
            # Defensive: LLM may pass a scalar (e.g. lookup returning a number)
            # instead of a list. Wrap scalars in a single-element list so the
            # rule still executes rather than crashing.
            if items is None:
                items = []
            elif not isinstance(items, list):
                items = [items]
            if op == "count":
                return len(items)
            # sum / avg require numeric items; coerce None to 0 like arithmetic ops.
            if not items:
                # avg over empty → 0 (avoids ZeroDivisionError); sum → 0.
                return 0 if op == "sum" else 0
            nums = [_coerce_num(v) for v in items]
            if op == "sum":
                return sum(nums)
            # avg
            return sum(nums) / len(nums)
        # All binary ops: 2 args
        if len(args) != 2:
            raise DSLError(f"op {op!r} expects 2 args, got {len(args)}")
        a = self._eval(args[0], state, depth + 1)
        b = self._eval(args[1], state, depth + 1)
        # Defensive: LLM rules may reference state paths that don't exist yet
        # (returning None). Coerce None→0 for comparisons so invariants don't
        # crash on first-write semantics (same as arithmetic ops).
        if op in {"lt", "gt", "le", "ge", "eq", "ne"}:
            a = _coerce_num(a)
            b = _coerce_num(b)
        if op == "add":
            return _coerce_num(a) + _coerce_num(b)
        if op == "sub":
            return _coerce_num(a) - _coerce_num(b)
        if op == "mul":
            return _coerce_num(a) * _coerce_num(b)
        if op == "div":
            ab = _coerce_num(b)
            if ab == 0:
                raise DSLError("division by zero in AST")
            return _coerce_num(a) / ab
        if op == "min":
            return min(_coerce_num(a), _coerce_num(b))
        if op == "max":
            return max(_coerce_num(a), _coerce_num(b))
        if op == "clamp":
            # clamp(x, lo, hi) is encoded as clamp(value=expr, args=[lo, hi])
            if "value" not in node:
                raise DSLError("clamp requires 'value' (the input expression)")
            x = self._eval(node["value"], state, depth + 1)
            return max(a, min(b, x))
        if op == "lt":
            return a < b
        if op == "gt":
            return a > b
        if op == "eq":
            return a == b
        if op == "ne":
            return a != b
        if op == "le":
            return a <= b
        if op == "ge":
            return a >= b
        if op == "and":
            return bool(a) and bool(b)
        if op == "or":
            return bool(a) or bool(b)
        raise DSLError(f"unhandled whitelist op {op!r}")  # defensive

    def _lookup(self, path: str, state: Dict[str, Any]) -> Any:
        if not path:
            return None
        cursor: Any = state
        for part in path.split("."):
            if isinstance(cursor, dict):
                if part not in cursor:
                    return None
                cursor = cursor[part]
            else:
                return None
        return cursor


# ---------------------------------------------------------------------------
# Compiled product — what the compiler produces from a spec
# ---------------------------------------------------------------------------


@dataclass
class CompiledKernel:
    """A deterministic, in-memory ruleset ready to execute.

    Internal to :class:`WorldKernelHost`; constructed only by
    :meth:`RuleCompiler.compile`.
    """

    world_type: str
    constraint_type: str
    rules: List[WorldRule]              # ordered by priority desc, then rule_id
    deny_writes: Tuple[str, ...]
    seed: int
    params: Dict[str, Any]
    enabled_kernels: List[str]
    spec_hash: str                       # hash of the spec the kernel was built from

    # Pre-sorted rule index by trigger for fast dispatch
    _by_trigger: Dict[Optional[str], List[WorldRule]] = field(default_factory=dict)
    # Rules whose trigger is a condition AST (unhashable dict); evaluated each tick
    _condition_rules: List[WorldRule] = field(default_factory=list)

    def __post_init__(self) -> None:
        self._reindex()

    def _reindex(self) -> None:
        idx: Dict[Optional[str], List[WorldRule]] = {}
        cond: List[WorldRule] = []
        for r in self.rules:
            if not r.enabled:
                continue
            if isinstance(r.trigger, dict):
                cond.append(r)
            else:
                idx.setdefault(r.trigger, []).append(r)
        # Already sorted from compile(); but keep stable order
        self._by_trigger = idx
        self._condition_rules = cond

    def rules_for_trigger(self, trigger: Optional[str]) -> List[WorldRule]:
        return list(self._by_trigger.get(trigger, ()))

    def rule_ids(self) -> Set[str]:
        return {r.rule_id for r in self.rules}


# ---------------------------------------------------------------------------
# Compiler
# ---------------------------------------------------------------------------


class RuleCompiler:
    """Compile + validate :class:`WorldKernelSpec` into :class:`CompiledKernel`.

    Public methods:
        - :meth:`compile`        — produce a :class:`CompiledKernel`.
        - :meth:`validate_spec`  — list of human-readable issues (empty = ok).
        - :meth:`validate_rule`  — single-rule issue list.
    """

    def __init__(self, *, seed: int = 0) -> None:
        self._seed = seed

    # -- compile -------------------------------------------------------------

    def compile(self, spec: WorldKernelSpec) -> CompiledKernel:
        """Compile *spec* into an executable :class:`CompiledKernel`.

        Raises :class:`ValidationError` if validation fails.
        """
        issues = self.validate_spec(spec)
        if issues:
            raise ValidationError("; ".join(issues))
        sorted_rules = sorted(
            spec.rules, key=lambda r: (-r.priority, r.rule_id),
        )
        spec_hash = self._spec_hash(spec)
        kernel = CompiledKernel(
            world_type=spec.world_type,
            constraint_type=classify_constraint_type(
                spec.world_type, spec.constraint_type,
            ),
            rules=sorted_rules,
            deny_writes=spec.deny_writes,
            seed=self._seed,
            params=dict(spec.params),
            enabled_kernels=list(spec.enabled_kernels),
            spec_hash=spec_hash,
        )
        kernel._reindex()
        return kernel

    # -- validate ------------------------------------------------------------

    def validate_spec(self, spec: WorldKernelSpec) -> List[str]:
        """Return a list of issues (empty = spec is valid)."""
        issues: List[str] = []
        if not isinstance(spec.world_type, str) or not spec.world_type:
            issues.append("world_type must be non-empty string")
        try:
            classify_constraint_type(spec.world_type, spec.constraint_type)
        except ValueError as exc:
            issues.append(str(exc))
        seen_ids: Set[str] = set()
        for i, rule in enumerate(spec.rules):
            if not isinstance(rule, WorldRule):
                issues.append(f"rule[{i}] is not a WorldRule")
                continue
            if rule.rule_id in seen_ids:
                issues.append(f"duplicate rule_id {rule.rule_id!r}")
            seen_ids.add(rule.rule_id)
            issues.extend(f"rule[{i}] ({rule.rule_id}): {m}"
                          for m in self.validate_rule(rule))
        # inter-rule: same trigger must not all be contradictory (cheap: same
        # trigger with two ``invariant`` kinds both writing to the same path).
        trigger_kinds: Dict[str, List[WorldRule]] = {}
        for r in spec.rules:
            if not r.enabled:
                continue
            if isinstance(r.trigger, dict):
                key = "<condition>:" + r.rule_id  # dict triggers never group
            else:
                key = r.trigger or "<always>"
            trigger_kinds.setdefault(key, []).append(r)
        for trigger, group in trigger_kinds.items():
            invariant_writers: Set[str] = set()
            for r in group:
                if r.kind == "invariant" and r.effect:
                    w = _extract_write_paths(r.effect)
                    for path in w:
                        invariant_writers.add(path)
            # If more than one invariant writes the same path, that's a conflict.
            counts: Dict[str, int] = {}
            for path in invariant_writers:
                counts[path] = counts.get(path, 0) + 1
            for path, n in counts.items():
                if n > 1:
                    issues.append(
                        f"contradiction: trigger={trigger!r} has multiple "
                        f"invariants writing {path!r}"
                    )
        return issues

    def validate_rule(self, rule: WorldRule) -> List[str]:
        """Return a list of issues for a single rule (empty = ok)."""
        issues: List[str] = []
        if not isinstance(rule.rule_id, str) or not rule.rule_id:
            issues.append("rule_id must be non-empty string")
        if rule.kind not in RULE_KINDS:
            issues.append(
                f"kind {rule.kind!r} not in {sorted(RULE_KINDS)}"
            )
        if rule.trigger is not None and not isinstance(rule.trigger, (str, dict)):
            issues.append("trigger must be a string path, condition AST dict, or None")
        if isinstance(rule.trigger, dict):
            try:
                self._validate_ast(rule.trigger, path="trigger")
            except DSLError as e:
                issues.append(f"trigger condition AST invalid: {e}")
        if rule.condition is not None:
            try:
                self._validate_ast(rule.condition, path="condition")
            except DSLError as e:
                issues.append(f"condition AST invalid: {e}")
        if rule.effect is not None:
            try:
                self._validate_effect(rule.effect)
            except DSLError as e:
                issues.append(f"effect AST invalid: {e}")
        # invariants must always be active (no trigger)
        if rule.kind == "invariant" and rule.trigger is not None:
            issues.append("invariant kind must have trigger=None (always-on)")
        # dynamic / minigame must have a trigger
        if rule.kind in {"dynamic", "minigame"} and rule.trigger is None:
            issues.append(f"kind {rule.kind!r} requires a trigger")
        # deny_writes must be prefixes
        for p in rule.deny_writes:
            if not isinstance(p, str) or not p:
                issues.append("deny_writes entries must be non-empty strings")
        # termination / non-deadlock heuristic: every effect must reference
        # at least one ref or const (no-op effects are dead).
        if rule.effect is not None and not _effect_has_terminal(rule.effect):
            issues.append("effect has no const/ref leaf — appears to be a no-op")
        return issues

    # -- internals -----------------------------------------------------------

    def _validate_ast(self, node: Any, *, path: str) -> None:
        """Walk an AST node, raising on any disallowed op."""
        if isinstance(node, (int, float, bool)) or node is None:
            return
        if isinstance(node, str):
            return  # bare-string ref shorthand is ok
        if not isinstance(node, dict):
            raise DSLError(f"{path}: unsupported node type {type(node).__name__}")
        # Shorthand leaves: ``{"const": <scalar>}`` and ``{"ref": "path"}``
        # are accepted without an ``op`` key (idiomatic from spec §2.3).
        if "const" in node and "op" not in node:
            return
        if "ref" in node and "op" not in node:
            if not isinstance(node["ref"], str):
                raise DSLError(f"{path}: ref shorthand needs string path")
            return
        op = node.get("op")
        if op is None:
            raise DSLError(f"{path}: node missing 'op'")
        if op not in WHITELIST_OPS:
            raise UnknownOpError(f"{path}: op {op!r} not in whitelist")
        if op in LEAF_OPS:
            return
        # ``lookup`` is a leaf-style op that reads a state path.  Accept
        # both ``{"op":"lookup","path":"x"}`` and ``{"op":"lookup","args":["x"]}``.
        if op == "lookup":
            return
        if op == "random_in_range":
            args = node.get("args", [])
            if len(args) != 2:
                raise DSLError(f"{path}: random_in_range needs 2 args")
            for a in args:
                self._validate_ast(a, path=path)
            return
        if op in {"not", "neg", "abs"}:
            args = node.get("args", [])
            if len(args) != 1:
                raise DSLError(f"{path}: {op} needs 1 arg")
            self._validate_ast(args[0], path=path)
            return
        if op == "if":
            args = node.get("args", [])
            if len(args) != 3:
                raise DSLError(f"{path}: 'if' needs 3 args (cond, then, else)")
            for i, a in enumerate(args):
                self._validate_ast(a, path=f"{path}.args[{i}]")
            return
        if op in AGG_OPS:
            args = node.get("args", [])
            if len(args) != 1:
                raise DSLError(
                    f"{path}: {op} needs 1 arg (the list)"
                )
            self._validate_ast(args[0], path=path)
            return
        if op == "clamp":
            args = node.get("args", [])
            if len(args) != 2 or "value" not in node:
                raise DSLError(f"{path}: clamp needs args=[lo,hi] and 'value'")
            self._validate_ast(node["value"], path=path)
            for a in args:
                self._validate_ast(a, path=path)
            return
        args = node.get("args", [])
        if len(args) != 2:
            raise DSLError(f"{path}: {op} needs 2 args")
        for a in args:
            self._validate_ast(a, path=path)

    def _validate_effect(self, effect: Any) -> None:
        """Validate an effect structure.

        Effect shapes (both legacy and flat are accepted):

          Legacy (nested) writes:
            ``{"op": "writes", "changes": [{"path": ..., "value": <ast>}, ...]}``

          Flat writes (LLM-friendly):
            ``{"writes": "<path>", "op": "<write_op>", "value": <ast>}``
            where ``<write_op>`` is one of ``"set"``, ``"add"``, ``"delete"``.
            ``op`` defaults to ``"set"`` if missing.

          Predicate (legacy):
            ``{"op": "predicate", "expr": <ast>}`` (used by invariants)

          Predicate (flat):
            ``{"predicate": <ast>}`` (LLM-friendly invariant form)

          Emit event:
            ``{"op": "emit_event", "value": <scalar>}``

        Only the ``value``/``expr`` sub-ASTs are validated against the
        expression whitelist.
        """
        if not isinstance(effect, dict):
            raise DSLError("effect must be a dict")
        op = effect.get("op")
        # Emit shape: ``{"emit": "<event_name>"[, "writes"/"value"/...]}``.
        # An effect may emit an event, optionally alongside a flat write.
        if "emit" in effect:
            name = effect.get("emit")
            if not isinstance(name, str) or not name:
                raise DSLError("emit effect must have non-empty 'emit' event name")
            if "writes" in effect:
                path = effect.get("writes")
                if not isinstance(path, str) or not path:
                    raise DSLError(
                        "emit+writes effect must have non-empty 'writes' path"
                    )
                v = effect.get("value")
                if v is not None:
                    self._validate_ast(v, path="emit.value")
            return
        # Flat writes shape: ``{"writes": path, "value": ...[, "op": ...]}``
        if "writes" in effect and op in (None, "set", "add", "delete"):
            path = effect.get("writes")
            if not isinstance(path, str) or not path:
                raise DSLError(
                    "flat writes effect must have non-empty 'writes' path"
                )
            v = effect.get("value")
            if v is not None:
                self._validate_ast(v, path="writes.value")
            return
        # Flat predicate shape: ``{"predicate": <ast>}`` for invariants
        if "predicate" in effect and op in (None, "predicate"):
            expr = effect.get("predicate")
            if expr is None:
                raise DSLError("flat predicate effect must have 'predicate'")
            self._validate_ast(expr, path="predicate")
            return
        if op not in {"writes", "emit_event", "predicate"}:
            raise DSLError(
                f"effect.op must be writes/emit_event/predicate, got {op!r}"
            )
        if op == "writes":
            changes = effect.get("changes", [])
            if not isinstance(changes, list) or not changes:
                raise DSLError("writes effect must have non-empty changes list")
            for i, c in enumerate(changes):
                if not isinstance(c, dict) or "path" not in c:
                    raise DSLError(f"changes[{i}] must be dict with 'path'")
                v = c.get("value")
                if v is not None:
                    self._validate_ast(v, path=f"changes[{i}].value")
        elif op == "predicate":
            expr = effect.get("expr")
            if expr is None:
                raise DSLError("predicate effect must have 'expr'")
            self._validate_ast(expr, path="predicate.expr")
        # emit_event: scalar value is fine; nothing to validate.

    @staticmethod
    def _spec_hash(spec: WorldKernelSpec) -> str:
        """Content hash for the spec — used as a provenance marker."""
        h = hashlib.sha256()
        h.update(spec.world_type.encode())
        h.update(b"|")
        h.update(spec.constraint_type.encode())
        h.update(b"|")
        for r in sorted(spec.rules, key=lambda r: r.rule_id):
            h.update(r.rule_id.encode())
            h.update(b";")
            h.update(str(r.kind).encode())
            h.update(b";")
            h.update(str(r.priority).encode())
            h.update(b";")
            if r.trigger is not None:
                if isinstance(r.trigger, dict):
                    h.update(json.dumps(r.trigger, sort_keys=True).encode())
                else:
                    h.update(r.trigger.encode())
            h.update(b";")
        return h.hexdigest()[:16]


# ---------------------------------------------------------------------------
# Helpers (module-level, not exported)
# ---------------------------------------------------------------------------


def _effect_has_terminal(effect: Dict[str, Any]) -> bool:
    """True if an effect structure contains at least one terminal expression.

    Used by validation to catch no-op effects.  Walks into ``writes.changes[*].value``,
    flat ``writes.value``, and ``predicate.expr`` / ``predicate`` to find a
    const/ref leaf.
    """
    if not isinstance(effect, dict):
        return False
    op = effect.get("op")
    # Emit effects are terminal (they carry an event name, optionally a write).
    if "emit" in effect:
        return True
    if op == "writes":
        for c in effect.get("changes", []) or []:
            if isinstance(c, dict):
                v = c.get("value")
                if v is None:
                    return True
                if _ast_has_terminal(v):
                    return True
        return False
    # Flat writes: ``{"writes": path, "value": <ast>}``
    if "writes" in effect and op in (None, "set", "add", "delete"):
        v = effect.get("value")
        if v is None:
            return True
        if _ast_has_terminal(v):
            return True
        return False
    if op == "predicate":
        return _ast_has_terminal(effect.get("expr"))
    # Flat predicate: ``{"predicate": <ast>}``
    if "predicate" in effect and op in (None, "predicate"):
        return _ast_has_terminal(effect.get("predicate"))
    if op == "emit_event":
        return True
    return False


def _ast_has_terminal(node: Any) -> bool:
    """True if *node* contains at least one ``const`` or ``ref`` leaf.

    Used by validation to catch no-op effects.
    """
    if isinstance(node, (int, float, bool)) or node is None or isinstance(node, str):
        return True
    if not isinstance(node, dict):
        return False
    # Shorthand leaves
    if "const" in node or "ref" in node:
        return True
    op = node.get("op")
    if op in LEAF_OPS:
        return True
    if op == "lookup":
        return True
    if op == "random_in_range":
        return True
    args = node.get("args", [])
    return any(_ast_has_terminal(a) for a in args)


def _extract_write_paths(effect: Dict[str, Any]) -> List[str]:
    """Extract the set of state paths an effect writes to.

    Recognised effect shapes::

        # Legacy (nested) writes:
        {"op": "writes", "changes": [
            {"path": "economy.price", "value": <expr>},
            ...
        ]}

        # Flat writes (LLM-friendly):
        {"writes": "economy.price", "op": "set", "value": <expr>}
    """
    paths: List[str] = []
    if not isinstance(effect, dict):
        return paths
    if effect.get("op") == "writes":
        for c in effect.get("changes", []) or []:
            if isinstance(c, dict) and "path" in c:
                paths.append(c["path"])
    # Flat writes: ``{"writes": path, ...}``
    w = effect.get("writes")
    if isinstance(w, str) and w and effect.get("op") in (None, "set", "add", "delete"):
        paths.append(w)
    return paths


def _extract_predicate_expr(effect: Dict[str, Any]) -> Optional[Any]:
    """Extract the predicate AST from either the legacy or flat shape.

    Legacy: ``{"op": "predicate", "expr": <ast>}``
    Flat:   ``{"predicate": <ast>}``
    Returns ``None`` if the effect is not a recognised predicate.
    """
    if not isinstance(effect, dict):
        return None
    op = effect.get("op")
    if op == "predicate":
        return effect.get("expr")
    if "predicate" in effect and op in (None, "predicate"):
        return effect.get("predicate")
    return None


# ---------------------------------------------------------------------------
# Host — runs the compiled kernel against world state
# ---------------------------------------------------------------------------


class WorldKernelHost:
    """Owns a :class:`CompiledKernel` + a state dict, runs ``step`` deterministically.

    Public API:
        - :meth:`step`       — execute one event, return list of emitted changes.
        - :meth:`query`      — read state by dot-path.
        - :meth:`add_rule`   — runtime supplement; rejects on conflicts.
        - :meth:`kernel`     — access the underlying compiled kernel.
        - :meth:`state`      — current world state (read-only copy).
    """

    def __init__(self, spec: WorldKernelSpec, state: Dict[str, Any],
                 *, seed: int = 0) -> None:
        compiler = RuleCompiler(seed=seed)
        self._kernel = compiler.compile(spec)
        # Caller-supplied state wins; any key still missing is filled from
        # ``spec.initial_state`` (LLM-generated or preset-supplied defaults).
        merged_state = _deep_merge_missing(spec.initial_state, state or {})
        self._state: Dict[str, Any] = copy.deepcopy(merged_state)
        self._rng = random.Random(seed)
        self._evaluator = ExprEvaluator(rng=self._rng)
        self._deny_writes: Tuple[str, ...] = spec.deny_writes
        # Track the *original* kernel rules separately from runtime adds
        # so ``add_rule`` never duplicates them.
        self._original_rules: List[WorldRule] = list(self._kernel.rules)
        self._compiled_extra: List[WorldRule] = []

    # -- public API ---------------------------------------------------------

    def step(self, event: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Execute one event; return the list of changes emitted.

        *event* shape::

            {"trigger": "trade.executed", "payload": {...}  # optional}

        Dispatch model — two kinds of triggers coexist:

          - **string trigger** (``trigger="turn.tick"`` or an emitted event
            name): fires when the processed event's ``trigger`` type matches.
          - **condition trigger** (``trigger={condition AST}``): re-evaluated on
            every ``turn.tick``; fires when the AST is truthy and additionally
            emits a ``condition_triggered`` event.

        Effects may ``emit`` further events (``{"emit": "name", ...}``); emitted
        events are appended to the event stream and dispatched in the same
        ``step`` so chains resolve deterministically (bounded by
        ``_MAX_EVENT_CHAIN`` to guarantee termination). Invariants
        (``trigger is None``) never fire here — see :meth:`check_invariants`.
        """
        emitted: List[Dict[str, Any]] = []
        queue: deque = deque()
        queue.append(event if isinstance(event, dict) else {})
        processed = 0
        while queue and processed < _MAX_EVENT_CHAIN:
            processed += 1
            ev = queue.popleft()
            ev_type = ev.get("trigger") if isinstance(ev, dict) else None
            # Priority-sorted list of every active rule (originals + runtime adds)
            sorted_rules = sorted(
                self._combined_rules(),
                key=lambda r: (-r.priority, r.rule_id),
            )
            for rule in sorted_rules:
                if not rule.enabled or rule.kind == "invariant":
                    continue
                is_condition = isinstance(rule.trigger, dict)
                # -- decide whether this rule's trigger matches the event ----
                if is_condition:
                    # Condition triggers are evaluated only on turn.tick.
                    if ev_type != "turn.tick":
                        continue
                    try:
                        matched = bool(self._evaluator.eval(rule.trigger, self._state))
                    except DSLError as e:
                        emitted.append(self._skip_marker(rule.rule_id,
                                                         f"trigger eval failed: {e}"))
                        continue
                    if not matched:
                        continue
                elif isinstance(rule.trigger, str):
                    if rule.trigger != ev_type:
                        continue
                else:
                    continue  # trigger is None (invariant handled above)
                # -- gate on the optional condition AST ----------------------
                try:
                    gate = (True if rule.condition is None
                            else bool(self._evaluator.eval(rule.condition, self._state)))
                except DSLError as e:
                    emitted.append(self._skip_marker(rule.rule_id,
                                                     f"condition eval failed: {e}"))
                    continue
                if not gate:
                    continue
                # -- fire: apply writes, collect emitted events --------------
                changes, events = self._eval_effect(rule, ev)
                for c in changes:
                    if not self._is_write_allowed(c.get("path", "")):
                        raise ForbiddenWriteError(
                            f"rule {rule.rule_id!r} tried to write denied "
                            f"path {c.get('path')!r}"
                        )
                    self._apply_change(c)
                    emitted.append(c)
                # Condition triggers auto-emit a condition_triggered event.
                if is_condition:
                    events.insert(0, {
                        "type": "condition_triggered",
                        "source_rule": rule.rule_id,
                        "path": json.dumps(rule.trigger, sort_keys=True),
                    })
                for nev in events:
                    emitted.append({
                        "path": "_events.emit",
                        "op": "set",
                        "value": {"rule_id": rule.rule_id, "event": nev},
                    })
                    queue.append({"trigger": nev.get("type"), "payload": nev})
        return emitted

    @staticmethod
    def _skip_marker(rule_id: str, reason: str) -> Dict[str, Any]:
        """Build a synthetic ``_events.rule_skipped`` marker change."""
        return {
            "path": "_events.rule_skipped",
            "op": "set",
            "value": {"rule_id": rule_id, "reason": reason},
        }

    def query(self, path: str) -> Any:
        """Read state by dot-path. Returns ``None`` for missing leaves."""
        cursor: Any = self._state
        for part in path.split("."):
            if not isinstance(cursor, dict) or part not in cursor:
                return None
            cursor = cursor[part]
        return cursor

    def state(self) -> Dict[str, Any]:
        """Return a deep copy of current state (callers cannot mutate it)."""
        return copy.deepcopy(self._state)

    def kernel(self) -> CompiledKernel:
        return self._kernel

    def add_rule(self, rule: WorldRule) -> List[str]:
        """Runtime rule supplement. Returns issues (empty = accepted).

        Rejects if:
          - ``rule_id`` already exists (only-add, no overwrite)
          - spec-level validation fails (whitelist, deny_writes, etc.)
        """
        issues: List[str] = []
        existing_ids = {r.rule_id for r in self._combined_rules()}
        if rule.rule_id in existing_ids:
            return [f"duplicate rule_id {rule.rule_id!r} — append-only"]
        compiler = RuleCompiler(seed=self._rng.randint(0, 2**31 - 1))
        # Build a synthetic spec covering kernel + new rule, validate union
        merged = WorldKernelSpec(
            world_type=self._kernel.world_type,
            constraint_type=self._kernel.constraint_type,
            rules=self._combined_rules() + [rule],
            params=dict(self._kernel.params),
            enabled_kernels=list(self._kernel.enabled_kernels),
            deny_writes=self._deny_writes,
        )
        issues = compiler.validate_spec(merged)
        if issues:
            return issues
        # Append-only: new rule lives in ``_compiled_extra``; the combined
        # view is rebuilt on demand.
        self._compiled_extra.append(rule)
        return []

    def check_invariants(self) -> List[str]:
        """Run all enabled invariants against the current state.

        Returns list of rule_ids that violated (empty = all green).
        Invariants are always-on rules whose ``effect`` is a predicate AST
        (``op: "predicate"``) that must evaluate truthy for the state.
        """
        failing: List[str] = []
        for r in self._combined_rules():
            if not r.enabled or r.kind != "invariant":
                continue
            effect = r.effect or {}
            expr = _extract_predicate_expr(effect)
            if expr is None:
                failing.append(
                    f"{r.rule_id}: invariant effect must be a predicate "
                    f"({{op:'predicate',expr:...}} or {{predicate: <ast>}})"
                )
                continue
            try:
                ok = bool(self._evaluator.eval(expr, self._state))
            except DSLError as e:
                failing.append(f"{r.rule_id}: predicate eval failed: {e}")
                continue
            if not ok:
                failing.append(r.rule_id)
        return failing

    # -- internals ----------------------------------------------------------

    def _combined_rules(self) -> List[WorldRule]:
        return list(self._original_rules) + self._compiled_extra

    def _eval_effect(
        self, rule: WorldRule, event: Dict[str, Any]
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Evaluate *rule.effect* into ``(changes, events)``.

        ``changes`` is a list of ``{path, op, value}`` state writes; ``events``
        is a list of event dicts (``{"type": name, ...}``) the rule emits.

        Supported effect shapes::

          {"op": "writes", "changes": [
              {"path": "economy.price",
               "value": {"op": "add", "args": [{"ref": "economy.price"},
                                               {"const": 1.0}]}},
              ...
          ]}

          # Flat LLM-friendly form (single write per effect):
          {"writes": "economy.price",
           "op": "set",                       # optional, defaults to "set"
           "value": <ast or scalar>}

          # Emit an event (optionally alongside a flat write):
          {"emit": "quarantine_started",
           "writes": "policy.quarantine", "op": "set", "value": true}

          {"op": "emit_event", "value": {"name": "price_spike", ...}}

        Unknown effect ops yield no changes (deterministic skip).
        """
        effect = rule.effect or {}
        if not isinstance(effect, dict):
            return [], []
        op = effect.get("op")
        # Emit shape: ``{"emit": name[, "writes": path, "value": ...]}``
        if "emit" in effect:
            name = effect.get("emit")
            events: List[Dict[str, Any]] = []
            if isinstance(name, str) and name:
                events.append({"type": name, "source_rule": rule.rule_id})
            changes: List[Dict[str, Any]] = []
            if "writes" in effect:
                w = self._flat_write(effect)
                if w is not None:
                    changes.append(w)
            return changes, events
        # Flat writes: ``{"writes": path, "value": <ast>[, "op": ...]}``
        if "writes" in effect and op in (None, "set", "add", "delete"):
            w = self._flat_write(effect)
            return ([w] if w is not None else []), []
        if op == "writes":
            out: List[Dict[str, Any]] = []
            for c in effect.get("changes", []) or []:
                if not isinstance(c, dict) or "path" not in c:
                    continue
                value_node = c.get("value")
                if value_node is None:
                    value = None
                elif isinstance(value_node, (int, float, bool, str)):
                    value = value_node
                else:
                    value = self._evaluator.eval(value_node, self._state)
                out.append({
                    "path": c["path"],
                    "op": c.get("op", "set"),
                    "value": value,
                })
            return out, []
        if op == "emit_event":
            # Legacy: surface the raw value as an emitted event.
            return [], [{"type": "emit_event", "source_rule": rule.rule_id,
                         "value": effect.get("value")}]
        return [], []

    def _flat_write(self, effect: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Build a single change dict from a flat ``{"writes": path, ...}`` effect."""
        path = effect.get("writes")
        if not isinstance(path, str) or not path:
            return None
        wop = effect.get("op")
        if wop not in ("set", "add", "delete"):
            wop = "set"
        value_node = effect.get("value")
        if value_node is None:
            value = None
        elif isinstance(value_node, (int, float, bool, str)):
            value = value_node
        else:
            value = self._evaluator.eval(value_node, self._state)
        return {"path": path, "op": wop, "value": value}

    def _is_write_allowed(self, path: str) -> bool:
        if not path:
            return False
        # Built-in blacklist
        for prefix in self._deny_writes:
            if path.startswith(prefix):
                return False
        # Per-rule blacklist (deny_writes on the firing rule)
        for r in self._combined_rules():
            for prefix in r.deny_writes:
                if path.startswith(prefix):
                    return False
        return True

    def _apply_change(self, change: Dict[str, Any]) -> None:
        """Apply a single change to the host state."""
        path = change.get("path", "")
        op = change.get("op", "set")
        if not path:
            return
        if path.startswith("_events."):
            # Synthetic meta-changes aren't written to state.
            return
        parts = path.split(".")
        cursor: Any = self._state
        for key in parts[:-1]:
            nxt = cursor.get(key) if isinstance(cursor, dict) else None
            if not isinstance(nxt, dict):
                nxt = {}
                cursor[key] = nxt
            cursor = nxt
        if op == "delete":
            if isinstance(cursor, dict):
                cursor.pop(parts[-1], None)
        else:
            cursor[parts[-1]] = change.get("value")


# ---------------------------------------------------------------------------
# Deep-merge helpers (used by ``WorldKernelHost.__init__`` to apply
# ``spec.initial_state`` without overwriting caller-supplied state).
# ---------------------------------------------------------------------------


def _deep_merge_missing(base: Dict[str, Any],
                        overlay: Dict[str, Any]) -> Dict[str, Any]:
    """Return a new dict where *overlay* keys win, falling back to *base*.

    Recurses into nested dicts so e.g. caller-provided
    ``{"economy": {"price": 2.0}}`` overrides only the ``price`` leaf of the
    preset's ``{"economy": {"price": 1.0, "supply": 100, "demand": 50}}`` —
    sibling keys like ``supply`` are still filled from ``base``.

    *base* and *overlay* themselves are not mutated.
    """
    out: Dict[str, Any] = {}
    for k, v in (base or {}).items():
        out[k] = copy.deepcopy(v)
    for k, v in (overlay or {}).items():
        if (
            k in out
            and isinstance(out[k], dict)
            and isinstance(v, dict)
        ):
            out[k] = _deep_merge_missing(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


# ---------------------------------------------------------------------------
# Module exports
# ---------------------------------------------------------------------------

__all__ = [
    "WorldRule",
    "WorldKernelSpec",
    "RuleCompiler",
    "CompiledKernel",
    "WorldKernelHost",
    "ExprEvaluator",
    "DSLError",
    "UnknownOpError",
    "ForbiddenWriteError",
    "DuplicateRuleError",
    "ValidationError",
    "DENY_WRITES_DEFAULT",
    "WHITELIST_OPS",
    "RULE_KINDS",
    "CONSTRAINT_TYPES",
    "classify_constraint_type",
]
