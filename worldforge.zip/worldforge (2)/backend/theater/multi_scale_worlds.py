"""P3 — non-three-body instances of the generic multi-scale framework.

Two worlds instantiated on top of :mod:`theater.multi_scale_agents` to
prove the framework is **world-agnostic**, not three-body-shaped:

1. **Economy** — merchant → guild → market.
   - :class:`MarketKernel` — a tiny deterministic supply/demand market
     (price = base × (1 + (demand-supply)/capacity)).  Not the full
     :class:`trader_mind.TraderMind` loop; only the kernel side the
     collective layer needs.
   - :class:`MerchantAgent`(:class:`IndividualAgent`) — observes price
     trend through a :class:`PriceTrendFilter`, revises a ``price_trend``
     belief, proposes ``buy`` / ``hold`` / ``sell``.
   - :class:`GuildAgent`(:class:`OrganizationAgent`) — aggregates merchant
     proposals; ``default_plan = "hold"`` (status quo).
   - :class:`MarketCollective`(:class:`CollectiveAgent`) — maps the guild
     decision to a ``{buy, hold, sell}`` allocation vector and reads the
     market outcome.
   - :func:`build_economy_sim` wires it into a :class:`MultiScaleSim`.

2. **Political fantasy** — noble → faction → kingdom.
   - :class:`KingdomKernel` — a deterministic defence kernel: an invasion
     is coming at time ``T_invasion``; the outcome depends on whether the
     kingdom's ``defense`` allocation covers the threat.  ``ignore`` under
     imminent invasion → ``kingdom_fallen``; ``defend`` → ``kingdom_held``.
   - :class:`NobleAgent`(:class:`IndividualAgent`) — observes invasion
     risk through :class:`InvasionRiskFilter` (capability-gated, same
     model-error shape as three-body), revises an ``invasion_risk``
     belief, proposes ``defend`` / ``diplomacy`` / ``ignore``.
   - :class:`FactionAgent`(:class:`OrganizationAgent`) — aggregates noble
     proposals; ``default_plan = "ignore"`` (status quo).
   - :class:`KingdomCollective`(:class:`CollectiveAgent`) — maps the
     faction decision to a ``{defense, diplomacy, appeasement, ignore}``
     vector.
   - :func:`build_political_sim` wires it.

Both worlds reproduce the canonical §5 dynamic ("leader distrusts the
informed individual → information does not propagate → status quo under
imminent threat → disaster") in a *different* vocabulary than three-body.
That is the generality proof.

Red lines: pure stdlib, deterministic, seed-driven (§8.2).  No LLM, no
unseeded randomness.  No existing kernel / core module is modified.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .character_graph import CharacterGraph, Organization
from .cognitive_model import Belief
from .multi_scale_agents import (
    CollectiveAgent,
    IndividualAgent,
    MultiScaleCausalTrace,
    MultiScaleSim,
    MultiScaleSimConfig,
    OrganizationAgent,
    proposal_from_thresholds,
)
from .sim_agent import CharacterDefinition, SimAgent


__all__ = [
    # economy
    "MarketKernel",
    "PriceTrendFilter",
    "MerchantAgent",
    "GuildAgent",
    "MarketCollective",
    "build_economy_sim",
    "PLAN_BUY",
    "PLAN_HOLD",
    "PLAN_SELL",
    # political
    "KingdomKernel",
    "InvasionRiskFilter",
    "NobleAgent",
    "FactionAgent",
    "KingdomCollective",
    "build_political_sim",
    "PLAN_DEFEND",
    "PLAN_DIPLOMACY",
    "PLAN_IGNORE",
]


# ===========================================================================
# Instance 1 — ECONOMY (merchant → guild → market)
# ===========================================================================

PLAN_BUY: str = "buy"
PLAN_HOLD: str = "hold"
PLAN_SELL: str = "sell"

#: Guild decision → market allocation vector ``{buy, hold, sell}``.
#: The market kernel's ``_allocation_quality`` reads ``committed = buy+hold``
#: vs ``liquidated = sell``: ``sell`` (liquidate) under a rising market is
#: *mismatched* → ``crash``; ``buy`` is *aligned*; ``hold`` is neutral.
PLAN_TO_MARKET_VECTOR: Dict[str, Dict[str, float]] = {
    PLAN_BUY: {"buy": 1.0, "hold": 0.0, "sell": 0.0},
    PLAN_HOLD: {"buy": 0.0, "hold": 1.0, "sell": 0.0},
    PLAN_SELL: {"buy": 0.0, "hold": 0.0, "sell": 1.0},
}

_PROPOSE_BUY_THRESHOLD: float = 0.9
_PROPOSE_HOLD_THRESHOLD: float = 0.66


@dataclass
class MarketOutcome:
    """Deterministic market verdict for one tick."""

    kind: str
    t: float
    price_before: float
    price_after: float
    decision_quality: str = "neutral"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind,
            "t": self.t,
            "price_before": self.price_before,
            "price_after": self.price_after,
            "decision_quality": self.decision_quality,
        }


class MarketKernel:
    """A tiny deterministic market the collective layer feeds.

    Ground truth: a supply/demand curve with a baked ``true_trend``
    (``+1`` rising / ``-1`` falling / ``0`` flat) the merchants cannot
    read directly — they only see the filtered price.  The market moves
    one step along the baked trend each tick; the guild's allocation
    vector tilts the step (a coordinated ``buy`` amplifies a rise, a
    coordinated ``sell`` amplifies a fall / crashes the market).

    The kernel is the only source of ground truth (§8.2 red line).  No
    LLM, no unseeded randomness.
    """

    def __init__(
        self,
        *,
        base_price: float = 100.0,
        true_trend: float = 1.0,
        capacity: float = 50.0,
        step: float = 0.05,
    ) -> None:
        self.base_price = float(base_price)
        self.price = float(base_price)
        self.true_trend = float(true_trend)  # +1 rising, -1 falling
        self.capacity = float(capacity)
        self.step = float(step)

    def true_state(self, t: float) -> Dict[str, Any]:
        """Ground truth the merchants observe (filtered)."""
        return {
            "t": float(t),
            "price": self.price,
            "true_trend": self.true_trend,
            "supply": self.capacity * 0.5,
            "demand": self.capacity * (0.5 + 0.1 * self.true_trend),
        }

    def market_outcome(
        self,
        t: float,
        allocation_vector: Optional[Dict[str, float]] = None,
    ) -> MarketOutcome:
        """Advance the market one tick and return the verdict."""
        price_before = self.price
        # baseline move along the baked trend
        delta = self.true_trend * self.step
        quality = "neutral"
        if allocation_vector is not None:
            buy = float(allocation_vector.get("buy", 0.0))
            sell = float(allocation_vector.get("sell", 0.0))
            hold = float(allocation_vector.get("hold", 0.0))
            committed = buy + hold
            liquidated = sell
            # coordinated buy amplifies a rise; coordinated sell amplifies a
            # fall / crashes.  Mismatch = selling into a rising market.
            delta += 0.5 * (buy - sell) * self.step
            if self.true_trend > 0 and liquidated > committed:
                quality = "mismatched"
            elif self.true_trend < 0 and committed > liquidated:
                quality = "mismatched"
            else:
                quality = "aligned"
        self.price = max(1.0, self.price * (1.0 + delta))
        kind = "crash" if (quality == "mismatched" and self.price < price_before) else "stable"
        if self.price > price_before:
            kind = "boom"
        elif self.price < price_before and quality != "mismatched":
            kind = "decline"
        return MarketOutcome(
            kind=kind, t=float(t),
            price_before=price_before, price_after=self.price,
            decision_quality=quality,
        )


class PriceTrendFilter:
    """Capability-gated price-trend observation for a merchant.

    Projects the market's ground-truth price + trend into a merchant's
    ``trend_prob`` reading (probability the market rises next tick),
    gated by the merchant's personal ``insight`` (model-error limit,
    same shape as three-body).  Low insight → commits to "no trend"
    (``trend_prob = 0.1``, ``model_error = True``) even when the kernel
    knows a trend is baked.
    """

    def __init__(self, insight_threshold: float = 0.5) -> None:
        self.insight_threshold = float(insight_threshold)

    def observe(
        self,
        true_state: Dict[str, Any],
        agent_binding: Dict[str, Any],
    ) -> Dict[str, Any]:
        insight = float(agent_binding.get("insight", 0.0))
        true_trend = true_state.get("true_trend", 0.0)
        price = true_state.get("price")
        t = float(true_state.get("t", 0.0))
        if insight >= self.insight_threshold:
            # sees the trend → trend_prob rises with |trend|
            trend_prob = 0.5 + 0.5 * float(true_trend) * insight
            trend_prob = max(0.05, min(0.95, trend_prob))
            model_error = False
        else:
            trend_prob = 0.1  # "no trend coming"
            model_error = True
        return {
            "trend_prob": trend_prob,
            "model_error": model_error,
            "price": price,
            "t": t,
            "insight": insight,
        }


class MerchantAgent(IndividualAgent):
    """A merchant: observe price trend → believe → propose buy/hold/sell."""

    def __init__(
        self,
        sim_agent: SimAgent,
        *,
        insight: float = 0.5,
        agent_id: Optional[str] = None,
        seed: Optional[int] = None,
    ) -> None:
        super().__init__(
            sim_agent,
            capability={"insight": float(insight)},
            agent_id=agent_id,
            belief_topic="trend_prob",
            propose_fn=proposal_from_thresholds(
                high_threshold=_PROPOSE_BUY_THRESHOLD,
                mid_threshold=_PROPOSE_HOLD_THRESHOLD,
                high_plan=PLAN_BUY,
                mid_plan=PLAN_HOLD,
                low_plan=PLAN_SELL,
            ),
            seed=seed,
        )

    def observe(
        self,
        filter_: PriceTrendFilter,
        true_state: Dict[str, Any],
    ) -> Dict[str, Any]:
        binding = {
            "agent_id": self.id,
            "insight": self.capability.get("insight", 0.0),
        }
        return filter_.observe(true_state, binding)

    def update_belief(
        self,
        observation: Dict[str, Any],
        topic: str = "trend_prob",
        evidence_field: str = "trend_prob",
        model_error_field: str = "model_error",
    ) -> Tuple[Belief, Any]:
        return super().update_belief(
            observation, topic=topic,
            evidence_field=evidence_field, model_error_field=model_error_field,
        )

    @property
    def trend_prob(self) -> float:
        return self.belief_value


class GuildAgent(OrganizationAgent):
    """A guild: aggregate merchant proposals; status quo = ``hold``."""

    def __init__(
        self,
        org: Organization,
        graph: CharacterGraph,
        trust_threshold: float = 0.0,
    ) -> None:
        super().__init__(
            org, graph,
            trust_threshold=trust_threshold,
            default_plan=PLAN_HOLD,
        )


class MarketCollective(CollectiveAgent):
    """Maps the guild decision to a market allocation vector."""

    def __init__(self, kernel: MarketKernel) -> None:
        super().__init__(
            kernel=kernel,
            plan_to_action_vector=PLAN_TO_MARKET_VECTOR,
            outcome_fn=_market_outcome_fn,
        )

    def outcome_verdict(self, outcome: Any) -> Tuple[str, bool]:
        """A crash is the economy's "destroyed" (reflux evidence = 1.0)."""
        kind = getattr(outcome, "kind", "") or (
            outcome.get("kind", "") if isinstance(outcome, dict) else ""
        )
        destroyed = kind == "crash"
        return str(kind), destroyed


def _market_outcome_fn(
    kernel: MarketKernel, action_vector: Optional[Dict[str, float]], t: float,
    **ctx: Any,
) -> MarketOutcome:
    return kernel.market_outcome(t=float(t), allocation_vector=action_vector)


def _market_true_state(kernel: MarketKernel, t: float) -> Dict[str, Any]:
    return kernel.true_state(t)


def _market_reflux_evidence(
    outcome: Any, outcome_kind: str, destroyed: bool,
) -> Tuple[float, bool]:
    # crash → the merchants who sold into a rising market were wrong;
    # evidence = 1.0 "the trend was real".  boom/decline → 0.0.
    return (1.0 if destroyed else 0.0, False)


def build_economy_sim(
    kernel: MarketKernel,
    merchants: Dict[str, MerchantAgent],
    guild: GuildAgent,
    market: MarketCollective,
    observation_filter: PriceTrendFilter,
    *,
    seed: Optional[int] = None,
) -> MultiScaleSim:
    """Wire the economy layers into a :class:`MultiScaleSim`."""
    config = MultiScaleSimConfig(
        true_state_fn=_market_true_state,
        observation_filter=observation_filter,
        reflux_evidence_fn=_market_reflux_evidence,
    )
    return MultiScaleSim(
        kernel=kernel,
        individuals=merchants,
        organization=guild,
        collective=market,
        config=config,
        seed=seed,
        observation_filter=observation_filter,
        evidence_field="trend_prob",
        model_error_field="model_error",
    )


# ===========================================================================
# Instance 2 — POLITICAL FANTASY (noble → faction → kingdom)
# ===========================================================================

PLAN_DEFEND: str = "defend"
PLAN_DIPLOMACY: str = "diplomacy"
PLAN_IGNORE: str = "ignore"

#: Faction decision → kingdom allocation vector
#: ``{defense, diplomacy, appeasement, ignore}``.  The kingdom kernel's
#: ``_defense_quality`` reads ``protected = defense+diplomacy`` vs
#: ``neglect = ignore+appeasement``: ``ignore`` under imminent invasion is
#: *mismatched* → ``kingdom_fallen``; ``defend`` is *aligned*.
PLAN_TO_KINGDOM_VECTOR: Dict[str, Dict[str, float]] = {
    PLAN_DEFEND: {"defense": 1.0, "diplomacy": 0.0, "appeasement": 0.0, "ignore": 0.0},
    PLAN_DIPLOMACY: {"defense": 0.0, "diplomacy": 1.0, "appeasement": 0.0, "ignore": 0.0},
    # an attempted appeasement is a gamble — it averts war only when the
    # threat is not imminent; under imminent invasion it is a squander.
    "appease": {"defense": 0.0, "diplomacy": 0.0, "appeasement": 1.0, "ignore": 0.0},
    PLAN_IGNORE: {"defense": 0.0, "diplomacy": 0.0, "appeasement": 0.0, "ignore": 1.0},
}

_PROPOSE_DEFEND_THRESHOLD: float = 0.9
_PROPOSE_DIPLOMACY_THRESHOLD: float = 0.66


@dataclass
class KingdomOutcome:
    """Deterministic kingdom verdict for one tick."""

    kind: str
    t: float
    invasion_imminent: bool
    decision_quality: str = "neutral"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind,
            "t": self.t,
            "invasion_imminent": self.invasion_imminent,
            "decision_quality": self.decision_quality,
        }


class KingdomKernel:
    """A deterministic defence kernel.

    Ground truth: an invasion is baked at ``T_invasion``.  The kingdom
    survives iff, at the tick the invasion lands, its allocation vector's
    ``protected = defense + diplomacy`` exceeds ``neglect = ignore +
    appeasement`` (i.e. the faction committed to defence, not neglect).
    ``ignore`` under imminent invasion → ``kingdom_fallen``; ``defend`` →
    ``kingdom_held``.  Before the invasion lands the outcome is ``peace``.

    The kernel is the only source of ground truth (§8.2 red line).  No
    LLM, no unseeded randomness.
    """

    def __init__(self, *, T_invasion: float = 10.0, horizon: float = 8.0) -> None:
        self.T_invasion = float(T_invasion)
        self.horizon = float(horizon)

    def true_state(self, t: float) -> Dict[str, Any]:
        imminent = (self.T_invasion - t) <= self.horizon and self.T_invasion > t
        return {
            "t": float(t),
            "T_invasion": self.T_invasion,
            "invasion_imminent": imminent,
        }

    def kingdom_outcome(
        self,
        t: float,
        allocation_vector: Optional[Dict[str, float]] = None,
    ) -> KingdomOutcome:
        imminent = (self.T_invasion - t) <= self.horizon and self.T_invasion > t
        quality = "neutral"
        if allocation_vector is not None:
            defense = float(allocation_vector.get("defense", 0.0))
            diplomacy = float(allocation_vector.get("diplomacy", 0.0))
            ignore = float(allocation_vector.get("ignore", 0.0))
            appeasement = float(allocation_vector.get("appeasement", 0.0))
            protected = defense + diplomacy
            neglect = ignore + appeasement
            if imminent and neglect > protected:
                quality = "mismatched"
            elif imminent:
                quality = "aligned"
            else:
                quality = "neutral"
        if not imminent:
            kind = "peace"
        elif quality == "mismatched":
            kind = "kingdom_fallen"
        else:
            kind = "kingdom_held"
        return KingdomOutcome(
            kind=kind, t=float(t),
            invasion_imminent=imminent, decision_quality=quality,
        )


class InvasionRiskFilter:
    """Capability-gated invasion-risk observation for a noble.

    Same model-error shape as :class:`ThreeBodyObservationFilter`: a
    high-insight noble sees the invasion coming (``risk_prob`` rises as
    the invasion nears); a low-insight noble commits to "no invasion"
    (``risk_prob = 0.1``, ``model_error = True``) — dramatic irony.
    """

    _PROXIMITY_SCALE: float = 8.0
    _PERCEIVED_FLOOR: float = 0.5
    _MISPERCEIVED: float = 0.1

    def observe(
        self,
        true_state: Dict[str, Any],
        agent_binding: Dict[str, Any],
    ) -> Dict[str, Any]:
        insight = float(agent_binding.get("insight", 0.0))
        T_invasion = true_state.get("T_invasion")
        t = float(true_state.get("t", 0.0))
        imminent = bool(true_state.get("invasion_imminent", False))
        if T_invasion is None or not imminent:
            # no imminent invasion in the noble's view
            if not imminent:
                return {
                    "risk_prob": 0.0, "model_error": False,
                    "T_invasion": T_invasion, "t": t, "insight": insight,
                }
        # imminent — does the noble see it?
        if insight >= 0.5:
            gap = max(0.0, float(T_invasion) - t)
            prob = self._PERCEIVED_FLOOR + (1.0 - self._PERCEIVED_FLOOR) * (
                1.0 / (1.0 + gap / self._PROXIMITY_SCALE))
            return {
                "risk_prob": float(prob), "model_error": False,
                "T_invasion": T_invasion, "t": t, "insight": insight,
            }
        return {
            "risk_prob": self._MISPERCEIVED, "model_error": True,
            "T_invasion": T_invasion, "t": t, "insight": insight,
        }


class NobleAgent(IndividualAgent):
    """A noble: observe invasion risk → believe → propose defend/diplomacy/ignore."""

    def __init__(
        self,
        sim_agent: SimAgent,
        *,
        insight: float = 0.5,
        agent_id: Optional[str] = None,
        seed: Optional[int] = None,
    ) -> None:
        super().__init__(
            sim_agent,
            capability={"insight": float(insight)},
            agent_id=agent_id,
            belief_topic="risk_prob",
            propose_fn=proposal_from_thresholds(
                high_threshold=_PROPOSE_DEFEND_THRESHOLD,
                mid_threshold=_PROPOSE_DIPLOMACY_THRESHOLD,
                high_plan=PLAN_DEFEND,
                mid_plan=PLAN_DIPLOMACY,
                low_plan=PLAN_IGNORE,
            ),
            seed=seed,
        )

    def observe(
        self,
        filter_: InvasionRiskFilter,
        true_state: Dict[str, Any],
    ) -> Dict[str, Any]:
        binding = {
            "agent_id": self.id,
            "insight": self.capability.get("insight", 0.0),
        }
        return filter_.observe(true_state, binding)

    def update_belief(
        self,
        observation: Dict[str, Any],
        topic: str = "risk_prob",
        evidence_field: str = "risk_prob",
        model_error_field: str = "model_error",
    ) -> Tuple[Belief, Any]:
        return super().update_belief(
            observation, topic=topic,
            evidence_field=evidence_field, model_error_field=model_error_field,
        )

    @property
    def risk_prob(self) -> float:
        return self.belief_value


class FactionAgent(OrganizationAgent):
    """A faction: aggregate noble proposals; status quo = ``ignore``."""

    def __init__(
        self,
        org: Organization,
        graph: CharacterGraph,
        trust_threshold: float = 0.0,
    ) -> None:
        super().__init__(
            org, graph,
            trust_threshold=trust_threshold,
            default_plan=PLAN_IGNORE,
        )


class KingdomCollective(CollectiveAgent):
    """Maps the faction decision to a kingdom allocation vector."""

    def __init__(self, kernel: KingdomKernel) -> None:
        super().__init__(
            kernel=kernel,
            plan_to_action_vector=PLAN_TO_KINGDOM_VECTOR,
            outcome_fn=_kingdom_outcome_fn,
        )

    def outcome_verdict(self, outcome: Any) -> Tuple[str, bool]:
        """``kingdom_fallen`` is the polity's "destroyed"."""
        kind = getattr(outcome, "kind", "") or (
            outcome.get("kind", "") if isinstance(outcome, dict) else ""
        )
        destroyed = kind == "kingdom_fallen"
        return str(kind), destroyed


def _kingdom_outcome_fn(
    kernel: KingdomKernel, action_vector: Optional[Dict[str, float]], t: float,
    **ctx: Any,
) -> KingdomOutcome:
    return kernel.kingdom_outcome(t=float(t), allocation_vector=action_vector)


def _kingdom_true_state(kernel: KingdomKernel, t: float) -> Dict[str, Any]:
    return kernel.true_state(t)


def _kingdom_reflux_evidence(
    outcome: Any, outcome_kind: str, destroyed: bool,
) -> Tuple[float, bool]:
    # kingdom_fallen → the invasion was real (evidence = 1.0);
    # held/peace → averted (0.0).
    return (1.0 if destroyed else 0.0, False)


def build_political_sim(
    kernel: KingdomKernel,
    nobles: Dict[str, NobleAgent],
    faction: FactionAgent,
    kingdom: KingdomCollective,
    observation_filter: InvasionRiskFilter,
    *,
    seed: Optional[int] = None,
) -> MultiScaleSim:
    """Wire the political-fantasy layers into a :class:`MultiScaleSim`."""
    config = MultiScaleSimConfig(
        true_state_fn=_kingdom_true_state,
        observation_filter=observation_filter,
        reflux_evidence_fn=_kingdom_reflux_evidence,
    )
    return MultiScaleSim(
        kernel=kernel,
        individuals=nobles,
        organization=faction,
        collective=kingdom,
        config=config,
        seed=seed,
        observation_filter=observation_filter,
        evidence_field="risk_prob",
        model_error_field="model_error",
    )


# ---------------------------------------------------------------------------
# Small helper to build a character + SimAgent from a personality text
# ---------------------------------------------------------------------------


def make_sim_agent(
    name: str,
    personality: str,
    *,
    character_id: Optional[str] = None,
    world_id: str = "",
) -> SimAgent:
    """Build a minimal :class:`SimAgent` for a demo / test character."""
    char = CharacterDefinition(
        character_id=character_id or name,
        name=name,
        personality=personality,
    )
    return SimAgent(char)
