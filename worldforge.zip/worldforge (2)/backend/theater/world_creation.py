"""World creation module — fork, don't mutate (ARCHITECTURE_SPEC §10.4/§11.4/§11.5).

Provides the WorldCreator which handles the full lifecycle: user proposal ->
kernel preview -> immutable fork -> runtime state.

Red lines (spec §10.4):
  - Worlds are *forked*, never mutated in place. Every new world gets its own
    world_id and isolated state store.
  - world_params are pinned at creation time inside the state file's ``_meta``
    and never rewritten.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
import threading
from typing import Any, Callable, Dict, List, Optional, Sequence, Union
from uuid import uuid4

from .storage import JsonStateStore


_CREATE_LOCK = threading.Lock()


def _state_path(root: Path, world_id: str) -> Path:
    return root / ("state.json" if world_id == "main" else f"state_{world_id}.json")


def _unique_world_id(root: Path, requested: str) -> str:
    """Return an unused ID without reusing an existing world's state file."""
    base = str(requested or "").strip() or f"world_{uuid4().hex[:12]}"
    if not _state_path(root, base).exists():
        return base
    while True:
        candidate = f"{base}_{uuid4().hex[:8]}"
        if not _state_path(root, candidate).exists():
            return candidate


# ---------------------------------------------------------------------------
# Defaults (spec §11.4 — a proposal is always valid).  These values are
# intentionally world-agnostic: a specialised kernel must be selected
# explicitly in ``enabled_kernels`` rather than inferred from prose.
# ---------------------------------------------------------------------------

DEFAULT_WORLD_PARAMS: Dict[str, Any] = {
    "enabled_kernels": [],
    "seed": 42,
}

DEFAULT_NPCS: List[Dict[str, str]] = [
    {
        "name": "引导者",
        "role": "向导",
        "description": "帮助参与者了解当前世界与可用选择的中立角色",
    },
    {
        "name": "记录者",
        "role": "观察者",
        "description": "记录世界变化并提供背景信息的中立角色",
    },
]

DEFAULT_OPENING_SCENE: str = (
    "一个尚待展开的世界在你面前。具体地点、规则与事件将由已确认的"
    "世界设定和你接下来的选择决定。"
)

DEFAULT_GUI_HINT: str = (
    '{"style":"neutral",'
    '"widgets":['
    '{"type":"label","text":"世界概览","key":"world_overview"},'
    '{"type":"label","text":"当前状态","key":"current_state"}'
    ']}'
)


# ---------------------------------------------------------------------------
# Proposal & Preview dataclasses
# ---------------------------------------------------------------------------

@dataclass
class WorldProposal:
    """A user's world creation proposal.

    ``world_params`` are the immutable physics/engine parameters pinned at
    creation time. ``npcs``, ``opening_scene``, and ``gui_hint`` are
    proposal-level suggestions that the user may edit before calling create().
    """
    world_id: str = ""
    world_params: Dict[str, Any] = field(
        default_factory=lambda: deepcopy(DEFAULT_WORLD_PARAMS),
    )
    npcs: List[Dict[str, Any]] = field(default_factory=lambda: [dict(n) for n in DEFAULT_NPCS])
    opening_scene: str = DEFAULT_OPENING_SCENE
    gui_hint: str = DEFAULT_GUI_HINT


@dataclass
class WorldPreview:
    """Preview of a world's long-term behaviour (spec §11.5).

    Produced by running the enabled kernels for a short simulation and
    computing civilization-level statistics. The summary_text is the
    human-readable string shown to the user *before* they commit to create.
    """
    avg_civ_duration: float = 0.0      # mean survival in simulation time units
    num_rises_falls: int = 0           # number of civilization collapses seen
    earliest_evac_civ: int = 0         # 0 = evacuation never proven within horizon
    summary_text: str = ""


# ---------------------------------------------------------------------------
# WorldCreator
# ---------------------------------------------------------------------------

class WorldCreator:
    """Handles the world creation lifecycle:

    1. ``propose(user_input, llm_fn)``       →  a draft ``WorldProposal``
    2. ``preview(world_params)``             →  a ``WorldPreview`` (summary text)
    3. ``create(proposal, state_root)``      →  a new ``world_id`` (state on disk)
    4. ``fork(existing_world_id, overrides, state_root)`` → a forked ``world_id``
    """

    # ------------------------------------------------------------------
    # propose
    # ------------------------------------------------------------------
    @staticmethod
    def propose(user_input: str,
                llm_fn: Optional[Callable[[str], Dict[str, Any]]] = None
                ) -> WorldProposal:
        """Turn a user's one-sentence idea into a structured WorldProposal.

        When ``llm_fn`` is given it is called with ``user_input`` and must
        return a dict with keys matching ``WorldProposal`` fields. Without an
        LLM, generation fails explicitly; callers may still construct a
        ``WorldProposal`` themselves for a fully manual flow.
        """
        if llm_fn is not None:
            result = llm_fn(user_input)
            if isinstance(result, dict):
                return WorldProposal(**result)
            raise TypeError(
                f"llm_fn must return a dict, got {type(result)}"
            )

        raise RuntimeError(
            "WorldCreator.propose requires llm_fn; world generation has no "
            "offline or preset fallback"
        )

    # ------------------------------------------------------------------
    # preview
    # ------------------------------------------------------------------
    @staticmethod
    def preview(
        world_params: Optional[Union[Dict[str, Any], WorldProposal]] = None,
    ) -> WorldPreview:
        """Produce a deterministic preview using only explicitly enabled kernels.

        With no enabled preview adapter, this returns a stable neutral preview
        and does not instantiate any specialised kernel.  ``three_body`` is
        retained as an explicit adapter: it runs only when the supplied
        ``world_params`` (or proposal's ``world_params``) contains
        ``enabled_kernels`` with the exact value ``"three_body"``.

        Bakes the ``ThreeBodyKernel`` for ~200 simulation years at the
        given seed, then scans the timeline to estimate:

        - **avg_civ_duration**: mean survival time across civilizations
          started at staggered points on the baked timeline.
        - **num_rises_falls**: count of civilizations destroyed when their
          prediction horizon could not cover the next chaotic era.
        - **earliest_evac_civ**: the ordinal of the first civilisation for
          which ``evacuation_check`` returns True (the max-tech horizon is
          shorter than the mean chaotic-era gap).

        The ``summary_text`` is formatted per spec §11.5 so a user sees
        something like:
          "这个宇宙：文明平均存续12.3万年·你会见证5次兴衰·逃离最早可能在第7号文明"
        """
        if isinstance(world_params, WorldProposal):
            params = dict(world_params.world_params)
        else:
            params = dict(world_params or {})

        enabled_kernels = params.get("enabled_kernels")
        three_body_enabled = (
            isinstance(enabled_kernels, (list, tuple, set, frozenset))
            and "three_body" in enabled_kernels
        )
        if not three_body_enabled:
            return WorldPreview(
                avg_civ_duration=0.0,
                num_rises_falls=0,
                earliest_evac_civ=0,
                summary_text="世界草案已就绪；未启用可预跑的确定性内核。",
            )

        # Optional reference adapter: importing it here keeps generic world
        # proposal/create/preview usable without loading a specialised kernel.
        from .kernels.three_body import ThreeBodyKernel

        seed = int(params.get("seed", DEFAULT_WORLD_PARAMS["seed"]))
        kernel = ThreeBodyKernel(
            seed=seed,
            dt=0.02,
            lyapunov_renorms=8,
            lyapunov_renorm_steps=80,
        )
        try:
            kernel.bake(years=200.0)
        except RuntimeError as exc:
            # Unlikely with default params, but handle gracefully so the
            # preview never crashes a UI.
            return WorldPreview(
                avg_civ_duration=0.0,
                num_rises_falls=0,
                earliest_evac_civ=0,
                summary_text=f"内核初始化失败（{exc}），请尝试不同种子或参数。",
            )

        dt = kernel.dt
        total_steps = len(kernel.t)

        # Sample ~40 evenly-spaced starting points across the timeline.
        stride = max(1, total_steps // 40)
        sample_indices: Sequence[int] = list(range(0, total_steps - 1, stride))

        num_rises_falls = 0
        total_civs = 0
        total_duration = 0.0
        earliest_evac = 0

        for idx in sample_indices:
            start_time = float(kernel.t[idx])
            if start_time >= 190.0:           # leave headroom at end of timeline
                continue

            total_civs += 1
            t = start_time
            died = False
            max_levels = 16

            for level in range(max_levels):
                ev = kernel.civilization_step(float(level), t)
                if ev.kind == "destroyed":
                    num_rises_falls += 1
                    died = True
                    break
                # Survived -> advance past the chaotic era that was just faced
                if ev.next_chaos is not None:
                    t = ev.next_chaos + dt
                else:
                    t += 1.0

            duration = (t - start_time) if died else (t - start_time)
            total_duration += max(duration, 0.01)

            if earliest_evac == 0:
                if kernel.evacuation_check(max_tech=10.0):
                    earliest_evac = total_civs

        avg_dur = total_duration / max(total_civs, 1)

        summary = (
            f"这个宇宙：文明平均存续{avg_dur:.1f}万年·"
            f"你会见证{num_rises_falls}次兴衰"
        )
        if earliest_evac > 0:
            summary += f"·逃离最早可能在第{earliest_evac}号文明"

        return WorldPreview(
            avg_civ_duration=avg_dur,
            num_rises_falls=num_rises_falls,
            earliest_evac_civ=earliest_evac,
            summary_text=summary,
        )

    # ------------------------------------------------------------------
    # create
    # ------------------------------------------------------------------
    @staticmethod
    def create(proposal: WorldProposal, state_root: Path) -> str:
        """Fork a new world from a proposal.

        Creates an empty state store at ``state_root / state_{world_id}.json``
        and pins ``world_params`` inside the file's ``_meta`` so they are
        immutable for the world's lifetime (spec §10.4 / §11.4).

        Returns the new ``world_id`` string.
        """
        root = Path(state_root)
        root.mkdir(parents=True, exist_ok=True)

        # Do not let a repeated human-readable ID reopen and mutate an
        # existing world. The process-local lock also closes the common
        # concurrent onboarding race.
        with _CREATE_LOCK:
            world_id = _unique_world_id(root, proposal.world_id)
            store = JsonStateStore(root, world_id=world_id)
            with store._lock:
                state = store._load_raw()
                meta = state.setdefault("_meta", {})
                meta["world_params"] = deepcopy(proposal.world_params)
                meta["created_from"] = "world_creator"
                store._save(state)

        return world_id

    # ------------------------------------------------------------------
    # fork
    # ------------------------------------------------------------------
    @staticmethod
    def fork(existing_world_id: str,
             overrides: Dict[str, Any],
             state_root: Path) -> str:
        """Fork an existing world, applying parameter overrides.

        Reads the existing world's pinned ``world_params`` from its
        state file, merges ``overrides`` on top, then creates a brand-new
        world with the merged parameters.

        ``overrides`` may be empty to produce a clone, or may set new
        ``seed`` / ``lambda`` to explore variations.
        """
        root = Path(state_root)
        existing_store = JsonStateStore(root, world_id=existing_world_id)
        existing_state = existing_store._load_raw()

        existing_params = dict(
            existing_state.get("_meta", {}).get("world_params", {})
        )
        merged_params = {**existing_params, **overrides}

        proposal = WorldProposal(world_params=merged_params)
        return WorldCreator.create(proposal, root)
