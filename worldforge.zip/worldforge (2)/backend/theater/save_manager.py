"""Archive / load archive API (§13.1, §13.2, §10.5).

SaveManager 是世界快照的包装：

    save → 导出 zip（state.json + llm_log.json + meta.json）
    load → 解压到 state_root → 跑迁移链 → 返回 world_id
    list_saves → 列出 state_root 下所有存档的元信息 + 预览
    export_readable → §13.1 降级策略：人类可读历史文本
    verify → 完整性校验（schema 对齐 + JSON 合法）
    delete → 删除整个存档

zip 内命名约定（§13.2）：
    state.json         — 完整世界 state（_meta 已包含 sandbox / llm_output_log）
    llm_log.json       — LLM 输出日志（独立副本，便于快速重放读）
    meta.json          — zip 级元信息（导出时间、来源、版本）

纯 Python（标准库 zipfile + json），可单测。

sandbox 标记（§10.5）：
    load() 检测 `_meta.sandbox` 为 True 时返回 world_id 但通过 save_warnings
    字段传回告警字符串 — 调用方可以 log / 阻止并回正典。
"""

from __future__ import annotations

import io
import json
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .migrations import MigrationChain, get_default_chain
from .storage import JsonStateStore


# LLM 日志落到 state 的 _meta 字段名（§13.2 重放读取用）
LLM_LOG_META_KEY = "llm_output_log"


def _is_sandboxed(meta: Dict[str, Any]) -> bool:
    """Read the v6 integrity flag while accepting the legacy flat field."""
    flags = meta.get("integrity_flags")
    nested = flags.get("sandbox", False) if isinstance(flags, dict) else False
    return bool(meta.get("sandbox", nested))


@dataclass
class SaveResult:
    """save() 的返回值。"""

    path: Path
    world_id: str
    schema_version: int


@dataclass
class LoadResult:
    """load() 的返回值 — 包含 world_id 与可能的 sandbox 警告。"""

    world_id: str
    schema_version: int
    extracted_to: Path
    sandbox_warning: Optional[str] = None
    # 若迁移链无法抵达当前 SCHEMA_VERSION，则填这条信息（§13.1 降级）
    fallback_text_path: Optional[Path] = None


@dataclass
class SaveInfo:
    """list_saves() 每条存档的描述。"""

    world_id: str
    state_path: Path
    schema_version: int
    sandbox: bool
    created_from: Optional[str]
    characters_count: int
    worldbook_count: int
    objects_count: int
    meta_extra: Dict[str, Any] = field(default_factory=dict)


class SaveManager:
    """存档/读档对外 API。

    实例只承载策略（目标 schema 版本、迁移链）；state_root / world_id
    每次调用显式传入，避免实例状态被多线程互踩。
    """

    # zip 内固定文件名
    STATE_NAME = "state.json"
    LLM_LOG_NAME = "llm_log.json"
    META_NAME = "meta.json"

    def __init__(self, *, migration_chain: Optional[MigrationChain] = None,
                 target_schema_version: Optional[int] = None) -> None:
        self.migration_chain = migration_chain or get_default_chain()
        self.target_schema_version = (
            target_schema_version if target_schema_version is not None
            else JsonStateStore.SCHEMA_VERSION
        )

    # ------------------------------------------------------------------
    # save
    # ------------------------------------------------------------------

    def save(
        self,
        world_id: str,
        output_path: Path,
        *,
        state_root: Optional[Path] = None,
        llm_output_log: Optional[List[dict]] = None,
        world_state: Optional[Dict[str, Any]] = None,
    ) -> SaveResult:
        """导出世界为 zip。

        - world_state: 显式传入完整 state dict（zombie-state 路径，由调用方
          load + 可能地 mutate 后再 save）；None 时从 JsonStateStore 读。
        - state_root: 未显式传 world_state 时，从这里读取世界状态。
        - llm_output_log: LLM 日志；None → 读 state._meta.llm_output_log。

        返回 SaveResult；zip path 一定已落地。
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if world_state is None:
            store = JsonStateStore(
                Path(state_root) if state_root else output_path.parent,
                world_id=world_id,
            )
            state = store._load()
        else:
            state = dict(world_state)

        # §13.2 — LLM 日志进存档。重放读日志非重生成。
        meta = state.setdefault("_meta", {})
        meta.setdefault("schema_version", self.target_schema_version)
        meta.setdefault("world_id", world_id)
        integrity_flags = meta.get("integrity_flags")
        if not isinstance(integrity_flags, dict):
            integrity_flags = {}
        integrity_flags.setdefault("sandbox", bool(meta.pop("sandbox", False)))
        integrity_flags.setdefault("constraint_mutations", [])
        meta["integrity_flags"] = integrity_flags
        if llm_output_log is not None:
            meta[LLM_LOG_META_KEY] = list(llm_output_log)
        meta[LLM_LOG_META_KEY] = meta.get(LLM_LOG_META_KEY, [])

        # 写一份独立 llm_log.json（便于在不解析 state 时快速读取）
        llm_log_for_zip: List[dict] = list(meta.get(LLM_LOG_META_KEY) or [])

        zip_meta = {
            "world_id": world_id,
            "schema_version": state["_meta"].get("schema_version", 0),
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "llm_log_count": len(llm_log_for_zip),
            "llm_log_key": LLM_LOG_META_KEY,
        }

        # 用临时缓冲写，最后原子替换（覆盖旧 zip 不留半截文件）
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(self.STATE_NAME,
                        json.dumps(state, ensure_ascii=False, indent=2))
            zf.writestr(self.LLM_LOG_NAME,
                        json.dumps(llm_log_for_zip, ensure_ascii=False, indent=2))
            zf.writestr(self.META_NAME,
                        json.dumps(zip_meta, ensure_ascii=False, indent=2))

        output_path.write_bytes(buffer.getvalue())

        return SaveResult(
            path=output_path,
            world_id=world_id,
            schema_version=int(zip_meta["schema_version"]),
        )

    # ------------------------------------------------------------------
    # load
    # ------------------------------------------------------------------

    def load(self, zip_path: Path, state_root: Path) -> LoadResult:
        """导入 zip：解压 → state.json 落 state_root → 跑迁移 → 返回 world_id。

        §10.5：检测 _meta.sandbox，若 True 警告。
        §13.1：若迁移失败，导出可读 fallback 文本，但仍返回原 world_id
        （降级策略 — 用户至少能读存档留念，而不是拿到一个 NotFound）。
        """
        zip_path = Path(zip_path)
        state_root = Path(state_root)
        state_root.mkdir(parents=True, exist_ok=True)
        sandbox_warning: Optional[str] = None
        fallback_text_path: Optional[Path] = None

        with zipfile.ZipFile(zip_path, "r") as zf:
            # 必须有 state.json
            try:
                state_bytes = zf.read(self.STATE_NAME)
            except KeyError as exc:
                raise ValueError(
                    f"存档 zip 缺少 {self.STATE_NAME}: {zip_path}"
                ) from exc

            state = json.loads(state_bytes.decode("utf-8"))
            world_id = str(state.get("_meta", {}).get("world_id") or
                           zip_path.stem)

            # §10.5 — sandbox 标记检查
            sandbox = _is_sandboxed(state.get("_meta", {}))
            if sandbox:
                sandbox_warning = (
                    f"存档 '{world_id}' 启用了约束突变（sandbox=True），"
                    "不能并回正典世界。"
                )

            # §13.1 — 跑迁移链
            try:
                state = self.migration_chain.migrate(
                    state, target_version=self.target_schema_version,
                )
            except Exception as exc:
                # 失败：把可读降级文本写一份，然后仍然用原始 state 落地
                fallback_text = self.migration_chain.downgrade_export(state)
                fallback_text_path = state_root / f"fallback_{world_id}.txt"
                fallback_text_path.write_text(fallback_text, encoding="utf-8")
                # 仍以原始 state 写入（不升级 schema_version）
                state = state

            # §13.2 — 抽 LLM 日志（如不在 _meta 里）从 llm_log.json 顶上覆盖
            meta = state.setdefault("_meta", {})
            if LLM_LOG_META_KEY not in meta or not meta[LLM_LOG_META_KEY]:
                try:
                    llm_bytes = zf.read(self.LLM_LOG_NAME)
                    meta[LLM_LOG_META_KEY] = json.loads(
                        llm_bytes.decode("utf-8")
                    )
                except KeyError:
                    # zip 没带独立 llm_log.json — 容忍，不报错
                    pass

            # 写 state.json（命名约定与 JsonStateStore 对齐：main → state.json）
            state_filename = (
                "state.json" if world_id == "main"
                else f"state_{world_id}.json"
            )
            target_path = state_root / state_filename
            target_path.write_text(
                json.dumps(state, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

        return LoadResult(
            world_id=world_id,
            schema_version=int(state.get("_meta", {}).get("schema_version", 0)),
            extracted_to=state_root,
            sandbox_warning=sandbox_warning,
            fallback_text_path=fallback_text_path,
        )

    # ------------------------------------------------------------------
    # list_saves
    # ------------------------------------------------------------------

    def list_saves(self, state_root: Path) -> List[Dict[str, Any]]:
        """列出 state_root 下所有存档世界。

        不仅包括 load() 落地的 state_*.json，也包括历史 world_id='main'
        的 state.json。返回 dict 列表以方便 JSON 序列化（CLI / HTTP 通用）。
        """
        state_root = Path(state_root)
        if not state_root.exists():
            return []

        results: List[Dict[str, Any]] = []
        # 1) 命名的 worlds: state_<world_id>.json
        for path in sorted(state_root.glob("state_*.json")):
            wid = path.stem[len("state_"):]
            results.append(self._describe_save(path, wid))
        # 2) main：state.json
        main_path = state_root / "state.json"
        if main_path.exists():
            # 若 list 中已有同名 wid='main'（极少见），让 main 覆盖
            results = [r for r in results if r.get("world_id") != "main"]
            results.append(self._describe_save(main_path, "main"))
        return results

    def _describe_save(self, path: Path, world_id: str) -> Dict[str, Any]:
        try:
            state = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            # 损坏的存档也列出，但标坏
            return {
                "world_id": world_id, "state_path": str(path),
                "schema_version": 0, "sandbox": False,
                "created_from": None, "characters_count": 0,
                "worldbook_count": 0, "objects_count": 0,
                "corrupt": True,
            }
        meta = state.get("_meta") if isinstance(state, dict) else {}
        if not isinstance(meta, dict):
            meta = {}
        return {
            "world_id": world_id,
            "state_path": str(path),
            "schema_version": int(meta.get("schema_version", 0)),
            "sandbox": _is_sandboxed(meta),
            "created_from": meta.get("created_from"),
            "characters_count": len(state.get("characters", []) or []),
            "worldbook_count": len(state.get("worldbook", []) or []),
            "objects_count": len(state.get("objects", []) or []),
            "corrupt": False,
        }

    # ------------------------------------------------------------------
    # export_readable (降级 / 存档可读导出)
    # ------------------------------------------------------------------

    def export_readable(self, world_id: str, output_path: Path,
                        state_root: Optional[Path] = None) -> Path:
        """把指定 world 导出为可读历史记录（§13.1）。

        等价于：读世界 state → 调用 MigrationChain.downgrade_export → 写文件。
        即使迁移会失败也照常输出（fallback 是给用户的最后保障）。
        """
        state_root = state_root or Path("data/runtime")
        state_filename = (
            "state.json" if world_id == "main"
            else f"state_{world_id}.json"
        )
        state_path = state_root / state_filename
        if not state_path.exists():
            raise FileNotFoundError(f"未找到世界 '{world_id}'（{state_path}）")
        state = json.loads(state_path.read_text(encoding="utf-8"))
        text = self.migration_chain.downgrade_export(state)

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(text, encoding="utf-8")
        return output_path

    # ------------------------------------------------------------------
    # verify
    # ------------------------------------------------------------------

    def verify(self, world_id: str, state_root: Path) -> List[str]:
        """校验存档完整性。返回问题字符串列表；空列表 = 通过。

        检查项：
          - state 文件存在 + JSON 合法
          - schema_version 命中已注册路径（可达 SCHEMA_VERSION）
          - 必填 _meta 字段齐
        """
        state_root = Path(state_root)
        problems: List[str] = []

        state_filename = (
            "state.json" if world_id == "main"
            else f"state_{world_id}.json"
        )
        state_path = state_root / state_filename
        if not state_path.exists():
            problems.append(f"缺少 state 文件：{state_path}")
            return problems

        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            problems.append(f"state JSON 损坏：{exc}")
            return problems
        if not isinstance(state, dict):
            problems.append("state 顶层必须是 dict")
            return problems

        meta = state.get("_meta")
        if not isinstance(meta, dict):
            problems.append("state 缺少 _meta 块")
        else:
            for key in ("schema_version", "world_id"):
                if key not in meta:
                    problems.append(f"_meta 缺 {key}")
            try:
                ver = int(meta.get("schema_version", 0))
            except (TypeError, ValueError):
                problems.append("_meta.schema_version 不是整数")
                ver = 0
            # 迁移可达性
            try:
                self.migration_chain.migrate(state, target_version=self.target_schema_version)
            except Exception as exc:
                problems.append(f"迁移链无法从 v{ver} 到 v{self.target_schema_version}：{exc}")

            if world_id != "main" and meta.get("world_id") not in (world_id, None):
                problems.append(
                    f"_meta.world_id={meta.get('world_id')!r} 与请求 world_id={world_id!r} 不一致"
                )

        return problems

    # ------------------------------------------------------------------
    # delete
    # ------------------------------------------------------------------

    def delete(self, world_id: str, state_root: Path) -> bool:
        """删除整个世界存档及其编译后的规则/玩法规格。

        返回是否真的删了什么；不存在即返回 False。
        """
        state_root = Path(state_root)
        removed = False
        state_filename = (
            "state.json" if world_id == "main"
            else f"state_{world_id}.json"
        )
        state_path = state_root / state_filename
        if state_path.exists():
            state_path.unlink()
            removed = True

        for derived in (
            state_root / f"kernel_{world_id}.json",
            state_root / f"gameplay_{world_id}.json",
        ):
            if derived.exists():
                derived.unlink()
                removed = True

        # 顺手清 fallback / dashboard 等同 world 衍生文件
        for suffix in (".bak", ".fallback.txt"):
            sib = state_root / f"{state_filename}{suffix}"
            if sib.exists():
                sib.unlink()
                removed = True
        return removed
