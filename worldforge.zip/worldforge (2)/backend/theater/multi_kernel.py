"""Multi-kernel composition: micro-kernel skeleton + event bus + wave-sync tick.

Aligned with ``docs/kernel_architecture_design.md`` §3-4.

Public surface:
    - :class:`KernelModule`     — Protocol/ABC plugin contract
    - :class:`Event`             — bus event (type, source, path, payload)
    - :class:`OwnershipConflict` — assembly-time error (overlapping owns_paths)
    - :class:`ForbiddenWriteError` — runtime error (kernel wrote out of owns_paths)
    - :class:`EventBus`          — closed pub/sub with bounded waves
    - :class:`DslKernelModule`   — wraps ``WorldKernelHost`` as a KernelModule
    - :class:`ThreeBodyKernelModule` — wraps ``ThreeBodyKernel`` as a KernelModule
    - :class:`MultiKernelHost`   — multi-module scheduler with priority + waves

Design rules (the three iron rules from §3.3):
    1. read shared — any module may read any state path
    2. write own   — assembly rejects overlapping owns_paths (fail-fast)
    3. write others via events — never directly mutate another module's path

Pure stdlib; no external deps; unit-testable in isolation.
"""

from __future__ import annotations

import copy
import itertools
import logging
import random
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol, Tuple


logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bounded cascade depth — prevents infinite event loops.  See design §4.3.
MAX_WAVES: int = 5


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class OwnershipConflict(ValueError):
    """Raised at assembly time when two modules claim overlapping path prefixes."""


class ForbiddenWriteError(PermissionError):
    """Raised when a module writes a state path outside its owns_paths."""


class AssemblyError(ValueError):
    """Raised when module assembly fails (duplicate name, bad contract, etc.)."""


# ---------------------------------------------------------------------------
# Event dataclass
# ---------------------------------------------------------------------------


@dataclass
class Event:
    """A bus event — what modules publish to influence each other.

    The bus is closed: every event has a unique monotonic ``seq`` assigned by
    :meth:`EventBus.assign_seq` so reordering is deterministic across replays.
    """

    type: str
    source_kernel: str
    path: str
    payload: Dict[str, Any] = field(default_factory=dict)
    seq: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type,
            "source_kernel": self.source_kernel,
            "path": self.path,
            "payload": dict(self.payload),
            "seq": self.seq,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Event":
        return Event(
            type=d.get("type", ""),
            source_kernel=d.get("source_kernel", ""),
            path=d.get("path", ""),
            payload=dict(d.get("payload", {})),
            seq=int(d.get("seq", 0)),
        )


# ---------------------------------------------------------------------------
# KernelModule — the plugin contract
# ---------------------------------------------------------------------------


class KernelModule(Protocol):
    """A pluggable world-kernel module.

    Lifecycle: ``init`` → many ``step`` → ``shutdown``.  Modules read shared
    state, write only their own paths, and influence other modules via
    :class:`Event` published on the bus.
    """

    # -- static declarations (read at assembly) --

    @property
    def name(self) -> str:
        """Stable module identifier (unique within a host)."""

    @property
    def owns_paths(self) -> Tuple[str, ...]:
        """State-path prefixes this module may write."""

    @property
    def priority(self) -> int:
        """Execution priority.  Lower runs first.  physics<economy<society."""

    # -- lifecycle --

    def init(self, state: Dict[str, Any]) -> None:
        """One-shot initialization.  May seed derived data into *state*."""

    def step(self, state: Dict[str, Any], events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Run one tick.  Returns events produced this step.

        ``events`` are bus events from prior waves in the same tick (empty
        for the first wave).  Returned events enter the bus and are routed
        in subsequent waves.
        """

    def shutdown(self) -> None:
        """Reverse-order teardown.  Free any resources."""

    def check_invariants(self, state: Dict[str, Any]) -> List[str]:
        """Return list of violated invariant IDs.  Empty = all green."""


# ---------------------------------------------------------------------------
# EventBus — closed pub/sub with bounded waves
# ---------------------------------------------------------------------------


SubscriberFn = Callable[[Event], None]


class EventBus:
    """Closed event bus with path-pattern subscription and bounded drain.

    Subscriptions are *path-prefix* matches (``subscribe("economy.", cb)``
    receives every event whose ``path`` starts with ``"economy."``).  A
    subscription on the empty string matches every event.

    Each :meth:`drain` cycles through pending events at most
    :data:`MAX_WAVES` times to bound cascading.
    """

    def __init__(self, *, max_waves: int = MAX_WAVES) -> None:
        self._subs: List[Tuple[str, SubscriberFn]] = []
        self._queue: List[Event] = []
        self._seq: int = 0
        self._max_waves = max_waves
        self._dropped: List[Event] = []

    # -- subscription --

    def subscribe(self, path_pattern: str, callback: SubscriberFn) -> None:
        """Subscribe *callback* to events whose ``path`` starts with *path_pattern*."""
        if not isinstance(path_pattern, str):
            raise TypeError("path_pattern must be a string")
        if not callable(callback):
            raise TypeError("callback must be callable")
        self._subs.append((path_pattern, callback))

    def clear(self) -> None:
        self._subs = []
        self._queue = []
        self._dropped = []

    # -- publishing --

    def publish(self, event: Event) -> None:
        """Append *event* to the queue.  ``assign_seq`` will tag it."""
        if not isinstance(event, Event):
            event = Event.from_dict(event)  # tolerant
        self._queue.append(event)

    def assign_seq(self, events: List[Event]) -> List[Event]:
        """Tag each event with the next monotonic seq (deterministic ordering).

        Only events that don't already have a seq are tagged — this lets
        callers safely re-tag a queue that mixes tagged and untagged
        events without re-numbering already-numbered ones.
        """
        for ev in events:
            if ev.seq == 0:
                self._seq += 1
                ev.seq = self._seq
        return events

    # -- draining --

    def drain(self) -> List[Event]:
        """Process pending events in waves.

        Each wave:
          1. Snapshot the current queue (deterministic order — sorted by seq)
          2. Deliver each event to every subscriber whose pattern matches
          3. Subscribers may call :meth:`publish` to enqueue new events
          4. Stop when no more events arrive or after :data:`MAX_WAVES` waves

        Returns the list of events *delivered* (each exactly once).
        """
        delivered: List[Event] = []
        wave = 0
        while self._queue and wave < self._max_waves:
            # Wave batch: take a snapshot of the current queue, sorted by seq.
            batch = sorted(self._queue, key=lambda e: e.seq)
            self._queue = []
            for ev in batch:
                delivered.append(ev)
                for pattern, cb in self._subs:
                    if not pattern or ev.path.startswith(pattern) or ev.type == pattern:
                        cb(ev)
            wave += 1
        # Anything left in the queue past MAX_WAVES is dropped (and recorded).
        if self._queue:
            self._dropped.extend(self._queue)
            logger.warning(
                "EventBus: dropped %d events past MAX_WAVES=%d (cascade bound)",
                len(self._queue), self._max_waves,
            )
            self._queue = []
        return delivered

    def pending_count(self) -> int:
        return len(self._queue)

    def dropped_events(self) -> List[Event]:
        return list(self._dropped)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _validate_path_ownership(modules: List[KernelModule]) -> None:
    """Fail-fast at assembly: any two modules' ``owns_paths`` must not overlap.

    Two prefixes ``a`` and ``b`` conflict if either starts with the other —
    e.g. ``"economy"`` and ``"economy.price"`` overlap because the latter
    is a sub-path of the former.
    """
    claims: List[Tuple[str, str]] = []
    for m in modules:
        for p in m.owns_paths:
            if not isinstance(p, str) or not p:
                raise AssemblyError(
                    f"module {m.name!r} has non-string/empty owns_path {p!r}"
                )
            claims.append((m.name, p))
    for (id_a, pa), (id_b, pb) in itertools.combinations(claims, 2):
        if pa.startswith(pb) or pb.startswith(pa):
            raise OwnershipConflict(
                f"module {id_a!r} owns {pa!r} and module {id_b!r} owns {pb!r} "
                f"— path prefixes overlap (assembly rejected)"
            )


def _assert_owned(kernel_name: str, owns_paths: Tuple[str, ...], change_path: str) -> None:
    """Runtime guard: a change must target a path this kernel owns."""
    if not change_path:
        return  # empty path = meta-event, allowed
    for p in owns_paths:
        if change_path.startswith(p):
            return
    raise ForbiddenWriteError(
        f"kernel {kernel_name!r} tried to write {change_path!r} "
        f"outside its owns_paths {list(owns_paths)}"
    )


# ---------------------------------------------------------------------------
# DslKernelModule — wraps WorldKernelHost
# ---------------------------------------------------------------------------


class DslKernelModule:
    """Adapter that wraps a :class:`WorldKernelSpec` as a :class:`KernelModule`.

    The existing 47-test path (``WorldKernelHost(spec, state).step(event)``)
    is untouched; this module lets a multi-kernel host schedule the same
    DSL kernel among others.

    ``owns_paths`` are inferred from the compiled spec by scanning the
    effect ASTs for ``writes`` targets.  ``_events.*`` paths are filtered
    out (they are bus events, not state writes).

    Events produced inside a rule with ``op: "emit_event"`` are surfaced
    on the bus.  Each rule's ``trigger`` is treated as the event ``type``
    that fires it.

    Implementation note: the wrapped ``WorldKernelHost`` writes through
    ``_apply_change`` which mutates ``self._host._state`` in place.  We
    deliberately **share** that dict with the multi-kernel host's
    top-level state so the module's writes land where other modules can
    read them.  The old single-kernel path (``WorldKernelHost(spec, state)``)
    still does a deepcopy — that constructor is unchanged.
    """

    def __init__(
        self,
        name: str,
        spec: Any,                       # WorldKernelSpec (avoid hard import)
        *,
        priority: int = 200,
        seed: int = 0,
    ) -> None:
        # Local import keeps the module dependency-surface narrow and lets
        # this file be imported even if world_kernel_host is unavailable.
        self._name = name
        self._spec = spec
        self._priority = priority
        self._seed = seed
        # Lazy compile + host init — defer the heavy work.
        self._host: Optional[Any] = None
        self._owns_paths: Tuple[str, ...] = self._infer_owns_paths(spec)
        # Trigger -> rule kind (for routing events back into the right
        # WorldKernelHost.step calls).  Discovered from spec.
        self._triggers: List[str] = self._collect_triggers(spec)

    # -- KernelModule surface -------------------------------------------

    @property
    def name(self) -> str:
        return self._name

    @property
    def owns_paths(self) -> Tuple[str, ...]:
        return self._owns_paths

    @property
    def priority(self) -> int:
        return self._priority

    def init(self, state: Dict[str, Any]) -> None:
        from theater.world_kernel_host import WorldKernelHost  # local import
        # Construct the host with the *shared* state (no deepcopy) so its
        # writes are immediately visible to other modules.
        # WorldKernelHost.__init__ does deepcopy(state) internally, so we
        # patch the post-init state reference back to the caller's dict.
        host = WorldKernelHost(self._spec, {}, seed=self._seed)
        host._state = state  # type: ignore[attr-defined]
        self._host = host

    def step(self, state: Dict[str, Any], events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if self._host is None:
            raise RuntimeError(f"DslKernelModule {self._name!r}: init() not called")
        produced: List[Dict[str, Any]] = []
        # Each bus event that maps to a known trigger is fed into host.step.
        for ev in events:
            ev_type = ev.get("type", "")
            if ev_type in self._triggers:
                host_event = {
                    "trigger": ev_type,
                    "payload": ev.get("payload", {}),
                }
                changes = self._host.step(host_event)
                for c in changes:
                    # _events.emit is the legacy marker; surface it as a
                    # real bus event.
                    if c.get("path", "").startswith("_events."):
                        em = (c.get("value") or {}).get("event")
                        if isinstance(em, dict):
                            produced.append({
                                "type": em.get("name", em.get("type", "emit")),
                                "source_kernel": self._name,
                                "path": em.get("path", ""),
                                "payload": em.get("payload", {}),
                            })
                        elif em is not None:
                            produced.append({
                                "type": str(em),
                                "source_kernel": self._name,
                                "path": "",
                                "payload": {},
                            })
                        continue
                    # Real state write — enforce ownership.
                    _assert_owned(self._name, self._owns_paths, c.get("path", ""))
        return produced

    def shutdown(self) -> None:
        self._host = None

    def check_invariants(self, state: Dict[str, Any]) -> List[str]:
        if self._host is None:
            return []
        return self._host.check_invariants()

    # -- helpers --------------------------------------------------------

    @property
    def host(self) -> Any:
        """Underlying ``WorldKernelHost`` (mainly for tests + diagnostics)."""
        return self._host

    def _infer_owns_paths(self, spec: Any) -> Tuple[str, ...]:
        from theater.world_kernel_host import _extract_write_paths  # local
        out: List[str] = []
        for rule in getattr(spec, "rules", []) or []:
            if not getattr(rule, "enabled", True):
                continue
            for p in _extract_write_paths(getattr(rule, "effect", {}) or {}):
                if not p.startswith("_events."):
                    out.append(p)
        # Deduplicate, preserve order.
        seen: set = set()
        deduped: List[str] = []
        for p in out:
            if p not in seen:
                seen.add(p)
                deduped.append(p)
        return tuple(deduped)

    def _collect_triggers(self, spec: Any) -> List[str]:
        out: List[str] = []
        for rule in getattr(spec, "rules", []) or []:
            if not getattr(rule, "enabled", True):
                continue
            t = getattr(rule, "trigger", None)
            if t and t not in out:
                out.append(t)
        return out


# ---------------------------------------------------------------------------
# ThreeBodyKernelModule — wraps ThreeBodyKernel
# ---------------------------------------------------------------------------


class ThreeBodyKernelModule:
    """Adapter that wraps ``three_body.ThreeBodyKernel`` as a :class:`KernelModule`.

    Lifecycle:
        - ``init``     : if state lacks ``three_body.baked``, calls ``bake()``
        - ``step``     : consumes a ``time.accelerate`` event, advances the
                         civilization one step, writes results to
                         ``civilization.*`` (and optionally ``three_body.*``)
        - ``shutdown`` : clears references
        - ``check_invariants`` : energy_drift < 1e-3 and lambda > 0

    The kernel module is **deterministic** (symplectic Yoshida integrator
    with seeded numpy RNG).  Same seed → same baked timeline.
    """

    DEFAULT_TRIGGER = "time.accelerate"
    DEFAULT_OWNS = ("civilization", "three_body")

    def __init__(
        self,
        name: str = "three_body",
        *,
        priority: int = 100,
        seed: int = 88123,
        bake_years: float = 1000.0,
        owns_paths: Optional[Tuple[str, ...]] = None,
    ) -> None:
        self._name = name
        self._priority = priority
        self._seed = seed
        self._bake_years = bake_years
        self._owns_paths: Tuple[str, ...] = (
            owns_paths if owns_paths is not None else self.DEFAULT_OWNS
        )
        # Lazy import (numpy is heavy; tests may skip this kernel).
        from theater.kernels.three_body import ThreeBodyKernel  # local
        self._ThreeBodyKernel = ThreeBodyKernel
        self._kernel: Optional[Any] = None
        self._trigger: str = self.DEFAULT_TRIGGER
        self._t: float = 0.0            # current simulation time

    @property
    def name(self) -> str:
        return self._name

    @property
    def owns_paths(self) -> Tuple[str, ...]:
        return self._owns_paths

    @property
    def priority(self) -> int:
        return self._priority

    def init(self, state: Dict[str, Any]) -> None:
        kernel = self._ThreeBodyKernel(seed=self._seed)
        if not kernel.baked:
            kernel.bake(self._bake_years)
        self._kernel = kernel
        # Mirror baked timeline into state so other kernels can read it.
        state.setdefault("three_body", {})
        three = state["three_body"]
        three["baked"] = True
        three["lambda_"] = float(kernel.lambda_)
        three["energy_drift"] = float(kernel.energy_drift)
        three["eras"] = [
            {"start": e.start, "end": e.end, "kind": e.kind}
            for e in kernel.eras
        ]
        # Persist the t pointer if the host already seeded one.
        self._t = float(state.get("civilization", {}).get("t", 0.0))
        state.setdefault("civilization", {})
        civ = state["civilization"]
        civ.setdefault("t", self._t)
        civ.setdefault("last_event", None)

    def step(self, state: Dict[str, Any], events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if self._kernel is None:
            raise RuntimeError(f"ThreeBodyKernelModule {self._name!r}: init() not called")
        produced: List[Dict[str, Any]] = []
        for ev in events:
            if ev.get("type") != self._trigger:
                continue
            payload = ev.get("payload") or {}
            tech = float(payload.get("tech_level", 0.0))
            t_now = float(payload.get("t", self._t))
            result = self._kernel.civilization_step(tech, t_now)
            # Write to civilization (our own path).
            civ = state.setdefault("civilization", {})
            civ["t"] = t_now
            civ["last_event"] = {
                "kind": result.kind,
                "tech_level": result.tech_level,
                "delta_0": result.delta_0,
                "T_predict": result.T_predict,
                "next_chaos": result.next_chaos,
                "note": result.note,
            }
            self._t = t_now
            # Announce on the bus for downstream consumers (society, etc.).
            produced.append({
                "type": "civilization.tick",
                "source_kernel": self._name,
                "path": "civilization.last_event",
                "payload": {
                    "kind": result.kind,
                    "tech_level": result.tech_level,
                },
            })
            if result.kind == "destroyed":
                produced.append({
                    "type": "civilization.destroyed",
                    "source_kernel": self._name,
                    "path": "civilization.last_event",
                    "payload": {"tech_level": result.tech_level},
                })
        return produced

    def shutdown(self) -> None:
        self._kernel = None

    def check_invariants(self, state: Dict[str, Any]) -> List[str]:
        if self._kernel is None:
            return []
        failing: List[str] = []
        if float(self._kernel.energy_drift) >= 1e-3:
            failing.append("three_body.energy_drift_exceeded")
        if float(self._kernel.lambda_) <= 0.0:
            failing.append("three_body.lambda_nonpositive")
        return failing


# ---------------------------------------------------------------------------
# MultiKernelHost — the scheduler
# ---------------------------------------------------------------------------


class MultiKernelHost:
    """Multi-kernel scheduler: priority + bounded wave-sync + per-tick txn.

    One ``tick()`` = one :class:`StateTransaction` covering all modules.
    Cascade events are drained in waves (up to :data:`MAX_WAVES`) and each
    wave re-runs modules in priority order so a same-tick data dependency
    (econ reads physics-fresh resource) is satisfied.

    Determinism:
        - modules sorted by (priority, name) — total order
        - events sorted by monotonic ``seq`` — total order
        - per-module rng isolated via ``Random(hash((seed, name)))``
    """

    def __init__(
        self,
        modules: List[KernelModule],
        state: Dict[str, Any],
        *,
        seed: int = 0,
    ) -> None:
        # -- validate module names unique --
        seen: set = set()
        for m in modules:
            if m.name in seen:
                raise AssemblyError(f"duplicate module name {m.name!r}")
            seen.add(m.name)
        # -- ownership validation (fail-fast) --
        _validate_path_ownership(modules)
        # -- priority sort (stable) --
        self._modules: List[KernelModule] = sorted(
            list(modules), key=lambda m: (m.priority, m.name),
        )
        self._state = state
        self._seed = seed
        # -- per-kernel isolated rng --
        self._rngs: Dict[str, random.Random] = {
            m.name: random.Random(self._seed_for(m.name)) for m in self._modules
        }
        # -- event bus --
        self._bus = EventBus(max_waves=MAX_WAVES)
        # -- call init() on every module --
        for m in self._modules:
            m.init(self._state)

    # -- public API ----------------------------------------------------

    def state(self) -> Dict[str, Any]:
        return self._state

    def modules(self) -> List[KernelModule]:
        return list(self._modules)

    def bus(self) -> EventBus:
        return self._bus

    def rng_for(self, module_name: str) -> random.Random:
        return self._rngs[module_name]

    def add_module(self, module: KernelModule) -> None:
        """Runtime supplement.  Validates ownership before insertion."""
        if any(m.name == module.name for m in self._modules):
            raise AssemblyError(f"module {module.name!r} already present")
        # Ownership re-check against the full set.
        _validate_path_ownership(self._modules + [module])
        # Insert in priority order (stable).
        self._modules.append(module)
        self._modules.sort(key=lambda m: (m.priority, m.name))
        self._rngs[module.name] = random.Random(self._seed_for(module.name))
        module.init(self._state)

    def remove_module(self, name: str) -> None:
        for i, m in enumerate(self._modules):
            if m.name == name:
                m.shutdown()
                del self._modules[i]
                self._rngs.pop(name, None)
                return
        raise AssemblyError(f"module {name!r} not found")

    def tick(self, external_events: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
        """One full tick.  Returns the list of bus events delivered this tick.

        Steps:
          1. Snapshot the state (pre-tick copy) for atomic rollback.
          2. Drain external_events into the bus.
          3. For each wave (≤ MAX_WAVES):
              a. snapshot queue, sort by seq → initial_batch
              b. for each module in priority order:
                   module.step(state, events-it-hasn't-seen)
                   append newly produced events to in_wave_emitted
              c. carryover rule: an event emitted in this wave is
                 queued for the next wave ONLY IF no module in this
                 wave saw it.  Otherwise, the event has been "consumed"
                 by at least one module and its job is done.
          4. After the last wave: check invariants; rollback or commit.

        This rule is what enables the canonical "A emits → B consumes in
        the same wave" pattern (B has higher priority than A, so B sees
        A's event immediately) and also "A emits, no one reacts in wave
        1, B reacts in wave 2" for cascading.

        Trade-off: a module that emits an event AND has downstream
        consumers that ran before it in the priority order will not see
        the consumers react in the same wave.  This is intentional —
        the priority order is the contract for execution determinism.
        """
        external_events = external_events or []
        pre_tick_snapshot = copy.deepcopy(self._state)
        delivered: List[Dict[str, Any]] = []
        for ev in external_events:
            self._bus.publish(Event.from_dict(ev))
        self._bus.assign_seq(self._bus._queue)  # noqa: SLF001 (controlled)
        seen_pairs: set = set()
        try:
            wave = 0
            while wave < MAX_WAVES and (wave == 0 or self._bus.pending_count()):
                initial_batch = sorted(
                    self._bus._queue, key=lambda e: e.seq  # noqa: SLF001
                )
                self._bus._queue = []  # noqa: SLF001
                in_wave_emitted: List[Event] = []
                # Set of seqs that at least one module "saw" this wave.
                seen_in_wave: set = set()
                for ev in initial_batch:
                    delivered.append(ev.to_dict())
                for m in self._modules:
                    visible: List[Event] = []
                    for ev in initial_batch + in_wave_emitted:
                        if (ev.seq, m.name) in seen_pairs:
                            continue
                        seen_pairs.add((ev.seq, m.name))
                        visible.append(ev)
                    if visible:
                        for ev in visible:
                            seen_in_wave.add(ev.seq)
                    batch_dicts = [ev.to_dict() for ev in visible]
                    produced = m.step(self._state, batch_dicts)
                    for p in produced:
                        ev_obj = Event.from_dict(p)
                        self._bus._seq += 1  # noqa: SLF001
                        ev_obj.seq = self._bus._seq  # noqa: SLF001
                        seen_pairs.add((ev_obj.seq, m.name))
                        # The producer saw its own event by definition.
                        seen_in_wave.add(ev_obj.seq)
                        in_wave_emitted.append(ev_obj)
                # Carryover rule: only events that NO module saw this wave.
                for ev in in_wave_emitted:
                    if ev.seq not in seen_in_wave:
                        self._bus._queue.append(ev)  # noqa: SLF001
                self._bus.assign_seq(self._bus._queue)  # noqa: SLF001
                wave += 1
            if self._bus.pending_count():
                self._bus.drain()  # captures dropped events
            # Aggregate invariants across all modules.
            failing: List[str] = []
            for m in self._modules:
                failing.extend(m.check_invariants(self._state))
            if failing:
                self._state.clear()
                self._state.update(pre_tick_snapshot)
                raise InvariantViolation(failing)
        except InvariantViolation:
            raise
        except Exception:
            self._state.clear()
            self._state.update(pre_tick_snapshot)
            raise
        return delivered

    # -- internals -----------------------------------------------------

    def _seed_for(self, name: str) -> int:
        # Deterministic, per-kernel rng isolation.  Hash is fine — we want
        # a stable mapping from (seed, name) -> int, not cryptographic.
        return hash((self._seed, name)) & 0x7FFFFFFF


# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------


class InvariantViolation(RuntimeError):
    """Raised when per-tick invariants fail; the tick is rolled back."""


__all__ = [
    "Event",
    "EventBus",
    "KernelModule",
    "MultiKernelHost",
    "ThreeBodyKernelModule",
    "DslKernelModule",
    "OwnershipConflict",
    "ForbiddenWriteError",
    "AssemblyError",
    "InvariantViolation",
    "MAX_WAVES",
]
