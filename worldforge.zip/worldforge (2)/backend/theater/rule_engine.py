"""Deterministic rule engine for world-state validation (§3.2, §9.4).

Architecture spec §2.3 / §3.2:
  90% of writes are validated here (deterministic, <1ms).
  10% go to LLM for semantic adjudication (async, seconds).

Usage::

    engine = RuleEngine(dag=my_dag, checker=my_conservation_checker)
    result = engine.validate(change, current_state)
    if result.approved:
        if engine.needs_llm_adjudication(change, current_state):
            # send result.llm_question to LLM, wait for verdict
        else:
            # apply directly
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol


# ---------------------------------------------------------------------------
# RuleResult
# ---------------------------------------------------------------------------


@dataclass
class RuleResult:
    """Result of a rule-engine validation.

    Attributes:
        approved:      All deterministic checks passed.
        reasons:       Human-readable list of why approved or denied.
        needs_llm:     True if the change requires semantic LLM adjudication.
        llm_question:  Question to pose to the LLM (only set when needs_llm).
    """

    approved: bool
    reasons: List[str] = field(default_factory=list)
    needs_llm: bool = False
    llm_question: Optional[str] = None

    @staticmethod
    def ok(*, needs_llm: bool = False, llm_question: Optional[str] = None) -> "RuleResult":
        return RuleResult(
            approved=True,
            reasons=["all deterministic checks passed"],
            needs_llm=needs_llm,
            llm_question=llm_question,
        )

    @staticmethod
    def deny(reason: str, *more_reasons: str) -> "RuleResult":
        return RuleResult(
            approved=False,
            reasons=[reason, *more_reasons],
        )


# ---------------------------------------------------------------------------
# DAG protocol (avoid circular import of dag.PrerequisiteDAG)
# ---------------------------------------------------------------------------


class DAGProtocol(Protocol):
    """Minimal interface expected by RuleEngine for DAG reachability checks."""

    def has_node(self, node_id: str) -> bool: ...
    def can_reach(self, node_id: str) -> bool: ...


# ---------------------------------------------------------------------------
# ConservationChecker
# ---------------------------------------------------------------------------

InvariantFn = Callable[[List[Dict[str, Any]], Dict[str, Any]], bool]
"""Signature::

    def my_invariant(
        changes: list[dict],          # the change dicts from StateChange.changes
        state: dict,                   # current world state snapshot
    ) -> bool:
        ...

Return True if the invariant holds, False if violated.
"""


class ConservationChecker:
    """Registry of conservation invariants for economic/resource/inventory checks.

    Each invariant is a named function that receives the full list of changes
    and the current world state.  The default set covers basic resource and
    economic conservation; callers may register additional invariants via
    ``register``.
    """

    def __init__(self) -> None:
        self._invariants: Dict[str, InvariantFn] = {}
        self._register_defaults()

    # -- public API ---------------------------------------------------------

    def register(self, name: str, check_fn: InvariantFn) -> None:
        """Register a named invariant."""
        self._invariants[name] = check_fn

    def unregister(self, name: str) -> None:
        """Remove a previously registered invariant (no-op if absent)."""
        self._invariants.pop(name, None)

    def check(self, changes: List[Dict[str, Any]], state: dict) -> bool:
        """Run all registered invariants.  Returns True iff *all* pass."""
        for name, fn in self._invariants.items():
            if not fn(changes, state):
                return False
        return True

    def failing(self, changes: List[Dict[str, Any]], state: dict) -> List[str]:
        """Return names of invariants that fail (empty = all pass)."""
        failed: List[str] = []
        for name, fn in self._invariants.items():
            if not fn(changes, state):
                failed.append(name)
        return failed

    @property
    def invariant_names(self) -> List[str]:
        return list(self._invariants.keys())

    # -- defaults -----------------------------------------------------------

    def _register_defaults(self) -> None:
        self.register("resource_total_conserved", _resource_total_conserved)
        self.register("economy_total_conserved", _economy_total_conserved)
        self.register("inventory_non_negative", _inventory_non_negative)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize registry metadata (names only, not the callables)."""
        return {
            "kind": "conservation_checker",
            "schema_version": 1,
            "invariants": list(self._invariants.keys()),
        }


# -- default invariants -------------------------------------------------------


def _resource_total_conserved(changes: List[Dict[str, Any]], state: dict) -> bool:
    """Check that total resource quantity does not change without explicit
    production/consumption nodes.

    Production paths use the pattern ``resources.produce.XXX``,
    ``resources.gather.XXX``; consumption paths use ``resources.consume.XXX``.
    If ANY change touches an exempt production/consumption path, conservation
    is waived entirely (production intrinsically breaks conservation).
    """
    resources: Dict[str, float] = {}
    for k, v in state.get("resources", {}).items():
        if isinstance(v, (int, float)):
            resources[k] = float(v)

    if not resources:
        return True  # nothing to conserve

    has_exempt = False
    new_resources = dict(resources)

    for c in changes:
        path: str = c.get("path", "")
        if not path.startswith("resources."):
            continue
        key = path[len("resources."):]
        # exempt production / consumption paths (key starts with produce/gather/consume)
        if key.startswith("produce") or key.startswith("gather") or key.startswith("consume"):
            has_exempt = True
            continue
        op: str = c.get("op", "set")
        if op == "delete":
            new_resources.pop(key, None)
        elif op == "set":
            val = c.get("value")
            if isinstance(val, (int, float)):
                new_resources[key] = float(val)

    if has_exempt:
        return True

    before = sum(resources.values())
    after = sum(new_resources.values())
    return abs(before - after) < 1e-9


def _economy_total_conserved(changes: List[Dict[str, Any]], state: dict) -> bool:
    """Check that economy/currency totals are conserved unless an explicit
    ``economy.transfer.XXX`` or ``economy.mint.XXX`` path is written."""
    economy: Dict[str, float] = {}
    for k, v in state.get("economy", {}).items():
        if isinstance(v, (int, float)):
            economy[k] = float(v)

    if not economy:
        return True

    has_exempt = False
    new_economy = dict(economy)

    for c in changes:
        path = c.get("path", "")
        if not path.startswith("economy."):
            continue
        key = path[len("economy."):]
        if key.startswith("transfer") or key.startswith("mint"):
            has_exempt = True
            continue
        op = c.get("op", "set")
        if op == "delete":
            new_economy.pop(key, None)
        elif op == "set":
            val = c.get("value")
            if isinstance(val, (int, float)):
                new_economy[key] = float(val)

    if has_exempt:
        return True

    before = sum(economy.values())
    after = sum(new_economy.values())
    return abs(before - after) < 1e-9


def _inventory_non_negative(changes: List[Dict[str, Any]], state: dict) -> bool:
    """Check that no inventory/resource count drops below zero."""
    state_inv = state.get("inventory", {})
    # build current snapshot
    current: Dict[str, float] = {}
    for k, v in state_inv.items():
        if isinstance(v, (int, float)):
            current[k] = float(v)

    for c in changes:
        path = c.get("path", "")
        op = c.get("op", "set")
        if not path.startswith("inventory."):
            continue
        if op == "delete":
            return False  # deleting an inventory item is never allowed
        val = c.get("value")
        if isinstance(val, (int, float)) and float(val) < 0:
            return False
        # simulate the new value
        key = path[len("inventory."):]
        new_val = float(val) if isinstance(val, (int, float)) else current.get(key, 0.0)
        if new_val < 0:
            return False

    return True


# ---------------------------------------------------------------------------
# RuleEngine
# ---------------------------------------------------------------------------


class RuleEngine:
    """Deterministic rule engine for world-state writes.

    Five checks (all <1ms on typical state):
      1. Schema validity  — required fields exist, types correct
      2. Numerical ranges — values within domain bounds
      3. Reference integrity — referenced entities exist
      4. DAG reachability    — prerequisite nodes are unlocked
      5. Conservation laws   — economic/resource totals conserved

    After these pass, a separate heuristic decides whether LLM semantic
    adjudication is needed (~10% of writes).
    """

    def __init__(
        self,
        dag: Optional[DAGProtocol] = None,
        checker: Optional[ConservationChecker] = None,
    ) -> None:
        self._dag = dag
        self._checker = checker or ConservationChecker()

    # -- public API ---------------------------------------------------------

    def validate(self, change: "StateChange", state: dict) -> RuleResult:
        """Run all five deterministic checks.  Returns a ``RuleResult``.

        The ``StateChange`` type is imported lazily to avoid circular deps;
        it must have ``.changes`` (list[dict]), ``.prerequisites_checked``
        (list[str]) and optionally ``.origin`` (str).
        """
        # 1. Schema validity
        result = self._check_schema(change, state)
        if not result.approved:
            return result

        # 2. Numerical ranges
        result = self._check_ranges(change, state)
        if not result.approved:
            return result

        # 3. Reference integrity
        result = self._check_references(change, state)
        if not result.approved:
            return result

        # 4. DAG reachability
        result = self._check_dag(change, state)
        if not result.approved:
            return result

        # 5. Conservation laws
        result = self._check_conservation(change, state)
        if not result.approved:
            return result

        return RuleResult.ok()

    def needs_llm_adjudication(self, change: "StateChange", state: dict) -> bool:
        """Heuristic: does this change require LLM semantic adjudication?

        Returns True when the deterministic checks pass but the change
        touches semantically ambiguous territory — temporal paradoxes,
        character continuity, narrative consistency, etc.
        """
        has_temporal = any(
            "temporal" in c.get("path", "").lower()
            or "timeline" in c.get("path", "").lower()
            for c in change.changes
        )
        has_continuity = any(
            "continuity" in c.get("path", "").lower()
            or "narrative" in c.get("path", "").lower()
            for c in change.changes
        )
        has_character_death = any(
            "dead" in str(c.get("value", "")).lower()
            or "killed" in str(c.get("value", "")).lower()
            for c in change.changes
        )
        # cross-chapter semantic conflict
        has_cross_chapter = any(
            "chapter" in c.get("path", "").lower() and c.get("op") == "delete"
            for c in change.changes
        )

        return has_temporal or has_continuity or has_character_death or has_cross_chapter

    def build_llm_question(self, change: "StateChange", state: dict) -> str:
        """Construct the question to send to the LLM for semantic adjudication."""
        paths = [c.get("path", "?") for c in change.changes]
        return (
            f"Does the proposed state change (paths: {paths}) conflict with "
            f"established narrative semantics (temporal consistency, character "
            f"continuity, chapter chronology)?  State keys: {list(state.keys())}."
        )

    # -- schema check -------------------------------------------------------

    def _check_schema(self, change: "StateChange", state: dict) -> RuleResult:
        """1. Schema validity: required fields present, types correct."""
        reasons: List[str] = []

        if not change.changes:
            return RuleResult.deny("change has no entries")

        for i, c in enumerate(change.changes):
            if not isinstance(c, dict):
                return RuleResult.deny(f"change[{i}] is not a dict")
            if "path" not in c:
                return RuleResult.deny(f"change[{i}] missing 'path'")
            if c.get("op") not in ("set", "delete"):
                return RuleResult.deny(
                    f"change[{i}] op={c.get('op')!r} is not 'set' or 'delete'"
                )
            if c["op"] == "set" and "value" not in c:
                return RuleResult.deny(f"change[{i}] has op=set but no 'value'")

        if hasattr(change, "origin") and change.origin == "llm_adjudication":
            if not change.adjudication_ref:
                return RuleResult.deny("llm_adjudication origin requires adjudication_ref")
        if not change.prerequisites_checked:
            reasons.append("prerequisites_checked is empty")

        if reasons:
            return RuleResult(approved=True, reasons=reasons)
        return RuleResult.ok()

    # -- numerical range check ----------------------------------------------

    # Domain bounds: path prefix -> (field, min, max) or path prefix -> dict
    _RANGE_RULES: Dict[str, Any] = {
        "technology.": {"min": 0, "max": 10},
        "civilization.": {"min": 0},              # count >= 0, no upper bound
        "character_stats.level": {"min": 1, "max": 100},
        "character_stats.health": {"min": 0, "max": 9999},
        "character_stats.strength": {"min": 1, "max": 100},
    }

    def _check_ranges(self, change: "StateChange", state: dict) -> RuleResult:
        """2. Numerical ranges: values within domain bounds."""
        for c in change.changes:
            val = c.get("value")
            if not isinstance(val, (int, float)):
                continue
            path = c.get("path", "")
            for prefix, rule in self._RANGE_RULES.items():
                if path.startswith(prefix) or path == prefix.rstrip("."):
                    rule_min = rule.get("min")
                    rule_max = rule.get("max")
                    if rule_min is not None and val < rule_min:
                        return RuleResult.deny(
                            f"{path}={val} below minimum {rule_min}"
                        )
                    if rule_max is not None and val > rule_max:
                        return RuleResult.deny(
                            f"{path}={val} above maximum {rule_max}"
                        )
                    break
        # also check implicit range rules from state schema
        # technology.* values (top-level dict like state["technology"]["combat"])
        tech = state.get("technology", {})
        for c in change.changes:
            path = c.get("path", "")
            if path.startswith("technology."):
                val = c.get("value")
                if isinstance(val, (int, float)):
                    if val < 0 or val > 10:
                        return RuleResult.deny(
                            f"technology value {path}={val} out of range [0, 10]"
                        )
        return RuleResult.ok()

    # -- reference integrity ------------------------------------------------

    def _check_references(self, change: "StateChange", state: dict) -> RuleResult:
        """3. Reference integrity: referenced entities exist."""
        characters = {e.get("character_id") or e.get("id") for e in state.get("characters", [])}
        characters.discard(None)
        objects = {e.get("object_id") or e.get("id") for e in state.get("objects", [])}
        objects.discard(None)
        worldbook_titles = {e.get("title") for e in state.get("worldbook", [])}

        for c in change.changes:
            val = c.get("value")
            if not isinstance(val, dict):
                continue
            ref_id = val.get("character_id") or val.get("ref_character")
            if ref_id is not None and ref_id not in characters:
                return RuleResult.deny(f"references unknown character {ref_id!r}")
            ref_obj = val.get("object_id") or val.get("ref_object")
            if ref_obj is not None and ref_obj not in objects:
                return RuleResult.deny(f"references unknown object {ref_obj!r}")
            ref_wb = val.get("worldbook_title") or val.get("ref_worldbook")
            if ref_wb is not None and ref_wb not in worldbook_titles:
                return RuleResult.deny(f"references unknown worldbook entry {ref_wb!r}")

        return RuleResult.ok()

    # -- DAG reachability ----------------------------------------------------

    def _check_dag(self, change: "StateChange", state: dict) -> RuleResult:
        """4. DAG reachability: prerequisite nodes are unlocked.

        If no DAG is configured, this check is skipped (passes trivially).
        """
        if self._dag is None:
            return RuleResult.ok()

        for pre_id in change.prerequisites_checked:
            if not self._dag.has_node(pre_id):
                return RuleResult.deny(f"prerequisite node {pre_id!r} does not exist in DAG")
            if not self._dag.can_reach(pre_id):
                return RuleResult.deny(f"prerequisite node {pre_id!r} is not reachable")

        return RuleResult.ok()

    # -- conservation --------------------------------------------------------

    def _check_conservation(self, change: "StateChange", state: dict) -> RuleResult:
        """5. Conservation laws: economic/resource totals conserved."""
        failed = self._checker.failing(change.changes, state)
        if failed:
            return RuleResult.deny(
                f"conservation invariant(s) violated: {', '.join(failed)}"
            )
        return RuleResult.ok()

    # -- misc ----------------------------------------------------------------

    def set_dag(self, dag: DAGProtocol) -> None:
        """Set or replace the DAG used for reachability checks."""
        self._dag = dag
