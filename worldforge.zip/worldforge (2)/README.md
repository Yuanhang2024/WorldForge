# WorldForge

> **一个 LLM 立法、确定性内核司法的通用 AI 世界模拟框架。**
>
> 大多数 AI 世界生成器让 LLM 编故事——随机且不可复现。WorldForge
> 让 LLM 只起草规则，确定性内核执行规则。运行时协议不绑定世界观；
> 三体物理只是一个参考内核适配器，用来证明“结局来自计算而不是编写”。

---

## 定位：立法与司法分离

现有的 AI 世界生成器把 LLM 同时当成**立法者**（定规则）和**法官**（判结果）。后果是世界失去必然性——退化成一台随机故事生成器：同一个 seed 跑两遍结果不同，用户"自信断言"就能改写真相，凶手是谁取决于上一句问了谁。

WorldForge 在编译期就切开这条边界：

| 角色 | 谁来做 | 管什么 |
|---|---|---|
| **立法（起草人）** | LLM（标准 OpenAI 协议，任意供应商） | 起草世界参数、规则草案、剧情叙述——只提议，不裁决 |
| **司法（法官）** | 确定性内核 | 物理积分、守恒校验、前提可达性、存亡判定——地面真相 |

这条边界就是全局红线 **I2**：**LLM 不得裁定任何有确定性真相源的事。** 一旦让 LLM 决定"这次预测成功了没有"，逃离就失去必然性。内核算出数字，LLM 只把数字翻译成剧情。

LLM 是世界创建和语义运行的必需依赖。未配置模型，或模型调用、解析、结构
校验失败时，对应阶段立即失败并保留原有状态；系统不会安装通用规则、生成替代
GUI 或拼接替代叙事。已确认规则的确定性执行，以及显式启用适配器的物理计算，
可以在不调用模型时继续运行，但它们不替代创建或语义工作。

---

## 核心卖点

### 1. I2 红线：LLM 不当法官

状态变更不从 LLM 自由文本直接写入（**I3**），必须先成为结构化变更并经过确定性校验。写入统一收敛到编排器的写入点（**I4**）；需要语义判断的请求也不能绕过状态验证。这里不承诺固定的延迟或调用比例，实际表现取决于规则和供应商。

### 6. 确定性涌现：条件触发 + 事件链

`WorldKernelHost` 支持声明式条件触发和事件链：规则不是每 tick 无条件执行，而是当状态越过阈值时自动点火。infected > 50 → 自动隔离 → demand 骤降一半；demand < 30 → 自动刺激 → 医疗资源增加。**没有人干预，世界自己产生连锁反应**——同 seed 每次运行一模一样。一次性门控保证链不循环，守恒规则保证涌现不造钱。

```python
auto_quarantine = WorldRule(
    rule_id="auto_quarantine",
    kind="dynamic",
    trigger={"op": "and", "args": [
        {"op": "gt", "args": [{"ref": "infected"}, {"const": 50}]},
        {"op": "not", "args": [{"ref": "policy.quarantine"}]},
    ]},
    effect={"emit": "quarantine_started", "writes": "policy.quarantine",
            "op": "set", "value": True},
)
```

### 7. 多内核组合：物理+经济同 tick 运行

`MultiKernelHost` 是一个微内核骨架 + 事件总线 + 波次调度器，支持在同一 tick 内按优先级依次执行多个内核。事件通过总线跨内核传递：物理内核的 `civilization.destroyed`（乱纪元）触发经济内核需求下降 20%——灾难有物理必然性，经济影响有确定性因果关系。

- **kernel write own**：装配期校验 owns_paths 无重叠，运行时禁止越界写
- **事件总线**：pub/sub，最大 5 波级联防无限循环，同 tick 内原子传递
- **波次调度**：priority 排序，先物理后经济
- **确定性**：同 seed 两次独立运行轨迹完全一致

```python
host = MultiKernelHost([physics_module, economy_module], state, seed=42)
host.tick(external_events=[time.accelerate, turn.tick])
```

### 8. 运行时世界内核：规则 DSL → 编译器 → 确定性执行

`WorldKernelHost` 让 LLM 起草 JSON DSL 规则（如生产、消费、价格调整），`RuleCompiler` 编译为确定性 Python 内核并执行——LLM 绝不触达结果（立法/司法分离）。内置 AST 操作白名单（四则运算、比较、逻辑、lookup），杜绝注入。

`WorldKernelHost` 只执行已通过 DSL 校验与编译的自定义规则。自然语言规则的
LLM 生成、解析或校验失败时，创建/变更阶段失败且不安装任何替代规则；用户可
修订输入后重新发起请求。

### 2. 可选参考适配器

仓库可以包含针对特定可计算领域的参考内核适配器，用于验证复杂规则也能
接受确定性裁决。它们必须由用户或已确认的世界配置显式启用：通用创建流程、
降级流程和模型路由都不会依据世界描述自动选择适配器，也不会把某个适配器的
规则当作默认世界规则。

### 3. 世界隔离

`world_id` 命名空间，多世界同时存在互不串扰。每世界独立状态文件、独立烘焙时间线、独立仪表盘。构成性约束（λ、物理、初值）创建后不可变——要变只能 **fork 新世界**，不能 mutate 正典。

### 4. 全确定性内核测试覆盖

确定性内核全部可单测（必须全绿）：物理能量守恒、DAG 无环、事务快照/提交/回滚可复现、规则引擎校验与黄金脚本回归。内核测试不过 → 不允许合并。

### 5. 可本地运行 + OpenAI-compatible 供应商

单机运行，代码全开源。LLM 通过 OpenAI-compatible `/v1/chat/completions` 协议连接，可以是本地 LM Studio/Ollama/vLLM，也可以是实现兼容接口的云端服务。创建世界和请求语义结果前必须配置可用的 `base_url`、`api_key` 与模型；已确认规则的确定性重放不需要重新调用模型。

---

## 架构

```
用户层
   ↓
交互显示层     Tk 模型配置 + 浏览器动态 GUI（角色卡、状态投影、COMMIT）
   ↓
网关与路由层   HTTP 网关 + world_id 隔离 + 模型角色路由
   ↓
执行与语义层
 ├─ 确定性执行路径        已确认规则 · 状态校验 · 显式适配器物理计算
 └─ LLM 必需语义路径      创建 / 规则提议 / 叙事 / GUI / 语义交互（失败即阻断）
   ↓
═══════════ 立法/司法边界（I2）═══════════
   ↓
世界内核层（确定性，可单测）
   已确认的规则 DSL · 前提 DAG · 状态事务 · 规则引擎 · 显式启用的适配器
   ↓
数据层         世界书 · 文本角色实体 · 场景对象
   ↓
持久层         存档(schema 版本) · 迁移链 · 完整性标记
```

框架提供四类可组合的通用机制；它们覆盖常见需求，但不声称自动覆盖全部场景：

| 机器 | 覆盖 |
|---|---|
| 内核库 + 规则 DSL | 玩法、状态变化、场景逻辑 |
| 前提 DAG + 可达性校验 | 认知进展、配方/建造、任务前置 |
| 状态事务（快照/提交/回滚） | 时间加速、反事实、投机缓冲 |
| 守恒/不变量校验 | 经济、资源、库存、人口 |

---

## 模块清单

**世界内核（确定性核心）**

| 模块 | 职责 |
|---|---|
| `kernels/` | 可选参考适配器；仅由显式配置装配 |
| `dag.py` | 前提 DAG（认知链/配方树通用），可达性查询 |
| `transactions.py` | 状态事务：快照 / 提交 / 回滚 |
| `rule_engine.py` | 规则引擎：5 项确定性校验 + LLM 裁定拆分 |
| `game_kernels.py` | 参数化玩法内核库（结算零 LLM） |
| `gates.py` | 校验门 |
| `multi_kernel.py` | 多内核组合：微内核骨架 + EventBus + MultiKernelHost + 波次调度 |
| `world_kernel_host.py` | 运行时世界内核主机：规则 DSL → RuleCompiler → 确定性执行 + ExprEvaluator |

**世界生命周期**

| 模块 | 职责 |
|---|---|
| `world_creation.py` | 世界 propose / preview / create / fork |
| `world_import.py` | ST 卡片导入编译 + 注入防护 |
| `migrations.py` | schema 版本 + 迁移链 |
| `storage.py` | JSON 状态存储（world_id 隔离） |
| `idle_loop.py` | 空闲循环（世界自主推进，带饱和上限） |
| `save_manager.py` | 存档管理：save / load / list / verify / delete（zip + schema 迁移） |
| `gui_generator.py` | GUI 生成：每世界自定义 UI（propose+confirm 流程，LLM 提议→用户编辑→确认） |
| `onboarding_*.py` | 9 个 propose+confirm 端点：每步 LLM 预填表单 → 用户审查编辑 → 确认。覆盖规则/GUI/认知模型/玩法 |

**智能层与推理优化**

| 模块 | 职责 |
|---|---|
| `dispatcher.py` | 编排器：连接内核、LLM、AgentMind 与单一写入点 |
| `agents.py` | 模型客户端（测试/演示可显式注入 `DeterministicModelClient` stub） |
| `prefix_cache.py` | RadixAttention 前缀缓存 |
| `best_of_n.py` | Best-of-N 采样 + 重排 |
| `speculative_decode.py` | 投机解码（draft + target） |
| `capability_report.py` / `provider_diagnostics` | 文本模型与 embedding 能力探测 / 供应商诊断 |

**动态 GUI（`web/`）**

世界描述 → GUI 规格 → 通用控件装载；意图通过统一 router 接入
`/api/dispatch`、`/api/interact` 和 `/api/world/tick`，COMMIT 后由内核裁决。

**服务与配置**：`server.py`（stdlib HTTP server）· `runtime.py` · `settings.py` · `models.py`

---

## 推荐 GUI 入口

```bash
# Windows
launch.bat

# Linux / macOS
./launch.sh
```

在 Tk 窗口中配置 OpenAI-compatible Base URL/API Key，拉取并选择
fast/deep 模型，然后启动后端。浏览器内可完成世界创建、分步向导、交互、
COMMIT、快进、生成规则/玩法以及存读档。模型路由只按 Agent 能力角色，
不与任何世界观绑定。

## CLI 用法

```bash
python worldforge.py "示例世界" --tick            # 推进已编译的世界规则
python worldforge.py --list                       # 列出所有世界
python worldforge.py "示例世界" --save out.zip    # 导出存档
python worldforge.py --load save.zip              # 导入存档
python worldforge.py --saves                      # 列出所有存档
```

CLI 是纯 Python（argparse）入口。创建、规则生成及任何语义请求同样需要已配置且
成功响应的 LLM；缺失或失败会返回错误，不会注入 stub 或替代内容。对已确认规则
执行本身是确定性的，但 `--tick` 的语义叙事仍必须调用模型；存读档不调用模型。
逐拍 tick 状态持久化进状态文件 `_meta`，连续 `--tick` 跨进程真正推进时间线。

只有明确启用了可预跑适配器的世界才执行该适配器的预览；未启用适配器的
通用世界保持中性，不会根据世界描述偷偷套用专用规则。

---

## 测试

```bash
PYTHONPATH=backend python -m pytest tests/ -q
```

- 测试数量随功能演进，不在文档中硬编码；以当前 pytest 收集结果为准
- 回归覆盖固定输入序列、危险规则拒绝与不变量检查；具体数量以当前测试收集结果为准
- 覆盖：辛积分保能量 · DAG 无环 · 事务可复现 · 规则引擎 · 世界隔离 · 世界创建/导入 · schema 迁移 · 推理优化 · GUI 意图闭环

> 内核部分完全确定性；真实供应商输出仍需通过启动器诊断和集成测试抽样评估。

---

## 设计文档索引

| 文档 | 内容 |
|---|---|
| [`docs/ARCHITECTURE_SPEC(2).md`](docs/ARCHITECTURE_SPEC(2).md) | 主架构规范：红线 · 分层架构 · 通用世界内核 · 权限模型 · 安全边界 · 构建顺序 |
| [`docs/runtime_world_kernel_design.md`](docs/runtime_world_kernel_design.md) | 运行时世界内核设计 |
| [`docs/gui_generation_design.md`](docs/gui_generation_design.md) | GUI 生成设计 |
| [`docs/MODEL_ROUTING.md`](docs/MODEL_ROUTING.md) | 多模型路由：per-role 默认模型 + 环境变量覆盖 + 标准 OpenAI 协议供应商配置 |

---

## 内置验证入口

| 入口 | 内容 |
|---|---|
| `launch.bat` / `launch.sh` | GUI 主流程：配置模型 → 创建世界 → 交互 → 存档 |

---

## 为什么这不是又一个 AI 故事机

确认后的世界规则不能被自由文本直接改写；要探索另一组构成性规则，应 fork
一个新世界并重新确认。框架对不同题材保持同一套协议和安全边界。
