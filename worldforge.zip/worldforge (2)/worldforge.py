"""worldforge — CLI for the LLM-authored WorldForge runtime.

A pure-Python (argparse) entry point for world creation, compiled-rule ticks,
explicit kernel-adapter diagnostics, and saves. Ordinary world creation
and semantic runtime steps require a configured LLM. The former fixed-world
``--demo`` entry is retained only to report that it has been removed.

Usage:
    python worldforge.py "示例世界"                   # 由已配置 LLM 创建世界
    python worldforge.py "示例世界" --tick            # 推进编译规则
    python worldforge.py --list                       # 列出所有世界
    python worldforge.py "示例世界" --save out.zip     # 导出存档
    python worldforge.py --load save.zip              # 导入存档
    python worldforge.py --saves                      # 列出存档

Per-world tick state (timeline cursor / civilization scalars / beat counter)
is persisted into the state file's ``_meta`` so consecutive ``--tick`` calls
genuinely advance the timeline across separate process invocations.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import replace
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

# Allow running from project root without setting PYTHONPATH.
ROOT = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.join(ROOT, "backend")
if BACKEND not in sys.path:
    sys.path.insert(0, BACKEND)

from theater.agents import (  # noqa: E402
    ModelClient,
    ModelClientError,
    OpenAICompatibleClient,
)
from theater.dispatcher import TheaterOrchestrator  # noqa: E402
from theater.save_manager import LLM_LOG_META_KEY, SaveManager  # noqa: E402
from theater.settings import Settings  # noqa: E402
from theater.storage import JsonStateStore  # noqa: E402
from theater.world_creation import WorldCreator, WorldProposal  # noqa: E402
from theater.world_kernel_host import RuleCompiler  # noqa: E402


STATE_ROOT = Path(ROOT) / "data" / "runtime"

ADAPTER_DEFAULT_SEED = 0


def _slugify(name: str) -> str:
    """Stable, filesystem-safe world_id from a human name.

    Keeps CJK characters (state_<name>.json works fine on Windows) but strips
    path separators and whitespace so the id round-trips through --list.
    """
    slug = re.sub(r"[\\/:*?\"<>|\s]+", "_", name.strip())
    return slug or "world"


def _world_seed(store: JsonStateStore) -> int:
    """The world's pinned adapter seed, with a neutral deterministic fallback."""
    with store._lock:
        raw = store._load_raw()
    params = raw.get("_meta", {}).get("world_params", {})
    try:
        return int(params.get("seed", ADAPTER_DEFAULT_SEED))
    except (TypeError, ValueError):
        return ADAPTER_DEFAULT_SEED


def _world_params(store: JsonStateStore) -> Dict[str, Any]:
    """Return the immutable parameters pinned when the world was created."""
    with store._lock:
        raw = store._load_raw()
    params = raw.get("_meta", {}).get("world_params", {})
    return dict(params) if isinstance(params, dict) else {}


def _uses_three_body_adapter(store: JsonStateStore) -> bool:
    enabled = _world_params(store).get("enabled_kernels")
    return (
        isinstance(enabled, (list, tuple, set, frozenset))
        and "three_body" in enabled
    )


def _bake_kernel(seed: int) -> ThreeBodyKernel:
    """Bake a three-body kernel at production settings for the given seed."""
    # The specialised reference adapter is intentionally loaded only by an
    # explicit adapter path (``--demo`` or a world that enables it).
    from theater.kernels.three_body import ThreeBodyKernel

    kernel = ThreeBodyKernel(seed=seed, dt=0.02,
                             lyapunov_renorms=8, lyapunov_renorm_steps=80)
    kernel.bake(years=600.0)
    return kernel


def _build_orchestrator(world_id: str) -> TheaterOrchestrator:
    """Generic orchestrator backed by the user's configured runtime LLM."""
    settings = replace(Settings.from_env(), data_dir=STATE_ROOT)
    orch = TheaterOrchestrator(
        state_store=JsonStateStore(STATE_ROOT, world_id=world_id),
        model_client=OpenAICompatibleClient(settings),
        settings=settings,
    )
    return orch


def _build_progressing_orchestrator(world_id: str, args) -> TheaterOrchestrator:
    """North-star orchestrator: AgentMind + commitments + auto-advance all on,
    unless the user opted out via --no-agent-mind / --no-commitments /
    --no-auto-advance. Both authoring and runtime narration use the configured
    LLM; no deterministic runtime substitute is installed."""
    settings = replace(
        Settings.from_env(),
        data_dir=STATE_ROOT,
        enable_agent_mind=not getattr(args, "no_agent_mind", False),
        enable_commitments=not getattr(args, "no_commitments", False),
        world_tick_interval=0 if getattr(args, "no_auto_advance", False) else 300,
    )
    orch = TheaterOrchestrator(
        state_store=JsonStateStore(STATE_ROOT, world_id=world_id),
        model_client=OpenAICompatibleClient(settings),
        settings=settings,
    )
    return orch


# ---------------------------------------------------------------------------
# Shared LLM wiring for onboarding and subsequent runtime beats
# ---------------------------------------------------------------------------


def _build_llm_for_onboarding(args) -> "Optional[Any]":
    """Return the configured LLM client required for ordinary CLI creation."""
    if getattr(args, "no_llm", False):
        raise RuntimeError("LLM is required; --no-llm is not supported for world creation.")
    from theater.onboarding_llm import build_llm
    client, message = build_llm()
    if client is None:
        raise RuntimeError(
            "LLM is required to create a world. Configure it in the WorldForge "
            f"launcher, then retry. Details: {message}"
        )
    return client


class _LLMRuntimeModelClient(ModelClient):
    """Adapt the onboarding LLM client to the full runtime model contract."""

    _DIRECTOR_SYSTEM = (
        "你是通用互动世界框架的制片人导演。根据当前请求决定本拍如何推进。"
        "只回复一个 JSON 对象，不要 markdown 或解释。必须包含："
        "intent（world_update/action/possession/complex_story 之一）、"
        "brief、dialogue、actor_id、world_title、world_content、"
        "character_summary、warnings（字符串数组）。"
    )

    _CARD_SYSTEM = (
        "你是互动剧场的角色设计师。玩家给你一段自然语言的人物描述，"
        "你把它扩写成一张结构化角色卡。只回复一个紧凑的 JSON 对象，"
        "不要散文、不要 markdown 代码块、不要解释。JSON 必须且仅使用这些键："
        "name(角色名), summary(一句话身份定位), personality(性格，2-3句), "
        "appearance(供叙事和身份识别使用的外貌描述，2-3句), "
        "sample_line(一句符合人设的代表台词), warnings(数组)。全部用中文。"
    )

    def __init__(self, llm_client: Any) -> None:
        self._llm = llm_client

    def complete_json(self, role: str, prompt: str, model: str) -> Dict[str, Any]:
        from theater.llm_client import LLMError, _parse_json_obj
        try:
            raw = self._llm.complete(
                f"role={role}\n{prompt}",
                system=self._DIRECTOR_SYSTEM,
                temperature=0.4,
                max_tokens=1536,
            )
            result = _parse_json_obj(raw)
            OpenAICompatibleClient._validate_director_payload(result)
            result["provider_model"] = model
            return result
        except (LLMError, ModelClientError, ValueError, TypeError) as exc:
            raise ModelClientError(
                f"LLM runtime generation failed: {exc}"
            ) from exc

    def complete_character_card(self, description: str, model: str) -> Dict[str, Any]:
        from theater.llm_client import LLMError, _parse_json_obj
        try:
            raw = self._llm.complete(
                f"描述：{description or ''}",
                system=self._CARD_SYSTEM,
                temperature=0.7,
                max_tokens=2048,
            )
            card = _parse_json_obj(raw)
            card.setdefault("warnings", [])
            OpenAICompatibleClient._validate_character_card(card)
            card["provider_model"] = model
            return card
        except (LLMError, ModelClientError, ValueError, TypeError) as exc:
            raise ModelClientError(
                f"LLM character-card generation failed: {exc}"
            ) from exc


# ---------------------------------------------------------------------------
# per-world tick-state persistence (in the state file's _meta)
# ---------------------------------------------------------------------------

def _load_tick_state(store: JsonStateStore) -> Dict[str, Any]:
    with store._lock:
        raw = store._load_raw()
    return dict(raw.get("_meta", {}).get("three_body_runtime", {}))


def _save_tick_state(store: JsonStateStore, cursor: float, civ: dict, beat: int) -> None:
    with store._lock:
        raw = store._load_raw()
        meta = raw.setdefault("_meta", {})
        meta["three_body_runtime"] = {
            "cursor": float(cursor),
            "civ": civ,
            "beat": int(beat),
        }
        store._save(raw)


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------

def cmd_create_or_preview(name: str) -> int:
    """Reject legacy non-LLM creation in favour of configured onboarding."""
    _ = name
    print(
        "error: ordinary CLI creation requires a configured LLM. Configure the "
        "provider and model in the WorldForge launcher, then use `worldforge "
        "\"你的世界描述\"` or `--onboard`.",
        file=sys.stderr,
    )
    return 2


def cmd_tick(name: str, tech: Optional[float]) -> int:
    """Advance the world by one beat.

    Routes by explicit world configuration: a persisted DSL spec runs
    :meth:`world_tick`; the Three-Body adapter runs only when
    ``enabled_kernels`` explicitly contains ``three_body``. A generic world
    must already have an LLM-authored persisted spec.
    """
    world_id = _slugify(name)
    store_path = STATE_ROOT / f"state_{world_id}.json"
    if not store_path.exists():
        print(
            f"error: 世界 '{name}' 不存在。普通世界必须由已配置的 LLM 创建；"
            "请先使用启动器配置 LLM 后运行 onboarding。",
            file=sys.stderr,
        )
        return 2

    orch = _build_orchestrator(world_id)
    store = orch._world_store(world_id)

    # A compiled DSL spec always wins: authored rules actually execute.
    spec = orch.get_world_kernel_spec(world_id)
    if spec is not None and _is_dsl_world(spec):
        try:
            return _cmd_world_tick(name, world_id, orch)
        except ModelClientError as exc:
            print(f"error: 本拍需要可用的 LLM：{exc}", file=sys.stderr)
            return 2

    # Specialised adapters are opt-in. Descriptions and world names never
    # select the Three-Body kernel implicitly.
    if not _uses_three_body_adapter(store):
        print(
            f"error: 世界 '{name}' 没有已生成的 LLM 规则。请先通过启动器完成 onboarding。",
            file=sys.stderr,
        )
        return 2

    # Restore persisted tick state (cursor / civ scalars / beat) if present.
    saved = _load_tick_state(store)
    if saved:
        orch._three_body_cursor = float(saved.get("cursor", 0.0))
        orch._three_body_civ = {"civilization": dict(saved.get("civ", {}))} \
            if saved.get("civ") else None
        orch._world_beat = int(saved.get("beat", 0))

    # Pre-set the kernel with the world's pinned seed (documented extension
    # point in _ensure_three_body_kernel: pre-setting skips the hardcoded-seed
    # bake). This keeps the running timeline consistent with the world's seed so
    # the evacuation proof surfaces in the tick.
    orch._three_body_kernel = _bake_kernel(_world_seed(store))
    decision = tech if tech is not None else None
    print(f"=== 推进一拍：世界 '{name}'  (decision={'carry-forward' if decision is None else tech}) ===")
    print("烘焙确定性时间线中（首拍较慢）……")
    try:
        result = orch.three_body_tick(decision=decision, world_id=world_id)
    except (ModelClientError, RuntimeError) as exc:
        print(f"error: 本拍叙事需要可用的 LLM：{exc}", file=sys.stderr)
        return 2

    civ = orch._three_body_civ["civilization"]
    _save_tick_state(store, orch._three_body_cursor, civ, orch._world_beat)

    print(f"节拍 beat = {orch._world_beat}")
    if result is not None:
        trace = result.model_trace
        print(f"内核判决：{trace['kernel_verdict']}")
        print(f"文明状态：科技={civ['tech_level']}·第{civ['count']}号文明·"
              f"存活={civ['alive']}·已逃离={civ['evacuated']}")
        print(f"逃离已被证明：{trace['evacuation_proven']}")
        print("内核事件日志：")
        for line in trace["kernel_event_log"]:
            print(f"  - {line}")
        if result.dialogue:
            print(f"台词：{result.dialogue}")
    else:
        # three_body_tick returns None when no new worldbook entry was added.
        print(f"文明状态：科技={civ['tech_level']}·第{civ['count']}号文明·"
              f"存活={civ['alive']}·已逃离={civ['evacuated']}")
        print("（本拍未新增世界书条目。）")
    return 0


def _is_dsl_world(spec) -> bool:
    """True if *spec* drives a DSL (non-three-body) world tick.

    Three-body / physical worlds are §8.2 constitutive and run through
    ``three_body_tick`` even if a spec happens to be registered.
    """
    return getattr(spec, "constraint_type", "content") != "constitutive"


def _cmd_world_tick(name: str, world_id: str, orch: TheaterOrchestrator) -> int:
    """Run one DSL-kernel-driven beat (economy / social / card / simulation)."""
    orch.set_world(world_id)
    print(f"=== 推进一拍（DSL 内核）：世界 '{name}' (world_id={world_id}) ===")
    result = orch.world_tick(session_id="world_clock")
    state = orch.get_world_kernel_state(world_id)
    print(f"节拍 beat = {orch._world_beat}")
    print(f"内核状态：{json.dumps(state, ensure_ascii=False)}")
    event_log = []
    if result is not None:
        event_log = result.model_trace.get("kernel_event_log") or []
    if event_log:
        print("内核事件日志：")
        for line in event_log:
            print(f"  - {line}")
    else:
        print("（本拍内核未触发事件。）")
    # Surface the kernel worldbook fact so callers can see rules fired.
    entries = orch.state_store.snapshot().worldbook
    kernel_entries = [e for e in entries if e.source == "world_kernel_tick"]
    if kernel_entries:
        print(f"内核世界书条目：{kernel_entries[-1].title} — {kernel_entries[-1].content}")
    return 0


def cmd_list() -> int:
    print("=== 所有世界 ===")
    STATE_ROOT.mkdir(parents=True, exist_ok=True)
    ids = sorted(p.stem.replace("state_", "", 1)
                 for p in STATE_ROOT.glob("state_*.json"))
    if (STATE_ROOT / "state.json").exists():
        ids.append("main")
    if not ids:
        print("（还没有任何世界。运行 `python worldforge.py \"示例世界\"` 创建一个。）")
        return 0
    for wid in sorted(set(ids)):
        print(f"  - {wid}")
    return 0


def cmd_bake(name: str) -> int:
    """Bake an explicitly enabled Three-Body adapter for dashboard data."""
    world_id = _slugify(name)
    store = JsonStateStore(STATE_ROOT, world_id=world_id)
    if not _uses_three_body_adapter(store):
        print(
            "error: --bake is only available for a world with the explicit "
            "Three-Body adapter enabled (or use --demo).",
            file=sys.stderr,
        )
        return 2
    seed = _world_seed(store)
    print(f"=== 烘焙世界 '{name}'  (world_id={world_id}, seed={seed}) ===")
    print("烘焙中（600 模拟年）……")
    kernel = _bake_kernel(seed)

    chaotic = kernel.chaotic_era_intervals()
    stable = kernel.stable_era_intervals()
    evac = kernel.evacuation_check(max_tech=10.0, Delta=0.1)
    light = kernel.light_series  # (n, 3) array attribute (set by bake())
    total_flux = light.sum(axis=1) if getattr(light, "size", 0) else np.zeros(0)

    dashboard = {
        "world_id": world_id,
        "seed": seed,
        "lambda": kernel.lambda_,
        "energy_drift": kernel.energy_drift,
        "n_stable_eras": len(stable),
        "n_chaotic_eras": len(chaotic),
        "chaotic_eras": [{"start": e.start, "end": e.end} for e in chaotic],
        "evacuation_proven": evac,
        "light_series": {
            "n_samples": int(total_flux.size),
            "min": float(total_flux.min()) if total_flux.size else 0.0,
            "max": float(total_flux.max()) if total_flux.size else 0.0,
            "mean": float(total_flux.mean()) if total_flux.size else 0.0,
        },
    }

    dash_path = STATE_ROOT / f"dashboard_{world_id}.json"
    dash_path.parent.mkdir(parents=True, exist_ok=True)
    dash_path.write_text(json.dumps(dashboard, ensure_ascii=False, indent=2),
                         encoding="utf-8")

    print(f"λ(Lyapunov) = {kernel.lambda_:.4f}·能量漂移 = {kernel.energy_drift:.3g}")
    print(f"稳定纪元 {len(stable)} 个·乱纪元 {len(chaotic)} 个")
    print(f"逃离已被数学证明：{evac}")
    print(f"仪表盘数据写入：{dash_path}")
    return 0


def cmd_save(name: str, output: Optional[Path]) -> int:
    """Export a world to a zip archive (§13.2: state + LLM log)."""
    world_id = _slugify(name)
    # §10.4 / 隔离：使用对应世界的 JsonStateStore 装载状态。
    orch = _build_orchestrator(world_id)
    orch.set_world(world_id)
    state = orch.state_store._load()
    llm_log = list(getattr(orch, "_three_body_llm_log", []) or [])
    out_path = Path(output) if output else (STATE_ROOT.parent / "saves" / f"{world_id}.zip")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    mgr = SaveManager()
    result = mgr.save(
        world_id, out_path,
        world_state=state,
        llm_output_log=llm_log,
    )
    print(f"=== 导出世界 '{name}' (world_id={world_id}) ===")
    print(f"zip 路径：{result.path}")
    print(f"schema version：{result.schema_version}")
    print(f"LLM 日志条目：{len(llm_log)}")
    return 0


def cmd_load(zip_path: Path) -> int:
    """Import a world archive from a zip file."""
    mgr = SaveManager()
    result = mgr.load(Path(zip_path), STATE_ROOT)
    print(f"=== 导入存档：{zip_path} ===")
    print(f"world_id：{result.world_id}")
    print(f"schema version：{result.schema_version}")
    print(f"解压到：{result.extracted_to}")
    if result.sandbox_warning:
        print(f"⚠️  {result.sandbox_warning}")
    if result.fallback_text_path:
        print(f"⚠️  迁移失败，已降级导出可读文本：{result.fallback_text_path}")
    return 0


def _resolve_world_id(name: str, world_id_flag: Optional[str]) -> str:
    """world_id from --world-id if given, else slugify(name)."""
    if world_id_flag:
        return world_id_flag
    return _slugify(name)


def cmd_import_book(name: str, path: Path, world_id_flag: Optional[str],
                    merge: bool) -> int:
    """Import a lorebook JSON into a world's worldbook (auto-create if missing).

    Pipeline: WorldbookImporter.compile_worldbook → orchestrator.add_world_entry.
    merge=false (default) skips entries whose title already exists.
    """
    from theater.worldbook_import import WorldbookImporter
    from theater.models import WorldBookPatch

    world_id = _resolve_world_id(name, world_id_flag)
    if not path.exists():
        print(f"error: lorebook 文件不存在：{path}", file=sys.stderr)
        return 2
    data = json.loads(path.read_text(encoding="utf-8"))

    compiled = WorldbookImporter.compile_worldbook(data, target_world_id=world_id)
    warnings = compiled.get("warnings", [])

    orch = _build_orchestrator(world_id)
    orch.set_world(world_id)
    store = orch.state_store
    existing_titles = {e.title for e in store.snapshot().worldbook}

    imported = 0
    skipped = 0
    for entry in compiled["worldbook"]:
        if not merge and entry["title"] in existing_titles:
            skipped += 1
            continue
        patch = WorldBookPatch(
            title=entry["title"],
            content=entry["content"],
            source=entry["source"],
        )
        orch.add_world_entry(patch, "science_director", origin="worldbook_import")
        imported += 1

    print(f"=== 导入世界书到 '{name}'  (world_id={world_id}) ===")
    print(f"导入 {imported} 条·跳过 {skipped} 条·解析总数 {compiled['count']}")
    if warnings:
        print("警告：")
        for w in warnings:
            print(f"  - {w}")
    return 0


def cmd_import_card(name: str, path: Path, world_id_flag: Optional[str],
                    character_id_override: Optional[str]) -> int:
    """Import a character card JSON into a world (auto-create if missing).

    Pipeline (§11.1): parse_card → scan_injection → compile_character →
    validate (QA gate) → upsert_character.  QA failure prints reasons and
    returns non-zero.
    """
    from theater.models import CharacterPatch
    from theater.world_import import WorldImporter

    world_id = _resolve_world_id(name, world_id_flag)
    if not path.exists():
        print(f"error: 角色卡文件不存在：{path}", file=sys.stderr)
        return 2
    card = json.loads(path.read_text(encoding="utf-8"))

    parsed = WorldImporter.parse_card(card)
    if character_id_override:
        parsed.character_id = character_id_override

    injection_warnings: list = []
    for raw_text in parsed.raw_fields.values():
        injection_warnings.extend(WorldImporter.scan_injection(raw_text))
    gaps = WorldImporter.detect_gaps(parsed)

    entity = WorldImporter.compile_character(
        parsed,
        gaps_filled={
            "dag_position": "imported",
            "allowed_actions": ["move", "speak"],
            "disposition": {"loyalty": 0.5},
            "damping": {"fear": 0.5},
        },
        injected=injection_warnings,
    )
    errors = WorldImporter.validate(entity)
    if errors:
        print(f"error: 角色卡未通过 QA 门禁：", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        return 1

    tone_samples = entity.prose.get("tone_samples") or []
    patch = CharacterPatch(
        character_id=entity.character_id,
        name=parsed.name or entity.character_id,
        summary=str(entity.prose.get("description", ""))[:280],
        source="imported_card",
        personality=str(entity.prose.get("personality", "")),
        sample_line=str(tone_samples[0]) if tone_samples else "",
    )
    orch = _build_orchestrator(world_id)
    orch.set_world(world_id)
    orch.upsert_character(patch, "science_director", origin="card_import")

    print(f"=== 导入角色卡到 '{name}'  (world_id={world_id}) ===")
    print(f"角色ID：{entity.character_id}·名称：{parsed.name}")
    if gaps:
        print(f"提示：以下字段在导入时缺失（已用默认值补全）：")
        for g in gaps:
            print(f"  - {g}")
    if injection_warnings:
        print("注入警告（未阻断）：")
        for w in injection_warnings:
            print(f"  - {w}")
    return 0


def cmd_saves() -> int:
    """List all archived worlds (one line each)."""
    mgr = SaveManager()
    saves = mgr.list_saves(STATE_ROOT)
    print("=== 存档列表 ===")
    if not saves:
        print("（还没有任何存档。`worldforge \"你的世界\" --save` 创建一个。）")
        return 0
    for s in saves:
        flag = "⚠️ SANDBOX" if s.get("sandbox") else ""
        print(
            f"  - {s['world_id']:20s} schema=v{s['schema_version']} "
            f"chars={s['characters_count']} wb={s['worldbook_count']} "
            f"obj={s['objects_count']} {flag}"
        )
    return 0


def cmd_create_character(name: str, args) -> int:
    """Create a character in world ``name`` via the unified entry point.

    Mode is inferred from the flags:
      --description only            → auto (LLM fills everything)
      --name (and all other fields)  → manual confirmation of supplied content
      --description + --name/fields → mixed (user fields kept, LLM fills the rest)
    """
    world_id = _slugify(name)
    store_path = STATE_ROOT / f"state_{world_id}.json"
    if not store_path.exists():
        print(f"error: 世界 '{name}' 不存在，请先创建。", file=sys.stderr)
        return 2

    orch = _build_orchestrator(world_id)
    orch.set_world(world_id)

    description = args.char_description or ""
    fields: Dict[str, Any] = {}
    for key in ("name", "summary", "personality", "appearance", "sample_line"):
        val = getattr(args, f"char_{key}", None)
        if val:
            fields[key] = val

    if description and fields:
        mode = "mixed"
    elif description:
        mode = "auto"
    else:
        mode = "manual"

    if mode == "manual" and not fields.get("name"):
        print("error: 手动造角色需要至少 --name", file=sys.stderr)
        return 2

    result = orch.create_character(
        mode=mode, description=description, fields=fields,
        character_id=args.character_id,
    )

    print(f"=== 造角色：世界 '{name}' (mode={mode}) ===")
    if not result.get("ok"):
        print(f"失败：{result.get('error')}")
        if result.get("reasons"):
            print("原因：" + "; ".join(result["reasons"]))
        return 1

    cid = result["character_id"]
    char = result.get("character") or {}
    print(f"character_id = {cid}")
    print(f"name         = {char.get('name')}")
    print(f"summary      = {char.get('summary')}")
    if char.get("personality"):
        print(f"personality  = {char['personality']}")
    if char.get("appearance"):
        print(f"appearance   = {char['appearance']}")
    if result.get("llm_filled_fields"):
        print("LLM 补全字段：" + ", ".join(result["llm_filled_fields"]))
    if result.get("warnings"):
        print("警告：" + "; ".join(result["warnings"]))
    return 0


def cmd_demo() -> int:
    """Reject the old fixed-world demo; every world starts with LLM authoring."""
    print(
        "error: 固定世界演示已移除。请运行 launch.bat/launch.sh，在 GUI 中"
        "配置 LLM，并从空白构想创建新世界。",
        file=sys.stderr,
    )
    return 2


# ---------------------------------------------------------------------------
# onboarding phase 3 — LLM 驱动 规则 / GUI 生成
# ---------------------------------------------------------------------------


def cmd_generate_rules(name: str) -> int:
    """用配置的 OpenAI 兼容 LLM 生成世界运行规则 DSL。

    需要 AI_THEATER_API_KEY / AI_THEATER_BASE_URL 已配置。未配置时直接
    报错退出，不静默降级。
    """
    from theater.onboarding_llm import build_llm, generate_world_rules

    world_id = _slugify(name)
    description = name  # 世界名本身作为描述； richer prompt 由 RuleGenerator 内置
    print(f"=== 用 LLM 生成规则：'{name}' (world_id={world_id}) ===")
    client, msg = build_llm()
    if client is None:
        print(f"error: 未配置 LLM：{msg}", file=sys.stderr)
        print("配置方式：export AI_THEATER_BASE_URL=https://api.openai.com/v1 "
              "AI_THEATER_API_KEY=sk-... AI_THEATER_MODEL_FAST=gpt-4o-mini",
              file=sys.stderr)
        return 2

    llm_fn = client.as_text_fn(temperature=0.2, max_tokens=2048)
    spec, meta = generate_world_rules(description, llm_fn=llm_fn)
    print(f"来源    : {meta['source']} (model={meta['model_label']})")
    print(f"world_type: {spec.world_type}  · 规则数 {len(spec.rules)}")
    if meta["issues"]:
        print(f"校验问题: {meta['issues']}")
    for r in spec.rules:
        print(f"  - {r.rule_id}  [{r.kind}, trigger={r.trigger or 'null'}, "
              f"priority={r.priority}]  {r.description}")
    # Compile as a final proof the spec is runnable.
    try:
        compiled = RuleCompiler(seed=42).compile(spec)
        print(f"编译通过  · spec_hash={compiled.spec_hash}")
    except Exception as exc:
        print(f"编译失败：{exc}", file=sys.stderr)
        return 1
    print("===TASK DONE: LLM 规则生成===")
    return 0


def cmd_gui(name: str, use_llm: bool) -> int:
    """Generate a GUI with the configured LLM; no generic substitute is used."""
    from theater.gui_generator import GUIGenerator, compile_to_css
    from theater.onboarding_llm import build_llm

    world_id = _slugify(name)
    print(f"=== 生成 GUI：'{name}' (world_id={world_id}) ===")
    if not use_llm:
        print("error: GUI generation requires --use-llm and a configured LLM.", file=sys.stderr)
        return 2
    client, msg = build_llm()
    if client is None:
        print(f"error: GUI generation requires a configured LLM: {msg}", file=sys.stderr)
        return 2
    llm_fn = client.as_dict_fn(temperature=0.4, max_tokens=4096)

    generator = GUIGenerator()
    spec = generator.generate(name, llm_fn=llm_fn)
    css = compile_to_css(spec)
    print("来源    : llm")
    print(f"layout  : {spec.layout_type}  · chrome={spec.chrome}")
    print(f"widgets : {len(spec.widgets)}")
    for w in spec.widgets:
        print(f"  - {w.name}  [{w.type}, area={w.area}]")
    out = STATE_ROOT / f"gui_{world_id}.css"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(css, encoding="utf-8")
    print(f"CSS 写入：{out}")
    return 0


def cmd_generate_cognitive_model(name: str, role: str, use_llm: bool) -> int:
    """为世界生成认知模型（Q7：LLM 生成主体误判结构）。

    世界描述用 *name*；角色由 ``--cognitive-model-role`` 给出。该阶段需要
    ``--use-llm``；框架不会根据世界描述关键词偷偷选择特定认知模型。
    生成产物通过五项硬验收后才放行。
    """
    from theater.cognitive_model_generator import generate_cognitive_model

    world_id = _slugify(name)
    print(f"=== 生成认知模型：'{name}' (world_id={world_id}, role={role}) ===")
    if not use_llm:
        print(
            "error: 认知模型需要 --use-llm；不存在按世界观关键词选择的通用替代品。",
            file=sys.stderr,
        )
        return 2
    llm_fn = None
    from theater.onboarding_llm import build_llm
    client, msg = build_llm()
    if client is None:
        print(f"error: 未配置 LLM：{msg}", file=sys.stderr)
        return 2
    llm_fn = client.as_text_fn(temperature=0.2, max_tokens=2048)

    spec, meta = generate_cognitive_model(name, agent_role=role, llm_fn=llm_fn)
    print(f"来源      : {meta['source']}")
    print(f"world_type: {meta['world_type']}  · agent_role={meta['agent_role']}")
    print(f"failure_modes: {meta['failure_modes']} 个  · repairs={meta['repairs']}")
    for fm in spec.failure_modes:
        print(f"  - {fm.get('name')}: misjudges '{fm.get('misjudged_variable')}' "
              f"[{fm.get('structure', '')[:60]}]")
    if meta.get("validation"):
        print(f"验收      : passed={meta['validation']['passed']}")
    # Compile as a final proof the spec is runnable.
    try:
        cm = spec.to_cognitive_model()
        from theater.cognitive_model import CognitiveModel
        ok = isinstance(cm, CognitiveModel)
        print(f"编译为 CognitiveModel 协议实例: {ok}")
    except Exception as exc:
        print(f"编译失败：{exc}", file=sys.stderr)
        return 1
    print("===TASK DONE: Q7认知模型生成===")
    return 0


def _run_onboarding(description: str, args, orch: TheaterOrchestrator):
    """Shared onboarding runner used by both ``--onboard`` and the default
    no-flag path. Returns the :class:`OnboardingFlow` result dict.

    The configured LLM is wired into onboarding generation and into the
    orchestrator's full model contract. The same provider therefore authors
    generation artifacts, character cards and subsequent runtime beats.
    """
    from theater.onboarding import OnboardingFlow

    llm = _build_llm_for_onboarding(args)
    orch.model_client = _LLMRuntimeModelClient(llm)

    flow = OnboardingFlow(
        orchestrator=orch, state_root=STATE_ROOT, llm_client=llm,
    )

    # North-star default: no --character flags and no --no-characters →
    # characters stays None so the flow auto-creates one protagonist.
    characters: Optional[list] = None
    if getattr(args, "no_characters", False):
        characters = []
    elif getattr(args, "characters", None):
        characters = list(args.characters)

    use_llm = True
    gameplay = None
    if getattr(args, "gameplay", None):
        gameplay = {
            "description": args.gameplay,
            "use_llm": use_llm,
            "mode": "auto",
        }
    result = flow.run(
        description,
        characters=characters,
        use_llm=use_llm,
        mode="auto",
        gameplay=gameplay,
    )
    result["llm_active"] = True
    return result


def _print_onboarding_summary(description: str, result: dict) -> None:
    print(f"=== 一键 Onboarding：'{description}' ===")
    print(f"world_id  = {result.get('world_id')}")
    spark_on = bool(result.get("llm_active"))
    print(f"LLM       = {'开' if spark_on else '错误：未配置'}")
    stages = result.get("stages", {})
    world = stages.get("world", {})
    if world.get("preview"):
        print(f"预览      : {world['preview'].get('summary_text')}")
    chars = stages.get("characters", [])
    if chars:
        print(f"角色      : {len(chars)} 个")
        for c in chars:
            mark = "✓" if c.get("ok") else "✗"
            # auto/mixed mode + LLM on → LLM-authored; manual remains manual.
            mode = c.get("mode") or "auto"
            if mode == "manual":
                src = "manual"
            else:
                src = "llm"
            label = c.get("name") or c.get("character_id") or c.get("error")
            print(f"  {mark} {label}  [source={src}]")
    else:
        print("角色      : 跳过")
    rules = stages.get("rules", {})
    gui = stages.get("gui", {})
    print(f"规则      : source={rules.get('source')} · {rules.get('rules', 0)} 条 · "
          f"compiled={rules.get('compiled')}")
    print(f"GUI       : source={gui.get('source')} · layout={gui.get('layout_type')} · "
          f"{gui.get('widgets', 0)} widgets")
    gp = stages.get("gameplay", {})
    if gp.get("skipped"):
        print("玩法      : 跳过")
    else:
        gp_kernel = gp.get("kernel") or gp.get("spec_name") or "?"
        print(f"玩法      : source={gp.get('source')} · kernel={gp_kernel} · "
              f"repairs={gp.get('repairs', 0)} · persisted={gp.get('persisted')}")
    cm = stages.get("cognitive_model", {})
    if cm.get("skipped"):
        print("认知模型  : 跳过")
    else:
        print(f"认知模型  : source={cm.get('source')} · role={cm.get('agent_role')} · "
              f"failure_modes={cm.get('failure_modes')}")
    if result.get("warnings"):
        print("警告：")
        for w in result["warnings"]:
            print(f"  - {w}")


def cmd_onboard(description: str, args) -> int:
    """One-shot onboarding: world → characters → rules+GUI → narrative handoff.

    Stages 1–4 are sequenced by :class:`OnboardingFlow`; a configured LLM is
    required and no neutral substitute is installed.
    """
    try:
        _build_llm_for_onboarding(args)
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    orch = _build_orchestrator(_slugify(description) or "world")
    try:
        result = _run_onboarding(description, args, orch)
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if not result.get("ok"):
        print(
            f"error: LLM onboarding failed: {result.get('error') or result.get('stages')}",
            file=sys.stderr,
        )
        return 1
    _print_onboarding_summary(description, result)
    if result.get("stages", {}).get("narrative", {}).get("ready"):
        print(f"\n✓ 可开始叙事：worldforge \"{description}\" --tick")
    print("===TASK DONE: onboarding 编排===")
    return 0


def cmd_progressing_world(description: str, args) -> int:
    """North-star default: ``worldforge "一句话"`` (no flags) → LLM authors the
    world (rules / GUI / gameplay) + a protagonist + cognitive model, then the
    world starts auto-progressing (WorldClock) with AgentMind + decision
    commitments on. The user is a guest who can observe or intervene.

    One autonomous beat is run immediately so progression is visible; the
    WorldClock is then started so the world keeps living every
    ``world_tick_interval`` seconds while this process runs. ``--no-*`` flags
    opt out of individual runtime layers; LLM generation remains required.
    """
    from theater.runtime import WorldClock

    world_id = _slugify(description) or "world"
    try:
        _build_llm_for_onboarding(args)
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    orch = _build_progressing_orchestrator(world_id, args)
    try:
        result = _run_onboarding(description, args, orch)
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if not result.get("ok"):
        print(
            f"error: LLM onboarding failed: {result.get('error') or result.get('stages')}",
            file=sys.stderr,
        )
        return 1
    _print_onboarding_summary(description, result)

    settings = orch.settings
    print()
    print("=== 世界自主推进中 ===")
    print(f"world_id          = {result.get('world_id')}")
    print(f"world_tick_interval = {settings.world_tick_interval}s（空闲时自动推进一拍）")
    print(f"AgentMind         = {'开' if settings.enable_agent_mind else '关'}"
          + ("（--no-agent-mind 关闭）" if not settings.enable_agent_mind else ""))
    print(f"决策承诺          = {'开' if settings.enable_commitments else '关'}"
          + ("（--no-commitments 关闭）" if not settings.enable_commitments else ""))
    print("LLM               = 开（世界生成与每拍运行均使用配置的 LLM）")

    # Run one autonomous beat immediately so progression is observable.
    orch.set_world(result.get("world_id") or world_id)
    try:
        beat = orch.world_tick(session_id="world_clock")
        beat_no = orch._world_beat
        print(f"\n→ 已自主推进第 {beat_no} 拍：" + (
            "世界向前发展一个节拍。" if beat is not None else "（本拍未产生新条目。）"))
    except Exception as exc:  # noqa: BLE001 — surface provider/runtime errors
        print(f"\nerror: 自主推进首拍的 LLM 调用失败：{exc}", file=sys.stderr)
        return 1

    # Start the WorldClock so the world keeps living while the process runs.
    clock = WorldClock(orch, settings.world_tick_interval)
    started = clock.start()
    print()
    print("✓ 世界正在自主推进。你是客人，可旁观或介入。")
    print(f"  旁观：worldforge \"{description}\" --tick")
    print(f"  介入：python -m theater.server（world_tick_interval={settings.world_tick_interval}s）")
    if started:
        print(f"  WorldClock 已启动（每 {settings.world_tick_interval}s 自动一拍，本进程存活期间有效）。")
    print("===TASK DONE: 北极星一句话→Progressing World===")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="worldforge",
        description="WorldForge 通用世界框架 CLI（创建 / 推进 / 适配器诊断 / 存档）。",
    )
    p.add_argument("name", nargs="?", help="世界名称，例如 \"示例世界\"")
    p.add_argument("--tick", action="store_true", help="推进一拍（内核驱动）")
    p.add_argument("--tech", type=float, default=None,
                   help="本拍科技决策（tech_level），配合 --tick 使用")
    p.add_argument("--bake", action="store_true", help="烘焙时间线并输出仪表盘数据")
    p.add_argument("--create-preview", dest="create_preview", action="store_true",
                   help="旧的非 LLM 创建入口；已禁用，请使用默认 onboarding 路径")
    p.add_argument("--list", action="store_true", help="列出所有世界")
    p.add_argument("--save", nargs="?", const=None, default=None, metavar="OUT",
                   help="导出世界为 zip；省略路径则用 saves/<world_id>.zip")
    p.add_argument("--load", dest="load", default=None, metavar="ZIP",
                   help="从 zip 导入存档")
    p.add_argument("--saves", action="store_true", help="列出所有存档")
    p.add_argument("--import-book", dest="import_book", default=None, metavar="PATH",
                   help="导入成品世界书 JSON 到该世界（不存在则创建）")
    p.add_argument("--import-card", dest="import_card", default=None, metavar="PATH",
                   help="导入成品角色卡 JSON 到该世界（不存在则创建）")
    p.add_argument("--world-id", dest="world_id", default=None, metavar="ID",
                   help="精确指定目标世界 ID；默认从名字 slugify")
    p.add_argument("--merge", action="store_true",
                   help="导入世界书时 append 不去重（默认按 title 去重）")
    p.add_argument("--character-id", dest="character_id", default=None, metavar="ID",
                   help="导入角色卡或造角色时指定 character_id")
    p.add_argument("--create-character", dest="create_character", action="store_true",
                   help="在该世界造角色（手动/自动/混合，由 --description 与字段 flags 决定）")
    p.add_argument("--description", dest="char_description", default=None, metavar="TEXT",
                   help="造角色：角色描述（auto/mixed 模式必需）")
    p.add_argument("--name", dest="char_name", default=None, metavar="NAME",
                   help="造角色：角色名（manual 模式必需；mixed 模式保留不覆盖）")
    p.add_argument("--summary", dest="char_summary", default=None, metavar="TEXT",
                   help="造角色：角色摘要（手动/混合模式可选）")
    p.add_argument("--personality", dest="char_personality", default=None, metavar="TEXT",
                   help="造角色：性格（手动/混合模式可选）")
    p.add_argument("--appearance", dest="char_appearance", default=None, metavar="TEXT",
                   help="造角色：外貌（手动/混合模式可选）")
    p.add_argument("--sample-line", dest="char_sample_line", default=None, metavar="TEXT",
                   help="造角色：示例台词")
    p.add_argument("--demo", action="store_true",
                   help="已移除：固定世界演示不符合从零 LLM 创建流程")
    p.add_argument("--generate-rules", dest="generate_rules", action="store_true",
                   help="用 LLM 生成世界运行规则（需配置 AI_THEATER_API_KEY）")
    p.add_argument("--gui", dest="gui", action="store_true",
                   help="生成世界 GUI（必须配合 --use-llm 和已配置的 LLM）")
    p.add_argument("--use-llm", dest="use_llm", action="store_true",
                   help="与 --gui 配合：用 LLM 生成 GUI")
    p.add_argument("--onboard", dest="onboard", default=None, metavar="DESC",
                   help="一键 onboarding：创建世界→造角色→生成规则+GUI→可开始叙事")
    p.add_argument("--character", dest="characters", action="append", default=None,
                   metavar="DESC",
                   help="配合 --onboard：追加一个角色描述（默认 auto 模式），可重复")
    p.add_argument("--no-characters", dest="no_characters", action="store_true",
                   help="配合 --onboard：跳过角色创造阶段")
    p.add_argument("--no-llm", dest="no_llm", action="store_true",
                   help="已禁用：普通世界创建必须使用已配置的 LLM")
    p.add_argument("--no-agent-mind", dest="no_agent_mind", action="store_true",
                   help="默认一句话路径：关闭 AgentMind（角色不再自主观察→决策→行动）")
    p.add_argument("--no-commitments", dest="no_commitments", action="store_true",
                   help="默认一句话路径：关闭决策承诺（重大决策不再持久化为因果机制）")
    p.add_argument("--no-auto-advance", dest="no_auto_advance", action="store_true",
                   help="默认一句话路径：关闭 WorldClock 自主推进（world_tick_interval=0）")
    p.add_argument("--gameplay", dest="gameplay", default=None, metavar="DESC",
                   help="配合 --onboard：第4阶段生成玩法（描述如 \"竞价拍卖\"/\"猜数字\"），不传则跳过玩法阶段")
    p.add_argument("--generate-cognitive-model", dest="generate_cognitive_model",
                   action="store_true",
                   help="为该世界生成认知模型（Q7：LLM 生成主体误判结构）。"
                        "需配合 --cognitive-model-role 与 --use-llm；不会按世界观关键词选择模板")
    p.add_argument("--cognitive-model-role", dest="cognitive_model_role",
                   default="auto", metavar="ROLE",
                   help="配合 --generate-cognitive-model：主体角色（scientist/merchant/noble/...）")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)

    # 命令行 flags 优先级（--demo 最高，其次 --saves/--load/--save/--list/--bake/--tick）
    if args.demo:
        return cmd_demo()
    if args.onboard:
        return cmd_onboard(args.onboard, args)
    if args.saves:
        return cmd_saves()
    if args.load:
        return cmd_load(Path(args.load))
    if args.save is not None:
        if not args.name:
            print("error: --save 需要一个世界名称", file=sys.stderr)
            return 2
        out = Path(args.save) if args.save else None
        return cmd_save(args.name, out)
    if args.list:
        return cmd_list()
    if not args.name:
        build_parser().print_help()
        return 2
    if args.import_book:
        return cmd_import_book(args.name, Path(args.import_book),
                               args.world_id, args.merge)
    if args.import_card:
        return cmd_import_card(args.name, Path(args.import_card),
                               args.world_id, args.character_id)
    if args.create_character:
        return cmd_create_character(args.name, args)
    if args.generate_rules:
        return cmd_generate_rules(args.name)
    if args.gui:
        return cmd_gui(args.name, args.use_llm)
    if args.generate_cognitive_model:
        return cmd_generate_cognitive_model(args.name, args.cognitive_model_role, args.use_llm)
    if args.bake:
        return cmd_bake(args.name)
    if args.tick:
        return cmd_tick(args.name, args.tech)
    # North-star default: a bare ``worldforge "一句话"`` (no command flags) →
    # LLM-authored world + protagonist + auto-progressing (AgentMind +
    # commitments + WorldClock). Legacy create/preview is reached via
    # --create-preview; --tick/--bake etc. are handled above.
    if args.create_preview:
        return cmd_create_or_preview(args.name)
    return cmd_progressing_world(args.name, args)


if __name__ == "__main__":
    raise SystemExit(main())
