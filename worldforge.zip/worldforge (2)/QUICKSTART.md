# WorldForge · 快速上手

> 推荐入口：启动器配置模型 → 后端启动 → 浏览器完成全部工作流

## 1. 安装依赖

```bash
pip install -r requirements.txt
```

要求 Python 3.10+。运行时核心依赖为 `numpy`；Tkinter 由大多数
Windows/macOS Python 安装自带，Linux 发行版可能需要单独安装。

## 2. 打开启动器

```bat
:: Windows
launch.bat
```

```bash
# Linux / macOS
./launch.sh
# 兼容入口，同样打开 Tk 启动器
./start.sh
```

在弹出的 Tk 窗口中：

1. 填写 OpenAI-compatible `Base URL` 和 `API Key`。
2. 点击 `Pull Models`。
3. 选择 fast/deep 模型；只有一个模型时可只选一项，启动器会同时用于两条能力通道。
4. 点击 `Start WorldForge`。

启动器会等待后端健康检查通过，再打开
`http://127.0.0.1:8787/index.html`。配置保存在
`~/.worldforge_config.json`，API Key 输入框始终以掩码显示。

## 3. 在浏览器中操作

- 首页：一句话创建世界并进入。
- 高级向导：逐步确认世界、角色、规则、GUI 和玩法。
- 世界仪表盘：交互、COMMIT、快进、旁观/夺舍、生成规则与玩法。
- 世界管理：存档、读档、列表和重置。

WorldForge 是通用世界运行框架。运行时协议、模型路由、状态事务和 GUI
意图通道不依赖任何特定世界观；专用内核仅能通过已确认的显式配置启用。

## 服务端入口

只需要后端、不需要 Tk 启动器时，可显式执行 Python 模块：

```bash
PYTHONPATH=backend python -m theater.server
```

手动启动前需通过 `AI_THEATER_BASE_URL`、`AI_THEATER_API_KEY`、
`AI_THEATER_MODEL_FAST` 和 `AI_THEATER_MODEL_DEEP` 配置模型。
模型是创建世界和语义运行的必需依赖。模型未配置、请求失败或输出未通过解析和
校验时，对应流程会明确失败并停止；不会安装通用安全内核、操作 GUI 或其他替代物。
已确认规则的确定性执行可以继续进行。

## CLI

CLI 适合自动化、存档和确定性内核诊断；完整产品流程推荐使用 GUI。

```bash
python worldforge.py "示例世界" --tick
python worldforge.py --list
python worldforge.py --saves
python worldforge.py "示例世界" --save
```

## 测试

```bash
PYTHONPATH=backend python -m pytest tests/ -q
```

不要在文档中硬编码测试数量；以当前收集和执行结果为准。提交前要求
当前工作树的完整测试套件通过。
