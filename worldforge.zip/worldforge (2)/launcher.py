#!/usr/bin/env python3
"""WorldForge one-click launcher GUI.

A cross-platform (Windows/Linux) tkinter front-end that lets the user:
  * configure an OpenAI-compatible provider (Base URL + API Key)
  * pull the provider's model list (GET {base_url}/models)
  * search/filter the model list
  * pick a fast + deep model
  * launch the WorldForge server with those settings and open the browser

Pure standard library: tkinter + urllib + json + subprocess + pathlib.

Run:
    python launcher.py        # or launch.bat / launch.sh
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

# --- Project paths ---------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent
BACKEND_DIR = PROJECT_ROOT / "backend"
CONFIG_PATH = Path.home() / ".worldforge_config.json"

# Environment variable names consumed by backend/theater/settings.py
ENV_BASE_URL = "AI_THEATER_BASE_URL"
ENV_API_KEY = "AI_THEATER_API_KEY"
ENV_MODEL_FAST = "AI_THEATER_MODEL_FAST"
ENV_MODEL_DEEP = "AI_THEATER_MODEL_DEEP"

# Default LLM provider (OpenAI-compatible). The user configures their own
# endpoint + API key (OpenAI, Azure, local LM Studio / Ollama, etc.). The
# WorldForge backend itself runs on port 8787 (see backend/theater/settings.py).
DEFAULT_BASE_URL = "http://127.0.0.1:1234/v1"
DEFAULT_API_KEY = ""
PROVIDER_OPTIONS = (
    "OpenAI",
    "LM Studio",
    "Ollama",
    "Custom",
)
PROVIDER_BASE_URLS = {
    "OpenAI": "https://api.openai.com/v1",
    "LM Studio": DEFAULT_BASE_URL,
    "Ollama": "http://127.0.0.1:11434/v1",
}

# WorldForge server (NOT the LLM provider) — the URL the browser opens.
WORLDFORGE_HOST = "127.0.0.1"
WORLDFORGE_PORT = 8787
WORLDFORGE_URL = f"http://{WORLDFORGE_HOST}:{WORLDFORGE_PORT}/index.html"


# --- Pure logic helpers (unit-tested) --------------------------------------


def build_models_url(base_url: str) -> str:
    """Build the /models endpoint URL from a base URL.

    OpenAI-compatible base URLs conventionally end with /v1; we simply append
    '/models' (stripping any trailing slash). If the user already typed the
    full /v1/models path we leave it alone.
    """
    if not base_url:
        raise ValueError("base_url must not be empty")
    url = base_url.strip().rstrip("/")
    if not url:
        raise ValueError("base_url must not be empty")
    if url.lower().endswith("/models"):
        return url
    return url + "/models"


def build_auth_headers(api_key: str) -> Dict[str, str]:
    """Build the Authorization header dict for a Bearer token."""
    key = (api_key or "").strip()
    if not key:
        return {}
    return {"Authorization": f"Bearer {key}"}


def parse_models_response(payload: Any) -> List[str]:
    """Extract model ids from an OpenAI-compatible /models JSON payload.

    Accepts {"data": [{"id": "..."}, ...]} (OpenAI shape) as well as a bare
    list of {"id": "..."} objects. Returns ids in the order given, deduped.
    """
    if isinstance(payload, list):
        items = payload
    elif isinstance(payload, dict):
        items = payload.get("data", []) or []
    else:
        return []

    seen: set = set()
    result: List[str] = []
    for item in items:
        if isinstance(item, dict):
            mid = item.get("id")
        elif isinstance(item, str):
            mid = item
        else:
            mid = None
        if mid and mid not in seen:
            seen.add(mid)
            result.append(mid)
    return result


def fetch_models(base_url: str, api_key: str) -> List[str]:
    """GET {base_url}/models and return the model id list.

    Raises ValueError on connection/HTTP errors with a human-readable message.
    """
    url = build_models_url(base_url)
    headers = build_auth_headers(api_key)
    headers.setdefault("Accept", "application/json")
    req = Request(url, headers=headers, method="GET")
    try:
        with urlopen(req) as resp:
            raw = resp.read()
    except HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", errors="replace")[:200]
        except Exception:
            pass
        if e.code in (401, 403):
            raise ValueError(f"API key rejected (HTTP {e.code}). Check your key. {body}") from None
        raise ValueError(f"HTTP {e.code} from {url}: {body}") from None
    except URLError as e:
        raise ValueError(f"Cannot reach {url}: {e.reason}") from None
    except OSError as e:
        raise ValueError(f"Connection error reaching {url}: {e}") from None

    try:
        payload = json.loads(raw.decode("utf-8", errors="replace"))
    except json.JSONDecodeError:
        raise ValueError(f"Server response was not valid JSON (from {url}).") from None
    return parse_models_response(payload)


def filter_models(models: List[str], query: str) -> List[str]:
    """Case-insensitive substring filter over model ids."""
    q = (query or "").strip().lower()
    if not q:
        return list(models)
    return [m for m in models if q in m.lower()]


def normalize_model_selection(model_fast: str,
                              model_deep: str) -> Tuple[str, str]:
    """Validate launcher model choices and fill the optional second lane.

    A single provider model is a valid configuration: it is used for both
    lanes.  Starting with neither model selected would only defer the error to
    the first LLM-backed GUI action, so reject it while the user is still in
    the launcher.
    """
    fast = (model_fast or "").strip()
    deep = (model_deep or "").strip()
    fast = "" if fast == "(none)" else fast
    deep = "" if deep == "(none)" else deep
    if not fast and not deep:
        raise ValueError("Select at least one model before starting.")
    if not fast:
        fast = deep
    if not deep:
        deep = fast
    return fast, deep


def validate_launch_configuration(provider: str, base_url: str, api_key: str,
                                  model_fast: str, model_deep: str) -> Tuple[str, str]:
    """Validate the LLM configuration required to start WorldForge."""
    if not (base_url or "").strip():
        raise ValueError("Select a provider and enter its Base URL.")
    if provider == "OpenAI" and not (api_key or "").strip():
        raise ValueError("OpenAI requires an API Key.")
    return normalize_model_selection(model_fast, model_deep)


def launcher_next_step(base_url: str, models: List[str],
                       model_fast: str, model_deep: str,
                       provider: str = "Custom", api_key: str = "") -> str:
    """Describe the first unfinished launcher step for the GUI status bar."""
    if not (base_url or "").strip():
        return (
            "Step 1/4: select a provider and enter its Base URL. "
            "An LLM connection is required."
        )
    if provider == "OpenAI" and not (api_key or "").strip():
        return "Step 1/4: OpenAI requires an API Key before WorldForge can start."
    if not models:
        return "Step 2/4: LLM connection is ready; pull the provider model list."
    fast = (model_fast or "").strip()
    deep = (model_deep or "").strip()
    if fast in {"", "(none)"} and deep in {"", "(none)"}:
        return "Step 3/4: choose a fast model, a deep model, or one model for both."
    return "Step 4/4: LLM model selected; start WorldForge when ready."


def provider_base_url(provider: str, current_url: str) -> str:
    """Return a provider's conventional endpoint; Custom preserves user input."""
    return PROVIDER_BASE_URLS.get(provider, current_url)


def provider_for_base_url(base_url: str) -> str:
    """Infer the visible provider without rewriting a saved custom endpoint."""
    normalised = (base_url or "").strip().rstrip("/").lower()
    for provider, known_url in PROVIDER_BASE_URLS.items():
        if normalised == known_url.rstrip("/").lower():
            return provider
    return "Custom"


def save_config(base_url: str, api_key: str, model_fast: str, model_deep: str,
                path: Path = CONFIG_PATH) -> None:
    """Persist non-secret launcher config to JSON. Never raises on write failure."""
    data = {
        "base_url": base_url,
        "model_fast": model_fast,
        "model_deep": model_deep,
    }
    try:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def load_config(path: Path = CONFIG_PATH) -> Dict[str, str]:
    """Load launcher config; returns {} if missing/corrupt."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {k: str(v) for k, v in data.items() if isinstance(v, (str, int, float))}


def build_server_env(base_url: str, api_key: str, model_fast: str,
                     model_deep: str) -> Dict[str, str]:
    """Build the environment dict for the WorldForge server subprocess."""
    env = os.environ.copy()
    env[ENV_BASE_URL] = base_url
    env[ENV_API_KEY] = api_key
    env[ENV_MODEL_FAST] = model_fast
    env[ENV_MODEL_DEEP] = model_deep
    env["PYTHONPATH"] = str(BACKEND_DIR) + os.pathsep + env.get("PYTHONPATH", "")
    return env


def wait_for_server(host: str = WORLDFORGE_HOST, port: int = WORLDFORGE_PORT,
                    timeout: float = 20.0,
                    process: Optional[subprocess.Popen] = None) -> bool:
    """Poll until the WorldForge server answers on /api/health, or timeout."""
    import socket
    deadline = time.time() + timeout
    while time.time() < deadline:
        if process is not None and process.poll() is not None:
            return False
        try:
            with socket.create_connection((host, port), timeout=1.0):
                return True
        except OSError:
            time.sleep(0.3)
    return False


def port_is_in_use(host: str = WORLDFORGE_HOST,
                   port: int = WORLDFORGE_PORT,
                   timeout: float = 0.5) -> bool:
    """Return whether another process already owns the server address.

    The launcher must check this *before* spawning the backend.  Otherwise a
    failed child (``address already in use``) can be mistaken for success
    merely because the pre-existing process still accepts TCP connections.
    """
    import socket
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


# --- GUI -------------------------------------------------------------------


class LauncherApp:
    """The tkinter application. Kept thin; logic lives in module functions."""

    def __init__(self, root: Any) -> None:
        import tkinter as tk
        self.root = root
        root.title("WorldForge Launcher")
        root.geometry("720x590")
        root.minsize(640, 520)

        self.all_models: List[str] = []
        self.server_proc: Optional[subprocess.Popen] = None

        saved = load_config()
        saved_base_url = saved.get("base_url", DEFAULT_BASE_URL)
        self.provider_var = tk.StringVar(
            value=provider_for_base_url(saved_base_url),
        )
        self.base_url_var = tk.StringVar(value=saved_base_url)
        # Never prefill a secret, including one stored by an earlier launcher.
        self.api_key_var = tk.StringVar(value=DEFAULT_API_KEY)
        self.model_fast_var = tk.StringVar(value=saved.get("model_fast", ""))
        self.model_deep_var = tk.StringVar(value=saved.get("model_deep", ""))
        self.search_var = tk.StringVar(value="")
        self.status_var = tk.StringVar(value=launcher_next_step(
            self.base_url_var.get(), self.all_models,
            self.model_fast_var.get(), self.model_deep_var.get(),
            self.provider_var.get(), self.api_key_var.get(),
        ))

        self._build_ui()
        self.search_var.trace_add("write", lambda *_: self._apply_filter())
        for var in (self.base_url_var, self.api_key_var, self.model_fast_var,
                    self.model_deep_var):
            var.trace_add("write", lambda *_: self._show_next_step())
        self.provider_var.trace_add("write", lambda *_: self._apply_provider_url())

    # -- UI construction ----------------------------------------------------

    def _build_ui(self) -> None:
        import tkinter as tk
        root = self.root
        pad = {"padx": 8, "pady": 4}

        guide = tk.Frame(root, relief="groove", borderwidth=1)
        guide.pack(fill="x", padx=10, pady=(10, 6))
        tk.Label(guide, text="WorldForge setup: 1 → 4", font=("", 10, "bold")) \
            .pack(anchor="w", **pad)
        tk.Label(
            guide,
            text=("LLM required: 1. Select provider / enter connection (API Key is not saved or prefilled)  "
                  "→  2. Pull models  →  3. Select fast/deep models  →  "
                  "4. Start WorldForge"),
            justify="left", wraplength=680,
        ).pack(anchor="w", **pad)

        # Provider frame
        prov = tk.Frame(root, relief="groove", borderwidth=1)
        prov.pack(fill="x", padx=10, pady=(0, 6))
        tk.Label(prov, text="1. Provider and connection", font=("", 10, "bold")) \
            .grid(row=0, column=0, columnspan=3, sticky="w", **pad)

        tk.Label(prov, text="Provider:").grid(row=1, column=0, sticky="e", **pad)
        tk.OptionMenu(prov, self.provider_var, *PROVIDER_OPTIONS) \
            .grid(row=1, column=1, columnspan=2, sticky="we", **pad)

        tk.Label(prov, text="Base URL:").grid(row=2, column=0, sticky="e", **pad)
        tk.Entry(prov, textvariable=self.base_url_var, width=55) \
            .grid(row=2, column=1, columnspan=2, sticky="we", **pad)

        tk.Label(prov, text="API Key:").grid(row=3, column=0, sticky="e", **pad)
        tk.Entry(prov, textvariable=self.api_key_var, width=55, show="*") \
            .grid(row=3, column=1, columnspan=2, sticky="we", **pad)

        self.pull_btn = tk.Button(prov, text="2. Pull Models", command=self.on_pull)
        self.pull_btn.grid(row=4, column=1, sticky="w", **pad)

        prov.columnconfigure(1, weight=1)

        # Models frame
        mfrm = tk.Frame(root, relief="groove", borderwidth=1)
        mfrm.pack(fill="both", expand=True, padx=10, pady=6)
        tk.Label(mfrm, text="3. Select models", font=("", 10, "bold")) \
            .grid(row=0, column=0, columnspan=2, sticky="w", **pad)

        tk.Label(mfrm, text="Search:").grid(row=1, column=0, sticky="e", **pad)
        tk.Entry(mfrm, textvariable=self.search_var, width=40) \
            .grid(row=1, column=1, sticky="we", **pad)
        self.count_lbl = tk.Label(mfrm, text="0 models")
        self.count_lbl.grid(row=1, column=2, sticky="w", **pad)

        tk.Label(mfrm, text="Model (fast):").grid(row=2, column=0, sticky="e", **pad)
        self.fast_combo = tk.OptionMenu(mfrm, self.model_fast_var, "(none)")
        self.fast_combo.configure(width=40)
        self.fast_combo.grid(row=2, column=1, columnspan=2, sticky="we", **pad)

        tk.Label(mfrm, text="Model (deep):").grid(row=3, column=0, sticky="e", **pad)
        self.deep_combo = tk.OptionMenu(mfrm, self.model_deep_var, "(none)")
        self.deep_combo.configure(width=40)
        self.deep_combo.grid(row=3, column=1, columnspan=2, sticky="we", **pad)

        mfrm.columnconfigure(1, weight=1)

        # Launch + status
        bot = tk.Frame(root)
        bot.pack(fill="x", padx=10, pady=(4, 10))
        self.launch_btn = tk.Button(bot, text="4. Start WorldForge", command=self.on_launch,
                                    height=2, font=("", 11, "bold"))
        self.launch_btn.pack(fill="x", **pad)

        self.status_lbl = tk.Label(bot, textvariable=self.status_var, relief="sunken",
                                   anchor="w", justify="left", wraplength=680)
        self.status_lbl.pack(fill="x", **pad)

        root.protocol("WM_DELETE_WINDOW", self.on_close)

    # -- Actions -----------------------------------------------------------

    def _set_status(self, msg: str) -> None:
        self.status_var.set(msg)

    def _show_next_step(self) -> None:
        self._set_status(launcher_next_step(
            self.base_url_var.get(), self.all_models,
            self.model_fast_var.get(), self.model_deep_var.get(),
            self.provider_var.get(), self.api_key_var.get(),
        ))

    def _apply_provider_url(self) -> None:
        """Apply the selected provider's conventional endpoint when available."""
        selected_url = provider_base_url(
            self.provider_var.get(), self.base_url_var.get(),
        )
        if selected_url != self.base_url_var.get():
            self.base_url_var.set(selected_url)
        self._show_next_step()

    def _populate_combos(self) -> None:
        """Rebuild the dropdown option lists from self.all_models + search filter."""
        filtered = filter_models(self.all_models, self.search_var.get())
        self.count_lbl.config(text=f"{len(filtered)} / {len(self.all_models)} models")
        for combo, var in ((self.fast_combo, self.model_fast_var),
                           (self.deep_combo, self.model_deep_var)):
            menu = combo["menu"]
            menu.delete(0, "end")
            menu.add_command(label="(none)",
                             command=lambda v=var: v.set("(none)"))
            for m in filtered:
                menu.add_command(label=m, command=lambda v=var, val=m: v.set(val))
            cur = var.get()
            if cur and cur != "(none)" and cur not in filtered:
                # keep current selection even if filtered out of view
                menu.add_command(label=cur, command=lambda v=var, val=cur: v.set(val))

    def _apply_filter(self) -> None:
        self._populate_combos()

    def on_pull(self) -> None:
        base_url = self.base_url_var.get().strip()
        api_key = self.api_key_var.get().strip()
        if not base_url:
            self._set_status("Step 1/4 incomplete: an LLM Base URL is required.")
            return
        if self.provider_var.get() == "OpenAI" and not api_key:
            self._set_status("Step 1/4 incomplete: OpenAI requires an API Key.")
            return
        self.pull_btn.config(state="disabled")
        self._set_status(f"Step 2/4: pulling models from {base_url} ...")

        def work() -> None:
            try:
                models = fetch_models(base_url, api_key)
            except ValueError as e:
                self.root.after(0, lambda: self._pull_failed(str(e)))
                return
            self.root.after(0, lambda: self._pull_done(models))

        threading.Thread(target=work, daemon=True).start()

    def _pull_failed(self, msg: str) -> None:
        self.pull_btn.config(state="normal")
        self._set_status(f"Step 2/4 failed: {msg}. Check the provider connection, then pull again.")
        self.all_models = []
        self._populate_combos()

    def _pull_done(self, models: List[str]) -> None:
        self.pull_btn.config(state="normal")
        self.all_models = models
        # auto-select first model if none chosen yet
        if models:
            if not self.model_fast_var.get() or self.model_fast_var.get() == "(none)":
                self.model_fast_var.set(models[0])
            if not self.model_deep_var.get() or self.model_deep_var.get() == "(none)":
                self.model_deep_var.set(models[-1])
        self._populate_combos()
        if models:
            self._set_status("Step 3/4: models loaded; confirm the fast/deep selections.")
        else:
            self._set_status("Step 2/4 complete, but the provider returned no models.")

    def on_launch(self) -> None:
        base_url = self.base_url_var.get().strip()
        api_key = self.api_key_var.get().strip()
        model_fast = self.model_fast_var.get()
        model_deep = self.model_deep_var.get()
        try:
            model_fast, model_deep = validate_launch_configuration(
                self.provider_var.get(), base_url, api_key, model_fast, model_deep,
            )
        except ValueError as exc:
            self._set_status(f"LLM configuration incomplete: {exc}")
            return

        save_config(base_url, api_key, model_fast, model_deep)
        env = build_server_env(base_url, api_key, model_fast, model_deep)

        self.launch_btn.config(state="disabled")
        self._set_status("Step 4/4: starting WorldForge with the configured LLM ...")

        def work() -> None:
            try:
                self._start_server(env)
            except Exception as e:  # pragma: no cover - GUI path
                self.root.after(0, lambda: self._set_status(f"Start failed: {e}"))
                self.root.after(0, lambda: self.launch_btn.config(state="normal"))
                return
            if wait_for_server(process=self.server_proc):
                self.root.after(0, lambda: self._server_up())
            else:
                self.root.after(0, lambda: self._set_status(
                    "Server did not respond in time. Check console for errors."))
                self.root.after(0, lambda: self.launch_btn.config(state="normal"))

        threading.Thread(target=work, daemon=True).start()

    def _start_server(self, env: Dict[str, str]) -> None:
        if port_is_in_use():
            raise RuntimeError(
                f"port {WORLDFORGE_PORT} is already in use; "
                "close the existing WorldForge/server process and retry"
            )
        cmd = [sys.executable, "-m", "theater.server"]
        self.server_proc = subprocess.Popen(
            cmd, cwd=str(PROJECT_ROOT), env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

    def _server_up(self) -> None:
        self._set_status(f"WorldForge running at {WORLDFORGE_URL} . Opening browser ...")
        try:
            webbrowser.open(WORLDFORGE_URL)
        except Exception:
            pass
        self._set_status(f"WorldForge is running at {WORLDFORGE_URL} (close this window to stop).")

    def on_close(self) -> None:
        if self.server_proc and self.server_proc.poll() is None:
            try:
                self.server_proc.terminate()
                try:
                    self.server_proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.server_proc.kill()
            except Exception:
                pass
        self.root.destroy()


def main() -> None:
    import tkinter as tk  # local import so module import (for tests) doesn't require a display
    root = tk.Tk()
    LauncherApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
