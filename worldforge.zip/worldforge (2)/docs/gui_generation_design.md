# 动态 GUI 生成设计

## 1. 目标

每个世界可以拥有不同的信息布局和操作控件，但所有界面必须共享同一套安全
协议：

- LLM 只提出 `gui_spec`；
- 用户在 onboarding 中检查和编辑；
- 编译器只接受闭合 schema；
- 控件只发送白名单意图；
- 状态变化仍由后端校验门和确定性内核裁决。

GUI 生成不能按世界描述匹配内置题材模板。LLM 是生成 GUI 规格的必需依赖：模型
未配置、调用失败、返回无效 JSON 或未通过校验时，propose/confirm 阶段必须失败，
不持久化也不挂载替代界面。已确认并持久化的规格仍可由确定性编译器装载。

## 2. 数据流

```text
world description
  → LLM proposes gui_spec
  → schema validation
  → user edits and confirms
  → persist per world_id
  → deterministic HTML/CSS compiler
  → browser mount
  → input router
  → public backend API
```

模型不生成可执行 JavaScript、网络地址或任意 CSS。它只能从闭合集合中选择
控件类型、布局 token、语义颜色和绑定。

## 3. `gui_spec`

最小结构：

```json
{
  "gui_spec_id": "example_console",
  "schema_version": 1,
  "world_id": "example",
  "layout_type": "dashboard",
  "grid": {
    "columns": "minmax(0, 2fr) minmax(0, 1fr)",
    "rows": "auto 1fr auto",
    "areas": [
      "status controls",
      "log controls",
      "input input"
    ]
  },
  "chrome": "instrument_bezel",
  "widgets": [],
  "color_scheme": {},
  "typography": {},
  "icon_style": "instrument",
  "motion": "free",
  "semantic_slots": {},
  "provenance": {
    "proposed_by": "llm"
  }
}
```

`grid.areas` 只允许合法 CSS Grid 标识符。编译器拒绝 URL、`@import`、
`expression()`、脚本片段和越界 token。

## 4. 控件闭集

### 4.1 执行类

| 类型 | 用途 |
|---|---|
| `slider` / `dial` | 有界数值输入 |
| `button` / `button_group` | 单次动作 |
| `card_row` | 从结构化候选中选择 |
| `toggle` | 布尔选择 |
| `text_field` | 文本输入 |
| `commit_bar` | 明确提交一次决策 |

### 4.2 显示类

| 类型 | 用途 |
|---|---|
| `canvas_panel` | 内核数值、曲线、拓扑或地图 |
| `gauge` / `lamp` / `meter` | 标量和布尔状态 |
| `table` / `ledger_grid` | 结构化记录 |
| `log_feed` / `timeline` | 事件与历史 |
| `map_panel` | 空间状态 |
| `nameplate` / `cue_row` | 当前主体和提示 |
| `belief_panel` | 主观信念与置信度 |
| `commitment_list` | 活跃承诺 |
| `causal_trace_panel` | 因果追踪 |
| `outcome_chapter` | 本拍结果摘要 |
| `text` | 静态文本和错误/状态提示 |

显示类控件只能读取状态投影，不能直接写状态。

## 5. 绑定协议

每个 widget 通过 `binds` 接线：

```json
{
  "name": "advance",
  "type": "commit_bar",
  "area": "controls",
  "label": "推进一拍",
  "binds": {
    "emit": "decision_vector",
    "action": "world/tick",
    "commit": true
  }
}
```

允许的执行目标：

- `dispatch`
- `interact`
- `world/tick`
- onboarding 的 propose/confirm
- 规则、玩法、认知模型和 GUI 的生成/确认动作
- 世界创建、切换、fork、删除
- 存档、恢复和列表

允许的通用意图：

- `utterance`
- `world_update`
- `playfield_action`
- `decision_vector`

`read` 只允许受控前缀：

- `state:`
- `kernel:`
- `world:`
- `agent:`

编译器必须拒绝任意路径、协议 URL、文件路径和未登记动作。

## 6. 提议与确认

### propose

1. 读取世界描述、已确认规则和可用状态字段。
2. 请求 `world_builder` 返回严格 JSON。
3. 将 JSON 转换为 `GUISpec`。
4. 运行 `validate_gui_spec`。
5. 返回预览，不持久化。

### confirm

1. 接收用户编辑后的完整规格。
2. 再次做同样的确定性校验。
3. 写入 `gui_specs/<world_id>.json`。
4. 返回浏览器可直接挂载的 JSON。

确认接口不接受代码片段。

## 7. 编译器

`compile_to_css` 只负责：

- CSS Grid；
- 字体和间距 token；
- chrome token；
- semantic role 到 CSS 变量的映射；
- 普通、可关闭的过渡效果。

`compile_to_html_template` 为每个控件生成带 `data-*` 属性的 DOM 骨架。所有
文本都进行 HTML 转义，所有属性都进行属性转义。

编译结果不包含内联脚本。行为由仓库内固定的
`web/gui/dynamic_gui.js` 提供。

## 8. 浏览器运行时

`dynamic_gui.mount()`：

1. 清理旧界面；
2. 应用确认后的 theme；
3. 构造 widget DOM；
4. 扫描 `data-binds-*`；
5. 把执行控件接到 `web/input/router.js`；
6. 轮询或刷新公开状态；
7. 把结果投影回显示控件。

Router 根据 `action` 调用：

- `/api/dispatch`
- `/api/interact`
- `/api/world/tick`
- 对应的 onboarding 或世界管理接口

客户端不得假定任何题材字段存在。专用适配器的数据只能通过显式
`world_id` 和已启用内核暴露。

## 9. 失败处理

GUI 规格的生成和确认必须由 LLM 返回完整、合法的结构。模型缺失、调用失败、
JSON 解析失败或 schema 校验失败时，接口返回结构化错误，保持已有持久化规格和
世界状态不变；不得合成布局、补齐字段或挂载替代 GUI。用户修订输入或恢复模型
服务后可重新请求。该规则不影响已确认规格的确定性 HTML/CSS 编译和装载。

## 10. 验收

必须覆盖：

1. 非法 widget、layout、bind 和 CSS token 被拒绝；
2. HTML 和属性转义；
3. propose 不落盘，confirm 才落盘；
4. `world_id` 隔离；
5. LLM 未配置、调用失败或返回坏 JSON 时，GUI 提议被拒绝且不产生替代界面；
6. 已确认的 GUI 规格可在不重新生成时正常挂载；
7. 浏览器脚本语法检查；
8. GUI 操作的 API 冒烟测试。
