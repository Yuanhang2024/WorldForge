# 世界观耦合与语义失败审计

审计范围：全仓库检索，代码复核重点为 `backend/theater` 的创建、规则生成、
GUI、玩法、认知模型、dispatch、tick、state 与 onboarding 链路。`web/**`、
`launcher.py`、LLM HTTP/timeout 不在本次修改范围。

## 不变量

1. 普通世界链路不得根据描述、题材关键词、`world_type`、embedding 相似度或
   未声明的默认值选择任何内置世界、规则、GUI、玩法、认知模型或主体系统。
2. 生成规则、GUI、玩法、认知模型、导演意图、因果叙事和三体叙事等语义工作
   必须由已配置且成功返回合法结果的 LLM 完成。模型缺失、调用失败、解析失败或
   验证失败时，本步显式失败，不写入伪造语义；不得返回结构化替代物、预设文案或
   由事件日志拼接出的叙事。
3. 已经成功生成并持久化的规则可以由确定性执行器离线运行；显式物理适配器也可
   确定性计算状态和判决。确定性执行结果不等于确定性生成或叙事。
4. 专用能力只能由精确 ID、显式参数、显式类/函数或独立 API 路由启用。
   `/api/three_body/*`、`three_body_tick()`、`kernels/three_body.py` 属于允许的
   显式参考适配器；普通 `/api/world/*` 缺省不得进入它们。
5. `world_type` 是世界数据，不是框架策略开关。会改变写入、约束或执行策略的
   字段必须单独显式声明。
6. `WorldCreator.create()` 每次创建都生成未占用的 `world_id`；重复建议 ID
   不得打开、覆盖或修改已有世界。

## 已收口的普通链路

| 文件 / 符号 | 原问题 | 当前边界 |
|---|---|---|
| `backend/theater/server.py::_handle_world_tick` | 普通 tick 曾缺省进入三体 | 缺省 `generic`/`world_tick`；只有显式 `mode="three_body"` 进入适配器；未知 mode 拒绝 |
| `backend/theater/server.py::_handle_world_fast_forward` | 未知 mode 曾落入专用分支 | 缺省使用当前通用世界；显式三体模式才进入适配器；未知 mode 拒绝 |
| `backend/theater/world_creation.py` | 普通创建顶层载入三体；重复 ID 可复用旧文件 | 三体仅在 `enabled_kernels` 精确包含 `three_body` 时局部导入；创建在锁内分配唯一 ID，绝不修改旧世界 |
| `backend/theater/dispatcher.py` 的 import/装配 | 普通 dispatch/tick 曾加载专用内核或专用 agent 设置 | 三体内核仅由显式函数按需导入；普通 agent 开关为通用 `enable_agent_mind` |
| `backend/theater/dispatcher.py::dispatch` | director 失败可被启发式 intent/brief 代替 | director 必须返回受支持的精确 intent 和非空 brief；模型/结构失败显式抛错，写入发生在验收之后 |
| `backend/theater/dispatcher.py::dispatch` / `world_scope` | 运行期只看短历史且共享可变当前世界，并发请求可能串台 | 每次 LLM 调用携带该世界的参数、角色、物件、内核状态和最近 12 条世界书；显式 `world_id` 绑定线程内请求作用域并在结束后恢复，不改变全局选择 |
| `backend/theater/dispatcher.py::_run_causal_narrative` | tick 可用确定性 planner/realizer 伪造叙事 | 必须显式装配模型驱动的 `CausalNarrativeEngine`；缺失或失败时该语义阶段失败 |
| `backend/theater/dispatcher.py::world_tick` | 叙事失败可能被吞掉或伪装为成功 | 已生成规则的确定性事件先持久化；后续语义叙事失败明确抛错，不新增伪造叙事 |
| `backend/theater/dispatcher.py::_create_character_mixed` | 手填/模型补全边界不清楚 | 五个 card 字段完整时直接保存且不调用模型；存在缺字段时必须调用模型，失败或仍不完整则不写入 |
| `backend/theater/dispatcher.py::three_body_tick` | beat/outcome 可由事件日志、模板或安全文案补齐 | 物理判决仍确定性；任何叙事缺失/解析/NLI 失败均抛错，不写入语义替代物 |
| `backend/theater/three_body_narrator.py` | 专用 narrator 曾以 outcome/beat 模板替代生成 | 所有 `narrate_*` 需要 LLM；解析、验证、NLI/词法一致性失败均显式失败 |
| `backend/theater/causal_narrative.py` | 通用叙事内置三体词表且有确定性实现 | 移除内置世界词表和确定性 planner/realizer；模型叙事未通过一致性检查时失败 |
| `backend/theater/gameplay_generator.py::generate` | 模型缺失时曾按 poker/dice/card 等词猜玩法，未知描述默认 deck | 普通生成必须有 LLM；库玩法只能通过精确 `kernel_id` 显式选择，未知 ID 拒绝 |
| `backend/theater/cognitive_model_generator.py` | 描述/角色关键词选择 three_body/economy/politics，未知描述默认 three_body | 普通生成必须有 LLM且无题材 few-shot；参考模型只能按精确 ID 显式取得 |
| `backend/theater/rule_generator.py::generate` | 关键词/preset_map 可暗选预置规则 | `preset_map` 被拒绝；普通生成只接受通过验证的 LLM 输出；失败不安装替代规则 |
| `backend/theater/rule_promotion.py::promote_for_path` | promotion 失败时可由路径/预置模板生成规则 | promotion 必须有 LLM；生成、规则/spec 验证或安装失败均抛错，并保持 host/tracker 不变 |
| `backend/theater/gui_generator.py::generate` | 可合成通用布局、修正非法字段或按 preset 返回 GUI | GUI 必须由 LLM 返回完整合法结构；生成器只做输入形状归一化，不补字段、不改语义、不丢非法 widget |
| `backend/theater/onboarding_llm.py` | 规则/GUI 失败曾返回中性 fallback | 两个阶段均要求 LLM 成功并通过验证，失败显式上抛 |
| `backend/theater/server.py` 的 GUI/summary 边界 | GET 可即时合成 GUI；summary 可退化为日志摘要 | GUI 只读取已持久化规范；summary 必须来自模型，原始日志只能作为失败诊断，不能伪装为摘要 |
| `backend/theater/world_kernel_host.py` | `world_type=="physical"/"three_body"` 可隐式选择 `constitutive` | `constraint_type` 显式持久化，缺省 `content`；`world_type` 不参与分类 |
| `backend/theater/settings.py` | 通用设置曾有默认开启的专用 agent 旗标 | 删除专用旗标；通用开关只作用于显式注册的 simulation |

## 允许保留的显式入口和参考夹具

下列符号含世界专用名称或静态参考数据，但普通描述不会自动触达它们。

| 文件 / 符号 | 允许原因 / 边界 |
|---|---|
| `backend/theater/kernels/three_body.py::ThreeBodyKernel` | 独立确定性参考内核；普通创建不导入、不实例化 |
| `backend/theater/server.py::_handle_three_body_bake`、`_handle_three_body_state` | 只绑定显式 `/api/three_body/*` 路由 |
| `backend/theater/dispatcher.py::three_body_tick` 及 `_three_body_*` | 函数名和调用均显式；普通 `world_tick` 不调用 |
| `backend/theater/three_body_narrator.py`、`three_body_agents.py` | 只由显式三体 tick 装配；虽是专用 adapter，叙事仍必须来自 LLM |
| `backend/theater/cognitive_model.py::ThreeBodyCognitiveModel` | 明确命名的协议适配器 |
| `backend/theater/dag.py::three_body_cognition_dag` | 明确命名的参考 DAG 工厂；通用 `PrerequisiteDAG` 不调用 |
| `backend/theater/multi_kernel.py::ThreeBodyKernelModule` | 显式模块类且内部按需导入；不得自动注册 |
| `backend/theater/cognitive_model_generator.py::PRESET_SPECS` | 显式参考/测试夹具；只能通过精确 ID 获取 |
| `backend/theater/rule_generator.py::_PRESET_BUILDERS` | 显式参考/测试夹具；普通 `generate()` 不可达 |
| `backend/theater/game_kernels.py::KERNEL_REGISTRY` | 参数化玩法库；只有显式 `kernel_id` 可选择 |
| `backend/theater/game_kernels.py::match_kernel` | 旧显式工具 API；禁止 onboarding/runtime 自动调用 |
| `backend/theater/agents.py::DeterministicModelClient` | 仅供测试/演示的显式注入 stub；生产构建不得自动装配或退化至此 |

## 关键回归覆盖

- `tests/test_world_creation.py`：描述关键词不改变默认参数；三体 preview 只由
  `enabled_kernels=["three_body"]` 启用；重复建议 ID 创建新文件且旧文件不变。
- `tests/test_gameplay_generator.py`、`tests/test_cognitive_model_generator.py`、
  `tests/test_rule_generator.py`、GUI tests：普通生成在模型缺失、解析失败或验证失败时均
  明确失败；精确 ID 参考夹具单独测试。
- `tests/test_rule_promotion.py`：模型、生成、验证失败不安装规则且不重置 tracker。
- `tests/test_causal_narrative.py`、`tests/test_agent_mind_tick_wiring.py`：普通 tick
  没有确定性叙事替代物；模型驱动 engine 必须显式装配。
- `tests/test_three_body_narrator.py`、`tests/test_arch_tension_p1_narrator.py`、
  `tests/test_three_body_tick.py`：显式适配器保留确定性物理判决，但叙事失败不伪装成功。
- `tests/test_character_create.py`：完整手填 card 不调用模型；缺字段路径只有模型成功
  补齐全部字段才写入。
- `tests/test_worldbook_provenance.py`：不再合成第二个 deterministic outcome chapter。
- `tests/test_world_isolation.py`：两个世界并发 dispatch 时提示上下文和最终写入均不串台；
  请求结束后全局当前世界不被隐式切换。
- `tests/test_p0_kernel_spec_persistence.py`：`world_type` 不决定约束类型；显式
  `constraint_type` 可序列化、恢复和执行。

## 复核命令

```powershell
rg -n -i --glob 'backend/**/*.py' `
  'three[_ -]?body|三体|preset|keyword|match_kernel'
python -m py_compile backend/theater/*.py
python -m pytest tests/test_world_creation.py tests/test_gui_generator.py `
  tests/test_gameplay_generator.py tests/test_cognitive_model_generator.py `
  tests/test_rule_generator.py tests/test_rule_promotion.py `
  tests/test_causal_narrative.py tests/test_three_body_narrator.py `
  tests/test_character_create.py tests/test_dispatcher.py -q
```

检索命中本身不等于违规：验收标准是普通入口的调用图不触达显式参考适配器，
并且任何语义失败都不会被确定性内容掩盖。
