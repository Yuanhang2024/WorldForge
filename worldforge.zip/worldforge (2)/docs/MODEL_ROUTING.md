# 多模型路由

WorldForge 通过标准 OpenAI-compatible 接口连接模型。正常流程是在
`launch.bat` / `launch.sh` 打开的 Tk 窗口中填写 Base URL、API Key，拉取
供应商模型列表并选择 fast/deep 模型；启动器会把选择写入当前后端进程。

## 角色

| Role | 职责 |
|---|---|
| `producer` | 请求识别、结构化世界更新、导演摘要 |
| `science_director` | 规则 DSL、约束和结构化校验 |
| `world_builder` | 世界设定、角色文本、叙事和 GUI 提议 |

这些角色只决定把哪类文本或结构化请求发给哪个模型。确定性结果仍由内核
裁定，模型选择不会改变写入权限。

## 路由优先级

从高到低：

1. `AI_THEATER_AGENT_{ROLE}_MODEL`
2. Tk 启动器或环境中的 `AI_THEATER_MODEL_FAST`
3. 该角色的内置缺省值

deep 路径使用 `AI_THEATER_MODEL_DEEP`；未设置时回落到 fast 模型。供应商
返回的模型 ID 原样发送，只有有限的历史逻辑名会做精确兼容映射。

## 全局配置

```bash
AI_THEATER_BASE_URL=http://127.0.0.1:1234/v1
AI_THEATER_API_KEY=local
AI_THEATER_MODEL_FAST=my-provider/fast-model
AI_THEATER_MODEL_DEEP=my-provider/deep-model
AI_THEATER_ENABLE_LIVE_API=true
```

支持 `bearer`、`api-key` 和 `x-api-key` 三种鉴权头：

```bash
AI_THEATER_AUTH_HEADER_TYPE=bearer
```

## 单角色覆盖

任一角色都可以单独指定模型、端点、凭据和开关：

```bash
AI_THEATER_AGENT_WORLD_BUILDER_MODEL=my-provider/writer
AI_THEATER_AGENT_WORLD_BUILDER_BASE_URL=http://127.0.0.1:1235/v1
AI_THEATER_AGENT_WORLD_BUILDER_API_KEY=local
AI_THEATER_AGENT_WORLD_BUILDER_AUTH_HEADER_TYPE=bearer
AI_THEATER_AGENT_WORLD_BUILDER_ENABLE_LIVE_API=true
```

未覆盖的角色继续使用全局端点。这样既可在一个兼容服务中按模型 ID 路由，
也可把不同角色部署到不同端点。

## 安全与诊断

- 没有 API Key 时，live API 默认关闭。
- 公开配置只返回掩码凭据。
- `/api/provider/models` 用于拉取模型列表。
- `/api/provider/diagnostics` 检查端点、模型可见性和文本请求。
- 模型调用会等待供应商返回；模型未配置、请求失败或输出无效时，对应创建或语义
  请求失败并返回结构化诊断，不安装规则、文本或 GUI 替代物。

## 验证

```bash
python -m pytest tests/test_model_routing.py tests/test_settings.py -q
```
