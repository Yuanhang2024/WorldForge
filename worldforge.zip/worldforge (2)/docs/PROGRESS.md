# 决策承诺补全 — 进度日志 (Phase4-8 接线 + 3 行动 + 测试)

## 目标
- Tick Phase4-8 接线 (dispatcher.world_tick + enable_commitments)
- 3 类通用重大行动 (launch_project / establish_policy / mobilize_faction)
- 测试 >=25
- 全套零回归

## 进度
- [x] 读 commitments.py / decision_resolver.py / dispatcher.py / settings.py / character_graph.py / observation_filter.py
- [x] settings.from_env 接 enable_commitments 环境变量
- [x] commitments.py 扩展: 3 类行动 builder + mobilize 关系图影响
- [x] dispatcher Phase4-8 接线 (world_tick + enable_commitments, 默认 False 向后兼容)
- [x] 测试 test_commitments.py (54 项, 覆盖全部要求场景)
- [x] 全套回归: 1641 passed (基线 1587 + 54 新), 0 回归

## 接线点
- TheaterOrchestrator.__init__: _commitment_state 注册表 (per-world)
- _commitments_enabled property (settings.enable_commitments)
- register_agent_agenda / register_commitment_proposal / get_commitment_executor / get_commitment_state
- _commitment_layer: 懒建 executor+resolver+agendas+world_state
- _tick_commitments: Phase4-8 主循环
- _agenda_proposal / _opportunity_fit / _failure_risk / _resources_for / _authority_for /
  _org_support_for / _opposition_for / _environment_for / _project_broadcast / _record_commitment_beat / _commitment_brief
- world_tick: enable_commitments 时在 AgentMind 之后调 _tick_commitments, 结果进 model_trace["commitments"] + narration prompt

## 3 类行动设计
- build_launch_project_proposal: budget+labor, 长 duration, 完成时产 scheduled effect (project_output)
- build_establish_policy_proposal: authority, 短 enactment, 立即 policy.enacted flag + 长期 modifier
- build_mobilize_faction_proposal: personnel+morale, 关系图 ripple (rally trust up / oppose conflict up), _opposition_refs stash
- authority_for_action / customize_effects / resource_requirements_for (scale 可调)

## 通用示例
某主体提议一个持续 8 个 tick 的项目；即使拥有完整权限，组织只批准 40%
预算时，资源系数会降低，结果可被标记为部分完成，并留下跨 tick 生效的
`WorldModifier`。承诺在注册和激活后逐拍推进，而不是瞬时完成。

===TASK DONE: 决策承诺补全===
