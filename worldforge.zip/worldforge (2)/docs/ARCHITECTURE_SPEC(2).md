# WorldForge 通用架构规范

## 1. 目标

WorldForge 是一个 GUI 优先、模型无关的世界模拟框架。用户在 Tk
启动器中配置任意 OpenAI-compatible 服务并选择模型，随后在浏览器中完成
世界创建、角色创建、规则确认、交互、推进和存档。

框架把职责分成两类：

- LLM 起草规则、角色文本、GUI 规格和叙事表达。
- 确定性内核验证规则、执行状态变化并裁定可计算结果。

运行时协议不得依赖特定题材。仓库内的三体内核只是显式启用的参考适配器，
不能成为普通世界的默认规则或降级模板。

## 2. 全局不变量

### I1：确定性真相由内核裁定

凡是存在确定性真相源的结果，都由内核计算。LLM 可以解释结果，但不能覆盖
结果。

### I2：LLM 输出不能直接写状态

模型输出先解析成闭合结构，再经过 schema、前提、权限和不变量校验。自由文本
只能进入叙事记录。

### I3：单一写入点

所有正典状态变化最终通过编排器写入点进入 `StateTransaction` 和
`RuleEngine`。HTTP handler、角色 Agent 和 GUI 控件都不能绕过该边界。

### I4：世界隔离

状态、规则规格、玩法规格、GUI 规格和运行时缓存都按 `world_id` 隔离。
构成性参数确认后不可原地改写；需要不同定律时创建新世界或 fork。

### I5：模型无关

供应商通过标准 OpenAI-compatible 协议接入。模型 ID 由启动器、环境变量或
持久化配置提供，业务代码不按模型名称或世界题材分支。

### I6：GUI 完整操作

正常用户流程不要求命令行。动态 GUI 的执行控件只能发出白名单意图，并通过
统一 router 进入公开 API。CLI 只作为自动化和诊断入口。

### I7：语义失败即阻断

世界创建和语义运行必须获得已配置 LLM 的合法结果。供应商不可用、调用失败、
解析失败或校验失败时，对应阶段返回可解释的结构化错误并保持状态不变；不得
安装任何安全内核、通用 GUI、角色卡或题材规则作为替代物。已确认规则的确定性
执行与显式适配器计算不属于语义替代。

## 3. 分层

```text
Tk 启动器
  └─ 供应商配置、模型选择、服务健康检查
        ↓
浏览器 GUI
  └─ onboarding、动态控件、状态投影、COMMIT
        ↓
HTTP 网关
  └─ 输入校验、world_id 路由、公开 API
        ↓
编排器
  ├─ LLM 角色路由
  ├─ 单一写入点
  ├─ AgentMind / commitments
  └─ 世界时钟
        ↓
确定性内核
  ├─ 规则 DSL 编译与执行
  ├─ 前提 DAG
  ├─ 状态事务
  ├─ 不变量校验
  └─ 可选内核适配器
        ↓
JSON 持久层
  └─ 世界状态、规则、玩法、GUI、迁移和存档
```

## 4. 模型角色

生产路径只保留文本与结构化推理角色：

| 角色 | 职责 |
|---|---|
| `producer` | 识别请求、提出世界更新、生成结构化导演摘要 |
| `science_director` | 起草和检查规则、约束与结构化变更 |
| `world_builder` | 世界设定、角色卡、叙事表达和 GUI 提议 |

启动器可以让这些角色共用一个模型，也可以通过环境变量分别覆盖。无论选择
什么模型，校验门和内核裁决均保持不变。

## 5. 世界生命周期

### 5.1 创建

1. 用户输入世界描述。
2. 系统提出 `WorldProposal`。
3. 用户在 GUI 中检查并编辑世界参数。
4. `WorldCreator.create` 建立隔离状态。
5. onboarding 分阶段提出并确认角色、规则、玩法、认知模型和 GUI。

每一阶段都采用 propose → edit → confirm；确认之前不得进入正典。

### 5.2 运行

```text
GUI intent
  → router
  → dispatch / interact / world tick
  → 结构化提议
  → 校验门
  → 单一写入点
  → 状态提交
  → GUI 重新读取状态投影
```

世界时钟可以在用户离开后按配置继续推进，但必须有饱和上限，并在用户重新
操作后重置空闲计数。

### 5.3 fork

fork 复制可变状态并记录 `created_from`。新世界可以选择不同的构成性参数，
原世界保持可复现。

## 6. 状态模型

当前世界状态由以下稳定部分组成：

```json
{
  "_meta": {
    "schema_version": 6,
    "world_id": "example",
    "created_from": null,
    "generator_ids": {
      "llm": null,
      "gui_compiler": null
    },
    "world_params": {},
    "integrity_flags": {}
  },
  "worldbook": [],
  "characters": [],
  "objects": []
}
```

角色是文本身份、性格、示例台词、权限和 AgentMind 状态的组合。场景对象是
具备位置、状态、材质、耐久度和可供性的结构化实体。两者都不拥有绕过校验门
的写权限。

`WorldBookEntry.provenance` 必须区分：

- `canonical_event`
- `narrative_text`
- `agent_observation`
- `agent_belief`
- `rumor`
- `lore`

叙事文本不能被下一拍当成确定性事实。

## 7. 规则与内核

LLM 起草的规则使用闭合 JSON DSL。编译器只接受白名单操作、显式读写路径和
有界参数。规则安装前至少检查：

- schema 合法；
- 写路径归属；
- 前提可达；
- 数值有界；
- 守恒与领域不变量；
- 同 seed 可复现。

`MultiKernelHost` 通过事件总线组合内核。每个内核声明 `owns_paths`，同一
tick 内按稳定优先级执行，并限制级联波次数。

## 8. Agent 与承诺

角色 Agent 只能读取经过 `ObservationFilter` 的主观观察，不能直接读取全部
真相。其信念更新和行动候选可以影响提议，但最终结果仍由规则和内核裁定。

重大决定可以进入 commitment 生命周期：

```text
proposal → resolution → active commitment → scheduled effects → completion
```

承诺执行器每拍产生结构化变更，再走同一写入点。

## 9. 动态 GUI

GUI 规格描述布局、控件、主题 token 和数据绑定。编译器只生成 HTML/CSS
结构；浏览器运行时负责装载控件并绑定公开意图。

执行类控件必须绑定到闭合动作集合，例如：

- `dispatch`
- `interact`
- `world/tick`
- onboarding 的 propose/confirm 动作
- 存档、读档和世界管理动作

显示类控件只能读取公开状态投影。`canvas_panel` 可用于绘制内核数值、曲线、
拓扑或地图；它不参与状态裁决。

## 10. API 边界

公开接口按能力分组：

- 供应商诊断与模型列表；
- 世界创建、列表、切换、删除和 fork；
- onboarding 分阶段 propose/confirm；
- dispatch、interact 和 world tick；
- 规则、玩法、认知模型和 GUI；
- 角色卡与世界书文本导入；
- 状态查询、存档和恢复。

所有写接口必须验证 `world_id`、输入类型和长度。服务端错误返回结构化 JSON，
不得把异常堆栈作为成功响应。

## 11. 持久化与迁移

`JsonStateStore` 使用临时文件加原子替换，避免并发读到半写状态。schema
每次改变都必须：

1. 提升 `SCHEMA_VERSION`；
2. 在 `MigrationChain` 注册单步迁移；
3. 为旧存档增加回归测试；
4. 保证存档 load → migrate → save 收敛。

存档 zip 只包含世界状态、LLM 日志和 zip 元数据。无法迁移时输出人类可读的
降级文本，同时明确报告失败。

## 12. 安全

- 导入文本永远进入受限 user turn，不拼接进 system prompt。
- DSL 操作符和 GUI 意图均使用白名单。
- 文件名、`world_id` 和 zip 内容必须防目录穿越。
- API key 只在本机配置和请求头中使用，公开诊断只返回掩码。
- 外部调用有明确超时；语义调用失败后返回结构化错误，不生成替代内容。

## 13. 验收

发布前至少验证：

1. Python 编译与 JavaScript 语法检查通过；
2. 全量测试通过；
3. Tk 启动器能拉取并选择模型；
4. 浏览器能从空状态完成 onboarding；
5. 动态 GUI 能 dispatch、interact、tick、存档和恢复；
6. 两个世界同时运行时状态不串；
7. 同 seed、同输入序列得到相同内核轨迹；
8. 未显式启用参考适配器的世界不会加载其规则。
