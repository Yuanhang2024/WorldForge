# WorldForge · 11 页演示大纲

## Slide 1 — 一句话

**LLM 立法，确定性内核司法。**

WorldForge 让模型起草世界规则，让可测试内核裁定结果。用户通过 Tk 启动器
选择任意 OpenAI-compatible 模型，再在浏览器 GUI 中完成全部操作。

## Slide 2 — 问题

普通生成式世界把“定规则”和“判结果”交给同一个模型：

- 同一输入难以复现；
- 用户一句断言可能改写真相；
- 叙事文本混入正典状态；
- 世界离开用户后不会继续运行。

## Slide 3 — 核心边界

```text
LLM：规则草案、角色文本、叙事、GUI 规格
                    ↓
        schema / 权限 / 不变量校验
                    ↓
内核：状态变化、守恒、前提、结局
```

有确定性真相源的结果，LLM 只能解释，不能覆盖。

## Slide 4 — GUI 优先

- `launch.bat` / `launch.sh` 打开 Tk 配置窗口；
- 填 Base URL、API Key；
- 拉取并选择 fast/deep 模型；
- 启动服务并打开浏览器；
- 在浏览器完成 onboarding、交互、推进和存档。

CLI 只用于自动化和诊断，不是正常用户的必经步骤。

## Slide 5 — 一句话创建世界

```text
描述
 → 世界参数提议
 → 角色提议
 → 规则 DSL
 → 玩法与认知模型
 → 动态 GUI
 → 用户逐步确认
```

每一步都是 propose → edit → confirm。模型未配置、失败或输出无效时，该步骤
明确阻断且不写入替代规则、GUI 或叙事；恢复模型或修订输入后才能重试。

## Slide 6 — 确定性涌现

规则使用闭合 JSON DSL。条件触发、事件总线和多内核波次调度让世界在无人
干预时产生可复现的因果链。

同 seed、同输入序列必须得到同一轨迹。

## Slide 7 — 活角色

角色只观察经过过滤的主观信息：

```text
observe → update belief → choose action → propose change
```

角色行动仍要经过单一写入点。重大决定进入 commitment 生命周期，跨多个 tick
持续产生后果。

## Slide 8 — 世界隔离与 fork

- 每个 `world_id` 独立状态、规则、玩法和 GUI；
- 构成性约束确认后不可原地改写；
- 要尝试另一组定律就 fork；
- 存档包含状态、模型日志和 schema 元数据；
- 迁移失败时仍可导出人类可读历史。

## Slide 9 — 通用，而非题材硬编码

框架提供可组合机制：

- 规则 DSL 与确定性编译器；
- 前提 DAG；
- 状态事务；
- 不变量校验；
- 多内核事件总线；
- AgentMind 与 commitments；
- 动态 GUI。

三体物理是显式启用的参考适配器，只证明可计算结局可以被严格裁定。

## Slide 10 — 模型无关

- 标准 `/v1/chat/completions`；
- 任意供应商模型 ID 原样路由；
- producer / science_director / world_builder 可共用或分别配置；
- 外部请求有超时和结构化失败报告；
- API key 不进入公开响应。

## Slide 11 — 验收与承诺

演示应现场证明：

1. Tk 能拉取并选择模型；
2. 新世界可从空状态完成 onboarding；
3. 动态 GUI 能交互、推进和存档；
4. 两个世界不会串状态；
5. 同 seed 重跑结果一致；
6. 未显式启用参考适配器的世界保持中性。

结束语：

> 大多数 AI 让世界看起来成立；WorldForge 让世界按自己确认过的规则真正成立。
