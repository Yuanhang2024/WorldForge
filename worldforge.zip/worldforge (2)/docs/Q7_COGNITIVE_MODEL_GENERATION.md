# 认知模型生成

## 目的

认知模型描述某个主体能观察什么、如何形成预测，以及预测与内核真值不一致时
如何标记误判。它是通用文本世界的可选能力，不是按世界题材自动选择的预设。

LLM 可以在创建或编辑阶段起草一份声明式 `CognitiveModelSpec`。用户确认并通过
校验后，运行时以确定性方式执行该规格；LLM 不参与逐拍预测，也不能修改真值。

## 通用规格

```json
{
  "schema_version": 1,
  "agent_role": "observer",
  "truth_variables": ["system.signal", "system.threshold"],
  "observable_variables": ["system.signal"],
  "hidden_variables": ["system.threshold"],
  "failure_modes": [
    {
      "name": "partial_observation",
      "misjudged_variable": "system.threshold",
      "structure": "information_incomplete"
    }
  ],
  "prediction_template": {
    "predicted_expr": {"op": "ref", "path": "system.signal"},
    "confidence_expr": {"op": "const", "value": 0.5}
  }
}
```

表达式使用受限 AST。允许的运算、状态引用和输出范围必须由编译器的闭合集合
定义，不能包含代码、网络访问或任意属性查找。

## 校验与运行时边界

校验至少应保证：

1. 必填字段和 AST 均符合 schema；
2. 可观测与隐藏变量来自已声明的真值变量，且两者不重叠；
3. 误判项引用已声明变量，并有明确的结构说明；
4. 预测函数在相同输入下结果一致，置信度保持在 `[0, 1]`；
5. 编译结果符合 `CognitiveModel` 协议。

运行时模型只读取授权的状态投影。`model_error` 是内核或叙述层用于说明预测与
真值差异的标记，不代表主体获得隐藏真值，也不是 LLM 的裁决。

## 创建与失败处理

认知模型提议、编辑和确认必须使用 LLM，且不得依据关键词加载题材专用模板。
模型不可用、提议不合法或用户未确认时，该阶段明确失败，不持久化规格，也不得
安装最小观察模型、预设规则或任何其他替代物。已确认的 `CognitiveModelSpec`
可由确定性运行时执行，无须在每拍重新请求模型。

## 验收

- 同一规格和输入产生相同预测；
- 非法 AST、越权引用和无效置信度被拒绝；
- 不同 `world_id` 的认知模型相互隔离；
- 保存与迁移保留 schema 版本和来源信息；
- 未启用认知模型时，认知输出明确不可用且不得被替代；已确认规则的确定性推进仍可继续。
