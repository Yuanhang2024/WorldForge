@echo off
REM WorldForge launcher - Windows
cd /d "%~dp0"
python launcher.py %*
