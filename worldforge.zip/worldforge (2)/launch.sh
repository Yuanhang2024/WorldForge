#!/usr/bin/env bash
# WorldForge launcher - Linux/macOS
set -e
cd "$(dirname "$0")"
python3 launcher.py "$@"
