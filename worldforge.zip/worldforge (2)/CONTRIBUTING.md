# Contributing

PR 必须通过 CI 才能合并。当前 CI 运行完整测试套件：

1. **测试套件全绿** — `PYTHONPATH=backend python -m pytest tests/ -q`（Python 3.11 / 3.12 matrix）

## 本地预跑

在推送前本地复现 CI：

```bash
pip install -r requirements.txt
pip install pytest
PYTHONPATH=backend python -m pytest tests/ -q
```

任一非零退出码即 CI 失败、阻断合并。不要为绕过 CI 禁用测试。
